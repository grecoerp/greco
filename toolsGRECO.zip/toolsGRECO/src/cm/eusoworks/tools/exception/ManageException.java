/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.tools.exception;

import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.ui.OptionPaneDialog;
import java.util.Locale;

/**
 *
 * @author macbookair
 */
public class ManageException {

    public static void show(GrecoException ge, Locale locale) {

        if (ge.isTypeDirect()) {
            new OptionPaneDialog(locale == Locale.FRENCH ? ge.getMessage() : ge.getMessageUs(), OptionPaneDialog.APPLICATION_ERROR);
        } else {
            String msg = getErrorExplain(ge.getMessage()
                                                    .replace("java.sql.SQLException", "")
                                                    .replace("com.mysql.jdbc.exceptions.jdbc4.", "MYSQLERROR : ")
                                                    .replace(":", "").trim(), locale);
            //show boite de dialogue des erreurs personnalisee icone BD ou icone erreur
            new OptionPaneDialog( msg, OptionPaneDialog.SQL_ERROR);
        }
    }

    private static String getErrorExplain(String exceptionMessage, Locale locale) {
        String error_msg = "";
        switch (exceptionMessage) {
            case "1001":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1001 : Une entite avec ce code existe déja" : "Error 1001 : An entity with same code already exists");
                break;
            case "1002":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1002 : Une entite avec cette abbréviation existe deja" : "Error 1002 : An entity with same acronym already exists");
                break;
            case "1003":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1003 : Une entite avec cette désignation existe deja" : "Error 1003 : An entity with same label already exists");
                break;
            case "1004":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1004 : Une unite organique de meme niveau existe deja" : "Error 1004 : An entite with already exists for this level/order");
                break;
            case "1005":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1005 : Une  entite ayant cette couleur existe deja" : "Error 1005 : An entity with same color already exists");
                break;
            case "1006":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1006 : L'utilisateur système ne peut être supprimé" : "Error 1006 : System's user can't be delete");
                break;
            case "1007":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1007 : Vous essayer de creer un compte intermediaire. Il existe des comptes ayant ce radical" : "Error 1007 : There is accounts witch starts with that code");
                break;
            case "1008":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1008 : Le format/longueur du code de la banque est incorrect" : "Error 1008 : Format of bank code is incorrect");
                break;
            case "1009":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1009 : Le format/longueur du code de l'agence est incorrect" : "Error 1009 : Format of agance's code is incorrect");
                break;
            case "1010":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1010 : Le RIB saisit existe deja dans le systeme pour un autre fournisseur" : "Error 1010 : This RIB Number already exists in system for another entity");
                break;
            case "1011":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1011 : Le RIB a deja ete utilise pour le traitement d'un dossier" : "Error 1011 : This RIB is already used in commitment");
                break;
            case "1012":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1012 : Des numeros de comptes bancaires fournisseurs sont deja enregistres avec cette banque" : "Error 1012 : Providers's Bank account exists with this bank code");
                break;
            case "1013":
                error_msg = (locale == Locale.FRENCH ? "Erreur 1013 : Ce numero de compte existe deja pour ce fournisseur" : "Error 1013 : This providers's Bank account already exists in the system ");
                break;
            case "2001":
                error_msg = (locale == Locale.FRENCH ? "Erreur 2001 : Violation d'une contrainte d'intégrité. Il existe des objets de la base qui sont liés à cette entité. " : "Error 2001 : Integrity constraints violation. There are some objects in the database which are linked to this one ");
                break;
            case "3001":
                error_msg = (locale == Locale.FRENCH ? "Erreur 3001 : La somme de toutes les liquidations ne doit pas depasser le montant TTC du dossier. " : "Error 3001 : Sum of liquidations on this commitment can't be higher than the TTC amount. ");
                break;
            case "3002":
                error_msg = (locale == Locale.FRENCH ? "Erreur 3001 : Cette liquidation a deja fait l'objet d'un mandatement et ne peut pas etre annulee " : "Error 3001 : Cette liquidation a deja fait l'objet d'un mandatement et ne peut pas etre annulee. ");
                break;
            case "4001":
                error_msg = (locale == Locale.FRENCH ? "Erreur 4001 : Impossible d'avoir plusieurs budgets de report pour le même exercice " : "Error 4001 : You can't hava two or more report's budget for the same financial year ");
                break;
            case "4002":
                error_msg = (locale == Locale.FRENCH ? "Erreur 4002 : Impossible d'avoir plusieurs budgets initiaux pour le même exercice " : "Error 4002 : You can't hava two or more initial budget for the same financial year ");
                break;
            case "5001":
                error_msg = (locale == Locale.FRENCH ? "Erreur 5001 : Ce virement ne peut plus être supprimé. Il a déjà fait l'objet d'une réservation de crédit " : "Error 5001 : This credit transfer can't be drop. It has already been the subject of a credit reservation ");
                break;
            case "5002":
                error_msg = (locale == Locale.FRENCH ? "Erreur 5002 : Le débit n'est pas égal au crédit. Ce virement ne peut etre réservé" : "Error 5002 : Error Debit not egual to credit ");
                break;
            case "5003":
                error_msg = (locale == Locale.FRENCH ? "Erreur 5003 : Interdit. Pas de virement de l'investissement vers le fonctionnement" : "Error 5003 : Restriction. No credit transfert between capital expenditures to current expenditures ");
                break;
            case "5004":
                error_msg = (locale == Locale.FRENCH ? "Erreur 5004 : Indisponibilité de crédits" : "Error 5004 : Credit not availlable on a account ");
                break;
            case "6000":
                error_msg = (locale == Locale.FRENCH ? "Erreur 6000 : Budget deja tranfere en execution" : "Error 6000 : This budget is already running  ");
                break;
            case "6001":
                error_msg = (locale == Locale.FRENCH ? "Erreur 6001 : Budget non valide" : "Error 6001 : Invalid budget ");
                break;
            
            default:
                error_msg = exceptionMessage;
                break;
        }
        return error_msg;
    }
}
