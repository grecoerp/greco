/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tools.algorithme;

/**
 *
 * @author ouethy
 */
public class AlgoContribuable {

    String numCtb;
    String numCtbComplet;
    int [] numCtbSign = {-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1};
    String [] lettre = {"A","B","C", "D", "E", "F", "G", "H","J", "K","L", "M", "N", "P", "Q", "R","S", "T","U", "W","X", "Y","Z"};
    
    int w_imp, w_pai, w_q, w_r, w_x, w_y, w_z;
    String lettre_cle;
    
    public AlgoContribuable(String numCont) {
        numCtbComplet = numCont;
        numCtb = numCtbComplet.substring(0, numCtbComplet.length()-1);
    }

    private boolean control(){
        boolean rep = true;
        if(numCtb.length() < 13){
            rep = false;
        }
        if(numCtb.contains(" ")){
            rep = false;
        }
        return rep;
    }
    
    public String getCle(){     
        carton3();
        w_imp = 0;
        w_pai = 0;
        carton4();
        
        w_x = 2*w_pai;
        w_x = w_x + w_imp;
        w_q = (int)(w_x / 23);
        w_y = w_x % 23;
        
        lettre_cle = lettre[w_y];
        
        return lettre_cle;
    }

    private void carton3(){
        for (int i = 0; i < numCtb.length(); i++) {
            if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("A")) numCtbSign[i] = 1;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("B")) numCtbSign[i] = 2;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("C")) numCtbSign[i] = 3;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("D")) numCtbSign[i] = 4;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("E")) numCtbSign[i] = 5;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("F")) numCtbSign[i] = 6;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("G")) numCtbSign[i] = 7;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("H")) numCtbSign[i] = 8;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("I")) numCtbSign[i] = 9;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("J")) numCtbSign[i] = 1;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("K")) numCtbSign[i] = 2;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("L")) numCtbSign[i] = 3;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("M")) numCtbSign[i] = 4;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("N")) numCtbSign[i] = 5;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("O")) numCtbSign[i] = 6;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("P")) numCtbSign[i] = 7;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("Q")) numCtbSign[i] = 8;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("R")) numCtbSign[i] = 9;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("S")) numCtbSign[i] = 2;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("T")) numCtbSign[i] = 3;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("U")) numCtbSign[i] = 4;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("V")) numCtbSign[i] = 5;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("W")) numCtbSign[i] = 6;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("X")) numCtbSign[i] = 7;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("Y")) numCtbSign[i] = 8;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("Z")) numCtbSign[i] = 9;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("0")) numCtbSign[i] = 0;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("1")) numCtbSign[i] = 1;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("2")) numCtbSign[i] = 2;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("3")) numCtbSign[i] = 3;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("4")) numCtbSign[i] = 4;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("5")) numCtbSign[i] = 5;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("6")) numCtbSign[i] = 6;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("7")) numCtbSign[i] = 7;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("8")) numCtbSign[i] = 8;
            else if(String.valueOf(numCtb.charAt(i)).equalsIgnoreCase("9")) numCtbSign[i] = 9;
        }
        
    }
    
    private void carton4(){
        for (int i = 0; i < numCtb.length(); i++) {
            if(numCtbSign[i] == -1){
                lettre_cle = " ";
            }
            else {
                w_z = i%2;
                if(w_z == 1){
                    w_pai = (w_pai*10)+ numCtbSign[i];
                }else {
                    w_imp= (w_imp*10) + numCtbSign[i];
                }
            }
        }
    }
    
    public String getNumCtb() {
        return numCtb;
    }

    public void setNumCtb(String numCtb) {
        this.numCtb = numCtb;
    }

    public String getNumCtbComplet() {
        return numCtbComplet;
    }
    
    public boolean isCorrect(){
        boolean rep = false;
        if(String.valueOf(getNumCtbComplet().charAt(getNumCtbComplet().length()-1)).equalsIgnoreCase(getCle())){
            rep = true; 
         }
        return rep;
    }
    
    public static void main(String [] arg){   
         AlgoContribuable c = new AlgoContribuable("P056412578852Q");
         System.out.println("Numéro saisie : "+c.getNumCtbComplet());
         System.out.println("Numéro de travail : "+c.getNumCtb());
         System.out.println("CLE trouvée: "+c.getCle());
         if(String.valueOf(c.getNumCtbComplet().charAt(c.getNumCtbComplet().length()-1)).equalsIgnoreCase(c.getCle())){
             System.out.println("RESULTAT : SUCCES");
         }else {
             System.out.println("RESULTAT : ECHEC");
         }
         System.out.println("correct ? : "+c.isCorrect());
    }
    
}
