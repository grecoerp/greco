/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tools.algorithme;

import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class AlgoRIB {
    
    public  static boolean checkRIB(String rib){
        //rib codebanque(5)+codeAgence(5)+numero de compte(11)+cle(2) = 23
        if(rib.length() != 23) return false;
        StringBuilder builder = new StringBuilder(rib.length());
        for (char currentChar: rib.toCharArray()) {
            int currentCharValue = Character.digit(currentChar, Character.MAX_RADIX);
            builder.append(currentCharValue<10?currentCharValue:(currentCharValue+(int)StrictMath.pow(2, (currentCharValue-10)/9))%10);
        }
        return new BigDecimal(builder.toString()).remainder(new BigDecimal(97)).intValue()==0;
    }
    
    public static void main(String [] arg){   
         System.out.println(checkRIB("10002000311139368315002"));
    }
}
