/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tools.ui.renderer;

import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author ouethy
 */
public class EngagementTypeRenderer extends DefaultTableCellRenderer{

  

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        JLabel l = new JLabel();
        try {
            l.setHorizontalAlignment(CENTER);
            l.setIcon(getIcond((int)value));
        } catch (Exception e) {
        }
        return l; 
    }
    
    public ImageIcon getIcond(int value){
        if(value == 1) return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"));
        else if(value == 2) return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"));
        else if(value == 3) return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"));
        else if(value == 4) return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"));
        else if(value == 2) return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"));
        else  return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"));
    }
}