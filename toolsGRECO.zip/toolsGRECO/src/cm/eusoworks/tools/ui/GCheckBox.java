/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.tools.ui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JCheckBox;

/**
 *
 * @author ouethy
 */
public class GCheckBox extends JCheckBox {

    private static final Color COLOR1 = new Color(0, 166, 0);
    private static final Color COLOR2 = new Color(0, 166, 0);
    private Color initialForegrund = new Color(0, 0, 0);

    public GCheckBox() {
        super();

    }

    @Override
    public void paintComponent(Graphics g) {
        setFocusPainted(false);
        setOpaque(false);

        Graphics2D g2d = (Graphics2D) g.create();
        int h = getHeight();
        int w = getWidth();

        float tran = 0.9f;//0.1f + pct * 0.9f;

        GradientPaint GP = new GradientPaint(0, 0, COLOR1, 0, h, COLOR2, true);
        g2d.setPaint(GP);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint p1;
        GradientPaint p2;

        if (getModel().isSelected()) {
            initialForegrund = getForeground();
            setForeground(Color.white);
            p1 = new GradientPaint(0, 0, COLOR2, 0, h - 1, COLOR1);
            p2 = new GradientPaint(0, 1, new Color(0, 0, 0, 50), 0, h - 3, new Color(255, 255, 255, 100));
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 20, 20);
            Shape clip = g2d.getClip();
            g2d.clip(r2d);
            g2d.fillRect(0, 0, w, h);
            g2d.setClip(clip);
            g2d.setPaint(p1);
            g2d.drawRoundRect(0, 0, w - 1, h - 1, 20, 20);

            g2d.dispose();
        } else if (!getModel().isEnabled()) {
            setForeground(new Color(128, 128, 128));
        } else {
//            setFont(new Font("arial",12,Font.BOLD));
            setForeground(Color.black);
        }

        super.paintComponent(g);
    }
}
