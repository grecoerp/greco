/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.tools.ui;

import cm.eusoworks.entities.view.VueOpDisponiblePipe;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.RoundRectangle2D;
import java.math.BigDecimal;
import javax.swing.JPanel;

/**
 *
 * @author macbookair
 */
public class GDisponiblePipe extends JPanel {

    private static final long serialVersionUID = -6290622947931566069L;
    private static boolean REPAINT_SHADOW = true;
//
//    private static Color COLOR1 = new Color(125, 161, 237);
//    private static Color COLOR2 = new Color(91, 118, 173);

    private Color COLOR1 = new Color(192, 192, 192);
    private Color COLOR2 = new Color(201, 201, 201);

    private static Color COLOR3 = new Color(56, 161, 127);
    private static Color COLOR4 = new Color(33, 118, 87);

    private static Color COLOR5 = Color.pink;
    private static Color COLOR6 = Color.pink;

    private float pct;
    private boolean forward;

    private BigDecimal d_ae = BigDecimal.ONE;
    private BigDecimal d_engage = BigDecimal.ZERO;
    ;
    private BigDecimal d_pipe = BigDecimal.ZERO;
    ;
    private BigDecimal d_reste = BigDecimal.ZERO;
    ;

    private int maxWidth = 550, engageWidth = 0, pipeWidth = 0, resteWidth = 0;

    private int heightDispo = 30;

    private int arcW = 15, arcH = 15;

    public GDisponiblePipe() {
        super();
//        setContentAreaFilled(false);
//        setBorderPainted(false);
//        setFocusPainted(false);
        setForeground(Color.WHITE);
    }

    public void setVueDisponible(VueOpDisponiblePipe pipe) {
        this.setD_ae(pipe.getAe());
        this.setD_engage(pipe.getEngage());
        this.setD_pipe(pipe.getPipe());
        this.setD_reste(pipe.getReste());
    }

    public void setColorOff() {
        COLOR1 = Color.red;
        COLOR2 = new Color(129, 23, 12);
    }

    public void setColorOn() {
        COLOR1 = new Color(192, 192, 192);
        COLOR2 = new Color(201, 201, 201);
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        setOpaque(false);
        float tran = 0.7f;//0.1f + pct * 0.9f;

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        //draw dotation
        GradientPaint GP = new GradientPaint(0, 0, new Color(249, 249, 249), 0, heightDispo, new Color(252, 252, 252), true);
        g2d.setPaint(GP);
        g2d.fillRoundRect(0, 0, maxWidth, heightDispo, arcW, arcH);
        g2d.drawRoundRect(0, 0, maxWidth, heightDispo, arcW, arcH);

        // draw engages
        GP = new GradientPaint(0, 0, COLOR3, 0, heightDispo, COLOR4, true);
        g2d.setPaint(GP);
        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
        RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(0, 0, engageWidth - 1 + arcW, heightDispo, arcW, arcH);
        Shape clip = g2d.getClip();
        g2d.clip(r2d);
        g2d.fillRect(0, 0, engageWidth, heightDispo);
        g2d.setClip(clip);
        //g2d.drawRoundRect(0, 0, engageWidth - 1 + arcW, heightDispo, arcW, arcH);

        // draw pipes
        GP = new GradientPaint(0, 0, COLOR5, 0, heightDispo, COLOR6, true);
        g2d.setPaint(GP);
        g2d.fillRect(engageWidth, 0, pipeWidth, heightDispo);
        g2d.drawRect(engageWidth, 0, pipeWidth, heightDispo);

        // draw reste
        GP = new GradientPaint(0, 0, COLOR1, 0, heightDispo, COLOR2, true);
        g2d.setPaint(GP);
        RoundRectangle2D.Float r2r = new RoundRectangle2D.Float(-arcW + engageWidth + pipeWidth, 0, resteWidth + arcW, heightDispo, arcW, arcH);
        clip = g2d.getClip();
        g2d.clip(r2r);
        g2d.fillRect(engageWidth + pipeWidth, 0, resteWidth, heightDispo);
        g2d.setClip(clip);
        //  g2d.drawRoundRect(-arcW+engageWidth+pipeWidth, 0, resteWidth+arcW, heightDispo, arcW, arcH);

        // draw text
        FontMetrics fm = g2d.getFontMetrics(new Font("Arial", Font.PLAIN, 14));
        g2d.setColor(Color.white);

        String strEngage = "Engagé(s)";
        String strPipe = "en attente";
        String strReste = "Disponible";

        int sw = fm.stringWidth(strEngage);
        if (sw < engageWidth) {
            int x = (engageWidth - sw) / 2;
            int y = ((heightDispo - fm.getHeight()) / 2) + fm.getAscent();
            g2d.drawString(strEngage, x, y);
        }

        sw = fm.stringWidth(strPipe);
        if (sw < pipeWidth) {
            int x = engageWidth + (int) ((pipeWidth - sw) / 2);
            int y = ((heightDispo - fm.getHeight()) / 2) + fm.getAscent();
            g2d.drawString(strPipe, x, y);
        }

        sw = fm.stringWidth(strReste);
        if (sw < resteWidth) {
            int x = engageWidth + pipeWidth + (int) ((resteWidth - sw) / 2);
            int y = ((heightDispo - fm.getHeight()) / 2) + fm.getAscent();
            g2d.drawString(strReste, x, y);
        }

        g2d.dispose();
        super.paintComponent(g);
    }

    public BigDecimal getD_ae() {
        return d_ae;
    }

    public void setD_ae(BigDecimal d_ae) {
        this.d_ae = d_ae;
        calculWidth();
    }

    public BigDecimal getD_engage() {
        return d_engage;
    }

    public void setD_engage(BigDecimal d_engage) {
        this.d_engage = d_engage;
        calculWidth();
    }

    public BigDecimal getD_pipe() {
        return d_pipe;
    }

    public void setD_pipe(BigDecimal d_pipe) {
        this.d_pipe = d_pipe;
        calculWidth();
    }

    public BigDecimal getD_reste() {
        return d_reste;
    }

    public void setD_reste(BigDecimal d_reste) {
        this.d_reste = d_reste;
        calculWidth();
    }

    public void calculWidth() {
        double max = d_ae.doubleValue();

        double egInt = d_engage.doubleValue();
        double egRatio = egInt / max;
        engageWidth = (int) (maxWidth * egRatio);

        double peInt = d_pipe.doubleValue();
        double peRatio = peInt / max;
        pipeWidth = (int) (maxWidth * peRatio);

        double reInt = d_reste.doubleValue();
        double reRatio = reInt / max;
        resteWidth = (int) (maxWidth * reRatio);

        repaint();
    }

}
