/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.tools.ui;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Container;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Ellipse2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;
import org.jdesktop.animation.timing.TimingController;
import org.jdesktop.animation.timing.TimingTarget;

/**
 *
 * @author macbookair
 */
public class GButton extends JButton implements TimingTarget {

    private static boolean REPAINT_SHADOW = true;

    private static Color COLOR1 = new Color(125, 161, 237);
    private static Color COLOR2 = new Color(91, 118, 173);
    private static final long serialVersionUID = -6290622947931566069L;

    private int style;
    private int couleur = 0;
    private float pct;
    private boolean forward;

    private int arcW = 15, arcH = 15;
    private TimingController cont = new TimingController(200, this);

    private final MouseAdapter MLISTENER = new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent me) {
            cont.stop();
            forward = true;
            cont.start();
        }

        @Override
        public void mouseExited(MouseEvent me) {
            cont.stop();
            forward = false;
            cont.start();
        }
    };

    public void begin() {
    }

    public void end() {
        if (forward) {
            setForeground(Color.WHITE);
//            setForeground(COLOR1);
//            pct = 0.0f;
        } else {
            setForeground(Color.WHITE);
//            pct = 1.0f;

        }
        Container p = getParent();
        if (p instanceof DropShadowPanel && REPAINT_SHADOW) {
            ((DropShadowPanel) p).propertyChange(null);
        } else {
            repaint();
        }
    }

    public void timingEvent(long cycleElapsedTime, long totalElapsedTime, float fraction) {
        if (forward) {
            pct = 1.0f - fraction;
            int r = COLOR2.getRed() + (int) ((Color.WHITE.getRed() - COLOR2.getRed()) * pct);
            int g = COLOR2.getGreen() + (int) ((Color.WHITE.getGreen() - COLOR2.getGreen()) * pct);
            int b = COLOR2.getBlue() + (int) ((Color.WHITE.getBlue() - COLOR2.getBlue()) * pct);
            setForeground(new Color(r, g, b));
        } else {
            pct = fraction;
            int r = COLOR2.getRed() + (int) ((Color.WHITE.getRed() - COLOR2.getRed()) * pct);
            int g = COLOR2.getGreen() + (int) ((Color.WHITE.getGreen() - COLOR2.getGreen()) * pct);
            int b = COLOR2.getBlue() + (int) ((Color.WHITE.getBlue() - COLOR2.getBlue()) * pct);
            setForeground(new Color(r, g, b));
        }
        Container p = getParent();
        if (p instanceof DropShadowPanel && REPAINT_SHADOW) {
            ((DropShadowPanel) p).propertyChange(null);
        } else {
            //repaint();
        }
    }

    public GButton(int style, int couleur) {
        super();
        this.style = style;
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
//        setOpaque(false);
//        setForeground(COLOR2);
        setForeground(Color.WHITE);
        addMouseListener(MLISTENER);
        //setFont(getFont().deriveFont(Font.BOLD));
    }

    public GButton() {
        this(0, 0);
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        setOpaque(false);
        int h = getHeight();
        int w = getWidth();
        float tran = 0.9f;//0.1f + pct * 0.9f;

        COLOR1 = getColor1();
        COLOR2 = getColor2();

        GradientPaint GP = new GradientPaint(0, 0, COLOR1, 0, h, COLOR2, true);
        g2d.setPaint(GP);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint p1;
        GradientPaint p2;

        if (getModel().isPressed()) {
            p1 = new GradientPaint(0, 0, new Color(0, 0, 0), 0, h - 1, new Color(100, 100, 100));
            p2 = new GradientPaint(0, 1, new Color(0, 0, 0, 50), 0, h - 3, new Color(255, 255, 255, 100));
            if(style == 5){
                p1 = new GradientPaint(0, 0, new Color(225, 225, 225, 100), 0, h - 1, new Color(230, 230, 230, 100));
                
            }
        } else {
            p1 = new GradientPaint(0, 0, COLOR1, 0, h - 1, COLOR2);
            p2 = new GradientPaint(0, 1, COLOR2, 0, h - 1, COLOR1);
            p2 = new GradientPaint(0, 1, new Color(255, 255, 255, 100), 0, h - 3, new Color(0, 0, 0, 50));
            if(style == 5){
                p1 = new GradientPaint(0, 0, Color.white, 0, h - 20, new Color(253, 253, 253, 100));
            }
        }

        if (style == 0) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 20, 20);
            Shape clip = g2d.getClip();
            g2d.clip(r2d);
            g2d.fillRect(0, 0, w, h);
            g2d.setClip(clip);
            g2d.setPaint(p1);
            g2d.drawRoundRect(0, 0, w - 1, h - 1, 20, 20);
            g2d.dispose();
        } else if (style == 1) {
            RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 20, 20);
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            Shape clip = g2d.getClip();
            g2d.clip(r2d);
            g2d.fillRect(0, 0, w, h);
            g2d.setClip(clip);
            g2d.setPaint(p1);
            g2d.drawRoundRect(0, 0, w - 1, h - 1, 20, 20);
            g2d.dispose();
        } else if (style == 2) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            g2d.fillRect(0, 0, w, h);
            g2d.setPaint(p1);
            g2d.drawRect(-5, 0, w - 1 + 10, h - 1);
            g2d.dispose();
        } else if (style == 3) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(-20, 0, w - 1 + 20, h - 1, 20, 20);
            Shape clip = g2d.getClip();
            g2d.clip(r2d);
            g2d.fillRect(0, 0, w, h);
            g2d.setClip(clip);
            g2d.setPaint(p1);
            g2d.drawRoundRect(-20, 0, w - 1 + 20, h - 1, 20, 20);
            g2d.dispose();
        }else if (style == 5) {
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 10, 10);
            Shape clip = g2d.getClip();
            g2d.clip(r2d);
            g2d.setPaint(p1);
            g2d.fillRoundRect(0, 0, w-1, h-1, 10, 10);
            g2d.setClip(clip);
            g2d.setColor(new Color(218, 218, 218));
            g2d.drawRoundRect(0, 0, w - 1, h - 1, 10, 10);
            g2d.dispose();
            setForeground(new Color(77,77,77));
        }

        super.paintComponent(g);
    }

    public int getStyle() {
        return style;
    }

    public void setStyle(int style) {
        this.style = style;
        if(style == 5){
            setForeground(new Color(77,77,77));
        }
    }

    public int getCouleur() {
        return couleur;
    }

    public void setCouleur(int couleur) {
        this.couleur = couleur;
    }

    public Color getColor1() {
        Color c = COLOR1;
        switch (couleur) {
            case 0:
                c = new Color(125, 161, 237);
                break;
            case 1:
                c = new Color(206, 1, 1);
                break;
            case 2:
                c = new Color(179, 102, 179);
                break;
            case 3:
                c = new Color(255, 255, 255);
                break;
            case 4:
                c = new Color(35, 73, 125);
                break;
            case 6:
                c = new Color(230, 241, 255);
                break;
        }
        return c;
    }

    public Color getColor2() {
        Color c = COLOR2;
        switch (couleur) {
            case 0:
                c = new Color(91, 118, 173);
                break;
            case 1:
                c = new Color(250, 0, 0);
                break;
            case 2:
                c = new Color(96, 0, 96);
                break;
            case 3:
                c = new Color(120, 120, 120);
                break;
            case 4:
                c = new Color(35, 73, 125);
                break;
        }
        return c;
    }
}
