/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.tools.ui;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Paint;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.Area;
import java.awt.geom.CubicCurve2D;
import java.awt.geom.GeneralPath;
import javax.swing.JPanel;

public class CurvesPanel extends JPanel {

    private RenderingHints hints;
    private int counter = 0;
    private int redColor1 = 168;
    private int redColor2 = 168;
    private int redColor3 = 168;
    private int greenColor1 = 245;
    private int greenColor2 = 245;
    private int greenColor3 = 245;
    private int yellowColor1 = 221;
    private int yellowColor2 = 221;
    private int yellowColor3 = 221;

    public CurvesPanel() {
        hints = new RenderingHints(RenderingHints.KEY_ALPHA_INTERPOLATION,
                RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);
        hints.put(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_COLOR_RENDERING,
                RenderingHints.VALUE_COLOR_RENDER_QUALITY);
        hints.put(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        hints.put(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        setOpaque(false);
    }

    public void paintComponent(Graphics g) {
        counter++;

        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHints(hints);
        super.paintComponent(g2);

        float width = getWidth();
        float height = getHeight();

        g2.translate(0, -30);
        drawCurve(g2,
                20.0f, -10.0f, 20.0f, -10.0f,
                width / 2.0f - 40.0f, 10.0f,
                0.0f, -5.0f,
                width / 2.0f + 40, 1.0f,
                0.0f, 5.0f,
                50.0f, 5.0f, false, greenColor1, greenColor2, greenColor3);
        g2.translate(0, 30);

        g2.translate(0, height - 60);
        drawCurve(g2,
                30.0f, -15.0f, 50.0f, 15.0f,
                width / 2.0f - 40.0f, 1.0f,
                15.0f, -25.0f,
                width / 2.0f, 1.0f / 2.0f,
                0.0f, 25.0f,
                15.0f, 6.0f, false, redColor1, redColor2, redColor3);
        g2.translate(0, -height + 60);

        drawCurve(g2,
                height - 35.0f, -5.0f, height - 50.0f, 10.0f,
                width / 2.0f - 40.0f, 1.0f,
                height - 35.0f, -25.0f,
                width / 2.0f, 1.0f / 2.0f,
                height - 20.0f, 25.0f,
                25.0f, 4.0f, true, yellowColor1, yellowColor2, yellowColor3);
    }

    private void drawCurve(Graphics2D g2,
            float y1, float y1_offset,
            float y2, float y2_offset,
            float cx1, float cx1_offset,
            float cy1, float cy1_offset,
            float cx2, float cx2_offset,
            float cy2, float cy2_offset,
            float thickness,
            float speed,
            boolean invert, int rColor, int gColor, int bColor) {

        float width = getWidth();
        float height = getHeight();

        double offset = Math.sin(counter / (speed * Math.PI));
        float start_x = 0.0f;
        float start_y = y1 + (float) (offset * y1_offset);
        float end_x = width;
        float end_y = y2 + (float) (offset * y2_offset);
        float ctrl1_x = (float) offset * cx1_offset + cx1;
        float ctrl1_y = cy1 + (float) (offset * cy1_offset);
        float ctrl2_x = (float) (offset * cx2_offset) + cx2;
        float ctrl2_y = (float) (offset * cy2_offset) + cy2;

        CubicCurve2D curve = new CubicCurve2D.Double(start_x, start_y, ctrl1_x, ctrl1_y, ctrl2_x, ctrl2_y, end_x, end_y);

        GeneralPath path = new GeneralPath(curve);
        path.lineTo(width, height);
        path.lineTo(0, height);
        path.closePath();

        Area thickCurve = new Area((Shape) path.clone());
        AffineTransform translation = AffineTransform.getTranslateInstance(0, thickness);
        path.transform(translation);
        thickCurve.subtract(new Area(path));

        Color start = new Color(rColor, gColor, bColor, 210);
        Color end = new Color(rColor, gColor, bColor, 255);

        Rectangle bounds = thickCurve.getBounds();
        GradientPaint painter = new GradientPaint(0, curve.getBounds().y,
                invert ? end : start,
                0, bounds.y + bounds.height,
                invert ? start : end);
        Paint oldPainter = g2.getPaint();
        g2.setPaint(painter);

        g2.fill(thickCurve);

        g2.setPaint(oldPainter);
    }

    public void setDrapeauCameroun() {
        redColor1 = 193;
        redColor2 = 56;
        redColor3 = 46;
        greenColor1 = 62;
        greenColor2 = 130;
        greenColor3 = 46;
        yellowColor1 = 255;
        yellowColor2 = 251;
        yellowColor3 = 32;
    }
    
    public void setDrapeauFrance() {
        redColor1 = 252;
        redColor2 = 252;
        redColor3 = 252;
        greenColor1 = 8;
        greenColor2 = 61;
        greenColor3 = 127;
        yellowColor1 = 235;
        yellowColor2 = 47;
        yellowColor3 = 63;
    }
    
    public void setDrapeauCotedivoire() {
        redColor1 = 252;
        redColor2 = 252;
        redColor3 = 252;
        greenColor1 = 245;
        greenColor2 = 128;
        greenColor3 = 34;
        yellowColor1 = 22;
        yellowColor2 = 158;
        yellowColor3 = 99;
    }
    
    public void setDrapeauTchad() {
        redColor1 = 253;
        redColor2 = 208;
        redColor3 = 54;
        greenColor1 = 5;
        greenColor2 = 46;
        greenColor3 = 127;
        yellowColor1 = 204;
        yellowColor2 = 23;
        yellowColor3 = 45;
    }
    
    public void setDrapeauGabon() {
        redColor1 = 255;
        redColor2 = 212;
        redColor3 = 49;
        greenColor1 = 22;
        greenColor2 = 158;
        greenColor3 = 98;
        yellowColor1 = 61;
        yellowColor2 = 119;
        yellowColor3 = 194;
    }
}
