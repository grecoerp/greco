/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tools.ui;

/**
 *
 * @author ouethy
 */
public class GrecoOptionPane {
    
    public static void showErrorDialog(String message){
        MessageDialog md = new MessageDialog(null, true, message, MessageDialog.ERROR_MODE);
        md.setVisible(true);
    }
    
    public static void showWarningDialog(String message){
        MessageDialog md = new MessageDialog(null, true, message, MessageDialog.WARNING_MODE);
        md.setVisible(true);
    }
    
    public static void showInformationDialog(String message){
        MessageDialog md = new MessageDialog(null, true, message, MessageDialog.INFORMATION_MODE);
        md.setVisible(true);
    }
    public static void showSuccessDialog(String message){
        MessageDialog md = new MessageDialog(null, true, message, MessageDialog.SUCCES_MODE);
        md.setVisible(true);
    }
    
    public static int showConfirmDialog(String message){
        MessageDialog md = new MessageDialog(null, true, message, MessageDialog.QUESTION_MODE);
        md.setVisible(true);
        int res = md.getRes();
        md.dispose();
        return res;
    }
    
    public static String showInputDialog(String message, String libelleAction){
        MessageInputDialog md = new MessageInputDialog(null, true, message,libelleAction, MessageInputDialog.INPUT_MODE);
        md.setVisible(true);
        String res = md.getRes();
        md.dispose();
        return res;
    }
}
