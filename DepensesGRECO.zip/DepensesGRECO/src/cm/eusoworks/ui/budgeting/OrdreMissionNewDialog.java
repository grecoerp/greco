/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.renderer.ComboOperationBudgetaireRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author macbookair
 */
public class OrdreMissionNewDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    String millesime;
    String organisationID;
    OrdreMission currentOM = null;
    Organisation org;

    public OrdreMissionNewDialog(JFrame parent, boolean modal, String millesime, Organisation org, OrdreMission om) {
        super(parent, modal);
        initComponents();
        this.millesime = millesime;
        this.org = org;
        this.organisationID = org.getOrganisationID();
        cboImputation.setRenderer(new ComboOperationBudgetaireRenderer());
        loadStructureOrganisation();
        this.currentOM = om;
        initBCAInfos();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Etablissement d'un ordre de mission ");
        pack();
        setSize(750, 720);
        setLocationRelativeTo(null);
    }
    
    public OrdreMissionNewDialog(JFrame parent, boolean modal, String millesime, Organisation org, OrdreMission om, boolean isConsultation){
        this(parent, modal, millesime, org, om);
        if(isConsultation) btnEnregistrer.setVisible(false);
    }

    private void initBCAInfos() {

        if (currentOM != null) {
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentOM.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentOM.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentOM.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            txtMotif.setText(currentOM.getMotifReference());
            ordonnateurComp.setMatricule(currentOM.getOrdonnateur());
            txtDestination.setText(currentOM.getDestination());
            txtPassantPar.setText(currentOM.getPassantPar());
            txtTransport.setText(currentOM.getTransport());
            txtAccompagnant.setText(currentOM.getAccompagnant());
            dtpDateDepart.setDate(currentOM.getDateDepart());
            dtpDateRetour.setDate(currentOM.getDateRetour());
            try {
                cboSituationMatrimoniale.setSelectedItem(currentOM.getSituation());
            } catch (Exception e) {
            }
            try {
                cboTypeMission.setSelectedIndex(currentOM.getTypeMission());
            } catch (Exception e) {
            }
            
            agentComp.setMatricule(currentOM.getMatricule());
            txtMontantGlobal.setValue(currentOM.getMontantGlobal());
            txtMontantOP.setValue(currentOM.getMontantOP());
            txtNumeroOP.setText(currentOM.getNumeroOP());
            txtNbreJoursMission.setValue(currentOM.getNbJours());
            
            if(currentOM.getEtat() >= EtatDossier.reserve){
                btnEnregistrer.setVisible(false);
            }
            
            
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(this.organisationID);
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);
        }

    }

    private void remplirOM() {
        Structure s = (Structure) cboStructure.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();

        currentOM.setMotifReference(txtMotif.getText().trim());

        currentOM.setTypeMission(cboTypeMission.getSelectedIndex());
        currentOM.setSituation((String) cboSituationMatrimoniale.getSelectedItem());
        currentOM.setDestination(txtDestination.getText().trim());
        currentOM.setPassantPar(txtPassantPar.getText());
        currentOM.setTransport(txtTransport.getText().trim());
        currentOM.setAccompagnant(txtAccompagnant.getText().trim());

        currentOM.setDateDepart(dtpDateDepart.getDate());
        currentOM.setDateRetour(dtpDateRetour.getDate());

        currentOM.setTacheID(o.getTacheID());
        currentOM.setMillesime(millesime);
        currentOM.setOrganisationID(organisationID);
        currentOM.setMatricule(agentComp.getMatricule());
        currentOM.setStructureID(s.getStructureID());
        currentOM.setActiviteID(a.getActiviteID());
        
        Number montantOP = (Number) txtMontantOP.getValue();
        Number montantG = (Number) txtMontantGlobal.getValue();
        Number nbJours = (Number) txtNbreJoursMission.getValue();
       
        currentOM.setOrdonnateur(ordonnateurComp.getMatricule());
        currentOM.setNbJours(nbJours.intValue());
        currentOM.setMontantGlobal(BigDecimal.valueOf(montantG.longValue()));
        currentOM.setMontantOP(BigDecimal.valueOf(montantOP.longValue()));
        currentOM.setNumeroOP(txtNumeroOP.getText());
        currentOM.setBeneficiaire(agentComp.getMatricule() + " - "+agentComp.getNomComplet());
        
        currentOM.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentOM.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

    }

    private boolean controlData() {
        boolean res = true;
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la structure");
            return false;
        }

        if (ordonnateurComp.getMatricule() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le matricule de l'ordonnateur  ");
            return false;
        }
        Activite a = (Activite) cboTache.getSelectedItem();
        if (a == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la tâche ");
            return false;
        }
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (o == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner l'imputation ");
            return false;
        }
        if (txtMotif.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir le motif de la mission ");
            return false;
        }

        if (agentComp.getMatricule() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le matricule de l'agent ");
            return false;
        }
        
        if (txtDestination.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir la destination ou l'itinéraire ");
            return false;
        }
        if (dtpDateDepart.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir la date de départ en mission ");
            return false;
        }
        if (dtpDateRetour.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir la date de retour de la mission ");
            return false;
        }
        if (dtpDateDepart.getDate().after(dtpDateRetour.getDate())) {
            JOptionPane.showMessageDialog(this, "La date de départ en mission doit être antérieur à la date de retour... ");
            return false;
        }
        
        Number montantG = (Number) txtMontantGlobal.getValue();
        if (montantG == null || montantG.longValue() <= 0) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir un montant global pour la mission en fonction du nombre de jours et du bareme de mission pour l'agent ");
            return false;
        }
        
        Number montantOP = (Number) txtMontantOP.getValue();
        if (montantOP == null || montantOP.longValue() <= 0) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir un montant pour l'ordre de paiement");
            return false;
        }
        
        if(montantOP.longValue() > montantG.longValue()){
            JOptionPane.showMessageDialog(this, "Le montant de l'OP ne peut pas être supérieur au montant global de la mission ");
            return false;
        }
        
        if (txtNumeroOP.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir le numéro de l'OP ");
            return false;
        }
        
        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ongletBCA = new javax.swing.JTabbedPane();
        pAccueil = new javax.swing.JPanel();
        pObjetCommande = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtMotif = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        btnEnregistrer = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        ordonnateurComp = new cm.eusoworks.component.AgentComponent();
        jLabel1 = new javax.swing.JLabel();
        cboSituationMatrimoniale = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        txtDestination = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtPassantPar = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtTransport = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtAccompagnant = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dtpDateDepart = new org.jdesktop.swingx.JXDatePicker();
        dtpDateRetour = new org.jdesktop.swingx.JXDatePicker();
        jLabel13 = new javax.swing.JLabel();
        cboTypeMission = new javax.swing.JComboBox();
        jLabel14 = new javax.swing.JLabel();
        agentComp = new cm.eusoworks.component.AgentComponent();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtNbreJoursMission = new javax.swing.JFormattedTextField();
        txtNumeroOP = new javax.swing.JFormattedTextField();
        txtMontantGlobal = new javax.swing.JFormattedTextField();
        txtMontantOP = new javax.swing.JFormattedTextField();
        lnkNewMission = new org.jdesktop.swingx.JXHyperlink();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        ongletBCA.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);

        pAccueil.setBackground(new java.awt.Color(255, 255, 255));
        pAccueil.setLayout(null);

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Imputation ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 204))); // NOI18N
        pObjetCommande.setLayout(null);

        jLabel2.setText("Tâche : ");
        pObjetCommande.add(jLabel2);
        jLabel2.setBounds(7, 50, 90, 30);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(7, 80, 90, 30);

        jLabel4.setText("Motif  : ");
        pObjetCommande.add(jLabel4);
        jLabel4.setBounds(10, 120, 80, 51);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 50, 550, 27);

        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 80, 550, 30);

        txtMotif.setColumns(20);
        txtMotif.setRows(2);
        jScrollPane2.setViewportView(txtMotif);

        pObjetCommande.add(jScrollPane2);
        jScrollPane2.setBounds(110, 120, 550, 51);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(10, 20, 90, 30);

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboStructure);
        cboStructure.setBounds(110, 20, 550, 27);

        pAccueil.add(pObjetCommande);
        pObjetCommande.setBounds(10, 50, 688, 180);

        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        pAccueil.add(btnEnregistrer);
        btnEnregistrer.setBounds(550, 600, 166, 43);

        jLabel6.setText("Ordonnateur :");
        pAccueil.add(jLabel6);
        jLabel6.setBounds(20, 10, 100, 22);
        pAccueil.add(ordonnateurComp);
        ordonnateurComp.setBounds(133, 10, 270, 26);

        jLabel1.setText("Situation : ");
        pAccueil.add(jLabel1);
        jLabel1.setBounds(20, 280, 90, 30);

        cboSituationMatrimoniale.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Célibataire sans enfants", "Célibataire avec enfants", "Marié sans enfants", "Marié avec enfants", "Divorcé" }));
        pAccueil.add(cboSituationMatrimoniale);
        cboSituationMatrimoniale.setBounds(130, 280, 220, 30);

        jLabel7.setText("Destination : ");
        pAccueil.add(jLabel7);
        jLabel7.setBounds(20, 320, 100, 30);

        txtDestination.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtDestination);
        txtDestination.setBounds(130, 320, 220, 30);

        jLabel8.setText("Passant par : ");
        pAccueil.add(jLabel8);
        jLabel8.setBounds(380, 320, 90, 30);

        txtPassantPar.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtPassantPar);
        txtPassantPar.setBounds(490, 320, 220, 30);

        jLabel9.setText("Transport : ");
        pAccueil.add(jLabel9);
        jLabel9.setBounds(20, 350, 100, 40);

        txtTransport.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtTransport);
        txtTransport.setBounds(130, 350, 220, 40);

        jLabel10.setText("Accompagnant : ");
        pAccueil.add(jLabel10);
        jLabel10.setBounds(380, 350, 110, 40);

        txtAccompagnant.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtAccompagnant);
        txtAccompagnant.setBounds(490, 350, 220, 40);

        jLabel11.setText("Date de départ : ");
        pAccueil.add(jLabel11);
        jLabel11.setBounds(20, 390, 110, 30);

        jLabel12.setText("Date de retour : ");
        pAccueil.add(jLabel12);
        jLabel12.setBounds(380, 390, 110, 30);
        pAccueil.add(dtpDateDepart);
        dtpDateDepart.setBounds(130, 390, 160, 30);
        pAccueil.add(dtpDateRetour);
        dtpDateRetour.setBounds(490, 390, 160, 30);

        jLabel13.setText("Type : ");
        pAccueil.add(jLabel13);
        jLabel13.setBounds(430, 10, 50, 20);

        cboTypeMission.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "à l'Intérieur du Cameroun", "à l'Extérieur du pays" }));
        pAccueil.add(cboTypeMission);
        cboTypeMission.setBounds(490, 10, 200, 27);

        jLabel14.setText("Matricule : ");
        pAccueil.add(jLabel14);
        jLabel14.setBounds(20, 250, 110, 22);
        pAccueil.add(agentComp);
        agentComp.setBounds(130, 250, 560, 26);

        jLabel15.setFont(new java.awt.Font("Lucida Grande", 1, 13)); // NOI18N
        jLabel15.setText("Nbre de jours :  ");
        pAccueil.add(jLabel15);
        jLabel15.setBounds(380, 430, 110, 40);

        jLabel16.setText("Numero OP : ");
        pAccueil.add(jLabel16);
        jLabel16.setBounds(20, 550, 100, 40);

        jLabel17.setText("Montant Global : ");
        pAccueil.add(jLabel17);
        jLabel17.setBounds(20, 470, 120, 40);

        jLabel18.setText("Montant Avance : ");
        pAccueil.add(jLabel18);
        jLabel18.setBounds(20, 510, 120, 40);

        txtNbreJoursMission.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtNbreJoursMission.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtNbreJoursMission);
        txtNbreJoursMission.setBounds(494, 430, 130, 40);

        try {
            txtNumeroOP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####A")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtNumeroOP.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtNumeroOP);
        txtNumeroOP.setBounds(130, 550, 130, 40);

        txtMontantGlobal.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtMontantGlobal.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtMontantGlobal);
        txtMontantGlobal.setBounds(130, 470, 220, 40);

        txtMontantOP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtMontantOP.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        pAccueil.add(txtMontantOP);
        txtMontantOP.setBounds(130, 510, 220, 40);

        lnkNewMission.setText("Nouvelle mission à partir de celle ci ");
        lnkNewMission.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        lnkNewMission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnkNewMissionActionPerformed(evt);
            }
        });
        pAccueil.add(lnkNewMission);
        lnkNewMission.setBounds(200, 610, 340, 22);

        ongletBCA.addTab("Détails de l'ordre de mission ", pAccueil);

        getContentPane().add(ongletBCA, "card3");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentOM == null) {
                currentOM = new OrdreMission();
                remplirOM();
                try {
                    String newBcaID = GrecoServiceFactory.getOrdreMissionService().ajouter(currentOM);
                    currentOM.setOmID(newBcaID);
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("Ordre de mission enregistré avec succès pour  "+agentComp.getNomComplet());
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            } else {
                remplirOM();
                try {
                    GrecoServiceFactory.getOrdreMissionService().modifier(currentOM);
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("Ordre de mission modifié avec succès pour "+agentComp.getNomComplet());
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(millesime, organisationID, s.getStructureID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void lnkNewMissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnkNewMissionActionPerformed
        // TODO add your handling code here:
        initMission();
    }//GEN-LAST:event_lnkNewMissionActionPerformed

    private void initMission(){
        agentComp.setMatricule(null);
        txtMontantGlobal.setValue(null);
        txtMontantOP.setValue(null);
        txtNumeroOP.setValue(null);
        try {
            cboSituationMatrimoniale.setSelectedIndex(-1);
        } catch (Exception e) {
        }
       
        currentOM = null;
        btnEnregistrer.setVisible(true);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboSituationMatrimoniale;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JComboBox cboTypeMission;
    private org.jdesktop.swingx.JXDatePicker dtpDateDepart;
    private org.jdesktop.swingx.JXDatePicker dtpDateRetour;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private org.jdesktop.swingx.JXHyperlink lnkNewMission;
    private javax.swing.JTabbedPane ongletBCA;
    private cm.eusoworks.component.AgentComponent ordonnateurComp;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JTextField txtAccompagnant;
    private javax.swing.JTextField txtDestination;
    private javax.swing.JFormattedTextField txtMontantGlobal;
    private javax.swing.JFormattedTextField txtMontantOP;
    private javax.swing.JTextArea txtMotif;
    private javax.swing.JFormattedTextField txtNbreJoursMission;
    private javax.swing.JFormattedTextField txtNumeroOP;
    private javax.swing.JTextField txtPassantPar;
    private javax.swing.JTextField txtTransport;
    // End of variables declaration//GEN-END:variables

}
