/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.ui.budgeting;

import cm.eusoworks.entities.model.Activite;
import java.math.BigDecimal;
import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;
import org.jdesktop.swingx.treetable.DefaultTreeTableModel;
import org.jdesktop.swingx.treetable.TreeTableNode;

/**
 *
 * @author ouethy
 */
public class TreeTableModel extends DefaultTreeTableModel {

    public static final int NUMERO = 0;
    public static final int TYPE = 1;
    public static final int LIBELLE = 2;
    public static final int IMPUTATION = 3;
    public static final int PAAE = 4;
    public static final int PACP = 5;
    

    public TreeTableModel(DefaultMutableTreeTableNode node) {
        super(node);
    }

    @Override
    public int getColumnCount() {
        return 6;
    }

    @Override
    public Class<?> getColumnClass(int column) {
        Class res = String.class;
        switch (column) {
            case NUMERO:
                res = String.class;
                break;
            case TYPE:
                res = Integer.class;
                break;
            case LIBELLE:
                res = String.class;
                break;
            case IMPUTATION:
                res = String.class;
                break;
            case PACP:
                res = String.class;
                break;
            case PAAE:
                res = BigDecimal.class;
                break;
        }
        return res;
    }

    /**
     * Returns which object is displayed in this column.
     */
    @Override
    public Object getValueAt(Object node, int column) {
        Object res = null;
        if (node instanceof DefaultMutableTreeTableNode) {
            DefaultMutableTreeTableNode defNode = (DefaultMutableTreeTableNode) node;
//				if (defNode.getUserObject() instanceof VueTacheBrowser) {
//					VueTacheBrowser tache = (VueTacheBrowser) defNode.getUserObject();
            Object val = defNode.getUserObject();
            try {
                switch (column) {
                    case NUMERO:
//                        if (val instanceof VueTacheBrowser) {
//                            res = ((VueTacheBrowser) val).getTaNumOrdre();
//                        } else if (val instanceof TblPSFEProgramme) {
//                            res = ((TblPSFEProgramme) val).getPgNumOrdre();
//                        }
                        break;
                    case TYPE:
//                        try {
//                            if (val instanceof TblPSFEProgramme) {
//                                res = 1;
//                            } else if (val instanceof TblPSFEAction) {
//                                res = 2;
//                            } else if (val instanceof TblPSFEActivite) {
//                                try {
//                                    if (((TblPSFEActivite) val).getAtType() == TblPSFEActivite.TYPE_BIP) {
//                                        res = 33;
//                                    } else {
//                                        res = 3;
//                                    }
//                                } catch (Exception e) {
//                                    res = 3;
//                                }
//                            } else if (val instanceof VueTacheBrowser) {
//                                res = 4;
//                            } else {
//                                res = 0;
//                            }
//                        } catch (Exception e) {
//                            return 0;
//                        }
                        break;
                    case LIBELLE:
//                        if (val instanceof VueTacheBrowser) {
//                            res = ((VueTacheBrowser) val).getLibelle();
//                        }else if (val instanceof VueParagrapheExec) {
//                            res = ((VueParagrapheExec) val).getLibelle();
//                        } else {
                            res = val.toString();
//                        }
                        break;
                    case IMPUTATION:
//                        if (val instanceof VueParagrapheExec) {
//                            res = ((VueParagrapheExec) val).getImputation();
//                        }

                        break;
                    case PACP:
//                        if (val instanceof VueParagrapheExec) {
//                            res = ((VueParagrapheExec) val).getCpDisponible();
//                        }

                        break;
                    case PAAE:
//                        if (val instanceof VueParagrapheExec) {
//                            res = ((VueParagrapheExec) val).getAeDisponible();
//                        }

                        break;
                }
            } catch (Exception ex) {
                res = null;
            }
        }
        return res;
    }

    /**
     * What the TableHeader displays when the Table is in a JScrollPane.
     */
    @Override
    public String getColumnName(int column) {
        String res = "";
        switch (column) {
            case NUMERO:
                res = "N°";
                break;
            case TYPE:
                res = "TYPE";
                break;
            case LIBELLE:
                res = "Libelle";
                break;
            case IMPUTATION:
                res = "Imputation";
                break;
            case PACP:
                res = "CP Disponible";
                break;
            case PAAE:
                res = "AE Disponible";
                break;
        }
        return res;
    }

    /**
     * Tells if a column can be edited.
     */
    @Override
    public boolean isCellEditable(Object node, int column) {
        boolean res = false;
        if (node instanceof DefaultMutableTreeTableNode) {
            DefaultMutableTreeTableNode tableNode = (DefaultMutableTreeTableNode) node;
            if (tableNode.getUserObject() instanceof Activite) {
                switch (column) {
                    case NUMERO:
                        res = false;
                        break;
                    case LIBELLE:
                        res = false;
                        break;
                    case IMPUTATION:
                        res = false;
                        break;
                    case PACP:
                    case PAAE:
                        res = false;
                        break;
                }
            } else {
            }
        }

        return res;
    }

    /**
     * Called when done editing a cell.
     */
    @Override
    public void setValueAt(Object value, Object node, int column) {
//        if (node instanceof DefaultMutableTreeTableNode) {
//            DefaultMutableTreeTableNode defNode = (DefaultMutableTreeTableNode) node;
//            if (defNode.getUserObject() instanceof VueTacheBrowser) {
//                VueTacheBrowser tache = (VueTacheBrowser) defNode.getUserObject();
//                switch (column) {
//                    case NUMERO:
////						tache.setFirstName(value.toString());
//                        break;
//                    case TYPE:
//
//                        break;
//                    case LIBELLE:
////						tache.setMiddleName(value.toString());
//                        break;
//                    case RESPONSABLE:
////						tache.setLastName(value.toString());
//                        break;
//                    case NATURE:
////						tache.setPhoneNbr(value.toString());
//                        break;
//                    case PACP:
////                        if (value != null) {
////                            try {
////                                BigDecimal px = new BigDecimal(value.toString());
////                                tache.setTaCP(px);
////                            } catch (NumberFormatException e) {
////                            }
////                        }
//                        break;
//                }
//            }
//        }
    }

    @Override
    public boolean isLeaf(Object node) {
        if (node instanceof DefaultMutableTreeTableNode) {
            DefaultMutableTreeTableNode nod = (DefaultMutableTreeTableNode) node;
            return nod.isLeaf();
        } else {
            return super.isLeaf(node);
        }
    }

    @Override
    public int getChildCount(Object parent) {
        if (parent instanceof DefaultMutableTreeTableNode) {
            DefaultMutableTreeTableNode nod = (DefaultMutableTreeTableNode) parent;
            return nod.getChildCount();
        } else {
            return super.getChildCount(parent);
        }
    }

    @Override
    public Object getChild(Object parent, int index) {
        if (parent instanceof DefaultMutableTreeTableNode) {
            DefaultMutableTreeTableNode nod = (DefaultMutableTreeTableNode) parent;
            return nod.getChildAt(index);
        } else {
            return super.getChild(parent, index);
        }
    }

    @Override
    public int getIndexOfChild(Object parent, Object child) {
        if (parent instanceof DefaultMutableTreeTableNode) {
            DefaultMutableTreeTableNode nod = (DefaultMutableTreeTableNode) parent;
            return nod.getIndex((TreeTableNode) child);
        } else {
            return super.getIndexOfChild(parent, child);
        }

    }
}
