/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueAgentOM;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueMissionFiche;
import cm.eusoworks.renderer.AgentOMRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import java.awt.Cursor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class OrdreMissionFrame extends javax.swing.JFrame {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<OrdreMission> listOM = ObservableCollections.observableList(new ArrayList<OrdreMission>());
    OrdreMission currentOM = null;
    String selectedAgent;
    List<VueAgentOM> list;
    GrecoReports fonctions = new GrecoReports();

    public OrdreMissionFrame() {
        initComponents();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Traitement ordres de mission (OM)  ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        setLocationRelativeTo(null);
        jListOM.setCellRenderer(new AgentOMRenderer());  
        loadOrganisations();
        loadExercicesBudgetisation();
        me = this;
    }

    private void initOMUI() {
        String vide = "***";
        if (currentOM == null) {
            lblReference.setText(vide);
            lblDateDerniereModif.setText(vide);
            lblUser.setText(vide);
            lblPrestataire.setText(vide);
            lblObjet.setText(vide);
            btnImprimer.setVisible(false);
            btnReservationAnnuler.setVisible(false);
            btnReserver.setVisible(false);
            btnFichedeSuiviMission.setVisible(false);
        } else {
            lblReference.setText(currentOM.getMotif());
            lblDateDerniereModif.setText(currentOM.getLastUpdate().toString());
            lblUser.setText(currentOM.getUserUpdate());
            lblPrestataire.setText(currentOM.getNomCompletWithMatricule());
            lblObjet.setText(currentOM.getMotifReference());
            btnImprimer.setVisible(true);
            if (currentOM.getEtat() >= EtatDossier.reserve) {
                btnReserver.setVisible(false);
                btnSupprimer.setVisible(false);
            } else {
                btnReserver.setVisible(true);
                btnSupprimer.setVisible(true);
            }
            if (currentOM.getEtat() == EtatDossier.mandate) {
                btnReservationAnnuler.setVisible(true);
            } else {
                btnReservationAnnuler.setVisible(false);
            }
            btnFichedeSuiviMission.setVisible(true);
        }
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'exercice budgétaire");
            return false;
        }

        return true;
    }

    public List<OrdreMission> getListOM() {
        return listOM;
    }

    public void setListOM(List<OrdreMission> listOM) {
        this.listOM = listOM;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jLabel2 = new javax.swing.JLabel();
        lblDateDerniereModif = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblUser = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        splitpane = new javax.swing.JSplitPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListOM = new javax.swing.JList();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableOM = new javax.swing.JTable();
        pDetailBCA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblReference = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblPrestataire = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lblObjet = new javax.swing.JLabel();
        btnImprimer = new javax.swing.JButton();
        cboModele = new javax.swing.JComboBox<>();
        btnFichedeSuiviMission = new cm.eusoworks.tools.ui.GButton();
        pBouton = new javax.swing.JPanel();
        btnNouveau = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        btnReserver = new cm.eusoworks.tools.ui.GButton();
        btnReservationAnnuler = new cm.eusoworks.tools.ui.GButton();

        jLabel2.setText("Dernière modification : ");

        lblDateDerniereModif.setText("***");

        jLabel3.setText("par : ");

        lblUser.setText("***");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Outil de montage des bons de commande administratif");

        jPanel2.setBackground(new java.awt.Color(102, 0, 102));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboOrganisation, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(568, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.NORTH);

        splitpane.setDividerLocation(400);

        jListOM.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jListOM.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListOM.setFixedCellHeight(30);
        jListOM.setFixedCellWidth(500);
        jListOM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListOMMouseClicked(evt);
            }
        });
        jListOM.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jListOMValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(jListOM);

        splitpane.setLeftComponent(jScrollPane2);

        jPanel1.setLayout(new java.awt.BorderLayout());

        tableOM.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        tableOM.setGridColor(new java.awt.Color(249, 249, 249));
        tableOM.setRowHeight(30);
        tableOM.setSelectionBackground(new java.awt.Color(208, 217, 230));
        tableOM.setSelectionForeground(new java.awt.Color(105, 128, 151));
        tableOM.setShowGrid(true);
        tableOM.setShowVerticalLines(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listOM}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableOM);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${strEtat}"));
        columnBinding.setColumnName("Etat");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("N° dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantGlobal}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${destination}"));
        columnBinding.setColumnName("Destination");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateDepart}"));
        columnBinding.setColumnName("Date Depart");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateRetour}"));
        columnBinding.setColumnName("Date Retour");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${motifReference}"));
        columnBinding.setColumnName("Motif");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        tableOM.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableOMMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableOM);

        jPanel1.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pDetailBCA.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel1.setText("Réf. : ");

        lblReference.setText("***");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel4.setText("Agent : ");

        lblPrestataire.setFont(new java.awt.Font("Tahoma", 0, 10)); // NOI18N
        lblPrestataire.setText("***+");

        jLabel6.setText("Objet : ");

        lblObjet.setText("***");

        btnImprimer.setText("Imprimer");
        btnImprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimerActionPerformed(evt);
            }
        });

        cboModele.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Modele CCAA 2016", "Modele standard" }));

        btnFichedeSuiviMission.setText("Fiche de suivi des missions");
        btnFichedeSuiviMission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFichedeSuiviMissionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pDetailBCALayout = new javax.swing.GroupLayout(pDetailBCA);
        pDetailBCA.setLayout(pDetailBCALayout);
        pDetailBCALayout.setHorizontalGroup(
            pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDetailBCALayout.createSequentialGroup()
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pDetailBCALayout.createSequentialGroup()
                                .addComponent(lblObjet, javax.swing.GroupLayout.PREFERRED_SIZE, 385, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(btnImprimer, javax.swing.GroupLayout.PREFERRED_SIZE, 113, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pDetailBCALayout.createSequentialGroup()
                                .addComponent(lblPrestataire, javax.swing.GroupLayout.PREFERRED_SIZE, 370, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(cboModele, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(lblReference, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(25, 25, 25))
            .addGroup(pDetailBCALayout.createSequentialGroup()
                .addComponent(btnFichedeSuiviMission, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pDetailBCALayout.setVerticalGroup(
            pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDetailBCALayout.createSequentialGroup()
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(lblReference))
                .addGap(2, 2, 2)
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(lblPrestataire)
                    .addComponent(cboModele, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(lblObjet)
                    .addComponent(btnImprimer))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 10, Short.MAX_VALUE)
                .addComponent(btnFichedeSuiviMission, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jPanel1.add(pDetailBCA, java.awt.BorderLayout.SOUTH);

        pBouton.setBackground(new java.awt.Color(204, 204, 204));
        pBouton.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnNouveau.setText("Etablir un OM");
        btnNouveau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNouveauActionPerformed(evt);
            }
        });
        pBouton.add(btnNouveau);

        btnSupprimer.setText("Supprimer ");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        pBouton.add(btnSupprimer);

        btnReserver.setText("Réserver");
        btnReserver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReserverActionPerformed(evt);
            }
        });
        pBouton.add(btnReserver);

        btnReservationAnnuler.setText("Annuler la Réservation");
        btnReservationAnnuler.setCouleur(1);
        btnReservationAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReservationAnnulerActionPerformed(evt);
            }
        });
        pBouton.add(btnReservationAnnuler);

        jPanel1.add(pBouton, java.awt.BorderLayout.NORTH);

        splitpane.setRightComponent(jPanel1);

        getContentPane().add(splitpane, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNouveauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNouveauActionPerformed
        // TODO add your handling code here:
        final Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            return;
        }
        final Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            return;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    OrdreMissionNewDialog frame = new OrdreMissionNewDialog(me, true, e.getMillesime(), o, null);
                    frame.setVisible(true);
                    loadAgentOM();
                } catch (Exception e) {
                }
            }
        });
    }//GEN-LAST:event_btnNouveauActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
            if (e != null) {
                loadAgentOM();
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }

            if (o != null) {
                loadAgentOM();
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void jListOMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListOMMouseClicked
        // TODO add your handling code here:
        VueAgentOM v = null;
        try {
            v = (VueAgentOM) jListOM.getSelectedValue();
        } catch (Exception exx) {
            v = null;
        }
        if (v != null) {
            selectedAgent = v.getMatricule();
            listOM.clear();
            currentOM = null;
            initOMUI();

            List<OrdreMission> l = new ArrayList<>();
            try {
                Exercice e = (Exercice) cboExercice.getSelectedItem();
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                l = GrecoServiceFactory.getOrdreMissionService().getOMByAgent(e.getMillesime(),
                        o.getOrganisationID(), v.getMatricule());
            } catch (Exception ex) {
            }
            if (l != null && !l.isEmpty()) {
                for (OrdreMission o : l) {
                    listOM.add(o);
                }
            }
        }
    }//GEN-LAST:event_jListOMMouseClicked

    private void tableOMMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableOMMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            int r = tableOM.getSelectedRow();
            final OrdreMission b = (OrdreMission) listOM.get(r);

            final Organisation o = (Organisation) cboOrganisation.getSelectedItem();
            if (o == null) {
                return;
            }
            final Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e == null) {
                return;
            }

            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        OrdreMissionNewDialog frame = new OrdreMissionNewDialog(me, true, e.getMillesime(), o, b);
                        frame.setVisible(true);
                        loadAgentOM();
                        for (int i = 0; i < list.size(); i++) {
                            VueAgentOM v = list.get(i);
                            if (v.getMatricule().equalsIgnoreCase(selectedAgent)) {
                                jListOM.setSelectedIndex(i);
                                break;
                            }
                        }
                        initOMUI();
                    } catch (Exception e) {
                    }
                }
            });
        } else {
            int r = tableOM.getSelectedRow();
            OrdreMission b = null;
            try {
                b = (OrdreMission) listOM.get(r);
            } catch (Exception e) {
                b = null;
            }
            if (b != null) {
                currentOM = b;
                initOMUI();
            }
        }
    }//GEN-LAST:event_tableOMMouseClicked

    private void jListOMValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jListOMValueChanged
        // TODO add your handling code here:
        jListOMMouseClicked(null);
    }//GEN-LAST:event_jListOMValueChanged

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        int r = tableOM.getSelectedRow();
        if (r != -1) {
            final OrdreMission b = (OrdreMission) listOM.get(r);
            int res = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir supprimer cet ordre de mission " + b.getMotif() + "\n" + "[" + b.getMatricule() + "] " + b.getNomAgent() + " " + b.getPrenomAgent(),
                    "Suppression de l'OM", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getOrdreMissionService().supprimer(b.getOmID(), GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "OM retiré du système  ");
                    loadAgentOM();
                    currentOM = null;
                    initOMUI();
                    for (int i = 0; i < list.size(); i++) {
                        VueAgentOM v = list.get(i);
                        if (v.getMatricule().equalsIgnoreCase(selectedAgent)) {
                            jListOM.setSelectedIndex(i);
                            break;
                        }
                    }
                    initOMUI();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vous n'avez pa sélectionné d'ordre de mission à supprimer");
        }

    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnImprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimerActionPerformed
        // TODO add your handling code here:
        int r = tableOM.getSelectedRow();
        if (r != -1) {
            final OrdreMission b = (OrdreMission) listOM.get(r);
            imprimer(b);
        }
    }//GEN-LAST:event_btnImprimerActionPerformed

    private void btnReserverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReserverActionPerformed
        // TODO add your handling code here:
        int r = tableOM.getSelectedRow();
        if (r != -1) {
            final OrdreMission b = (OrdreMission) listOM.get(r);
            int res = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir réserver les crédits sur cet OM  " + b.getMotif() + "\n" + "[" + b.getMatricule() + "] " + b.getNomAgent() + " " + b.getPrenomAgent(),
                    "Réservation de crédits", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                try {
                    OrdreMissionReservationDialog dialog = new OrdreMissionReservationDialog(me, true, b);
                    dialog.setVisible(true);
                    loadAgentOM();
                    currentOM = null;
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
            }
        } else {
            JOptionPane.showMessageDialog(this, "Vous n'avez pa sélectionné d'ordre de mission à réserver");
        }
    }//GEN-LAST:event_btnReserverActionPerformed

    private void btnReservationAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReservationAnnulerActionPerformed
        // TODO add your handling code here:
        int r = tableOM.getSelectedRow();
        if (r != -1) {
            final OrdreMission b = (OrdreMission) listOM.get(r);
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sûr de vouloir annuler la réservervation des crédits sur cet OM  " + b.getMotif() + "\n" + "[" + b.getMatricule() + "] " + b.getNomAgent() + " " + b.getPrenomAgent());
            if (res == JOptionPane.YES_OPTION) {
                try {
                    String motif = "";
                    boolean annuler = false;
                    GrecoServiceFactory.getOrdreMissionService().reservationOMAnnuler(currentOM.getOmID(), annuler, motif, GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    GrecoSession.notifications.success();
                    loadAgentOM();
                    currentOM = null;
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Vous n'avez pa sélectionné d'ordre de mission à réserver");
        }
    }//GEN-LAST:event_btnReservationAnnulerActionPerformed

    private void btnFichedeSuiviMissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFichedeSuiviMissionActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }

            if (o != null) {
                imprimerFicheOM();
            }
        }
        
    }//GEN-LAST:event_btnFichedeSuiviMissionActionPerformed

    private void imprimerFicheOM() {
            setCursor(new Cursor(Cursor.WAIT_CURSOR));
            SwingUtilities.invokeLater(new Runnable() {

                @Override
                public void run() {
                    Thread con = new Thread(new Runnable() {

                        @Override
                        public void run() {
                            try {
                                HashMap parameters = fonctions.mainParameters();

                                String organisationID = null;
                                String millesime = null;
                                Exercice exo = null;
                                Organisation o = null;

                                o = (Organisation) cboOrganisation.getSelectedItem();
                                organisationID = o.getOrganisationID();

                                exo = (Exercice) cboExercice.getSelectedItem();
                                millesime = exo.getMillesime();
                                
                                String ag = currentOM.getMatricule();

                                ////////////////////////////////////////////////
                                List<VueMissionFiche> fiche = GrecoServiceFactory.getReportService().getMissionFiche(organisationID, millesime, ag);
                                if (fiche != null) {
                                    GrecoImages mesImages = new GrecoImages();
                                    parameters.put("logo", mesImages.logo());
                                    parameters.put("PARAM_DispositifFR", "FST MANAGER");
                                    parameters.put("PARAM_DispositifUS", "Dispositif de gestion budgétaire et comptable du FST");

                                    JRHelper.viewReport(fonctions.ficheMission(), parameters, new JRBeanCollectionDataSource(fiche, false), null, null);
                                }

                            } catch (Exception ex) {
                                ex.printStackTrace();
                                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                            }
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                    }, "Performer");
                    con.start();
                }
            });
    }
    
    
    private void imprimer(final OrdreMission b) {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueOMReport> list = new ArrayList<>();
                            list.add(GrecoServiceFactory.getReportService().getOM(b.getOmID()));

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("entete", mesImages.logoOrganisation());
                            parameters.put("drapeau", mesImages.drapeauCroise());
                            parameters.put("user", Crypto.decrypt(GrecoSession.USER_CONNECTED.getLogin()) + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("controleur", "LE CONTROLEUR FINANCIER");
                            parameters.put("comptable", "L'AGENT COMPTABLE");
                            int i = cboModele.getSelectedIndex();
                            if (i == 0) {
                                JRHelper.viewReport(fonctions.ordreMisssionCCAA(), parameters, new JRBeanCollectionDataSource(list), null, null);
                            } else {
                                JRHelper.viewReport(fonctions.ordreMisssion(), parameters, new JRBeanCollectionDataSource(list), null, null);
                            }

                        } catch (Exception ex) {
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void loadAgentOM() {
        jListOM.removeAll();
        jListOM.repaint();
        // vider le tableau des bca
        listOM.clear();
        // vider le panneau de details
        initOMUI();
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getOrdreMissionService().getOMNumberByAgent(e.getMillesime(), o.getOrganisationID());
        } catch (Exception ex) {
        }
        if (list != null) {
            jListOM.setListData(list.toArray());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(OrdreMissionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(OrdreMissionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(OrdreMissionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(OrdreMissionFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new OrdreMissionFrame().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnFichedeSuiviMission;
    private javax.swing.JButton btnImprimer;
    private javax.swing.JButton btnNouveau;
    private cm.eusoworks.tools.ui.GButton btnReservationAnnuler;
    private cm.eusoworks.tools.ui.GButton btnReserver;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox<String> cboModele;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JList jListOM;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblDateDerniereModif;
    private javax.swing.JLabel lblObjet;
    private javax.swing.JLabel lblPrestataire;
    private javax.swing.JLabel lblReference;
    private javax.swing.JLabel lblUser;
    private javax.swing.JPanel pBouton;
    private javax.swing.JPanel pDetailBCA;
    private javax.swing.JSplitPane splitpane;
    private javax.swing.JTable tableOM;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
