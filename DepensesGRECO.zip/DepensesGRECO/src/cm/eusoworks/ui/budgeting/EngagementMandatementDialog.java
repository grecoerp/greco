/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.Liasse;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.Mandatement;
import cm.eusoworks.entities.model.MandatementDroits;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import cm.eusoworks.entities.view.VueMandatementReport;
import cm.eusoworks.entities.view.VuePaieBulletin;
import cm.eusoworks.entities.view.VuePaieRecapRubrique;
import cm.eusoworks.entities.view.VuePaieRubrique;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.renderer.BooleanTableRenderer;
import cm.eusoworks.renderer.DecimalTableRenderer;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.algorithme.AlgoRIB;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.util.DateUtil;
import com.siicore.util.StringUtil;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementMandatementDialog extends GrecoTemplateDialog {

    public static int MODE_ENREGISTRE = 1;
    public static int MODE_SUPPRESSION = 2;
    public static int MODE_VALIDATION = 3;
    public static int MODE_ANNULATION_VALIDATION = 4;
    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    GrecoReports fonctions = new GrecoReports();
    int mode = MODE_ENREGISTRE;

    Liquidation selectedLiquidation = null;
    Engagement currentEngagement;
    Mandatement currentMandatement;
    List<LiquidationDroits> listLiquidation = ObservableCollections.observableList(new ArrayList<LiquidationDroits>());
    List<LiquidationDroits> listForMandatement;
    List<Mandatement> listMandatement = ObservableCollections.observableList(new ArrayList<Mandatement>());
    Mandatement selectedMandatement;

    List<Liasse> listLiasse = ObservableCollections.observableList(new ArrayList<Liasse>());

    public EngagementMandatementDialog(JFrame parent, boolean modal, Liquidation liquidation, int modeValide) {
        super(parent, true);
        initComponents();
        this.mode = modeValide;
        try {
            setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Mandatement du Dossier N°:  ");
        } catch (Exception e) {
        }

        initMode();
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.selectedLiquidation = liquidation;

        setPreferredSize(new Dimension(850, 500));
        setLocationRelativeTo(null);

        initEngagementUI();

    }

    private void initMode() {
        switch (this.mode) {
            case 1:
                btnAction.setText("Enregistrer le mandatement");
                dtpDateMandatement.setDate(new Date());
                break;
        }
    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getTypeID());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {

        currentEngagement = GrecoServiceFactory.getEngagementService().getEngagement(selectedLiquidation.getEngagementID());
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        txtNumDossier.setText(currentEngagement.getNumDossier());
        txtObjet.setText(currentEngagement.getObjet().trim());

        btnBeneficiare.setText(currentEngagement.getBeneficiaire());

        try {
            txtMontant.setValue(currentEngagement.getMontantTTC());
        } catch (Exception e) {
        }

        txtMontantIR.setValue(selectedLiquidation.getMontantIR());
        txtMontantNAP.setValue(selectedLiquidation.getMontantNAP());
        txtMontantRG.setValue(selectedLiquidation.getMontantRG());
        txtMontantTVA.setValue(selectedLiquidation.getMontantTVA());
        txtMontantTaxes.setValue(selectedLiquidation.getMontantIR().add(selectedLiquidation.getMontantTVA()));

        try {
            loadMandatement();
        } catch (Exception e) {
        }

        //charger la liste des liquidation rubriques
        try {
            List<LiquidationDroits> ltemp = GrecoServiceFactory.getDroitsService().listeLiquidationDroits(selectedLiquidation.getLiquidationID());
            for (LiquidationDroits droits : ltemp) {
                int mnt = com.google.common.math.DoubleMath.roundToInt(droits.getMontant().doubleValue(), RoundingMode.HALF_UP);
                droits.setMontant(BigDecimal.valueOf(mnt));
                listLiquidation.add(droits);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        //ordonnateur par défaut
        try {
            agentComp.setMatricule(currentEngagement.getGestionnaire());
        } catch (Exception e) {
        }

        //rib bancaire
        List<VueFournisseurRIB> list = GrecoServiceFactory.getBanqueService().ribByFournisseur(currentEngagement.getFournisseurID());
        if (list != null) {
            if (list.size() == 1) {
                txtRIB.setValue(list.get(0).getRib());
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        benefGroup = new javax.swing.ButtonGroup();
        radioGroup = new javax.swing.ButtonGroup();
        validGroup = new javax.swing.ButtonGroup();
        jSplitPane1 = new javax.swing.JSplitPane();
        panelInfos = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtMontantNAP = new javax.swing.JFormattedTextField();
        txtMontantIR = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtMontantTVA = new javax.swing.JFormattedTextField();
        txtMontantRG = new javax.swing.JFormattedTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        txtMontantTaxes = new javax.swing.JFormattedTextField();
        jLabel8 = new javax.swing.JLabel();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        dtpDateMandatement = new org.jdesktop.swingx.JXDatePicker();
        btnAction = new cm.eusoworks.tools.ui.GButton();
        btnOPSupprimer = new cm.eusoworks.tools.ui.GButton();
        agentComp = new cm.eusoworks.component.AgentComponent();
        jLabel3 = new javax.swing.JLabel();
        btnOPImprimer = new cm.eusoworks.tools.ui.GButton();
        jLabel10 = new javax.swing.JLabel();
        txtRIB = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOrdrePaiement = new javax.swing.JTable();
        btnOPAjouter = new cm.eusoworks.tools.ui.GButton();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblPieces = new javax.swing.JTable();
        chkCocherTous = new javax.swing.JCheckBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Liquidation ");

        panelInfos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        panelInfos.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 181, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        panelInfos.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 180, -1));

        jLabel2.setText("Montant :");
        panelInfos.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 80, 30));

        txtMontant.setEnabled(false);
        panelInfos.add(txtMontant, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 180, 30));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        panelInfos.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        panelInfos.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        panelInfos.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 270, 30));
        panelInfos.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        panelInfos.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 180, 50));

        txtReference.setEditable(false);
        txtReference.setEnabled(false);
        panelInfos.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 180, -1));
        panelInfos.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 260, 260, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        panelInfos.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 86, 22));

        jLabel1.setFont(new java.awt.Font("Lucida Grande", 1, 14)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("RUBRIQUES DE LIQUIDATION");
        panelInfos.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 276, 247, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("NET A PAYER : ");
        panelInfos.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 100, 30));

        txtMontantNAP.setEditable(false);
        txtMontantNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantNAP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontantNAP.setEnabled(false);
        txtMontantNAP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtMontantNAP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMontantNAPActionPerformed(evt);
            }
        });
        panelInfos.add(txtMontantNAP, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 160, 30));

        txtMontantIR.setEditable(false);
        txtMontantIR.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantIR.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontantIR.setEnabled(false);
        txtMontantIR.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        panelInfos.add(txtMontantIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 160, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("IR : ");
        panelInfos.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 90, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("TVA : ");
        panelInfos.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 90, 30));

        txtMontantTVA.setEditable(false);
        txtMontantTVA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantTVA.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontantTVA.setEnabled(false);
        txtMontantTVA.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        panelInfos.add(txtMontantTVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, 160, 30));

        txtMontantRG.setEditable(false);
        txtMontantRG.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantRG.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontantRG.setEnabled(false);
        txtMontantRG.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        panelInfos.add(txtMontantRG, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 160, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("RETENUE  : ");
        panelInfos.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 90, 30));

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel11.setText("TVA + IR : ");
        panelInfos.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 110, 30));

        txtMontantTaxes.setEditable(false);
        txtMontantTaxes.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantTaxes.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontantTaxes.setEnabled(false);
        txtMontantTaxes.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        panelInfos.add(txtMontantTaxes, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 450, 160, 30));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgreceptionMini.png"))); // NOI18N
        panelInfos.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 630));

        jSplitPane1.setLeftComponent(panelInfos);

        pDetails.setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Date : ");

        btnAction.setText("Enregistrer le(s) OP ci-dessous");
        btnAction.setCouleur(2);
        btnAction.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAction.setStyle(2);
        btnAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionActionPerformed(evt);
            }
        });

        btnOPSupprimer.setText("X");
        btnOPSupprimer.setCouleur(3);
        btnOPSupprimer.setFont(new java.awt.Font("Lucida Grande", 0, 12)); // NOI18N
        btnOPSupprimer.setStyle(5);
        btnOPSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOPSupprimerActionPerformed(evt);
            }
        });

        jLabel3.setText("Ordonnateur : ");

        btnOPImprimer.setText("P");
        btnOPImprimer.setStyle(5);
        btnOPImprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOPImprimerActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("RIB Bancaire : ");

        try {
            txtRIB.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-#####-###########-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtRIB.setText("");
        txtRIB.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtRIB.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtRIBFocusLost(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 204));
        jLabel6.setText("Liste des Ordres de Paiement en cours sur cette liquidation    ");

        tblOrdrePaiement.setFont(new java.awt.Font("Lucida Grande", 0, 16)); // NOI18N
        tblOrdrePaiement.setRowHeight(23);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listMandatement}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblOrdrePaiement);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numeroOP}"));
        columnBinding.setColumnName("N° OP");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${objet}"));
        columnBinding.setColumnName("Objet");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantMandate}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${details}"));
        columnBinding.setColumnName("Détails");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedMandatement}"), tblOrdrePaiement, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane1.setViewportView(tblOrdrePaiement);
        if (tblOrdrePaiement.getColumnModel().getColumnCount() > 0) {
            tblOrdrePaiement.getColumnModel().getColumn(0).setResizable(false);
            tblOrdrePaiement.getColumnModel().getColumn(0).setPreferredWidth(10);
            tblOrdrePaiement.getColumnModel().getColumn(1).setPreferredWidth(150);
            tblOrdrePaiement.getColumnModel().getColumn(2).setPreferredWidth(20);
            tblOrdrePaiement.getColumnModel().getColumn(2).setCellRenderer(new DecimalTableRenderer());
            tblOrdrePaiement.getColumnModel().getColumn(3).setPreferredWidth(15);
        }

        btnOPAjouter.setText("+");
        btnOPAjouter.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnOPAjouter.setStyle(5);
        btnOPAjouter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOPAjouterActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 102, 204));
        jLabel14.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        jLabel14.setText("Pièces accompagnant la liasse de la dépense");

        tblPieces.setRowHeight(22);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listLiasse}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblPieces);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelleFr}"));
        columnBinding.setColumnName("Pièce(s)");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("Cocher");
        columnBinding.setColumnClass(Boolean.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane3.setViewportView(tblPieces);
        if (tblPieces.getColumnModel().getColumnCount() > 0) {
            tblPieces.getColumnModel().getColumn(0).setPreferredWidth(500);
            tblPieces.getColumnModel().getColumn(1).setPreferredWidth(5);
            tblPieces.getColumnModel().getColumn(1).setCellRenderer(new BooleanTableRenderer());
        }

        chkCocherTous.setText("Cocher tous");
        chkCocherTous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCocherTousActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(260, 260, 260)
                        .addComponent(chkCocherTous, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40)
                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(dtpDateMandatement, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addGap(10, 10, 10)
                        .addComponent(txtRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70)
                        .addComponent(btnAction, javax.swing.GroupLayout.PREFERRED_SIZE, 227, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(btnOPAjouter, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnOPSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(btnOPImprimer, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(8, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateMandatement, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(30, 30, 30)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(5, 5, 5)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnOPAjouter, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnOPImprimer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btnOPSupprimer, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(chkCocherTous))
                .addGap(5, 5, 5)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pDetails.add(jPanel1, "liquidation");

        jSplitPane1.setRightComponent(pDetails);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionActionPerformed
        // TODO add your handling code here:
        switch (this.mode) {
            case 1:
                enregistrerLiquidation();
                break;
        }
    }//GEN-LAST:event_btnActionActionPerformed

    private void btnOPSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOPSupprimerActionPerformed
        // TODO add your handling code here:
        if (selectedMandatement != null) {
            if (selectedMandatement.getMandatementID() == null) {
                int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir retirer ce mandatement de la liste ?");
                if (res == JOptionPane.YES_OPTION) {
                    List<Mandatement> list = new ArrayList<>();
                    for (Mandatement m : listMandatement) {
                        if (!m.getNumeroOP().equals(selectedMandatement.getNumeroOP())) {
                            list.add(m);
                        }
                    }
                    listMandatement.clear();
                    for (Mandatement mandatement : list) {
                        listMandatement.add(mandatement);
                    }
                }
            } else {
                int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer cette liquidation ?");
                if (res == JOptionPane.YES_OPTION) {
                    try {
                        GrecoServiceFactory.getEngagementService().MandatementSupprimer(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedMandatement.getMandatementID());
                        GrecoSession.notifications.success();
                        loadMandatement();
                        GrecoOptionPane.showSuccessDialog(" mandatement(s) supprimé(s) avec succès ");
                        glasspane.arret();

                    } catch (GrecoException e) {
                        glasspane.arret();
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }
                }
            }

        }
    }//GEN-LAST:event_btnOPSupprimerActionPerformed

    private void txtMontantNAPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMontantNAPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontantNAPActionPerformed

    private void btnOPImprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOPImprimerActionPerformed
        // TODO add your handling code here:
        imprimer(currentMandatement);
//        imprimerBulletinPaie();
        //    imprimerPaieRecap();
    }//GEN-LAST:event_btnOPImprimerActionPerformed

    private void btnOPAjouterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOPAjouterActionPerformed
        // TODO add your handling code here:
        nouveauMandat();
    }//GEN-LAST:event_btnOPAjouterActionPerformed

    private void chkCocherTousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCocherTousActionPerformed
        // TODO add your handling code here:
        selectAll();;
    }//GEN-LAST:event_chkCocherTousActionPerformed

    private void txtRIBFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtRIBFocusLost
        try {
            // TODO add your handling code here:
            txtRIB.commitEdit();
        } catch (ParseException ex) {
            Logger.getLogger(EngagementMandatementDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        if(!AlgoRIB.checkRIB(txtRIB.getValue().toString().replace("-", ""))){
            txtRIB.setValue(null);
            GrecoOptionPane.showErrorDialog("RIB incorrect");
        }
    }//GEN-LAST:event_txtRIBFocusLost

    private void selectAll() {
        // TODO add your handling code here:
        boolean s = chkCocherTous.isSelected();
        List<Liasse> l = new ArrayList<>();
        for (Liasse st : listLiasse) {
            st.setChecked(s);
            l.add(st);
        }
        listLiasse.clear();
        for (Liasse st : l) {
            listLiasse.add(st);
        }
    }

    private void getListForMandatement() {
//        if (listForMandatement == null) {
            listForMandatement = new ArrayList<>();
//        }

        List<LiquidationDroits> ltemp = new ArrayList<>();
        ltemp.clear();
        for (LiquidationDroits l : listLiquidation) {
            ltemp.add(l);
            listForMandatement.add(l);
        }
        // rechercher les existants et bloquer 
        List<String> droitsUsed = new ArrayList<>();
        if (!listMandatement.isEmpty()) {
            for (Mandatement m : listMandatement) {
                try {
                    List<MandatementDroits> liqs = m.getDroits();
                for (MandatementDroits l : liqs) {
                    droitsUsed.add(l.getDroitID());
                }
                } catch (Exception e) {
                }
                
            }

            for (int i = 0; i < listLiquidation.size(); i++) {
                LiquidationDroits liq = listLiquidation.get(i);
                for (String l : droitsUsed) {
                    if (liq.getDroitID().equalsIgnoreCase(l)) {
                        ltemp.remove(liq);
                        break;
                    }
                }
            }

            listForMandatement.clear();
            for (LiquidationDroits l : ltemp) {
                listForMandatement.add(l);
            }

        }
    }

    private void nouveauMandat() {
        getListForMandatement();
        if (listForMandatement.isEmpty()) {
            GrecoOptionPane.showWarningDialog("Impossible de faire cet OP. La liquidation ne comporte aucune rubrique");
            return;
        }
        EngagementMandatementOPDialog dialog = new EngagementMandatementOPDialog(me, true, listForMandatement, txtObjet.getText());
        dialog.setVisible(true);

        List<Mandatement> list = new ArrayList<>();
        for (Mandatement m : listMandatement) {
            list.add(m);
        }
        Mandatement newMandat = dialog.getMandatement();
        if (newMandat != null) {
            boolean isOPAlreadyExists = false;
            for (Mandatement mandatement : listMandatement) {
                if (mandatement.getNumeroOP().equalsIgnoreCase(newMandat.getNumeroOP())) {
                    isOPAlreadyExists = true;
                }
            }
            if (!isOPAlreadyExists) {
                list.add(newMandat);
            } else {
                GrecoOptionPane.showErrorDialog("Ce numéro d'Ordre de Paiement est déjà dans la liste. Réessayer SVP");
            }

        }
        dialog.dispose();

        listMandatement.clear();
        for (Mandatement mandatement : list) {
            listMandatement.add(mandatement);
        }
    }

    private void imprimer(final Mandatement b) {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueMandatementReport> list = new ArrayList<>();
                            list = GrecoServiceFactory.getReportService().getMandatementReport(currentMandatement.getMandatementID());

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("logo", mesImages.logoOrganisation());
//                            parameters.put("user", GrecoSession.USER_CONNECTED.getLogin() + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("napLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, b.getMontantMandate()) + "  francs CFA");
//                            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitle());
//                            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

                            JRHelper.viewReport(fonctions.mandat(), parameters, new JRBeanCollectionDataSource(list), null, null);

                        } catch (Exception ex) {
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void imprimerBulletinPaie() {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            glasspane.attente();
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            VuePaieBulletin fiche = GrecoServiceFactory.getReportService().getPaieBulletin(null, null, null, null);
                            if (fiche != null) {
                                List<VuePaieBulletin> bulletinPaie = new ArrayList<>();
                                bulletinPaie.add(fiche);

                                //sub reports stream
                                InputStream base = fonctions.paieRubriqueBase();
                                InputStream retenues = fonctions.paieRubriqueRetenues();
                                InputStream net = fonctions.paieRubriqueNet();

                                //sub report data collection
                                List<VuePaieRubrique> dataBase = GrecoServiceFactory.getReportService().getPaieRubriquesBase(null, null, null, null);
                                List<VuePaieRubrique> dataRetenues = GrecoServiceFactory.getReportService().getPaieRubriquesRetenues(null, null, null, null);
                                List<VuePaieRubrique> dataNet = GrecoServiceFactory.getReportService().getPaieRubriquesNet(null, null, null, null);

                                GrecoImages mesImages = new GrecoImages();

                                parameters.put("logo", mesImages.logoOrganisation());
                                parameters.put("montantEnLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, fiche.getNetAPayer()) + "  francs CFA");
                                parameters.put("rubriqueBase", base);
                                parameters.put("rubriqueRetenues", retenues);
                                parameters.put("rubriqueNet", net);
                                parameters.put("dataCollectionBase", dataBase);
                                parameters.put("dataCollectionRetenue", dataRetenues);
                                parameters.put("dataCollectionNet", dataNet);

                                JRHelper.viewReport(fonctions.paieBulletin(), parameters, new JRBeanCollectionDataSource(bulletinPaie), null, null);
                            }

                        } catch (Exception ex) {
                            glasspane.arret();
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        glasspane.arret();
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void imprimerPaieRecap() {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            glasspane.attente();
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VuePaieRecapRubrique> fiche = GrecoServiceFactory.getReportService().getPaieRecapCotisations(null, null);
                            if (fiche != null) {
                                //sub reports stream
                                InputStream base = fonctions.paieRubriqueBase();
                                InputStream retenues = fonctions.paieRubriqueRetenues();
                                InputStream net = fonctions.paieRubriqueNet();

                                GrecoImages mesImages = new GrecoImages();

                                parameters.put("logo", mesImages.logoOrganisation());
                                parameters.put("periodeDebut", DateUtil.date(2016, 5, 1));
                                parameters.put("periodeFin", DateUtil.date(2016, 5, 31));

                                JRHelper.viewReport(fonctions.paieRecapCotisation(), parameters, new JRBeanCollectionDataSource(fiche), null, null);
                            }

                        } catch (Exception ex) {
                            glasspane.arret();
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        glasspane.arret();
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private boolean controlData() {

        if (agentComp.getMatricule() == null || agentComp.getMatricule().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le matricule de l'ordonnateur ");
            return false;
        }
        if (dtpDateMandatement.getDate() == null) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir la date du mandatement ");
            return false;
        }
        if (txtRIB.getValue() == null) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le RIB du fournisseur ");
            return false;
        }
        List<Liasse> list = new ArrayList<>();
        for (Liasse l : listLiasse) {
            list.add(l);
        }
        if (list.isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez cocher les pièces de la liasse ");
            return false;
        }
        if (listMandatement.isEmpty()) {
            GrecoOptionPane.showWarningDialog("Aucun ordre de paiement dans le tableau. ");
            return false;
        }

        return true;
    }

    private void enregistrerLiquidation() {
        if (controlData()) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        glasspane.setText("enregistrement de la dépense ....");
                        glasspane.attente();
                        List<String> listLiasseID = new ArrayList<>();
                        for (Liasse l : listLiasse) {
                            if (l.isChecked()) {
                                listLiasseID.add(l.getLiasseID());
                            }
                        }
                        int nbMandat = 0;
                        for (Mandatement mandat : listMandatement) {

                            if (mandat.getMandatementID() == null) {
                                try {
                                    GrecoServiceFactory.getEngagementService().MandatementEnregistrement(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                            null, selectedLiquidation.getLiquidationID(), agentComp.getMatricule(), mandat.getMontantMandate(), txtRIB.getText(), mandat.getNumeroOP(), mandat.getObjet(),
                                            listLiasseID, mandat.getDroits());
                                    nbMandat++;

                                } catch (GrecoException e) {
                                    glasspane.arret();
                                    GrecoSession.notifications.echec();
                                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                    return;
                                } catch (Exception e) {
                                    glasspane.arret();
                                    e.printStackTrace();
                                    GrecoSession.notifications.echec();
                                    JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                            } else {
                                try {
                                    GrecoServiceFactory.getEngagementService().MandatementModifier(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                            mandat.getMandatementID(), agentComp.getMatricule(), txtRIB.getText(), mandat.getNumeroOP(), mandat.getObjet(),
                                            listLiasseID, mandat.getDroits());
                                    nbMandat++;
//                                    GrecoSession.notifications.success();
//                                    GrecoOptionPane.showSuccessDialog(nbMandat + " Mandatement(s) modifié(s) avec succès ");
//                                    glasspane.arret();
                                } catch (Exception e) {
                                    glasspane.arret();
                                    e.printStackTrace();
                                    //currentLiquidationID = null;
                                    GrecoSession.notifications.echec();
                                    JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                    return;
                                }

                            }

                        }
                        GrecoSession.notifications.success();
                        loadMandatement();
                        GrecoOptionPane.showSuccessDialog(nbMandat + " mandatement(s) enregistré(s) avec succès ");
                        glasspane.arret();

                    } catch (Exception e) {
                    }
                }
            });

        }
    }

    private void loadMandatement() {
        listLiasse.clear();
        listMandatement.clear();

        List<Mandatement> list = GrecoServiceFactory.getEngagementService().MandatementFindByLiquidation(selectedLiquidation.getLiquidationID());
        if (list != null && !list.isEmpty()) {
            for (Mandatement m : list) {
                listMandatement.add(m);
            }
        } else {
            //chargement des pieces
            List<Liasse> liasses = GrecoServiceFactory.getEngagementService().getLiasseByEngagement(selectedLiquidation.getEngagementID());
            if (liasses != null) {
                for (Liasse l : liasses) {
                    listLiasse.add(l);
                }
            }
        }
//        if (currentEngagement != null) {
//            agentComp.setMatricule(currentMandatement.getOrdonnateur());
//            try {
//                txtRIB.setText(currentMandatement.getRib());
//            } catch (Exception e) {
//            }
//        }

    }

    private void supprimerLiquidation() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("enregistrement de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationSupprimer(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC, selectedLiquidation.getLiquidationID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Cette Liquidation a bien ete supprime de la liste ");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA SUPPRESSION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void validerLiquidation() {
        ((CardLayout) pDetails.getLayout()).show(pDetails, "validation");
    }

    private void disableComponents() {
        txtMontantIR.setEditable(false);
        txtMontantNAP.setEditable(false);
        txtMontantRG.setEditable(false);
        txtMontantTVA.setEditable(false);
    }

    private void enableComponents() {
        txtMontantIR.setEditable(true);
        txtMontantNAP.setEditable(true);
        txtMontantRG.setEditable(true);
        txtMontantTVA.setEditable(true);
    }

    private void afficherCout() {
        try {
//            btnTTC.setText(txtMontant.getText());
        } catch (Exception e) {
        }
    }

    public List<Liasse> getListLiasse() {
        return listLiasse;
    }

    public void setListLiasse(List<Liasse> listLiasse) {
        this.listLiasse = listLiasse;
    }

    public Liquidation getSelectedLiquidation() {
        return selectedLiquidation;
    }

    public void setSelectedLiquidation(Liquidation selectedLiquidation) {
        this.selectedLiquidation = selectedLiquidation;
    }

    public List<Mandatement> getListMandatement() {
        return listMandatement;
    }

    public void setListMandatement(List<Mandatement> listMandatement) {
        this.listMandatement = listMandatement;
    }

    public Mandatement getSelectedMandatement() {
        return selectedMandatement;
    }

    public void setSelectedMandatement(Mandatement selectedMandatement) {
        this.selectedMandatement = selectedMandatement;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.ButtonGroup benefGroup;
    private cm.eusoworks.tools.ui.GButton btnAction;
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnOPAjouter;
    private cm.eusoworks.tools.ui.GButton btnOPImprimer;
    private cm.eusoworks.tools.ui.GButton btnOPSupprimer;
    private javax.swing.JCheckBox chkCocherTous;
    private org.jdesktop.swingx.JXDatePicker dtpDateMandatement;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblType;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel panelInfos;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JTable tblOrdrePaiement;
    private javax.swing.JTable tblPieces;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtMontantIR;
    private javax.swing.JFormattedTextField txtMontantNAP;
    private javax.swing.JFormattedTextField txtMontantRG;
    private javax.swing.JFormattedTextField txtMontantTVA;
    private javax.swing.JFormattedTextField txtMontantTaxes;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JFormattedTextField txtRIB;
    private javax.swing.JTextField txtReference;
    private javax.swing.ButtonGroup validGroup;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
