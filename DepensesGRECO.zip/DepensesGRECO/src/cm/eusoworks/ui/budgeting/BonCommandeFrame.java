/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.enumeration.TypeDossier;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueStructureBCA;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.renderer.ListVueStructureBCARenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import com.siicore.util.StringUtil;
import java.awt.Cursor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class BonCommandeFrame extends javax.swing.JFrame {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Bca> listBCA = ObservableCollections.observableList(new ArrayList<Bca>());
    Bca currentBCA = null;
    String selectedStructureID;
    List<VueStructureBCA> list;
    VueStructureBCA oldSelected;
    GrecoReports fonctions = new GrecoReports();
    EngagementPipeImportDialog dialog = null;

    public BonCommandeFrame() {
        initComponents();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Traitement des Bons de Commande Administratif (BCA)  ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        setLocationRelativeTo(null);
        loadOrganisations();
        loadExercicesBudgetisation();
        me = this;
        btnReserver.setVisible(false);
        btnAnnulerReserver.setVisible(false);
    }

    private void initBcaUI() {
        String vide = "***";
        btnReserver.setVisible(false);
        btnAnnulerReserver.setVisible(false);
        if (currentBCA == null) {
            lblReference.setText(vide);
            lblDateDerniereModif.setText(vide);
            lblUser.setText(vide);
            lblPrestataire.setText(vide);
            lblMontant.setText(vide);
            lblObjet.setText(vide);
            btnImprimer.setVisible(false);
        } else {
            lblReference.setText(currentBCA.getReference());
            lblDateDerniereModif.setText(currentBCA.getLastUpdate().toString());
            lblUser.setText(currentBCA.getUserUpdate());
            lblPrestataire.setText(currentBCA.getFournisseur());
            try {
                lblMontant.setText(currentBCA.getMontantTTC().toString());
            } catch (Exception e) {
            }
            lblObjet.setText(currentBCA.getObjet());
            btnImprimer.setVisible(true);
            if (currentBCA.getEtat() == EtatDossier.enregistre || currentBCA.getEtat() == EtatDossier.modifie) {
                btnReserver.setVisible(true);
            } else if (currentBCA.getEtat() == EtatDossier.reserve || currentBCA.getEtat() == EtatDossier.reservation_annule) {
                btnAnnulerReserver.setVisible(true);
            }
        }
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'exercice budgétaire");
            return false;
        }

        return true;
    }

    public List<Bca> getListBCA() {
        return listBCA;
    }

    public void setListBCA(List<Bca> listBCA) {
        this.listBCA = listBCA;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jLabel2 = new javax.swing.JLabel();
        lblDateDerniereModif = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        lblUser = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        splitpane = new javax.swing.JSplitPane();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListBCA = new javax.swing.JList();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableBCA = new javax.swing.JTable();
        pDetailBCA = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        lblReference = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        lblPrestataire = new javax.swing.JLabel();
        lblMontant = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        lblObjet = new javax.swing.JLabel();
        btnImprimer = new javax.swing.JButton();
        cboModele = new javax.swing.JComboBox<>();
        btnProforma = new javax.swing.JButton();
        btnReserver = new cm.eusoworks.tools.ui.GButton();
        btnAnnulerReserver = new cm.eusoworks.tools.ui.GButton();
        pBouton = new javax.swing.JPanel();
        btnNouveau = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        btnImportFromFile = new cm.eusoworks.tools.ui.GButton();

        jLabel2.setText("Dernière modification : ");

        lblDateDerniereModif.setText("***");

        jLabel3.setText("par : ");

        lblUser.setText("***");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Outil de montage des bons de commande administratif");

        jPanel2.setBackground(new java.awt.Color(249, 249, 249));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboOrganisation, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(784, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        getContentPane().add(jPanel2, java.awt.BorderLayout.NORTH);

        splitpane.setDividerLocation(250);

        jListBCA.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jListBCA.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListBCA.setCellRenderer(new ListVueStructureBCARenderer());
        jListBCA.setSelectionBackground(new java.awt.Color(153, 204, 255));
        jListBCA.setSelectionForeground(new java.awt.Color(0, 102, 255));
        jListBCA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListBCAMouseClicked(evt);
            }
        });
        jListBCA.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jListBCAValueChanged(evt);
            }
        });
        jScrollPane2.setViewportView(jListBCA);

        splitpane.setLeftComponent(jScrollPane2);

        jPanel1.setLayout(new java.awt.BorderLayout());

        tableBCA.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        tableBCA.setGridColor(new java.awt.Color(249, 249, 249));
        tableBCA.setRowHeight(30);
        tableBCA.setSelectionBackground(new java.awt.Color(208, 217, 230));
        tableBCA.setSelectionForeground(new java.awt.Color(105, 128, 151));
        tableBCA.setShowGrid(true);
        tableBCA.setShowVerticalLines(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listBCA}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableBCA);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${fournisseur}"));
        columnBinding.setColumnName("Fournisseur");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantTTC}"));
        columnBinding.setColumnName("Montant TTC");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${tauxTVA}"));
        columnBinding.setColumnName("Taux TVA");
        columnBinding.setColumnClass(Float.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${tauxIR}"));
        columnBinding.setColumnName("Taux IR");
        columnBinding.setColumnClass(Float.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${reference}"));
        columnBinding.setColumnName("Reference");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        tableBCA.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableBCAMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tableBCA);
        if (tableBCA.getColumnModel().getColumnCount() > 0) {
            tableBCA.getColumnModel().getColumn(0).setPreferredWidth(400);
        }

        jPanel1.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pDetailBCA.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel1.setText("Réf. : ");

        lblReference.setText("***");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel4.setText("Prestataire : ");

        jLabel5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel5.setText("MONTANT TTC");

        lblPrestataire.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblPrestataire.setText("***+");

        lblMontant.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblMontant.setText("***");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel6.setText("Objet : ");

        lblObjet.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        lblObjet.setText("***");

        btnImprimer.setText("Imprimer");
        btnImprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimerActionPerformed(evt);
            }
        });

        cboModele.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Modèle FST", "Modèle standard 1 ", "Modèle standard 2" }));

        btnProforma.setText("PROFORMA");
        btnProforma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProformaActionPerformed(evt);
            }
        });

        btnReserver.setText("Réserver");
        btnReserver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReserverActionPerformed(evt);
            }
        });

        btnAnnulerReserver.setText("Annuler réservation");
        btnAnnulerReserver.setCouleur(1);
        btnAnnulerReserver.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerReserverActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pDetailBCALayout = new javax.swing.GroupLayout(pDetailBCA);
        pDetailBCA.setLayout(pDetailBCALayout);
        pDetailBCALayout.setHorizontalGroup(
            pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDetailBCALayout.createSequentialGroup()
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 47, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblReference, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblPrestataire, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(104, 104, 104)
                .addComponent(btnImprimer, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(6, 6, 6)
                .addComponent(cboModele, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(pDetailBCALayout.createSequentialGroup()
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(6, 6, 6)
                        .addComponent(lblMontant, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(51, 51, 51)
                        .addComponent(lblObjet, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(171, 171, 171)
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnProforma, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pDetailBCALayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnReserver, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnAnnulerReserver, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pDetailBCALayout.setVerticalGroup(
            pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDetailBCALayout.createSequentialGroup()
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel1)
                        .addGap(9, 9, 9)
                        .addComponent(jLabel4))
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addComponent(lblReference)
                        .addGap(6, 6, 6)
                        .addComponent(lblPrestataire, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnImprimer))
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(cboModele, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(12, 12, 12)
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addComponent(jLabel5))
                    .addComponent(lblMontant, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnProforma))
                .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6)
                            .addComponent(lblObjet)))
                    .addGroup(pDetailBCALayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(pDetailBCALayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnReserver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnAnnulerReserver, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(57, Short.MAX_VALUE))
        );

        jPanel1.add(pDetailBCA, java.awt.BorderLayout.SOUTH);

        pBouton.setBackground(new java.awt.Color(204, 204, 204));

        btnNouveau.setText("Nouveau BCA ...");
        btnNouveau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNouveauActionPerformed(evt);
            }
        });

        btnSupprimer.setText("Supprimer ");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });

        btnImportFromFile.setText("Importer à partir de la file ");
        btnImportFromFile.setCouleur(4);
        btnImportFromFile.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImportFromFileActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pBoutonLayout = new javax.swing.GroupLayout(pBouton);
        pBouton.setLayout(pBoutonLayout);
        pBoutonLayout.setHorizontalGroup(
            pBoutonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pBoutonLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(btnImportFromFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(402, 402, 402)
                .addComponent(btnNouveau)
                .addGap(5, 5, 5)
                .addComponent(btnSupprimer))
        );
        pBoutonLayout.setVerticalGroup(
            pBoutonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pBoutonLayout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addGroup(pBoutonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pBoutonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnNouveau)
                        .addComponent(btnImportFromFile, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnSupprimer)))
        );

        jPanel1.add(pBouton, java.awt.BorderLayout.NORTH);

        splitpane.setRightComponent(jPanel1);

        getContentPane().add(splitpane, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNouveauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNouveauActionPerformed
        // TODO add your handling code here:
        final Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            return;
        }
        final Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            return;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    BonCommandeNewDialog frame = new BonCommandeNewDialog(me, true, e.getMillesime(), o.getOrganisationID(), null);
                    frame.setVisible(true);
                    loadStructureBCA();
                } catch (Exception e) {
                }
            }
        });
    }//GEN-LAST:event_btnNouveauActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
            if (e != null) {
                loadStructureBCA();
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }

            if (o != null) {
                loadStructureBCA();
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void jListBCAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListBCAMouseClicked
        // TODO add your handling code here:
        VueStructureBCA v = null;
        try {
            v = (VueStructureBCA) jListBCA.getSelectedValue();

        } catch (Exception exx) {
            v = null;
        }
        if (v != null) {
            oldSelected = v;
            selectedStructureID = v.getStructureID();
            listBCA.clear();
            currentBCA = null;
            initBcaUI();

            List<Bca> l = new ArrayList<>();
            try {
                Exercice e = (Exercice) cboExercice.getSelectedItem();
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                l = GrecoServiceFactory.getBonCommandeService().getBCAByStructure(e.getMillesime(),
                        o.getOrganisationID(), v.getStructureID(), v.getEtat(), "1");
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            if (l != null && !l.isEmpty()) {
                for (Bca bca : l) {
                    listBCA.add(bca);
                }

            }
        }
    }//GEN-LAST:event_jListBCAMouseClicked

    private void tableBCAMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableBCAMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            int r = tableBCA.getSelectedRow();
            final Bca b = (Bca) listBCA.get(r);

            final Organisation o = (Organisation) cboOrganisation.getSelectedItem();
            if (o == null) {
                return;
            }
            final Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e == null) {
                return;
            }

            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        BonCommandeNewDialog frame = new BonCommandeNewDialog(me, true, e.getMillesime(), o.getOrganisationID(), b);
                        frame.setVisible(true);
                        loadStructureBCA();
                        for (int i = 0; i < list.size(); i++) {
                            VueStructureBCA v = list.get(i);
                            if (v.getStructureID().equalsIgnoreCase(selectedStructureID)) {
                                jListBCA.setSelectedIndex(i);
                                break;
                            }
                        }
                        initBcaUI();
                    } catch (Exception e) {
                    }
                }
            });
        } else {
            int r = tableBCA.getSelectedRow();
            Bca b = null;
            try {
                b = (Bca) listBCA.get(r);
            } catch (Exception e) {
                b = null;
            }
            if (b != null) {
                currentBCA = b;
                initBcaUI();
            }
        }
    }//GEN-LAST:event_tableBCAMouseClicked

    private void jListBCAValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jListBCAValueChanged
        // TODO add your handling code here:
        jListBCAMouseClicked(null);
    }//GEN-LAST:event_jListBCAValueChanged

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
//         int r = tableBCA.getSelectedRow();
        int[] rows = tableBCA.getSelectedRows();
        if (rows.length > 0) {
            int resg = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir supprimer les bons de commande selectionnes ? ",
                    "Suppression des BCA", JOptionPane.YES_NO_OPTION);
            if (resg == JOptionPane.YES_OPTION) {
                for (int i = 0; i < rows.length; i++) {
                    int r = rows[i];
                    if (r != -1) {
                        final Bca b = (Bca) listBCA.get(r);
                        if (b.getEtat() == EtatDossier.enregistre) {
                            int res = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir supprimer le bon de commande " + b.getReference() + "\n" + "[" + b.getFournisseur() + "]",
                                    "Suppression du BCA", JOptionPane.YES_NO_OPTION);
                            if (res == JOptionPane.YES_OPTION) {
                                try {
                                    GrecoServiceFactory.getBonCommandeService().supprimer(b.getBcaID(), GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                                    GrecoSession.notifications.success();
                                    JOptionPane.showMessageDialog(this, "BCA retiré du système  ");
                                    loadStructureBCA();
                                    currentBCA = null;
                                    initBcaUI();
                                    for (int j = 0; j < list.size(); j++) {
                                        VueStructureBCA v = list.get(j);
                                        if (v.getStructureID().equalsIgnoreCase(selectedStructureID)) {
                                            jListBCA.setSelectedIndex(j);
                                            break;
                                        }
                                    }
                                    initBcaUI();
                                } catch (GrecoException e) {
                                    GrecoSession.notifications.echec();
                                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                    return;
                                }
                            }
                        }

                    }
                }
            }

        } else {
            JOptionPane.showMessageDialog(this, "Vous n'avez pa sélectionné de BCA a supprimer");
        }

    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnImprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimerActionPerformed
        // TODO add your handling code here:
        int r = tableBCA.getSelectedRow();
        if (r != -1) {
            final Bca b = (Bca) listBCA.get(r);
            imprimer(b);
        }
    }//GEN-LAST:event_btnImprimerActionPerformed

    private void btnProformaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProformaActionPerformed
        // TODO add your handling code here:
        int r = tableBCA.getSelectedRow();
        if (r != -1) {
            final Bca b = (Bca) listBCA.get(r);
            proforma(b);
        }
    }//GEN-LAST:event_btnProformaActionPerformed

    private void btnReserverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReserverActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    int r = tableBCA.getSelectedRow();
                    if (r != -1) {
                        Bca b = (Bca) listBCA.get(r);
                        BonCommandeReservationDialog dialog = new BonCommandeReservationDialog(me, true, b);
                        dialog.setVisible(true);
                        loadStructureBCA();
                        for (VueStructureBCA v : list) {
                            if (v.getEtat() == oldSelected.getEtat()) {

                                if (v != null) {
                                    oldSelected = v;
                                    selectedStructureID = v.getStructureID();
                                    listBCA.clear();
                                    currentBCA = null;
                                    initBcaUI();

                                    List<Bca> l = new ArrayList<>();
                                    try {
                                        Exercice e = (Exercice) cboExercice.getSelectedItem();
                                        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                                        l = GrecoServiceFactory.getBonCommandeService().getBCAByStructure(e.getMillesime(),
                                                o.getOrganisationID(), v.getStructureID(), v.getEtat(), "1");
                                    } catch (Exception ex) {
                                        ex.printStackTrace();
                                    }
                                    if (l != null && !l.isEmpty()) {
                                        for (Bca bca : l) {
                                            listBCA.add(bca);
                                        }

                                    }
                                }

//                                jListBCA.setSelectedValue(v, true);
//                                jListBCAMouseClicked(null);
                                break;
                            }
                        }

                    } else {
                        GrecoOptionPane.showWarningDialog("Veuillez sélectionner un BCA SVP");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }//GEN-LAST:event_btnReserverActionPerformed

    private void btnAnnulerReserverActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerReserverActionPerformed
        // TODO add your handling code here:
        int r = tableBCA.getSelectedRow();
        if (r != -1) {
            final Bca b = (Bca) listBCA.get(r);
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sûr de vouloir annuler la réservervation des crédits sur ce contrat  " + b.getObjet());
            if (res == JOptionPane.YES_OPTION) {
                try {
                    String motif = "";
                    boolean annuler = false;
                    GrecoServiceFactory.getBonCommandeService().reservationBCAAnnuler(currentBCA.getBcaID(), annuler, motif, GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    GrecoSession.notifications.success();
                    loadStructureBCA();
                    currentBCA = null;
                } catch (Exception e) {
                    e.printStackTrace();
                    return;
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Vous n'avez pa sélectionné de contrat à annuler");
        }
    }//GEN-LAST:event_btnAnnulerReserverActionPerformed

    private void btnImportFromFileActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImportFromFileActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    String organisationID = null;
                    String millesime = null;
                    Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                    if (o != null) {
                        organisationID = o.getOrganisationID();
                        Exercice ex = (Exercice) cboExercice.getSelectedItem();
                        if (ex != null) {
                            millesime = ex.getMillesime();
                            if(dialog == null){
                                dialog = new EngagementPipeImportDialog(me, true, organisationID, millesime, TypeDossier.BON_COMMANDE);
                            }
                            dialog.setVisible(true);
                        } else {
                            GrecoOptionPane.showWarningDialog("Sélectionnez l'exercice budgétaire");
                        }

                    } else {
                        GrecoOptionPane.showWarningDialog("Sélectionnez l'organisation SVP");
                    }

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }//GEN-LAST:event_btnImportFromFileActionPerformed

    private void proforma(Bca b) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    BonCommandeProformaDialog dialog = new BonCommandeProformaDialog(me, true, b);
                    dialog.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void imprimer(final Bca b) {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueBCAReport> list = new ArrayList<>();
                            list = GrecoServiceFactory.getReportService().getBcaLignesReport(b.getBcaID());

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("logoEntete", mesImages.drapeauCroise());
                            parameters.put("user", Crypto.decrypt(GrecoSession.USER_CONNECTED.getLogin()) + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("montantEnLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, b.getMontantTTC()) + "  francs CFA");
                            parameters.put("contact", GrecoAppConfig.getOrgContact());
                            parameters.put("PARAM_DispositifFR", "Dispositif Technique de Gestion budgétaire et Comptable");
                            parameters.put("PARAM_DispositifUS", "FSTMANAGER");

                            if (b.getBudgetExploite().equals(BudgetType.ETAT_REPORT)) {
                                parameters.put("report", "[REPORT]");
                            } else {
                                parameters.put("report", "");
                            }

                            int i = cboModele.getSelectedIndex();
                            if (i == 0) {
                                JRHelper.viewReport(fonctions.bonCommandeAdministratifFST(), parameters, new JRBeanCollectionDataSource(list, false), null, null);
                            } else if (i == 1) {
                                JRHelper.viewReport(fonctions.bonCommandeAdministratif(), parameters, new JRBeanCollectionDataSource(list, false), null, null);
                            } else if (i == 2) {
                                JRHelper.viewReport(fonctions.bonCommandeAdministratifCCAA(), parameters, new JRBeanCollectionDataSource(list, false), null, null);
                            }

                        } catch (Exception ex) {
                            ex.printStackTrace();
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void loadStructureBCA() {
        jListBCA.removeAll();
        jListBCA.repaint();
        // vider le tableau des bca
        listBCA.clear();
        // vider le panneau de details
        initBcaUI();
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getBonCommandeService()
                    .getBCANumberByStructure(e.getMillesime(), o.getOrganisationID(), "1");
        } catch (Exception ex) {
        }
        if (list != null) {
            jListBCA.setListData(list.toArray());
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BonCommandeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BonCommandeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BonCommandeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BonCommandeFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BonCommandeFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAnnulerReserver;
    private cm.eusoworks.tools.ui.GButton btnImportFromFile;
    private javax.swing.JButton btnImprimer;
    private javax.swing.JButton btnNouveau;
    private javax.swing.JButton btnProforma;
    private cm.eusoworks.tools.ui.GButton btnReserver;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox<String> cboModele;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JList jListBCA;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblDateDerniereModif;
    private javax.swing.JLabel lblMontant;
    private javax.swing.JLabel lblObjet;
    private javax.swing.JLabel lblPrestataire;
    private javax.swing.JLabel lblReference;
    private javax.swing.JLabel lblUser;
    private javax.swing.JPanel pBouton;
    private javax.swing.JPanel pDetailBCA;
    private javax.swing.JSplitPane splitpane;
    private javax.swing.JTable tableBCA;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
