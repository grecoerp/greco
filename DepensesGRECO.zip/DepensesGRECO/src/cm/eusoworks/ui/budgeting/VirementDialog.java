/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.component.virement.ImputationEditor;
import cm.eusoworks.component.virement.ImputationRenderer;
import cm.eusoworks.component.virement.ImputationTableModel;
import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.DialogOpenMode;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.Virement;
import cm.eusoworks.entities.model.VirementTache;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.renderer.BooleanTableRenderer;
import cm.eusoworks.renderer.DecimalTableRenderer;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author macbookair
 */
public class VirementDialog extends GrecoTemplateDialog {

    /**
     * Creates new form NomenclatureDialog
     */
    String organisationID;
    String millesime;
    Virement currentVir = null;
    int modeOuverture;
    List<Virement> listVirement = ObservableCollections.observableList(new ArrayList<Virement>());
    Virement selectedVirement = null;
    private ImputationTableModel modeleTableDebit = null;
    private ImputationTableModel modeleTableCredit = null;
    public static int DEBIT = 1;
    public static int CREDIT = 2;
    GrecoReports fonctions = new GrecoReports();
    boolean edition = false;
    JFrame me;

    public VirementDialog(JFrame parent, boolean modal, int mode, boolean edition) {
        super(parent, modal);
        initComponents();
        this.modeOuverture = mode;
        this.edition = edition;
        me = parent;
        initTableDebit();
        initTableCredit();
        initMode();

        setResizable(true);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Gestion des virements de crédits  ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        loadOrganisations();
        loadExercicesBudgetisation();
//        pack();
        setPreferredSize(new Dimension(750, 660));
        setLocationRelativeTo(null);
    }

    public VirementDialog(JFrame parent, boolean modal, int mode) {
        this(parent, modal, mode, false);
    }

    private void initMode() {
        lblArreteFinal.setVisible(false);
        txtArreteFinal.setVisible(false);
        lblDateSignature.setVisible(false);
        dtpDateSignature.setVisible(false);
        btnPTA.setVisible(false);
        btnPTASelectLignes.setVisible(false);
        btnNewImputation.setVisible(false);

        if (this.modeOuverture < 0) {
            txtArrete.setEnabled(false);
            txtObjet.setEnabled(false);
            txtTitreOrdonnateur.setEnabled(false);
            ordonnateurComp.setEnabled(false);
            editeurModele.setEditable(false);
            lnlModifierVirement.setText("Consulter le virement");
            btnNewVirement.setVisible(false);
            btnAction.setVisible(false);
            btnActionRevert.setVisible(false);
        } else if (this.modeOuverture == DialogOpenMode.enregistre) {
            btnAction.setText("Enregistrer ");
            btnActionRevert.setText("Supprimmer ");
            btnPTA.setVisible(true);
            btnPTASelectLignes.setVisible(true);
            btnNewImputation.setVisible(true);
        } else if (this.modeOuverture == DialogOpenMode.reserve) {
            btnNewVirement.setVisible(false);
            lnlModifierVirement.setText("Réserver les crédits pour ce virement");
            btnAction.setText("Réservation de crédit ");
            btnActionRevert.setVisible(false);
        } else if (this.modeOuverture == DialogOpenMode.reservation_annule) {
            btnNewVirement.setVisible(false);
            lnlModifierVirement.setText("Annuler la Réservation de crédits pour ce virement");
            btnAction.setText("Annuler la Réservation ");
            btnActionRevert.setVisible(false);
        } else if (this.modeOuverture == DialogOpenMode.valide) {
            btnNewVirement.setVisible(false);
            lnlModifierVirement.setText("Accorder le visa budgétaire pour ce virement");
            btnAction.setText("Visa budgétaire OK ");
            btnActionRevert.setVisible(false);
            if (edition) {
                btnAction.setVisible(false);
            }
        } else if (this.modeOuverture == DialogOpenMode.valide_annule) {
            btnNewVirement.setVisible(false);
            lnlModifierVirement.setText("Annuler le visa budgétaire pour ce virement");
            btnAction.setText("Annuler le Visa budgétaire ");
            btnActionRevert.setVisible(false);
        } else if (this.modeOuverture == DialogOpenMode.transmiPourLiquidation) {
            btnNewVirement.setVisible(false);
            lnlModifierVirement.setText("Prise en compte de la signature de l'arrêté ");
            btnAction.setText("Valider le virement ");
            btnActionRevert.setVisible(false);
            lblArreteFinal.setVisible(true);
            txtArreteFinal.setVisible(true);
            lblDateSignature.setVisible(true);
            dtpDateSignature.setVisible(true);
        }
        if (this.modeOuverture > DialogOpenMode.enregistre) {
            txtArrete.setEnabled(false);
            txtObjet.setEnabled(false);
            txtTitreOrdonnateur.setEnabled(false);
            ordonnateurComp.setEnabled(false);
            editeurModele.setEditable(false);
        }
    }

    private void initTableDebit() {
        modeleTableDebit = new ImputationTableModel(this, DEBIT, modeOuverture);
        tableDebit.setModel(modeleTableDebit);
        tableDebit.setRowHeight(25);
        tableDebit.setShowGrid(true);
        scrollTable.setViewportView(tableDebit);
        if (tableDebit.getColumnModel().getColumnCount() > 0) {
            tableDebit.getColumnModel().getColumn(0).setResizable(false);
            tableDebit.getColumnModel().getColumn(0).setWidth(60);
            tableDebit.getColumnModel().getColumn(1).setResizable(false);
            tableDebit.getColumnModel().getColumn(1).setWidth(10);
            tableDebit.getColumnModel().getColumn(2).setResizable(false);
            tableDebit.getColumnModel().getColumn(2).setWidth(10);
            tableDebit.getColumnModel().getColumn(3).setResizable(false);
            tableDebit.getColumnModel().getColumn(3).setPreferredWidth(200);
            tableDebit.getColumnModel().getColumn(0).setResizable(false);
            tableDebit.getColumnModel().getColumn(4).setWidth(40);
            tableDebit.getColumnModel().getColumn(5).setResizable(false);
            tableDebit.getColumnModel().getColumn(5).setWidth(40);
        }
        tableDebit.getColumnModel().getColumn(0).setCellEditor(new ImputationEditor(null));
        tableDebit.getColumnModel().getColumn(4).setCellRenderer(new ImputationRenderer());
        tableDebit.getColumnModel().getColumn(5).setCellRenderer(new ImputationRenderer());

        tableDebit.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int[] selectedRow = tableDebit.getSelectedRows();
                if (selectedRow.length == 1) {
                    int r = selectedRow[0];
                    String ref = (String) tableDebit.getValueAt(r, 0);
                    if (ref != null && !ref.isEmpty()) {
                        tableDebit.getSelectionModel().setSelectionInterval(r, r);
                        tableDebit.getColumnModel().getSelectionModel().setSelectionInterval(2, 2);
                    }
                }
            }
        }
        );

    }

    private void initTableCredit() {
        modeleTableCredit = new ImputationTableModel(this, CREDIT, modeOuverture);
        tableCredit.setModel(modeleTableCredit);
        tableCredit.setRowHeight(25);
        tableCredit.setShowGrid(true);
        scrollTable1.setViewportView(tableCredit);
        if (tableCredit.getColumnModel().getColumnCount() > 0) {
            tableCredit.getColumnModel().getColumn(0).setResizable(false);
            tableCredit.getColumnModel().getColumn(0).setWidth(60);
            tableCredit.getColumnModel().getColumn(1).setResizable(false);
            tableCredit.getColumnModel().getColumn(1).setWidth(10);
            tableCredit.getColumnModel().getColumn(2).setResizable(false);
            tableCredit.getColumnModel().getColumn(2).setWidth(10);
            tableCredit.getColumnModel().getColumn(3).setResizable(false);
            tableCredit.getColumnModel().getColumn(3).setPreferredWidth(200);
            tableCredit.getColumnModel().getColumn(0).setResizable(false);
            tableCredit.getColumnModel().getColumn(4).setWidth(40);
            tableCredit.getColumnModel().getColumn(5).setResizable(false);
            tableCredit.getColumnModel().getColumn(5).setWidth(40);
        }
        tableCredit.getColumnModel().getColumn(0).setCellEditor(new ImputationEditor(null));
        tableCredit.getColumnModel().getColumn(4).setCellRenderer(new ImputationRenderer());
        tableCredit.getColumnModel().getColumn(5).setCellRenderer(new ImputationRenderer());

        tableCredit.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int[] selectedRow = tableCredit.getSelectedRows();
                if (selectedRow.length == 1) {
                    int r = selectedRow[0];
                    String ref = (String) tableCredit.getValueAt(r, 0);
                    if (ref != null && !ref.isEmpty()) {
                        tableCredit.getSelectionModel().setSelectionInterval(r, r);
                        tableCredit.getColumnModel().getSelectionModel().setSelectionInterval(2, 2);
                    }
                }
            }
        }
        );
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    private void loadBudget() {
        try {
            Organisation o = (Organisation) cboOrganisation.getSelectedItem();
            if (o != null) {
                Exercice e = (Exercice) cboExercice.getSelectedItem();
                if (e != null) {
                    List<PrepaBudget> list = GrecoServiceFactory.getExerciceService().budgetGetByMillesimeOnLine(o.getOrganisationID(),
                            e.getMillesime(), false);
                    if (list != null && !list.isEmpty()) {
                        if (list.size() > 1) {
                            list.add(null);
                        }
                        cboBudget.setModel(new DefaultComboBoxModel(list.toArray()));
                        if (list.size() > 1) {
                            cboBudget.setSelectedIndex(-1);
                        } else {
                            cboBudget.setSelectedIndex(0);
                        }

                    }
                }
            }
        } catch (Exception e) {
        }

    }

    public VirementDialog(JFrame parent, boolean modal, String organisationID, String millesime, Virement modele) {
        this(parent, modal, DialogOpenMode.enregistre);
        currentVir = modele;
        initModeleUI();
    }

    private void initModeleUI() {
        modeleTableDebit.resetModel();
        modeleTableCredit.resetModel();

        if (currentVir == null) {
            txtArrete.setText("____________/");
            txtObjet.setText("");
            ordonnateurComp.setMatricule(null);
            txtTitreOrdonnateur.setText("");
            editeurModele.setText("");
            lblNumVirement.setText("");
            txtDebit.setValue(0);
            txtCredit.setValue(0);
            btnEdition.setVisible(false);
        } else {
            txtArrete.setText(currentVir.getReference());
            txtObjet.setText(currentVir.getObjet());
            ordonnateurComp.setMatricule(currentVir.getGestionnaire());
            txtTitreOrdonnateur.setText(currentVir.getTitre());
            editeurModele.setText(currentVir.getContenu());
            lblNumVirement.setText("N° " + currentVir.getNumVirement());
            // chargement des taches du virement
            List<VirementTache> listImputations = GrecoServiceFactory.getVirementService().getListTache(currentVir.getVirementID());
            if (listImputations != null) {
                if (listImputations.size() > 0) {
                    List<VirementTache> listDebits = new ArrayList<>();
                    List<VirementTache> listCredits = new ArrayList<>();

                    for (VirementTache v : listImputations) {
                        if (v.getDebit().compareTo(BigDecimal.ZERO) == 0) {
                            v.setMontant(v.getCredit());
                            listCredits.add(v);
                        } else {
                            v.setMontant(v.getDebit());
                            listDebits.add(v);
                        }
                    }
                    modeleTableDebit.setDataList(listDebits);
                    modeleTableCredit.setDataList(listCredits);

                }
            }
            btnEdition.setVisible(true);

            //mise a jour des volumes debit et credit 
            modeleTableCredit.calculerSomme();
            modeleTableDebit.calculerSomme();

        }
    }

    private boolean controlData() {
        boolean res = true;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        PrepaBudget p = (PrepaBudget) cboBudget.getSelectedItem();

        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisation");
            return false;
        }
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire ");
            return false;
        }
        if (txtObjet.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir l'objet du virement ");
            return false;
        }
        if (ordonnateurComp.getMatricule() == null) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le matricule de l'ordonnateur");
            return false;
        }
        if (txtTitreOrdonnateur.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le titre de l'ordonnateur  du virement ");
            return false;
        }
        if (editeurModele.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le modèle de virement à enregistrer");
            return false;
        }
        return res;
    }

    private boolean controlDataSignature() {
        boolean res = true;

        if (txtArreteFinal.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le numéro de l'arrêté");
            return false;
        }
        if (dtpDateSignature.getDate() == null) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir la date de signature de l'arrêté");
            return false;
        }
        return res;
    }

    private void remplirModele() {
        currentVir.setReference(txtArrete.getText());
        currentVir.setObjet(txtObjet.getText());
        currentVir.setGestionnaire(ordonnateurComp.getMatricule());
        currentVir.setTitre(txtTitreOrdonnateur.getText());
        currentVir.setContenu(editeurModele.getText());

        currentVir.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentVir.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        PrepaBudget p = (PrepaBudget) cboBudget.getSelectedItem();
        currentVir.setMillesime(e.getMillesime());
        currentVir.setOrganisationID(o.getOrganisationID());
        currentVir.setBudgetID(p == null ? null : p.getBudgetID());

        // liste details
        Number debit = (Number) txtDebit.getValue();
        Number credit = (Number) txtCredit.getValue();
        currentVir.setDebit(BigDecimal.valueOf(debit.longValue()));
        currentVir.setCredit(BigDecimal.valueOf(credit.longValue()));
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        buttonGroup1 = new javax.swing.ButtonGroup();
        pListModele = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        cboBudget = new javax.swing.JComboBox();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        scrollTable2 = new javax.swing.JScrollPane();
        tablelisteVirement = new org.jdesktop.swingx.JXTable();
        jPanel2 = new javax.swing.JPanel();
        btnNewVirement = new cm.eusoworks.tools.ui.GButton();
        lnlModifierVirement = new org.jdesktop.swingx.JXHyperlink();
        pDetails = new javax.swing.JPanel();
        panelVolume = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtDebit = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        txtCredit = new javax.swing.JFormattedTextField();
        btnListe = new cm.eusoworks.tools.ui.GButton();
        tabbedPaneVirement = new javax.swing.JTabbedPane();
        panelObjet = new javax.swing.JPanel();
        jSplitPane1 = new javax.swing.JSplitPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtArrete = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        ordonnateurComp = new cm.eusoworks.component.AgentComponent();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtTitreOrdonnateur = new javax.swing.JTextArea();
        lblNumVirement = new javax.swing.JLabel();
        lblArreteFinal = new javax.swing.JLabel();
        txtArreteFinal = new javax.swing.JTextField();
        dtpDateSignature = new org.jdesktop.swingx.JXDatePicker();
        lblDateSignature = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        editeurModele = new javax.swing.JTextPane();
        panelLignes = new javax.swing.JPanel();
        splitImputation = new javax.swing.JSplitPane();
        panelDebit = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        scrollTable = new javax.swing.JScrollPane();
        tableDebit = new org.jdesktop.swingx.JXTable();
        jPanel5 = new javax.swing.JPanel();
        btnPTASelectLignes = new cm.eusoworks.tools.ui.GButton();
        panelCredit = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        scrollTable1 = new javax.swing.JScrollPane();
        tableCredit = new org.jdesktop.swingx.JXTable();
        jPanel4 = new javax.swing.JPanel();
        btnNewImputation = new cm.eusoworks.tools.ui.GButton();
        btnPTA = new cm.eusoworks.tools.ui.GButton();
        panelBouton = new javax.swing.JPanel();
        btnAction = new cm.eusoworks.tools.ui.GButton();
        btnActionRevert = new cm.eusoworks.tools.ui.GButton();
        btnEdition = new cm.eusoworks.tools.ui.GButton();

        getContentPane().setLayout(new java.awt.CardLayout());

        pListModele.setLayout(new java.awt.BorderLayout(0, 10));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel8.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel9.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel9.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        jLabel10.setText("Budget : ");

        cboBudget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboBudgetActionPerformed(evt);
            }
        });

        btnRechercher.setText("Rechercher ");
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cboOrganisation, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(758, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(cboBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 495, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnRechercher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(283, 283, 283))))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboBudget, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRechercher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pListModele.add(jPanel3, java.awt.BorderLayout.PAGE_START);

        tablelisteVirement.setColumnSelectionAllowed(true);
        tablelisteVirement.setRowHeight(25);
        tablelisteVirement.setShowGrid(true);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listVirement}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tablelisteVirement);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numVirement}"));
        columnBinding.setColumnName("N° VIR");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${reference}"));
        columnBinding.setColumnName("ARRETE");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${objet}"));
        columnBinding.setColumnName("OBJET");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${debit}"));
        columnBinding.setColumnName("DEBIT");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${credit}"));
        columnBinding.setColumnName("CREDIT");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${reserve}"));
        columnBinding.setColumnName("Réservé");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${receptionCF}"));
        columnBinding.setColumnName("Reception CF");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${visaBudgetaire}"));
        columnBinding.setColumnName("Visa Budgétaire");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${signe}"));
        columnBinding.setColumnName("Signé");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        tablelisteVirement.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tablelisteVirementMouseClicked(evt);
            }
        });
        tablelisteVirement.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tablelisteVirementKeyReleased(evt);
            }
        });
        scrollTable2.setViewportView(tablelisteVirement);
        tablelisteVirement.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);
        if (tablelisteVirement.getColumnModel().getColumnCount() > 0) {
            tablelisteVirement.getColumnModel().getColumn(0).setPreferredWidth(25);
            tablelisteVirement.getColumnModel().getColumn(3).setPreferredWidth(40);
            tablelisteVirement.getColumnModel().getColumn(3).setCellRenderer(new DecimalTableRenderer());
            tablelisteVirement.getColumnModel().getColumn(4).setPreferredWidth(40);
            tablelisteVirement.getColumnModel().getColumn(4).setCellRenderer(new DecimalTableRenderer());
            tablelisteVirement.getColumnModel().getColumn(5).setPreferredWidth(10);
            tablelisteVirement.getColumnModel().getColumn(5).setCellRenderer(new BooleanTableRenderer());
            tablelisteVirement.getColumnModel().getColumn(6).setPreferredWidth(10);
            tablelisteVirement.getColumnModel().getColumn(6).setCellRenderer(new BooleanTableRenderer());
            tablelisteVirement.getColumnModel().getColumn(7).setCellRenderer(new BooleanTableRenderer());
            tablelisteVirement.getColumnModel().getColumn(8).setPreferredWidth(10);
            tablelisteVirement.getColumnModel().getColumn(8).setCellRenderer(new BooleanTableRenderer());
        }

        pListModele.add(scrollTable2, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 40, 5));

        btnNewVirement.setText("Nouveau projet de virement");
        btnNewVirement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewVirementActionPerformed(evt);
            }
        });
        jPanel2.add(btnNewVirement);

        lnlModifierVirement.setText("Modifier le virement sélectionné ");
        lnlModifierVirement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnlModifierVirementActionPerformed(evt);
            }
        });
        jPanel2.add(lnlModifierVirement);

        pListModele.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pListModele, "list");

        pDetails.setLayout(new java.awt.BorderLayout(0, 10));

        panelVolume.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 0, 204));
        jLabel1.setText("Volume débit : ");

        txtDebit.setEditable(false);
        txtDebit.setForeground(new java.awt.Color(153, 0, 204));
        txtDebit.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtDebit.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 153, 0));
        jLabel2.setText("Volume Crédit : ");

        txtCredit.setEditable(false);
        txtCredit.setForeground(new java.awt.Color(255, 153, 0));
        txtCredit.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtCredit.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        btnListe.setText("<<<");
        btnListe.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListeActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelVolumeLayout = new javax.swing.GroupLayout(panelVolume);
        panelVolume.setLayout(panelVolumeLayout);
        panelVolumeLayout.setHorizontalGroup(
            panelVolumeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelVolumeLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnListe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 127, Short.MAX_VALUE)
                .addComponent(jLabel1)
                .addGap(5, 5, 5)
                .addComponent(txtDebit, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(147, 147, 147)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(txtCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 237, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(67, 67, 67))
        );
        panelVolumeLayout.setVerticalGroup(
            panelVolumeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(panelVolumeLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(panelVolumeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(panelVolumeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnListe, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelVolumeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtDebit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtCredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        pDetails.add(panelVolume, java.awt.BorderLayout.PAGE_START);

        tabbedPaneVirement.setBackground(new java.awt.Color(255, 255, 255));

        panelObjet.setLayout(new java.awt.BorderLayout());

        jSplitPane1.setMinimumSize(new java.awt.Dimension(450, 111));

        jPanel1.setBackground(new java.awt.Color(252, 252, 252));

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel6.setText("Objet : ");

        jLabel7.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel7.setText("Ordonnateur : ");

        txtArrete.setText("ARRETE N° _______________/");
        txtArrete.setToolTipText("");

        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        txtObjet.setLineWrap(true);
        txtObjet.setRows(5);
        jScrollPane2.setViewportView(txtObjet);

        jLabel11.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel11.setText("Titre de l'Ordonnateur  ");

        txtTitreOrdonnateur.setColumns(20);
        txtTitreOrdonnateur.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        txtTitreOrdonnateur.setLineWrap(true);
        txtTitreOrdonnateur.setRows(3);
        jScrollPane3.setViewportView(txtTitreOrdonnateur);

        lblNumVirement.setFont(new java.awt.Font("Arial Black", 1, 24)); // NOI18N
        lblNumVirement.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);

        lblArreteFinal.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblArreteFinal.setText("Arrêté N° :");

        lblDateSignature.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblDateSignature.setText("Date de signature de l'arrêté ");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 68, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ordonnateurComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 208, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtArreteFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 318, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(dtpDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lblNumVirement, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(98, 98, 98)
                        .addComponent(lblArreteFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtArrete, javax.swing.GroupLayout.PREFERRED_SIZE, 325, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(txtArrete, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(ordonnateurComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblNumVirement, javax.swing.GroupLayout.PREFERRED_SIZE, 44, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblArreteFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(txtArreteFinal, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dtpDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(76, 76, 76))
        );

        jSplitPane1.setLeftComponent(jPanel1);

        jScrollPane1.setBorder(javax.swing.BorderFactory.createTitledBorder("Zone de saisie du contenu de l'àrrêté"));
        jScrollPane1.setViewportView(editeurModele);

        jSplitPane1.setRightComponent(jScrollPane1);

        panelObjet.add(jSplitPane1, java.awt.BorderLayout.PAGE_START);

        tabbedPaneVirement.addTab("Contenu de l'arrêté", panelObjet);

        panelLignes.setLayout(new java.awt.BorderLayout());

        splitImputation.setDividerLocation(280);
        splitImputation.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);
        splitImputation.setPreferredSize(new java.awt.Dimension(400, 370));

        panelDebit.setLayout(new java.awt.BorderLayout());

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 204));
        jLabel3.setText("Ligne(s) Débitrice(s)  : ");
        panelDebit.add(jLabel3, java.awt.BorderLayout.NORTH);

        tableDebit.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "REFERENCE", "DESIGNATION", "QTE", "PRIX UNIT.", "PRIX TOTAL", "REMISE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableDebit.setColumnSelectionAllowed(true);
        tableDebit.setRowHeight(25);
        tableDebit.setShowGrid(true);
        tableDebit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableDebitKeyReleased(evt);
            }
        });
        scrollTable.setViewportView(tableDebit);
        tableDebit.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        panelDebit.add(scrollTable, java.awt.BorderLayout.CENTER);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnPTASelectLignes.setText("Choisir dans le PTA");
        btnPTASelectLignes.setCouleur(6);
        btnPTASelectLignes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPTASelectLignesActionPerformed(evt);
            }
        });
        jPanel5.add(btnPTASelectLignes);

        panelDebit.add(jPanel5, java.awt.BorderLayout.SOUTH);

        splitImputation.setLeftComponent(panelDebit);

        panelCredit.setLayout(new java.awt.BorderLayout());

        jLabel4.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 153, 0));
        jLabel4.setText("Ligne(s) Créditrice(s)  : ");
        panelCredit.add(jLabel4, java.awt.BorderLayout.NORTH);

        tableCredit.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "REFERENCE", "DESIGNATION", "QTE", "PRIX UNIT.", "PRIX TOTAL", "REMISE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableCredit.setColumnSelectionAllowed(true);
        tableCredit.setRowHeight(25);
        tableCredit.setShowGrid(true);
        tableCredit.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableCreditKeyReleased(evt);
            }
        });
        scrollTable1.setViewportView(tableCredit);

        panelCredit.add(scrollTable1, java.awt.BorderLayout.CENTER);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 10, 5));

        btnNewImputation.setText("Créer une nouvelle ligne");
        btnNewImputation.setCouleur(6);
        btnNewImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewImputationActionPerformed(evt);
            }
        });
        jPanel4.add(btnNewImputation);

        btnPTA.setText("Consulter le PTA ");
        btnPTA.setCouleur(6);
        btnPTA.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPTAActionPerformed(evt);
            }
        });
        jPanel4.add(btnPTA);

        panelCredit.add(jPanel4, java.awt.BorderLayout.SOUTH);

        splitImputation.setRightComponent(panelCredit);

        panelLignes.add(splitImputation, java.awt.BorderLayout.CENTER);

        tabbedPaneVirement.addTab("Lignes d'Imputations", panelLignes);

        pDetails.add(tabbedPaneVirement, java.awt.BorderLayout.CENTER);

        panelBouton.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 30, 5));

        btnAction.setText("Enregistrer ");
        btnAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionActionPerformed(evt);
            }
        });
        panelBouton.add(btnAction);

        btnActionRevert.setText("Supprimer");
        btnActionRevert.setCouleur(1);
        btnActionRevert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionRevertActionPerformed(evt);
            }
        });
        panelBouton.add(btnActionRevert);

        btnEdition.setText("Edition du Projet de Virement ");
        btnEdition.setCouleur(4);
        btnEdition.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditionActionPerformed(evt);
            }
        });
        panelBouton.add(btnEdition);

        pDetails.add(panelBouton, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetails, "details");

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tableDebitKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableDebitKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_TAB) {
            ajouterLigneDebit();
        } else if (evt.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            deleteLigneDebit();
        }
    }//GEN-LAST:event_tableDebitKeyReleased

    private void tableCreditKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableCreditKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_TAB) {
            ajouterLigneCredit();
        } else if (evt.getKeyCode() == KeyEvent.VK_DELETE) {
            deleteLigneCredit();
        }
    }//GEN-LAST:event_tableCreditKeyReleased

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            // TODO add your handling code here:
            try {
                loadBudget();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void tablelisteVirementKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tablelisteVirementKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tablelisteVirementKeyReleased

    private void cboBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboBudgetActionPerformed
        // TODO add your handling code here:
        chargerListeVirement();
    }//GEN-LAST:event_cboBudgetActionPerformed

    private void btnActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionActionPerformed
        // TODO add your handling code here:
        if (this.modeOuverture == DialogOpenMode.enregistre) {
            enregistrer();
        } else if (this.modeOuverture == DialogOpenMode.reserve) {
            reserver();
        } else if (this.modeOuverture == DialogOpenMode.reservation_annule) {
            reserver_annuler();
        } else if (this.modeOuverture == DialogOpenMode.valide) {
            valider();
        } else if (this.modeOuverture == DialogOpenMode.valide_annule) {
            valider_annuler();
        } else if (this.modeOuverture == DialogOpenMode.transmiPourLiquidation) {
            priseencompte();
        }
        chargerListeVirement();
    }//GEN-LAST:event_btnActionActionPerformed

    private void btnNewVirementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewVirementActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        PrepaBudget p = (PrepaBudget) cboBudget.getSelectedItem();

        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisation");
            return;
        }
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire ");
            return;
        }
        if (p == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner le budget ");
            return;
        }
        modeleTableDebit.setOrganisationID(o.getOrganisationID());
        modeleTableDebit.setMillesime(e.getMillesime());
        modeleTableDebit.setBudgetID(p.getBudgetID());

        modeleTableCredit.setOrganisationID(o.getOrganisationID());
        modeleTableCredit.setMillesime(e.getMillesime());
        modeleTableCredit.setBudgetID(p.getBudgetID());

        currentVir = null;
        initModeleUI();
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "details");
    }//GEN-LAST:event_btnNewVirementActionPerformed

    private void btnListeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListeActionPerformed
        // TODO add your handling code here:
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
    }//GEN-LAST:event_btnListeActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // TODO add your handling code here:
        chargerListeVirement();
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void tablelisteVirementMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tablelisteVirementMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_tablelisteVirementMouseClicked

    private void lnlModifierVirementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnlModifierVirementActionPerformed
        // TODO add your handling code here:
        Organisation og = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        PrepaBudget p = (PrepaBudget) cboBudget.getSelectedItem();

        if (og == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisation");
            return;
        }
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire ");
            return;
        }
        if (p == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner le budget ");
            return;
        }

        modeleTableDebit.setOrganisationID(og.getOrganisationID());
        modeleTableDebit.setMillesime(e.getMillesime());
        modeleTableDebit.setBudgetID(p.getBudgetID());

        modeleTableCredit.setOrganisationID(og.getOrganisationID());
        modeleTableCredit.setMillesime(e.getMillesime());
        modeleTableCredit.setBudgetID(p.getBudgetID());

        int row = tablelisteVirement.getSelectedRow();
        int column = tablelisteVirement.getSelectedColumn();
        Object o = listVirement.get(row); //  tablelisteVirement.getValueAt(row, column);
        if (o != null) {
            Virement v = (Virement) o;
            currentVir = v;
            initModeleUI();
////////            if (currentVir.getEtat() == EtatDossier.enregistre) {
////////                this.modeOuverture = DialogOpenMode.enregistre;
////////            }
////////            if (currentVir.getEtat() == EtatDossier.reserve) {
////////                this.modeOuverture = DialogOpenMode.reserve;
////////            }
////////            initMode();
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "details");
        }
    }//GEN-LAST:event_lnlModifierVirementActionPerformed

    private void btnActionRevertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionRevertActionPerformed
        // TODO add your handling code here:
        if (currentVir != null) {
            int reponse = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer ce virement ?" + currentVir.getNumVirement());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getVirementService().supprimer(currentVir.getVirementID(), GrecoSession.USER_CONNECTED.getLogin());
                    GrecoSession.notifications.success();
                    chargerListeVirement();
                    GrecoOptionPane.showSuccessDialog("Virement supprimé  ");
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnActionRevertActionPerformed

    private void btnEditionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditionActionPerformed
        // TODO add your handling code here:
        imprimer();
    }//GEN-LAST:event_btnEditionActionPerformed

    private void btnNewImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewImputationActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    PrepaBudget pb = (PrepaBudget) cboBudget.getSelectedItem();
                    if(pb == null){
                        GrecoOptionPane.showErrorDialog("Sélectionnez le budget ");
                        return;
                    }
                    ExecPTADialog frame = new ExecPTADialog(me, true,pb.getBudgetID());
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }//GEN-LAST:event_btnNewImputationActionPerformed

    private void btnPTAActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPTAActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    PrepaBudget pb = (PrepaBudget) cboBudget.getSelectedItem();
                    if(pb == null){
                        GrecoOptionPane.showErrorDialog("Sélectionnez le budget ");
                        return;
                    }
                    ExecPTADialog frame = new ExecPTADialog(me, true, true, pb.getBudgetID());
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }//GEN-LAST:event_btnPTAActionPerformed

    private void btnPTASelectLignesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPTASelectLignesActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    PrepaBudget pb = (PrepaBudget) cboBudget.getSelectedItem();
                    if(pb == null){
                        GrecoOptionPane.showErrorDialog("Sélectionnez le budget ");
                        return;
                    }
                    ExecPTADialog frame = new ExecPTADialog(me, true, true, pb.getBudgetID(), ExecPTADialog.MODE_SELECT);
                    frame.setVisible(true);
                    // recuperér la liste
                    List<MyMutableTreeTableNode> list = frame.getListElements();
                    List<VirementTache> listVirTache = new ArrayList<>();
                    if (list != null && !list.isEmpty()) {
                        for (MyMutableTreeTableNode node : list) {
                            Object o = node.getUserObject();
                            if (o instanceof OperationBudgetaire) {
                                OperationBudgetaire op = (OperationBudgetaire) o;
                                
                                VirementTache v = new VirementTache();
                                v.setCredit(BigDecimal.ZERO);
                                v.setDebit(op.getCp());
                                v.setDisponibleAvant(op.getCp());
                                v.setTacheID(op.getTacheID());
                                v.setLibelleFr(op.getLibelleFr());
                                v.setLibelleUs(op.getLibelleUs());
                                v.setMontant(op.getCp());
                                v.setParagraphe(op.getCompteCode());
                                v.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                                v.setLastUpdate(new Date());
                                v.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                                v.setMillesime(op.getMillesime());
                                v.setChapitre(op.getChapitre());
                                v.setProgramme(op.getProgramme());
                                v.setAction(op.getAction());
                                v.setTacheCode(op.getTacheCode());
                                
                                listVirTache.add(v);
                            }
                        }
                        if(!listVirTache.isEmpty() && listVirTache.size()>0){
                            for (VirementTache vt : listVirTache) {
                                modeleTableDebit.addArticle(vt);
                            }
                            modeleTableDebit.addArticle(new VirementTache());
                        }
                    }
                    frame.dispose();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }//GEN-LAST:event_btnPTASelectLignesActionPerformed

    private void imprimer() {

        if (currentVir != null) {

            setCursor(new Cursor(Cursor.WAIT_CURSOR));
            SwingUtilities.invokeLater(new Runnable() {

                @Override
                public void run() {
                    Thread con;
                    con = new Thread(new Runnable() {

                        @Override
                        public void run() {
                            try {
                                glasspane.setText("Edition du projet de virement ");
                                glasspane.attente();
                                HashMap parameters = fonctions.mainParameters();

                                ////////////////////////////////////////////////
                                Virement vir = GrecoServiceFactory.getVirementService().getVirement(currentVir.getVirementID());
                                if (vir != null) {
                                    List<Virement> listVir = new ArrayList<>();
                                    listVir.add(vir);

                                    //sub reports stream
                                    InputStream subReportDetails = fonctions.virementDetails();
                                    //sub report data collection
                                    List<VirementTache> subReportCollection = GrecoServiceFactory.getVirementService().getListTache(currentVir.getVirementID());
                                    System.out.println("liste des taches du virement" + subReportCollection.size());
                                    //decoupage du modele de virement pour separer en deux et inserer les imputations au milieu
                                    String[] article = currentVir.getContenu().split("@@imputations@@");
                                    if (article.length > 0) {
                                        try {
                                            parameters.put("article1", article[0]);
                                        } catch (Exception e) {
                                        }
                                        try {
                                            parameters.put("article2", article[1]);
                                        } catch (Exception e) {
                                        }
                                    }

                                    GrecoImages mesImages = new GrecoImages();
                                    // parameters.put("logo", mesImages.logoFST());
                                    parameters.put("app", mesImages.logo());
                                    parameters.put("logo", mesImages.drapeauCroise());
                                    parameters.put("deviseFR", "Paix - Travail - Patrie");
                                    parameters.put("tutelleFr", GrecoAppConfig.getTutelleFr());
                                    parameters.put("tutelleUs", GrecoAppConfig.getTutelleUs());
                                    parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppAbbreviation());
                                    parameters.put("PARAM_DispositifUS", GrecoAppConfig.getAppTitleFr());
                                    parameters.put("imputationStream", subReportDetails);
                                    parameters.put("dataCollection", new JRBeanCollectionDataSource(subReportCollection, false));
                                    System.out.println("pasage des parametres du sous etat ");
                                    String filigrane = "";
                                    if (currentVir.getEtat() == EtatDossier.enregistre) {
                                        filigrane = "Brouillon";
                                    } else if (currentVir.getEtat() == EtatDossier.reserve) {
                                        filigrane = "Projet";
                                    } else if (currentVir.getEtat() >= EtatDossier.valide) {
                                        if (edition) {
                                            filigrane = "";
                                        } else {
                                            filigrane = "Visa CF";
                                        }
                                    }
                                    parameters.put("filigrane", filigrane);

                                    JRHelper.viewReport(fonctions.virement(), parameters, new JRBeanCollectionDataSource(listVir, false), null, null);
                                }

                            } catch (Exception ex) {
                                ex.printStackTrace();
                                glasspane.arret();
                                setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                            }
                            glasspane.arret();
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                    }, "Performer");
                    con.start();
                }
            });
        }
    }

    private void chargerListeVirement() {

        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        PrepaBudget p = (PrepaBudget) cboBudget.getSelectedItem();

        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisation");
            return;
        }
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire ");
            return;
        }
        if (p == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner le budget ");
            return;
        }
        int etat = EtatDossier.enregistre;
        if (this.modeOuverture == EtatDossier.enregistre) {
            etat = EtatDossier.enregistre;
        } else if (this.modeOuverture == EtatDossier.reserve) {
            etat = EtatDossier.enregistre;
        } else if (this.modeOuverture == EtatDossier.reservation_annule) {
            etat = EtatDossier.reserve;
        } else if (this.modeOuverture == EtatDossier.valide) {
            etat = EtatDossier.reserve;
            if (edition) {
                etat = EtatDossier.valide;
            }
        } else if (this.modeOuverture == EtatDossier.valide_annule) {
            etat = EtatDossier.valide;
        } else if (this.modeOuverture == EtatDossier.transmiPourLiquidation) {
            etat = EtatDossier.valide;
        } else {
            etat = modeOuverture;
        }

        List<Virement> list = GrecoServiceFactory.getVirementService().getListVirement(o.getOrganisationID(),
                e.getMillesime(), p.getBudgetID(), etat);
        listVirement.clear();
        if (list != null && !list.isEmpty()) {
            for (Virement v : list) {
                listVirement.add(v);
            }
        }
    }

    private void reserver() {
        if (controlData()) {
            if (currentVir != null) {
                Number debit = (Number) txtDebit.getValue();
                Number credit = (Number) txtCredit.getValue();
                if (debit.longValue() != credit.longValue()) {
                    GrecoOptionPane.showWarningDialog("Le volume a créditer ne peut pas etre différent du volume a débiter");
                    return;
                }
                int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir bloquer les crédits sur les lignes à débiter ?");
                if (reponse == JOptionPane.NO_OPTION) {
                    return;
                }
                //reserver
                try {
                    GrecoServiceFactory.getVirementService().reserver(currentVir.getVirementID(), GrecoSession.USER_CONNECTED.getLogin());
                    GrecoSession.notifications.success();
//                    currentVir.setEtat(EtatDossier.reserve);
                    chargerListeVirement();
                    GrecoOptionPane.showSuccessDialog("virement réservé avec succès ");
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }

    private void reserver_annuler() {
        if (controlData()) {
            if (currentVir != null) {
                Number debit = (Number) txtDebit.getValue();
                Number credit = (Number) txtCredit.getValue();
                if (debit.longValue() != credit.longValue()) {
                    GrecoOptionPane.showWarningDialog("Le volume a créditer ne peut pas etre différent du volume a débiter");
                    return;
                }
                int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir annuler la réservation de crédits sur les lignes à débiter ?");
                if (reponse == JOptionPane.NO_OPTION) {
                    return;
                }
                //reserver
                try {
                    GrecoServiceFactory.getVirementService().reservation_annuler(currentVir.getVirementID(), GrecoSession.USER_CONNECTED.getLogin());
                    GrecoSession.notifications.success();
//                    currentVir.setEtat(EtatDossier.reserve);
                    chargerListeVirement();
                    GrecoOptionPane.showSuccessDialog(" Réservation de crédit annulé avec succès ");
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }

    private void priseencompte() {
        if (controlDataSignature()) {
            if (currentVir != null) {

                int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir valider ce virement ?");
                if (reponse == JOptionPane.NO_OPTION) {
                    return;
                }
                //reserver
                try {
                    GrecoServiceFactory.getVirementService().valider(currentVir.getVirementID(), GrecoSession.USER_CONNECTED.getLogin(),
                            txtArreteFinal.getText().trim(), dtpDateSignature.getDate());
                    GrecoSession.notifications.success();
//                    currentVir.setEtat(EtatDossier.reserve);
                    chargerListeVirement();
                    GrecoOptionPane.showSuccessDialog("Les lignes de crédits ont été mouvementés avec succès");
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }

    private void valider() {
        if (controlData()) {
            if (currentVir != null) {

                int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir marquer votre visa budgétaire sur ce virement ?");
                if (reponse == JOptionPane.NO_OPTION) {
                    return;
                }
                //reserver
                try {
                    GrecoServiceFactory.getVirementService().visaBudgetaire(currentVir.getVirementID(), GrecoSession.USER_CONNECTED.getLogin());
                    GrecoSession.notifications.success();
//                    currentVir.setEtat(EtatDossier.reserve);
                    chargerListeVirement();
                    GrecoOptionPane.showSuccessDialog("Visa budgétaire OK  ");
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }

    private void valider_annuler() {
        if (controlData()) {
            if (currentVir != null) {

                int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir annuler votre visa budgétaire sur ce virement ?");
                if (reponse == JOptionPane.NO_OPTION) {
                    return;
                }
                //reserver
                try {
                    GrecoServiceFactory.getVirementService().visaBudgetaire_annuler(currentVir.getVirementID(), GrecoSession.USER_CONNECTED.getLogin());
                    GrecoSession.notifications.success();
//                    currentVir.setEtat(EtatDossier.reserve);
                    chargerListeVirement();
                    GrecoOptionPane.showSuccessDialog("Visa budgétaire annulé  ");
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }

    private void enregistrer() {
        if (controlData()) {
            if (currentVir == null) {
                currentVir = new Virement();
            }
            remplirModele();
            Number debit = (Number) txtDebit.getValue();
            Number credit = (Number) txtCredit.getValue();
            if (debit.longValue() < credit.longValue()) {
                GrecoOptionPane.showWarningDialog("Le volume a créditer ne peut pas etre supérieur au volume a débiter");
                return;
            }
            if (debit.longValue() != credit.longValue()) {
                int reponse = GrecoOptionPane.showConfirmDialog("Le volume DEBIT est différent du volume CREDIT. \n Voulez vous néanmoins enregistrer ce virement ?");
                if (reponse == JOptionPane.NO_OPTION) {
                    return;
                }
            }
            try {
                List<VirementTache> listeImputations = new ArrayList<>();
                List<VirementTache> listeDebits = new ArrayList<>();
                List<VirementTache> listeCredits = new ArrayList<>();

                listeDebits = modeleTableDebit.getDataListToSave();
                listeCredits = modeleTableCredit.getDataListToSave();

                for (VirementTache virDebit : listeDebits) {
                    listeImputations.add(virDebit);
                }
                for (VirementTache virCredit : listeCredits) {
                    listeImputations.add(virCredit);
                }
                String virementID = GrecoServiceFactory.getVirementService().ajouter(currentVir, listeImputations);
                currentVir.setVirementID(virementID);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("virement enregistré avec succès ");

            } catch (GrecoException e) {
                GrecoSession.notifications.echec();
                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                return;
            }

        }
    }

    public void ajouterLigneDebit() {
        VirementTache a = new VirementTache();
        modeleTableDebit.addArticle(a);
    }

    public void ajouterLigneCredit() {
        VirementTache a = new VirementTache();
        modeleTableCredit.addArticle(a);
    }

    public void deleteLigneDebit() {
        int[] selection = tableDebit.getSelectedRows();
        if (selection.length > 0) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer ces lignes ??");
            if (res == JOptionPane.YES_OPTION) {
                for (int i = selection.length - 1; i >= 0; i--) {
                    modeleTableDebit.removeArticle(selection[i]);
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Aucune ligne a retirer. Veuillez selectionner une ligne SVP");
        }
    }

    public void deleteLigneCredit() {
        int[] selection = tableDebit.getSelectedRows();
        if (selection.length > 0) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer ces lignes ??");
            if (res == JOptionPane.YES_OPTION) {
                for (int i = selection.length - 1; i >= 0; i--) {
                    modeleTableDebit.removeArticle(selection[i]);
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Aucune ligne a retirer. Veuillez selectionner une ligne SVP");
        }
    }

    public List<Virement> getListVirement() {
        return listVirement;
    }

    public void setListVirement(List<Virement> listVirement) {
        this.listVirement = listVirement;
    }

    public Virement getSelectedVirement() {
        return selectedVirement;
    }

    public void setSelectedVirement(Virement selectedVirement) {
        this.selectedVirement = selectedVirement;
    }

    public void calculTotaux(BigDecimal montant, int mode) {
        if (mode == DEBIT) {
            txtDebit.setValue(montant);
        } else if (mode == CREDIT) {
            txtCredit.setValue(montant);
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAction;
    private cm.eusoworks.tools.ui.GButton btnActionRevert;
    private cm.eusoworks.tools.ui.GButton btnEdition;
    private cm.eusoworks.tools.ui.GButton btnListe;
    private cm.eusoworks.tools.ui.GButton btnNewImputation;
    private cm.eusoworks.tools.ui.GButton btnNewVirement;
    private cm.eusoworks.tools.ui.GButton btnPTA;
    private cm.eusoworks.tools.ui.GButton btnPTASelectLignes;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboBudget;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private org.jdesktop.swingx.JXDatePicker dtpDateSignature;
    private javax.swing.JTextPane editeurModele;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblArreteFinal;
    private javax.swing.JLabel lblDateSignature;
    private javax.swing.JLabel lblNumVirement;
    private org.jdesktop.swingx.JXHyperlink lnlModifierVirement;
    private cm.eusoworks.component.AgentComponent ordonnateurComp;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListModele;
    private javax.swing.JPanel panelBouton;
    private javax.swing.JPanel panelCredit;
    private javax.swing.JPanel panelDebit;
    private javax.swing.JPanel panelLignes;
    private javax.swing.JPanel panelObjet;
    private javax.swing.JPanel panelVolume;
    private javax.swing.JScrollPane scrollTable;
    private javax.swing.JScrollPane scrollTable1;
    private javax.swing.JScrollPane scrollTable2;
    private javax.swing.JSplitPane splitImputation;
    private javax.swing.JTabbedPane tabbedPaneVirement;
    private org.jdesktop.swingx.JXTable tableCredit;
    private org.jdesktop.swingx.JXTable tableDebit;
    private org.jdesktop.swingx.JXTable tablelisteVirement;
    private javax.swing.JTextField txtArrete;
    private javax.swing.JTextField txtArreteFinal;
    private javax.swing.JFormattedTextField txtCredit;
    private javax.swing.JFormattedTextField txtDebit;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextArea txtTitreOrdonnateur;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
