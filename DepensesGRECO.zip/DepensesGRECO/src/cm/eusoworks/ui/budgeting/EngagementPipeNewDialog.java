/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.ActiviteNiveau;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.entities.view.VueOpDisponiblePipe;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.renderer.ComboOperationBudgetaireRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.EngagementPipeStatusRenderer;
import cm.eusoworks.tools.ui.renderer.EngagementTypeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Color;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import javax.swing.table.TableColumn;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author DISI
 */
public class EngagementPipeNewDialog extends GrecoTemplateDialog {

    private Organisation currentOrganisation = null;
    private Exercice currentExercice = null;
    Engagement currentEngagement = null;
    String currentStructureID = null;
    GrecoReports fonctions = new GrecoReports();

    List<ActiviteNiveau> listNiveaux;
    List<VueEngagementDossier> listDossiers = ObservableCollections.observableList(new ArrayList<VueEngagementDossier>());
    VueEngagementDossier selectedDossier = null;
    String engagementID = null;

    /**
     * Creates new form EngagementPipeNewDialog
     */
    public EngagementPipeNewDialog(JFrame parent, boolean modal, String engagementPipeID) {
        super(parent, modal);
        initComponents();
        setTitle("Traitement préalables des engagements ");
        engagementID = engagementPipeID;
        loadOrganisations();
        loadExercicesBudgetisation();
        loadNiveauActivite();
        loadEngagementType();
        loadFournisseurs();
        loadProgrammes();
        cboImputation.setRenderer(new ComboOperationBudgetaireRenderer());
        TableColumn colorColumn = tableDossiers.getColumnModel().getColumn(0);
        colorColumn.setCellRenderer(new EngagementTypeRenderer());

        setLocationRelativeTo(null);
    }

    private void initEngagementUI() {

        try {
            if (engagementID != null) {
                currentEngagement = GrecoServiceFactory.getEngagementService().getEngagementPipe(engagementID);
            }
        } catch (Exception e) {
            e.printStackTrace();
            currentEngagement = null;
        }

        if (currentEngagement == null) {
            currentStructureID = null;
            txtObjet.setText("");
            txtMontant.setValue(null);
            cboImputation.setSelectedItem(null);
            rdbAgent.setEnabled(true);
            rdbFournisseur.setEnabled(true);
            txtDisponible.setValue(BigDecimal.ZERO);

            txtMontantNet.setValue(BigDecimal.ZERO);
            txtMontantTaxe.setValue(BigDecimal.ZERO);
            txtNumeroOPNet.setText("");
            txtNumeroOPTaxe.setText("");
            txtReference.setText("");
        } else {

            try {
                Enumeration<AbstractButton> e = typeGroup.getElements();

                while (e.hasMoreElements()) {
                    JRadioButton r = (JRadioButton) e.nextElement();
                    if (r.getActionCommand().equalsIgnoreCase(currentEngagement.getTypeID())) {
                        r.setSelected(true);
                        break;
                    }
                }

            } catch (Exception e) {
            }
            txtObjet.setText(currentEngagement.getObjet());
            try {
                txtMontant.setValue(currentEngagement.getMontantTTC());
            } catch (Exception e) {
            }

            if (currentEngagement.getMatricule() != null && !currentEngagement.getMatricule().isEmpty()) {
                agentComp.setMatricule(currentEngagement.getMatricule());
                rdbAgent.setSelected(true);
            } else if (currentEngagement.getFournisseurID() != null && !currentEngagement.getFournisseurID().isEmpty()) {
                for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                    Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                    if (f.getFournisseurID().equalsIgnoreCase(currentEngagement.getFournisseurID())) {
                        cboFournisseur.setSelectedIndex(i);
                        break;
                    }
                }
                rdbFournisseur.setSelected(true);
            }
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentEngagement.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    currentStructureID = s.getStructureID();
                    break;
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentEngagement.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentEngagement.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }

            txtNumeroOPNet.setText(currentEngagement.getNumeroOPNet());
            txtNumeroOPTaxe.setText(currentEngagement.getNumeroOPTaxe());
            txtMontantNet.setValue(currentEngagement.getMontantNet());
            txtMontantTaxe.setValue(currentEngagement.getMontantTaxe());
            txtReference.setText(currentEngagement.getReference());

            if (currentEngagement.getEtat() > EtatDossier.reserve) {
                btnEnregistrer.setVisible(false);
                btnSupprimer.setVisible(false);
            }

        }

    }

    private void loadProgrammes() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e != null) {
                List<Activite> prog = GrecoServiceFactory.getActiviteService().getListActiviteRoots(o.getOrganisationID(), e.getMillesime());
                if (prog != null) {
                    prog.add(null);
                    cboProgramme.setModel(new DefaultComboBoxModel(prog.toArray()));
                    cboProgramme.setSelectedIndex(-1);
                }
            }
        }

    }

    private void loadFournisseurs() {
        List<Fournisseur> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getFournisseurService().getListFournisseur();
        } catch (Exception e) {
            list = null;
        }

        if (list != null && !list.isEmpty()) {
            cboFournisseur.setModel(new DefaultComboBoxModel(list.toArray()));
            cboFournisseur.setSelectedIndex(-1);
        }
    }

    private void loadEngagementType() {
        List<EngagementType> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getEngagementService().getEngagementType();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            list.add(null);
            cboTypeengagement.setModel(new DefaultComboBoxModel(list.toArray()));
            cboTypeengagement.setSelectedIndex(-1);
        }
    }

    private void loadNiveauActivite() {
        try {
            listNiveaux = GrecoServiceFactory.getNiveauService().listeNiveauActivite();
        } catch (Exception e) {
        }
    }

    private void loadActivite() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e != null) {
//                Structure s = null;
//                try {
//                    s = (Structure) cboStructure.getSelectedItem();
//                } catch (Exception ev) {
//                    s = null;
//                }
//                if (s != null) {
                cboTache.removeAll();
                cboImputation.removeAll();
                List<Activite> l = new ArrayList<>();
                try {
//                        l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(e.getMillesime(), o.getOrganisationID(), s.getStructureID());
                    l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(e.getMillesime(), o.getOrganisationID(), null);
                } catch (Exception ex) {
                    l = null;
                }
                if (l != null && !l.isEmpty()) {
                    l.add(null);
                    cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                    cboTache.setSelectedIndex(-1);
                    cboImputation.setSelectedItem(null);
                }
//                }
            }
        }

    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserActives(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    private void loadStructureOrganisation() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            List<Structure> list = new ArrayList<Structure>();
            try {
                list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(o.getOrganisationID());
            } catch (Exception e) {
                list = null;
            }
            if (list != null && !list.isEmpty()) {
                cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
                cboStructure.setSelectedIndex(-1);
            }
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        buttonGroup1 = new javax.swing.ButtonGroup();
        typeGroup = new javax.swing.ButtonGroup();
        jLabel5 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        panelNew = new javax.swing.JPanel();
        panelType = new javax.swing.JPanel();
        rdbBC = new javax.swing.JRadioButton();
        rdbLC = new javax.swing.JRadioButton();
        rdbMarche = new javax.swing.JRadioButton();
        rdbMission = new javax.swing.JRadioButton();
        rdbDecision = new javax.swing.JRadioButton();
        btnFileGlobale = new cm.eusoworks.tools.ui.GButton();
        panelDetails = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        pObjetCommande = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        btnListeEngagements = new cm.eusoworks.tools.ui.GButton();
        gDisponiblePipe1 = new cm.eusoworks.tools.ui.GDisponiblePipe();
        jLabel11 = new javax.swing.JLabel();
        txtDisponible = new javax.swing.JFormattedTextField();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtNumeroOPNet = new javax.swing.JTextField();
        txtMontantNet = new javax.swing.JFormattedTextField();
        jLabel14 = new javax.swing.JLabel();
        txtNumeroOPTaxe = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        txtMontantTaxe = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        pPrestataire = new javax.swing.JPanel();
        cboFournisseur = new javax.swing.JComboBox();
        agentComp = new cm.eusoworks.component.AgentComponent();
        rdbFournisseur = new javax.swing.JRadioButton();
        rdbAgent = new javax.swing.JRadioButton();
        btnFournisseurNew = new cm.eusoworks.tools.ui.GButton();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();
        panelList = new javax.swing.JPanel();
        panelFiltre = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtBeneficiaire = new javax.swing.JTextField();
        cboProgramme = new javax.swing.JComboBox();
        jLabel15 = new javax.swing.JLabel();
        txtNbJours = new javax.swing.JFormattedTextField();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        jLabel10 = new javax.swing.JLabel();
        cboTypeengagement = new javax.swing.JComboBox<>();
        lblRecherche = new javax.swing.JLabel();
        btnMiseAJourOP = new cm.eusoworks.tools.ui.GButton();
        scrollTableList = new javax.swing.JScrollPane();
        tableDossiers = new javax.swing.JTable();
        jPanel1 = new javax.swing.JPanel();
        btnRetour = new cm.eusoworks.tools.ui.GButton();

        jLabel5.setText("Structure : ");

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new java.awt.CardLayout());

        panelNew.setLayout(new java.awt.BorderLayout());

        panelType.setBackground(new java.awt.Color(249, 249, 249));

        typeGroup.add(rdbBC);
        rdbBC.setText("BON DE COMMANDE");
        rdbBC.setActionCommand("1");
        rdbBC.setName("1"); // NOI18N

        typeGroup.add(rdbLC);
        rdbLC.setText("LETTRE COMMANDE");
        rdbLC.setActionCommand("2");
        rdbLC.setName("2"); // NOI18N

        typeGroup.add(rdbMarche);
        rdbMarche.setText("MARCHE");
        rdbMarche.setActionCommand("3");
        rdbMarche.setName("3"); // NOI18N

        typeGroup.add(rdbMission);
        rdbMission.setText("ORDRE DE MISSION");
        rdbMission.setActionCommand("4");
        rdbMission.setName("4"); // NOI18N

        typeGroup.add(rdbDecision);
        rdbDecision.setText("DECISION ");
        rdbDecision.setActionCommand("5");
        rdbDecision.setName("5"); // NOI18N

        btnFileGlobale.setText("File d'attente globale ");
        btnFileGlobale.setCouleur(4);
        btnFileGlobale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFileGlobaleActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelTypeLayout = new javax.swing.GroupLayout(panelType);
        panelType.setLayout(panelTypeLayout);
        panelTypeLayout.setHorizontalGroup(
            panelTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTypeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbBC)
                    .addComponent(rdbLC)
                    .addComponent(rdbMission)
                    .addComponent(rdbMarche, javax.swing.GroupLayout.PREFERRED_SIZE, 139, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdbDecision, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFileGlobale, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(14, Short.MAX_VALUE))
        );
        panelTypeLayout.setVerticalGroup(
            panelTypeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTypeLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(rdbBC)
                .addGap(33, 33, 33)
                .addComponent(rdbLC)
                .addGap(30, 30, 30)
                .addComponent(rdbMarche)
                .addGap(29, 29, 29)
                .addComponent(rdbMission)
                .addGap(30, 30, 30)
                .addComponent(rdbDecision)
                .addGap(89, 89, 89)
                .addComponent(btnFileGlobale, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(251, Short.MAX_VALUE))
        );

        panelNew.add(panelType, java.awt.BorderLayout.WEST);

        panelDetails.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        pObjetCommande.setBackground(new java.awt.Color(255, 255, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Objet de la commande ou du service ...", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 204))); // NOI18N
        pObjetCommande.setLayout(null);

        jLabel2.setText("Tâche : ");
        pObjetCommande.add(jLabel2);
        jLabel2.setBounds(10, 200, 87, 30);

        jLabel4.setText("Objet : ");
        pObjetCommande.add(jLabel4);
        jLabel4.setBounds(10, 20, 87, 60);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(130, 200, 550, 30);

        cboImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboImputationActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(130, 240, 550, 30);

        jScrollPane2.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N

        txtObjet.setColumns(20);
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        jScrollPane2.setViewportView(txtObjet);

        pObjetCommande.add(jScrollPane2);
        jScrollPane2.setBounds(130, 20, 330, 60);

        jLabel9.setText("Imputation : ");
        pObjetCommande.add(jLabel9);
        jLabel9.setBounds(10, 240, 87, 30);

        jLabel1.setText("Montant : ");
        pObjetCommande.add(jLabel1);
        jLabel1.setBounds(10, 90, 77, 38);

        txtMontant.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontant.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        txtMontant.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtMontantFocusLost(evt);
            }
        });
        pObjetCommande.add(txtMontant);
        txtMontant.setBounds(130, 90, 240, 38);

        btnListeEngagements.setText("...");
        btnListeEngagements.setCouleur(4);
        btnListeEngagements.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListeEngagementsActionPerformed(evt);
            }
        });
        pObjetCommande.add(btnListeEngagements);
        btnListeEngagements.setBounds(690, 210, 44, 29);

        javax.swing.GroupLayout gDisponiblePipe1Layout = new javax.swing.GroupLayout(gDisponiblePipe1);
        gDisponiblePipe1.setLayout(gDisponiblePipe1Layout);
        gDisponiblePipe1Layout.setHorizontalGroup(
            gDisponiblePipe1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 550, Short.MAX_VALUE)
        );
        gDisponiblePipe1Layout.setVerticalGroup(
            gDisponiblePipe1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 30, Short.MAX_VALUE)
        );

        pObjetCommande.add(gDisponiblePipe1);
        gDisponiblePipe1.setBounds(130, 280, 550, 30);

        jLabel11.setText("Disponible : ");
        pObjetCommande.add(jLabel11);
        jLabel11.setBounds(10, 320, 100, 38);

        txtDisponible.setEditable(false);
        txtDisponible.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtDisponible.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        txtDisponible.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtDisponibleFocusLost(evt);
            }
        });
        pObjetCommande.add(txtDisponible);
        txtDisponible.setBounds(130, 320, 240, 38);

        jLabel12.setText("OP du NAP :  ");
        pObjetCommande.add(jLabel12);
        jLabel12.setBounds(480, 20, 110, 30);

        jLabel13.setText("Montant NAP : ");
        pObjetCommande.add(jLabel13);
        jLabel13.setBounds(480, 56, 100, 20);
        pObjetCommande.add(txtNumeroOPNet);
        txtNumeroOPNet.setBounds(590, 20, 140, 30);

        txtMontantNet.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        pObjetCommande.add(txtMontantNet);
        txtMontantNet.setBounds(590, 50, 140, 30);

        jLabel14.setForeground(new java.awt.Color(255, 51, 51));
        jLabel14.setText("OP des Taxes  :  ");
        pObjetCommande.add(jLabel14);
        jLabel14.setBounds(480, 80, 110, 30);

        txtNumeroOPTaxe.setForeground(new java.awt.Color(255, 51, 51));
        pObjetCommande.add(txtNumeroOPTaxe);
        txtNumeroOPTaxe.setBounds(590, 80, 140, 30);

        jLabel16.setForeground(new java.awt.Color(255, 51, 51));
        jLabel16.setText("Montant Taxe : ");
        pObjetCommande.add(jLabel16);
        jLabel16.setBounds(480, 110, 100, 30);

        txtMontantTaxe.setForeground(new java.awt.Color(255, 51, 51));
        txtMontantTaxe.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        pObjetCommande.add(txtMontantTaxe);
        txtMontantTaxe.setBounds(590, 110, 140, 30);

        jLabel17.setText("Reference : ");
        pObjetCommande.add(jLabel17);
        jLabel17.setBounds(10, 140, 110, 40);

        txtReference.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        pObjetCommande.add(txtReference);
        txtReference.setBounds(130, 140, 330, 40);

        pPrestataire.setBackground(new java.awt.Color(226, 226, 226));
        pPrestataire.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Bénéficiaire ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 255))); // NOI18N
        pPrestataire.setOpaque(false);

        cboFournisseur.setFont(new java.awt.Font("Lucida Grande", 0, 15)); // NOI18N

        buttonGroup1.add(rdbFournisseur);
        rdbFournisseur.setText("Contribuable");

        buttonGroup1.add(rdbAgent);
        rdbAgent.setText("Agent ");

        btnFournisseurNew.setText("+");
        btnFournisseurNew.setCouleur(4);
        btnFournisseurNew.setFont(new java.awt.Font("Lucida Grande", 0, 12)); // NOI18N
        btnFournisseurNew.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        btnFournisseurNew.setIconTextGap(0);
        btnFournisseurNew.setMargin(new java.awt.Insets(0, 0, 0, 0));
        btnFournisseurNew.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFournisseurNewActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pPrestataireLayout = new javax.swing.GroupLayout(pPrestataire);
        pPrestataire.setLayout(pPrestataireLayout);
        pPrestataireLayout.setHorizontalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbFournisseur)
                    .addComponent(rdbAgent, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pPrestataireLayout.createSequentialGroup()
                        .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, 547, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnFournisseurNew, javax.swing.GroupLayout.PREFERRED_SIZE, 51, Short.MAX_VALUE))
                    .addGroup(pPrestataireLayout.createSequentialGroup()
                        .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, 538, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        pPrestataireLayout.setVerticalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFournisseurNew, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(rdbAgent)
                    .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(9, Short.MAX_VALUE))
        );

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });

        btnSupprimer.setText("Supprimer ");
        btnSupprimer.setCouleur(1);
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelDetailsLayout = new javax.swing.GroupLayout(panelDetails);
        panelDetails.setLayout(panelDetailsLayout);
        panelDetailsLayout.setHorizontalGroup(
            panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDetailsLayout.createSequentialGroup()
                .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelDetailsLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(panelDetailsLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(26, 26, 26)
                                .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 274, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 541, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(pObjetCommande, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(pPrestataire, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(panelDetailsLayout.createSequentialGroup()
                        .addGap(105, 105, 105)
                        .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33)
                        .addComponent(btnSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(179, Short.MAX_VALUE))
        );
        panelDetailsLayout.setVerticalGroup(
            panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelDetailsLayout.createSequentialGroup()
                .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelDetailsLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(pPrestataire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pObjetCommande, javax.swing.GroupLayout.DEFAULT_SIZE, 377, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelDetailsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(25, 25, 25))
        );

        panelNew.add(panelDetails, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelNew, "new");

        panelList.setLayout(new java.awt.BorderLayout());

        panelFiltre.setBackground(new java.awt.Color(252, 252, 252));
        panelFiltre.setBorder(javax.swing.BorderFactory.createTitledBorder("Filtre(s)"));

        jLabel3.setText("Programme : ");

        jLabel6.setText("Bénéficiaire : ");

        txtBeneficiaire.setFont(new java.awt.Font("Lucida Grande", 0, 15)); // NOI18N

        cboProgramme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboProgrammeActionPerformed(evt);
            }
        });

        jLabel15.setText("Durée dans la file (Jours) : ");

        txtNbJours.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtNbJours.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N

        btnRechercher.setText("Rechercher ");
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });

        jLabel10.setText("Type de dépense :  ");

        cboTypeengagement.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblRecherche.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblRecherche.setForeground(new java.awt.Color(91, 118, 173));
        lblRecherche.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        lblRecherche.setText("Résultats de la recherche : ");

        btnMiseAJourOP.setText("Mettre a Jour les OP ");
        btnMiseAJourOP.setCouleur(4);
        btnMiseAJourOP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnMiseAJourOPActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelFiltreLayout = new javax.swing.GroupLayout(panelFiltre);
        panelFiltre.setLayout(panelFiltreLayout);
        panelFiltreLayout.setHorizontalGroup(
            panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFiltreLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelFiltreLayout.createSequentialGroup()
                        .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, 100, Short.MAX_VALUE))
                            .addComponent(jLabel15))
                        .addGap(22, 22, 22)
                        .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(cboProgramme, javax.swing.GroupLayout.PREFERRED_SIZE, 590, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelFiltreLayout.createSequentialGroup()
                                .addComponent(txtNbJours, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(83, 83, 83)
                                .addComponent(jLabel10)
                                .addGap(18, 18, 18)
                                .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, 576, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(335, Short.MAX_VALUE))
                    .addGroup(panelFiltreLayout.createSequentialGroup()
                        .addComponent(btnRechercher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblRecherche, javax.swing.GroupLayout.PREFERRED_SIZE, 358, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnMiseAJourOP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(70, 70, 70))))
        );
        panelFiltreLayout.setVerticalGroup(
            panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelFiltreLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboProgramme, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelFiltreLayout.createSequentialGroup()
                        .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelFiltreLayout.createSequentialGroup()
                                .addGap(8, 8, 8)
                                .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(txtNbJours, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(panelFiltreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnRechercher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblRecherche, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(16, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelFiltreLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnMiseAJourOP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
        );

        panelList.add(panelFiltre, java.awt.BorderLayout.NORTH);

        tableDossiers.setFont(new java.awt.Font("Lucida Grande", 0, 13)); // NOI18N
        tableDossiers.setRowHeight(24);
        tableDossiers.setShowGrid(true);
        tableDossiers.setShowVerticalLines(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listDossiers}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${type}"));
        columnBinding.setColumnName("Type");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${codeTache}"));
        columnBinding.setColumnName("Tache");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${compte}"));
        columnBinding.setColumnName("Paragaphe");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Bénéficiaire");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${objet}"));
        columnBinding.setColumnName("Objet");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numeroOPNet}"));
        columnBinding.setColumnName("OP Net");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantNet}"));
        columnBinding.setColumnName("Net a Payer");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numeroOPTaxe}"));
        columnBinding.setColumnName("OP Taxes");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantTaxe}"));
        columnBinding.setColumnName("Montant Taxes");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${reference}"));
        columnBinding.setColumnName("Reference");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${updateUser}"));
        columnBinding.setColumnName("User");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${updateLastDate}"));
        columnBinding.setColumnName("LastDate");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedDossier}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableDossiers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableDossiersMouseClicked(evt);
            }
        });
        scrollTableList.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(10);
            tableDossiers.getColumnModel().getColumn(1).setMinWidth(70);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(70);
            tableDossiers.getColumnModel().getColumn(2).setMinWidth(15);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(15);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(250);
            tableDossiers.getColumnModel().getColumn(4).setPreferredWidth(60);
            tableDossiers.getColumnModel().getColumn(6).setMinWidth(18);
            tableDossiers.getColumnModel().getColumn(6).setPreferredWidth(18);
            tableDossiers.getColumnModel().getColumn(8).setMinWidth(18);
            tableDossiers.getColumnModel().getColumn(8).setPreferredWidth(18);
            tableDossiers.getColumnModel().getColumn(10).setMinWidth(50);
            tableDossiers.getColumnModel().getColumn(10).setPreferredWidth(50);
        }

        panelList.add(scrollTableList, java.awt.BorderLayout.CENTER);

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnRetour.setText("<<< Retourner");
        btnRetour.setCouleur(3);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });
        jPanel1.add(btnRetour);

        panelList.add(jPanel1, java.awt.BorderLayout.SOUTH);

        getContentPane().add(panelList, "list");

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        loadStructureOrganisation();
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        loadActivite();
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        VueOpDisponiblePipe vide = new VueOpDisponiblePipe();
        gDisponiblePipe1.setVueDisponible(vide);
        txtDisponible.setValue(BigDecimal.ZERO);
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        cboImputation.setSelectedItem(null);
        if (a != null) {
            cboImputation.removeAll();;
//            Structure s = null;
//            try {
//                s = (Structure) cboStructure.getSelectedItem();
//            } catch (Exception e) {
//            }
//            if (s != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
//                    l = GrecoServiceFactory.getOperationService().getListOperationByActiviteAndStructure(a.getActiviteID(), s.getStructureID());
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                l.add(null);
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
//            }

        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void cboImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboImputationActionPerformed
        // TODO add your handling code here:
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op != null) {
            VueOpDisponiblePipe dispo = GrecoServiceFactory.getOperationService().getDisponiblePipe(op.getTacheID());
            currentStructureID = op.getStructureID();
            if (dispo.getTacheID() == null) {
                btnEnregistrer.setVisible(false);
            } else {
                Number resteNum = dispo.getReste();
                Number mntNum = null;
                try {
                    txtMontant.commitEdit();
                    mntNum = (Number) txtMontant.getValue();
                } catch (ParseException ex) {
                    mntNum = 0;
                    Logger.getLogger(EngagementPipeNewDialog.class.getName()).log(Level.SEVERE, null, ex);
                }
                if (resteNum.longValue() < mntNum.longValue()) {
                    btnEnregistrer.setVisible(false);
                    txtDisponible.setForeground(Color.red);
                    gDisponiblePipe1.setColorOff();
                } else {
                    btnEnregistrer.setVisible(true);
                    txtDisponible.setForeground(Color.black);
                    gDisponiblePipe1.setColorOn();
                }
                txtDisponible.setValue(dispo.getReste());
                gDisponiblePipe1.setVueDisponible(dispo);
            }
        } else {
            VueOpDisponiblePipe vide = new VueOpDisponiblePipe();
            gDisponiblePipe1.setVueDisponible(vide);
            txtDisponible.setValue(BigDecimal.ZERO);
        }
    }//GEN-LAST:event_cboImputationActionPerformed

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        try {
            loadActivite();
        } catch (Exception e) {
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private void cboProgrammeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboProgrammeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboProgrammeActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // TODO add your handling code here:
        search(true, false, false);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void btnFileGlobaleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFileGlobaleActionPerformed
        // TODO add your handling code here:
        search(true, true, false);
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
    }//GEN-LAST:event_btnFileGlobaleActionPerformed

    private void btnListeEngagementsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListeEngagementsActionPerformed
        // TODO add your handling code here:
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op == null) {
            GrecoOptionPane.showWarningDialog("Vous devez sélectionner l'imputation pour pouvoir afficher \n la liste des dossiers en cours ");
            return;
        }
        search(false, true, true);
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
    }//GEN-LAST:event_btnListeEngagementsActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "new");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        enregistrer();
        cboImputationActionPerformed(null);
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnFournisseurNewActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFournisseurNewActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    FournisseurNewDialog frame = new FournisseurNewDialog(null, true, null);
                    frame.setVisible(true);
                    loadFournisseurs();
                } catch (Exception e) {
                }
            }
        });
    }//GEN-LAST:event_btnFournisseurNewActionPerformed

    private void tableDossiersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableDossiersMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if (selectedDossier != null) {
                engagementID = selectedDossier.getEngagementID();
                currentEngagement = null;
                initEngagementUI();
                ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "new");
            }
        }
    }//GEN-LAST:event_tableDossiersMouseClicked

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (currentEngagement == null) {
            GrecoOptionPane.showInformationDialog("Aucun dossier à supprimer ...");
            return;
        }
        int rs = GrecoOptionPane.showConfirmDialog("Etes-vous sûr de vouloir supprimer ce dossier  ? ");
        if (rs == JOptionPane.YES_OPTION) {
            glasspane.attente();
            try {
                GrecoServiceFactory.getEngagementService().supprimerPipe(currentEngagement.getEngagementID(),
                        GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("Engagement  supprimé");

                engagementID = null;
                currentEngagement = null;
                initEngagementUI();

                search(true, true, false);
                glasspane.arret();
            } catch (Exception e) {
                glasspane.arret();
            }
        }

    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void txtMontantFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtMontantFocusLost
        // TODO add your handling code here:
        cboImputationActionPerformed(null);
    }//GEN-LAST:event_txtMontantFocusLost

    private void txtDisponibleFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtDisponibleFocusLost
        // TODO add your handling code here:
    }//GEN-LAST:event_txtDisponibleFocusLost

    private void btnMiseAJourOPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnMiseAJourOPActionPerformed
        // TODO add your handling code here:
        try {
            glasspane.setText("enregistrement de la dépense ....");
            glasspane.attente();
            List<VueEngagementDossier> list = new ArrayList<VueEngagementDossier>();
            for (VueEngagementDossier d : listDossiers) {
                list.add(d);
            }
            int nbre = list.size();
            int nbReussi = 0;
            if(nbre > 0){
                nbReussi = GrecoServiceFactory.getEngagementService().modifierPipeOP(list);
                glasspane.arret();
                GrecoOptionPane.showInformationDialog(nbReussi+"/"+nbre+" dossiers modifies avec succes");
            }
        } catch (Exception e) {
            glasspane.arret();
        }

    }//GEN-LAST:event_btnMiseAJourOPActionPerformed

    private boolean controlData() {

        if (typeGroup.getSelection() == null) {
            JOptionPane.showMessageDialog(null, "Veuillez choisir le type d'engagement à gauche");
            return false;
        }

        currentOrganisation = (Organisation) cboOrganisation.getSelectedItem();
        if (currentOrganisation == null) {
            JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'organisation");
            return false;
        }
        currentExercice = (Exercice) cboExercice.getSelectedItem();
        if (currentExercice == null) {
            JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'exercice");
            return false;
        }

        if (txtObjet.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir l'objet de l'engagement ");
            return false;
        }

        //control beneficiare
        if (rdbAgent.isSelected()) {
            if (agentComp.getMatricule().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Veuillez saisir le matricule de l'agent bénéficiaire ");
                return false;
            }
        }
        if (rdbFournisseur.isSelected()) {
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            if (f == null) {
                JOptionPane.showMessageDialog(null, "Veuillez sélectionner le fournisseur ");
                return false;
            }
        }

        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op == null) {
            JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'imputation budgétaire");
            return false;
        }
        if (txtMontant.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir le montant de la dépense ");
            return false;
        }

        return true;
    }

    private void enregistrer() {
        if (controlData()) {
            glasspane.setText("enregistrement de la dépense ....");
            glasspane.attente();
            if (currentEngagement == null) {
                currentEngagement = new Engagement();
                remplirEngagement();
                try {
                    String numDossier = GrecoServiceFactory.getEngagementService().ajouterPipe(currentEngagement);
                    currentEngagement.setNumDossier(numDossier);

                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Dossier enregistré dans la file de traitement avec succès \n");

                    currentEngagement = null;
                    engagementID = null;
                    initEngagementUI();

                    glasspane.arret();
                } catch (GrecoException e) {
                    glasspane.arret();
                    currentEngagement = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                } catch (Exception e) {
                    glasspane.arret();
                    e.printStackTrace();
                    currentEngagement = null;
                    GrecoSession.notifications.echec();
                    JOptionPane.showMessageDialog(this, "ECHEC DE L'NREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                remplirEngagement();
                try {
                    GrecoServiceFactory.getEngagementService().modifierPipe(currentEngagement);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "dossier modifié avec succès ");
                    glasspane.arret();
                } catch (GrecoException e) {
                    glasspane.arret();
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }

            glasspane.arret();
        }
    }

    private void remplirEngagement() {

        currentOrganisation = (Organisation) cboOrganisation.getSelectedItem();
        if (currentOrganisation == null) {
            return;
        }
        currentExercice = (Exercice) cboExercice.getSelectedItem();
        if (currentExercice == null) {
            return;
        }
        currentEngagement.setObjet(txtObjet.getText());

        Number nbr = (Number) txtMontant.getValue();
        currentEngagement.setMontantTTC(BigDecimal.valueOf(nbr.longValue()));

        if (rdbAgent.isSelected()) {
            currentEngagement.setMatricule(agentComp.getMatricule());
            currentEngagement.setBeneficiaire("[" + agentComp.getMatricule() + "] " + agentComp.getNomComplet());
            currentEngagement.setFournisseurID(null);
            currentEngagement.setStructureBenefID(null);
        } else if (rdbFournisseur.isSelected()) {
            currentEngagement.setMatricule(null);
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            currentEngagement.setBeneficiaire(f.getNumContribuable() + " - " + f.getRaisonSociale());
            currentEngagement.setFournisseurID(f.getFournisseurID());
            currentEngagement.setStructureBenefID(null);
        }
        Structure s = (Structure) cboStructure.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();

        currentEngagement.setStructureID(s == null ? currentStructureID : s.getStructureID());
        currentEngagement.setTacheID(o.getTacheID());
        currentEngagement.setActiviteID(a.getActiviteID());
        currentEngagement.setOrganisationID(currentOrganisation.getOrganisationID());
        currentEngagement.setMillesime(currentExercice.getMillesime());

        currentEngagement.setNumeroOPNet(txtNumeroOPNet.getText().trim());
        currentEngagement.setNumeroOPTaxe(txtNumeroOPTaxe.getText().trim());
        Number nap = (Number) txtMontantNet.getValue();
        currentEngagement.setMontantNet(nap == null ? BigDecimal.ZERO : BigDecimal.valueOf(nap.longValue()));
        Number taxe = (Number) txtMontantTaxe.getValue();
        currentEngagement.setMontantTaxe(taxe == null ? BigDecimal.ZERO : BigDecimal.valueOf(taxe.longValue()));
        currentEngagement.setReference(txtReference.getText().trim());
        
        currentEngagement.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentEngagement.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        currentEngagement.setTypeID(typeGroup.getSelection().getActionCommand());
    }

    private void search(boolean fileGlobale, boolean allTypes, boolean isForTache) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String engagementType = null;
        String beneficiare = null;
        int nbJours = -1;
        String programmeID = null;
        String operationID = null;

        Activite pg = (Activite) cboProgramme.getSelectedItem();
        if (pg != null) {
            programmeID = pg.getActiviteID();
        }

        EngagementType et = (EngagementType) cboTypeengagement.getSelectedItem();
        if (et != null) {
            engagementType = et.getTypeID();
        }
        if (allTypes) {
            engagementType = null;
        }

        beneficiare = txtBeneficiaire.getText().isEmpty() ? null : txtBeneficiaire.getText();
        String chiffres = txtNbJours.getText();
        int nb = -1;
        try {
            nb = Integer.valueOf(chiffres);
        } catch (Exception e) {
        }
        nbJours = nb;

        if (isForTache) {
            OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
            if (op != null) {
                operationID = op.getTacheID();
            }
        }

        glasspane.attente();
        List<VueEngagementDossier> l = null;
        try {
            l = GrecoServiceFactory.getEngagementService().getEngagementPipe(millesime, organisationID, programmeID, operationID, engagementType, beneficiare, nbJours, fileGlobale);
        } catch (Exception e) {
            e.printStackTrace();
        }

        listDossiers.clear();
        if (l != null) {
            lblRecherche.setText(l.size() + " dossier(s) trouvé(s)");
            for (VueEngagementDossier v : l) {
                listDossiers.add(v);
            }
        } else {
            lblRecherche.setText("aucun dossier trouvé");
        }
        glasspane.arret();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EngagementPipeNewDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EngagementPipeNewDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EngagementPipeNewDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EngagementPipeNewDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                EngagementPipeNewDialog dialog = new EngagementPipeNewDialog(new javax.swing.JFrame(), true, null);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    public List<VueEngagementDossier> getListDossiers() {
        return listDossiers;
    }

    public void setListDossiers(List<VueEngagementDossier> listDossiers) {
        this.listDossiers = listDossiers;
    }

    public VueEngagementDossier getSelectedDossier() {
        return selectedDossier;
    }

    public void setSelectedDossier(VueEngagementDossier selectedDossier) {
        this.selectedDossier = selectedDossier;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnFileGlobale;
    private cm.eusoworks.tools.ui.GButton btnFournisseurNew;
    private cm.eusoworks.tools.ui.GButton btnListeEngagements;
    private cm.eusoworks.tools.ui.GButton btnMiseAJourOP;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboFournisseur;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboProgramme;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JComboBox<String> cboTypeengagement;
    private cm.eusoworks.tools.ui.GDisponiblePipe gDisponiblePipe1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblRecherche;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel pPrestataire;
    private javax.swing.JPanel panelDetails;
    private javax.swing.JPanel panelFiltre;
    private javax.swing.JPanel panelList;
    private javax.swing.JPanel panelNew;
    private javax.swing.JPanel panelType;
    private javax.swing.JRadioButton rdbAgent;
    private javax.swing.JRadioButton rdbBC;
    private javax.swing.JRadioButton rdbDecision;
    private javax.swing.JRadioButton rdbFournisseur;
    private javax.swing.JRadioButton rdbLC;
    private javax.swing.JRadioButton rdbMarche;
    private javax.swing.JRadioButton rdbMission;
    private javax.swing.JScrollPane scrollTableList;
    private javax.swing.JTable tableDossiers;
    private javax.swing.JTextField txtBeneficiaire;
    private javax.swing.JFormattedTextField txtDisponible;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtMontantNet;
    private javax.swing.JFormattedTextField txtMontantTaxe;
    private javax.swing.JFormattedTextField txtNbJours;
    private javax.swing.JTextField txtNumeroOPNet;
    private javax.swing.JTextField txtNumeroOPTaxe;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.ButtonGroup typeGroup;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
