/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.BcaArticles;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import cm.eusoworks.renderer.ComboOperationBudgetaireRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WLigneFacture;
import com.siicore.util.StringUtil;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;


/**
 *
 * @author macbookair
 */
public class LCMarcheNewDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    String millesime;
    String organisationID;
    Bca currentBCA = null;
//    Organisation org;
    private String mode;
    public LCMarcheNewDialog(JFrame parent, boolean modal, String millesime, String orgID, Bca bca, String type) {
        super(parent, modal);
        initComponents();
        bcaFacture.setActiverRefFacture(false);
        bcaFacture.setActiverObjetFacture(false);
        this.millesime = millesime;
        mode = type;
//        this.org = org;
        this.organisationID = orgID;
        cboImputation.setRenderer(new ComboOperationBudgetaireRenderer());
        loadStructureOrganisation();
        loadFournisseurs();
        AutoCompleteDecorator.decorate(cboFournisseur);
        //AutoCompleteDecorator.decorate(cboImputation);
        this.currentBCA = bca;
        initBCAInfos();
        
        if(mode.equalsIgnoreCase(LCMarcheFrame.LC_TYPE)) rdbMarche.setVisible(false);
        else if(mode.equalsIgnoreCase(LCMarcheFrame.Marche_TYPE)) rdbLC.setVisible(false);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Traitement des contrats ");
        pack();
        setPreferredSize(new Dimension(890, 400));
        setLocationRelativeTo(null);
    }

    private void initBCAInfos() {
//        txtEntete1.setText(this.org.getLibelle());
        if (currentBCA != null) {
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentBCA.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                if (f.getFournisseurID().equalsIgnoreCase(currentBCA.getFournisseurID())) {
                    cboFournisseur.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentBCA.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentBCA.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            txtObjet.setText(currentBCA.getObjet());
            txtReference.setText(currentBCA.getReference());
            agentComp.setMatricule(currentBCA.getMatriculeOrdo());
            txtEntete1.setText(currentBCA.getEntete1());
            txtEntete2.setText(currentBCA.getEntete2());
            txtEntete3.setText(currentBCA.getEntete3());
            txtEntete4.setText(currentBCA.getEntete4());
            txtEntete5.setText(currentBCA.getEntete5());

            if(this.mode == LCMarcheFrame.LC_TYPE) rdbLC.setSelected(true);
            else if(this.mode == LCMarcheFrame.Marche_TYPE) rdbMarche.setSelected(true);
            
            txtRetenueGarantie.setValue(currentBCA.getMontantRG());
            
            
            /**
             * *******chargements des lignes de la facture *****************
             */
            bcaFacture.setTauxIR(currentBCA.getTauxIR());
            bcaFacture.setTauxTVA(currentBCA.getTauxTVA());
            List<BcaArticles> list = new ArrayList<>();
            list = GrecoServiceFactory.getBonCommandeService().getBCALignes(currentBCA.getBcaID());
            int ordre = 0;
            for (BcaArticles l : list) {
                WLigneFacture wlf = new WLigneFacture(l.getAmId(), ordre);
                wlf.setReference(l.getRefArticle());
                wlf.setDesignation(l.getDesignation());
                wlf.setId(l.getAmId());
                wlf.setIndex(l.getNumOrdre());
                wlf.setPrixUnitaire(l.getPrixUnitaire().doubleValue());
                Double marge = l.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                wlf.setPuMax(l.getPrixUnitaire().doubleValue() + marge);
                wlf.setPuMin(Double.valueOf(0));
                wlf.setQuantite((int) l.getQuantite());
                bcaFacture.getLignesFacture().ajouterLigne(wlf);
                ordre++;
            }
            
            
            
            disableComponents();
        }
    }

    private void disableComponents() {
        if (currentBCA != null) {
            if (currentBCA.getEtat() >= EtatDossier.reserve) {
                txtObjet.setEnabled(false);
                txtReference.setEnabled(false);
                agentComp.setEnabled(false);
                txtEntete1.setEnabled(false);
                txtEntete2.setEnabled(false);
                txtEntete3.setEnabled(false);
                txtEntete4.setEnabled(false);
                txtEntete5.setEnabled(false);
                cboImputation.setEnabled(false);
                cboFournisseur.setEnabled(false);
                cboTache.setEnabled(false);
                cboStructure.setEnabled(false);
                btnEnregistrer.setVisible(false);
                btnEnregistrerFacture.setVisible(false);
            }
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(this.organisationID);
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);
        }

    }

    private void loadFournisseurs() {
        List<Fournisseur> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getFournisseurService().getListFournisseur();
        } catch (Exception e) {
            list = null;
        }

        if (list != null && !list.isEmpty()) {
            cboFournisseur.setModel(new DefaultComboBoxModel(list.toArray()));
            cboFournisseur.setSelectedIndex(-1);
        }
    }

    private void remplirBCA() {
        Structure s = (Structure) cboStructure.getSelectedItem();
        Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();

        currentBCA.setObjet(txtObjet.getText().trim());
        currentBCA.setReference(txtReference.getText().trim());

        currentBCA.setEntete1(txtEntete1.getText().trim());
        currentBCA.setEntete2(txtEntete2.getText().trim());
        currentBCA.setEntete3(txtEntete3.getText().trim());
        currentBCA.setEntete4(txtEntete4.getText().trim());
        currentBCA.setEntete5(txtEntete5.getText().trim());

        currentBCA.setFournisseurID(f.getFournisseurID());
        currentBCA.setTacheID(o.getTacheID());
        currentBCA.setMillesime(millesime);
        currentBCA.setOrganisationID(organisationID);
        currentBCA.setMatriculeOrdo(agentComp.getMatricule());
        currentBCA.setStructureID(s.getStructureID());
        currentBCA.setActiviteID(a.getActiviteID());

        currentBCA.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentBCA.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        //montant de la facture
        List<WLigneFacture> l = bcaFacture.getLignesFacture().getLignes();
        if (l != null && !l.isEmpty()) {
            currentBCA.setMontantTTC(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantTTC()));
            currentBCA.setMontantHT(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantHT()));
            currentBCA.setTauxIR((float) bcaFacture.getTauxIR());
            currentBCA.setTauxTVA((float) bcaFacture.getTauxTVA());
            currentBCA.setNap(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantNetAPayer()));  
        }
        Number n = (Number) txtRetenueGarantie.getValue();
            if(n != null){
                currentBCA.setMontantRG(BigDecimal.valueOf(n.longValue()));
            }
            if(rdbLC.isSelected()) currentBCA.setTypeID("2");
            else if (rdbMarche.isSelected()) currentBCA.setTypeID("3");
    }

    private boolean controlData() {
        boolean res = true;
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner la structure");
            return false;
        }
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
        if (f == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner le prestataire de service");
            return false;
        }
        if (agentComp.getMatricule() == null) {
            GrecoOptionPane.showErrorDialog("Veuillez saisir le matricule de l'ordonnateur ");
            return false;
        }
        Activite a = (Activite) cboTache.getSelectedItem();
        if (a == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner la tâche ");
            return false;
        }
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner l'imputation ");
            return false;
        }
        if (txtObjet.getText().isEmpty()) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner l'objet du contrat ");
            return false;
        }
        //existence des articles commandes 
        List<WLigneFacture> articles = new ArrayList<>();
        List<WLigneFacture> l = bcaFacture.getLignesFacture().getLignes();
        if (l != null && !l.isEmpty()) {
            for (WLigneFacture art : l) {
                if (art.getReference() != null && !(art.getDesignation()).isEmpty()) {
                    articles.add(art);
                }
            }
        }
        if (articles.isEmpty()) {
            GrecoOptionPane.showErrorDialog("Vous n'avez pas saisi les articles commandes SVP");
            return false;
        }

        if (!bcaFacture.getLignesFacture().isValid()) {
            int rep = GrecoOptionPane.showConfirmDialog("Certains prix des articles de la facture sont incorrects. \n Voulez-vous néanmoins enregistrer  ? ");
            if (rep != JOptionPane.YES_OPTION) {
                return false;
            }
        }

        if (!rdbLC.isSelected() && !rdbMarche.isSelected()) {
            GrecoOptionPane.showErrorDialog("Vous n'avez pas préciser au bas de la fenêtre si c'ets une Lettre commande ou un Marché");
            return false;
        }

        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pEntete = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtEntete1 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtEntete2 = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtEntete3 = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtEntete4 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtEntete5 = new javax.swing.JTextArea();
        buttonGroup1 = new javax.swing.ButtonGroup();
        ongletBCA = new javax.swing.JTabbedPane();
        pAccueil = new javax.swing.JPanel();
        pPrestataire = new javax.swing.JPanel();
        cboFournisseur = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAdresseFournisseur = new javax.swing.JTextArea();
        pObjetCommande = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        btnEnregistrer = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        txtDisponible = new javax.swing.JFormattedTextField();
        jLabel22 = new javax.swing.JLabel();
        txtRetenueGarantie = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        agentComp = new cm.eusoworks.component.AgentComponent();
        pRIB = new javax.swing.JPanel();
        cboRIB = new javax.swing.JComboBox();
        btnModiierRIB = new cm.eusoworks.tools.ui.GButton();
        rdbLC = new javax.swing.JRadioButton();
        rdbMarche = new javax.swing.JRadioButton();
        pDetailCommande = new javax.swing.JPanel();
        bcaFacture = new com.siicore.facture.WPanelFacture(){
            @Override
            public void loadRowData(WLigneFacture wlf) {
                chargerLigne(wlf);
            }

            @Override
            public boolean validationFacture() {
                return validerFacture();
            }
        };
        jPanel1 = new javax.swing.JPanel();
        btnEnregistrerFacture = new cm.eusoworks.tools.ui.GButton();

        jLabel8.setText("Entête 1 : ");

        txtEntete1.setColumns(20);
        txtEntete1.setRows(2);
        jScrollPane3.setViewportView(txtEntete1);

        jLabel9.setText("Entête 2 : ");

        txtEntete2.setColumns(20);
        txtEntete2.setRows(2);
        jScrollPane4.setViewportView(txtEntete2);

        jLabel10.setText("Entête 3 : ");

        txtEntete3.setColumns(20);
        txtEntete3.setRows(2);
        jScrollPane5.setViewportView(txtEntete3);

        jLabel11.setText("Entête 4 : ");

        txtEntete4.setColumns(20);
        txtEntete4.setRows(2);
        jScrollPane6.setViewportView(txtEntete4);

        jLabel12.setText("Entête 5 : ");

        txtEntete5.setColumns(20);
        txtEntete5.setRows(2);
        jScrollPane7.setViewportView(txtEntete5);

        javax.swing.GroupLayout pEnteteLayout = new javax.swing.GroupLayout(pEntete);
        pEntete.setLayout(pEnteteLayout);
        pEnteteLayout.setHorizontalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(131, Short.MAX_VALUE))
        );
        pEnteteLayout.setVerticalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane5)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane6)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane7)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des contrats ");

        pAccueil.setBackground(new java.awt.Color(255, 255, 255));
        pAccueil.setLayout(null);

        pPrestataire.setBackground(new java.awt.Color(226, 226, 226));
        pPrestataire.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Prestataire de service/Fourniseur", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 255))); // NOI18N
        pPrestataire.setOpaque(false);

        cboFournisseur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboFournisseurActionPerformed(evt);
            }
        });

        txtAdresseFournisseur.setEditable(false);
        txtAdresseFournisseur.setColumns(20);
        txtAdresseFournisseur.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        txtAdresseFournisseur.setLineWrap(true);
        txtAdresseFournisseur.setRows(2);
        jScrollPane1.setViewportView(txtAdresseFournisseur);

        javax.swing.GroupLayout pPrestataireLayout = new javax.swing.GroupLayout(pPrestataire);
        pPrestataire.setLayout(pPrestataireLayout);
        pPrestataireLayout.setHorizontalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pPrestataireLayout.createSequentialGroup()
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboFournisseur, 0, 352, Short.MAX_VALUE)
                    .addGroup(pPrestataireLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1)))
                .addContainerGap())
        );
        pPrestataireLayout.setVerticalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 57, Short.MAX_VALUE)
                .addContainerGap())
        );

        pAccueil.add(pPrestataire);
        pPrestataire.setBounds(10, 50, 370, 126);

        pObjetCommande.setBackground(new java.awt.Color(255, 255, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Objet de la commande ...", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 204))); // NOI18N
        pObjetCommande.setLayout(null);

        jLabel2.setText("Tâche : ");
        pObjetCommande.add(jLabel2);
        jLabel2.setBounds(10, 50, 87, 30);

        jLabel3.setText("Reference : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(7, 190, 100, 20);

        jLabel4.setText("Objet : ");
        pObjetCommande.add(jLabel4);
        jLabel4.setBounds(10, 120, 87, 40);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 50, 640, 30);

        cboImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboImputationActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 80, 640, 30);

        txtObjet.setColumns(20);
        txtObjet.setRows(2);
        jScrollPane2.setViewportView(txtObjet);

        pObjetCommande.add(jScrollPane2);
        jScrollPane2.setBounds(110, 120, 630, 60);

        jLabel7.setText("Imputation : ");
        pObjetCommande.add(jLabel7);
        jLabel7.setBounds(10, 80, 87, 30);

        txtReference.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        pObjetCommande.add(txtReference);
        txtReference.setBounds(110, 180, 630, 40);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(10, 20, 90, 30);

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboStructure);
        cboStructure.setBounds(110, 20, 640, 27);

        pAccueil.add(pObjetCommande);
        pObjetCommande.setBounds(10, 190, 760, 230);

        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        pAccueil.add(btnEnregistrer);
        btnEnregistrer.setBounds(510, 470, 166, 43);

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 153, 102));
        jLabel21.setText("AE Disponible : ");
        pAccueil.add(jLabel21);
        jLabel21.setBounds(20, 420, 110, 30);

        txtDisponible.setEditable(false);
        txtDisponible.setForeground(new java.awt.Color(0, 153, 102));
        txtDisponible.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtDisponible.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        pAccueil.add(txtDisponible);
        txtDisponible.setBounds(200, 420, 240, 30);

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 51, 51));
        jLabel22.setText("Retenue de garantie :  ");
        pAccueil.add(jLabel22);
        jLabel22.setBounds(20, 480, 160, 30);

        txtRetenueGarantie.setForeground(new java.awt.Color(51, 51, 51));
        txtRetenueGarantie.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtRetenueGarantie.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        pAccueil.add(txtRetenueGarantie);
        txtRetenueGarantie.setBounds(200, 480, 240, 30);

        jLabel6.setForeground(new java.awt.Color(0, 102, 255));
        jLabel6.setText("Matricule de l'ordonnateur  : ");
        pAccueil.add(jLabel6);
        jLabel6.setBounds(20, 10, 200, 26);
        pAccueil.add(agentComp);
        agentComp.setBounds(230, 10, 550, 26);

        pRIB.setBackground(new java.awt.Color(226, 226, 226));
        pRIB.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Relevé d'identité bancaire du bénéficiare ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 255))); // NOI18N
        pRIB.setOpaque(false);

        cboRIB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboRIBActionPerformed(evt);
            }
        });

        btnModiierRIB.setText("Modifier le RIB de ce contrat");
        btnModiierRIB.setStyle(5);
        btnModiierRIB.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModiierRIBActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pRIBLayout = new javax.swing.GroupLayout(pRIB);
        pRIB.setLayout(pRIBLayout);
        pRIBLayout.setHorizontalGroup(
            pRIBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRIBLayout.createSequentialGroup()
                .addGroup(pRIBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboRIB, 0, 352, Short.MAX_VALUE)
                    .addGroup(pRIBLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnModiierRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        pRIBLayout.setVerticalGroup(
            pRIBLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRIBLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cboRIB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                .addComponent(btnModiierRIB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        pAccueil.add(pRIB);
        pRIB.setBounds(400, 50, 370, 126);

        buttonGroup1.add(rdbLC);
        rdbLC.setText("LETTRE COMMANDE");
        pAccueil.add(rdbLC);
        rdbLC.setBounds(50, 540, 210, 23);

        buttonGroup1.add(rdbMarche);
        rdbMarche.setText("MARCHE");
        pAccueil.add(rdbMarche);
        rdbMarche.setBounds(280, 540, 86, 23);

        ongletBCA.addTab("Détail du contrat", pAccueil);

        pDetailCommande.setLayout(new java.awt.BorderLayout());
        pDetailCommande.add(bcaFacture, java.awt.BorderLayout.CENTER);

        btnEnregistrerFacture.setText("Enregistrer le contrat et le détails des coûts  ci-dessus ");
        btnEnregistrerFacture.setStyle(5);
        btnEnregistrerFacture.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerFactureActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnregistrerFacture);

        pDetailCommande.add(jPanel1, java.awt.BorderLayout.SOUTH);

        ongletBCA.addTab("Elements de coût", pDetailCommande);

        getContentPane().add(ongletBCA, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboFournisseurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboFournisseurActionPerformed
        // TODO add your handling code here:
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
        if (f != null) {
            txtAdresseFournisseur.setText(f.getRaisonSociale() + " \n" + f.getAdresse() + "\n RC :" + f.getRegistreCommerce());
            chargerComptes(f.getFournisseurID());
        }

    }//GEN-LAST:event_cboFournisseurActionPerformed

    private void chargerComptes(String fournisseurID) {
        cboRIB.removeAllItems();
        List<VueFournisseurRIB> list = GrecoServiceFactory.getBanqueService().ribByFournisseur(fournisseurID);
        if (list != null) {
            cboRIB.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() > 1) {
                cboRIB.setSelectedIndex(-1);
            }
        }
    }

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(millesime, organisationID, s.getStructureID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (txtRetenueGarantie.getValue() == null) {
                int res = GrecoOptionPane.showConfirmDialog("Vous n'avez pas préciser la retenue de garantie. Voulez vous néanmoins continuer ?");
                if (res == JOptionPane.NO_OPTION) {
                    return;
                }
            }

            Number dispo;
            if (txtDisponible.getValue() != null) {
                dispo = (Number) txtDisponible.getValue();
                double ttc = bcaFacture.getLignesFacture().getMontantTTC();
                if (ttc > dispo.doubleValue()) {
                    int rep = GrecoOptionPane.showConfirmDialog("Le disponible sur l'imputation est insuffant pour couvrir ce contrat. Voulez vous neanmoins enregistrer le contrat ?");
                    if (rep == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                if (currentBCA == null) {
                    currentBCA = new Bca();
                    remplirBCA();
                    try {
                        String newBcaID = GrecoServiceFactory.getBonCommandeService().ajouter(currentBCA);
                        currentBCA.setBcaID(newBcaID);
//                    GrecoSession.notifications.success();
//                    JOptionPane.showMessageDialog(this, "Bon de commande enregistré avec succès ");
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    }
                } else {
                    remplirBCA();
                    try {
                        GrecoServiceFactory.getBonCommandeService().modifier(currentBCA);
//                    GrecoSession.notifications.success();
//                    JOptionPane.showMessageDialog(this, "Bon de commande modifié ");
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    }
                }
                //enregistrement des lignes du bca
                try {
                    //suppression de toutes les lignes
                    GrecoServiceFactory.getBonCommandeService().supprimerTousArticles(currentBCA.getBcaID(),
                            GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    //enregistrement des nouvelles
                    int nbLigneErronees = 0;
                    List<WLigneFacture> list = bcaFacture.getLignesFacture().getLignes();
                    for (WLigneFacture wlf : list) {
                        if (wlf.getReference() != null && !StringUtil.isNullOrEmpty(wlf.getDesignation())) {
                            BcaArticles l = new BcaArticles();
                            l.setAmId(wlf.getId().toString());
                            l.setBcaID(currentBCA.getBcaID());
                            l.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                            l.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                            l.setPrixUnitaire(BigDecimal.valueOf(wlf.getPrixUnitaire()));
                            l.setQuantite(wlf.getQuantite());

                            try {
                                GrecoServiceFactory.getBonCommandeService().ajouterLigne(l);
                            } catch (Exception e) {
                                nbLigneErronees++;
                            }
                        }
                    }
                    if (nbLigneErronees > 0) {
                        Toolkit.getDefaultToolkit().beep();
                        GrecoOptionPane.showWarningDialog("Enregistrement du contrat avec erreurs \n" + nbLigneErronees + "ligne(s) de la facture n'ont pas pu être enregistrées.\n\n" + "Veuillez réessayer SVP ...");
                    } else if (rdbLC.isSelected()) {
                        GrecoOptionPane.showSuccessDialog("LETTRE COMMANDE enregistré avec succès");
                    } else if (rdbMarche.isSelected()) {
                        GrecoOptionPane.showSuccessDialog("MARCHE enregistré avec succès");
                    }
                } catch (Exception e) {
                }
            }

        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        txtDisponible.setValue(null);
        txtRetenueGarantie.setValue(null);
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void cboImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboImputationActionPerformed
        // TODO add your handling code here:
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op != null) {
            BigDecimal montant = GrecoServiceFactory.getOperationService().getDisponible(op);
            txtDisponible.setValue(montant);
//            txtRetenueGarantie.setValue(op.getAe());
        }
    }//GEN-LAST:event_cboImputationActionPerformed

    private void btnEnregistrerFactureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerFactureActionPerformed
        // TODO add your handling code here:
        btnEnregistrerActionPerformed(evt);
    }//GEN-LAST:event_btnEnregistrerFactureActionPerformed

    private void cboRIBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboRIBActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboRIBActionPerformed

    private void btnModiierRIBActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModiierRIBActionPerformed
        // TODO add your handling code here:
        modifierRIB();
    }//GEN-LAST:event_btnModiierRIBActionPerformed

    private void modifierRIB() {
        VueFournisseurRIB v = (VueFournisseurRIB) cboRIB.getSelectedItem();
        if (v != null) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sûr de vouloir associer le RIB " + v.toString() + " à ce contrat ?");
            if (res == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getBonCommandeService().modifierRIB(currentBCA.getBcaID(), v.getRib(), GrecoSession.USER_CONNECTED.getLogin(),
                            GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                            Crypto.encrypt("Modification du RIB du contrat "), GrecoSession.USER_CONNECTED.getLogin(), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                            GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.DEPENSES, 3);

                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("Le RIB a été pris en compte ");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner un RIB dans la liste ou créer en un ...");
        }
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private com.siicore.facture.WPanelFacture bcaFacture;
    private javax.swing.JButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnEnregistrerFacture;
    private cm.eusoworks.tools.ui.GButton btnModiierRIB;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboFournisseur;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboRIB;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane ongletBCA;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pDetailCommande;
    private javax.swing.JPanel pEntete;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel pPrestataire;
    private javax.swing.JPanel pRIB;
    private javax.swing.JRadioButton rdbLC;
    private javax.swing.JRadioButton rdbMarche;
    private javax.swing.JTextArea txtAdresseFournisseur;
    private javax.swing.JFormattedTextField txtDisponible;
    private javax.swing.JTextArea txtEntete1;
    private javax.swing.JTextArea txtEntete2;
    private javax.swing.JTextArea txtEntete3;
    private javax.swing.JTextArea txtEntete4;
    private javax.swing.JTextArea txtEntete5;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtRetenueGarantie;
    // End of variables declaration//GEN-END:variables

    public void chargerLigne(WLigneFacture wlf) {
        try {
            Article am = GrecoServiceFactory.getMercurialeService().getArticle(millesime, wlf.getReference().toString());
            if (am != null) {
                wlf.setDesignation(am.getDesignation());
                Double prixLocalite = am.getPrixDeReference().doubleValue();
                Double marge = am.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                wlf.setPrixUnitaire(prixLocalite);
                wlf.setPuMin(Double.valueOf(0));
                wlf.setPuMax(prixLocalite + marge);
                wlf.setQuantite(1);
                wlf.setReference(am.getRefArticle());
                wlf.setId(am.getAmId());
            }
        } catch (Exception e) {

        }
    }

    public boolean validerFacture() {
        return true;
    }

}
