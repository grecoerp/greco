/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import cm.eusoworks.renderer.ComboOperationBudgetaireRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WLigneFacture;
import java.awt.Dimension;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author macbookair
 */
public class DecisionNewDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    String millesime;
    String organisationID;
    Decision currentDecision = null;
//    Organisation org;

    public DecisionNewDialog(JFrame parent, boolean modal, String millesime, String orgID, Decision bca) {
        super(parent, modal);
        initComponents();
        this.millesime = millesime;
//        this.org = org;
        this.organisationID = orgID;
        cboImputation.setRenderer(new ComboOperationBudgetaireRenderer());
        loadStructureOrganisation();
        loadFournisseurs();
        AutoCompleteDecorator.decorate(cboFournisseur);
        AutoCompleteDecorator.decorate(cboRIB);
        //AutoCompleteDecorator.decorate(cboImputation);
        this.currentDecision = bca;
        initBCAInfos();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Décisions ");
        pack();
        setPreferredSize(new Dimension(890, 750));
        setLocationRelativeTo(null);
    }

    private void initBCAInfos() {
//        txtEntete1.setText(this.org.getLibelle());
        if (currentDecision != null) {
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentDecision.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                if (f.getFournisseurID().equalsIgnoreCase(currentDecision.getFournisseurID())) {
                    cboFournisseur.setSelectedIndex(i);
                    rdbContribuable.setSelected(true);
                    break;
                }
            }
            String numRIB = currentDecision.getRib();
            if (numRIB != null && !numRIB.isEmpty()) {
                try {
                    for (int i = 0; i < cboRIB.getItemCount(); i++) {
                        VueFournisseurRIB frib = (VueFournisseurRIB) cboRIB.getItemAt(i);
                        if (frib.getRib().equalsIgnoreCase(numRIB)) {
                            cboRIB.setSelectedIndex(i);
                            break;
                        }
                    }
                } catch (Exception e) {
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentDecision.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentDecision.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            txtObjet.setText(currentDecision.getObjet());
            txtReference.setText(currentDecision.getReference());
            ordonnateurComp.setMatricule(currentDecision.getOrdonnateur());

            if (currentDecision.getMatricule() != null) {
                agentComp.setMatricule(currentDecision.getMatricule());
                rdbAgent.setSelected(true);
            }

            txtNAP.setValue(currentDecision.getMontantNAP());
            txtIR.setValue(currentDecision.getMontantIR());
            txtTVA.setValue(currentDecision.getMontantTVA());

            txtOPNap.setText(currentDecision.getNumeroOPNap());
            txtOPTaxes.setText(currentDecision.getNumeroOPTaxe());

            disableComponents();
        }
    }

    private void disableComponents() {
        if (currentDecision != null) {
            if (currentDecision.getEtat() >= EtatDossier.reserve) {
                txtObjet.setEnabled(false);
                txtReference.setEnabled(false);
                ordonnateurComp.setEnabled(false);
                txtEntete1.setEnabled(false);
                txtEntete2.setEnabled(false);
                txtEntete3.setEnabled(false);
                txtEntete4.setEnabled(false);
                txtEntete5.setEnabled(false);
                cboImputation.setEnabled(false);
                cboFournisseur.setEnabled(false);
                cboTache.setEnabled(false);
                cboStructure.setEnabled(false);
                btnEnregistrer.setVisible(false);
            }
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(this.organisationID);
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);
        }

    }

    private void loadFournisseurs() {
        List<Fournisseur> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getFournisseurService().getListFournisseur();
        } catch (Exception e) {
            list = null;
        }

        if (list != null && !list.isEmpty()) {
            cboFournisseur.setModel(new DefaultComboBoxModel(list.toArray()));
            cboFournisseur.setSelectedIndex(-1);
        }
    }

    private void remplirDecision() {
        Structure s = (Structure) cboStructure.getSelectedItem();
        Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        String rib = null;
        Object ribObject = cboRIB.getSelectedItem();
        if (ribObject != null) {
            VueFournisseurRIB v = (VueFournisseurRIB) ribObject;
            if (v != null && !v.getFournisseurID().isEmpty()) {
                rib = v.getRib();
            }
        }

        currentDecision.setObjet(txtObjet.getText().trim());
        currentDecision.setReference(txtReference.getText().trim());

        currentDecision.setFournisseurID(rdbContribuable.isSelected() ? f.getFournisseurID() : null);
        currentDecision.setRib(rdbContribuable.isSelected() ? rib : null);
        currentDecision.setMatricule(rdbAgent.isSelected() ? agentComp.getMatricule() : null);
        currentDecision.setTacheID(o.getTacheID());
        currentDecision.setMillesime(millesime);
        currentDecision.setOrganisationID(organisationID);
        currentDecision.setOrdonnateur(ordonnateurComp.getMatricule());
        currentDecision.setStructureID(s.getStructureID());
        currentDecision.setActiviteID(a.getActiviteID());
        currentDecision.setTacheID(o.getTacheID());

        currentDecision.setBeneficiaire(rdbContribuable.isSelected() ? f.toString() : agentComp.getMatricule() + " - " + agentComp.getNomComplet());
        currentDecision.setSignataire(ordonnateurComp.getNomComplet());

        currentDecision.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentDecision.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        Number nap = (Number) txtNAP.getValue();
        Number tva = (Number) txtTVA.getValue();
        Number ir = (Number) txtIR.getValue();

        double doubleNAP = 0;
        double doubleIR = 0;
        double doubleTVA = 0;

        if (nap != null) {
            doubleNAP = nap.doubleValue();
        }
        if (ir != null) {
            doubleIR = ir.doubleValue();
        }
        if (tva != null) {
            doubleTVA = tva.doubleValue();
        }

        double decisionTTC = doubleNAP + doubleIR + doubleTVA;
        double decisionHT = doubleNAP + doubleIR;

        currentDecision.setMontantTTC(BigDecimal.valueOf(com.google.common.math.DoubleMath.roundToInt(decisionTTC, RoundingMode.HALF_UP)));
        currentDecision.setMontantHT(BigDecimal.valueOf(com.google.common.math.DoubleMath.roundToInt(decisionHT, RoundingMode.HALF_UP)));
        currentDecision.setMontantIR(BigDecimal.valueOf(com.google.common.math.DoubleMath.roundToInt(doubleIR, RoundingMode.HALF_UP)));
        currentDecision.setMontantTVA(BigDecimal.valueOf(com.google.common.math.DoubleMath.roundToInt(doubleTVA, RoundingMode.HALF_UP)));
        currentDecision.setMontantNAP(BigDecimal.valueOf(com.google.common.math.DoubleMath.roundToInt(doubleNAP, RoundingMode.HALF_UP)));
        currentDecision.setMontant(BigDecimal.valueOf(com.google.common.math.DoubleMath.roundToInt(decisionTTC, RoundingMode.HALF_UP)));

        currentDecision.setNumeroOPNap(txtOPNap.getText());
        currentDecision.setNumeroOPTaxe(txtOPTaxes.getText());
    }

    private boolean controlData() {
        boolean res = true;
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner la structure");
            return false;
        }

        if (ordonnateurComp.getMatricule() == null) {
            GrecoOptionPane.showErrorDialog("Veuillez saisir le matricule de l'ordonnateur ");
            return false;
        }
        if (!rdbAgent.isSelected() && !rdbContribuable.isSelected()) {
            GrecoOptionPane.showErrorDialog("Veuillez choisir le type de bénéficiaire porté sur la décision  ");
            return false;
        }
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
        if (f == null && rdbContribuable.isSelected()) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner le prestataire de service");
            return false;
        }
        if (rdbAgent.isSelected() && agentComp.getMatricule().isEmpty()) {
            GrecoOptionPane.showErrorDialog("Veuillez entrer le matricule de l'agent  ");
            return false;
        }
        Activite a = (Activite) cboTache.getSelectedItem();
        if (a == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner la tâche ");
            return false;
        }
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner l'imputation ");
            return false;
        }
        if (txtObjet.getText().isEmpty()) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner l'objet de la commande ");
            return false;
        }

        Number nap = (Number) txtNAP.getValue();
        Number tva = (Number) txtTVA.getValue();
        Number ir = (Number) txtIR.getValue();

        double doubleNAP = 0;
        double doubleIR = 0;
        double doubleTVA = 0;

        if (nap != null) {
            doubleNAP = nap.doubleValue();
        }
        if (ir != null) {
            doubleIR = ir.doubleValue();
        }
        if (tva != null) {
            doubleTVA = tva.doubleValue();
        }

        if (doubleNAP <= 0) {
            GrecoOptionPane.showErrorDialog("Veuillez saisir au moins le montant à payer ");
            return false;
        }
        if (txtOPNap.getText().trim().isEmpty()) {
            GrecoOptionPane.showErrorDialog("Vous n'avez pas renseigné le numéro de l'Ordre de Paiement du Net à Payer ");
            return false;
        }
        if ((doubleIR > 0) || (doubleTVA > 0)) {
            if (txtOPTaxes.getText().trim().isEmpty()) {
                GrecoOptionPane.showErrorDialog("Vous n'avez pas renseigné le numéro de l'Ordre de Paiement des taxes ");
                return false;
            }
        }
        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pEntete = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtEntete1 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtEntete2 = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtEntete3 = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtEntete4 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtEntete5 = new javax.swing.JTextArea();
        buttonGroup1 = new javax.swing.ButtonGroup();
        ongletBCA = new javax.swing.JTabbedPane();
        pAccueil = new javax.swing.JPanel();
        pPrestataire = new javax.swing.JPanel();
        cboFournisseur = new javax.swing.JComboBox();
        agentComp = new cm.eusoworks.component.AgentComponent();
        rdbContribuable = new javax.swing.JRadioButton();
        rdbAgent = new javax.swing.JRadioButton();
        jLabel14 = new javax.swing.JLabel();
        cboRIB = new javax.swing.JComboBox();
        pObjetCommande = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        btnEnregistrer = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        txtDisponible = new javax.swing.JFormattedTextField();
        jLabel22 = new javax.swing.JLabel();
        txtNAP = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        ordonnateurComp = new cm.eusoworks.component.AgentComponent();
        jLabel23 = new javax.swing.JLabel();
        txtTVA = new javax.swing.JFormattedTextField();
        lblii = new javax.swing.JLabel();
        txtIR = new javax.swing.JFormattedTextField();
        txtOPNap = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        txtOPTaxes = new javax.swing.JFormattedTextField();

        jLabel8.setText("Entête 1 : ");

        txtEntete1.setColumns(20);
        txtEntete1.setRows(2);
        jScrollPane3.setViewportView(txtEntete1);

        jLabel9.setText("Entête 2 : ");

        txtEntete2.setColumns(20);
        txtEntete2.setRows(2);
        jScrollPane4.setViewportView(txtEntete2);

        jLabel10.setText("Entête 3 : ");

        txtEntete3.setColumns(20);
        txtEntete3.setRows(2);
        jScrollPane5.setViewportView(txtEntete3);

        jLabel11.setText("Entête 4 : ");

        txtEntete4.setColumns(20);
        txtEntete4.setRows(2);
        jScrollPane6.setViewportView(txtEntete4);

        jLabel12.setText("Entête 5 : ");

        txtEntete5.setColumns(20);
        txtEntete5.setRows(2);
        jScrollPane7.setViewportView(txtEntete5);

        javax.swing.GroupLayout pEnteteLayout = new javax.swing.GroupLayout(pEntete);
        pEntete.setLayout(pEnteteLayout);
        pEnteteLayout.setHorizontalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(131, Short.MAX_VALUE))
        );
        pEnteteLayout.setVerticalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane5)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane6)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane7)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");

        pAccueil.setBackground(new java.awt.Color(255, 255, 255));

        pPrestataire.setBackground(new java.awt.Color(226, 226, 226));
        pPrestataire.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Bénéficiaire de la décision", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 255))); // NOI18N
        pPrestataire.setOpaque(false);

        cboFournisseur.setFont(new java.awt.Font("Lucida Grande", 0, 15)); // NOI18N
        cboFournisseur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboFournisseurActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdbContribuable);
        rdbContribuable.setText("à un Contribuable");

        buttonGroup1.add(rdbAgent);
        rdbAgent.setText("à un Agent ");

        jLabel14.setText("RIB : ");

        javax.swing.GroupLayout pPrestataireLayout = new javax.swing.GroupLayout(pPrestataire);
        pPrestataire.setLayout(pPrestataireLayout);
        pPrestataireLayout.setHorizontalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addComponent(rdbContribuable, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(16, 16, 16)
                .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addGap(114, 114, 114)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addComponent(cboRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 360, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(rdbAgent, javax.swing.GroupLayout.PREFERRED_SIZE, 154, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(14, 14, 14)
                .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, 544, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pPrestataireLayout.setVerticalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbContribuable, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(7, 7, 7)
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboRIB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbAgent)
                    .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pObjetCommande.setBackground(new java.awt.Color(255, 255, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Objet de la commande ...", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 204))); // NOI18N

        jLabel2.setText("Tâche : ");

        jLabel3.setText("Reference : ");

        jLabel4.setText("Objet : ");

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });

        cboImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboImputationActionPerformed(evt);
            }
        });

        txtObjet.setColumns(20);
        txtObjet.setRows(2);
        jScrollPane2.setViewportView(txtObjet);

        jLabel7.setText("Imputation : ");

        txtReference.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        jLabel5.setText("Structure : ");

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pObjetCommandeLayout = new javax.swing.GroupLayout(pObjetCommande);
        pObjetCommande.setLayout(pObjetCommandeLayout);
        pObjetCommandeLayout.setHorizontalGroup(
            pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pObjetCommandeLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(cboStructure, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pObjetCommandeLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(cboTache, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pObjetCommandeLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(cboImputation, javax.swing.GroupLayout.PREFERRED_SIZE, 640, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pObjetCommandeLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(13, 13, 13)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pObjetCommandeLayout.createSequentialGroup()
                .addGap(1, 1, 1)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(3, 3, 3)
                .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 630, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pObjetCommandeLayout.setVerticalGroup(
            pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pObjetCommandeLayout.createSequentialGroup()
                .addGap(2, 2, 2)
                .addGroup(pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboStructure, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboTache, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboImputation, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pObjetCommandeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pObjetCommandeLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(0, 153, 102));
        jLabel21.setText("AE Disponible : ");

        txtDisponible.setEditable(false);
        txtDisponible.setForeground(new java.awt.Color(0, 153, 102));
        txtDisponible.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtDisponible.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N

        jLabel22.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel22.setForeground(new java.awt.Color(51, 51, 51));
        jLabel22.setText("Net à Payer");

        txtNAP.setForeground(new java.awt.Color(51, 51, 51));
        txtNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtNAP.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N

        jLabel6.setForeground(new java.awt.Color(0, 102, 255));
        jLabel6.setText("Matricule de l'ordonnateur  : ");

        jLabel23.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel23.setForeground(new java.awt.Color(51, 51, 51));
        jLabel23.setText("TVA : ");

        txtTVA.setForeground(new java.awt.Color(51, 51, 51));
        txtTVA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtTVA.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N

        lblii.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        lblii.setForeground(new java.awt.Color(51, 51, 51));
        lblii.setText("IR  : ");

        txtIR.setForeground(new java.awt.Color(51, 51, 51));
        txtIR.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtIR.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N

        try {
            txtOPNap.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####A")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtOPNap.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N

        jLabel1.setText("OP du Net à payer  ");

        jLabel13.setText("OP des taxes");

        try {
            txtOPTaxes.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####A")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtOPTaxes.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N

        javax.swing.GroupLayout pAccueilLayout = new javax.swing.GroupLayout(pAccueil);
        pAccueil.setLayout(pAccueilLayout);
        pAccueilLayout.setHorizontalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(ordonnateurComp, javax.swing.GroupLayout.PREFERRED_SIZE, 536, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(pPrestataire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(pObjetCommande, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(txtDisponible, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(220, 220, 220)
                .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(txtTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(txtOPNap, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(lblii, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(txtIR, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(70, 70, 70)
                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(txtOPTaxes, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        pAccueilLayout.setVerticalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(ordonnateurComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addComponent(pPrestataire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(12, 12, 12)
                .addComponent(pObjetCommande, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(2, 2, 2)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel21, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtDisponible, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(10, 10, 10)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtOPNap, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblii, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIR, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtOPTaxes, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        ongletBCA.addTab("Détails de la décision", pAccueil);

        getContentPane().add(ongletBCA, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboFournisseurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboFournisseurActionPerformed
        // TODO add your handling code here:
        Fournisseur f = null;
        try {
            Object o = cboFournisseur.getSelectedItem();
            if(o != null){
                f = (Fournisseur)o ;
                chargerComptes(f.getFournisseurID());
            }
            
        } catch (Exception e) {
            f = null;
        }

        
    }//GEN-LAST:event_cboFournisseurActionPerformed

    private void chargerComptes(String fournisseurID) {
        if (fournisseurID != null) {
            cboRIB.removeAllItems();
            List<VueFournisseurRIB> list = GrecoServiceFactory.getBanqueService().ribByFournisseur(fournisseurID);
            if (list != null) {
                cboRIB.setModel(new DefaultComboBoxModel(list.toArray()));
                if (list.size() > 1) {
                    cboRIB.setSelectedIndex(-1);
                }
            } else {
                cboRIB.setModel(new DefaultComboBoxModel(new ArrayList().toArray()));
            }
        }

    }

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(millesime, organisationID, s.getStructureID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {

            Number dispo;
            if (txtDisponible.getValue() != null) {
                dispo = (Number) txtDisponible.getValue();

                Number nap = (Number) txtNAP.getValue();
                Number tva = (Number) txtTVA.getValue();
                Number ir = (Number) txtIR.getValue();

                double doubleNAP = 0;
                double doubleIR = 0;
                double doubleTVA = 0;

                if (nap != null) {
                    doubleNAP = nap.doubleValue();
                }
                if (ir != null) {
                    doubleIR = ir.doubleValue();
                }
                if (tva != null) {
                    doubleTVA = tva.doubleValue();
                }

                double decisionTTC = doubleNAP + doubleIR + doubleTVA;

                if (decisionTTC > dispo.doubleValue()) {
                    int rep = GrecoOptionPane.showConfirmDialog("Le disponible sur l'imputation est insuffant pour couvrir cette décision. Voulez-vous néanmoins enregistrer la décision?");
                    if (rep == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                if (currentDecision == null) {
                    currentDecision = new Decision();
                    remplirDecision();
                    try {
                        String newBcaID = GrecoServiceFactory.getDecisionService().ajouterDecision(currentDecision);
                        currentDecision.setDecisionID(newBcaID);
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    }
                } else {
                    remplirDecision();
                    try {
                        GrecoServiceFactory.getDecisionService().modifierDecision(currentDecision);
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    }
                }

                GrecoOptionPane.showSuccessDialog("Décision enregistrée avec succès");

            }

        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        txtDisponible.setValue(null);
        txtNAP.setValue(null);
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void cboImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboImputationActionPerformed
        // TODO add your handling code here:
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op != null) {
            BigDecimal montant = GrecoServiceFactory.getOperationService().getDisponible(op);
            txtDisponible.setValue(montant);
            // txtNAP.setValue(op.getAe());
        }
    }//GEN-LAST:event_cboImputationActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboFournisseur;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboRIB;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lblii;
    private javax.swing.JTabbedPane ongletBCA;
    private cm.eusoworks.component.AgentComponent ordonnateurComp;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pEntete;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel pPrestataire;
    private javax.swing.JRadioButton rdbAgent;
    private javax.swing.JRadioButton rdbContribuable;
    private javax.swing.JFormattedTextField txtDisponible;
    private javax.swing.JTextArea txtEntete1;
    private javax.swing.JTextArea txtEntete2;
    private javax.swing.JTextArea txtEntete3;
    private javax.swing.JTextArea txtEntete4;
    private javax.swing.JTextArea txtEntete5;
    private javax.swing.JFormattedTextField txtIR;
    private javax.swing.JFormattedTextField txtNAP;
    private javax.swing.JFormattedTextField txtOPNap;
    private javax.swing.JFormattedTextField txtOPTaxes;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtTVA;
    // End of variables declaration//GEN-END:variables

    public void chargerLigne(WLigneFacture wlf) {
        try {
            Article am = GrecoServiceFactory.getMercurialeService().getArticle(millesime, wlf.getReference().toString());
            if (am != null) {
                wlf.setDesignation(am.getDesignation());
                Double prixLocalite = am.getPrixDeReference().doubleValue();
                Double marge = am.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                wlf.setPrixUnitaire(prixLocalite);
                wlf.setPuMin(Double.valueOf(0));
                wlf.setPuMax(prixLocalite + marge);
                wlf.setQuantite(1);
                wlf.setReference(am.getRefArticle());
                wlf.setId(am.getAmId());
            }
        } catch (Exception e) {

        }
    }

    public boolean validerFacture() {
        return true;
    }

}
