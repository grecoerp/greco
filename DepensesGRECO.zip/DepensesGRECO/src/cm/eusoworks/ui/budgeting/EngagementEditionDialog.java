/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.DialogOpenMode;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.entities.view.VueEngagementLivre;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.EngagementTypeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.util.StringUtil;
import java.awt.CardLayout;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.table.TableColumn;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementEditionDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<VueEngagementDossier> listDossiers = ObservableCollections.observableList(new ArrayList<VueEngagementDossier>());
    VueEngagementDossier selectedDossier = null;
    List<VueEngagementDossier> dossiersSelectionnée = null;

    GrecoReports fonctions = new GrecoReports();
    int wSearch = 600, hSearch = 300;
    int openMode = DialogOpenMode.enregistre;
//    private CurvesProgressPanel glasspane;

    public EngagementEditionDialog(java.awt.Frame parent, boolean modal, int mode) {
        super(parent, modal);
        initComponents();
        setSize(850, 600);
        this.openMode = mode;
        initMode();
        panelRecherche.setBounds((int) ((getWidth() - wSearch) / 2), (int) ((getHeight() - hSearch) / 2), wSearch, hSearch);
        glasspane.setText("Recherche des dossiers correspondant aux critères ...");
//        this.setGlassPane(glasspane);
        loadOrganisations();
        loadExercicesBudgetisation();
        loadTypeEngagement();
        setLocationRelativeTo(null);

        TableColumn colorColumn = tableDossiers.getColumn(0);
        colorColumn.setCellRenderer(new EngagementTypeRenderer());
    }

    public List<VueEngagementDossier> getListDossiers() {
        return listDossiers;
    }

    public void setListDossiers(List<VueEngagementDossier> listDossiers) {
        this.listDossiers = listDossiers;
    }

    public VueEngagementDossier getSelectedDossier() {
        return selectedDossier;
    }

    public void setSelectedDossier(VueEngagementDossier selectedDossier) {
        this.selectedDossier = selectedDossier;
    }

    public List<VueEngagementDossier> getDossiersSelectionnée() {
        return dossiersSelectionnée;
    }

    public void setDossiersSelectionnée(List<VueEngagementDossier> dossiersSelectionnée) {
        this.dossiersSelectionnée = dossiersSelectionnée;
    }

    private void initMode() {
        loadTypeEngagement();
    }


    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserActives(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            } else {
                cboExercice.setSelectedIndex(cboExercice.getItemCount() - 1);
            }
        }
    }

    private void loadTypeEngagement() {
        List<EngagementType> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getEngagementService().getEngagementType();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            list.add(null);
            cboTypeengagement.setModel(new DefaultComboBoxModel(list.toArray()));
            cboTypeengagement.setSelectedIndex(-1);
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        return true;
    }

    private void imprimerFicheEngagement(String engagementID, String numDossier) {

        VueEngagementLivre vuedossier = new VueEngagementLivre();
        vuedossier = GrecoServiceFactory.getEngagementService().getFicheDossier(numDossier);
        //impression de la fiche
        if (vuedossier != null) {
            GrecoImages logo = new GrecoImages();
            Image armoirieCM = null;//new siiResources.Images();
            HashMap parameters = fonctions.mainParameters();
            parameters.put("armoirieCM", armoirieCM);
            parameters.put("logo", logo.logoOrganisation());
            parameters.put("app", logo.logo());
            parameters.put("montantLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, vuedossier.getMontant()));
            parameters.put("user", GrecoSession.USER_CONNECTED.getNom());
            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

            //datasource principale
            List<VueEngagementLivre> list = new ArrayList<>();
            list.add(vuedossier);
            JRDataSource dataSource = new JRBeanCollectionDataSource(list);

            //datasource du sous etat
            List<LiquidationDroits> listSousEtat = new ArrayList<>();
            listSousEtat = null; //GrecoServiceFactory.getDroitsService().listeDroitsEngagement(engagementID);
            JRDataSource dataSourcesousEtat = new JRBeanCollectionDataSource(listSousEtat);

            //passage des parametres du sousetat
            parameters.put("sousetat", fonctions.ficheEngagementDroits());
            parameters.put("jrds", dataSourcesousEtat);

            //impression de la fiche
            try {
                JasperPrint print = JasperFillManager.fillReport(fonctions.ficheEngagement(), parameters, dataSource);
                JRHelper.viewReport(print);
            } catch (Exception e) {
                e.printStackTrace();
            }
            glasspane.arret();
        }
    }
    
    private void search(boolean advanced) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String numdossier = ((String) txtnumDossier.getValue());
        String etat = EtatDossier.getListeEtat(this.openMode);
        String engagementType = null;
        String cpte = null;
        Date dateEnregDebut = null;
        Date dateEnregFin = null;
        Date dateValidDebut = null;
        Date dateValidFin = null;
        String beneficiare = null;

        if (advanced) {
            EngagementType et = (EngagementType) cboTypeengagement.getSelectedItem();
            if (et != null) {
                engagementType = et.getTypeID();
            }
            cpte = txtCompteBudgetaire.getText().isEmpty() ? null : txtCompteBudgetaire.getText();
            dateEnregDebut = dtpEnregistrementDebut.getDate();
            dateEnregFin = dtpEnregistrementfin.getDate();
            dateValidDebut = dtpDateValidationDebut.getDate();
            dateValidFin = dtpDateValidationFin.getDate();
            beneficiare = txtBeneficiaire.getText().isEmpty() ? null : txtBeneficiaire.getText();
        }

        glasspane.attente();
        List<VueEngagementDossier> l = GrecoServiceFactory.getEngagementService().getDossiers(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut, dateEnregFin, dateValidDebut, dateValidFin, beneficiare);
        listDossiers.clear();
        if (l != null) {
            for (VueEngagementDossier v : l) {
                listDossiers.add(v);
            }
        } 
        glasspane.arret();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        panelEntete = new javax.swing.JPanel();
        panelExercice = new javax.swing.JPanel();
        jPanel4 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        txtnumDossier = new javax.swing.JFormattedTextField();
        jPanel1 = new javax.swing.JPanel();
        btnOptions = new cm.eusoworks.tools.ui.GButton();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        panelRecherche = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cboTypeengagement = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        txtCompteBudgetaire = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dtpEnregistrementDebut = new org.jdesktop.swingx.JXDatePicker();
        dtpEnregistrementfin = new org.jdesktop.swingx.JXDatePicker();
        dtpDateValidationDebut = new org.jdesktop.swingx.JXDatePicker();
        dtpDateValidationFin = new org.jdesktop.swingx.JXDatePicker();
        txtBeneficiaire = new javax.swing.JTextField();
        btnRechercheAvance = new cm.eusoworks.tools.ui.GButton();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        panelTable = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        btnFicheEngagement = new cm.eusoworks.tools.ui.GButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableDossiers = new org.jdesktop.swingx.JXTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Recherche d'un dossier ");

        panelEntete.setLayout(new java.awt.CardLayout());

        panelExercice.setBackground(new java.awt.Color(255, 255, 255));
        panelExercice.setLayout(new java.awt.BorderLayout());

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 629, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(6, 6, 6)
                .addComponent(jLabel7))
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        panelExercice.add(jPanel4, java.awt.BorderLayout.NORTH);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("N° de dossier : ");

        try {
            txtnumDossier.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("U######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtnumDossier.setFont(new java.awt.Font("Arial Black", 0, 16)); // NOI18N
        txtnumDossier.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtnumDossierKeyReleased(evt);
            }
        });

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnOptions.setForeground(new java.awt.Color(0, 0, 0));
        btnOptions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/search.png"))); // NOI18N
        btnOptions.setText("Options...");
        btnOptions.setCouleur(3);
        btnOptions.setStyle(1);
        btnOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOptionsActionPerformed(evt);
            }
        });
        jPanel1.add(btnOptions);

        btnRechercher.setText("Rechercher ...");
        btnRechercher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnRechercher.setStyle(3);
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });
        jPanel1.add(btnRechercher);

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(34, 34, 34)
                                .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addGap(18, 18, 18)
                                .addComponent(txtnumDossier, javax.swing.GroupLayout.PREFERRED_SIZE, 104, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(0, 39, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtnumDossier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(51, 51, 51)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(51, Short.MAX_VALUE))
        );

        panelExercice.add(jPanel2, java.awt.BorderLayout.WEST);

        panelEntete.add(panelExercice, "exercice");

        panelRecherche.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(125, 161, 237));

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Recherche avancée ");
        jPanel5.add(jLabel3);

        panelRecherche.add(jPanel5, java.awt.BorderLayout.NORTH);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel4.setText("Type d'engagement ");

        cboTypeengagement.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel5.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel5.setText("Compte budgétaire ");

        txtCompteBudgetaire.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        jLabel6.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel6.setText("Date d'enregistrement entre le ");

        jLabel9.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel9.setText("et le ");

        jLabel10.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel10.setText("Date de validation entre le ");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel11.setText("et le ");

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire (intitulé)");

        dtpEnregistrementfin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dtpEnregistrementfinActionPerformed(evt);
            }
        });

        btnRechercheAvance.setText("Rechercher les dossiers répondant aux critères ");
        btnRechercheAvance.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRechercheAvance.setStyle(3);
        btnRechercheAvance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercheAvanceActionPerformed(evt);
            }
        });

        btnRetour.setForeground(new java.awt.Color(0, 0, 0));
        btnRetour.setText("<<< Retour     ");
        btnRetour.setCouleur(3);
        btnRetour.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4)
                        .addGap(84, 84, 84)
                        .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel5)
                        .addGap(87, 87, 87)
                        .addComponent(txtCompteBudgetaire, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel10)
                        .addGap(47, 47, 47)
                        .addComponent(dtpDateValidationDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpDateValidationFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(212, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel4))
                    .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel5))
                    .addComponent(txtCompteBudgetaire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateValidationDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateValidationFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(13, Short.MAX_VALUE))
        );

        panelRecherche.add(jPanel6, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelRecherche, "recherche");

        getContentPane().add(panelEntete, java.awt.BorderLayout.NORTH);

        panelTable.setLayout(new java.awt.BorderLayout());

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));

        btnFicheEngagement.setText("Fiche d'Engagement");
        btnFicheEngagement.setCouleur(4);
        btnFicheEngagement.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnFicheEngagement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFicheEngagementActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFicheEngagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnFicheEngagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(177, Short.MAX_VALUE))
        );

        panelTable.add(jPanel7, java.awt.BorderLayout.WEST);

        tableDossiers.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableDossiers.setGridColor(new java.awt.Color(204, 204, 204));
        tableDossiers.setRowHeight(24);
        tableDossiers.setSelectionBackground(new java.awt.Color(91, 118, 173));
        tableDossiers.setShowGrid(true);
        tableDossiers.getTableHeader().setReorderingAllowed(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listDossiers}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${type}"));
        columnBinding.setColumnName("T");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("N° Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Beneficiaire");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${compte}"));
        columnBinding.setColumnName("Compte");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${etatDossier}"));
        columnBinding.setColumnName("Etat du dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedDossier}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane2.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setMinWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setMaxWidth(30);
            tableDossiers.getColumnModel().getColumn(1).setMinWidth(100);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(100);
            tableDossiers.getColumnModel().getColumn(1).setMaxWidth(150);
            tableDossiers.getColumnModel().getColumn(2).setMinWidth(110);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(110);
            tableDossiers.getColumnModel().getColumn(2).setMaxWidth(110);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(250);
            tableDossiers.getColumnModel().getColumn(4).setMinWidth(80);
            tableDossiers.getColumnModel().getColumn(4).setPreferredWidth(80);
            tableDossiers.getColumnModel().getColumn(4).setMaxWidth(120);
        }

        panelTable.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelTable, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void dtpEnregistrementfinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dtpEnregistrementfinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dtpEnregistrementfinActionPerformed

    private void btnRechercheAvanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercheAvanceActionPerformed
        // recherche des elements
        rechercher(true);
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRechercheAvanceActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // recherche des elements
        rechercher(false);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void btnOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOptionsActionPerformed
        // TODO add your handling code here:
        optionsRecherche();
    }//GEN-LAST:event_btnOptionsActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void txtnumDossierKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnumDossierKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            rechercher(false);
        }
    }//GEN-LAST:event_txtnumDossierKeyReleased

    private void btnFicheEngagementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFicheEngagementActionPerformed
        // TODO add your handling code here:
        if(selectedDossier != null){
            glasspane.setText("Edition de la fiche d'engagement");
            glasspane.attente();
            imprimerFicheEngagement(selectedDossier.getEngagementID(), selectedDossier.getNumDossier());
            glasspane.arret();
        }
    }//GEN-LAST:event_btnFicheEngagementActionPerformed

    private void rechercher(boolean advanced) {
//        glasspane.attente();
        search(advanced);
//        glasspane.arret();
    }

    private void optionsRecherche() {
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "recherche");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EngagementEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EngagementEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EngagementEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EngagementEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new EngagementSearchDialog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnFicheEngagement;
    private cm.eusoworks.tools.ui.GButton btnOptions;
    private cm.eusoworks.tools.ui.GButton btnRechercheAvance;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboTypeengagement;
    private org.jdesktop.swingx.JXDatePicker dtpDateValidationDebut;
    private org.jdesktop.swingx.JXDatePicker dtpDateValidationFin;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementDebut;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementfin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelEntete;
    private javax.swing.JPanel panelExercice;
    private javax.swing.JPanel panelRecherche;
    private javax.swing.JPanel panelTable;
    private org.jdesktop.swingx.JXTable tableDossiers;
    private javax.swing.JTextField txtBeneficiaire;
    private javax.swing.JFormattedTextField txtCompteBudgetaire;
    private javax.swing.JFormattedTextField txtnumDossier;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
