/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.view.VueEngagementJournal;
import cm.eusoworks.entities.view.VueEngagementState;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WPanelFacture;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementConsultationDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();
    Bca currentBca = null;
    OrdreMission currentOM = null;
    Decision currentDecision = null;
    Engagement currentEngagement = null;

    List<LiquidationDroits> listRetenues = ObservableCollections.observableList(new ArrayList<LiquidationDroits>());
    LiquidationDroits selectedRetenue = null;

    List<VueEngagementJournal> journal = ObservableCollections.observableList(new ArrayList<VueEngagementJournal>());
    //composant
    WPanelFacture bcaFacture = null;

    public EngagementConsultationDialog(JFrame parent, boolean modal, Engagement current) {
        super(parent, true);
        initComponents();
        setPreferredSize(new Dimension(850, 476));
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Dossier N°:  " + current.getNumDossier());
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.currentEngagement = current;
        setLocationRelativeTo(null);
        loadStructureOrganisation();
        loadJournal();
        initEngagementUI();
    }

    private void loadJournal() {
        List<VueEngagementJournal> list = GrecoServiceFactory.getEngagementService().getJournal(currentEngagement.getEngagementID());
        if (list != null & !list.isEmpty()) {
            journal.clear();
            for (VueEngagementJournal v : list) {
                journal.add(v);
            }
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(currentEngagement.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructureImputation.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructureImputation.setSelectedIndex(-1);
        }

    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getTypeID());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        txtNumDossier.setText(currentEngagement.getNumDossier());
        txtObjet.setText(currentEngagement.getObjet().trim());
        txtReference.setText(currentEngagement.getReference().trim());
        try {
            dtpDatesignature.setDate(currentEngagement.getDateSignature());
        } catch (Exception e) {
            dtpDatesignature.setDate(null);
        }
        btnBeneficiare.setText(currentEngagement.getBeneficiaire());

        try {
            txtMontant.setValue(currentEngagement.getMontantTTC());
        } catch (Exception e) {
        }
////        //charger les droits a liquider
////        List<LiquidationDroits> list = GrecoServiceFactory.getDroitsService().listeDroitsEngagement(currentEngagement.getEngagementID());
////        if (list != null && !list.isEmpty()) {
////            listRetenues.clear();
////            for (LiquidationDroits e : list) {
////                listRetenues.add(e);
////            }
////            calculerNAP();
////        }
////
////        //appeler une fonction pour calculer le nap et les retenues
////        afficherCout();

        for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
            Structure s = (Structure) cboStructureImputation.getItemAt(i);
            if (s.getStructureID().equalsIgnoreCase(currentEngagement.getStructureID())) {
                cboStructureImputation.setSelectedIndex(i);
                break;
            }
        }

        for (int i = 0; i < cboTache.getItemCount(); i++) {
            Activite f = (Activite) cboTache.getItemAt(i);
            if (f.getActiviteID().equalsIgnoreCase(currentEngagement.getActiviteID())) {
                cboTache.setSelectedIndex(i);
                break;
            }
        }
        for (int i = 0; i < cboImputation.getItemCount(); i++) {
            OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
            if (f.getTacheID().equalsIgnoreCase(currentEngagement.getTacheID())) {
                cboImputation.setSelectedIndex(i);
                break;
            }
        }
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);

        lblEtat.setText(EtatDossier.getString(currentEngagement.getEtat()).toUpperCase());

        lblEtapeSuivante.setText(EtatDossier.getNextStep(currentEngagement.getEtat()).toUpperCase());

        //etat par phase
        try {
            VueEngagementState p = GrecoServiceFactory.getEngagementService().getEtatengagement(currentEngagement.getNumDossier());
            if (p != null) {
                SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
                if (p.isStateEngage()) {
                    lblStateEngage.setToolTipText(s.format(p.getDateEngage()));
                    try {
                        lblStateEngage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceON.png")));
                    } catch (Exception e) {
                    }
                }
                if (p.isStateLiquide()) {
                    lblStateLiquide.setToolTipText(s.format(p.getDateLiquide()));
                    try {
                        lblStateLiquide.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceON.png")));
                    } catch (Exception e) {
                    }
                }
                if (p.isStateMandate()) {
                    lblStateMandate.setToolTipText(s.format(p.getDateMandate()));
                    try {
                        lblStateMandate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceON.png")));
                    } catch (Exception e) {
                    }
                }
                if (p.isStateRegle()) {
                    lblStateRegle.setToolTipText(s.format(p.getDateRegle()));
                    try {
                        lblStateRegle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceON.png")));
                    } catch (Exception e) {
                    }
                }
            }
        } catch (Exception e) {
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        benefGroup = new javax.swing.ButtonGroup();
        radioGroup = new javax.swing.ButtonGroup();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        panelInfos = new javax.swing.JPanel();
        pDetailDecision = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnFermer = new cm.eusoworks.tools.ui.GButton();
        jPanel2 = new javax.swing.JPanel();
        pObjetCommande = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        cboStructureImputation = new javax.swing.JComboBox();
        btnTTC = new cm.eusoworks.tools.ui.GButton();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        txtSignataire = new javax.swing.JTextField();
        dtpDatesignature = new org.jdesktop.swingx.JXDatePicker();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        lblStateEngage = new javax.swing.JLabel();
        lblStateLiquide = new javax.swing.JLabel();
        lblStateMandate = new javax.swing.JLabel();
        lblStateRegle = new javax.swing.JLabel();
        panelTaxes = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableTaxes = new org.jdesktop.swingx.JXTable();
        jPanel8 = new javax.swing.JPanel();
        btnCoutRetour = new cm.eusoworks.tools.ui.GButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtNAP = new javax.swing.JFormattedTextField();
        jLabel15 = new javax.swing.JLabel();
        txtRetenues = new javax.swing.JFormattedTextField();
        panelDetails = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableJournal = new org.jdesktop.swingx.JXTable();
        jPanel5 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        lblEtat = new javax.swing.JLabel();
        lblEtapeSuivante = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Saise des dossiers d'engagements");

        jTabbedPane1.setBackground(new java.awt.Color(255, 255, 255));
        jTabbedPane1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jTabbedPane1.setOpaque(true);

        panelInfos.setBackground(new java.awt.Color(255, 255, 255));
        panelInfos.setLayout(new java.awt.CardLayout());

        pDetailDecision.setBackground(new java.awt.Color(255, 255, 255));
        pDetailDecision.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 5));

        btnFermer.setText("Fermer la fenêtre");
        btnFermer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });
        jPanel3.add(btnFermer);

        jPanel1.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 204));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "IMPUTATION", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N
        pObjetCommande.setOpaque(false);
        pObjetCommande.setLayout(null);

        jLabel6.setText("Tâche : ");
        pObjetCommande.add(jLabel6);
        jLabel6.setBounds(20, 60, 70, 30);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(20, 100, 80, 30);

        cboTache.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboTacheItemStateChanged(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 60, 480, 30);

        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 100, 290, 30);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(20, 20, 70, 30);

        cboStructureImputation.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboStructureImputationItemStateChanged(evt);
            }
        });
        pObjetCommande.add(cboStructureImputation);
        cboStructureImputation.setBounds(110, 20, 480, 30);

        btnTTC.setText("0");
        btnTTC.setCouleur(4);
        btnTTC.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnTTC.setStyle(3);
        btnTTC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnTTCMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnTTCMouseExited(evt);
            }
        });
        btnTTC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTTCActionPerformed(evt);
            }
        });
        pObjetCommande.add(btnTTC);
        btnTTC.setBounds(410, 100, 180, 30);

        jPanel2.add(pObjetCommande, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 298, 600, 139));

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 227, 181, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        jPanel2.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 11, 166, -1));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 55, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        jPanel2.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 590, 30));
        jPanel2.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(288, 11, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 55, 496, 50));

        txtReference.setEditable(false);
        jPanel2.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 119, 496, -1));

        txtSignataire.setEditable(false);
        jPanel2.add(txtSignataire, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 153, 496, -1));

        dtpDatesignature.setEditable(false);
        jPanel2.add(dtpDatesignature, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 187, 177, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 86, 22));

        jLabel19.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel19.setText("signataire : ");
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 154, 86, 22));

        jLabel20.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel20.setText("Date : ");
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 187, 86, 22));

        jPanel1.add(jPanel2, java.awt.BorderLayout.CENTER);

        pDetailDecision.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new java.awt.GridLayout(4, 1));

        lblStateEngage.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStateEngage.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceOFF.png"))); // NOI18N
        lblStateEngage.setText("ENGAGE");
        lblStateEngage.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblStateEngage.setIconTextGap(0);
        lblStateEngage.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel4.add(lblStateEngage);

        lblStateLiquide.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStateLiquide.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceOFF.png"))); // NOI18N
        lblStateLiquide.setText("LIQUIDE");
        lblStateLiquide.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblStateLiquide.setIconTextGap(0);
        lblStateLiquide.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel4.add(lblStateLiquide);

        lblStateMandate.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStateMandate.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceOFF.png"))); // NOI18N
        lblStateMandate.setText("MANDATE");
        lblStateMandate.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblStateMandate.setIconTextGap(0);
        lblStateMandate.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel4.add(lblStateMandate);

        lblStateRegle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblStateRegle.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/pouceOFF.png"))); // NOI18N
        lblStateRegle.setText("REGLE");
        lblStateRegle.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblStateRegle.setIconTextGap(0);
        lblStateRegle.setVerticalTextPosition(javax.swing.SwingConstants.TOP);
        jPanel4.add(lblStateRegle);

        pDetailDecision.add(jPanel4, java.awt.BorderLayout.EAST);

        panelInfos.add(pDetailDecision, "dossier");

        panelTaxes.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Montant TTC: ");

        txtMontant.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtMontant.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontant.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        tableTaxes.setShowGrid(true);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listRetenues}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableTaxes);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Rubrique");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${sigleFr}"));
        columnBinding.setColumnName("Abbréviation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${taux}"));
        columnBinding.setColumnName("Taux (%)");
        columnBinding.setColumnClass(Double.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedRetenue}"), tableTaxes, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableTaxes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableTaxesKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(tableTaxes);
        if (tableTaxes.getColumnModel().getColumnCount() > 0) {
            tableTaxes.getColumnModel().getColumn(1).setResizable(false);
            tableTaxes.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableTaxes.getColumnModel().getColumn(2).setResizable(false);
            tableTaxes.getColumnModel().getColumn(2).setPreferredWidth(30);
        }

        jPanel8.setOpaque(false);
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnCoutRetour.setText("<<< Retour");
        btnCoutRetour.setCouleur(3);
        btnCoutRetour.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCoutRetour.setStyle(1);
        btnCoutRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCoutRetourActionPerformed(evt);
            }
        });
        jPanel8.add(btnCoutRetour);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 0, 102));
        jLabel13.setText("TAXES ET AUTRES RETENUES");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Montant Net A Payer  : ");

        txtNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtNAP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtNAP.setEnabled(false);
        txtNAP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(102, 0, 102));
        jLabel15.setText("Total des retenues : ");

        txtRetenues.setForeground(new java.awt.Color(102, 0, 102));
        txtRetenues.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtRetenues.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRetenues.setEnabled(false);
        txtRetenues.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout panelTaxesLayout = new javax.swing.GroupLayout(panelTaxes);
        panelTaxes.setLayout(panelTaxesLayout);
        panelTaxesLayout.setHorizontalGroup(
            panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTaxesLayout.createSequentialGroup()
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTaxesLayout.createSequentialGroup()
                                    .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addComponent(txtMontant, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelTaxesLayout.createSequentialGroup()
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(panelTaxesLayout.createSequentialGroup()
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtRetenues, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(258, Short.MAX_VALUE))
        );
        panelTaxesLayout.setVerticalGroup(
            panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTaxesLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMontant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRetenues, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(136, Short.MAX_VALUE))
        );

        panelInfos.add(panelTaxes, "cout");

        jTabbedPane1.addTab("Informations générales", panelInfos);

        panelDetails.setBackground(new java.awt.Color(255, 255, 255));
        panelDetails.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                panelDetailsFocusLost(evt);
            }
        });
        panelDetails.setLayout(new java.awt.BorderLayout());

        tableJournal.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableJournal.setRowHeight(20);
        tableJournal.setShowGrid(true);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${journal}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableJournal);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${operation}"));
        columnBinding.setColumnName("Operation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateOperation}"));
        columnBinding.setColumnName("Date Operation");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${user}"));
        columnBinding.setColumnName("User");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane1.setViewportView(tableJournal);
        if (tableJournal.getColumnModel().getColumnCount() > 0) {
            tableJournal.getColumnModel().getColumn(0).setPreferredWidth(400);
            tableJournal.getColumnModel().getColumn(1).setResizable(false);
            tableJournal.getColumnModel().getColumn(1).setPreferredWidth(100);
            tableJournal.getColumnModel().getColumn(2).setResizable(false);
            tableJournal.getColumnModel().getColumn(2).setPreferredWidth(200);
        }

        panelDetails.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("ETAT ACTUEL : ");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("PROCHAINE ETAPE");

        lblEtat.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblEtat.setForeground(new java.awt.Color(255, 0, 0));

        lblEtapeSuivante.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        lblEtapeSuivante.setForeground(new java.awt.Color(0, 153, 204));
        lblEtapeSuivante.setText("ETAPE SUIVANTE ?");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.DEFAULT_SIZE, 144, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblEtat, javax.swing.GroupLayout.DEFAULT_SIZE, 562, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(155, 155, 155)
                    .addComponent(lblEtapeSuivante, javax.swing.GroupLayout.PREFERRED_SIZE, 553, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(16, Short.MAX_VALUE)))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblEtat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.DEFAULT_SIZE, 28, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
            .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel5Layout.createSequentialGroup()
                    .addGap(45, 45, 45)
                    .addComponent(lblEtapeSuivante, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(35, Short.MAX_VALUE)))
        );

        panelDetails.add(jPanel5, java.awt.BorderLayout.NORTH);

        jTabbedPane1.addTab("Historique de traitement", panelDetails);

        getContentPane().add(jTabbedPane1, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTTCMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTTCMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btnTTCMouseEntered

    private void btnTTCMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTTCMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnTTCMouseExited

    private void btnCoutRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCoutRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnCoutRetourActionPerformed

    private void btnTTCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTTCActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "cout");
    }//GEN-LAST:event_btnTTCActionPerformed

    private void calculerNAP() {
        Number ttc;
        if (txtMontant.getValue() == null) {
            ttc = new Long(0);
        } else {
            ttc = (Number) txtMontant.getValue();
        }
        long taxe = 0;
        //si la liste des retenues existe, recalculer les montants
        if (listRetenues.size() > 0) {
            List<LiquidationDroits> l = new ArrayList<>();
            for (LiquidationDroits d : listRetenues) {
                double t = d.getTaux();
                double m = t * ttc.doubleValue() / 100;
                d.setMontant(new BigDecimal(m));
                l.add(d);
            }
            listRetenues.clear();
            for (LiquidationDroits e : l) {
                listRetenues.add(e);
            }
        }
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (LiquidationDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
        long nap = ttc.longValue() - taxe;
        txtNAP.setValue(nap);
    }

    private void getRetenue() {

        long taxe = 0;
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (LiquidationDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
    }
    private void tableTaxesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableTaxesKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_DELETE) {
            if (selectedRetenue != null) {
                //recupérer la liste existante des rubriques
                List<LiquidationDroits> l = new ArrayList<>();
                for (LiquidationDroits eg : listRetenues) {
                    l.add(eg);
                }
                //supprimmer la rubrique selectionne
                for (LiquidationDroits retenues : l) {
                    if (retenues.getDroitID().equalsIgnoreCase(selectedRetenue.getDroitID())) {
                        l.remove(retenues);
                        break;
                    }
                }
                // recharger la liste dans le tableau par binding
                listRetenues.clear();
                for (LiquidationDroits g : l) {
                    listRetenues.add(g);
                }
            }
        }

        calculerNAP();
    }//GEN-LAST:event_tableTaxesKeyReleased

    private void panelDetailsFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_panelDetailsFocusLost
        // TODO add your handling code here:

    }//GEN-LAST:event_panelDetailsFocusLost

    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnFermerActionPerformed

    private void cboStructureImputationItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboStructureImputationItemStateChanged
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructureImputation.getSelectedItem();
        } catch (Exception ex) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(currentEngagement.getMillesime(),
                        currentEngagement.getOrganisationID(), s.getStructureID());
            } catch (Exception exx) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureImputationItemStateChanged

    private void cboTacheItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboTacheItemStateChanged
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();

        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheItemStateChanged

    private void disableComponents() {
        btnBeneficiare.setEnabled(false);
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);
        txtMontant.setEnabled(true);
        txtObjet.setEditable(false);
        txtReference.setEditable(false);
        txtSignataire.setEditable(false);
    }

    private void afficherCout() {
        try {
            btnTTC.setText(txtMontant.getText());
        } catch (Exception e) {
        }
    }

    public List<LiquidationDroits> getListRetenues() {
        return listRetenues;
    }

    public void setListRetenues(List<LiquidationDroits> listRetenues) {
        this.listRetenues = listRetenues;
    }

    public LiquidationDroits getSelectedRetenue() {
        return selectedRetenue;
    }

    public void setSelectedRetenue(LiquidationDroits selectedRetenue) {
        this.selectedRetenue = selectedRetenue;
    }

    public List<VueEngagementJournal> getJournal() {
        return journal;
    }

    public void setJournal(List<VueEngagementJournal> journal) {
        this.journal = journal;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup benefGroup;
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnCoutRetour;
    private cm.eusoworks.tools.ui.GButton btnFermer;
    private cm.eusoworks.tools.ui.GButton btnTTC;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboStructureImputation;
    private javax.swing.JComboBox cboTache;
    private org.jdesktop.swingx.JXDatePicker dtpDatesignature;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblEtapeSuivante;
    private javax.swing.JLabel lblEtat;
    private javax.swing.JLabel lblStateEngage;
    private javax.swing.JLabel lblStateLiquide;
    private javax.swing.JLabel lblStateMandate;
    private javax.swing.JLabel lblStateRegle;
    private javax.swing.JLabel lblType;
    private javax.swing.JPanel pDetailDecision;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel panelDetails;
    private javax.swing.JPanel panelInfos;
    private javax.swing.JPanel panelTaxes;
    private javax.swing.ButtonGroup radioGroup;
    private org.jdesktop.swingx.JXTable tableJournal;
    private org.jdesktop.swingx.JXTable tableTaxes;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtNAP;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtRetenues;
    private javax.swing.JTextField txtSignataire;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
