/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.SourceFinancement;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueOpFichier;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.observablecollections.ObservableCollections;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author macbookair
 */
public class ExecOperationDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OperationDialog
     */
    boolean fichierDejaLu = false;
    Activite tache;
    OperationBudgetaire paragraphe;
    private List<OperationBudgetaire> operations = null;
    List<VueOpFichier> listLignes = ObservableCollections.observableList(new ArrayList<VueOpFichier>());
    PrepaBudget budget;
    
    boolean isUpdatable;

    public ExecOperationDialog(JFrame parent, boolean modal, Activite tache, OperationBudgetaire paragraphe, PrepaBudget budget, boolean updatable) {
        super(parent, modal);
        initComponents();
        this.tache = tache;
        this.paragraphe = paragraphe;
        this.budget = budget;
        this.isUpdatable = updatable;
        txtProjetLibelle.setText(tache.getCode() + " - " + tache.getLibelleFr());
        loadStructureOrganisation();
        loadFinancement();
        loadCompte();
        AutoCompleteDecorator.decorate(cboCompte);
        AutoCompleteDecorator.decorate(cboStructure);
        AutoCompleteDecorator.decorate(cboFinancement);
        initUI();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Opérations budgétaires //" + budget.getLibelleFr());
        setPreferredSize(new Dimension(955, 620));
        pack();
        setLocationRelativeTo(null);
    }

    private void loadStructureOrganisation() {
        String organisationID = tache.getOrganisationID();
        if (organisationID != null) {
            List<Structure> list = new ArrayList<Structure>();
            try {
                list = GrecoServiceFactory.getOrganisationService().listeStructuresUserByOrganisation(organisationID,
                        GrecoSession.USER_CONNECTED.getLogin());
            } catch (Exception e) {
                list = null;
            }
            if (list != null && !list.isEmpty()) {
                cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
                if (list.size() == 1) {
                    cboStructure.setSelectedIndex(0);
                } else {
                    cboStructure.setSelectedIndex(-1);
                }
            }
        }
    }

    private void loadFinancement() {

        List<SourceFinancement> list = new ArrayList<SourceFinancement>();
        try {
            list = GrecoServiceFactory.getSourceFinancementService().listeSourceFinancement(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboFinancement.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboFinancement.setSelectedIndex(0);
            }
        }
    }

    private void loadCompte() {

        List<Compte> list = new ArrayList<Compte>();
        try {
            list = GrecoServiceFactory.getNomenclatureService().getListCompteUtilisables();
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboCompte.setModel(new DefaultComboBoxModel(list.toArray()));
            cboCompte.setSelectedIndex(-1);
        }
    }

    private void initUI() {
        btnEnregistrer.setVisible(isUpdatable);
        if (paragraphe == null) {
            txtLibelle.clear();
            txtIndicateurResultat.clear();
            txtSourceVerif.clear();
            cboCompte.setSelectedIndex(-1);
            txtAE.setValue(BigDecimal.ZERO);
            txtCP.setValue(BigDecimal.ZERO);
        } else {
            txtLibelle.setTextFr(paragraphe.getLibelleFr());
            txtLibelle.setTextUs(paragraphe.getLibelleUs()==null?"":paragraphe.getLibelleUs());
            txtIndicateurResultat.setTextFr(paragraphe.getIndicateurFr());
            txtIndicateurResultat.setTextUs(paragraphe.getIndicateurUs()==null?"":paragraphe.getIndicateurUs());
            txtSourceVerif.setTextFr(paragraphe.getSourceVerificationFr());
            txtSourceVerif.setTextUs(paragraphe.getSourceVerificationUs()==null?"":paragraphe.getSourceVerificationUs());
            txtAE.setValue(paragraphe.getAe());
            txtCP.setValue(paragraphe.getCp());
            dtpDateDebut.setDate(paragraphe.getDateDebut());
            dtpDateFin.setDate(paragraphe.getDateFin());
            try {
                chronogramme1.setCalendrier(paragraphe.getCalendrier());
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                if (((Structure) cboStructure.getItemAt(i)).getStructureID().equalsIgnoreCase(paragraphe.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboFinancement.getItemCount(); i++) {
                if (((SourceFinancement) cboFinancement.getItemAt(i)).getFinancementID().equalsIgnoreCase(paragraphe.getFinancementID())) {
                    cboFinancement.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboCompte.getItemCount(); i++) {
                if (((Compte) cboCompte.getItemAt(i)).getCode().equalsIgnoreCase(paragraphe.getCompteCode())) {
                    cboCompte.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void remplirCurrentOperationBud() {
        paragraphe.setLibelleFr(txtLibelle.getTextFr());
        paragraphe.setLibelleUs(txtLibelle.getTextUs());
        paragraphe.setIndicateurFr(txtIndicateurResultat.getTextFr());
        paragraphe.setIndicateurUs(txtIndicateurResultat.getTextUs());
        paragraphe.setSourceVerificationFr(txtSourceVerif.getTextFr());
        paragraphe.setSourceVerificationUs(txtSourceVerif.getTextUs());
        paragraphe.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        paragraphe.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
        paragraphe.setDateDebut(dtpDateDebut.getDate());
        paragraphe.setDateFin(dtpDateFin.getDate());

        try {
            txtAE.commitEdit();
        } catch (Exception e) {
        }
        try {
            txtCP.commitEdit();
        } catch (Exception e) {
        }

        try {
            paragraphe.setAe(BigDecimal.valueOf((long) txtAE.getValue()));
//            paragraphe.setAe((BigDecimal) txtAE.getValue());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "La modification sur le montant AE n'a pas été prise en compte");
//            return;

        }
        try {
            paragraphe.setCp(BigDecimal.valueOf((long) txtCP.getValue()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "La modification sur le montant CP n'a pas été prise en compte");
            return;
        }

        Compte c = (Compte) cboCompte.getSelectedItem();
        paragraphe.setCompteCode(c.getCode());
        Structure s = (Structure) cboStructure.getSelectedItem();
        paragraphe.setStructureID(s.getStructureID());
        paragraphe.setPosteComptableID(s.getPosteComptableID());
        SourceFinancement sf = (SourceFinancement) cboFinancement.getSelectedItem();
        paragraphe.setFinancementID(sf.getFinancementID());
        paragraphe.setActiviteBudgetiseID(tache.getActiviteID());

        paragraphe.setCalendrier(chronogramme1.getCalendrier());

        // budget pour lequel l'opération est inscrite 
        paragraphe.setBudgetID(budget.getBudgetID());
        switch (budget.getType()) {
            case BudgetType.REPORT:
                paragraphe.setBudgetExploite(BudgetType.ETAT_REPORT);
                break;
            case BudgetType.INITIAL:
                paragraphe.setBudgetExploite(BudgetType.ETAT_INITIAL);
                break;
            case BudgetType.ADDITIF:
                paragraphe.setBudgetExploite(BudgetType.ETAT_ADDITIF);
                break;
            default:
                break;
        }
    }

    private boolean checkData() {
        boolean res = true;

        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir la structure porteuse du projet");
            return false;
        }
        SourceFinancement sf = (SourceFinancement) cboFinancement.getSelectedItem();
        if (sf == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir la source de financement ");
            return false;
        }
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir le paragraphe budgétaire de cette opération");
            return false;
        }
        if (txtLibelle.getTextFr() == null || txtLibelle.getTextFr().isEmpty()) {
            GrecoOptionPane.showWarningDialog("le libellé de la tâche ne peut pas être vide ");
            return false;
        }

        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel5 = new javax.swing.JLabel();
        dtpDateDebut = new org.jdesktop.swingx.JXDatePicker();
        jLabel6 = new javax.swing.JLabel();
        dtpDateFin = new org.jdesktop.swingx.JXDatePicker();
        jLabel12 = new javax.swing.JLabel();
        pDetails = new javax.swing.JPanel();
        pOperation = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtLibelle = new editor.EditorRTF();
        txtIndicateurResultat = new editor.EditorRTF();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        cboFinancement = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        cboCompte = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        txtSourceVerif = new editor.EditorRTF();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCP = new javax.swing.JFormattedTextField();
        txtAE = new javax.swing.JFormattedTextField();
        jSeparator1 = new javax.swing.JSeparator();
        btnEnregistrer = new javax.swing.JButton();
        chronogramme1 = new cm.eusoworks.tools.ui.Chronogramme();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtProjetLibelle = new javax.swing.JTextArea();
        jPanel2 = new javax.swing.JPanel();
        btnFermer = new javax.swing.JButton();

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel5.setText("Date de début : ");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel6.setText("Date de fin : ");

        jLabel12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel12.setText("Calendrier d'exécution : ");

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");

        pDetails.setLayout(new java.awt.BorderLayout());

        pOperation.setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(200, 190, 490, 70);
        jPanel1.add(txtIndicateurResultat);
        txtIndicateurResultat.setBounds(200, 270, 490, 70);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Opération  : ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 190, 100, 50);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Indicateur / Résultat :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 270, 160, 50);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Structure responsable : ");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 10, 150, 30);

        jPanel1.add(cboStructure);
        cboStructure.setBounds(200, 7, 490, 30);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Financement : ");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(20, 40, 140, 30);

        jPanel1.add(cboFinancement);
        cboFinancement.setBounds(200, 40, 490, 30);

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Compte : ");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(20, 70, 140, 30);

        cboCompte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCompteActionPerformed(evt);
            }
        });
        jPanel1.add(cboCompte);
        cboCompte.setBounds(200, 70, 490, 30);

        jLabel7.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel7.setText("Source de vérification :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 360, 160, 40);
        jPanel1.add(txtSourceVerif);
        txtSourceVerif.setBounds(200, 350, 490, 80);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("AE : ");
        jLabel2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel2MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel2);
        jLabel2.setBounds(190, 110, 50, 30);

        jLabel8.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel8.setText("CP : ");
        jLabel8.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jLabel8MouseClicked(evt);
            }
        });
        jPanel1.add(jLabel8);
        jLabel8.setBounds(450, 110, 50, 30);

        txtCP.setEditable(false);
        txtCP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtCP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtCP.setText("0");
        txtCP.setEnabled(false);
        txtCP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtCP.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCPFocusLost(evt);
            }
        });
        jPanel1.add(txtCP);
        txtCP.setBounds(500, 110, 190, 32);

        txtAE.setEditable(false);
        txtAE.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtAE.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtAE.setText("0");
        txtAE.setEnabled(false);
        txtAE.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtAE.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtAEFocusLost(evt);
            }
        });
        jPanel1.add(txtAE);
        txtAE.setBounds(240, 110, 190, 32);
        jPanel1.add(jSeparator1);
        jSeparator1.setBounds(20, 170, 660, 12);

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnregistrer);
        btnEnregistrer.setBounds(710, 280, 116, 29);
        jPanel1.add(chronogramme1);
        chronogramme1.setBounds(200, 450, 290, 46);

        jScrollPane3.setEnabled(false);
        jScrollPane3.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N

        txtProjetLibelle.setColumns(20);
        txtProjetLibelle.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtProjetLibelle.setForeground(new java.awt.Color(102, 102, 102));
        txtProjetLibelle.setLineWrap(true);
        txtProjetLibelle.setRows(5);
        txtProjetLibelle.setEnabled(false);
        jScrollPane3.setViewportView(txtProjetLibelle);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(700, 10, 210, 230);

        pOperation.add(jPanel1, "operation");

        pDetails.add(pOperation, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 15, 5));

        btnFermer.setText("Fermer");
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });
        jPanel2.add(btnFermer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetails, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (!checkData()) {
            return;
        }

        if (paragraphe == null) {
            paragraphe = new OperationBudgetaire();
            remplirCurrentOperationBud();
            try {
                GrecoServiceFactory.getOperationService().ajouter(paragraphe, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Ajout de l'opération en cours d'exercice :" + paragraphe.getLibelle()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.BUDGETISATION_ANNUELLE);
                GrecoSession.notifications.success();
                if (operations == null) {
                    operations = new ArrayList<>();
                }
                OperationBudgetaire e = paragraphe;
                operations.add(e);
                paragraphe = null;
                initUI();
            } catch (GrecoException ex) {
                paragraphe = null;
                GrecoSession.notifications.echec();
                ManageException.show(ex, GrecoSession.USER_LANGUAGE);
            } catch (Exception e) {
                paragraphe = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
            }
        } else {
            remplirCurrentOperationBud();
            try {
                GrecoServiceFactory.getOperationService().modifier(paragraphe, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Modification de l'opération en cours d'exercice : " + paragraphe.getLibelle()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.BUDGETISATION_ANNUELLE);
                GrecoSession.notifications.success();
                dispose();
            } catch (GrecoException ex) {
                GrecoSession.notifications.echec();
                ManageException.show(ex, GrecoSession.USER_LANGUAGE);
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void txtAEFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAEFocusLost
        try {
            // TODO add your handling code here:
            txtAE.commitEdit();
        } catch (ParseException ex) {
            Logger.getLogger(ExecOperationDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
//        Compte c = (Compte) cboCompte.getSelectedItem();
//        if (c == null || !c.getCode().substring(0, 1).equals("2")) {
        txtCP.setValue(txtAE.getValue());
//        }

    }//GEN-LAST:event_txtAEFocusLost

    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_btnFermerActionPerformed

    private void cboCompteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCompteActionPerformed
        // TODO add your handling code here:`
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c != null) {
            if (!c.getCode().substring(0, 1).equals("2")) {
                if (paragraphe == null) {
                    txtLibelle.setTextFr(c.getLibelleFr());
                    txtLibelle.setTextUs(c.getLibelleUs());
                }
            }
        }
    }//GEN-LAST:event_cboCompteActionPerformed

    private void txtCPFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCPFocusLost
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            txtCP.commitEdit();
        } catch (ParseException ex) {
            Logger.getLogger(ExecOperationDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c == null || !c.getCode().substring(0, 1).equals("2")) {
            txtAE.setValue(txtCP.getValue());
        }
    }//GEN-LAST:event_txtCPFocusLost

    private void jLabel2MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel2MouseClicked
        // TODO add your handling code here:
        if(evt.getClickCount() == 2){
            txtAE.setEnabled(true);
            txtAE.setEditable(true);
        }
    }//GEN-LAST:event_jLabel2MouseClicked

    private void jLabel8MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel8MouseClicked
        // TODO add your handling code here:
        if(evt.getClickCount() == 2){
            txtCP.setEnabled(true);
            txtCP.setEditable(true);
        }
    }//GEN-LAST:event_jLabel8MouseClicked

    private boolean controlData() {
        boolean res = true;

        if (txtLibelle.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le libelle de l'opération ", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtIndicateurResultat.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir l'indicateur de résultat ", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtSourceVerif.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir la source de vérification ", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la structure responsable ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        SourceFinancement u = (SourceFinancement) cboFinancement.getSelectedItem();
        if (u == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la source de financement ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner le paragraphe budgétaire ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Date deb = dtpDateDebut.getDate();
        if (deb == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la date de démarrage de cette opération ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Date fin = dtpDateFin.getDate();
        if (deb == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la date de fin de cette opération ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        long ae = ((Number) txtAE.getValue()).longValue();
        long cp = ((Number) txtCP.getValue()).longValue();
        if (cp > ae) {
            JOptionPane.showMessageDialog(this, "Le CP ne doit pas etre supérieur à l'AE ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ExecOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ExecOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ExecOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ExecOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ExecOperationDialog dialog = new ExecOperationDialog(new javax.swing.JFrame(), true, null, null, null,true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    public List<OperationBudgetaire> getOperations() {
        return operations;
    }

    public List<VueOpFichier> getListLignes() {
        return listLignes;
    }

    public void setListLignes(List<VueOpFichier> listLignes) {
        this.listLignes = listLignes;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnFermer;
    private javax.swing.JComboBox cboCompte;
    private javax.swing.JComboBox cboFinancement;
    private javax.swing.JComboBox cboStructure;
    private cm.eusoworks.tools.ui.Chronogramme chronogramme1;
    private org.jdesktop.swingx.JXDatePicker dtpDateDebut;
    private org.jdesktop.swingx.JXDatePicker dtpDateFin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pOperation;
    private javax.swing.JFormattedTextField txtAE;
    private javax.swing.JFormattedTextField txtCP;
    private editor.EditorRTF txtIndicateurResultat;
    private editor.EditorRTF txtLibelle;
    private javax.swing.JTextArea txtProjetLibelle;
    private editor.EditorRTF txtSourceVerif;
    // End of variables declaration//GEN-END:variables
}
