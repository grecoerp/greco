/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.DialogOpenMode;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueEngagementBordereau;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.util.DateUtil;
import java.awt.CardLayout;
import java.awt.Image;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementReceptionDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<VueEngagementDossier> listDossiers = ObservableCollections.observableList(new ArrayList<VueEngagementDossier>());
    VueEngagementDossier selectedDossier = null;

    GrecoReports fonctions = new GrecoReports();
    int wSearch = 600, hSearch = 300;
    int openMode = DialogOpenMode.enregistre;
//    private CurvesProgressPanel glasspane;

    public EngagementReceptionDialog(java.awt.Frame parent, boolean modal, int mode) {
        super(parent, modal);
        initComponents();
        setSize(815, 500);
        this.openMode = mode;
        initMode();
        panelRecherche.setBounds((int) ((getWidth() - wSearch) / 2), (int) ((getHeight() - hSearch) / 2), wSearch, hSearch);
        glasspane.setText("Recherche des dossiers correspondant aux critères ...");
        this.setGlassPane(glasspane);
        loadOrganisations();
        loadExercicesBudgetisation();
        loadTypeEngagement();
        txtAgentLiaison.setText(GrecoSession.USER_CONNECTED.getNomComplet());
        dtpTransmission.setDate(DateUtil.now());
        paneltransmission.setVisible(false);
        setLocationRelativeTo(null);

    }

    public List<VueEngagementDossier> getListDossiers() {
        return listDossiers;
    }

    public void setListDossiers(List<VueEngagementDossier> listDossiers) {
        this.listDossiers = listDossiers;
    }

    public VueEngagementDossier getSelectedDossier() {
        return selectedDossier;
    }

    public void setSelectedDossier(VueEngagementDossier selectedDossier) {
        this.selectedDossier = selectedDossier;
    }

    private void initMode() {
        switch (openMode) {
            case DialogOpenMode.receptionneCF: {
                setTitle("Réception des dossiers pour Contrôle de conformité ");
                txtServiceEmetteur.setText("Ordonnateur");
                txtserviceDestinanataire.setText(GrecoSession.USER_CONNECTED.getService());
                txtAgentLiaison.setText(GrecoSession.USER_CONNECTED.getNomComplet());
                break;
            }
            case DialogOpenMode.receptionneLiquidation: {
                setTitle("Réception des dossiers pour Liquidation ");
                txtServiceEmetteur.setText("Contrôleur Financier ");
                txtserviceDestinanataire.setText(GrecoSession.USER_CONNECTED.getService());
                txtAgentLiaison.setText(GrecoSession.USER_CONNECTED.getNomComplet());
                break;
            }
            case DialogOpenMode.receptionneRegularite: {
                setTitle("Réception des dossiers pour Contrôle de la Régularité ");
                txtServiceEmetteur.setText("Ordonnateur ");
                txtserviceDestinanataire.setText(GrecoSession.USER_CONNECTED.getService());
                txtAgentLiaison.setText(GrecoSession.USER_CONNECTED.getNomComplet());
                break;
            }
            case DialogOpenMode.receptionneComptable: {
                setTitle("Réception des dossiers pour prise en charge comptable ");
                txtServiceEmetteur.setText("Contrôleur Financier");
                txtserviceDestinanataire.setText(GrecoSession.USER_CONNECTED.getService());
                txtAgentLiaison.setText(GrecoSession.USER_CONNECTED.getNomComplet());
                break;
            }
        }
    }

    private int getReceptionMode(){
        int mode = DialogOpenMode.receptionneCF;
        switch (openMode) {
//            case DialogOpenMode.transmiCF: {
//                mode = DialogOpenMode.receptionneCF;
//                break;
//            }
//            case DialogOpenMode.transmiPourLiquidation: {
//                mode = DialogOpenMode.receptionneLiquidation;
//                break;
//            }
            case DialogOpenMode.transmiPourRegularite: {
                mode = DialogOpenMode.receptionneRegularite;
                break;
            }
            default:{
                mode = this.openMode;
                break;
            }
                
//            case DialogOpenMode.transmiAuComptable: {
//                mode = DialogOpenMode.receptionneComptable;
//                break;
//            }
        }
        return mode;
    }
    
    private String getBordereauTitle(){
        String title = "";
        switch (openMode) {
            case DialogOpenMode.receptionneCF: {
                title = "BORDEREAU DE RECEPTION POUR CONTROLE DE CONFORMITE";
                break;
            }
            case DialogOpenMode.receptionneLiquidation: {
                title = "BORDEREAU DE RECEPTION POUR LIQUIDATION";
                break;
            }
            case DialogOpenMode.receptionneRegularite: {
                title = "BORDEREAU DE RECEPTION POUR CONTROLE DE REGULARITE";
                break;
            }
            case DialogOpenMode.receptionneComptable: {
                title = title = "BORDEREAU DE RECEPTION POUR PRISE EN CHARGE (AC)";
                break;
            }
        }
        return title;
    }
    
    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserActives(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            } else {
                cboExercice.setSelectedIndex(cboExercice.getItemCount() - 1);
            }
        }
    }

    private void loadTypeEngagement() {
        List<EngagementType> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getEngagementService().getEngagementType();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            list.add(null);
            cboTypeengagement.setModel(new DefaultComboBoxModel(list.toArray()));
            cboTypeengagement.setSelectedIndex(-1);
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog( "Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        return true;
    }

    private void search(boolean advanced) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String numdossier = ((String) txtnumDossier.getValue());
        String etat = EtatDossier.getListeEtat(this.openMode);
        String engagementType = null;
        String cpte = null;
        Date dateEnregDebut = null;
        Date dateEnregFin = null;
        Date dateValidDebut = null;
        Date dateValidFin = null;
        String beneficiare = null;

        if (advanced) {
            EngagementType et = (EngagementType) cboTypeengagement.getSelectedItem();
            if (et != null) {
                engagementType = et.getTypeID();
            }
            cpte = txtCompteBudgetaire.getText().isEmpty() ? null : txtCompteBudgetaire.getText();
            dateEnregDebut = dtpEnregistrementDebut.getDate();
            dateEnregFin = dtpEnregistrementfin.getDate();
            dateValidDebut = dtpDateValidationDebut.getDate();
            dateValidFin = dtpDateValidationFin.getDate();
            beneficiare = txtBeneficiaire.getText().isEmpty() ? null : txtBeneficiaire.getText();
        }

        List<VueEngagementDossier> l = GrecoServiceFactory.getEngagementService().getDossiers(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut, dateEnregFin, dateValidDebut, dateValidFin, beneficiare);
        listDossiers.clear();
        if (l != null && !l.isEmpty()) {
            for (VueEngagementDossier v : l) {
                listDossiers.add(v);
            }
            paneltransmission.setVisible(true);
        } else {
            paneltransmission.setVisible(false);
        }
    }

    

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        paneltransmission = new javax.swing.JPanel();
        panelTransmission = new javax.swing.JPanel();
        panelEntete = new javax.swing.JPanel();
        panelExercice = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        txtnumDossier = new javax.swing.JFormattedTextField();
        jPanel1 = new javax.swing.JPanel();
        btnOptions = new cm.eusoworks.tools.ui.GButton();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        txtServiceEmetteur = new javax.swing.JTextField();
        txtserviceDestinanataire = new javax.swing.JTextField();
        txtAgentLiaison = new javax.swing.JTextField();
        dtpTransmission = new org.jdesktop.swingx.JXDatePicker();
        btnReception = new cm.eusoworks.tools.ui.GButton();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel16 = new javax.swing.JLabel();
        chkCocherTous = new javax.swing.JCheckBox();
        panelRecherche = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cboTypeengagement = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        txtCompteBudgetaire = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dtpEnregistrementDebut = new org.jdesktop.swingx.JXDatePicker();
        dtpEnregistrementfin = new org.jdesktop.swingx.JXDatePicker();
        dtpDateValidationDebut = new org.jdesktop.swingx.JXDatePicker();
        dtpDateValidationFin = new org.jdesktop.swingx.JXDatePicker();
        txtBeneficiaire = new javax.swing.JTextField();
        btnRechercheAvance = new cm.eusoworks.tools.ui.GButton();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        panelTable = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableDossiers = new org.jdesktop.swingx.JXTable();

        paneltransmission.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Détails de la transmission", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(153, 0, 153))); // NOI18N
        paneltransmission.setOpaque(false);

        javax.swing.GroupLayout paneltransmissionLayout = new javax.swing.GroupLayout(paneltransmission);
        paneltransmission.setLayout(paneltransmissionLayout);
        paneltransmissionLayout.setHorizontalGroup(
            paneltransmissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 438, Short.MAX_VALUE)
        );
        paneltransmissionLayout.setVerticalGroup(
            paneltransmissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 220, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Transmission des dossiers ...");
        setResizable(false);
        getContentPane().setLayout(new java.awt.CardLayout());

        panelTransmission.setLayout(new java.awt.BorderLayout());

        panelEntete.setMinimumSize(new java.awt.Dimension(0, 0));
        panelEntete.setLayout(new java.awt.CardLayout());

        panelExercice.setBackground(new java.awt.Color(255, 255, 255));
        panelExercice.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 31, 76, 30));

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });
        jPanel2.add(cboExercice, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 37, 169, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("N° de dossier : ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 79, -1, 26));

        try {
            txtnumDossier.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("U#########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtnumDossier.setFont(new java.awt.Font("Arial Black", 0, 16)); // NOI18N
        txtnumDossier.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtnumDossierKeyReleased(evt);
            }
        });
        jPanel2.add(txtnumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(122, 79, 167, -1));

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnOptions.setForeground(new java.awt.Color(0, 0, 0));
        btnOptions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/search.png"))); // NOI18N
        btnOptions.setText("Options...");
        btnOptions.setCouleur(3);
        btnOptions.setStyle(1);
        btnOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOptionsActionPerformed(evt);
            }
        });
        jPanel1.add(btnOptions);

        btnRechercher.setText("Rechercher ...");
        btnRechercher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnRechercher.setStyle(3);
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });
        jPanel1.add(btnRechercher);

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 193, 240, -1));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("Service émetteur : ");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 40, -1, 20));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(0, 102, 204));
        jLabel13.setText("Service destinataire : ");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 70, 122, 23));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(0, 102, 204));
        jLabel14.setText("Date de réception : ");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 110, -1, 23));

        jLabel15.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(0, 102, 204));
        jLabel15.setText("Agent de liaison : ");
        jPanel2.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(350, 160, 125, 22));
        jPanel2.add(txtServiceEmetteur, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 40, 277, -1));
        jPanel2.add(txtserviceDestinanataire, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 70, 277, -1));
        jPanel2.add(txtAgentLiaison, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 160, 277, -1));
        jPanel2.add(dtpTransmission, new org.netbeans.lib.awtextra.AbsoluteConstraints(490, 110, 178, -1));

        btnReception.setText("Réceptionner ...");
        btnReception.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnReception.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnReceptionActionPerformed(evt);
            }
        });
        jPanel2.add(btnReception, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 210, 161, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 1, 92, -1));

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        jPanel2.add(cboOrganisation, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 0, 650, -1));

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgreception.png"))); // NOI18N
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 810, 260));

        chkCocherTous.setText("Cocher tous");
        chkCocherTous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCocherTousActionPerformed(evt);
            }
        });
        jPanel2.add(chkCocherTous, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 260, 290, -1));

        panelExercice.add(jPanel2, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelExercice, "exercice");

        panelRecherche.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(125, 161, 237));

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Recherche avancée ");
        jPanel5.add(jLabel3);

        panelRecherche.add(jPanel5, java.awt.BorderLayout.NORTH);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel4.setText("Type d'engagement ");

        cboTypeengagement.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel5.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel5.setText("Compte budgétaire ");

        txtCompteBudgetaire.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        jLabel6.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel6.setText("Date d'enregistrement entre le ");

        jLabel9.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel9.setText("et le ");

        jLabel10.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel10.setText("Date de validation entre le ");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel11.setText("et le ");

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire (intitulé)");

        dtpEnregistrementfin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dtpEnregistrementfinActionPerformed(evt);
            }
        });

        btnRechercheAvance.setText("Rechercher les dossiers répondant aux critères ");
        btnRechercheAvance.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRechercheAvance.setStyle(3);
        btnRechercheAvance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercheAvanceActionPerformed(evt);
            }
        });

        btnRetour.setForeground(new java.awt.Color(0, 0, 0));
        btnRetour.setText("<<< Retour     ");
        btnRetour.setCouleur(3);
        btnRetour.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4)
                        .addGap(84, 84, 84)
                        .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel5)
                        .addGap(87, 87, 87)
                        .addComponent(txtCompteBudgetaire, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel10)
                        .addGap(47, 47, 47)
                        .addComponent(dtpDateValidationDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpDateValidationFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(264, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel4))
                    .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel5))
                    .addComponent(txtCompteBudgetaire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateValidationDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateValidationFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(31, Short.MAX_VALUE))
        );

        panelRecherche.add(jPanel6, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelRecherche, "recherche");

        panelTransmission.add(panelEntete, java.awt.BorderLayout.NORTH);

        panelTable.setLayout(new java.awt.BorderLayout());

        tableDossiers.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableDossiers.setGridColor(new java.awt.Color(204, 204, 204));
        tableDossiers.setRowHeight(24);
        tableDossiers.setSelectionBackground(new java.awt.Color(91, 118, 173));
        tableDossiers.setShowGrid(true);
        tableDossiers.getTableHeader().setReorderingAllowed(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listDossiers}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${check}"));
        columnBinding.setColumnName("");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("N° Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Beneficiaire");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${compte}"));
        columnBinding.setColumnName("Compte");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${etatDossier}"));
        columnBinding.setColumnName("Etat du dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedDossier}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane2.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setMinWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setMaxWidth(30);
            tableDossiers.getColumnModel().getColumn(1).setMinWidth(100);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(100);
            tableDossiers.getColumnModel().getColumn(1).setMaxWidth(150);
            tableDossiers.getColumnModel().getColumn(2).setMinWidth(110);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(110);
            tableDossiers.getColumnModel().getColumn(2).setMaxWidth(110);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(250);
            tableDossiers.getColumnModel().getColumn(4).setMinWidth(80);
            tableDossiers.getColumnModel().getColumn(4).setPreferredWidth(80);
            tableDossiers.getColumnModel().getColumn(4).setMaxWidth(120);
        }

        panelTable.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        panelTransmission.add(panelTable, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelTransmission, "transmission");

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void dtpEnregistrementfinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dtpEnregistrementfinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dtpEnregistrementfinActionPerformed

    private void btnRechercheAvanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercheAvanceActionPerformed
        // recherche des elements
        rechercher(true);
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRechercheAvanceActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // recherche des elements
        rechercher(false);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void btnOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOptionsActionPerformed
        // TODO add your handling code here:
        optionsRecherche();
    }//GEN-LAST:event_btnOptionsActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void txtnumDossierKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnumDossierKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            rechercher(false);
        }
    }//GEN-LAST:event_txtnumDossierKeyReleased

    private void btnReceptionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnReceptionActionPerformed
        // TODO add your handling code here:
        if (txtServiceEmetteur.getText().trim().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez renseigner le service qui transmet les dossiers");
            return;
        }
        if (txtserviceDestinanataire.getText().trim().isEmpty()) {
            GrecoOptionPane.showWarningDialog( "Veuillez renseigner le service qui va réceptionner les dossiers");
            return;
        }
        if (dtpTransmission == null) {
            GrecoOptionPane.showWarningDialog( "Veuillez marquer la date de transmission");
            return;
        }
//        if (txtAgentLiaison.getText().trim().isEmpty()) {
//            GrecoOptionPane.showWarningDialog("Veuillez indiquer le nom de l'agent chargé d'acheminer les dossiers à leur destination SVP");
//            return;
//        }
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return;
        }
        Exercice ex = (Exercice) cboExercice.getSelectedItem();
        if (ex == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return;
        }
        List<VueEngagementDossier> dossiers = new ArrayList<>();
        for (VueEngagementDossier v : listDossiers) {
            if (v.isCheck()) {
              //  v.setEngagementID("XXX"+v.getNumDossier());
                dossiers.add(v);
            }
        }
        if (dossiers.size() == 0) {
            GrecoOptionPane.showInformationDialog( "Aucun dossier n'a été coché dans la liste");
            return;
        } else {
            int res = GrecoOptionPane.showConfirmDialog( "Etes-vour de vouloir réceptionner ces " + dossiers.size() + " dossiers ?" );
            if (res == JOptionPane.YES_OPTION) {
                String bordereau = null;
                try {
                    glasspane.attente();
                    //transmettre la liste des bons pour generation bordereau
                    bordereau = GrecoServiceFactory.getEngagementService().transmissionDossier(o.getOrganisationID(), ex.getMillesime(), this.openMode,
                            txtServiceEmetteur.getText().toUpperCase(), txtserviceDestinanataire.getText().toUpperCase(), txtAgentLiaison.getText().toUpperCase(), dossiers, GrecoSession.USER_CONNECTED.getLogin(), getReceptionMode());
                    if (bordereau == null) {
                        GrecoSession.notifications.echec();
                        GrecoOptionPane.showErrorDialog("Les dossiers n'ont pas pu etre réceptionnés ...");
                    } else {
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Dossiers réceptionné avec succès sous le bordereau N° :" + bordereau + "\n Le bordereau va être édité dans quelques secondes ");
                        search(false); // recharger la liste
                        //impression du bordereau
                        GrecoImages logo = new GrecoImages();
                        Image armoirieCM = null;//new siiResources.Images();
                        HashMap parameters = fonctions.mainParameters();
                        parameters.put("chapitreFR", o.getLibelleFr());
                        parameters.put("chapitreEN", o.getLibelleUs());
                        parameters.put("armoirieCM", armoirieCM);
                        parameters.put("logo", logo.logoOrganisation());
                        parameters.put("app", logo.logo());
                        parameters.put("user", GrecoSession.USER_CONNECTED.getNom());
                        parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
                        parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");
                        parameters.put("title", getBordereauTitle());
                        parameters.put("msg", "FST");

                        List<VueEngagementBordereau> contentBordereau = new ArrayList<>();

                        contentBordereau = GrecoServiceFactory.getReportService().getBordereauTransmission(bordereau);
                        JRDataSource dataSource = new JRBeanCollectionDataSource(contentBordereau);
                        try {
                            JasperPrint print = JasperFillManager.fillReport(fonctions.bordereauTransmission(), parameters, dataSource);
                            JRHelper.viewReport(print);
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    glasspane.arret();
                } catch (Exception e) {
                    GrecoSession.notifications.echec();
                    GrecoOptionPane.showErrorDialog("Les dossiers n'ont pas pu etre réceptionnés ...");
                    glasspane.arret();
                }

            }
        }
    }//GEN-LAST:event_btnReceptionActionPerformed

    private void chkCocherTousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCocherTousActionPerformed
        // TODO add your handling code here:
        selectAll();
    }//GEN-LAST:event_chkCocherTousActionPerformed

    private void selectAll() {
        // TODO add your handling code here:
        boolean s = chkCocherTous.isSelected();
        List<VueEngagementDossier> l = new ArrayList<>();
        for (VueEngagementDossier st : listDossiers) {
            st.setCheck(s);
            l.add(st);
        }
        listDossiers.clear();
        for (VueEngagementDossier st : l) {
            listDossiers.add(st);
        }
    }
    
    private void rechercher(boolean advanced) {
        glasspane.attente();
        search(advanced);
        glasspane.arret();
    }

    private void optionsRecherche() {
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "recherche");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EngagementReceptionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EngagementReceptionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EngagementReceptionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EngagementReceptionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new EngagementSearchDialog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnOptions;
    private cm.eusoworks.tools.ui.GButton btnReception;
    private cm.eusoworks.tools.ui.GButton btnRechercheAvance;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboTypeengagement;
    private javax.swing.JCheckBox chkCocherTous;
    private org.jdesktop.swingx.JXDatePicker dtpDateValidationDebut;
    private org.jdesktop.swingx.JXDatePicker dtpDateValidationFin;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementDebut;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementfin;
    private org.jdesktop.swingx.JXDatePicker dtpTransmission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelEntete;
    private javax.swing.JPanel panelExercice;
    private javax.swing.JPanel panelRecherche;
    private javax.swing.JPanel panelTable;
    private javax.swing.JPanel panelTransmission;
    private javax.swing.JPanel paneltransmission;
    private org.jdesktop.swingx.JXTable tableDossiers;
    private javax.swing.JTextField txtAgentLiaison;
    private javax.swing.JTextField txtBeneficiaire;
    private javax.swing.JFormattedTextField txtCompteBudgetaire;
    private javax.swing.JTextField txtServiceEmetteur;
    private javax.swing.JFormattedTextField txtnumDossier;
    private javax.swing.JTextField txtserviceDestinanataire;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
