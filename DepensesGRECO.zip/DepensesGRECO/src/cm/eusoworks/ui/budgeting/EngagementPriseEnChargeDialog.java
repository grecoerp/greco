/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.component.compta.EcritureDateEditor;
import cm.eusoworks.component.compta.EcritureLibelleEditor;
import cm.eusoworks.component.compta.EcritureMontantRenderer;
import cm.eusoworks.component.compta.EcritureTableModel;
import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.enumeration.TypeDossier;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Axe;
import cm.eusoworks.entities.model.ComptaLibelle;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.CompteLiquidite;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.Ecritures;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.Journaux;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.Mandatement;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Paiement;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.view.VueControle;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.renderer.BooleanTableRenderer;
import cm.eusoworks.renderer.DecimalTableRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GButton;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultCellEditor;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementPriseEnChargeDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();

    Engagement currentEngagement = null;
    String millesime;
    List<VueControle> listDossiers = ObservableCollections.observableList(new ArrayList<VueControle>());

    List<Mandatement> listMandatement = ObservableCollections.observableList(new ArrayList<Mandatement>());
    List<Mandatement> listMandatementPaiement = ObservableCollections.observableList(new ArrayList<Mandatement>());

    List<LiquidationDroits> listRetenues = ObservableCollections.observableList(new ArrayList<LiquidationDroits>());

    List<CompteLiquidite> listCompteLiquidite = ObservableCollections.observableList(new ArrayList<CompteLiquidite>());
    CompteLiquidite liquidite;

    List<Droits> listDroits = new ArrayList<Droits>();

    private EcritureTableModel modeleTableEcritures = null;
    private EcritureTableModel modeleTableEcrituresPaiement = null;

    public EngagementPriseEnChargeDialog(JFrame parent, boolean modal, Engagement current, String exercice) {
        super(parent, true);
        initComponents();
        setPreferredSize(new Dimension(504, 476));
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Dossier N°:  " + current.getNumDossier());
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.currentEngagement = current;
        this.millesime = exercice;

        initTableEcriture();
        initTableEcriturePaiement();

        btnInfosSuivant.setVisible(true);
        btnValiderCreance.setVisible(false);
        btnPaiementValide.setVisible(false);
        btnPriseEnChargeAnnuler.setVisible(false);
        btnPaiementAnnuler.setVisible(false);
        btnModePaiement.setVisible(false);

        setLocationRelativeTo(null);
        loadStructureOrganisation();
        initEngagementUI();
        loadMandatement();
        initComptaLibelle();
        loadDroits();
        loadCompteLiquidite();

    }

    private void loadCompteLiquidite() {
        List<CompteLiquidite> liquidites = GrecoServiceFactory.getComptaService().liquiditeListe(CompteLiquidite.ALL);
        listCompteLiquidite.clear();
        if (liquidites != null) {
            for (CompteLiquidite liq : liquidites) {
                listCompteLiquidite.add(liq);
            }
        }

    }

    private void loadDroits() {
        listDroits = GrecoServiceFactory.getDroitsService().listeDroitsNAP();
    }

    private void initComptaLibelle() {
        List<ComptaLibelle> list = GrecoServiceFactory.getComptaService().comptaLibelleList(currentEngagement.getOrganisationID());
        if (list != null && !list.isEmpty()) {
            GrecoSession.setComptaLibelleMap(list);
        }

    }

    private void initTableEcriture() {
        modeleTableEcritures = new EcritureTableModel(this, 1);
        tableEcritures.setModel(modeleTableEcritures);
        tableEcritures.setRowHeight(25);
        tableEcritures.setShowGrid(true);
        scrollTable.setViewportView(tableEcritures);
        if (tableEcritures.getColumnModel().getColumnCount() > 0) {
            tableEcritures.getColumnModel().getColumn(0).setResizable(true);
            tableEcritures.getColumnModel().getColumn(0).setWidth(10);
            tableEcritures.getColumnModel().getColumn(1).setResizable(true);
            tableEcritures.getColumnModel().getColumn(1).setWidth(50);
            tableEcritures.getColumnModel().getColumn(2).setResizable(true);
            tableEcritures.getColumnModel().getColumn(2).setWidth(150);
            tableEcritures.getColumnModel().getColumn(3).setResizable(false);
            tableEcritures.getColumnModel().getColumn(3).setPreferredWidth(300);
            tableEcritures.getColumnModel().getColumn(4).setResizable(false);
            tableEcritures.getColumnModel().getColumn(4).setWidth(40);
            tableEcritures.getColumnModel().getColumn(5).setResizable(false);
            tableEcritures.getColumnModel().getColumn(5).setWidth(40);
            tableEcritures.getColumnModel().getColumn(6).setResizable(false);
            tableEcritures.getColumnModel().getColumn(6).setWidth(200);
            tableEcritures.getColumnModel().getColumn(7).setResizable(false);
            tableEcritures.getColumnModel().getColumn(7).setWidth(10);
        }

        List<Journaux> lj = GrecoServiceFactory.getComptaService().journauxList();
        JComboBox comboBoxJournal = new JComboBox();
        if (lj != null) {
            comboBoxJournal.setModel(new DefaultComboBoxModel(lj.toArray()));
        }

        List<Axe> la = GrecoServiceFactory.getComptaService().axeList();
        JComboBox comboBoxAxe = new JComboBox();
        if (lj != null) {
            comboBoxAxe.setModel(new DefaultComboBoxModel(la.toArray()));
        }

        List<Compte> lc = GrecoServiceFactory.getNomenclatureService().getListCompteUtilisables();
        JComboBox comboBoxCompte = new JComboBox();
        if (lj != null) {
            comboBoxCompte.setModel(new DefaultComboBoxModel(lc.toArray()));
        }

        tableEcritures.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(comboBoxJournal));
        tableEcritures.getColumnModel().getColumn(1).setCellEditor(new EcritureDateEditor());
        tableEcritures.getColumnModel().getColumn(2).setCellEditor(new DefaultCellEditor(comboBoxCompte));
        tableEcritures.getColumnModel().getColumn(7).setCellEditor(new DefaultCellEditor(comboBoxAxe));
        tableEcritures.getColumnModel().getColumn(3).setCellEditor(new EcritureLibelleEditor());

        tableEcritures.getColumnModel().getColumn(1).setCellRenderer(new EcritureMontantRenderer());
        tableEcritures.getColumnModel().getColumn(4).setCellRenderer(new EcritureMontantRenderer());
        tableEcritures.getColumnModel().getColumn(5).setCellRenderer(new EcritureMontantRenderer());

        tableEcritures.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int[] selectedRow = tableEcritures.getSelectedRows();
                if (selectedRow.length == 1) {
                    int r = selectedRow[0];
                    String ref = (String) tableEcritures.getValueAt(r, 0);
                    if (ref != null && !ref.isEmpty()) {
                        tableEcritures.getSelectionModel().setSelectionInterval(r, r);
                        tableEcritures.getColumnModel().getSelectionModel().setSelectionInterval(2, 2);
                    }
                }
            }
        }
        );

    }

    private void initTableEcriturePaiement() {
        modeleTableEcrituresPaiement = new EcritureTableModel(this, 2);
        tableEcrituresPaiement.setModel(modeleTableEcrituresPaiement);
        tableEcrituresPaiement.setRowHeight(25);
        tableEcrituresPaiement.setShowGrid(true);
        scrollTable1.setViewportView(tableEcrituresPaiement);
        if (tableEcrituresPaiement.getColumnModel().getColumnCount() > 0) {
            tableEcrituresPaiement.getColumnModel().getColumn(0).setResizable(true);
            tableEcrituresPaiement.getColumnModel().getColumn(0).setWidth(10);
            tableEcrituresPaiement.getColumnModel().getColumn(1).setResizable(true);
            tableEcrituresPaiement.getColumnModel().getColumn(1).setWidth(50);
            tableEcrituresPaiement.getColumnModel().getColumn(2).setResizable(true);
            tableEcrituresPaiement.getColumnModel().getColumn(2).setWidth(150);
            tableEcrituresPaiement.getColumnModel().getColumn(3).setResizable(false);
            tableEcrituresPaiement.getColumnModel().getColumn(3).setPreferredWidth(300);
            tableEcrituresPaiement.getColumnModel().getColumn(4).setResizable(false);
            tableEcrituresPaiement.getColumnModel().getColumn(4).setWidth(40);
            tableEcrituresPaiement.getColumnModel().getColumn(5).setResizable(false);
            tableEcrituresPaiement.getColumnModel().getColumn(5).setWidth(40);
            tableEcrituresPaiement.getColumnModel().getColumn(6).setResizable(false);
            tableEcrituresPaiement.getColumnModel().getColumn(6).setWidth(200);
            tableEcrituresPaiement.getColumnModel().getColumn(7).setResizable(false);
            tableEcrituresPaiement.getColumnModel().getColumn(7).setWidth(10);
        }

        List<Journaux> lj = GrecoServiceFactory.getComptaService().journauxList();
        JComboBox comboBoxJournal = new JComboBox();
        if (lj != null) {
            comboBoxJournal.setModel(new DefaultComboBoxModel(lj.toArray()));
        }

        List<Axe> la = GrecoServiceFactory.getComptaService().axeList();
        JComboBox comboBoxAxe = new JComboBox();
        if (lj != null) {
            comboBoxAxe.setModel(new DefaultComboBoxModel(la.toArray()));
        }

        List<Compte> lc = GrecoServiceFactory.getNomenclatureService().getListCompteUtilisables();
        JComboBox comboBoxCompte = new JComboBox();
        if (lj != null) {
            comboBoxCompte.setModel(new DefaultComboBoxModel(lc.toArray()));
        }

        tableEcrituresPaiement.getColumnModel().getColumn(0).setCellEditor(new DefaultCellEditor(comboBoxJournal));
        tableEcrituresPaiement.getColumnModel().getColumn(1).setCellEditor(new EcritureDateEditor());
        tableEcrituresPaiement.getColumnModel().getColumn(2).setCellEditor(new DefaultCellEditor(comboBoxCompte));
        tableEcrituresPaiement.getColumnModel().getColumn(7).setCellEditor(new DefaultCellEditor(comboBoxAxe));
        tableEcrituresPaiement.getColumnModel().getColumn(3).setCellEditor(new EcritureLibelleEditor());

        tableEcrituresPaiement.getColumnModel().getColumn(1).setCellRenderer(new EcritureMontantRenderer());
        tableEcrituresPaiement.getColumnModel().getColumn(4).setCellRenderer(new EcritureMontantRenderer());
        tableEcrituresPaiement.getColumnModel().getColumn(5).setCellRenderer(new EcritureMontantRenderer());

        tableEcrituresPaiement.getSelectionModel().addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                int[] selectedRow = tableEcrituresPaiement.getSelectedRows();
                if (selectedRow.length == 1) {
                    int r = selectedRow[0];
                    String ref = (String) tableEcrituresPaiement.getValueAt(r, 0);
                    if (ref != null && !ref.isEmpty()) {
                        tableEcrituresPaiement.getSelectionModel().setSelectionInterval(r, r);
                        tableEcrituresPaiement.getColumnModel().getSelectionModel().setSelectionInterval(2, 2);
                    }
                }
            }
        }
        );

    }

    public void afficherSommeEcritures(BigDecimal debit, BigDecimal credit) {
        txtDebit.setValue(debit);
        txtCredit.setValue(credit);
    }
    
    public void afficherSommeEcrituresPaiement(BigDecimal debit, BigDecimal credit) {
        txtDebitPaiement.setValue(debit);
        txtCreditPaiement.setValue(credit);
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(currentEngagement.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructureImputation.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructureImputation.setSelectedIndex(-1);
        }

    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getTypeID());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        txtNumDossier.setText(currentEngagement.getNumDossier());
        txtObjet.setText(currentEngagement.getObjet().trim());
        txtReference.setText(currentEngagement.getReference().trim());
        try {
            dtpDatesignature.setDate(currentEngagement.getDateSignature());
        } catch (Exception e) {
            dtpDatesignature.setDate(null);
        }
        btnBeneficiare.setText(currentEngagement.getBeneficiaire());

        try {
            txtMontant.setValue(currentEngagement.getMontantTTC());
        } catch (Exception e) {
        }

        //appeler une fonction pour calculer le nap et les retenues
        afficherCout();

        for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
            Structure s = (Structure) cboStructureImputation.getItemAt(i);
            if (s.getStructureID().equalsIgnoreCase(currentEngagement.getStructureID())) {
                cboStructureImputation.setSelectedIndex(i);
                break;
            }
        }

        for (int i = 0; i < cboTache.getItemCount(); i++) {
            Activite f = (Activite) cboTache.getItemAt(i);
            if (f.getActiviteID().equalsIgnoreCase(currentEngagement.getActiviteID())) {
                cboTache.setSelectedIndex(i);
                break;
            }
        }
        for (int i = 0; i < cboImputation.getItemCount(); i++) {
            OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
            if (f.getTacheID().equalsIgnoreCase(currentEngagement.getTacheID())) {
                cboImputation.setSelectedIndex(i);
                break;
            }
        }
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        radioGroup = new javax.swing.ButtonGroup();
        jLabel9 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableTaxes = new org.jdesktop.swingx.JXTable();
        jLabel15 = new javax.swing.JLabel();
        txtRetenues = new javax.swing.JFormattedTextField();
        txtNAP = new javax.swing.JFormattedTextField();
        jLabel14 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txtRIB = new javax.swing.JFormattedTextField();
        txtMontant = new javax.swing.JFormattedTextField();
        pBoutons = new javax.swing.JPanel();
        lblInfosLabel = new javax.swing.JLabel();
        lblOPLabel = new javax.swing.JLabel();
        lblPaiementLabel = new javax.swing.JLabel();
        lblOPIcon = new javax.swing.JLabel();
        lblPaiementIcon = new javax.swing.JLabel();
        lblInfosIcon = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        lblReglementIcon = new javax.swing.JLabel();
        lblReglementLabel = new javax.swing.JLabel();
        cardPanel = new javax.swing.JPanel();
        pInfos = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        pObjetCommande = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        cboStructureImputation = new javax.swing.JComboBox();
        btnTTC = new cm.eusoworks.tools.ui.GButton();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        txtSignataire = new javax.swing.JTextField();
        dtpDatesignature = new org.jdesktop.swingx.JXDatePicker();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        btnInfosSuivant = new cm.eusoworks.tools.ui.GButton();
        pOrdrePaiement = new javax.swing.JPanel();
        panelPriseEnCharge = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tblOrdrePaiement = new javax.swing.JTable();
        txtSommeOP = new javax.swing.JFormattedTextField();
        jPanel5 = new javax.swing.JPanel();
        scrollTable = new javax.swing.JScrollPane();
        tableEcritures = new org.jdesktop.swingx.JXTable();
        txtDebit = new javax.swing.JFormattedTextField();
        txtCredit = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        btnPriseEnChargeAnnuler = new cm.eusoworks.tools.ui.GButton();
        jPanel1 = new javax.swing.JPanel();
        btnValiderCreance = new cm.eusoworks.tools.ui.GButton();
        pModePaiement = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        btnModePaiement = new cm.eusoworks.tools.ui.GButton();
        jScrollPane6 = new javax.swing.JScrollPane();
        tableLiquidite = new org.jdesktop.swingx.JXTable();
        jLabel22 = new javax.swing.JLabel();
        txtPiecesPaiement = new javax.swing.JTextField();
        pPaiement = new javax.swing.JPanel();
        panelPaiement = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblPaiement = new javax.swing.JTable();
        txtSommeReglement = new javax.swing.JFormattedTextField();
        jPanel6 = new javax.swing.JPanel();
        scrollTable1 = new javax.swing.JScrollPane();
        tableEcrituresPaiement = new org.jdesktop.swingx.JXTable();
        txtDebitPaiement = new javax.swing.JFormattedTextField();
        txtCreditPaiement = new javax.swing.JFormattedTextField();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        btnPaiementAnnuler = new cm.eusoworks.tools.ui.GButton();
        jPanel3 = new javax.swing.JPanel();
        btnPaiementValide = new cm.eusoworks.tools.ui.GButton();

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 153, 153));
        jLabel9.setText("MONTANT TTC :");

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("TAXES ET AUTRES RETENUES");

        tableTaxes.setShowGrid(true);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listRetenues}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableTaxes);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Rubrique");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${sigleFr}"));
        columnBinding.setColumnName("Abbréviation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${taux}"));
        columnBinding.setColumnName("Taux (%)");
        columnBinding.setColumnClass(Double.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedRetenue}"), tableTaxes, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane3.setViewportView(tableTaxes);
        if (tableTaxes.getColumnModel().getColumnCount() > 0) {
            tableTaxes.getColumnModel().getColumn(1).setResizable(false);
            tableTaxes.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableTaxes.getColumnModel().getColumn(2).setResizable(false);
            tableTaxes.getColumnModel().getColumn(2).setPreferredWidth(30);
        }

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("TOTAL DES RETENUES :");

        txtRetenues.setEditable(false);
        txtRetenues.setForeground(new java.awt.Color(102, 0, 102));
        txtRetenues.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtRetenues.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRetenues.setEnabled(false);
        txtRetenues.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        txtNAP.setEditable(false);
        txtNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtNAP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtNAP.setEnabled(false);
        txtNAP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("MONTANT NET A PAYER :");

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("RIB DU FOURNISSEUR :");

        try {
            txtRIB.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-#####-###########-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtRIB.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        txtMontant.setEditable(false);
        txtMontant.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtMontant.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontant.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Saise des dossiers d'engagements");

        pBoutons.setBackground(new java.awt.Color(247, 247, 247));

        lblInfosLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        lblInfosLabel.setForeground(new java.awt.Color(0, 102, 204));
        lblInfosLabel.setText("Informations (Dossier)");
        lblInfosLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblInfosLabelMouseClicked(evt);
            }
        });

        lblOPLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        lblOPLabel.setForeground(new java.awt.Color(204, 204, 204));
        lblOPLabel.setText("Prise en charge des OP  ");
        lblOPLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblOPLabelMouseClicked(evt);
            }
        });

        lblPaiementLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        lblPaiementLabel.setForeground(new java.awt.Color(204, 204, 204));
        lblPaiementLabel.setText("Validation du Paiement ");
        lblPaiementLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPaiementLabelMouseClicked(evt);
            }
        });

        lblOPIcon.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        lblOPIcon.setForeground(new java.awt.Color(204, 204, 204));
        lblOPIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOPIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png"))); // NOI18N
        lblOPIcon.setText("2");
        lblOPIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblOPIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblOPIconMouseClicked(evt);
            }
        });

        lblPaiementIcon.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        lblPaiementIcon.setForeground(new java.awt.Color(204, 204, 204));
        lblPaiementIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblPaiementIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png"))); // NOI18N
        lblPaiementIcon.setText("4");
        lblPaiementIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblPaiementIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblPaiementIconMouseClicked(evt);
            }
        });

        lblInfosIcon.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        lblInfosIcon.setForeground(new java.awt.Color(255, 255, 255));
        lblInfosIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblInfosIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png"))); // NOI18N
        lblInfosIcon.setText("1");
        lblInfosIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblInfosIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblInfosIconMouseClicked(evt);
            }
        });

        lblReglementIcon.setFont(new java.awt.Font("Arial", 1, 36)); // NOI18N
        lblReglementIcon.setForeground(new java.awt.Color(204, 204, 204));
        lblReglementIcon.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblReglementIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png"))); // NOI18N
        lblReglementIcon.setText("3");
        lblReglementIcon.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblReglementIcon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReglementIconMouseClicked(evt);
            }
        });

        lblReglementLabel.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        lblReglementLabel.setForeground(new java.awt.Color(204, 204, 204));
        lblReglementLabel.setText("Mode de reglement");
        lblReglementLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblReglementLabelMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout pBoutonsLayout = new javax.swing.GroupLayout(pBoutons);
        pBoutons.setLayout(pBoutonsLayout);
        pBoutonsLayout.setHorizontalGroup(
            pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pBoutonsLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pBoutonsLayout.createSequentialGroup()
                        .addComponent(lblInfosLabel)
                        .addGap(66, 66, 66)
                        .addComponent(lblOPLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 172, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pBoutonsLayout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(lblInfosIcon)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblOPIcon)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pBoutonsLayout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(lblReglementIcon)
                        .addGap(18, 18, 18)
                        .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(lblPaiementIcon)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pBoutonsLayout.createSequentialGroup()
                        .addComponent(lblReglementLabel)
                        .addGap(129, 129, 129)
                        .addComponent(lblPaiementLabel)
                        .addGap(0, 168, Short.MAX_VALUE))))
        );
        pBoutonsLayout.setVerticalGroup(
            pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pBoutonsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pBoutonsLayout.createSequentialGroup()
                        .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblInfosLabel)
                            .addComponent(lblOPLabel))
                        .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pBoutonsLayout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(lblInfosIcon)
                                    .addComponent(lblOPIcon)))
                            .addGroup(pBoutonsLayout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pBoutonsLayout.createSequentialGroup()
                                .addGap(28, 28, 28)
                                .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pBoutonsLayout.createSequentialGroup()
                        .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblReglementLabel)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pBoutonsLayout.createSequentialGroup()
                                .addComponent(lblPaiementLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)))
                        .addGroup(pBoutonsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblReglementIcon)
                            .addGroup(pBoutonsLayout.createSequentialGroup()
                                .addGap(27, 27, 27)
                                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblPaiementIcon))))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        getContentPane().add(pBoutons, java.awt.BorderLayout.NORTH);

        cardPanel.setLayout(new java.awt.CardLayout());

        pInfos.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 204));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "IMPUTATION", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N
        pObjetCommande.setOpaque(false);
        pObjetCommande.setLayout(null);

        jLabel6.setText("Tâche : ");
        pObjetCommande.add(jLabel6);
        jLabel6.setBounds(20, 60, 70, 30);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(20, 100, 80, 30);

        cboTache.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboTacheItemStateChanged(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 60, 480, 30);

        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 100, 290, 30);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(20, 20, 70, 30);

        cboStructureImputation.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboStructureImputationItemStateChanged(evt);
            }
        });
        pObjetCommande.add(cboStructureImputation);
        cboStructureImputation.setBounds(110, 20, 480, 30);

        btnTTC.setText("0");
        btnTTC.setCouleur(4);
        btnTTC.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnTTC.setStyle(3);
        btnTTC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnTTCMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnTTCMouseExited(evt);
            }
        });
        pObjetCommande.add(btnTTC);
        btnTTC.setBounds(410, 100, 180, 30);

        jPanel2.add(pObjetCommande, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 290, 600, 150));

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 230, 240, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        jPanel2.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 10, 166, -1));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 10, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 60, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        jPanel2.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 250, 590, 30));
        jPanel2.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 10, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 60, 496, 50));

        txtReference.setEditable(false);
        jPanel2.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 120, 496, -1));

        txtSignataire.setEditable(false);
        jPanel2.add(txtSignataire, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 150, 496, -1));

        dtpDatesignature.setEditable(false);
        jPanel2.add(dtpDatesignature, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 190, 177, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 120, 86, 22));

        jLabel19.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel19.setText("signataire : ");
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 150, 86, 22));

        jLabel20.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel20.setText("Date : ");
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 190, 86, 22));

        pInfos.add(jPanel2, java.awt.BorderLayout.CENTER);

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 5));

        btnInfosSuivant.setText("Suivant >>>");
        btnInfosSuivant.setCouleur(4);
        btnInfosSuivant.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnInfosSuivant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInfosSuivantActionPerformed(evt);
            }
        });
        jPanel4.add(btnInfosSuivant);

        pInfos.add(jPanel4, java.awt.BorderLayout.SOUTH);

        cardPanel.add(pInfos, "dossier");

        pOrdrePaiement.setLayout(new java.awt.BorderLayout());

        panelPriseEnCharge.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 102, 204));
        jLabel7.setText("Liste des Ordres de Paiement en cours de prise en charge ");

        tblOrdrePaiement.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        tblOrdrePaiement.setRowHeight(30);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listMandatement}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblOrdrePaiement);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${priseEnCharge}"));
        columnBinding.setColumnName("PE");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("Num Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numeroOP}"));
        columnBinding.setColumnName("Numero OP");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${rubrique}"));
        columnBinding.setColumnName("Details");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${rubriqueMontant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane4.setViewportView(tblOrdrePaiement);
        if (tblOrdrePaiement.getColumnModel().getColumnCount() > 0) {
            tblOrdrePaiement.getColumnModel().getColumn(0).setResizable(false);
            tblOrdrePaiement.getColumnModel().getColumn(0).setPreferredWidth(15);
            tblOrdrePaiement.getColumnModel().getColumn(0).setCellRenderer(new BooleanTableRenderer());
            tblOrdrePaiement.getColumnModel().getColumn(3).setMinWidth(150);
            tblOrdrePaiement.getColumnModel().getColumn(3).setPreferredWidth(200);
            tblOrdrePaiement.getColumnModel().getColumn(4).setCellRenderer(new DecimalTableRenderer());
        }

        txtSommeOP.setEditable(false);
        txtSommeOP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtSommeOP.setEnabled(false);
        txtSommeOP.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N

        jPanel5.setBackground(new java.awt.Color(254, 217, 202));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder("SAISIE DES ECRITURES EN COMPTABILITE GENERALE"));

        tableEcritures.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "REFERENCE", "DESIGNATION", "QTE", "PRIX UNIT.", "PRIX TOTAL", "REMISE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableEcritures.setColumnSelectionAllowed(true);
        tableEcritures.setRowHeight(25);
        tableEcritures.setShowGrid(true);
        tableEcritures.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableEcrituresKeyReleased(evt);
            }
        });
        scrollTable.setViewportView(tableEcritures);
        tableEcritures.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        txtDebit.setEditable(false);
        txtDebit.setForeground(new java.awt.Color(153, 0, 204));
        txtDebit.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtDebit.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        txtCredit.setEditable(false);
        txtCredit.setForeground(new java.awt.Color(255, 153, 0));
        txtCredit.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtCredit.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        jLabel2.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel2.setText("Débit : ");

        jLabel4.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel4.setText("Crédit : ");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDebit, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCredit, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(249, 249, 249))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(scrollTable, javax.swing.GroupLayout.PREFERRED_SIZE, 1113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDebit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCredit, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollTable, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );

        btnPriseEnChargeAnnuler.setText("Annuler la prise en charge");
        btnPriseEnChargeAnnuler.setCouleur(1);
        btnPriseEnChargeAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPriseEnChargeAnnulerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelPriseEnChargeLayout = new javax.swing.GroupLayout(panelPriseEnCharge);
        panelPriseEnCharge.setLayout(panelPriseEnChargeLayout);
        panelPriseEnChargeLayout.setHorizontalGroup(
            panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPriseEnChargeLayout.createSequentialGroup()
                .addGap(98, 98, 98)
                .addGroup(panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelPriseEnChargeLayout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(35, 35, 35)
                        .addComponent(txtSommeOP))
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(35, 35, 35)
                .addComponent(btnPriseEnChargeAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(78, Short.MAX_VALUE))
            .addGroup(panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelPriseEnChargeLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelPriseEnChargeLayout.setVerticalGroup(
            panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPriseEnChargeLayout.createSequentialGroup()
                .addGroup(panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSommeOP, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPriseEnChargeLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelPriseEnChargeLayout.createSequentialGroup()
                        .addGap(87, 87, 87)
                        .addComponent(btnPriseEnChargeAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(259, Short.MAX_VALUE))
            .addGroup(panelPriseEnChargeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPriseEnChargeLayout.createSequentialGroup()
                    .addContainerGap(198, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pOrdrePaiement.add(panelPriseEnCharge, java.awt.BorderLayout.CENTER);

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 50, 5));

        btnValiderCreance.setText("Valider la creance >>>");
        btnValiderCreance.setCouleur(4);
        btnValiderCreance.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnValiderCreance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnValiderCreanceActionPerformed(evt);
            }
        });
        jPanel1.add(btnValiderCreance);

        pOrdrePaiement.add(jPanel1, java.awt.BorderLayout.SOUTH);

        cardPanel.add(pOrdrePaiement, "op");

        pModePaiement.setBackground(new java.awt.Color(255, 255, 255));
        pModePaiement.setLayout(null);

        jLabel21.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(153, 153, 153));
        jLabel21.setText("Selectionnez le mode de reglement SVP  ");
        pModePaiement.add(jLabel21);
        jLabel21.setBounds(260, 30, 440, 28);

        btnModePaiement.setText("Valider le mode de paiement  >>>");
        btnModePaiement.setCouleur(4);
        btnModePaiement.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnModePaiement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModePaiementActionPerformed(evt);
            }
        });
        pModePaiement.add(btnModePaiement);
        btnModePaiement.setBounds(360, 410, 256, 38);

        tableLiquidite.setColumnSelectionAllowed(true);
        tableLiquidite.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        tableLiquidite.setRowHeight(25);
        tableLiquidite.getTableHeader().setReorderingAllowed(false);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listCompteLiquidite}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableLiquidite);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelleFr}"));
        columnBinding.setColumnName("ORIGINE DES FONDS A DECAISSER");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${liquidite}"), tableLiquidite, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane6.setViewportView(tableLiquidite);
        tableLiquidite.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        pModePaiement.add(jScrollPane6);
        jScrollPane6.setBounds(240, 80, 460, 200);

        jLabel22.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel22.setText("Pieces (recu, cheque, ...)");
        pModePaiement.add(jLabel22);
        jLabel22.setBounds(250, 300, 210, 50);

        txtPiecesPaiement.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        pModePaiement.add(txtPiecesPaiement);
        txtPiecesPaiement.setBounds(470, 300, 230, 50);

        cardPanel.add(pModePaiement, "reglement");

        pPaiement.setLayout(new java.awt.BorderLayout());

        panelPaiement.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(0, 102, 204));
        jLabel8.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        jLabel8.setText("Total des reglements restant a effectuer ");

        tblPaiement.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        tblPaiement.setRowHeight(30);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listMandatementPaiement}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblPaiement);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${regle}"));
        columnBinding.setColumnName("Regle");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numeroOP}"));
        columnBinding.setColumnName("Numero OP");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${rubrique}"));
        columnBinding.setColumnName("Rubrique");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${rubriqueMontant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${reglementEnCours}"));
        columnBinding.setColumnName("deja Regles");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${reglementRestant}"));
        columnBinding.setColumnName("Reste A Payer");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane5.setViewportView(tblPaiement);
        if (tblPaiement.getColumnModel().getColumnCount() > 0) {
            tblPaiement.getColumnModel().getColumn(0).setResizable(false);
            tblPaiement.getColumnModel().getColumn(0).setPreferredWidth(10);
            tblPaiement.getColumnModel().getColumn(0).setCellRenderer(new BooleanTableRenderer());
            tblPaiement.getColumnModel().getColumn(3).setCellRenderer(new DecimalTableRenderer());
            tblPaiement.getColumnModel().getColumn(4).setCellRenderer(new DecimalTableRenderer());
            tblPaiement.getColumnModel().getColumn(5).setCellRenderer(new DecimalTableRenderer());
        }

        txtSommeReglement.setEditable(false);
        txtSommeReglement.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtSommeReglement.setEnabled(false);
        txtSommeReglement.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N

        jPanel6.setBackground(new java.awt.Color(0, 153, 204));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "SAISIE DES ECRITURES EN COMPTABILITE GENERALE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(255, 255, 255))); // NOI18N

        tableEcrituresPaiement.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "REFERENCE", "DESIGNATION", "QTE", "PRIX UNIT.", "PRIX TOTAL", "REMISE"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, true, true, false, true
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableEcrituresPaiement.setRowHeight(25);
        tableEcrituresPaiement.setShowGrid(true);
        tableEcrituresPaiement.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableEcrituresPaiementKeyReleased(evt);
            }
        });
        scrollTable1.setViewportView(tableEcrituresPaiement);
        tableEcrituresPaiement.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_INTERVAL_SELECTION);

        txtDebitPaiement.setEditable(false);
        txtDebitPaiement.setForeground(new java.awt.Color(153, 0, 204));
        txtDebitPaiement.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtDebitPaiement.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        txtCreditPaiement.setEditable(false);
        txtCreditPaiement.setForeground(new java.awt.Color(255, 153, 0));
        txtCreditPaiement.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtCreditPaiement.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setText("Débit : ");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        jLabel11.setForeground(new java.awt.Color(255, 255, 255));
        jLabel11.setText("Crédit : ");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtDebitPaiement, javax.swing.GroupLayout.PREFERRED_SIZE, 164, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(42, 42, 42)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtCreditPaiement, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(249, 249, 249))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(scrollTable1, javax.swing.GroupLayout.PREFERRED_SIZE, 1113, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtDebitPaiement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtCreditPaiement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollTable1, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(52, 52, 52))
        );

        btnPaiementAnnuler.setText("Annuler le reglement");
        btnPaiementAnnuler.setCouleur(1);
        btnPaiementAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPaiementAnnulerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelPaiementLayout = new javax.swing.GroupLayout(panelPaiement);
        panelPaiement.setLayout(panelPaiementLayout);
        panelPaiementLayout.setHorizontalGroup(
            panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPaiementLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPaiementLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 453, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtSommeReglement, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelPaiementLayout.createSequentialGroup()
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 881, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnPaiementAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(75, Short.MAX_VALUE))
            .addGroup(panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(panelPaiementLayout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        panelPaiementLayout.setVerticalGroup(
            panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelPaiementLayout.createSequentialGroup()
                .addGroup(panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtSommeReglement, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelPaiementLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelPaiementLayout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(btnPaiementAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(259, Short.MAX_VALUE))
            .addGroup(panelPaiementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelPaiementLayout.createSequentialGroup()
                    .addContainerGap(198, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        pPaiement.add(panelPaiement, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 20, 5));

        btnPaiementValide.setText("Valider le paiement");
        btnPaiementValide.setCouleur(4);
        btnPaiementValide.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnPaiementValide.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPaiementValideActionPerformed(evt);
            }
        });
        jPanel3.add(btnPaiementValide);

        pPaiement.add(jPanel3, java.awt.BorderLayout.SOUTH);

        cardPanel.add(pPaiement, "paiement");

        getContentPane().add(cardPanel, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTTCMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTTCMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btnTTCMouseEntered

    private void btnTTCMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTTCMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnTTCMouseExited

    private void calculerNAP() {
        Number ttc;
        if (txtMontant.getValue() == null) {
            ttc = new Long(0);
        } else {
            ttc = (Number) txtMontant.getValue();
        }
        long taxe = 0;
        //si la liste des retenues existe, recalculer les montants
        if (listRetenues.size() > 0) {
            List<LiquidationDroits> l = new ArrayList<>();
            for (LiquidationDroits d : listRetenues) {
                double t = d.getTaux();
                double m = t * ttc.doubleValue() / 100;
                d.setMontant(new BigDecimal(m));
                l.add(d);
            }
            listRetenues.clear();
            for (LiquidationDroits e : l) {
                listRetenues.add(e);
            }
        }
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (LiquidationDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
        long nap = ttc.longValue() - taxe;
        txtNAP.setValue(nap);
    }

    private void getRetenue() {

        long taxe = 0;
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (LiquidationDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
    }
    private void btnInfosSuivantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInfosSuivantActionPerformed
        // TODO add your handling code here:
        //afficherInfos(false, true, false);
        Color actived = new Color(0, 102, 204);
        Color desactived = new Color(204, 204, 204);
        lblInfosIcon.setForeground(desactived);
        lblInfosIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
        lblInfosLabel.setForeground(actived);

        lblOPIcon.setForeground(Color.white);
        lblOPIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
        lblOPLabel.setForeground(actived);

        btnInfosSuivant.setVisible(false);
        btnValiderCreance.setVisible(true);

        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "op");

    }//GEN-LAST:event_btnInfosSuivantActionPerformed

    private void cboStructureImputationItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboStructureImputationItemStateChanged
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructureImputation.getSelectedItem();
        } catch (Exception ex) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(currentEngagement.getMillesime(),
                        currentEngagement.getOrganisationID(), s.getStructureID());
            } catch (Exception exx) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureImputationItemStateChanged

    private void cboTacheItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboTacheItemStateChanged
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();

        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheItemStateChanged

    private boolean controlePourPaiement() {
        boolean result = true;

        if (listMandatementPaiement.size() == 0) {
            GrecoOptionPane.showWarningDialog("Aucun Ordre de Paiement a regler ...");
            return false;
        }
        Number debit = (Number) txtDebitPaiement.getValue();
        Number credit = (Number) txtDebitPaiement.getValue();

        if (debit.longValue() == 0 || credit.longValue() == 0) {
            GrecoOptionPane.showWarningDialog("Ecriture non autorise. Le debit et le credit ne peuvent pas etre a zero (0)");
            return false;
        }

        if (debit.longValue() != credit.longValue()) {
            GrecoOptionPane.showWarningDialog("Cette ecriture n'est pas equilibree en debit / credit");
            return false;
        }
//        else {
//            Number op = (Number) txtSommeOP.getValue();
//            if (debit.longValue() != op.longValue()) {
//                GrecoOptionPane.showWarningDialog("Le debit total des ecritures comptables ne correspond pas a la somme des Ordres de Reglements");
//                return false;
//            }
//        }

        List<Ecritures> list = modeleTableEcrituresPaiement.getDataListToSave();
        if (list.size() == 0) {
            GrecoOptionPane.showWarningDialog("Les ecritures comptables a passer en debit / credit nont pas ete identifiees ...");
            return false;
        }
        for (Ecritures e : list) {
            if (e.getJournalID() == null) {
                GrecoOptionPane.showWarningDialog("Veuillez renseigner la 1ere colonne JOURNAL de la ligne : " + e.getLibelle());
                return false;
            }
        }
        for (Ecritures e : list) {
            if (e.getCompte() == null) {
                GrecoOptionPane.showWarningDialog("Veuillez renseigner la 3eme colonne COMPTE de la ligne : " + e.getLibelle());
                return false;
            }
        }
        return result;
    }

    private boolean controlePourValidationVreance() {
        boolean result = true;

        if (listMandatement.size() == 0) {
            GrecoOptionPane.showWarningDialog("Aucun Ordre de Paiement a vaider ...");
            return false;
        }
        Number debit = (Number) txtDebit.getValue();
        Number credit = (Number) txtCredit.getValue();

        if (debit.longValue() == 0 || credit.longValue() == 0) {
            GrecoOptionPane.showWarningDialog("Ecriture non autorise. Le debit et le credit ne peuvent pas etre a zero (0)");
            return false;
        }

        if (debit.longValue() != credit.longValue()) {
            GrecoOptionPane.showWarningDialog("Cette ecriture n'est pas equilibree en debit / credit");
            return false;
        } else {
            Number op = (Number) txtSommeOP.getValue();
            if (debit.longValue() != op.longValue()) {
                GrecoOptionPane.showWarningDialog("Le debit total des ecritures comptables ne correspond pas a la somme des Ordres de Paiements");
                return false;
            }
        }

        List<Ecritures> list = modeleTableEcritures.getDataListToSave();
        if (list.size() == 0) {
            GrecoOptionPane.showWarningDialog("Les ecritures comptables a passer en debit / credit nont pas ete identifiees ...");
            return false;
        }
        for (Ecritures e : list) {
            if (e.getJournalID() == null) {
                GrecoOptionPane.showWarningDialog("Veuillez renseigner la 1ere colonne JOURNAL de la ligne : " + e.getLibelle());
                return false;
            }
        }
        for (Ecritures e : list) {
            if (e.getCompte() == null) {
                GrecoOptionPane.showWarningDialog("Veuillez renseigner la 3eme colonne COMPTE de la ligne : " + e.getLibelle());
                return false;
            }
        }
        return result;
    }
    private void btnValiderCreanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnValiderCreanceActionPerformed
        // TODO add your handling code here:
        if (controlePourValidationVreance()) {

            int res = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir valider la prise en charge de ce dossier ? \n"
                    + currentEngagement.getObjet() + "\n\\n" + currentEngagement.getBeneficiaire());
            //enregistrement 
            if (res == JOptionPane.YES_OPTION) {
                List<String> listeOPIDs = new ArrayList<>();
                for (Mandatement op : listMandatement) {
                    listeOPIDs.add(op.getMandatementID());
                }
                try {
                    GrecoServiceFactory.getEngagementService().validationComptable(listeOPIDs, modeleTableEcritures.getDataListToSave(), true, false);
                    GrecoSession.notifications.success();
                    modeleTableEcritures.setBlockUpdate(true);
                    reloadMandatement();
                    GrecoOptionPane.showSuccessDialog("Prise en charge effectuee avec success");
                    btnPriseEnChargeAnnuler.setVisible(true);
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }

                //passage au paiement 
                Color actived = new Color(0, 102, 204);
                Color desactived = new Color(204, 204, 204);
                lblOPIcon.setForeground(desactived);
                lblOPIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
                lblOPLabel.setForeground(actived);

                lblReglementIcon.setForeground(Color.white);
                lblReglementIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
                lblReglementLabel.setForeground(actived);

                btnValiderCreance.setVisible(false);
                btnModePaiement.setVisible(true);

                ((CardLayout) cardPanel.getLayout()).show(cardPanel, "reglement");
            }
        }
    }//GEN-LAST:event_btnValiderCreanceActionPerformed

    private void lblInfosLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblInfosLabelMouseClicked
        // TODO add your handling code here:
        afficherInfos(true, false, false, false);
    }//GEN-LAST:event_lblInfosLabelMouseClicked

    private void lblOPLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOPLabelMouseClicked
        // TODO add your handling code here:
        afficherInfos(false, true, false, false);
    }//GEN-LAST:event_lblOPLabelMouseClicked

    private void lblPaiementLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPaiementLabelMouseClicked
        // TODO add your handling code here:
        afficherInfos(false, false, true, false);
    }//GEN-LAST:event_lblPaiementLabelMouseClicked

    private void lblInfosIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblInfosIconMouseClicked
        // TODO add your handling code here:
        afficherInfos(true, false, false, false);
    }//GEN-LAST:event_lblInfosIconMouseClicked

    private void lblOPIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblOPIconMouseClicked
        // TODO add your handling code here:
        afficherInfos(false, true, false, false);
    }//GEN-LAST:event_lblOPIconMouseClicked

    private void lblPaiementIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblPaiementIconMouseClicked
        // TODO add your handling code here:
        afficherInfos(false, false, true, false);
    }//GEN-LAST:event_lblPaiementIconMouseClicked

    private void btnPaiementValideActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPaiementValideActionPerformed
        if (controlePourPaiement()) {

            int res = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir effectuer le reglement de ce dossier ? \n"
                    + currentEngagement.getObjet() + "\n\\n" + currentEngagement.getBeneficiaire());
            //enregistrement 
            if (res == JOptionPane.YES_OPTION) {
                List<Paiement> listeOPIDs = new ArrayList<>();
                for (Mandatement op : listMandatementPaiement) {
                    Paiement p = new Paiement();
                    p.setDatePaiement(new Date());
                    p.setMontant(op.getReglementRestant());
                    p.setDroitID(op.getRubriqueID());
                    p.setLiquiditeID(liquidite.getLiquiditeID());
                    p.setMandatementID(op.getMandatementID());
                    p.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    p.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                    p.setReference(op.getNumeroOP()+"; "+txtPiecesPaiement.getText().trim());

                    listeOPIDs.add(p);
                }
                try {
                    GrecoServiceFactory.getEngagementService().validationComptablePaiement(listeOPIDs, modeleTableEcrituresPaiement.getDataListToSave(), true);
                    GrecoSession.notifications.success();
                    modeleTableEcrituresPaiement.setBlockUpdate(true);
                    btnPriseEnChargeAnnuler.setVisible(false);
                    btnPaiementValide.setVisible(false);
                    btnPaiementAnnuler.setVisible(true);
                    reloadMandatementPaiement();
                    GrecoOptionPane.showSuccessDialog("Reglement effectuee avec success");
                    
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }

                //passage au paiement 
                Color actived = new Color(0, 102, 204);
                Color desactived = new Color(204, 204, 204);
                lblOPIcon.setForeground(desactived);
                lblOPIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
                lblOPLabel.setForeground(actived);

                lblPaiementIcon.setForeground(Color.white);
                lblPaiementIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
                lblPaiementLabel.setForeground(actived);

                btnValiderCreance.setVisible(false);
                btnPaiementValide.setVisible(true);

                loadMandatementPaiement();

                ((CardLayout) cardPanel.getLayout()).show(cardPanel, "paiement");
            }

        }

    }//GEN-LAST:event_btnPaiementValideActionPerformed

    private void tableEcrituresKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableEcrituresKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_TAB) {
            ajouterLigne();
        } else if (evt.getKeyCode() == KeyEvent.VK_BACK_SPACE) {
            deleteLigne();
        }
    }//GEN-LAST:event_tableEcrituresKeyReleased

    private void tableEcrituresPaiementKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableEcrituresPaiementKeyReleased
        // TODO add your handling code here:
    }//GEN-LAST:event_tableEcrituresPaiementKeyReleased

    private void btnPriseEnChargeAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPriseEnChargeAnnulerActionPerformed
        // TODO add your handling code here:
        if (listMandatement.size() == 0) {
            GrecoOptionPane.showWarningDialog("Aucun Ordre de Paiement a annuler ...");
            return;
        }
        int res = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir annuler la prise en charge de ce dossier ? \n"
                + currentEngagement.getObjet() + "\n" + currentEngagement.getBeneficiaire());
        //enregistrement 
        if (res == JOptionPane.YES_OPTION) {
            try {
                List<String> list = new ArrayList<>();
                for (Mandatement m : listMandatement) {
                    list.add(m.getMandatementID());
                }
                GrecoServiceFactory.getEngagementService().validationComptableAnnuler(list, currentEngagement.getNumDossier(), true, false);
                GrecoSession.notifications.success();
                modeleTableEcritures.setBlockUpdate(false);
                loadMandatement();
                GrecoOptionPane.showInformationDialog("L'annulation de la Prise en charge a effectuee avec success");
                btnPriseEnChargeAnnuler.setVisible(false);
                btnModePaiement.setVisible(false);
                btnPaiementValide.setVisible(false);
                btnValiderCreance.setVisible(true);
            } catch (GrecoException e) {
                GrecoSession.notifications.echec();
                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                return;
            }
        }
    }//GEN-LAST:event_btnPriseEnChargeAnnulerActionPerformed

    private void btnPaiementAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPaiementAnnulerActionPerformed
        // TODO add your handling code here:
        if (listMandatementPaiement.size() == 0) {
            GrecoOptionPane.showWarningDialog("Aucun Ordre de Reglement a annuler ...");
            return;
        }
        int res = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir annuler le reglement de ce dossier ? \n"
                + currentEngagement.getObjet() + "\n" + currentEngagement.getBeneficiaire());
        //enregistrement 
        if (res == JOptionPane.YES_OPTION) {
            try {
                List<String> list = new ArrayList<>();
                for (Mandatement m : listMandatementPaiement) {
                    list.add(m.getMandatementID());
                }
                GrecoServiceFactory.getEngagementService().validationComptableAnnuler(list, currentEngagement.getNumDossier(), false, true);
                GrecoSession.notifications.success();
                modeleTableEcrituresPaiement.setBlockUpdate(false);
                reloadMandatement();
                GrecoOptionPane.showInformationDialog("L'annulation du reglement a effectuee avec success");
                btnPaiementAnnuler.setVisible(false);
                btnPaiementValide.setVisible(true);
            } catch (GrecoException e) {
                GrecoSession.notifications.echec();
                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                return;
            }
        }
    }//GEN-LAST:event_btnPaiementAnnulerActionPerformed

    private void btnModePaiementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModePaiementActionPerformed
        // TODO add your handling code here
        try {
            // liquidite = (CompteLiquidite) tableLiquidite.getValueAt(tableLiquidite.getSelectedRow(), tableLiquidite.getSelectedColumn());
            if (liquidite == null) {
                GrecoOptionPane.showErrorDialog("Selectionner le mode de reglement de cette depense SVP");
                return;
            }

        } catch (IndexOutOfBoundsException e) {
            GrecoOptionPane.showErrorDialog("Selectionner le mode de reglement de cette depense SVP");
            return;
        }

        //passage au paiement 
        Color actived = new Color(0, 102, 204);
        Color desactived = new Color(204, 204, 204);
        lblReglementIcon.setForeground(desactived);
        lblReglementIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
        lblReglementLabel.setForeground(actived);

        lblPaiementIcon.setForeground(Color.white);
        lblPaiementIcon.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")));
        lblPaiementLabel.setForeground(actived);

        btnModePaiement.setVisible(false);
        btnPaiementValide.setVisible(true);

        loadMandatementPaiement();

        ((CardLayout) cardPanel.getLayout()).show(cardPanel, "paiement");
    }//GEN-LAST:event_btnModePaiementActionPerformed

    private void lblReglementIconMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReglementIconMouseClicked
        // TODO add your handling code here:
        afficherInfos(false, false, false, true);
    }//GEN-LAST:event_lblReglementIconMouseClicked

    private void lblReglementLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblReglementLabelMouseClicked
        // TODO add your handling code here:
        afficherInfos(false, false, false, true);
    }//GEN-LAST:event_lblReglementLabelMouseClicked

    public void ajouterLigne() {
        Ecritures a = new Ecritures();
        modeleTableEcritures.addArticle(a);
    }

    public void deleteLigne() {
        int[] selection = tableEcritures.getSelectedRows();
        if (selection.length > 0) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer ces lignes ??");
            if (res == JOptionPane.YES_OPTION) {
                for (int i = selection.length - 1; i >= 0; i--) {
                    modeleTableEcritures.removeArticle(selection[i]);
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Aucune ligne a retirer. Veuillez selectionner une ligne SVP");
        }
    }

    private void afficherInfos(boolean isInfos, boolean isOP, boolean isPaiement, boolean isModeReglement) {
//        Color actived = new Color(0,102,204);
//        Color desactived = new Color(204, 204, 204);
//        lblInfosIcon.setForeground(isInfos?Color.white:desactived);
//        lblInfosIcon.setIcon(isInfos?new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")):new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png"))); 
//        lblInfosLabel.setForeground(isInfos?actived:desactived);
        if (isInfos) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "dossier");
        }

//        lblOPIcon.setForeground(isOP?Color.white:desactived);
//        lblOPIcon.setIcon(isOP?new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")):new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png"))); 
//        lblOPLabel.setForeground(isOP?actived:desactived);
        if (isOP) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "op");
        }

//        lblPaiementIcon.setForeground(isPaiement?Color.white:desactived);
//        lblPaiementIcon.setIcon(isPaiement?new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")):new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png"))); 
//        lblPaiementLabel.setForeground(isPaiement?actived:desactived);
        if (isPaiement) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "paiement");
        }

        if (isModeReglement) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "reglement");
        }

    }

    private void advancedState(boolean isInfos, boolean isOP, boolean isPaiement) {
        Color actived = new Color(0, 102, 204);
        Color desactived = new Color(204, 204, 204);
        lblInfosIcon.setForeground(isInfos ? Color.white : desactived);
        lblInfosIcon.setIcon(isInfos ? new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")) : new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png")));
        lblInfosLabel.setForeground(isInfos ? actived : desactived);
        if (isInfos) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "dossier");
        }

        lblOPIcon.setForeground(isOP ? Color.white : desactived);
        lblOPIcon.setIcon(isOP ? new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")) : new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png")));
        lblOPLabel.setForeground(isOP ? actived : desactived);
        if (isOP) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "op");
        }

        lblPaiementIcon.setForeground(isPaiement ? Color.white : desactived);
        lblPaiementIcon.setIcon(isPaiement ? new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondPlein.png")) : new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/rondVide.png")));
        lblPaiementLabel.setForeground(isPaiement ? actived : desactived);
        if (isPaiement) {
            ((CardLayout) cardPanel.getLayout()).show(cardPanel, "paiement");
        }

    }

    private void valider() {
        String msg = "";
        boolean activer = false;

        String motif = "";
        int res = GrecoOptionPane.showConfirmDialog(msg);
        List<Mandatement> listOP = new ArrayList<>();
        for (Mandatement mandatement : listMandatement) {
            listOP.add(mandatement);
        }
        if (res == JOptionPane.YES_OPTION) {
            glasspane.attente();

            try {
                String captcha = "";
                captcha = GrecoServiceFactory.getEngagementService().validerRegulariteOP(currentEngagement.getEngagementID(), activer, motif,
                        GrecoSession.USER_CONNECTED.getLogin(), listOP);

                if (captcha == null) {
                    GrecoOptionPane.showErrorDialog("Erreur lors de la validation des ordres paiements");
                    return;
                }
                GrecoSession.notifications.success();
                btnValiderCreance.setVisible(false);
                GrecoOptionPane.showSuccessDialog("Opération effectuée avec succès. \n Veuillez marquer le numéro suivant sur la fiche d'engagement : \n" + captcha);
                glasspane.arret();
            } catch (Exception e) {
                GrecoSession.notifications.echec();
                GrecoOptionPane.showErrorDialog("Echec de l'opération");
                glasspane.arret();
            }
        }
    }

    private void disableComponents() {
        btnBeneficiare.setEnabled(false);
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);
        txtMontant.setEnabled(true);
        txtObjet.setEditable(false);
        txtReference.setEditable(false);
        txtSignataire.setEditable(false);
    }

    private void afficherCout() {
        try {
            btnTTC.setText(txtMontant.getText());
        } catch (Exception e) {
        }
    }

    public List<LiquidationDroits> getListRetenues() {
        return listRetenues;
    }

    public void setListRetenues(List<LiquidationDroits> listRetenues) {
        this.listRetenues = listRetenues;
    }

    public List<VueControle> getListDossiers() {
        return listDossiers;
    }

    public void setListDossiers(List<VueControle> listDossiers) {
        this.listDossiers = listDossiers;
    }

    public boolean validerFacture() {
        return true;
    }

    public List<Mandatement> getListMandatement() {
        return listMandatement;
    }

    public void setListMandatement(List<Mandatement> listMandatement) {
        this.listMandatement = listMandatement;
    }

    private void reloadMandatement() {
        listMandatement.clear();
        List<Mandatement> list = GrecoServiceFactory.getEngagementService().MandatementByEtatRubriques(currentEngagement.getOrganisationID(), currentEngagement.getMillesime(),
                currentEngagement.getNumDossier(), "" + EtatDossier.prisEnCharge);
        if (list != null && !list.isEmpty()) {
            for (Mandatement m : list) {
                listMandatement.add(m);
            }
        }
    }

    private void reloadMandatementPaiement() {
        listMandatementPaiement.clear();
        List<Mandatement> list = GrecoServiceFactory.getEngagementService().MandatementByEtatRubriquesPaiement(currentEngagement.getOrganisationID(), currentEngagement.getMillesime(),
                currentEngagement.getNumDossier(), "" + EtatDossier.regle);
        if (list != null && !list.isEmpty()) {
            for (Mandatement m : list) {
                listMandatementPaiement.add(m);
            }
        }
    }

    private void loadMandatement() {
        listMandatement.clear();
        List<Mandatement> list = GrecoServiceFactory.getEngagementService().MandatementByEtatRubriques(currentEngagement.getOrganisationID(), currentEngagement.getMillesime(),
                currentEngagement.getNumDossier(), "" + EtatDossier.receptionneComptable);
        BigDecimal sommeOP = BigDecimal.ZERO;
        List<Ecritures> listEcritures = new ArrayList<>();
        if (list != null && !list.isEmpty()) {
            for (Mandatement m : list) {
                listMandatement.add(m);
                sommeOP = sommeOP.add(m.getRubriqueMontant());
                listEcritures.add(getEcritures(m, false, BigDecimal.ZERO));
            }
        }
        txtSommeOP.setValue(sommeOP);

        List<Ecritures> listEcrituresCompta = new ArrayList<>();
        listEcrituresCompta.add(getEcritures(null, true, sommeOP));
        for (Ecritures e : listEcritures) {
            listEcrituresCompta.add(e);
        }
        modeleTableEcritures.setDataList(listEcrituresCompta);

    }

    private void loadMandatementPaiement() {
        listMandatementPaiement.clear();
        List<Mandatement> list = GrecoServiceFactory.getEngagementService().MandatementByEtatRubriquesPaiement(currentEngagement.getOrganisationID(), currentEngagement.getMillesime(),
                currentEngagement.getNumDossier(), "" + EtatDossier.prisEnCharge);
        BigDecimal sommeOP = BigDecimal.ZERO;
        List<Ecritures> listEcritures = new ArrayList<>();
        if (list != null && !list.isEmpty()) {
            for (Mandatement m : list) {
                listMandatementPaiement.add(m);
                sommeOP = sommeOP.add(m.getReglementRestant() == null ? BigDecimal.ZERO : m.getReglementRestant());
                getEcrituresPaiement(m, listEcritures);
            }
        }
        txtSommeReglement.setValue(sommeOP);
        modeleTableEcrituresPaiement.setDataList(listEcritures);
    }

    private Ecritures getEcritures(Mandatement m, boolean principal, BigDecimal somme) {
        Ecritures e = new Ecritures();
        if (principal) {
            OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
            e.setCompte(op.getCompteCode());
            e.setCredit(BigDecimal.ZERO);
            e.setDebit(somme);
            e.setJournalID(null);
            e.setLibelle(TypeDossier.getLibelleType(currentEngagement.getTypeID()) + " - " + currentEngagement.getBeneficiaire());
            e.setMandatementID(null);
            e.setDroitID(null);
            e.setPieces(currentEngagement.getNumDossier());
        } else {
            e.setCompte(m.getCompteCredit());
            e.setCredit(m.getRubriqueMontant());
            e.setDebit(BigDecimal.ZERO);
            e.setEcritureID(null);
            e.setJournalID(m.getJournalID());
            e.setLibelle(m.getRubrique() + " - " + currentEngagement.getBeneficiaire());
            e.setDroitID(m.getRubriqueID());
            e.setMandatementID(m.getMandatementID());
            e.setPieces(m.getNumeroOP() + "; ");
        }
        e.setEcritureID(null);
        e.setAxeID(null);
        e.setEngagementID(currentEngagement.getEngagementID());
        e.setDateOperation(new Date());
        e.setLettrage(currentEngagement.getNumDossier());
        e.setMillesime(millesime);
        e.setTypeEcriture(EtatDossier.prisEnCharge);
        e.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        e.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        return e;
    }

    private void getEcrituresPaiement(Mandatement m, List<Ecritures> list) {
        Ecritures e = null;

        for (Droits d : listDroits) {
            if (m.getRubriqueID().equals(d.getDroitID())) {
                // credit banque ou caisse
                e = new Ecritures();
                e.setCompte(liquidite.getCompte());
                e.setDebit(BigDecimal.ZERO);
                e.setCredit(m.getReglementRestant());
                e.setEcritureID(null);
                e.setJournalID(liquidite.getJournalID());
                e.setLibelle("Reglement  " + TypeDossier.getLibelleType(currentEngagement.getTypeID()) + " " + currentEngagement.getBeneficiaire());
                e.setDroitID(m.getRubriqueID());
                e.setMandatementID(m.getMandatementID());
                e.setPieces(m.getNumeroOP()+";"+txtPiecesPaiement.getText().trim());

                e.setEcritureID(null);
                e.setAxeID(null);
                e.setEngagementID(currentEngagement.getEngagementID());
                e.setDateOperation(new Date());
                e.setLettrage(currentEngagement.getNumDossier());
                e.setMillesime(millesime);
                e.setTypeEcriture(EtatDossier.regle);
                e.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                e.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                list.add(e);

                // debit net a percevoir 
                e = new Ecritures();
                e.setCompte(m.getCompteDebit());
                e.setDebit(m.getReglementRestant());
                e.setCredit(BigDecimal.ZERO);
                e.setEcritureID(null);
                e.setJournalID(m.getJournalID());
                e.setLibelle("Reglement  " + d.getSigleFr() + " " + currentEngagement.getBeneficiaire());
                e.setDroitID(m.getRubriqueID());
                e.setMandatementID(m.getMandatementID());
                e.setPieces(m.getNumeroOP());

                e.setEcritureID(null);
                e.setAxeID(null);
                e.setEngagementID(currentEngagement.getEngagementID());
                e.setDateOperation(new Date());
                e.setLettrage(currentEngagement.getNumDossier());
                e.setMillesime(millesime);
                e.setTypeEcriture(EtatDossier.regle);
                e.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                e.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                list.add(e);
            }
        }
    }

    public List<Mandatement> getListMandatementPaiement() {
        return listMandatementPaiement;
    }

    public void setListMandatementPaiement(List<Mandatement> listMandatementPaiement) {
        this.listMandatementPaiement = listMandatementPaiement;
    }

    public List<CompteLiquidite> getListCompteLiquidite() {
        return listCompteLiquidite;
    }

    public void setListCompteLiquidite(List<CompteLiquidite> listCompteLiquidite) {
        this.listCompteLiquidite = listCompteLiquidite;
    }

    public CompteLiquidite getLiquidite() {
        return liquidite;
    }

    public void setLiquidite(CompteLiquidite liquidite) {
        this.liquidite = liquidite;
    }

    public GButton getBtnInfosSuivant() {
        return btnInfosSuivant;
    }

    public void setBtnInfosSuivant(GButton btnInfosSuivant) {
        this.btnInfosSuivant = btnInfosSuivant;
    }

    public JLabel getLblType() {
        return lblType;
    }

    public void setLblType(JLabel lblType) {
        this.lblType = lblType;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnInfosSuivant;
    private cm.eusoworks.tools.ui.GButton btnModePaiement;
    private cm.eusoworks.tools.ui.GButton btnPaiementAnnuler;
    private cm.eusoworks.tools.ui.GButton btnPaiementValide;
    private cm.eusoworks.tools.ui.GButton btnPriseEnChargeAnnuler;
    private cm.eusoworks.tools.ui.GButton btnTTC;
    private cm.eusoworks.tools.ui.GButton btnValiderCreance;
    private javax.swing.JPanel cardPanel;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboStructureImputation;
    private javax.swing.JComboBox cboTache;
    private org.jdesktop.swingx.JXDatePicker dtpDatesignature;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JLabel lblInfosIcon;
    private javax.swing.JLabel lblInfosLabel;
    private javax.swing.JLabel lblOPIcon;
    private javax.swing.JLabel lblOPLabel;
    private javax.swing.JLabel lblPaiementIcon;
    private javax.swing.JLabel lblPaiementLabel;
    private javax.swing.JLabel lblReglementIcon;
    private javax.swing.JLabel lblReglementLabel;
    private javax.swing.JLabel lblType;
    private javax.swing.JPanel pBoutons;
    private javax.swing.JPanel pInfos;
    private javax.swing.JPanel pModePaiement;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel pOrdrePaiement;
    private javax.swing.JPanel pPaiement;
    private javax.swing.JPanel panelPaiement;
    private javax.swing.JPanel panelPriseEnCharge;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JScrollPane scrollTable;
    private javax.swing.JScrollPane scrollTable1;
    private org.jdesktop.swingx.JXTable tableEcritures;
    private org.jdesktop.swingx.JXTable tableEcrituresPaiement;
    private org.jdesktop.swingx.JXTable tableLiquidite;
    private org.jdesktop.swingx.JXTable tableTaxes;
    private javax.swing.JTable tblOrdrePaiement;
    private javax.swing.JTable tblPaiement;
    private javax.swing.JFormattedTextField txtCredit;
    private javax.swing.JFormattedTextField txtCreditPaiement;
    private javax.swing.JFormattedTextField txtDebit;
    private javax.swing.JFormattedTextField txtDebitPaiement;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtNAP;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtPiecesPaiement;
    private javax.swing.JFormattedTextField txtRIB;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtRetenues;
    private javax.swing.JTextField txtSignataire;
    private javax.swing.JFormattedTextField txtSommeOP;
    private javax.swing.JFormattedTextField txtSommeReglement;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
