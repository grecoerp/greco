/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.enumeration.TypeDossier;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.BcaArticles;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.renderer.DecimalTableRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.LiquidationStatusRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WLigneFacture;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableColumn;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementLiquidationDialog extends GrecoTemplateDialog {

    public static int MODE_ENREGISTRE = 1;
    public static int MODE_SUPPRESSION = 2;
    public static int MODE_VALIDATION = 3;
    public static int MODE_ANNULATION_VALIDATION = 4;
    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();
    Bca currentBca = null;
    OrdreMission currentOM = null;
    Decision currentDecision = null;
    VueEngagementDossier currentEngagement = null;
    int mode = MODE_ENREGISTRE;

    List<LiquidationDroits> listRetenues = ObservableCollections.observableList(new ArrayList<LiquidationDroits>());
    LiquidationDroits selectedRetenue = null;

    List<Liquidation> listLiquidations = ObservableCollections.observableList(new ArrayList<Liquidation>());
    Liquidation selectedLiquidation = null;

    String currentLiquidationID = null;

    List<Droits> listRubriques = null;

    public EngagementLiquidationDialog(JFrame parent, boolean modal, VueEngagementDossier current, int modeValide) {
        super(parent, true);
        initComponents();
        this.mode = modeValide;

        try {
            setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Liquidation du Dossier N°:  " + current.getNumDossier());
        } catch (Exception e) {
        }

        initMode();
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.currentEngagement = current;
        setLocationRelativeTo(null);

        TableColumn colorColumn = ((DefaultTableColumnModel) tblLiquidationListe.getColumnModel()).getColumn(3);
        colorColumn.setCellRenderer(new LiquidationStatusRenderer());

        initEngagementUI();
        btnValiderLiquidation.setVisible(false);
        btnOrdrePaiement.setVisible(false);
        setPreferredSize(new Dimension(1000, 675));
    }

    private void initMode() {
        switch (this.mode) {
            case 1:
                btnAction.setText("Enregistrer une liquidation");
                dtpDateLiquidation.setDate(new Date());
                btnOrdrePaiement.setVisible(false);
                break;
            case 3:
                disableComponents();
                btnSupprimerLiquidMini.setVisible(false);
                btnAnnuler.setVisible(false);
                btnAction.setText("Valider la liquidation");
                btnOrdrePaiement.setVisible(false);
                break;
            case 4:
                disableComponents();
                btnSupprimerLiquidMini.setVisible(false);
                btnAnnuler.setVisible(false);
                btnAction.setText("Annuler la Validation");
                break;
        }
    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getType());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        // Traitement des BCA
        if (String.valueOf(currentEngagement.getType()).equalsIgnoreCase(TypeDossier.BON_COMMANDE)
                || String.valueOf(currentEngagement.getType()).equalsIgnoreCase(TypeDossier.LETTRE_COMMANDE)
                || String.valueOf(currentEngagement.getType()).equalsIgnoreCase(TypeDossier.MARCHE)) {

            txtNumDossier.setText(currentEngagement.getNumDossier());
            txtObjet.setText(currentEngagement.getObjet().trim());
            txtObjetLiquidation.setText(currentEngagement.getObjet().trim());
            txtReference.setText(currentEngagement.getCompte());

            btnBeneficiare.setText(currentEngagement.getBeneficiaire());

            try {
                txtMontant.setValue(currentEngagement.getMontant());
            } catch (Exception e) {
            }
            // charger les liquidations deja enregistrees
            loadLiquidations();
        }

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        benefGroup = new javax.swing.ButtonGroup();
        radioGroup = new javax.swing.ButtonGroup();
        validGroup = new javax.swing.ButtonGroup();
        penaliteDialog = new javax.swing.JDialog();
        cboRubrique = new javax.swing.JComboBox<>();
        txtMontantRubrique = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        btnAjouterRubrique = new cm.eusoworks.tools.ui.GButton();
        jSplitPane1 = new javax.swing.JSplitPane();
        panelInfos = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLiquidationListe = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtMontantRestantLiquider = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        btnNewLiquidationMini = new cm.eusoworks.tools.ui.GButton();
        btnSupprimerLiquidMini = new cm.eusoworks.tools.ui.GButton();
        btnValiderLiquidation = new cm.eusoworks.tools.ui.GButton();
        jLabel8 = new javax.swing.JLabel();
        pDetails = new javax.swing.JPanel();
        pNewLiquidation = new javax.swing.JPanel();
        btnNewLiquidation = new cm.eusoworks.tools.ui.GButton();
        tabbedLiquidation = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtPieces = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtLivrables = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        dtpDateLiquidation = new org.jdesktop.swingx.JXDatePicker();
        btnAnnuler = new cm.eusoworks.tools.ui.GButton();
        btnAction = new cm.eusoworks.tools.ui.GButton();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtObjetLiquidation = new javax.swing.JTextArea();
        jScrollPane8 = new javax.swing.JScrollPane();
        tableTaxes = new org.jdesktop.swingx.JXTable();
        btnOrdrePaiement = new cm.eusoworks.tools.ui.GButton();
        lnkPenalites = new org.jdesktop.swingx.JXHyperlink();
        pDetailCommande = new javax.swing.JPanel();
        bcaFacture = new com.siicore.facture.WPanelFacture(){
            @Override
            public void loadRowData(WLigneFacture wlf) {
                chargerLigne(wlf);
            }

            @Override
            public boolean validationFacture() {
                return validerFacture();
            }
        };
        jPanel4 = new javax.swing.JPanel();
        btnFactureDefinitive = new cm.eusoworks.tools.ui.GButton();
        jPanel2 = new javax.swing.JPanel();
        rdbValidation = new javax.swing.JRadioButton();
        rdbRejet = new javax.swing.JRadioButton();
        jLabel15 = new javax.swing.JLabel();
        jXLabel1 = new org.jdesktop.swingx.JXLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtObservations = new javax.swing.JTextArea();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        btnValidation = new cm.eusoworks.tools.ui.GButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jXLabel2 = new org.jdesktop.swingx.JXLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtObservationsAnnulation = new javax.swing.JTextArea();
        btnRetourAnnuler = new cm.eusoworks.tools.ui.GButton();
        btnAnnulation = new cm.eusoworks.tools.ui.GButton();

        penaliteDialog.setTitle("AJOUT RUBRIQUES DE LIQUIDATION");
        penaliteDialog.setBackground(new java.awt.Color(255, 255, 255));

        cboRubrique.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtMontantRubrique.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0.00"))));
        txtMontantRubrique.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontantRubrique.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N

        jLabel4.setText("Rubrique : ");

        jLabel5.setText("Montant ");

        btnAjouterRubrique.setText("Ajouter ");
        btnAjouterRubrique.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAjouterRubriqueActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout penaliteDialogLayout = new javax.swing.GroupLayout(penaliteDialog.getContentPane());
        penaliteDialog.getContentPane().setLayout(penaliteDialogLayout);
        penaliteDialogLayout.setHorizontalGroup(
            penaliteDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penaliteDialogLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(penaliteDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 84, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 72, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(penaliteDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboRubrique, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(txtMontantRubrique))
                .addContainerGap())
            .addGroup(penaliteDialogLayout.createSequentialGroup()
                .addGap(111, 111, 111)
                .addComponent(btnAjouterRubrique, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(123, Short.MAX_VALUE))
        );
        penaliteDialogLayout.setVerticalGroup(
            penaliteDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(penaliteDialogLayout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(penaliteDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboRubrique, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(penaliteDialogLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtMontantRubrique, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(btnAjouterRubrique, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(32, Short.MAX_VALUE))
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Liquidation ");

        panelInfos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        panelInfos.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 181, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        panelInfos.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 180, -1));

        jLabel2.setText("Montant :");
        panelInfos.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 80, 30));

        txtMontant.setEnabled(false);
        panelInfos.add(txtMontant, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 180, 30));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        panelInfos.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        panelInfos.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        panelInfos.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 270, 30));

        lblType.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblTypeMouseClicked(evt);
            }
        });
        panelInfos.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        panelInfos.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 180, 50));

        txtReference.setEditable(false);
        txtReference.setEnabled(false);
        panelInfos.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 180, -1));
        panelInfos.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 260, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        panelInfos.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 86, 22));

        tblLiquidationListe.setRowHeight(23);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listLiquidations}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblLiquidationListe);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numOrdre}"));
        columnBinding.setColumnName("Num Ordre");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantTTC}"));
        columnBinding.setColumnName("Montant TTC");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateLiquidation}"));
        columnBinding.setColumnName("Date Liquidation");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${etat}"));
        columnBinding.setColumnName("Etat");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedLiquidation}"), tblLiquidationListe, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tblLiquidationListe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLiquidationListeMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblLiquidationListe);
        if (tblLiquidationListe.getColumnModel().getColumnCount() > 0) {
            tblLiquidationListe.getColumnModel().getColumn(0).setResizable(false);
            tblLiquidationListe.getColumnModel().getColumn(0).setPreferredWidth(20);
            tblLiquidationListe.getColumnModel().getColumn(1).setPreferredWidth(100);
            tblLiquidationListe.getColumnModel().getColumn(2).setPreferredWidth(75);
            tblLiquidationListe.getColumnModel().getColumn(3).setPreferredWidth(25);
        }

        panelInfos.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 290, 170));

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 0, 102));
        jLabel3.setText("Liquidation(s) deja effectuee(s)");
        panelInfos.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 270, -1));

        txtMontantRestantLiquider.setEditable(false);
        txtMontantRestantLiquider.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtMontantRestantLiquider.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMontantRestantLiquider.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        panelInfos.add(txtMontantRestantLiquider, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 570, 230, 40));

        jLabel6.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel6.setText("Montant restant a liquider  : ");
        panelInfos.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, 220, -1));

        btnNewLiquidationMini.setText("+");
        btnNewLiquidationMini.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        btnNewLiquidationMini.setStyle(5);
        btnNewLiquidationMini.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewLiquidationMiniActionPerformed(evt);
            }
        });
        panelInfos.add(btnNewLiquidationMini, new org.netbeans.lib.awtextra.AbsoluteConstraints(160, 480, 60, 30));

        btnSupprimerLiquidMini.setText("X");
        btnSupprimerLiquidMini.setCouleur(1);
        btnSupprimerLiquidMini.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerLiquidMiniActionPerformed(evt);
            }
        });
        panelInfos.add(btnSupprimerLiquidMini, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 480, 60, -1));

        btnValiderLiquidation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_success_mini.png"))); // NOI18N
        btnValiderLiquidation.setCouleur(4);
        btnValiderLiquidation.setIconTextGap(0);
        btnValiderLiquidation.setPreferredSize(new java.awt.Dimension(38, 30));
        btnValiderLiquidation.setStyle(5);
        btnValiderLiquidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnValiderLiquidationActionPerformed(evt);
            }
        });
        panelInfos.add(btnValiderLiquidation, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 480, 50, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgannulationbord.png"))); // NOI18N
        panelInfos.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 300, 670));

        jSplitPane1.setLeftComponent(panelInfos);

        pDetails.setLayout(new java.awt.CardLayout());

        pNewLiquidation.setBackground(new java.awt.Color(249, 249, 249));

        btnNewLiquidation.setText("+ Faire une une nouvelle liquidation");
        btnNewLiquidation.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        btnNewLiquidation.setStyle(5);
        btnNewLiquidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewLiquidationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pNewLiquidationLayout = new javax.swing.GroupLayout(pNewLiquidation);
        pNewLiquidation.setLayout(pNewLiquidationLayout);
        pNewLiquidationLayout.setHorizontalGroup(
            pNewLiquidationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pNewLiquidationLayout.createSequentialGroup()
                .addGap(175, 175, 175)
                .addComponent(btnNewLiquidation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(187, Short.MAX_VALUE))
        );
        pNewLiquidationLayout.setVerticalGroup(
            pNewLiquidationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pNewLiquidationLayout.createSequentialGroup()
                .addGap(292, 292, 292)
                .addComponent(btnNewLiquidation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(366, Short.MAX_VALUE))
        );

        pDetails.add(pNewLiquidation, "new");

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel1.setForeground(new java.awt.Color(51, 204, 0));
        jLabel1.setText("RUBRIQUES DE LIQUIDATION");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 10, 220, 16);

        jLabel10.setForeground(new java.awt.Color(51, 204, 0));
        jLabel10.setText("PIECES JUSTIFICATIVES DU SERVICE FAIT");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(445, 10, 356, 16);

        txtPieces.setColumns(20);
        txtPieces.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        txtPieces.setRows(3);
        jScrollPane3.setViewportView(txtPieces);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(451, 32, 350, 150);

        jLabel11.setForeground(new java.awt.Color(51, 153, 0));
        jLabel11.setText("LIVRABLES ");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(448, 200, 290, 20);

        txtLivrables.setColumns(20);
        txtLivrables.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtLivrables.setRows(3);
        jScrollPane4.setViewportView(txtLivrables);

        jPanel1.add(jScrollPane4);
        jScrollPane4.setBounds(450, 230, 352, 70);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(204, 0, 0));
        jLabel13.setText("Date de liquidation : ");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(10, 340, 180, 17);
        jPanel1.add(dtpDateLiquidation);
        dtpDateLiquidation.setBounds(10, 360, 180, 30);

        btnAnnuler.setText("Effacer tout");
        btnAnnuler.setCouleur(3);
        btnAnnuler.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAnnuler.setStyle(1);
        btnAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerActionPerformed(evt);
            }
        });
        jPanel1.add(btnAnnuler);
        btnAnnuler.setBounds(60, 464, 150, 29);

        btnAction.setText("Enregistrer la liquidation");
        btnAction.setCouleur(2);
        btnAction.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAction.setStyle(3);
        btnAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionActionPerformed(evt);
            }
        });
        jPanel1.add(btnAction);
        btnAction.setBounds(214, 464, 200, 29);

        jLabel14.setForeground(new java.awt.Color(51, 153, 0));
        jLabel14.setText("OBJET DE LA LIQUIDATION ");
        jPanel1.add(jLabel14);
        jLabel14.setBounds(10, 200, 210, 22);

        txtObjetLiquidation.setColumns(20);
        txtObjetLiquidation.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtObjetLiquidation.setLineWrap(true);
        txtObjetLiquidation.setRows(3);
        jScrollPane5.setViewportView(txtObjetLiquidation);

        jPanel1.add(jScrollPane5);
        jScrollPane5.setBounds(10, 230, 410, 70);

        tableTaxes.setRowHeight(22);
        tableTaxes.setShowGrid(true);
        tableTaxes.setShowVerticalLines(false);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listRetenues}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableTaxes);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Libelle");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${taux}"));
        columnBinding.setColumnName("Taux");
        columnBinding.setColumnClass(Double.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        tableTaxes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableTaxesKeyReleased(evt);
            }
        });
        jScrollPane8.setViewportView(tableTaxes);
        if (tableTaxes.getColumnModel().getColumnCount() > 0) {
            tableTaxes.getColumnModel().getColumn(0).setPreferredWidth(150);
            tableTaxes.getColumnModel().getColumn(1).setPreferredWidth(10);
            tableTaxes.getColumnModel().getColumn(2).setPreferredWidth(50);
            tableTaxes.getColumnModel().getColumn(2).setCellRenderer(new DecimalTableRenderer());
        }

        jPanel1.add(jScrollPane8);
        jScrollPane8.setBounds(6, 30, 410, 147);

        btnOrdrePaiement.setText("Préparer un Ordre de Paiement");
        btnOrdrePaiement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrdrePaiementActionPerformed(evt);
            }
        });
        jPanel1.add(btnOrdrePaiement);
        btnOrdrePaiement.setBounds(450, 460, 270, 29);

        lnkPenalites.setText("Ajouter pénalité ...");
        lnkPenalites.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lnkPenalites.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnkPenalitesActionPerformed(evt);
            }
        });
        jPanel1.add(lnkPenalites);
        lnkPenalites.setBounds(250, 10, 170, 17);

        tabbedLiquidation.addTab("Détails de la liquidation", jPanel1);

        pDetailCommande.setPreferredSize(new java.awt.Dimension(808, 650));
        pDetailCommande.setLayout(new java.awt.BorderLayout());

        bcaFacture.setPreferredSize(new java.awt.Dimension(808, 630));
        pDetailCommande.add(bcaFacture, java.awt.BorderLayout.CENTER);

        jPanel4.setBackground(new java.awt.Color(255, 255, 255));
        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnFactureDefinitive.setText("Afficher la facture du BCA");
        btnFactureDefinitive.setStyle(5);
        btnFactureDefinitive.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFactureDefinitiveActionPerformed(evt);
            }
        });
        jPanel4.add(btnFactureDefinitive);

        pDetailCommande.add(jPanel4, java.awt.BorderLayout.NORTH);

        tabbedLiquidation.addTab("Facture définitive", pDetailCommande);

        pDetails.add(tabbedLiquidation, "liquidation");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        validGroup.add(rdbValidation);
        rdbValidation.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        rdbValidation.setForeground(new java.awt.Color(0, 153, 51));
        rdbValidation.setSelected(true);
        rdbValidation.setText("Valider la liquidation ");
        rdbValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbValidationActionPerformed(evt);
            }
        });

        validGroup.add(rdbRejet);
        rdbRejet.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rdbRejet.setForeground(new java.awt.Color(204, 51, 0));
        rdbRejet.setText("Rejeter ");

        jLabel15.setText("Observations ");

        jXLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jXLabel1.setText("La validation de cette liquidation permet d'effetuer le mandatement dans la suite de la procedure\n\nLe rejet arrete le processus de traitement de ce dossier a cette etape");
        jXLabel1.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jXLabel1.setLineWrap(true);

        txtObservations.setColumns(20);
        txtObservations.setRows(5);
        jScrollPane6.setViewportView(txtObservations);

        btnRetour.setCouleur(3);
        btnRetour.setLabel("Retour");
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        btnValidation.setText("Valider");
        btnValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnValidationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jXLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdbValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdbRejet, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(164, 164, 164)
                                .addComponent(btnValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(87, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jXLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(rdbValidation)
                        .addGap(39, 39, 39)
                        .addComponent(rdbRejet))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 215, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnValidation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pDetails.add(jPanel2, "validation");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setText("Observations ");

        jXLabel2.setForeground(new java.awt.Color(102, 0, 0));
        jXLabel2.setText("L'annulation de la validation n'est possible que si elle n'a pas encore fait l'objet d'un mandatement");
        jXLabel2.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jXLabel2.setLineWrap(true);

        txtObservationsAnnulation.setColumns(20);
        txtObservationsAnnulation.setRows(5);
        jScrollPane7.setViewportView(txtObservationsAnnulation);

        btnRetourAnnuler.setCouleur(3);
        btnRetourAnnuler.setLabel("Retour");
        btnRetourAnnuler.setStyle(1);
        btnRetourAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourAnnulerActionPerformed(evt);
            }
        });

        btnAnnulation.setText("Annuler la validation");
        btnAnnulation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jXLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 688, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(btnRetourAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(164, 164, 164)
                        .addComponent(btnAnnulation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(87, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jXLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 287, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRetourAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnnulation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pDetails.add(jPanel3, "annulation");

        jSplitPane1.setRightComponent(pDetails);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loadLiquidations() {
        if (currentEngagement != null) {
            List<Liquidation> list = GrecoServiceFactory.getEngagementService().liquidationByEngagement(currentEngagement.getEngagementID());
            if (list != null && !list.isEmpty()) {
                listLiquidations.clear();
                long valide = 0;
                for (Liquidation l : list) {
                    listLiquidations.add(l);
                    if (l.getEtat() == EtatDossier.liquide_validation) {
                        valide = valide + l.getMontantTTC().longValue();
                    }
                }
                long reste = currentEngagement.getMontant().longValue() - valide;
                txtMontantRestantLiquider.setValue(reste);
                if (reste == 0) {
                    btnNewLiquidation.setVisible(false);
                    btnNewLiquidationMini.setVisible(false);
                }
                btnSupprimerLiquidMini.setVisible(true);
            } else if (list.isEmpty()) {
                listLiquidations.clear();
//                listLiquidations = new ArrayList<>();
                long reste = currentEngagement.getMontant().longValue();
                txtMontantRestantLiquider.setValue(reste);
                afficherCout();
                btnSupprimerLiquidMini.setVisible(false);
            }
        }
        ((CardLayout) pDetails.getLayout()).show(pDetails, "new");
    }

    private void showSelectedLiquidation() {
        if (selectedLiquidation != null) {
            txtLivrables.setText(selectedLiquidation.getLivrables());
            txtObjetLiquidation.setText(selectedLiquidation.getObjet());
            txtPieces.setText(selectedLiquidation.getPieces());
            dtpDateLiquidation.setDate(selectedLiquidation.getDateLiquidation());
            currentLiquidationID = selectedLiquidation.getLiquidationID();

            listRetenues.clear();
            List<LiquidationDroits> droits = GrecoServiceFactory.getDroitsService().listeLiquidationDroits(selectedLiquidation.getLiquidationID());
            if (droits != null && !droits.isEmpty()) {
                for (LiquidationDroits d : droits) {
                    listRetenues.add(d);
                }
            }

            //load facture definitive 
            boolean b = bcaFacture.getLignesFacture().supprimerLignes(bcaFacture.getLignesFacture().getLignes());
            if (b) {
                try {
                    if (currentBca == null) {
                        currentBca = GrecoServiceFactory.getBonCommandeService().getBCA(currentEngagement.getBcaID());
                    }

                } catch (Exception e) {
                }
                bcaFacture.setTauxIR(currentBca.getTauxIR());
                bcaFacture.setTauxTVA(currentBca.getTauxTVA());
                List<BcaArticles> list = new ArrayList<>();
                list = GrecoServiceFactory.getBonCommandeService().getBCALignesDefinitives(selectedLiquidation.getLiquidationID());
                int ordre = 0;
                for (BcaArticles l : list) {
                    WLigneFacture wlf = new WLigneFacture(l.getAmId(), ordre);
                    wlf.setReference(l.getRefArticle());
                    wlf.setDesignation(l.getDesignation());
                    wlf.setId(l.getAmId());
                    wlf.setIndex(l.getNumOrdre());
                    wlf.setPrixUnitaire(l.getPrixUnitaire().doubleValue());
                    Double marge = l.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                    wlf.setPuMax(l.getPrixUnitaire().doubleValue() + marge);
                    wlf.setPuMin(Double.valueOf(0));
                    wlf.setQuantite((int) l.getQuantite());
                    bcaFacture.getLignesFacture().ajouterLigne(wlf);
                    ordre++;
                }
            }

            ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
        }
    }

    private void btnAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerActionPerformed
        // TODO add your handling code here:
        txtLivrables.setText("");
//        txtObjetLiquidation.setText("");
        txtPieces.setText("");
////        txtMontantIR.setValue(null);
////        txtMontantNAP.setValue(null);
////        txtMontantRG.setValue(null);
////        txtMontantTVA.setValue(null);
        listRetenues.clear();
        currentLiquidationID = null;
        txtObservations.setText("");
        txtObservationsAnnulation.setText("");
        ((CardLayout) pDetails.getLayout()).show(pDetails, "new");
    }//GEN-LAST:event_btnAnnulerActionPerformed

    private void btnActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionActionPerformed
        // TODO add your handling code here:
        switch (this.mode) {
            case 1:
                enregistrerLiquidation();
                break;
            case 2:
                supprimerLiquidation();
                break;
            case 3:
                validerLiquidation();
                break;
            case 4:
                ((CardLayout) pDetails.getLayout()).show(pDetails, "annulation");
                break;
        }
    }//GEN-LAST:event_btnActionActionPerformed

    private void tblLiquidationListeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLiquidationListeMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if (selectedLiquidation != null) {
                showSelectedLiquidation();
                if (mode != 4) {
                    if (selectedLiquidation.getEtat() == EtatDossier.liquide_validation) {
                        disableComponents();
                        btnAction.setVisible(false);
                        btnAnnuler.setVisible(false);
                        btnOrdrePaiement.setVisible(true);
                    } else {
                        enableComponents();
                        btnAction.setVisible(true);
                        btnAnnuler.setVisible(true);
                        btnOrdrePaiement.setVisible(false);
                    }
                } else if (selectedLiquidation.getEtat() == EtatDossier.liquide_validation) {
                    disableComponents();
                    btnAction.setVisible(true);
                    btnAnnuler.setVisible(false);
                    btnOrdrePaiement.setVisible(true);
                } else {
                    disableComponents();
                    btnAction.setVisible(false);
                    btnAnnuler.setVisible(false);
                    btnOrdrePaiement.setVisible(false);
                }

            }
        } else if (selectedLiquidation != null) {
            if (selectedLiquidation.getEtat() >= EtatDossier.liquide_validation) {
                btnSupprimerLiquidMini.setVisible(false);
                btnValiderLiquidation.setVisible(false);
            } else {
                btnSupprimerLiquidMini.setVisible(true);
                btnValiderLiquidation.setVisible(true);
            }
        }
    }//GEN-LAST:event_tblLiquidationListeMouseClicked

    private void supprimerLiquid() {
        if (selectedLiquidation != null) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer cette liquidation ?");
            if (res == JOptionPane.YES_OPTION) {
                supprimerLiquidation();
            }
        }
    }

    private void rdbValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbValidationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbValidationActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void btnValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnValidationActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir valider cette liquidation ?");
        if (res == JOptionPane.YES_OPTION) {
            valider();
        }
    }//GEN-LAST:event_btnValidationActionPerformed

    private void btnRetourAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourAnnulerActionPerformed
        // TODO add your handling code here:
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }//GEN-LAST:event_btnRetourAnnulerActionPerformed

    private void btnAnnulationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulationActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir annuler la validation de cette liquidation ?");
        if (res == JOptionPane.YES_OPTION) {
            annuler();
        }

    }//GEN-LAST:event_btnAnnulationActionPerformed

    private void lblTypeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblTypeMouseClicked
        // TODO add your handling code here:
        afficherBCA();
    }//GEN-LAST:event_lblTypeMouseClicked

    private void btnNewLiquidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewLiquidationActionPerformed
        // TODO add your handling code here:
        newLiquidation();
    }//GEN-LAST:event_btnNewLiquidationActionPerformed

    private void btnNewLiquidationMiniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewLiquidationMiniActionPerformed
        // TODO add your handling code here:
        newLiquidation();
    }//GEN-LAST:event_btnNewLiquidationMiniActionPerformed

    private void btnFactureDefinitiveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFactureDefinitiveActionPerformed
        // TODO add your handling code here:
        loadArticleBCA();
    }//GEN-LAST:event_btnFactureDefinitiveActionPerformed

    private void loadArticleBCA() {
        try {
            if (currentBca == null) {
                currentBca = GrecoServiceFactory.getBonCommandeService().getBCA(currentEngagement.getBcaID());
            }

        } catch (Exception e) {
        }
        /**
         * *******chargements des lignes de la facture *****************
         */
        bcaFacture.setTauxIR(currentBca.getTauxIR());
        bcaFacture.setTauxTVA(currentBca.getTauxTVA());
        List<BcaArticles> list = new ArrayList<>();
        list = GrecoServiceFactory.getBonCommandeService().getBCALignes(currentBca.getBcaID());
        int ordre = 0;
        bcaFacture.getLignesFacture().removeAll();
        for (BcaArticles l : list) {
            WLigneFacture wlf = new WLigneFacture(l.getAmId(), ordre);
            wlf.setReference(l.getRefArticle());
            wlf.setDesignation(l.getDesignation());
            wlf.setId(l.getAmId());
//            wlf.setIndex(l.getNumOrdre());
            wlf.setPrixUnitaire(l.getPrixUnitaire().doubleValue());
            Double marge = l.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
            wlf.setPuMax(l.getPrixUnitaire().doubleValue() + marge);
            wlf.setPuMin(Double.valueOf(0));
            wlf.setQuantite((int) l.getQuantite());
            bcaFacture.getLignesFacture().ajouterLigne(wlf);
            ordre++;
        }
    }


    private void btnSupprimerLiquidMiniActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerLiquidMiniActionPerformed
        // TODO add your handling code here:
        supprimerLiquid();
    }//GEN-LAST:event_btnSupprimerLiquidMiniActionPerformed

    private void tableTaxesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableTaxesKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_DELETE) {
            if (selectedRetenue != null) {
                //recupérer la liste existante des rubriques
                List<LiquidationDroits> l = new ArrayList<>();
                for (LiquidationDroits eg : listRetenues) {
                    l.add(eg);
                }
                //supprimmer la rubrique selectionne
                for (LiquidationDroits retenues : l) {
                    if (retenues.getDroitID().equalsIgnoreCase(selectedRetenue.getDroitID())) {
                        l.remove(retenues);
                        break;
                    }
                }
                // recharger la liste dans le tableau par binding
                listRetenues.clear();
                for (LiquidationDroits g : l) {
                    listRetenues.add(g);
                }
            }
        }

//        calculerNAP();
    }//GEN-LAST:event_tableTaxesKeyReleased

    private void btnValiderLiquidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnValiderLiquidationActionPerformed
        // TODO add your handling code here:
        validerLiquidationMini();
    }//GEN-LAST:event_btnValiderLiquidationActionPerformed

    private void btnOrdrePaiementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrdrePaiementActionPerformed
        // TODO add your handling code here:
        ordrePaiement();
    }//GEN-LAST:event_btnOrdrePaiementActionPerformed

    private void lnkPenalitesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnkPenalitesActionPerformed
        // TODO add your handling code here:

        if (penaliteDialog == null) {
            penaliteDialog = new JDialog();
        }
        if (listRubriques == null) {
            listRubriques = GrecoServiceFactory.getDroitsService().listeDroits();
            cboRubrique.setModel(new DefaultComboBoxModel(listRubriques.toArray()));
        }
        penaliteDialog.setModal(true);
        penaliteDialog.setSize(400, 250);
        penaliteDialog.setPreferredSize(new Dimension(400, 350));
        penaliteDialog.setLocationRelativeTo(tableTaxes);
        penaliteDialog.setVisible(true);
    }//GEN-LAST:event_lnkPenalitesActionPerformed

    private void btnAjouterRubriqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAjouterRubriqueActionPerformed
        // TODO add your handling code here:
        Droits d = (Droits) cboRubrique.getSelectedItem();
        if (d != null) {
            long montant = 0;
            Number nb = (Number) txtMontantRubrique.getValue();
            if (nb != null) {
                montant = nb.longValue();
            } else {
                GrecoOptionPane.showWarningDialog("Veuillez saisir le montant de cette rubrique");
                return;
            }
            //controle de l'existence de la rubrique
            for (LiquidationDroits droit : listRetenues) {
                if (droit.getDroitID().equalsIgnoreCase(d.getDroitID())) {
                    GrecoOptionPane.showWarningDialog("Cette rubrique existe déjà dans la liste. Supprimer et ajouter à nouveau");
                    return;
                }
            }

            // nouvelle liste en enlevant le NAP
            List<LiquidationDroits> newList = new ArrayList<>();
            
            // modification du NAP en diminuant la penalités 
            for (LiquidationDroits droit : listRetenues) {
                if (droit.isNAP()) {
                    long m = droit.getMontant().longValue();
                    m = m - montant;
                    if (m < 0) {
                        GrecoOptionPane.showWarningDialog("La pénalités est plus grande que le Net à Percevoir. Opération bloquée");
                        return;
                    }
                    droit.setMontant(BigDecimal.valueOf(m));
                    newList.add(droit);
                }
            }
            
            // ajout des autres rubriques
            for (LiquidationDroits droit : listRetenues) {
                if (!droit.isNAP()) {
                    newList.add(droit);
                }
            }
            
            // ajout dans la liste
            LiquidationDroits penaliteDroit = new LiquidationDroits();
            penaliteDroit.setPenalite(true);
            penaliteDroit.setMontant(BigDecimal.valueOf(montant));
            penaliteDroit.setDroitID(d.getDroitID());
            penaliteDroit.setIp_update(GrecoSession.USER_ADRESSE_IP);
            penaliteDroit.setUser_update(GrecoSession.USER_CONNECTED.getLogin());
            penaliteDroit.setLibelleFr(d.getLibelleFr());
            penaliteDroit.setLibelleUs(d.getLibelleUs());
            penaliteDroit.setSigleFr(d.getSigleFr());
            penaliteDroit.setSigleUs(d.getSigleUs());

            newList.add(penaliteDroit);

            penaliteDialog.setVisible(false);
            
            
            //nouvelle liste des retenues
            listRetenues.clear();
            for (LiquidationDroits l : newList) {
                listRetenues.add(l);
            }
            
        } else {
            GrecoOptionPane.showWarningDialog("Aucune rubrique sélectionnée");
            return;
        }
    }//GEN-LAST:event_btnAjouterRubriqueActionPerformed

    private void ordrePaiement() {
        try {
            if (selectedLiquidation == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner une liquidation SVP");
                return;
            } else {
                EngagementMandatementDialog dialog = new EngagementMandatementDialog(me, true, selectedLiquidation, EngagementMandatementDialog.MODE_ENREGISTRE);
                dialog.setVisible(true);
            }
        } catch (Exception e) {
        }
    }

    private void validerLiquidationMini() {
        if (selectedLiquidation != null) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sûr de vouloir valider cette liquidation ?");
            if (res == JOptionPane.YES_OPTION) {
                valider();
            }
        }

    }

    private void newLiquidation() {
        currentLiquidationID = null;
        // selectedLiquidation = null;
        btnAnnulerActionPerformed(null);
        loadRubriqueLiquidation();
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }

    private void loadRubriqueLiquidation() {
        int t = currentEngagement.getType();
        if (t == Integer.valueOf(TypeDossier.BON_COMMANDE) || t == Integer.valueOf(TypeDossier.LETTRE_COMMANDE) || t == Integer.valueOf(TypeDossier.MARCHE)) {
            try {
                if (currentBca == null) {
                    currentBca = GrecoServiceFactory.getBonCommandeService().getBCA(currentEngagement.getBcaID());
                }
            } catch (Exception e) {
            }
            if (currentBca != null) {
                List<Droits> droits = null;
                droits = GrecoServiceFactory.getDroitsService().listeDroits();
                if (droits != null && !droits.isEmpty()) {
                    listRetenues.clear();
                    for (Droits d : droits) {
                        if (d.isNAP() || d.isTVA() || d.isIR()) {
                            LiquidationDroits ld = null;
                            ld = new LiquidationDroits();
                            ld.setLiquidationID(null);
                            ld.setDroitID(d.getDroitID());
                            ld.setLibelleFr(d.getLibelleFr());
                            if (d.isNAP()) {
                                ld.setMontant(currentBca.getNap());
                                ld.setNAP(true);
                            } else if (d.isTVA()) {
                                ld.setMontant(BigDecimal.valueOf((double) (currentBca.getMontantHT().longValue() * currentBca.getTauxTVA())));
                                ld.setTaux(currentBca.getTauxTVA() * 100);
                                ld.setTVA(true);
                            } else if (d.isIR()) {
                                //double ir = currentEngagement.getMontantHT().doubleValue() * currentEngagement.getTauxIR();
                                ld.setMontant(BigDecimal.valueOf((double) (currentBca.getMontantHT().longValue() * currentBca.getTauxIR())));
                                ld.setTaux(currentBca.getTauxIR() * 100);
                                ld.setIR(true);
                            }
                            ld.setIp_update(GrecoSession.USER_ADRESSE_IP);
                            ld.setUser_update(GrecoSession.USER_CONNECTED.getLogin());
                            listRetenues.add(ld);
                        }

                    }
                }
            }
        }
    }

    private void afficherBCA() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    if (currentBca == null) {
                        currentBca = GrecoServiceFactory.getBonCommandeService().getBCA(currentEngagement.getBcaID());
                    }

                } catch (Exception e) {
                }
                if (currentBca != null) {
                    BonCommandeNewDialog dialog = new BonCommandeNewDialog(me, true, currentEngagement.getMillesime(), currentEngagement.getOrganisationID(), currentBca);
                    dialog.setVisible(true);
                }
            }
        });

    }

    private void annuler() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("Validation de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationValiderAnnuler(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedLiquidation.getLiquidationID(), txtObservationsAnnulation.getText().trim(), selectedLiquidation.getEngagementID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Liquidation annulee avec succès ");
                        btnAnnulerActionPerformed(null);
                        loadLiquidations();
                        btnAction.setVisible(false);
                        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE L'ANNULATION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void valider() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("Validation de la liquidation ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationValider(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedLiquidation.getLiquidationID(), txtObservations.getText().trim(), rdbValidation.isSelected() ? true : false, selectedLiquidation.getEngagementID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Liquidation validee avec succès ");
                        btnAnnulerActionPerformed(null);
                        loadLiquidations();
                        btnOrdrePaiement.setVisible(true);
                        ((CardLayout) pDetails.getLayout()).show(pDetails, "new");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        //selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        //selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA VALIDATION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private boolean controlData() {

        if (txtPieces.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir la liste des pieces justificatives du service fait");
            return false;
        }
        if (txtLivrables.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir les livrables obtenus suite à la réalisation de cet engagement");
            return false;
        }
        if (txtObjetLiquidation.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir l'objet de cette liquidation. Est-ce un decompte? une avance de demarrage....");
            return false;
        }

        if (getRubriques().isEmpty()) {
            GrecoOptionPane.showWarningDialog("La liste des rubriques à liquider ne doit pas être vide.");
            return false;
        }

        List<BcaArticles> listeArticles = new ArrayList<>();
        List<WLigneFacture> la = bcaFacture.getLignesFacture().getLignes();
        if (la != null && !la.isEmpty()) {
            for (WLigneFacture ligne : la) {
                if (!ligne.getReference().toString().isEmpty()) {
                    BcaArticles a = new BcaArticles();
                    listeArticles.add(a);
                }
            }
        }
        if (listeArticles.size() <= 0) {
            GrecoOptionPane.showWarningDialog("Vous avez sans doute oublié de saisir la facture définitive.");
            return false;
        }

        return true;
    }

    private List<LiquidationDroits> getRubriques() {
        List<LiquidationDroits> l = new ArrayList<>();
        for (LiquidationDroits liq : listRetenues) {
            l.add(liq);
        }
        return l;
    }

    private void enregistrerLiquidation() {
        if (controlData()) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {

                        glasspane.setText("enregistrement de la dépense ....");
                        glasspane.attente();
                        Number tva = 0;
                        Number ir = 0;
                        Number nap = 0;
                        Number rg = 0;
                        List<BcaArticles> listeArticles = new ArrayList<>();

                        List<WLigneFacture> la = bcaFacture.getLignesFacture().getLignes();
                        if (la != null && !la.isEmpty()) {

                            for (WLigneFacture ligne : la) {
                                if (!ligne.getReference().toString().isEmpty()) {
                                    BcaArticles a = new BcaArticles();
                                    a.setAmId(ligne.getReference().toString());
                                    try {
                                        a.setBcaID(currentBca.getBcaID());
                                    } catch (Exception e) {
                                    }
//                                a.setLiquidationID(liquidationIDNew);
                                    a.setPrixUnitaire(BigDecimal.valueOf(ligne.getPrixUnitaire()));
                                    a.setQuantite(ligne.getQuantite());
                                    a.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                                    a.setIpUpdate(GrecoSession.USER_ADRESSE_IP);

                                    listeArticles.add(a);
                                }

                            }

                        }

                        List<LiquidationDroits> listeDroits = new ArrayList<>();
                        for (LiquidationDroits liq : listRetenues) {
                            listeDroits.add(liq);
                            if (liq.isNAP()) {
                                nap = com.google.common.math.DoubleMath.roundToInt(liq.getMontant().doubleValue(), RoundingMode.HALF_EVEN);
                            } else if (liq.isTVA()) {
                                tva = com.google.common.math.DoubleMath.roundToInt(liq.getMontant().doubleValue(), RoundingMode.HALF_EVEN);
                            } else if (liq.isIR()) {
                                ir = com.google.common.math.DoubleMath.roundToInt(liq.getMontant().doubleValue(), RoundingMode.HALF_EVEN);
                            } else if (liq.isRG()) {
                                rg = com.google.common.math.DoubleMath.roundToInt(liq.getMontant().doubleValue(), RoundingMode.HALF_EVEN);
                            }
                        }

                        if (currentLiquidationID == null) {
                            try {

                                String liquidationIDNew = GrecoServiceFactory.getEngagementService().liquidationEnregistrement(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                        currentLiquidationID, currentEngagement.getEngagementID(), txtObjetLiquidation.getText().trim(), BigDecimal.valueOf(tva.longValue()), BigDecimal.valueOf(ir.longValue()), BigDecimal.valueOf(nap.longValue()), BigDecimal.valueOf(rg.longValue()),
                                        currentEngagement.getBeneficiaire(), txtPieces.getText().trim(), txtLivrables.getText().trim(), listeDroits);
                                if (liquidationIDNew != null) {
                                    for (BcaArticles b : listeArticles) {
                                        b.setLiquidationID(liquidationIDNew);
                                    }
                                    if (!listeArticles.isEmpty()) {
                                        GrecoServiceFactory.getBonCommandeService().ajouterLigneDefinitive(liquidationIDNew, listeArticles, GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                                    }
                                    GrecoSession.notifications.success();
                                    GrecoOptionPane.showSuccessDialog("Liquidation enregistré avec succès ");
                                    btnAnnulerActionPerformed(null);
                                    loadLiquidations();
                                    glasspane.arret();
                                }

                            } catch (GrecoException e) {
                                glasspane.arret();
                                currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                return;
                            } catch (Exception e) {
                                glasspane.arret();
                                e.printStackTrace();
                                currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        } else {
                            try {
                                GrecoServiceFactory.getEngagementService().liquidationModifier(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                        currentLiquidationID, currentEngagement.getEngagementID(), txtObjetLiquidation.getText().trim(), BigDecimal.valueOf(tva.longValue()), BigDecimal.valueOf(ir.longValue()), BigDecimal.valueOf(nap.longValue()),
                                        BigDecimal.valueOf(rg.longValue()), currentEngagement.getBeneficiaire(), txtPieces.getText().trim(), txtLivrables.getText().trim(), listeDroits);
                                for (BcaArticles b : listeArticles) {
                                    b.setLiquidationID(currentLiquidationID);
                                }
                                if (!listeArticles.isEmpty()) {
                                    GrecoServiceFactory.getBonCommandeService().ajouterLigneDefinitive(currentLiquidationID, listeArticles, GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                                }
                                GrecoSession.notifications.success();
                                GrecoOptionPane.showSuccessDialog("Liquidation modifiee avec succès ");
                                //btnAnnulerActionPerformed(null);
                                loadLiquidations();
                                glasspane.arret();
                            } catch (GrecoException e) {
                                glasspane.arret();
                                //currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                return;
                            } catch (Exception e) {
                                glasspane.arret();
                                e.printStackTrace();
                                //currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }

                        glasspane.arret();

                    } catch (Exception e) {
                    }
                }
            });

        }
    }

    private void supprimerLiquidation() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("enregistrement de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationSupprimer(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC, selectedLiquidation.getLiquidationID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Cette Liquidation a bien ete supprime de la liste ");
                        btnAnnulerActionPerformed(null);
                        loadLiquidations();
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA SUPPRESSION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void validerLiquidation() {
        ((CardLayout) pDetails.getLayout()).show(pDetails, "validation");
    }

    private void disableComponents() {
        txtObjetLiquidation.setEditable(false);
        txtLivrables.setEditable(false);
        txtPieces.setEditable(false);
        btnAnnuler.setVisible(false);
    }

    private void enableComponents() {
        txtObjetLiquidation.setEditable(true);
        txtLivrables.setEditable(true);
        txtPieces.setEditable(true);
        btnAnnuler.setVisible(true);
    }

    private void afficherCout() {
//        try {
//            txtMontantTVA.setValue(currentEngagement.getBeneficiaire());
//        } catch (Exception e) {
//        }
    }

    public List<LiquidationDroits> getListRetenues() {
        return listRetenues;
    }

    public void setListRetenues(List<LiquidationDroits> listRetenues) {
        this.listRetenues = listRetenues;
    }

    public LiquidationDroits getSelectedRetenue() {
        return selectedRetenue;
    }

    public void setSelectedRetenue(LiquidationDroits selectedRetenue) {
        this.selectedRetenue = selectedRetenue;
    }

    public List<Liquidation> getListLiquidations() {
        return listLiquidations;
    }

    public void setListLiquidations(List<Liquidation> listLiquidations) {
        this.listLiquidations = listLiquidations;
    }

    public Liquidation getSelectedLiquidation() {
        return selectedLiquidation;
    }

    public void setSelectedLiquidation(Liquidation selectedLiquidation) {
        this.selectedLiquidation = selectedLiquidation;
    }

    public void chargerLigne(WLigneFacture wlf) {
        try {
            Article am = GrecoServiceFactory.getMercurialeService().getArticle(currentEngagement.getMillesime(), wlf.getReference().toString());
            if (am != null) {
                wlf.setDesignation(am.getDesignation());
                Double prixLocalite = am.getPrixDeReference().doubleValue();
                Double marge = am.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                wlf.setPrixUnitaire(prixLocalite);
                wlf.setPuMin(Double.valueOf(0));
                wlf.setPuMax(prixLocalite + marge);
                wlf.setQuantite(1);
                wlf.setReference(am.getRefArticle());
                wlf.setId(am.getAmId());
            }
        } catch (Exception e) {

        }
    }

    public boolean validerFacture() {
        return true;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private com.siicore.facture.WPanelFacture bcaFacture;
    private javax.swing.ButtonGroup benefGroup;
    private cm.eusoworks.tools.ui.GButton btnAction;
    private cm.eusoworks.tools.ui.GButton btnAjouterRubrique;
    private cm.eusoworks.tools.ui.GButton btnAnnulation;
    private cm.eusoworks.tools.ui.GButton btnAnnuler;
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnFactureDefinitive;
    private cm.eusoworks.tools.ui.GButton btnNewLiquidation;
    private cm.eusoworks.tools.ui.GButton btnNewLiquidationMini;
    private cm.eusoworks.tools.ui.GButton btnOrdrePaiement;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private cm.eusoworks.tools.ui.GButton btnRetourAnnuler;
    private cm.eusoworks.tools.ui.GButton btnSupprimerLiquidMini;
    private cm.eusoworks.tools.ui.GButton btnValidation;
    private cm.eusoworks.tools.ui.GButton btnValiderLiquidation;
    private javax.swing.JComboBox<String> cboRubrique;
    private org.jdesktop.swingx.JXDatePicker dtpDateLiquidation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSplitPane jSplitPane1;
    private org.jdesktop.swingx.JXLabel jXLabel1;
    private org.jdesktop.swingx.JXLabel jXLabel2;
    private javax.swing.JLabel lblType;
    private org.jdesktop.swingx.JXHyperlink lnkPenalites;
    private javax.swing.JPanel pDetailCommande;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pNewLiquidation;
    private javax.swing.JPanel panelInfos;
    private javax.swing.JDialog penaliteDialog;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JRadioButton rdbRejet;
    private javax.swing.JRadioButton rdbValidation;
    private javax.swing.JTabbedPane tabbedLiquidation;
    private org.jdesktop.swingx.JXTable tableTaxes;
    private javax.swing.JTable tblLiquidationListe;
    private javax.swing.JTextArea txtLivrables;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtMontantRestantLiquider;
    private javax.swing.JFormattedTextField txtMontantRubrique;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextArea txtObjetLiquidation;
    private javax.swing.JTextArea txtObservations;
    private javax.swing.JTextArea txtObservationsAnnulation;
    private javax.swing.JTextArea txtPieces;
    private javax.swing.JTextField txtReference;
    private javax.swing.ButtonGroup validGroup;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
