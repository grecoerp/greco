/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.component.mercuriale.MercurialeComponent;
import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.enumeration.MercurialeMode;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Agent;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueEngagementLivre;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import cm.eusoworks.renderer.ListeActeRenderer;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WPanelFacture;
import com.siicore.util.StringUtil;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.AbstractButton;
import javax.swing.DefaultComboBoxModel;
import javax.swing.DefaultListModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.SwingUtilities;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();
    Exercice exercice;
    Organisation organisation;
    Bca currentBca = null;
    OrdreMission currentOM = null;
    Decision currentDecision = null;
    Engagement currentEngagement = null;
//    private CurvesProgressPanel glasspane;

    List<LiquidationDroits> listRetenues = ObservableCollections.observableList(new ArrayList<LiquidationDroits>());
    LiquidationDroits selectedRetenue = null;

    //composant
    WPanelFacture bcaFacture = null;

    public EngagementDialog(JFrame parent, boolean modal, Exercice e, Organisation o, Engagement current) {
        super(parent, true);
        initComponents();
        setPreferredSize(new Dimension(850, 476));
        glasspane.setText("1/2 Collecte des informations ...");
//        this.setGlassPane(glasspane);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Saisie des dossiers  ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.exercice = e;
        this.organisation = o;
        this.currentEngagement = current;
        ListeActeRenderer renderer = new ListeActeRenderer();
        renderer.setPreferredSize(new Dimension(425, 77));
        jListeActes.setCellRenderer(renderer);
        setLocationRelativeTo(null);
        loadStructureOrganisation();
        loadFournisseurs();
        initEngagementUI();
        disableBenef();
        rdbAgentItemStateChanged(null);
    }

    private void initEngagementUI() {
        if (currentEngagement == null) {
            txtNumDossier.setText("");
            txtReference.setText("");
            dtpDateSignature.setDate(null);
            txtObjet.setText("");
            txtSignataire.setText("");
            ordonnateurComp.setMatricule(null);

            txtMontant.setValue(null);
            listRetenues.clear();
            calculerNAP();

            cboImputation.setSelectedItem(null);
            txtDisponible.setValue(null);
            rdbAgent.setEnabled(true);
            rdbFournisseur.setEnabled(true);
            rdbStructure.setEnabled(true);
            rdbAutre.setEnabled(true);

            loadObjetcomponent();
            btnBeneficiare.setText("");
        } else {

            try {
                Enumeration<AbstractButton> e = radioGroup.getElements();

                while (e.hasMoreElements()) {
                    JRadioButton r = (JRadioButton) e.nextElement();
                    if (r.getActionCommand().equalsIgnoreCase(currentEngagement.getTypeID())) {
                        r.setSelected(true);
                        break;
                    }
                }

            } catch (Exception e) {
            }
            txtNumDossier.setText(currentEngagement.getNumDossier());
            txtReference.setText(currentEngagement.getReference());
            dtpDateSignature.setDate(currentEngagement.getDateSignature());
            txtObjet.setText(currentEngagement.getObjet());
            txtSignataire.setText(currentEngagement.getSignataire());
            ordonnateurComp.setMatricule(currentEngagement.getGestionnaire());
            try {
                txtMontant.setValue(currentEngagement.getMontantTTC());
            } catch (Exception e) {
            }

            if (currentEngagement.getMatricule() != null && !currentEngagement.getMatricule().isEmpty()) {
                agentComp.setMatricule(currentEngagement.getMatricule());
                rdbAgent.setSelected(true);
            } else if (currentEngagement.getFournisseurID() != null && !currentEngagement.getFournisseurID().isEmpty()) {
                for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                    Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                    if (f.getFournisseurID().equalsIgnoreCase(currentEngagement.getFournisseurID())) {
                        cboFournisseur.setSelectedIndex(i);
                        break;
                    }
                }
                rdbFournisseur.setSelected(true);
            } else if (currentEngagement.getStructureBenefID() != null && !currentEngagement.getStructureBenefID().isEmpty()) {
                for (int i = 0; i < cboStructure.getItemCount(); i++) {
                    Structure s = (Structure) cboStructure.getItemAt(i);
                    if (s.getStructureID().equalsIgnoreCase(currentEngagement.getStructureBenefID())) {
                        cboStructure.setSelectedIndex(i);
                        break;
                    }
                }
                rdbStructure.setSelected(true);
            } else {
                txtBenefAutre.setText(currentEngagement.getBeneficiaire());
                rdbAutre.setSelected(true);
            }
            for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
                Structure s = (Structure) cboStructureImputation.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentEngagement.getStructureID())) {
                    cboStructureImputation.setSelectedIndex(i);
                    break;
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentEngagement.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentEngagement.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            if (currentEngagement.getEtat() >= EtatDossier.reserve) {
                btnEnregistrer.setVisible(false);
                btnSupprimer.setVisible(false);
            }
            
            loadObjetcomponent();
            
            // details a charger en fonction du type de procedure

////            //charger les droits a liquider
////            List<LiquidationDroits> list = GrecoServiceFactory.getDroitsService().listeDroitsEngagement(currentEngagement.getEngagementID());
////            if (list != null && !list.isEmpty()) {
////                listRetenues.clear();
////                for (LiquidationDroits e : list) {
////                    listRetenues.add(e);
////                }
////                calculerNAP();
////            }
            
            ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");

        }
    }

    private void loadFournisseurs() {
        List<Fournisseur> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getFournisseurService().getListFournisseur();
        } catch (Exception e) {
            list = null;
        }

        if (list != null && !list.isEmpty()) {
            cboFournisseur.setModel(new DefaultComboBoxModel(list.toArray()));
            cboFournisseur.setSelectedIndex(-1);
        }
    }

    private void initDecisionUI() {

        txtReference.setText(currentDecision.getReference());
        dtpDateSignature.setDate(currentDecision.getDateSignature());
        txtObjet.setText(currentDecision.getObjet());
        txtSignataire.setText(currentDecision.getSignataire());
        txtMontant.setValue(currentDecision.getMontant());

        if (currentDecision.getMatricule() != null && !currentDecision.getMatricule().isEmpty()) {
            agentComp.setMatricule(currentDecision.getMatricule());
            rdbAgent.setSelected(true);
            cboStructure.setSelectedIndex(-1);
            cboFournisseur.setSelectedIndex(-1);
            txtBenefAutre.setText("");
        } else if (currentDecision.getFournisseurID() != null && !currentDecision.getFournisseurID().isEmpty()) {
            for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                if (f.getFournisseurID().equalsIgnoreCase(currentDecision.getFournisseurID())) {
                    cboFournisseur.setSelectedIndex(i);
                    break;
                }
            }
            rdbFournisseur.setSelected(true);
            cboStructure.setSelectedIndex(-1);
            agentComp.setMatricule(null);
            txtBenefAutre.setText("");
        } else if (currentDecision.getStructureBenefID() != null && !currentDecision.getStructureBenefID().isEmpty()) {
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentDecision.getStructureBenefID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }
            rdbStructure.setSelected(true);
            cboFournisseur.setSelectedIndex(-1);
            agentComp.setMatricule(null);
            txtBenefAutre.setText("");
        } else {
            txtBenefAutre.setText(currentDecision.getBeneficiaire());
            rdbAutre.setSelected(true);
        }
        for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
            Structure s = (Structure) cboStructureImputation.getItemAt(i);
            if (s.getStructureID().equalsIgnoreCase(currentDecision.getStructureID())) {
                cboStructureImputation.setSelectedIndex(i);
                break;
            }
        }

        for (int i = 0; i < cboTache.getItemCount(); i++) {
            Activite f = (Activite) cboTache.getItemAt(i);
            if (f.getActiviteID().equalsIgnoreCase(currentDecision.getActiviteID())) {
                cboTache.setSelectedIndex(i);
                break;
            }
        }
        for (int i = 0; i < cboImputation.getItemCount(); i++) {
            OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
            if (f.getTacheID().equalsIgnoreCase(currentDecision.getTacheID())) {
                cboImputation.setSelectedIndex(i);
                break;
            }
        }
        loadObjetcomponent();
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresUserByOrganisation(organisation.getOrganisationID(), 
                                                                        GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);
            cboStructureImputation.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructureImputation.setSelectedIndex(-1);
        }

    }

    private boolean controlData() {

        if (radioGroup.getSelection() == null) {
            JOptionPane.showMessageDialog(null, "Veuillez choisir le type d'engagement ou l'acte administratif");
            return false;
        }

        if (txtReference.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir la référence juridique de l'engagement");
            return false;
        }

        if (txtObjet.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir l'objet de l'engagement ");
            return false;
        }
        if (dtpDateSignature.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir la date de signature de l'engagement ");
            return false;
        }
        if (txtSignataire.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir le nom du signataire de l'engagement ");
            return false;
        }
        //control beneficiare
        if (rdbAgent.isSelected()) {
            if (agentComp.getMatricule().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Veuillez saisir le matricule de l'agent bénéficiaire ");
                return false;
            }
        }
        if (rdbFournisseur.isSelected()) {
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            if (f == null) {
                JOptionPane.showMessageDialog(null, "Veuillez sélectionner le fournisseur ");
                return false;
            }
        }
        if (rdbStructure.isSelected()) {
            Structure s = (Structure) cboStructure.getSelectedItem();
            if (s == null) {
                JOptionPane.showMessageDialog(null, "Veuillez sélectionner la structure bénéficiare ");
                return false;
            }
        }
        if (rdbAutre.isSelected()) {
            if (txtBenefAutre.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Veuillez saisir le libellé du bénéficiare ");
                return false;
            }
        }
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op == null) {
            JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'imputation budgétaire");
            return false;
        }
        if (txtMontant.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir le montant de la dépense ");
            return false;
        }
        if (listRetenues.size() == 0) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir les droits à liquider de cette dépense ");
            return false;
        }

        //disponible 
        Number ttc = (Number) txtMontant.getValue();
        Number dispo = (Number) txtDisponible.getValue();
        if (dispo.longValue() < Math.round(ttc.doubleValue())) {
            JOptionPane.showMessageDialog(null, "Indisponibilité de crédits sur la tâche!! ", "GRECO - INDISPONIBILITE DE CREDITS",
                    JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }

    private void remplirEngagement() {
        currentEngagement.setReference(txtReference.getText().trim());
        currentEngagement.setDateSignature(dtpDateSignature.getDate());
        currentEngagement.setObjet(txtObjet.getText());
        currentEngagement.setSignataire(txtSignataire.getText());

        Number nbr = (Number) txtMontant.getValue();
        currentEngagement.setMontantTTC(BigDecimal.valueOf(nbr.longValue()));

        if (rdbAgent.isSelected()) {
            currentEngagement.setMatricule(agentComp.getMatricule());
            currentEngagement.setBeneficiaire("[" + agentComp.getMatricule() + "] " + agentComp.getNomComplet());
            currentEngagement.setFournisseurID(null);
            currentEngagement.setStructureBenefID(null);
        } else if (rdbFournisseur.isSelected()) {
            currentEngagement.setMatricule(null);
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            currentEngagement.setBeneficiaire(f.getNumContribuable() + " - " + f.getRaisonSociale());
            currentEngagement.setFournisseurID(f.getFournisseurID());
            currentEngagement.setStructureBenefID(null);
        } else if (rdbStructure.isSelected()) {
            Structure s = (Structure) cboStructure.getSelectedItem();
            currentEngagement.setMatricule(null);
            currentEngagement.setBeneficiaire(s.getLibelle());
            currentEngagement.setFournisseurID(null);
            currentEngagement.setStructureBenefID(s.getStructureID());
        } else if (rdbAutre.isSelected()) {
            currentEngagement.setMatricule(null);
            currentEngagement.setBeneficiaire(txtBenefAutre.getText().trim());
            currentEngagement.setFournisseurID(null);
            currentEngagement.setStructureBenefID(null);
        }
        Structure s = (Structure) cboStructureImputation.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();

        currentEngagement.setStructureID(s.getStructureID());
        currentEngagement.setTacheID(o.getTacheID());
        currentEngagement.setActiviteID(a.getActiviteID());
        currentEngagement.setOrganisationID(organisation.getOrganisationID());
        currentEngagement.setMillesime(exercice.getMillesime());

        currentEngagement.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentEngagement.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        try {
            currentEngagement.setBcaID(currentBca.getBcaID());
        } catch (Exception e) {
            currentEngagement.setBcaID(null);
        }

        try {
            currentEngagement.setOmID(currentOM.getOmID());
        } catch (Exception e) {
            currentEngagement.setOmID(null);
        }
        try {
            currentEngagement.setDecisionID(currentDecision.getDecisionID());
        } catch (Exception e) {
            currentEngagement.setDecisionID(null);
        }
        try {
//            currentEngagement.setGestionnaire(ordonnateurComp.getMatricule());
            currentEngagement.setGestionnaire(txtSignataire.getText().trim().toLowerCase());
        } catch (Exception e) {
        }

        currentEngagement.setTypeID(radioGroup.getSelection().getActionCommand());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        benefGroup = new javax.swing.ButtonGroup();
        radioGroup = new javax.swing.ButtonGroup();
        panelDetails = new javax.swing.JPanel();
        tabbedPane = new javax.swing.JTabbedPane();
        panelInfos = new javax.swing.JPanel();
        panelActeAdministratif = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        rdbBonCommande = new javax.swing.JRadioButton();
        rdbOrdreMission = new javax.swing.JRadioButton();
        rdbDecision = new javax.swing.JRadioButton();
        jPanel5 = new javax.swing.JPanel();
        btnActeAdministratifRetour = new cm.eusoworks.tools.ui.GButton();
        btnActeAdministratifSave = new cm.eusoworks.tools.ui.GButton();
        btnApercu = new cm.eusoworks.tools.ui.GButton();
        rdbLettreCommande = new javax.swing.JRadioButton();
        rdbMarche = new javax.swing.JRadioButton();
        scrollActes = new javax.swing.JScrollPane();
        jListeActes = new javax.swing.JList<>();
        btnContinuerActeSelected = new cm.eusoworks.tools.ui.GButton();
        lblResult = new javax.swing.JLabel();
        pDetailDecision = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnAddEngagement = new cm.eusoworks.tools.ui.GButton();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        jPanel2 = new javax.swing.JPanel();
        pObjetCommande = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        cboStructureImputation = new javax.swing.JComboBox();
        jLabel21 = new javax.swing.JLabel();
        txtDisponible = new javax.swing.JFormattedTextField();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        panelObjet = new cm.eusoworks.tools.ui.GPanelInfo();
        linkActeAdministratfi = new org.jdesktop.swingx.JXHyperlink();
        btnCout = new javax.swing.JButton();
        panelReference = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        jLabel2 = new javax.swing.JLabel();
        dtpDateSignature = new org.jdesktop.swingx.JXDatePicker();
        jLabel11 = new javax.swing.JLabel();
        txtSignataire = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        ordonnateurComp = new cm.eusoworks.component.AgentComponent();
        jLabel8 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btnObjetRetour = new cm.eusoworks.tools.ui.GButton();
        btnObjetSave = new cm.eusoworks.tools.ui.GButton();
        panelMission = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txtMissionItineraire = new javax.swing.JTextField();
        jLabel18 = new javax.swing.JLabel();
        dtpMissionDepart = new org.jdesktop.swingx.JXDatePicker();
        jLabel19 = new javax.swing.JLabel();
        dtpMissionArrivee = new org.jdesktop.swingx.JXDatePicker();
        jLabel20 = new javax.swing.JLabel();
        lblNbreJours = new javax.swing.JLabel();
        chkMissionType = new javax.swing.JCheckBox();
        chkMissionEffectue = new javax.swing.JCheckBox();
        panelBenef = new javax.swing.JPanel();
        agentComp = new cm.eusoworks.component.AgentComponent();
        rdbAgent = new javax.swing.JRadioButton();
        rdbFournisseur = new javax.swing.JRadioButton();
        cboFournisseur = new javax.swing.JComboBox();
        rdbStructure = new javax.swing.JRadioButton();
        cboStructure = new javax.swing.JComboBox();
        rdbAutre = new javax.swing.JRadioButton();
        txtBenefAutre = new javax.swing.JTextField();
        jPanel7 = new javax.swing.JPanel();
        btnBenefRetour = new cm.eusoworks.tools.ui.GButton();
        btnBenefSave = new cm.eusoworks.tools.ui.GButton();
        jLabel22 = new javax.swing.JLabel();
        cboRIB = new javax.swing.JComboBox<>();
        btnFournisseurAfficher = new cm.eusoworks.tools.ui.GButton();
        panelTaxes = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableTaxes = new org.jdesktop.swingx.JXTable();
        jPanel8 = new javax.swing.JPanel();
        btnCoutRetour = new cm.eusoworks.tools.ui.GButton();
        btnCoutSave = new cm.eusoworks.tools.ui.GButton();
        btnAddRetenue = new cm.eusoworks.tools.ui.GButton();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtNAP = new javax.swing.JFormattedTextField();
        jLabel15 = new javax.swing.JLabel();
        txtRetenues = new javax.swing.JFormattedTextField();

        panelDetails.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                panelDetailsFocusLost(evt);
            }
        });
        panelDetails.setLayout(new java.awt.BorderLayout());

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Saise des dossiers d'engagements");

        tabbedPane.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        panelInfos.setLayout(new java.awt.CardLayout());

        panelActeAdministratif.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel4.setText("Sélectionner le type d'engagement ");

        radioGroup.add(rdbBonCommande);
        rdbBonCommande.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbBonCommande.setForeground(new java.awt.Color(204, 0, 51));
        rdbBonCommande.setText("BON DE COMMANDE ADMINISTRATIF (BCA)");
        rdbBonCommande.setActionCommand("1");
        rdbBonCommande.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbBonCommandeActionPerformed(evt);
            }
        });

        radioGroup.add(rdbOrdreMission);
        rdbOrdreMission.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbOrdreMission.setForeground(new java.awt.Color(102, 0, 204));
        rdbOrdreMission.setText("ORDRE DE MISSION (OM)");
        rdbOrdreMission.setActionCommand("4");
        rdbOrdreMission.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbOrdreMissionActionPerformed(evt);
            }
        });

        radioGroup.add(rdbDecision);
        rdbDecision.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbDecision.setForeground(new java.awt.Color(153, 153, 0));
        rdbDecision.setText("DECISION DE DEBLOCAGE DE FONDS");
        rdbDecision.setActionCommand("5");
        rdbDecision.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbDecisionActionPerformed(evt);
            }
        });

        jPanel5.setOpaque(false);
        jPanel5.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnActeAdministratifRetour.setText("<<< Annuler");
        btnActeAdministratifRetour.setCouleur(3);
        btnActeAdministratifRetour.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnActeAdministratifRetour.setStyle(1);
        btnActeAdministratifRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActeAdministratifRetourActionPerformed(evt);
            }
        });
        jPanel5.add(btnActeAdministratifRetour);

        btnActeAdministratifSave.setText("Continuer >>>");
        btnActeAdministratifSave.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnActeAdministratifSave.setStyle(3);
        btnActeAdministratifSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActeAdministratifSaveActionPerformed(evt);
            }
        });
        jPanel5.add(btnActeAdministratifSave);

        btnApercu.setText("Aperçu");
        btnApercu.setCouleur(2);
        btnApercu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApercuActionPerformed(evt);
            }
        });

        radioGroup.add(rdbLettreCommande);
        rdbLettreCommande.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbLettreCommande.setText("LETTRE COMMANDE");
        rdbLettreCommande.setActionCommand("2");
        rdbLettreCommande.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbLettreCommandeActionPerformed(evt);
            }
        });

        radioGroup.add(rdbMarche);
        rdbMarche.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbMarche.setText("MARCHE ");
        rdbMarche.setActionCommand("3");
        rdbMarche.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbMarcheActionPerformed(evt);
            }
        });

        jListeActes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        scrollActes.setViewportView(jListeActes);

        btnContinuerActeSelected.setText("Continuer avec cet acte >>>");
        btnContinuerActeSelected.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnContinuerActeSelected.setStyle(3);
        btnContinuerActeSelected.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnContinuerActeSelectedActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelActeAdministratifLayout = new javax.swing.GroupLayout(panelActeAdministratif);
        panelActeAdministratif.setLayout(panelActeAdministratifLayout);
        panelActeAdministratifLayout.setHorizontalGroup(
            panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelActeAdministratifLayout.createSequentialGroup()
                .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdbDecision, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(rdbMarche, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(rdbLettreCommande, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(rdbOrdreMission, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(rdbBonCommande, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 81, Short.MAX_VALUE)
                .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(scrollActes, javax.swing.GroupLayout.PREFERRED_SIZE, 464, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblResult, javax.swing.GroupLayout.PREFERRED_SIZE, 340, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(16, 90, Short.MAX_VALUE))
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addComponent(btnContinuerActeSelected, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btnApercu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(40, 40, 40))))
        );
        panelActeAdministratifLayout.setVerticalGroup(
            panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4)
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(lblResult, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addComponent(rdbBonCommande)
                        .addGap(18, 18, 18)
                        .addComponent(rdbLettreCommande)
                        .addGap(23, 23, 23)
                        .addComponent(rdbMarche)
                        .addGap(27, 27, 27)
                        .addComponent(rdbOrdreMission)
                        .addGap(26, 26, 26)
                        .addComponent(rdbDecision)
                        .addGap(148, 148, 148)
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelActeAdministratifLayout.createSequentialGroup()
                        .addComponent(scrollActes, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(54, 54, 54)
                        .addGroup(panelActeAdministratifLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnContinuerActeSelected, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnApercu, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap(181, Short.MAX_VALUE))
        );

        panelInfos.add(panelActeAdministratif, "acte");

        pDetailDecision.setBackground(new java.awt.Color(255, 255, 255));
        pDetailDecision.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 5));

        btnAddEngagement.setText("+");
        btnAddEngagement.setCouleur(2);
        btnAddEngagement.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btnAddEngagement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddEngagementActionPerformed(evt);
            }
        });
        jPanel3.add(btnAddEngagement);

        btnSupprimer.setText("Supprimer le dossier");
        btnSupprimer.setCouleur(1);
        btnSupprimer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel3.add(btnSupprimer);

        btnEnregistrer.setText("Enregistrer les informations");
        btnEnregistrer.setCouleur(2);
        btnEnregistrer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel3.add(btnEnregistrer);

        jPanel1.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        pObjetCommande.setBackground(new java.awt.Color(255, 255, 255));
        pObjetCommande.setLayout(null);

        jLabel6.setText("Tâche : ");
        pObjetCommande.add(jLabel6);
        jLabel6.setBounds(17, 50, 70, 20);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(20, 90, 90, 20);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 47, 610, 30);

        cboImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboImputationActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 83, 610, 27);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(20, 10, 80, 30);

        cboStructureImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureImputationActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboStructureImputation);
        cboStructureImputation.setBounds(110, 7, 610, 40);

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(204, 0, 0));
        jLabel21.setText("Disponible : ");
        pObjetCommande.add(jLabel21);
        jLabel21.setBounds(20, 120, 90, 30);

        txtDisponible.setEditable(false);
        txtDisponible.setForeground(new java.awt.Color(255, 0, 0));
        txtDisponible.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtDisponible.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        pObjetCommande.add(txtDisponible);
        txtDisponible.setBounds(110, 120, 220, 30);

        jLabel12.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);

        jLabel17.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel17.setText("N° Dossier : ");

        jLabel16.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        jLabel16.setText("Objet : ");

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        btnBeneficiare.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBeneficiareMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBeneficiareMouseEntered(evt);
            }
        });
        btnBeneficiare.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBeneficiareActionPerformed(evt);
            }
        });

        panelObjet.setCouleur(3);
        panelObjet.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                panelObjetMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                panelObjetMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                panelObjetMouseExited(evt);
            }
        });

        linkActeAdministratfi.setText("Sélectionner l'acte administratif ....");
        linkActeAdministratfi.setClickedColor(new java.awt.Color(0, 51, 255));
        linkActeAdministratfi.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        linkActeAdministratfi.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                linkActeAdministratfiMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                linkActeAdministratfiMouseExited(evt);
            }
        });
        linkActeAdministratfi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                linkActeAdministratfiActionPerformed(evt);
            }
        });

        btnCout.setText("Cout");
        btnCout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCoutActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(pObjetCommande, javax.swing.GroupLayout.PREFERRED_SIZE, 748, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(panelObjet, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnBeneficiare, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 731, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(jLabel17)
                                .addGap(8, 8, 8)
                                .addComponent(txtNumDossier, javax.swing.GroupLayout.PREFERRED_SIZE, 156, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(linkActeAdministratfi, javax.swing.GroupLayout.PREFERRED_SIZE, 404, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(24, 24, 24)
                        .addComponent(btnCout, javax.swing.GroupLayout.PREFERRED_SIZE, 93, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(txtNumDossier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(linkActeAdministratfi, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(17, 17, 17)
                .addComponent(jLabel16, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, 0)
                .addComponent(panelObjet, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnBeneficiare, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(pObjetCommande, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btnCout, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(86, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2, java.awt.BorderLayout.CENTER);

        pDetailDecision.add(jPanel1, java.awt.BorderLayout.CENTER);

        panelInfos.add(pDetailDecision, "dossier");

        panelReference.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("Référence : ");

        txtReference.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        txtObjet.setRows(2);
        jScrollPane2.setViewportView(txtObjet);

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel2.setText("Date de signature : ");

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Signataire : ");

        txtSignataire.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("Objet : ");

        ordonnateurComp.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                ordonnateurCompFocusLost(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Ordonnateur ");

        jPanel6.setOpaque(false);
        jPanel6.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnObjetRetour.setText("<<< Annuler");
        btnObjetRetour.setCouleur(3);
        btnObjetRetour.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnObjetRetour.setStyle(1);
        btnObjetRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnObjetRetourActionPerformed(evt);
            }
        });
        jPanel6.add(btnObjetRetour);

        btnObjetSave.setText("Continuer >>>");
        btnObjetSave.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnObjetSave.setStyle(3);
        btnObjetSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnObjetSaveActionPerformed(evt);
            }
        });
        jPanel6.add(btnObjetSave);

        panelMission.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Details de la mission ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Arial", 0, 14))); // NOI18N

        jLabel7.setText("Itineraire : ");

        txtMissionItineraire.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        jLabel18.setText("Date de depart : ");

        jLabel19.setText("Date d'arrivee  : ");

        jLabel20.setText("Nombre de jours :   ");

        lblNbreJours.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblNbreJours.setText("pp");

        chkMissionType.setText("Mission effectue a l'interieur du pays ");

        chkMissionEffectue.setText("Mission deja effectuee");

        javax.swing.GroupLayout panelMissionLayout = new javax.swing.GroupLayout(panelMission);
        panelMission.setLayout(panelMissionLayout);
        panelMissionLayout.setHorizontalGroup(
            panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMissionLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelMissionLayout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblNbreJours, javax.swing.GroupLayout.PREFERRED_SIZE, 157, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelMissionLayout.createSequentialGroup()
                        .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel18))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelMissionLayout.createSequentialGroup()
                                .addComponent(dtpMissionDepart, javax.swing.GroupLayout.PREFERRED_SIZE, 162, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jLabel19)
                                .addGap(18, 18, 18)
                                .addComponent(dtpMissionArrivee, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(187, 187, 187))
                            .addGroup(panelMissionLayout.createSequentialGroup()
                                .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txtMissionItineraire, javax.swing.GroupLayout.PREFERRED_SIZE, 690, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(panelMissionLayout.createSequentialGroup()
                                        .addComponent(chkMissionType, javax.swing.GroupLayout.PREFERRED_SIZE, 331, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(35, 35, 35)
                                        .addComponent(chkMissionEffectue, javax.swing.GroupLayout.PREFERRED_SIZE, 258, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))))
        );
        panelMissionLayout.setVerticalGroup(
            panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMissionLayout.createSequentialGroup()
                .addContainerGap(10, Short.MAX_VALUE)
                .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(chkMissionType)
                    .addComponent(chkMissionEffectue))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMissionItineraire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(dtpMissionDepart, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(dtpMissionArrivee, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelMissionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblNbreJours, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        javax.swing.GroupLayout panelReferenceLayout = new javax.swing.GroupLayout(panelReference);
        panelReference.setLayout(panelReferenceLayout);
        panelReferenceLayout.setHorizontalGroup(
            panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelReferenceLayout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelReferenceLayout.createSequentialGroup()
                        .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 106, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelReferenceLayout.createSequentialGroup()
                                .addGap(0, 0, Short.MAX_VALUE)
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 86, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(506, 506, 506))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelReferenceLayout.createSequentialGroup()
                                .addGap(47, 47, 47)
                                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txtReference)
                                    .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 708, Short.MAX_VALUE))
                                .addGap(0, 0, Short.MAX_VALUE))))
                    .addGroup(panelReferenceLayout.createSequentialGroup()
                        .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(panelMission, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addGroup(panelReferenceLayout.createSequentialGroup()
                                .addGap(153, 153, 153)
                                .addComponent(dtpDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(txtSignataire, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, panelReferenceLayout.createSequentialGroup()
                                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(20, 20, 20)
                                .addComponent(ordonnateurComp, javax.swing.GroupLayout.PREFERRED_SIZE, 710, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(97, Short.MAX_VALUE))))
            .addGroup(panelReferenceLayout.createSequentialGroup()
                .addGap(203, 203, 203)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, 423, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        panelReferenceLayout.setVerticalGroup(
            panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelReferenceLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane2)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtReference)
                    .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(dtpDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel11)
                        .addComponent(txtSignataire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelReferenceLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(ordonnateurComp, javax.swing.GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE))
                .addGap(39, 39, 39)
                .addComponent(panelMission, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(161, 161, 161))
        );

        panelInfos.add(panelReference, "objet");

        panelBenef.setBackground(new java.awt.Color(255, 255, 255));
        panelBenef.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "BENEFICIAIRE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 102, 153))); // NOI18N

        benefGroup.add(rdbAgent);
        rdbAgent.setSelected(true);
        rdbAgent.setText("Agent");
        rdbAgent.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbAgentItemStateChanged(evt);
            }
        });

        benefGroup.add(rdbFournisseur);
        rdbFournisseur.setText("Fournisseur ");
        rdbFournisseur.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbFournisseurItemStateChanged(evt);
            }
        });

        cboFournisseur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboFournisseurActionPerformed(evt);
            }
        });

        benefGroup.add(rdbStructure);
        rdbStructure.setText("Structure");
        rdbStructure.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbStructureItemStateChanged(evt);
            }
        });

        benefGroup.add(rdbAutre);
        rdbAutre.setText("Autre : ");
        rdbAutre.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbAutreItemStateChanged(evt);
            }
        });
        rdbAutre.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbAutreActionPerformed(evt);
            }
        });

        jPanel7.setOpaque(false);
        jPanel7.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnBenefRetour.setText("<<< Annuler");
        btnBenefRetour.setCouleur(3);
        btnBenefRetour.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBenefRetour.setStyle(1);
        btnBenefRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBenefRetourActionPerformed(evt);
            }
        });
        jPanel7.add(btnBenefRetour);

        btnBenefSave.setText("Continuer >>>");
        btnBenefSave.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnBenefSave.setStyle(3);
        btnBenefSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnBenefSaveActionPerformed(evt);
            }
        });
        jPanel7.add(btnBenefSave);

        jLabel22.setText("RIB : ");

        cboRIB.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnFournisseurAfficher.setText("Ouvrir ...");
        btnFournisseurAfficher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFournisseurAfficherActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelBenefLayout = new javax.swing.GroupLayout(panelBenef);
        panelBenef.setLayout(panelBenefLayout);
        panelBenefLayout.setHorizontalGroup(
            panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelBenefLayout.createSequentialGroup()
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(rdbAutre, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rdbStructure, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rdbAgent, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(rdbFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, 131, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 20, Short.MAX_VALUE)
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboStructure, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboFournisseur, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(agentComp, javax.swing.GroupLayout.DEFAULT_SIZE, 448, Short.MAX_VALUE)
                    .addComponent(txtBenefAutre))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnFournisseurAfficher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(259, 259, 259))
            .addGroup(panelBenefLayout.createSequentialGroup()
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBenefLayout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelBenefLayout.createSequentialGroup()
                        .addGap(70, 70, 70)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(39, 39, 39)
                        .addComponent(cboRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 286, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        panelBenefLayout.setVerticalGroup(
            panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelBenefLayout.createSequentialGroup()
                .addGap(36, 36, 36)
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbAgent)
                    .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(9, 9, 9)
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnFournisseurAfficher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(rdbFournisseur, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboRIB)
                    .addComponent(jLabel22, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(17, 17, 17)
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbStructure)
                    .addGroup(panelBenefLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(cboStructure, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(9, 9, 9)
                .addGroup(panelBenefLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtBenefAutre, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdbAutre, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(84, 84, 84)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(261, Short.MAX_VALUE))
        );

        panelInfos.add(panelBenef, "benef");

        panelTaxes.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("Montant TTC: ");

        txtMontant.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtMontant.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontant.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtMontant.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtMontantFocusLost(evt);
            }
        });
        txtMontant.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtMontantKeyReleased(evt);
            }
        });

        tableTaxes.setShowGrid(true);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listRetenues}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableTaxes);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Rubrique");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${sigleFr}"));
        columnBinding.setColumnName("Abbréviation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${taux}"));
        columnBinding.setColumnName("Taux (%)");
        columnBinding.setColumnClass(Double.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedRetenue}"), tableTaxes, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableTaxes.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                tableTaxesKeyReleased(evt);
            }
        });
        jScrollPane3.setViewportView(tableTaxes);
        if (tableTaxes.getColumnModel().getColumnCount() > 0) {
            tableTaxes.getColumnModel().getColumn(1).setResizable(false);
            tableTaxes.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableTaxes.getColumnModel().getColumn(2).setResizable(false);
            tableTaxes.getColumnModel().getColumn(2).setPreferredWidth(30);
        }

        jPanel8.setOpaque(false);
        jPanel8.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnCoutRetour.setText("<<< Annuler");
        btnCoutRetour.setCouleur(3);
        btnCoutRetour.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCoutRetour.setStyle(1);
        btnCoutRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCoutRetourActionPerformed(evt);
            }
        });
        jPanel8.add(btnCoutRetour);

        btnCoutSave.setText("Continuer >>>");
        btnCoutSave.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnCoutSave.setStyle(3);
        btnCoutSave.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCoutSaveActionPerformed(evt);
            }
        });
        jPanel8.add(btnCoutSave);

        btnAddRetenue.setText("+");
        btnAddRetenue.setCouleur(2);
        btnAddRetenue.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        btnAddRetenue.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddRetenueActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(102, 0, 102));
        jLabel13.setText("TAXES ET AUTRES RETENUES");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setText("Montant Net A Payer  : ");

        txtNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtNAP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtNAP.setEnabled(false);
        txtNAP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(102, 0, 102));
        jLabel15.setText("Total des retenues : ");

        txtRetenues.setForeground(new java.awt.Color(102, 0, 102));
        txtRetenues.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtRetenues.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRetenues.setEnabled(false);
        txtRetenues.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        javax.swing.GroupLayout panelTaxesLayout = new javax.swing.GroupLayout(panelTaxes);
        panelTaxes.setLayout(panelTaxesLayout);
        panelTaxesLayout.setHorizontalGroup(
            panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTaxesLayout.createSequentialGroup()
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTaxesLayout.createSequentialGroup()
                                    .addComponent(btnAddRetenue, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 176, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGap(18, 18, 18)
                                    .addComponent(txtMontant, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(panelTaxesLayout.createSequentialGroup()
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(panelTaxesLayout.createSequentialGroup()
                                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(30, 30, 30)
                                    .addComponent(txtRetenues, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 427, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(515, Short.MAX_VALUE))
        );
        panelTaxesLayout.setVerticalGroup(
            panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTaxesLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMontant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(btnAddRetenue, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRetenues, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(285, Short.MAX_VALUE))
        );

        panelInfos.add(panelTaxes, "cout");

        tabbedPane.addTab("Informations générales", panelInfos);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboFournisseurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboFournisseurActionPerformed
        // TODO add your handling code here:
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
        if(f != null){
            chargerComptes(f.getFournisseurID());
        }
    }//GEN-LAST:event_cboFournisseurActionPerformed

    
    private void chargerComptes(String fournisseurID) {
        List<VueFournisseurRIB> list = GrecoServiceFactory.getBanqueService().ribByFournisseur(fournisseurID);
        if (list != null) {
            cboRIB.setModel(new DefaultComboBoxModel(list.toArray()));
            if(list.size() > 1){
                cboRIB.setSelectedIndex(-1);
            }
        }
    }
    
    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        txtDisponible.setValue(new BigDecimal(0));
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void cboStructureImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureImputationActionPerformed
        // TODO add your handling code here:

        Structure s = null;
        try {
            s = (Structure) cboStructureImputation.getSelectedItem();
        } catch (Exception ex) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            txtDisponible.setValue(new BigDecimal(0));
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(exercice.getMillesime(),
                        organisation.getOrganisationID(), s.getStructureID());
            } catch (Exception exx) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureImputationActionPerformed

    private void rdbAgentItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbAgentItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbAgent.isSelected()) {
            agentComp.setEnabled(true);
        }
    }//GEN-LAST:event_rdbAgentItemStateChanged

    private void rdbFournisseurItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbFournisseurItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbFournisseur.isSelected()) {
            cboFournisseur.setEnabled(true);
        }
    }//GEN-LAST:event_rdbFournisseurItemStateChanged

    private void rdbStructureItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbStructureItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbStructure.isSelected()) {
            cboStructure.setEnabled(true);
        }
    }//GEN-LAST:event_rdbStructureItemStateChanged

    private void rdbAutreItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbAutreItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbAutre.isSelected()) {
            txtBenefAutre.setEnabled(true);
        }
    }//GEN-LAST:event_rdbAutreItemStateChanged

    private void rdbBonCommandeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbBonCommandeActionPerformed
        // TODO add your handling code here:

        if (rdbBonCommande.isSelected()) {
            loadBCA();
        }
    }//GEN-LAST:event_rdbBonCommandeActionPerformed

    private void rdbOrdreMissionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbOrdreMissionActionPerformed
        // TODO add your handling code here:

        if (rdbOrdreMission.isSelected()) {
            loadOM();
        }
    }//GEN-LAST:event_rdbOrdreMissionActionPerformed

    private void rdbDecisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbDecisionActionPerformed
        // TODO add your handling code here:

        if (rdbDecision.isSelected()) {
            loadDecision();
        }
    }//GEN-LAST:event_rdbDecisionActionPerformed

    private void enregistrer() {
        if (controlData()) {
            glasspane.setText("enregistrement de la dépense ....");
            glasspane.attente();
            if (currentEngagement == null) {
                currentEngagement = new Engagement();
                remplirEngagement();
                try {
                    String numDossier = GrecoServiceFactory.getEngagementService().ajouter(currentEngagement);
                    currentEngagement.setNumDossier(numDossier);
                    txtNumDossier.setText(numDossier);

                    currentEngagement = GrecoServiceFactory.getEngagementService().getEngagementByDossier(numDossier);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Engagement enregistré avec succès \n\n" + "N° de dossier : " + numDossier + "\n\nLa fiche d'engagement va être imprimée tout de suite après");

//////                    glasspane.setText("enregistrement des droits a liquider");
//////                    glasspane.attente();
//////                    //enregistrement des droits
//////                    try {
//////                        GrecoServiceFactory.getDroitsService().supprimerDroitEngagement(currentEngagement.getEngagementID());
//////                        if (listRetenues.size() > 0) {
//////                            List<LiquidationDroits> l = new ArrayList<>();
//////                            for (LiquidationDroits e : listRetenues) {
//////                                e.setEngagementID(currentEngagement.getEngagementID());
//////                                l.add(e);
//////                            }
//////                            GrecoServiceFactory.getDroitsService().ajouterDroitEngagement(l);
//////                        }
//////                    } catch (Exception e) {
//////                        glasspane.arret();
//////                    }
                    //impression de la fiche d'engagement
                    try {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                glasspane.setText("Edition de la fiche d'engagement N° " + currentEngagement.getNumDossier());
                            }
                        });
                        imprimerFicheEngagement(currentEngagement.getEngagementID(), currentEngagement.getNumDossier());
                        glasspane.arret();
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(this, "La fiche d'engagement n'a pas pu être imprimée");
                    }

                    glasspane.arret();
                } catch (GrecoException e) {
                    glasspane.arret();
                    currentEngagement = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                } catch (Exception e) {
                    glasspane.arret();
                    e.printStackTrace();
                    currentEngagement = null;
                    GrecoSession.notifications.echec();
                    JOptionPane.showMessageDialog(this, "ECHEC DE L'NREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                remplirEngagement();
                try {
                    GrecoServiceFactory.getEngagementService().modifier(currentEngagement);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Engagement modifié avec succès ");
//////                    glasspane.setText("enregistrement des droits a liquider");
//////                    glasspane.attente();
//////                    //enregistrement des droits
//////                    try {
//////                        GrecoServiceFactory.getDroitsService().supprimerDroitEngagement(currentEngagement.getEngagementID());
//////                        if (listRetenues.size() > 0) {
//////                            List<LiquidationDroits> l = new ArrayList<>();
//////                            for (LiquidationDroits e : listRetenues) {
//////                                e.setEngagementID(currentEngagement.getEngagementID());
//////                                l.add(e);
//////                            }
//////                            GrecoServiceFactory.getDroitsService().ajouterDroitEngagement(l);
//////                        }
//////                    } catch (Exception e) {
//////                        glasspane.arret();
//////                    }
//////                    glasspane.arret();
                } catch (GrecoException e) {
                    glasspane.arret();
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }

            glasspane.arret();
        }
    }
    
    private void linkActeAdministratfiMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_linkActeAdministratfiMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_linkActeAdministratfiMouseEntered

    private void linkActeAdministratfiMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_linkActeAdministratfiMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_linkActeAdministratfiMouseExited

    private void panelObjetMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelObjetMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_panelObjetMouseEntered

    private void panelObjetMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelObjetMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_panelObjetMouseExited

    private void btnBeneficiareMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBeneficiareMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btnBeneficiareMouseEntered

    private void btnBeneficiareMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBeneficiareMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnBeneficiareMouseExited

    private void linkActeAdministratfiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkActeAdministratfiActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "acte");
    }//GEN-LAST:event_linkActeAdministratfiActionPerformed

    private void btnActeAdministratifRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActeAdministratifRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnActeAdministratifRetourActionPerformed

    private void btnObjetRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnObjetRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnObjetRetourActionPerformed

    private void btnBenefRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBenefRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnBenefRetourActionPerformed

    private void btnCoutRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCoutRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnCoutRetourActionPerformed

    private void panelObjetMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_panelObjetMouseClicked
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "objet");
    }//GEN-LAST:event_panelObjetMouseClicked

    private void btnBeneficiareActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBeneficiareActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "benef");
    }//GEN-LAST:event_btnBeneficiareActionPerformed

    private void btnAddRetenueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddRetenueActionPerformed
        // TODO add your handling code here:
        Number n = (Number) txtMontant.getValue();
        if (n == null || n.longValue() == 0) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir le montant TTC");
            return;
        }
        EngagementDroitDialog e = new EngagementDroitDialog(this, new BigDecimal(n.longValue()));
        e.setVisible(true);
        LiquidationDroits r = e.getRubrique();
        e.dispose();
        if (r != null) {
            //vérifier que cette rubrique n'existait pas déjà
            for (LiquidationDroits eg : listRetenues) {
                if (eg.getDroitID().equalsIgnoreCase(r.getDroitID())) {
                    JOptionPane.showMessageDialog(null, "Cette rubrique de retenue existe déja");
                    return;
                }
            }
            //récupérer la liste des rubriques
            List<LiquidationDroits> l = new ArrayList<>();
            for (LiquidationDroits retenues : listRetenues) {
                l.add(retenues);
            }
            //ajouter le nouvel element
            l.add(r);
            // recharger la liste dans le tableau par binding
            listRetenues.clear();
            for (LiquidationDroits g : l) {
                listRetenues.add(g);
            }
        }

        calculerNAP();
    }//GEN-LAST:event_btnAddRetenueActionPerformed

    private void btnActeAdministratifSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActeAdministratifSaveActionPerformed
        // TODO add your handling code here:
        continuer();
    }//GEN-LAST:event_btnActeAdministratifSaveActionPerformed

    private void continuer() {
        currentEngagement = null;
        currentDecision = null;
        currentBca = null;
        currentOM = null;
        linkActeAdministratfi.setText("Sélectionnez l'acte administratif ...");
        chargerUI();
        initEngagementUI();
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }

    private void continuerAvecActes() {
        if (rdbBonCommande.isSelected()) {
            currentBca = (Bca) ((DefaultListModel) jListeActes.getModel()).elementAt(jListeActes.getSelectedIndex());//       cboReference.getSelectedItem();
            if (currentBca != null) {
                linkActeAdministratfi.setText("BCA:  " + currentBca.getReference());
            }else {
                GrecoOptionPane.showWarningDialog("Aucun BCA n'a ete selectionnee");
                return;
            }
            currentOM = null;
            currentDecision = null;

        } else if (rdbOrdreMission.isSelected()) {
            currentOM = (OrdreMission) ((DefaultListModel) jListeActes.getModel()).elementAt(jListeActes.getSelectedIndex());
            if (currentOM != null) {
                linkActeAdministratfi.setText("OM:  " + currentOM.getMotif());
            }else {
                GrecoOptionPane.showWarningDialog("Aucun ordre de mission n'a ete selectionnee");
                return;
            }
            currentBca = null;
            currentDecision = null;

        } else if (rdbDecision.isSelected()) {
            currentDecision = (Decision) ((DefaultListModel) jListeActes.getModel()).elementAt(jListeActes.getSelectedIndex());
            if (currentDecision != null) {
                linkActeAdministratfi.setText("Décision:   " + currentDecision.getReference());
            }else {
                GrecoOptionPane.showWarningDialog("Aucune decision n'a ete selectionnee");
                return;
            }
            currentBca = null;
            currentOM = null;

        } else {
            currentDecision = null;
            currentBca = null;
            currentOM = null;
            linkActeAdministratfi.setText("Sélectionnez l'acte administratif ...");
        }
        chargerUI();
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }

    private void ordonnateurCompFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_ordonnateurCompFocusLost
        // TODO add your handling code here:
        if (ordonnateurComp.getNomComplet() != null) {
            if (!ordonnateurComp.getNomComplet().isEmpty()) {
                txtSignataire.setText(ordonnateurComp.getNomComplet());
            }
        }
    }//GEN-LAST:event_ordonnateurCompFocusLost

    private void btnObjetSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnObjetSaveActionPerformed
        // TODO add your handling code here:
        if (txtReference.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir la référence juridique de l'engagement");
            return;
        }

        if (txtObjet.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir l'objet de l'engagement ");
            return;
        }
        if (dtpDateSignature.getDate() == null) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir la date de signature de l'engagement ");
            return;
        }
        if (txtSignataire.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir le nom du signataire de l'engagement ");
            return;
        }
        loadObjetcomponent();
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnObjetSaveActionPerformed

    private void btnBenefSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnBenefSaveActionPerformed
        // TODO add your handling code here:
        //control beneficiare
        if (rdbAgent.isSelected()) {
            if (agentComp.getMatricule().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Veuillez saisir le matricule de l'agent bénéficiaire ");
                return;
            }
        }
        if (rdbFournisseur.isSelected()) {
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            if (f == null) {
                JOptionPane.showMessageDialog(null, "Veuillez sélectionner le fournisseur ");
                return;
            }
        }
        if (rdbStructure.isSelected()) {
            Structure s = (Structure) cboStructure.getSelectedItem();
            if (s == null) {
                JOptionPane.showMessageDialog(null, "Veuillez sélectionner la structure bénéficiare ");
                return;
            }
        }
        if (rdbAutre.isSelected()) {
            if (txtBenefAutre.getText().isEmpty()) {
                JOptionPane.showMessageDialog(null, "Veuillez saisir le libellé du bénéficiare ");
                return;
            }
        }
        loadObjetcomponent();
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
    }//GEN-LAST:event_btnBenefSaveActionPerformed

    private void btnCoutSaveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCoutSaveActionPerformed
        // TODO add your handling code here:
        if (txtMontant.getText().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Veuillez saisir le montant de l'engagement ");
            return;
        }
        afficherCout();
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "dossier");
//        setDisablePanelCout(false);
    }//GEN-LAST:event_btnCoutSaveActionPerformed

    private void txtMontantFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtMontantFocusLost
        // TODO add your handling code here:
        calculerNAP();
    }//GEN-LAST:event_txtMontantFocusLost

    private void calculerNAP() {
        Number ttc;
        if (txtMontant.getValue() == null) {
            ttc = new Long(0);
        } else {
            ttc = (Number) txtMontant.getValue();
        }
        long taxe = 0;
        //si la liste des retenues existe, recalculer les montants
        if (listRetenues.size() > 0) {
            List<LiquidationDroits> l = new ArrayList<>();
            for (LiquidationDroits d : listRetenues) {
                double t = d.getTaux();
                double m = t * ttc.doubleValue() / 100;
                d.setMontant(new BigDecimal(m));
                l.add(d);
            }
            listRetenues.clear();
            for (LiquidationDroits e : l) {
                listRetenues.add(e);
            }
        }
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (LiquidationDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
        long nap = ttc.longValue() - taxe;
        txtNAP.setValue(nap);
    }

    private void getRetenue() {

        long taxe = 0;
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (LiquidationDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
    }
    private void btnApercuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApercuActionPerformed
        // TODO add your handling code here:
        if (rdbBonCommande.isSelected()) {
            Bca b = (Bca) ((DefaultListModel) jListeActes.getModel()).elementAt(jListeActes.getSelectedIndex()); //     cboReference.getSelectedItem();
            if (b != null) {
                imprimerBCA(b);
            }
        } else if (rdbOrdreMission.isSelected()) {
            OrdreMission om = (OrdreMission) ((DefaultListModel) jListeActes.getModel()).elementAt(jListeActes.getSelectedIndex()); //cboReference.getSelectedItem();
            if (om != null) {
                imprimerOM(om);
            }
        } else if (rdbDecision.isSelected()) {
            Decision d = (Decision) ((DefaultListModel) jListeActes.getModel()).elementAt(jListeActes.getSelectedIndex()); //cboReference.getSelectedItem();
            if (d != null) {
                imprimerDecision(d);
            }
        } else {
            Toolkit.getDefaultToolkit().beep();
        }

    }//GEN-LAST:event_btnApercuActionPerformed

    private void tableTaxesKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_tableTaxesKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_DELETE) {
            if (selectedRetenue != null) {
                //recupérer la liste existante des rubriques
                List<LiquidationDroits> l = new ArrayList<>();
                for (LiquidationDroits eg : listRetenues) {
                    l.add(eg);
                }
                //supprimmer la rubrique selectionne
                for (LiquidationDroits retenues : l) {
                    if (retenues.getDroitID().equalsIgnoreCase(selectedRetenue.getDroitID())) {
                        l.remove(retenues);
                        break;
                    }
                }
                // recharger la liste dans le tableau par binding
                listRetenues.clear();
                for (LiquidationDroits g : l) {
                    listRetenues.add(g);
                }
            }
        }

        calculerNAP();
    }//GEN-LAST:event_tableTaxesKeyReleased

    private void txtMontantKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtMontantKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            //calculerNAP();
            txtMontantFocusLost(null);
        }
    }//GEN-LAST:event_txtMontantKeyReleased

    private void panelDetailsFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_panelDetailsFocusLost
        // TODO add your handling code here:
        if (rdbBonCommande.isSelected()) {
            initBCACout();
        }
    }//GEN-LAST:event_panelDetailsFocusLost

    private void rdbLettreCommandeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbLettreCommandeActionPerformed
        // TODO add your handling code here:
        loadJList(null);
    }//GEN-LAST:event_rdbLettreCommandeActionPerformed

    private void rdbMarcheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbMarcheActionPerformed
        // TODO add your handling code here:
        loadJList(null);
    }//GEN-LAST:event_rdbMarcheActionPerformed

    private void cboImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboImputationActionPerformed
        // TODO add your handling code here:
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op != null) {
            BigDecimal montant = GrecoServiceFactory.getOperationService().getDisponible(op);
            txtDisponible.setValue(montant);
        }
    }//GEN-LAST:event_cboImputationActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        enregistrer();
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        supprimer();
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAddEngagementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddEngagementActionPerformed
        // TODO add your handling code here:
        currentEngagement = null;
        initEngagementUI();
    }//GEN-LAST:event_btnAddEngagementActionPerformed

    private void btnContinuerActeSelectedActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnContinuerActeSelectedActionPerformed
        // TODO add your handling code here:
        continuerAvecActes();
    }//GEN-LAST:event_btnContinuerActeSelectedActionPerformed

    private void rdbAutreActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbAutreActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbAutreActionPerformed

    private void btnFournisseurAfficherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFournisseurAfficherActionPerformed
        // TODO add your handling code here:
        Fournisseur f =  (Fournisseur) cboFournisseur.getSelectedItem();
        if(f != null){
            FournisseurNewDialog dialog = new FournisseurNewDialog(me, true, f);
            dialog.setVisible(true);
            //recharger les comptes bancaires du fournisseur
            
        }
    }//GEN-LAST:event_btnFournisseurAfficherActionPerformed

    private void btnCoutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCoutActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "cout");
    }//GEN-LAST:event_btnCoutActionPerformed

    private void supprimer() {
        if (currentEngagement != null) {
            String numDossier = currentEngagement.getNumDossier();
            int rs = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir supprimer cet engagement ? \n\n Dossier N° " + numDossier + " (" + currentEngagement.getBeneficiaire() + ")",
                    "GRECO-SUPRRESION", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
            if (rs == JOptionPane.YES_OPTION) {
                glasspane.attente();
                try {
                    GrecoServiceFactory.getEngagementService().supprimer(currentEngagement.getEngagementID(),
                            GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    GrecoSession.notifications.success();
                    currentEngagement = null;
                    initEngagementUI();
                    JOptionPane.showMessageDialog(this, "Engagement N° " + numDossier + " supprimé");
                    glasspane.arret();
                    this.dispose();
                } catch (Exception e) {
                    glasspane.arret();
                }
            }
        }
    }

    private void chargerUI() {

        if (rdbBonCommande.isSelected()) {
            initBCAUI();
            disableBenef();
            rdbFournisseur.setEnabled(true);
            cboFournisseur.setEnabled(true);
        } else if (rdbOrdreMission.isSelected()) {
            initOMUI();
            disableBenef();
            rdbAgent.setEnabled(true);
            agentComp.setEnabled(true);
        } else if (rdbDecision.isSelected()) {
            initDecisionUI();
            enableComponents();
        } else if (rdbLettreCommande.isSelected()) {
            disableBenef();
            rdbFournisseur.setEnabled(true);
            cboFournisseur.setEnabled(true);
        } else if (rdbMarche.isSelected()) {
            disableBenef();
            rdbFournisseur.setEnabled(true);
            cboFournisseur.setEnabled(true);
        } else {
            enableComponents();
        }

    }

    private void disableComponents() {
        txtReference.setEnabled(false);
        if (!txtObjet.getText().isEmpty()) {
            txtObjet.setEnabled(false);
        }

        if (dtpDateSignature.getDate() != null) {
            dtpDateSignature.setEnabled(false);
        }

        txtSignataire.setEnabled(false);
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);
        txtMontant.setEnabled(false);

        agentComp.setEnabled(false);
        cboFournisseur.setEnabled(false);
        cboStructure.setEnabled(false);
        txtBenefAutre.setEnabled(false);
        rdbAgent.setEnabled(false);
        rdbAutre.setEnabled(false);
        rdbFournisseur.setEnabled(false);
        rdbStructure.setEnabled(false);
    }

    private void disabledBenef() {
        agentComp.setEnabled(false);
        cboFournisseur.setEnabled(false);
        cboStructure.setEnabled(false);
        txtBenefAutre.setEnabled(false);
        rdbAgent.setEnabled(false);
        rdbAutre.setEnabled(false);
        rdbFournisseur.setEnabled(false);
        rdbStructure.setEnabled(false);
    }

    private void enableComponents() {
        txtReference.setEnabled(true);
        txtObjet.setEnabled(true);
        dtpDateSignature.setEnabled(true);
        txtSignataire.setEnabled(true);
        agentComp.setEnabled(true);
        cboFournisseur.setEnabled(true);
        cboStructure.setEnabled(true);
        txtBenefAutre.setEnabled(true);
        cboStructureImputation.setEnabled(true);
        cboTache.setEnabled(true);
        cboImputation.setEnabled(true);
        txtMontant.setEnabled(true);

        rdbAgent.setEnabled(true);
        rdbAutre.setEnabled(true);
        rdbFournisseur.setEnabled(true);
        rdbStructure.setEnabled(true);
    }

    private void loadObjetcomponent() {
        panelObjet.setObjet(txtObjet.getText().trim());
        panelObjet.setReference(txtReference.getText().trim());
        try {
            panelObjet.setDatesignature(dtpDateSignature.getDate());
        } catch (Exception e) {
            panelObjet.setDatesignature(null);
        }
        if (rdbAgent.isSelected()) {
            btnBeneficiare.setText("[" + agentComp.getMatricule() + "] " + agentComp.getNomComplet());
        } else if (rdbFournisseur.isSelected()) {
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            btnBeneficiare.setText(f.getNumContribuable() + " - " + f.getRaisonSociale());
        } else if (rdbStructure.isSelected()) {
            Structure s = (Structure) cboStructure.getSelectedItem();
            btnBeneficiare.setText(s.getLibelle());
        } else if (rdbAutre.isSelected()) {
            btnBeneficiare.setText(txtBenefAutre.getText().trim());
        }
        //appeler une fonction pour calculer le nap et les retenues
        afficherCout();
    }

    private void afficherCout() {
//        try {
//            btnTTC.setText(txtMontant.getText());
//        } catch (Exception e) {
//        }
//        try {
//            btnNAP.setText(txtNAP.getText());
//        } catch (Exception e) {
//        }
//        try {
//            btnTaxes.setText(txtRetenues.getText());
//        } catch (Exception e) {
//        }

    }

    private void initBCAUI() {
        glasspane.attente();
        
        panelMission.setVisible(false);
        
        if (currentBca != null) {
            try {
                txtReference.setText(currentBca.getReference());
                dtpDateSignature.setDate(currentBca.getDateSignature());
                txtObjet.setText(currentBca.getObjet());
                try {
                    Agent a = GrecoServiceFactory.getAgentService().getAgent(currentBca.getMatriculeOrdo());
                    txtSignataire.setText(a.getNomComplet());
                    agentComp.setMatricule(currentBca.getMatriculeOrdo());
                } catch (Exception e) {
                }

                txtMontant.setValue(currentBca.getMontantTTC());
                if (currentBca.getFournisseurID() != null && !currentBca.getFournisseurID().isEmpty()) {
                    for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                        Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                        if (f.getFournisseurID().equalsIgnoreCase(currentBca.getFournisseurID())) {
                            cboFournisseur.setSelectedIndex(i);
                            break;
                        }
                    }
                    rdbFournisseur.setSelected(true);
                    cboStructure.setSelectedIndex(-1);
                    agentComp.setMatricule(null);
                    txtBenefAutre.setText("");
                }
                for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
                    Structure s = (Structure) cboStructureImputation.getItemAt(i);
                    if (s.getStructureID().equalsIgnoreCase(currentBca.getStructureID())) {
                        cboStructureImputation.setSelectedIndex(i);
                        break;
                    }
                }

                for (int i = 0; i < cboTache.getItemCount(); i++) {
                    Activite f = (Activite) cboTache.getItemAt(i);
                    if (f.getActiviteID().equalsIgnoreCase(currentBca.getActiviteID())) {
                        cboTache.setSelectedIndex(i);
                        break;
                    }
                }
                for (int i = 0; i < cboImputation.getItemCount(); i++) {
                    OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                    if (f.getTacheID().equalsIgnoreCase(currentBca.getTacheID())) {
                        cboImputation.setSelectedIndex(i);
                        break;
                    }
                }
                
                loadObjetcomponent();

                //chargement de la facture
                panelDetails.removeAll();
                MercurialeComponent listeArticlePanel = new MercurialeComponent();
                listeArticlePanel.setMillesime(currentBca.getMillesime());
                listeArticlePanel.setModePresentation(MercurialeMode.MODE_FACTURE);
                listeArticlePanel.setTauxTVA(currentBca.getTauxTVA());
                listeArticlePanel.setTauxIR(currentBca.getTauxIR());
                listeArticlePanel.setReference(currentBca.getReference());
                listeArticlePanel.setObjet(currentBca.getObjet());

                List<Article> arts = new ArrayList<Article>();
                arts = GrecoServiceFactory.getBonCommandeService().getArticleLignes(currentBca.getBcaID());

                listeArticlePanel.setListArticleMercuriale(arts);
                panelDetails.add(listeArticlePanel);
                
                tabbedPane.add("Facture ", panelDetails);

            } catch (Exception e) {
            }
        }
        glasspane.arret();
    }

    private void initBCACout() {
        try {
            //affichage des couts du BCA
            txtMontant.setValue(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantTTC()));
            LiquidationDroits ir = new LiquidationDroits();
            LiquidationDroits tva = new LiquidationDroits();
            List<Droits> dir = GrecoServiceFactory.getDroitsService().listeDroits();
            //TVA
            for (Droits droits : dir) {
                if (droits.isTVA()) {
                    tva.setDroitID(droits.getDroitID());
                    tva.setLibelleFr(droits.getLibelleFr());
                    tva.setLibelleUs(droits.getLibelleUs());
                    tva.setSigleFr(droits.getSigleFr());
                    tva.setSigleUs(droits.getSigleUs());
                    tva.setTaux((float) bcaFacture.getTauxTVA() * 100);
                    tva.setMontant(BigDecimal.valueOf(Math.round(bcaFacture.getLignesFacture().getMontantTVA())));
                    break;
                }
            }
            //IR
            for (Droits droits : dir) {
                if (droits.isIR()) {
                    ir.setDroitID(droits.getDroitID());
                    ir.setLibelleFr(droits.getLibelleFr());
                    ir.setLibelleUs(droits.getLibelleUs());
                    ir.setSigleFr(droits.getSigleFr());
                    ir.setSigleUs(droits.getSigleUs());
                    ir.setTaux((float) bcaFacture.getTauxIR() * 100);
                    ir.setMontant(BigDecimal.valueOf(Math.round(bcaFacture.getLignesFacture().getMontantIR())));
                    break;
                }
            }
            listRetenues.clear();
            listRetenues.add(tva);
            listRetenues.add(ir);
            getRetenue();
            txtNAP.setValue(BigDecimal.valueOf(Math.round(bcaFacture.getLignesFacture().getMontantNetAPayer())));
//        setDisablePanelCout(false);
            afficherCout();
        } catch (Exception e) {
            glasspane.arret();
        }

    }

    private void initOMUI() {
        if (currentOM != null) {
            txtReference.setText(currentOM.getMotif());
            txtObjet.setText(currentOM.getMotifReference());
            try {
                Agent a = GrecoServiceFactory.getAgentService().getAgent(ordonnateurComp.getMatricule());
                txtSignataire.setText(a.getNomComplet());
            } catch (Exception e) {
            }
            if (currentOM.getMatricule() != null && !currentOM.getMatricule().isEmpty()) {
                agentComp.setMatricule(currentOM.getMatricule());
                rdbAgent.setSelected(true);
                cboStructure.setSelectedIndex(-1);
                cboFournisseur.setSelectedIndex(-1);
                txtBenefAutre.setText("");
            }

            txtMontant.setValue(new BigDecimal(0));

            for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
                Structure s = (Structure) cboStructureImputation.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentOM.getStructureID())) {
                    cboStructureImputation.setSelectedIndex(i);
                    break;
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentOM.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentOM.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            loadObjetcomponent();
        }
    }

    private void loadBCA() {
        List<Bca> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getBonCommandeService().getBCAByOrganisationNotUsed(exercice.getMillesime(), organisation.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        loadJList(list);

    }

    private void loadJList(List list) {
        DefaultListModel lm = new DefaultListModel();
        btnContinuerActeSelected.setVisible(false);
        if (list != null && !list.isEmpty()) {
            for (Object o : list) {
                lm.addElement(o);
            }
            btnContinuerActeSelected.setVisible(true);
        }
        jListeActes.removeAll();
        jListeActes.setModel(lm);
        lblResult.setText(""+lm.size()+" resultat(s) trouve(s)");
    }

    private void loadOM() {
        List<OrdreMission> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getOrdreMissionService().getOMByOrganisation(exercice.getMillesime(), organisation.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        loadJList(list);
    }

    private void loadDecision() {
        List<Decision> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getDecisionService().getDecisionByOrganisation(exercice.getMillesime(), organisation.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        loadJList(list);
    }

    private void disableBenef() {
        agentComp.setEnabled(false);
        cboFournisseur.setEnabled(false);
        cboStructure.setEnabled(false);
        txtBenefAutre.setEnabled(false);
        txtBenefAutre.setText("");
    }

    private void imprimerFicheEngagement(String engagementID, String numDossier) {

        VueEngagementLivre vuedossier = new VueEngagementLivre();
        vuedossier = GrecoServiceFactory.getEngagementService().getFicheDossier(numDossier);
        //impression de la fiche
        if (vuedossier != null) {
            GrecoImages logo = new GrecoImages();
            Image armoirieCM = null;//new siiResources.Images();
            HashMap parameters = fonctions.mainParameters();
            parameters.put("armoirieCM", armoirieCM);
            parameters.put("logo", logo.logoOrganisation());
            parameters.put("app", logo.logo());
            parameters.put("montantLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, vuedossier.getMontant()));
            parameters.put("user", GrecoSession.USER_CONNECTED.getNom());
            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

            //datasource principale
            List<VueEngagementLivre> list = new ArrayList<>();
            list.add(vuedossier);
            JRDataSource dataSource = new JRBeanCollectionDataSource(list);

            //datasource du sous etat
            List<LiquidationDroits> listSousEtat = new ArrayList<>();
            listSousEtat = null; //GrecoServiceFactory.getDroitsService().listeDroitsEngagement(engagementID);
            JRDataSource dataSourcesousEtat = new JRBeanCollectionDataSource(listSousEtat);

            //passage des parametres du sousetat
            parameters.put("sousetat", fonctions.ficheEngagementDroits());
            parameters.put("jrds", dataSourcesousEtat);

            //impression de la fiche
            try {
                JasperPrint print = JasperFillManager.fillReport(fonctions.ficheEngagement(), parameters, dataSource);
                JRHelper.viewReport(print);
            } catch (Exception e) {
                e.printStackTrace();
            }
            glasspane.arret();
        }

    }

    private void imprimerBCA(final Bca b) {
//        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        glasspane.attente();
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueBCAReport> list = new ArrayList<>();
                            list = GrecoServiceFactory.getReportService().getBcaLignesReport(b.getBcaID());

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("logoEntete", mesImages.logoOrganisation());
                            parameters.put("user", GrecoSession.USER_CONNECTED.getLogin() + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("montantEnLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, b.getMontantTTC()) + "  francs CFA");
                            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
                            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

                            glasspane.setText("2/2 Rendu");
                            JRHelper.viewReport(fonctions.bonCommandeAdministratif(), parameters, new JRBeanCollectionDataSource(list), null, null);

                        } catch (Exception ex) {
                            glasspane.arret();
                        }
                        glasspane.arret();
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void imprimerOM(final OrdreMission b) {
        glasspane.attente();
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueOMReport> list = new ArrayList<>();
                            list.add(GrecoServiceFactory.getReportService().getOM(b.getOmID()));

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("entete", mesImages.logoOrganisation());
                            parameters.put("user", GrecoSession.USER_CONNECTED.getLogin() + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("controleur", "LE CONTROLEUR FINANCIER");
                            parameters.put("comptable", "L'AGENT COMPTABLE");
                            glasspane.setText("2/2 Rendu");
//                            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitle());
//                            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

                            JRHelper.viewReport(fonctions.ordreMisssion(), parameters, new JRBeanCollectionDataSource(list), null, null);

                        } catch (Exception ex) {
                            glasspane.arret();
                        }
                        glasspane.arret();
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void imprimerDecision(Decision d) {
//         Decision d = GrecoServiceFactory.getDecisionService().getDecision(currentDecision.getDecisionID());
        final DecisionModele modele = GrecoServiceFactory.getDecisionService().getModele(d.getModeleID());
        String contenu = modele.getContenu();
        contenu = contenu.replace("@@reference@@", d.getReference());
        contenu = contenu.replace("@@millesime@@", d.getMillesime());
        contenu = contenu.replace("@@BUDGET@@", d.getBudget());
        contenu = contenu.replace("@@ORGANISATION@@", d.getOrganisationLibelle());
        contenu = contenu.replace("@@beneficiaire@@", d.getBeneficiaire());
        contenu = contenu.replace("@@montant@@", d.getMontant().toString());
        contenu = contenu.replace("@@montantEnLettre@@", StringUtil.getMontantEnLettre(Locale.FRENCH, d.getMontant()));
        contenu = contenu.replace("@@imputation@@", d.getImputation());
        try {
            contenu = contenu.replace("@@objet@@", d.getObjet());
        } catch (Exception e) {
        }
        try {
            contenu = contenu.replace("@@signataire@@", d.getSignataire());
        } catch (Exception e) {
        }

        final String texte = contenu;
        //impression
        glasspane.attente();
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = new HashMap();
                            parameters.put("entete1Fr", modele.getEntete1Fr());
                            parameters.put("entete2Fr", modele.getEntete2Fr());
                            parameters.put("entete3Fr", modele.getEntete3Fr());
                            parameters.put("entete4Fr", modele.getEntete4Fr());
                            parameters.put("entete5Fr", modele.getEntete5Fr());

                            parameters.put("entete1Us", modele.getEntete1Us());
                            parameters.put("entete2Us", modele.getEntete2Us());
                            parameters.put("entete3Us", modele.getEntete3Us());
                            parameters.put("entete4Us", modele.getEntete4Us());
                            parameters.put("entete5Us", modele.getEntete5Us());

                            parameters.put("texte", texte);
                            //parameter.put("apercu","Apercu-Copie")
                            glasspane.setText("2/2 Rendu ");
                            JRHelper.viewReport(fonctions.apercu(), parameters, null, null, null);

                        } catch (Exception ex) {
                            glasspane.arret();
                        }
                        glasspane.arret();
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    public List<LiquidationDroits> getListRetenues() {
        return listRetenues;
    }

    public void setListRetenues(List<LiquidationDroits> listRetenues) {
        this.listRetenues = listRetenues;
    }

    public LiquidationDroits getSelectedRetenue() {
        return selectedRetenue;
    }

    public void setSelectedRetenue(LiquidationDroits selectedRetenue) {
        this.selectedRetenue = selectedRetenue;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EngagementDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EngagementDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EngagementDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EngagementDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new EngagementDialog(null, true, null, null, null).setVisible(true);
            }
        });
    }

    private void setDisablePanelCout(boolean value) {
        txtMontant.setEnabled(value);
        tableTaxes.setEnabled(value);
        btnAddRetenue.setVisible(value);
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.ButtonGroup benefGroup;
    private cm.eusoworks.tools.ui.GButton btnActeAdministratifRetour;
    private cm.eusoworks.tools.ui.GButton btnActeAdministratifSave;
    private cm.eusoworks.tools.ui.GButton btnAddEngagement;
    private cm.eusoworks.tools.ui.GButton btnAddRetenue;
    private cm.eusoworks.tools.ui.GButton btnApercu;
    private cm.eusoworks.tools.ui.GButton btnBenefRetour;
    private cm.eusoworks.tools.ui.GButton btnBenefSave;
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnContinuerActeSelected;
    private javax.swing.JButton btnCout;
    private cm.eusoworks.tools.ui.GButton btnCoutRetour;
    private cm.eusoworks.tools.ui.GButton btnCoutSave;
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnFournisseurAfficher;
    private cm.eusoworks.tools.ui.GButton btnObjetRetour;
    private cm.eusoworks.tools.ui.GButton btnObjetSave;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private javax.swing.JComboBox cboFournisseur;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox<String> cboRIB;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboStructureImputation;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JCheckBox chkMissionEffectue;
    private javax.swing.JCheckBox chkMissionType;
    private org.jdesktop.swingx.JXDatePicker dtpDateSignature;
    private org.jdesktop.swingx.JXDatePicker dtpMissionArrivee;
    private org.jdesktop.swingx.JXDatePicker dtpMissionDepart;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList<String> jListeActes;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JLabel lblNbreJours;
    private javax.swing.JLabel lblResult;
    private org.jdesktop.swingx.JXHyperlink linkActeAdministratfi;
    private cm.eusoworks.component.AgentComponent ordonnateurComp;
    private javax.swing.JPanel pDetailDecision;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel panelActeAdministratif;
    private javax.swing.JPanel panelBenef;
    private javax.swing.JPanel panelDetails;
    private javax.swing.JPanel panelInfos;
    private javax.swing.JPanel panelMission;
    private cm.eusoworks.tools.ui.GPanelInfo panelObjet;
    private javax.swing.JPanel panelReference;
    private javax.swing.JPanel panelTaxes;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JRadioButton rdbAgent;
    private javax.swing.JRadioButton rdbAutre;
    private javax.swing.JRadioButton rdbBonCommande;
    private javax.swing.JRadioButton rdbDecision;
    private javax.swing.JRadioButton rdbFournisseur;
    private javax.swing.JRadioButton rdbLettreCommande;
    private javax.swing.JRadioButton rdbMarche;
    private javax.swing.JRadioButton rdbOrdreMission;
    private javax.swing.JRadioButton rdbStructure;
    private javax.swing.JScrollPane scrollActes;
    private javax.swing.JTabbedPane tabbedPane;
    private org.jdesktop.swingx.JXTable tableTaxes;
    private javax.swing.JTextField txtBenefAutre;
    private javax.swing.JFormattedTextField txtDisponible;
    private javax.swing.JTextField txtMissionItineraire;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtNAP;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtRetenues;
    private javax.swing.JTextField txtSignataire;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
