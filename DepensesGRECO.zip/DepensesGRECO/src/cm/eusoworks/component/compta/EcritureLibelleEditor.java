/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.component.compta;

import cm.eusoworks.context.GrecoSession;
import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Date;
import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableCellEditor;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author macbook
 */
public class EcritureLibelleEditor extends AbstractCellEditor implements TableCellEditor, KeyListener {

    private JTextField txtLibelle = new JTextField();

    public EcritureLibelleEditor() {
        txtLibelle.addKeyListener(this);
    }

    @Override
    public Object getCellEditorValue() {
        return txtLibelle.getText();
    }

    @Override
    public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected, int row, int column) {
        txtLibelle.setText((String) value);
        return txtLibelle;
    }

    @Override
    public void keyTyped(KeyEvent e) {
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyPressed(KeyEvent e) {
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_F10) {
            String s = null;
            s = GrecoSession.getComptaLibelle(txtLibelle.getText().trim());
            if (s != null && !s.isEmpty()) {
                txtLibelle.setText(s);
            }
        }
    }

}
