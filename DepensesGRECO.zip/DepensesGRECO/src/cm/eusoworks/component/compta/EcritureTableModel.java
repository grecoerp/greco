/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.component.compta;

import cm.eusoworks.entities.model.Axe;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.Ecritures;
import cm.eusoworks.entities.model.Journaux;
import cm.eusoworks.ui.budgeting.EngagementPriseEnChargeDialog;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author jeanemmanuel
 */
public class EcritureTableModel extends AbstractTableModel {

    private int mode = 1;
    private String organisationID;
    private String millesime;
    private String budgetID;

    private List<Ecritures> dataList = new ArrayList<>();
    private final String[] columNames = {"Journal", "Date op.", "Compte", "Libelle de l'ecriture", "Debit", "Credit", "Pieces", "Analytique"};
    boolean[] canEdit = new boolean[]{true, true, true, true, true, true, true, true};
    BigDecimal sommeDebit = BigDecimal.ZERO;
    BigDecimal sommeCredit = BigDecimal.ZERO;
    int modeouverture;
    private boolean blockUpdate = false;

    EngagementPriseEnChargeDialog dialog;

    public EcritureTableModel(EngagementPriseEnChargeDialog frame, int mode) {
        this.mode = mode;
        this.dialog = frame;
        dataList.add(new Ecritures());
    }

    public void setMode(int m) {
        this.mode = m;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(blockUpdate) return false;
        else return canEdit[columnIndex];
    }

    @Override
    public int getRowCount() {
        return dataList == null ? 0 : dataList.size();
    }

    @Override
    public int getColumnCount() {
        return columNames.length;
    }

    @Override
    public String getColumnName(int col) {
        return columNames[col];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Ecritures a = dataList.get(rowIndex);
        Object ob = null;
        switch (columnIndex) {
            case 0:
                ob = a.getJournalID();
                break;
            case 1:
                ob = a.getDateOperation();
                break;
            case 2:
                ob = a.getCompte();
                break;
            case 3:
                ob = a.getLibelle();
                break;
            case 4:
                ob = a.getDebit() == null ? BigDecimal.ZERO : a.getDebit();
                break;
            case 5:
                ob = a.getCredit() == null ? BigDecimal.ZERO : a.getCredit();
                break;
            case 6:
                ob = a.getPieces();
                break;
            case 7:
                ob = a.getAxeID();
                break;
        }
        return ob;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 4) {
            return BigDecimal.class;
        } else if (columnIndex == 5) {
            return BigDecimal.class;
        } else {
            return String.class;
        }
    }

    @Override
    public void setValueAt(Object value, int row, int col) {
        Ecritures a = dataList.get(row);
        String ref = value == null ? null : value.toString();
        switch (col) {
            case 0:
                a.setJournalID(((Journaux) value).getJournalID());
                //si c'est la derniere ligne, ajouter une ligne dans le tableau
                if (row == dataList.size() - 1) {
                    Ecritures art = new Ecritures(((Journaux) value).getJournalID(), (Date) getValueAt(row, 1), (String) getValueAt(row, 3));
                    addArticle(art);
                }
                break;
            case 1:
                a.setDateOperation(value == null ? new Date() : (Date) value);
                break;
            case 2:
                a.setCompte(value == null ? "" : ((Compte) value).getCode());
                break;
            case 3:
                a.setLibelle(value == null ? "" : value.toString());
                break;
            case 4:
                if (value == null) {
                    a.setDebit(BigDecimal.ZERO);
                } else {
                    BigDecimal d = (BigDecimal) value;
                    a.setDebit(d);
                    if (d.compareTo(BigDecimal.ZERO) == 1) {
                        a.setCredit(BigDecimal.ZERO);
                    }
                }
                calculerSomme();
                break;
            case 5:
                if (value == null) {
                    a.setCredit(BigDecimal.ZERO);
                } else {
                    BigDecimal d = (BigDecimal) value;
                    a.setCredit(d);
                    if (d.compareTo(BigDecimal.ZERO) == 1) {
                        a.setDebit(BigDecimal.ZERO);
                    }
                }
                calculerSomme();
                break;
            case 6:
                a.setPieces(value == null ? "" : value.toString());
                break;
            case 7:
                a.setAxeID(value == null ? "" : ((Axe) value).getAxeID());
                break;
//                fireTableCellUpdated(row, col);

        }
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getBudgetID() {
        return budgetID;
    }

    public void setBudgetID(String budgetID) {
        this.budgetID = budgetID;
    }

    public void addArticle(Ecritures article) {
        // supprimer la derniere ligne si elle est vide
        int lastIndex = dataList.size() - 1;
        if (lastIndex >= 0) {
            Ecritures a = dataList.get(dataList.size() - 1);
            if (a.getJournalID() == null) {
                dataList.remove(lastIndex);
                fireTableRowsDeleted(lastIndex, lastIndex);
            }
        }
        // ajouter la nouvelle ligne
        dataList.add(article);
        fireTableRowsInserted(dataList.size() - 1, dataList.size() - 1);
        calculerSomme();

    }

    public void removeArticle(int rowIndex) {
        dataList.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
        calculerSomme();
    }

    public void resetModel() {
        int s = dataList.size();
        dataList.clear();
//        fireTableRowsDeleted(0, s);
        addArticle(new Ecritures());
        calculerSomme();
    }

    public Ecritures getArticleAt(int index) {
        return dataList.get(index);
    }

    public void calculerSomme() {
        sommeDebit = BigDecimal.ZERO;
        sommeCredit = BigDecimal.ZERO;
        for (Ecritures a : dataList) {
            if (a != null) {
//                if (a.getEcritureID() != null) {
                if (a.getDebit() != null) {
                    sommeDebit = sommeDebit.add(a.getDebit());
                    sommeCredit = sommeCredit.add(a.getCredit());
                }
//                }
            }
        }
        //mise a jour des totaux
        if(mode == 1) dialog.afficherSommeEcritures(sommeDebit, sommeCredit);
        else dialog.afficherSommeEcrituresPaiement(sommeDebit, sommeCredit);
    }

    public List<Ecritures> getDataList() {
        return dataList;
    }

    public List<Ecritures> getDataListToSave() {
        List<Ecritures> list = new ArrayList<>();
        if (dataList != null) {
            for (Ecritures vt : dataList) {
                if (vt != null && vt.getLibelle()!=null) {
                    if (vt.getDebit().compareTo(BigDecimal.ZERO) != 0 || vt.getCredit().compareTo(BigDecimal.ZERO) != 0) {
                        list.add(vt);
                    }
                }

            }
        }

        return list;
    }

    public void setDataList(List<Ecritures> data) {
        dataList.clear();
        if (data != null) {
            for (int i = 0; i < data.size(); i++) {
                Ecritures t = data.get(i);
                dataList.add(t);
            }
            dataList.add(new Ecritures());
            calculerSomme();

        }

    }

    public boolean isBlockUpdate() {
        return blockUpdate;
    }

    public void setBlockUpdate(boolean blockUpdate) {
        this.blockUpdate = blockUpdate;
    }

    
}
