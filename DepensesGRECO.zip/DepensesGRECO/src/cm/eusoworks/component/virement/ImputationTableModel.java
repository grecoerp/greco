/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.component.virement;

import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.entities.enumeration.DialogOpenMode;
import cm.eusoworks.entities.model.VirementTache;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.budgeting.VirementDialog;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author jeanemmanuel
 */
public class ImputationTableModel extends AbstractTableModel {

    VirementDialog frame;

    private int mode = 1;
    private String organisationID;
    private String millesime;
    private String budgetID;

    private List<VirementTache> dataList = new ArrayList<>();
    private final String[] columNames = {"IMPUTATION", "PROG.", "ACT.", "DESIGNATION", "DISPONIBLE", "MONTANT"};
    boolean[] canEdit = new boolean[]{true, false, false, false, false, true};
    BigDecimal somme = BigDecimal.ZERO;
    BigDecimal remise = BigDecimal.ZERO;
    int modeouverture;

    public ImputationTableModel(VirementDialog virFrame, int mode, int etatOuverture) {
        this.mode = mode;
        frame = virFrame;
        this.modeouverture = etatOuverture;
        dataList.add(new VirementTache());
    }

    public void setMode(int m) {
        this.mode = m;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        if(modeouverture < 0  || modeouverture > DialogOpenMode.enregistre){
            return false;
        }else {
            return canEdit[columnIndex];
        } 
    }

    @Override
    public int getRowCount() {
        return dataList == null ? 0 : dataList.size();
    }

    @Override
    public int getColumnCount() { 
        return columNames.length;
    }

    @Override
    public String getColumnName(int col) {
        return columNames[col];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        VirementTache a = dataList.get(rowIndex);
        Object ob = null;
        switch (columnIndex) {
            case 0:
                ob = a.getImputation();
                break;
            case 1:
                ob = a.getProgramme() == null ? "" : a.getProgramme();
                break;
            case 2:
                ob = a.getAction() == null ? "" : a.getAction();
                break;
            case 3:
                ob = a.getLibelleFr() == null ? "" : a.getLibelleFr();
                break;
            case 4:
                ob = a.getDisponibleAvant() == null ? BigDecimal.ZERO : a.getDisponibleAvant();
                break;
            case 5:
                ob = a.getMontant() == null ? BigDecimal.ZERO : a.getMontant();
                break;
        }
        return ob;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 4) {
            return BigDecimal.class;
        } else if (columnIndex == 5) {
            return BigDecimal.class;
        } else {
            return String.class;
        }
    }

    @Override
    public void setValueAt(Object value, int row, int col) {
        VirementTache a = dataList.get(row);
        String ref = value == null ? null : value.toString();
        switch (col) {
            case 0:
                //rechercher l'artiche ici et charger la designation et le prix unitaire
                String imputation = ref.replace(" ", "");
                String chap = imputation.substring(2, 4);
                String tache = imputation.substring(4, 10);
                String paragraphe = imputation.substring(10);
                List<VirementTache> list = GrecoServiceFactory.getVirementService().getDisponibleTache(organisationID, millesime,
                        budgetID, chap, tache, paragraphe);

                VirementTache tmp = new VirementTache();

                if (list != null && !list.isEmpty()) {
                    if (list.size() == 1) {
                        tmp = list.get(0);
                    } else {
                        // fenetre pour afficher la liste des taches pour sélection de la bonne
                        ImputationSearchDialog dialog = new ImputationSearchDialog(null, true);
                        dialog.setListImputations(list);
                        dialog.setVisible(true);
                        //dialog.setUndecorated(true);

                        //recuperer l'article selectione et ajouter au tableau
                        tmp = null;
                        tmp = dialog.getSelectedImputation();

                        dialog.dispose();
                    }
                }
                if (tmp != null) {

                    //verifier que la ligne n'existe pas deja
                    for (VirementTache v : dataList) {
                        if (v.getTacheID() == null) {
                            break;
                        }
                        if (v.getTacheID().equalsIgnoreCase(tmp.getTacheID())) {
                            GrecoOptionPane.showErrorDialog("Cette imputation existe déjà dans la liste");
                            return;
                        }
                    }

                    a.setTacheID(tmp.getTacheID());
                    a.setMillesime(tmp.getMillesime());
                    a.setChapitre(tmp.getChapitre());
                    a.setTacheCode(tmp.getTacheCode());
                    a.setParagraphe(tmp.getParagraphe());
                    a.setLibelleFr(tmp.getLibelleFr());
                    a.setProgramme(tmp.getProgramme());
                    a.setAction(tmp.getAction());
                    a.setDisponibleAvant(tmp.getDisponibleAvant());

                    setValueAt(tmp.getProgramme(), row, 1);
                    setValueAt(tmp.getAction(), row, 2);
                    setValueAt(tmp.getLibelleFr(), row, 3);
                    setValueAt(tmp.getDisponibleAvant(), row, 4);

                    //si c'est la derniere ligne, ajouter une ligne dans le tableau
                    if (row == dataList.size() - 1) {
                        VirementTache art = new VirementTache();
                        addArticle(art);
                    }
                }

                break;
            case 1:
                a.setProgramme(value == null ? "" : value.toString());
                break;
            case 2:
                a.setAction(value == null ? "" : value.toString());
                break;
            case 3:
                a.setLibelleFr(value == null ? "" : value.toString());
                break;
            case 4:
                a.setDisponibleAvant(value == null ? BigDecimal.ZERO : (BigDecimal) value);
                break;
            case 5:
                if (value == null || a.getDisponibleAvant() == null) {
                    a.setMontant(BigDecimal.ZERO);
                } else {
                    if (mode == VirementDialog.DEBIT) {
                        Number nd = a.getDisponibleAvant();
                        Number nm = (BigDecimal) value;
                        if (nm.longValue() > nd.longValue()) {
                            value = BigDecimal.ZERO;
                            GrecoOptionPane.showWarningDialog("Le montant a débité saisit est supérieur au disponible. Réessayer SVP");
                        }
                    }
                    a.setMontant((BigDecimal) value);
                    calculerSomme();
                    break;
                }
                fireTableCellUpdated(row, col);

        }
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getBudgetID() {
        return budgetID;
    }

    public void setBudgetID(String budgetID) {
        this.budgetID = budgetID;
    }

    public void addArticle(VirementTache article) {
        // supprimer la derniere ligne si elle est vide
        int lastIndex = dataList.size() - 1;
        if (lastIndex >= 0) {
            VirementTache a = dataList.get(dataList.size() - 1);
            if (a.getTacheID() == null) {
                dataList.remove(lastIndex);
                fireTableRowsDeleted(lastIndex, lastIndex);
            }
        }
        // ajouter la nouvelle ligne
        dataList.add(article);
        fireTableRowsInserted(dataList.size() - 1, dataList.size() - 1);
        calculerSomme();

    }

    public void removeArticle(int rowIndex) {
        dataList.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
        calculerSomme();
    }

    public void resetModel() {
        int s = dataList.size();
        dataList.clear();
//        fireTableRowsDeleted(0, s);
        addArticle(new VirementTache());
        calculerSomme();
    }

    public VirementTache getArticleAt(int index) {
        return dataList.get(index);
    }

    public void calculerSomme() {
        somme = BigDecimal.ZERO;
        for (VirementTache a : dataList) {
            if (a != null) {
                if (a.getTacheID() != null) {
                    if (a.getMontant() != null) {
                        somme = somme.add(a.getMontant());
                    }
                }
            }
        }
        //mise a jour des totaux
        frame.calculTotaux(somme, this.mode);
    }

    public List<VirementTache> getDataList() {
        return dataList;
    }

    public List<VirementTache> getDataListToSave() {
        List<VirementTache> list = new ArrayList<>();
        if (dataList != null) {
            for (VirementTache vt : dataList) {
                if (vt.getTacheID() != null) {
                    if (vt.getMontant() != BigDecimal.ZERO) {
                        if (mode == VirementDialog.DEBIT) {
                            vt.setDebit(vt.getMontant());
                            vt.setCredit(BigDecimal.ZERO);
                        } else if (mode == VirementDialog.CREDIT) {
                            vt.setCredit(vt.getMontant());
                            vt.setDebit(BigDecimal.ZERO);
                        }

                        list.add(vt);
                    }
                }
            }
        }

        return list;
    }

    public void setDataList(List<VirementTache> data) {
        dataList.clear();
        if (data != null) {
            for (int i = 0; i < data.size(); i++) {
                VirementTache t = data.get(i);
//                if(this.mode == VirementDialog.DEBIT){
//                    if(t.getDebit().compareTo(t.getDisponibleAvant())  == 1){
//                        t.setDebit(t.getDisponibleAvant());
//                        t.setMontant(t.getDisponibleAvant());
//                    }
//                }
                addArticle(t);
            }
            addArticle(new VirementTache());
            calculerSomme();
        }

    }

}
