/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.entities.enumeration.DialogOpenMode;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.EngagementTypeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.table.TableColumn;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class LiquidationSearchDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Liquidation> listLiquidations = ObservableCollections.observableList(new ArrayList<Liquidation>());
    Liquidation selectedLiquidation = null;

    GrecoReports fonctions = new GrecoReports();
    int wSearch = 600, hSearch = 300;
    int openMode = DialogOpenMode.enregistre;
//    private CurvesProgressPanel glasspane;

    public LiquidationSearchDialog(java.awt.Frame parent, boolean modal, int mode) {
        super(parent, modal);
        initComponents();
        setSize(780, 550);
        this.openMode = mode;
        initMode();
        glasspane.setText("Recherche des liquidations validees correspondant aux critères ...");
//        this.setGlassPane(glasspane);
        loadOrganisations();
        loadExercicesBudgetisation();
        loadTypeEngagement();
        setLocationRelativeTo(null);

    }

    public List<Liquidation> getListLiquidations() {
        return listLiquidations;
    }

    public void setListLiquidations(List<Liquidation> listLiquidations) {
        this.listLiquidations = listLiquidations;
    }

    public Liquidation getSelectedLiquidation() {
        return selectedLiquidation;
    }

    public void setSelectedLiquidation(Liquidation selectedLiquidation) {
        this.selectedLiquidation = selectedLiquidation;
    }

    private void initMode() {

    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            } else {
                cboExercice.setSelectedIndex(cboExercice.getItemCount() - 1);
            }
        }
    }

    private void loadTypeEngagement() {
        List<EngagementType> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getEngagementService().getEngagementType();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            list.add(null);
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        return true;
    }

    private void search(boolean advanced) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String numdossier = ((String) txtnumDossier.getValue());
        String etat = EtatDossier.getListeEtat(this.openMode);

        glasspane.attente();
        List<Liquidation> l = GrecoServiceFactory.getEngagementService().liquidationByEtatOnly(organisationID, millesime, numdossier, etat);
        listLiquidations.clear();
        if (l != null) {
            lblRecherche.setText(l.size() + " liquidation(s) trouvé(s)");
            for (Liquidation v : l) {
                listLiquidations.add(v);
            }
        } else {
            lblRecherche.setText("aucune liquidation validee trouvée");
        }
        glasspane.arret();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        panelEntete = new javax.swing.JPanel();
        panelExercice = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        txtnumDossier = new javax.swing.JFormattedTextField();
        lblRecherche = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnAction = new cm.eusoworks.tools.ui.GButton();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        panelTable = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableDossiers = new org.jdesktop.swingx.JXTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Recherche d'un dossier ");
        setResizable(false);

        panelEntete.setLayout(new java.awt.CardLayout());

        panelExercice.setBackground(new java.awt.Color(255, 255, 255));
        panelExercice.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 44, 76, 30));

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });
        jPanel2.add(cboExercice, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 193, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("N° de dossier : ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 92, -1, 26));

        try {
            txtnumDossier.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("U########")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtnumDossier.setFont(new java.awt.Font("Arial Black", 0, 16)); // NOI18N
        txtnumDossier.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtnumDossierKeyReleased(evt);
            }
        });
        jPanel2.add(txtnumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(122, 92, 180, -1));

        lblRecherche.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblRecherche.setForeground(new java.awt.Color(91, 118, 173));
        lblRecherche.setText("Résultats de la recherche : ");
        jPanel2.add(lblRecherche, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 272, 342, 20));

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnAction.setText("Mandatements");
        btnAction.setCouleur(2);
        btnAction.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnAction.setStyle(1);
        btnAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionActionPerformed(evt);
            }
        });
        jPanel1.add(btnAction);

        btnRechercher.setText("Rechercher ...");
        btnRechercher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnRechercher.setStyle(3);
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });
        jPanel1.add(btnRechercher);

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 440, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 19, 92, -1));

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        jPanel2.add(cboOrganisation, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 18, 629, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgannulationbord.png"))); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 290));

        panelExercice.add(jPanel2, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelExercice, "exercice");

        getContentPane().add(panelEntete, java.awt.BorderLayout.NORTH);

        panelTable.setLayout(new java.awt.BorderLayout());

        tableDossiers.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableDossiers.setGridColor(new java.awt.Color(204, 204, 204));
        tableDossiers.setRowHeight(24);
        tableDossiers.setSelectionBackground(new java.awt.Color(91, 118, 173));
        tableDossiers.setShowGrid(true);
        tableDossiers.getTableHeader().setReorderingAllowed(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listLiquidations}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("Num Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numOrdre}"));
        columnBinding.setColumnName("Num Ordre");
        columnBinding.setColumnClass(Integer.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantTTC}"));
        columnBinding.setColumnName("Montant TTC");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Beneficiaire");
        columnBinding.setColumnClass(String.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedLiquidation}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane2.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setMinWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(120);
            tableDossiers.getColumnModel().getColumn(0).setMaxWidth(30);
            tableDossiers.getColumnModel().getColumn(1).setMinWidth(100);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(70);
            tableDossiers.getColumnModel().getColumn(1).setMaxWidth(150);
            tableDossiers.getColumnModel().getColumn(2).setMinWidth(110);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(110);
            tableDossiers.getColumnModel().getColumn(2).setMaxWidth(110);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(250);
        }

        panelTable.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelTable, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // recherche des elements
        rechercher(false);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void txtnumDossierKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnumDossierKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            rechercher(false);
        }
    }//GEN-LAST:event_txtnumDossierKeyReleased

    private void btnActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionActionPerformed
        // TODO add your handling code here:
        try {
            if (selectedLiquidation == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner une liquidation SVP");
                return;
            } else {
                EngagementMandatementDialog dialog = new EngagementMandatementDialog(me, true, selectedLiquidation, EngagementMandatementDialog.MODE_ENREGISTRE);
                dialog.setVisible(true);
                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }

        } catch (Exception e) {
        }
    }//GEN-LAST:event_btnActionActionPerformed

    private void rechercher(boolean advanced) {
//        glasspane.attente();
        search(advanced);
//        glasspane.arret();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(LiquidationSearchDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(LiquidationSearchDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(LiquidationSearchDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(LiquidationSearchDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new EngagementSearchDialog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAction;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblRecherche;
    private javax.swing.JPanel panelEntete;
    private javax.swing.JPanel panelExercice;
    private javax.swing.JPanel panelTable;
    private org.jdesktop.swingx.JXTable tableDossiers;
    private javax.swing.JFormattedTextField txtnumDossier;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
