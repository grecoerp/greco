/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Bordereau;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueEngagementBordereau;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.EngagementTypeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.table.TableColumn;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementTransmissionAnnulationDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<VueEngagementDossier> listDossiers = ObservableCollections.observableList(new ArrayList<VueEngagementDossier>());
    VueEngagementDossier selectedDossier = null;
    

    GrecoReports fonctions = new GrecoReports();
    int wSearch = 600, hSearch = 300;
    int typetransmission;

    public EngagementTransmissionAnnulationDialog(java.awt.Frame parent, boolean modal, int typeTrans) {
        super(parent, modal);
        initComponents();
        setSize(650, 515);
        this.typetransmission = typeTrans;
        getTitre();
        glasspane.setText("Recherche des dossiers correspondant aux critères ...");
        loadOrganisations();
        loadExercicesBudgetisation();
        panelAnnulationTransmission.setVisible(false);
        setLocationRelativeTo(null);

        TableColumn colorColumn = tableDossiers.getColumn(2);
        colorColumn.setCellRenderer(new EngagementTypeRenderer());
    }

    private String getTitre() {
        String annulationType = "";
        if (this.typetransmission == EtatDossier.transmiCF) {
            annulationType = "Annulation de la transmission pour Controle de Conformité";
        }
        else if (this.typetransmission == EtatDossier.transmiPourLiquidation) {
            annulationType = "Annulation de la transmission pour liquidation";
        }
        else if (this.typetransmission == EtatDossier.transmiPourRegularite) {
            annulationType = "Annulation de la transmission pour Controle de régularité";
        }
        else if (this.typetransmission == EtatDossier.transmiAuComptable) {
            annulationType = "Annulation de la transmission pour Controle de régularitéau comptable";
        }
        return annulationType;
    }
    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            } else {
                cboExercice.setSelectedIndex(cboExercice.getItemCount() - 1);
            }
        }
    }

    private void loadBordereauAtTransmission() {

        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return;
        }
        List<Bordereau> list = GrecoServiceFactory.getEngagementService().getBordereauTransmissionEnCours(o.getOrganisationID(), e.getMillesime(), this.typetransmission);
        if (list != null && !list.isEmpty()) {
            list.add(null);
            cboListeBordereau.setModel(new DefaultComboBoxModel(list.toArray()));
        } else {
            cboListeBordereau.setModel(new DefaultComboBoxModel());
        }
    }

    public List<VueEngagementDossier> getListDossiers() {
        return listDossiers;
    }

    public void setListDossiers(List<VueEngagementDossier> listDossiers) {
        this.listDossiers = listDossiers;
    }

    public VueEngagementDossier getSelectedDossier() {
        return selectedDossier;
    }

    public void setSelectedDossier(VueEngagementDossier selectedDossier) {
        this.selectedDossier = selectedDossier;
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        return true;
    }

    private void search(boolean advanced) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String numdossier = txtNumDossier.getText().trim().isEmpty() ? null : txtNumDossier.getText().trim();
        String numBordereau = txtNumBordereau.getText().trim().isEmpty() ? null : txtNumBordereau.getText().trim();
        Date dateEnregDebut = dtpEnregistrementDebut.getDate();
        Date dateEnregFin = dtpEnregistrementfin.getDate();

        glasspane.attente();
        List<VueEngagementDossier> l = GrecoServiceFactory.getEngagementService().getDossiersAtTypeTransmission(organisationID, millesime, numBordereau, numdossier, dateEnregDebut, dateEnregFin, this.typetransmission);
        listDossiers.clear();
        if (l != null && !l.isEmpty()) {
            for (VueEngagementDossier v : l) {
                listDossiers.add(v);
            }
            panelAnnulationTransmission.setVisible(true);
        } else {
            panelAnnulationTransmission.setVisible(false);
        }
        glasspane.arret();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        dtpEnregistrementDebut = new org.jdesktop.swingx.JXDatePicker();
        jLabel14 = new javax.swing.JLabel();
        dtpEnregistrementfin = new org.jdesktop.swingx.JXDatePicker();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNumBordereau = new javax.swing.JTextField();
        txtNumDossier = new javax.swing.JTextField();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        cboListeBordereau = new javax.swing.JComboBox();
        chkCocherTous = new javax.swing.JCheckBox();
        jLabel3 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableDossiers = new org.jdesktop.swingx.JXTable();
        panelAnnulationTransmission = new javax.swing.JPanel();
        btnAnnulationTrans = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Annulation des dossiers transmis");
        setPreferredSize(new java.awt.Dimension(650, 515));
        setResizable(false);

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(643, 251));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 42, 81, 30));

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });
        jPanel2.add(cboExercice, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 48, 186, -1));

        jLabel13.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel13.setText("Date entre le ");
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 92, 105, 20));
        jPanel2.add(dtpEnregistrementDebut, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 92, 130, -1));

        jLabel14.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel14.setText("et le ");
        jPanel2.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 50, 20));

        dtpEnregistrementfin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dtpEnregistrementfinActionPerformed(evt);
            }
        });
        jPanel2.add(dtpEnregistrementfin, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 90, 140, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 12, 92, -1));

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        jPanel2.add(cboOrganisation, new org.netbeans.lib.awtextra.AbsoluteConstraints(133, 11, 490, -1));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setText("N° de bordereau : ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 133, -1, -1));

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("N° de dossier : ");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 171, -1, -1));
        jPanel2.add(txtNumBordereau, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 132, 185, -1));
        jPanel2.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(131, 170, 185, -1));

        btnRechercher.setText("Rechercher  ...");
        btnRechercher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });
        jPanel2.add(btnRechercher, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 213, -1, -1));

        cboListeBordereau.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboListeBordereau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboListeBordereauActionPerformed(evt);
            }
        });
        jPanel2.add(cboListeBordereau, new org.netbeans.lib.awtextra.AbsoluteConstraints(354, 132, 270, -1));

        chkCocherTous.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        chkCocherTous.setForeground(new java.awt.Color(0, 102, 204));
        chkCocherTous.setText("Cocher tous");
        chkCocherTous.setOpaque(false);
        chkCocherTous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCocherTousActionPerformed(evt);
            }
        });
        jPanel2.add(chkCocherTous, new org.netbeans.lib.awtextra.AbsoluteConstraints(520, 220, 120, -1));

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgannulationbord.png"))); // NOI18N
        jLabel3.setText("jLabel3");
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 650, 250));

        getContentPane().add(jPanel2, java.awt.BorderLayout.NORTH);

        tableDossiers.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableDossiers.setGridColor(new java.awt.Color(204, 204, 204));
        tableDossiers.setRowHeight(24);
        tableDossiers.setSelectionBackground(new java.awt.Color(91, 118, 173));
        tableDossiers.setShowGrid(true);
        tableDossiers.getTableHeader().setReorderingAllowed(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listDossiers}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${check}"));
        columnBinding.setColumnName("Check");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("Num Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${type}"));
        columnBinding.setColumnName("Type");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Beneficiaire");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${objet}"));
        columnBinding.setColumnName("Objet");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedListDossiers}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElements"));
        bindingGroup.addBinding(binding);

        tableDossiers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableDossiersMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setResizable(false);
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(3);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(40);
            tableDossiers.getColumnModel().getColumn(2).setResizable(false);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(3);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(200);
            tableDossiers.getColumnModel().getColumn(4).setResizable(false);
            tableDossiers.getColumnModel().getColumn(4).setPreferredWidth(40);
        }

        getContentPane().add(jScrollPane2, java.awt.BorderLayout.CENTER);

        panelAnnulationTransmission.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnAnnulationTrans.setText("Annuler la transmission de ces dossiers");
        btnAnnulationTrans.setCouleur(2);
        btnAnnulationTrans.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnAnnulationTrans.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulationTransActionPerformed(evt);
            }
        });
        panelAnnulationTransmission.add(btnAnnulationTrans);

        getContentPane().add(panelAnnulationTransmission, java.awt.BorderLayout.SOUTH);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }
        }
        loadBordereauAtTransmission();
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // recherche des elements
        rechercher(true);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void btnAnnulationTransActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulationTransActionPerformed
        // TODO add your handling code here:
        annulerTransmission();
    }//GEN-LAST:event_btnAnnulationTransActionPerformed

    private void annulerTransmission() {
        List<VueEngagementDossier> selectedListDossiers = new ArrayList<VueEngagementDossier>();
        for (VueEngagementDossier v : listDossiers) {
            if(v.isCheck()){
                selectedListDossiers.add(v);
            }
        }
        
        if (selectedListDossiers == null || selectedListDossiers.isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner les dossiers pour lesquelles la transmission doit être annulée");
            return;
        }
        int res = GrecoOptionPane.showConfirmDialog("Voulez-vous annuler la transmission des dossier(s) sélectionné(s) ?");
        if (res == JOptionPane.YES_OPTION) {
            String numBordereauAnnulation;
            Organisation o = (Organisation) cboOrganisation.getSelectedItem();
            if (o == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
                return;
            }
            Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
                return;
            }
            try {
                glasspane.setText("Edition du bordereau d'annulation des dossiers ...");
                glasspane.attente();
                numBordereauAnnulation = GrecoServiceFactory.getEngagementService().transmissionAnnulationDossier(
                        o.getOrganisationID(), e.getMillesime(), getTypeAnnulation(), GrecoSession.USER_CONNECTED.getService(),
                        GrecoSession.USER_CONNECTED.getService(), GrecoSession.USER_CONNECTED.getNomComplet(), selectedListDossiers, GrecoSession.USER_CONNECTED.getLogin(), getTypeAnnulation());
                if (numBordereauAnnulation == null) {
                    GrecoSession.notifications.echec();
                    GrecoOptionPane.showErrorDialog("La transmission de ces dossiers n'a pas pu être effectuée ...");
                } else {
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("Transmission annulée avec succès sous le bordereau N° : " + numBordereauAnnulation + "\n Le bordereau va être édité dans quelques secondes ");
                    search(false); // recharger la liste
                    //impression du bordereau
                    GrecoImages logo = new GrecoImages();
                    Image armoirieCM = null;//new siiResources.Images();
                    HashMap parameters = fonctions.mainParameters();
                    parameters.put("chapitreFR", o.getLibelleFr());
                    parameters.put("chapitreEN", o.getLibelleUs());
                    parameters.put("armoirieCM", armoirieCM);
                    parameters.put("logo", logo.logoOrganisation());
                    parameters.put("app", logo.logo());
                    parameters.put("user", GrecoSession.USER_CONNECTED.getNom());
                    parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
                    parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");
                    parameters.put("title", "BORDEREAU D'ANNULATION DE TRANSMISSION ");

                    List<VueEngagementBordereau> contentBordereau = new ArrayList<>();

                    contentBordereau = GrecoServiceFactory.getReportService().getBordereauTransmission(numBordereauAnnulation);
                    JRDataSource dataSource = new JRBeanCollectionDataSource(contentBordereau);
                    try {
                        JasperPrint print = JasperFillManager.fillReport(fonctions.bordereauTransmission(), parameters, dataSource);
                        JRHelper.viewReport(print);
                    } catch (Exception ed) {
                        ed.printStackTrace();
                    }
                    loadBordereauAtTransmission();
                }
                glasspane.arret();
            } catch (Exception ex) {
                GrecoSession.notifications.echec();
                GrecoOptionPane.showErrorDialog("Les dossiers n'ont pas pu etre transmis ...");
                glasspane.arret();
            }

        }
    }

    private int getTypeAnnulation() {
        int annulationType = EtatDossier.transmiCF;
        if (this.typetransmission == EtatDossier.transmiCF) {
            annulationType = EtatDossier.transmiCF_annule;
        }
        else if (this.typetransmission == EtatDossier.transmiPourLiquidation) {
            annulationType = EtatDossier.transmiPourLiquidation_annule;
        }
        else if (this.typetransmission == EtatDossier.transmiPourRegularite) {
            annulationType = EtatDossier.transmiPourRegularite_annule;
        }
        else if (this.typetransmission == EtatDossier.transmiAuComptable) {
            annulationType = EtatDossier.transmiAuComptable_annule;
        }
        return annulationType;
    }
    private void dtpEnregistrementfinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dtpEnregistrementfinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dtpEnregistrementfinActionPerformed

    private void tableDossiersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableDossiersMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {

//            final Engagement e = GrecoServiceFactory.getEngagementService().getEngagementByDossier(code);
//            if (e != null) {
//                SwingUtilities.invokeLater(new Runnable() {
//                    @Override
//                    public void run() {
//                        try {
//                            EngagementConsultationDialog frame = new EngagementConsultationDialog(me, true, e);
//                            frame.setVisible(true);
//                        } catch (Exception e) {
//                            e.printStackTrace();
//                        }
//                    }
//                });
//            }
        }
    }//GEN-LAST:event_tableDossiersMouseClicked

    private void chkCocherTousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCocherTousActionPerformed
        // TODO add your handling code here:
        chkCocherTous.setSelected(chkCocherTous.isSelected());
        boolean state = chkCocherTous.isSelected();
        List<VueEngagementDossier> lst = new ArrayList<>();
        for (VueEngagementDossier dossier : listDossiers) {
            dossier.setCheck(state);
            lst.add(dossier);
        }
        //recharger la liste
        listDossiers.clear();
        for (VueEngagementDossier d : lst) {
            listDossiers.add(d);
        }
    }//GEN-LAST:event_chkCocherTousActionPerformed

    private void cboListeBordereauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboListeBordereauActionPerformed
        // TODO add your handling code here:
        Bordereau b = (Bordereau) cboListeBordereau.getSelectedItem();
        if (b != null) {
            txtNumBordereau.setText(b.getNumBordereau());
        } else {
            txtNumBordereau.setText("");
        }
    }//GEN-LAST:event_cboListeBordereauActionPerformed

    private void rechercher(boolean advanced) {
        search(advanced);
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EngagementTransmissionAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EngagementTransmissionAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EngagementTransmissionAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EngagementTransmissionAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new EngagementSearchDialog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAnnulationTrans;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboListeBordereau;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JCheckBox chkCocherTous;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementDebut;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementfin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel panelAnnulationTransmission;
    private org.jdesktop.swingx.JXTable tableDossiers;
    private javax.swing.JTextField txtNumBordereau;
    private javax.swing.JTextField txtNumDossier;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
