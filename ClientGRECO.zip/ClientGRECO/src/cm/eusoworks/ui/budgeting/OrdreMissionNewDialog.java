/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author macbookair
 */
public class OrdreMissionNewDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    String millesime;
    String organisationID;
    OrdreMission currentOM = null;
    Organisation org;

    public OrdreMissionNewDialog(JFrame parent, boolean modal, String millesime, Organisation org, OrdreMission om) {
        super(parent, modal);
        initComponents();
        this.millesime = millesime;
        this.org = org;
        this.organisationID = org.getOrganisationID();
        loadStructureOrganisation();
        this.currentOM = om;
        initBCAInfos();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Etablissement d'un ordre de mission ");
        pack();
        setSize(750, 560);
        setLocationRelativeTo(null);
    }

    private void initBCAInfos() {

        if (currentOM != null) {
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentOM.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentOM.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentOM.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            txtMotif.setText(currentOM.getMotifReference());
            agentComp.setMatricule(currentOM.getMatricule());
            txtDestination.setText(currentOM.getDestination());
            txtPassantPar.setText(currentOM.getPassantPar());
            txtTransport.setText(currentOM.getTransport());
            txtAccompagnant.setText(currentOM.getAccompagnant());
            dtpDateDepart.setDate(currentOM.getDateDepart());
            dtpDateRetour.setDate(currentOM.getDateRetour());
            try {
                cboSituationMatrimoniale.setSelectedItem(currentOM.getSituation());
            } catch (Exception e) {
            }
            try {
                cboTypeMission.setSelectedIndex(currentOM.getTypeMission());
            } catch (Exception e) {
            }
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(this.organisationID);
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);
        }

    }

    private void remplirOM() {
        Structure s = (Structure) cboStructure.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();

        currentOM.setMotifReference(txtMotif.getText().trim());

        currentOM.setTypeMission(cboTypeMission.getSelectedIndex());
        currentOM.setSituation((String) cboSituationMatrimoniale.getSelectedItem());
        currentOM.setDestination(txtDestination.getText().trim());
        currentOM.setPassantPar(txtPassantPar.getText());
        currentOM.setTransport(txtTransport.getText().trim());
        currentOM.setAccompagnant(txtAccompagnant.getText().trim());

        currentOM.setDateDepart(dtpDateDepart.getDate());
        currentOM.setDateRetour(dtpDateRetour.getDate());

        currentOM.setTacheID(o.getTacheID());
        currentOM.setMillesime(millesime);
        currentOM.setOrganisationID(organisationID);
        currentOM.setMatricule(agentComp.getMatricule());
        currentOM.setStructureID(s.getStructureID());
        currentOM.setActiviteID(a.getActiviteID());

        currentOM.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentOM.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

    }

    private boolean controlData() {
        boolean res = true;
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la structure");
            return false;
        }

        if (agentComp.getMatricule() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le matricule de l'agent ");
            return false;
        }
        Activite a = (Activite) cboTache.getSelectedItem();
        if (a == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la tâche ");
            return false;
        }
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (o == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner l'imputation ");
            return false;
        }
        if (txtMotif.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir le motif de la mission ");
            return false;
        }

        if (txtDestination.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir la destination ou l'itinéraire ");
            return false;
        }
        if (dtpDateDepart.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir la date de départ en mission ");
            return false;
        }
        if (dtpDateRetour.getDate() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez ssaisir la date de retour de la mission ");
            return false;
        }
        if (dtpDateDepart.getDate().after(dtpDateRetour.getDate())) {
            JOptionPane.showMessageDialog(this, "La date de départ en mission doit être antérieur à la date de retour... ");
            return false;
        }
        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ongletBCA = new javax.swing.JTabbedPane();
        pAccueil = new javax.swing.JPanel();
        pObjetCommande = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtMotif = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        btnEnregistrer = new javax.swing.JButton();
        jLabel6 = new javax.swing.JLabel();
        agentComp = new cm.eusoworks.component.AgentComponent();
        jLabel1 = new javax.swing.JLabel();
        cboSituationMatrimoniale = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        txtDestination = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtPassantPar = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtTransport = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txtAccompagnant = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dtpDateDepart = new org.jdesktop.swingx.JXDatePicker();
        dtpDateRetour = new org.jdesktop.swingx.JXDatePicker();
        jLabel13 = new javax.swing.JLabel();
        cboTypeMission = new javax.swing.JComboBox();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        ongletBCA.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);

        pAccueil.setLayout(null);

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Imputation ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 11), new java.awt.Color(0, 102, 204))); // NOI18N
        pObjetCommande.setLayout(null);

        jLabel2.setText("Tâche : ");
        pObjetCommande.add(jLabel2);
        jLabel2.setBounds(17, 50, 80, 20);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(17, 80, 80, 20);

        jLabel4.setText("Motif  : ");
        pObjetCommande.add(jLabel4);
        jLabel4.setBounds(20, 120, 70, 51);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 50, 550, 20);

        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 80, 550, 20);

        txtMotif.setColumns(20);
        txtMotif.setRows(2);
        jScrollPane2.setViewportView(txtMotif);

        pObjetCommande.add(jScrollPane2);
        jScrollPane2.setBounds(110, 120, 550, 51);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(20, 20, 80, 20);

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboStructure);
        cboStructure.setBounds(110, 20, 550, 20);

        pAccueil.add(pObjetCommande);
        pObjetCommande.setBounds(10, 50, 688, 180);

        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        pAccueil.add(btnEnregistrer);
        btnEnregistrer.setBounds(530, 370, 166, 43);

        jLabel6.setText("Matricule : ");
        pAccueil.add(jLabel6);
        jLabel6.setBounds(30, 10, 70, 22);
        pAccueil.add(agentComp);
        agentComp.setBounds(113, 10, 290, 22);

        jLabel1.setText("Situation : ");
        pAccueil.add(jLabel1);
        jLabel1.setBounds(30, 250, 70, 20);

        cboSituationMatrimoniale.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Célibataire sans enfants", "Célibataire avec enfants", "Marié sans enfants", "Marié avec enfants", "Divorcé" }));
        pAccueil.add(cboSituationMatrimoniale);
        cboSituationMatrimoniale.setBounds(120, 250, 220, 20);

        jLabel7.setText("Destination : ");
        pAccueil.add(jLabel7);
        jLabel7.setBounds(30, 280, 80, 20);
        pAccueil.add(txtDestination);
        txtDestination.setBounds(120, 280, 220, 20);

        jLabel8.setText("Passant par : ");
        pAccueil.add(jLabel8);
        jLabel8.setBounds(380, 280, 90, 20);
        pAccueil.add(txtPassantPar);
        txtPassantPar.setBounds(480, 280, 220, 20);

        jLabel9.setText("Transport : ");
        pAccueil.add(jLabel9);
        jLabel9.setBounds(30, 310, 80, 20);
        pAccueil.add(txtTransport);
        txtTransport.setBounds(120, 310, 220, 20);

        jLabel10.setText("Accompagnant : ");
        pAccueil.add(jLabel10);
        jLabel10.setBounds(380, 310, 90, 20);
        pAccueil.add(txtAccompagnant);
        txtAccompagnant.setBounds(480, 310, 220, 20);

        jLabel11.setText("Date de départ : ");
        pAccueil.add(jLabel11);
        jLabel11.setBounds(30, 350, 90, 20);

        jLabel12.setText("Date de retour : ");
        pAccueil.add(jLabel12);
        jLabel12.setBounds(30, 374, 90, 30);
        pAccueil.add(dtpDateDepart);
        dtpDateDepart.setBounds(120, 350, 160, 22);
        pAccueil.add(dtpDateRetour);
        dtpDateRetour.setBounds(120, 380, 160, 22);

        jLabel13.setText("Type : ");
        pAccueil.add(jLabel13);
        jLabel13.setBounds(420, 10, 50, 20);

        cboTypeMission.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "à l'Intérieur du Cameroun", "à l'Extérieur du pays" }));
        pAccueil.add(cboTypeMission);
        cboTypeMission.setBounds(490, 10, 200, 20);

        ongletBCA.addTab("Détails de l'ordre de mission ", pAccueil);

        getContentPane().add(ongletBCA, "card3");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentOM == null) {
                currentOM = new OrdreMission();
                remplirOM();
                try {
                    String newBcaID = GrecoServiceFactory.getOrdreMissionService().ajouter(currentOM);
                    currentOM.setOmID(newBcaID);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Ordre de mission enregistré avec succès ");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            } else {
                remplirOM();
                try {
                    GrecoServiceFactory.getOrdreMissionService().modifier(currentOM);
                    GrecoSession.notifications.success();
                    //                    JOptionPane.showMessageDialog(this, "Bon de commande modifié ");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(millesime, organisationID, s.getStructureID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboSituationMatrimoniale;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JComboBox cboTypeMission;
    private org.jdesktop.swingx.JXDatePicker dtpDateDepart;
    private org.jdesktop.swingx.JXDatePicker dtpDateRetour;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTabbedPane ongletBCA;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JTextField txtAccompagnant;
    private javax.swing.JTextField txtDestination;
    private javax.swing.JTextArea txtMotif;
    private javax.swing.JTextField txtPassantPar;
    private javax.swing.JTextField txtTransport;
    // End of variables declaration//GEN-END:variables

}
