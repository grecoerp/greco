/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.view.VueAgentOM;
import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import com.siicore.util.StringUtil;
import java.awt.Cursor;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 *
 * @author ouethy
 */
public class DecisionFrame extends javax.swing.JFrame {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    Decision currentDecision = null;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();

    public DecisionFrame() {
        initComponents();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Traitement des décisions  ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        setLocationRelativeTo(null);
        loadOrganisations();
        loadExercicesBudgetisation();
        loadFournisseurs();
        disableBenef();
        rdbAgentItemStateChanged(null);
        me = this;
    }

    private void loadFournisseurs() {
        List<Fournisseur> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getFournisseurService().getListFournisseur();
        } catch (Exception e) {
            list = null;
        }

        if (list != null && !list.isEmpty()) {
            cboFournisseur.setModel(new DefaultComboBoxModel(list.toArray()));
            cboFournisseur.setSelectedIndex(-1);
        }
    }

    private void initDecisionUI() {
        if (currentDecision == null) {
            txtReference.setText("");
            dtpDateSignature.setDate(null);
            txtMontant.setValue(null);
            txtMontant.setText("");
            txtObjet.setText("");
            txtSignataire.setText("");
        } else {
            txtReference.setText(currentDecision.getReference());
            dtpDateSignature.setDate(currentDecision.getDateSignature());
            txtObjet.setText(currentDecision.getObjet());
            txtSignataire.setText(currentDecision.getSignataire());
            txtMontant.setValue(currentDecision.getMontant());
            for (int i = 0; i < cboModeleDecision.getItemCount(); i++) {
                DecisionModele m = (DecisionModele) cboModeleDecision.getItemAt(i);
                if (m.getModeleID().equalsIgnoreCase(currentDecision.getModeleID())) {
                    cboModeleDecision.setSelectedIndex(i);
                    break;
                }
            }
            if (currentDecision.getMatricule() != null && !currentDecision.getMatricule().isEmpty()) {
                agentComp.setMatricule(currentDecision.getMatricule());
                rdbAgent.setSelected(true);
            } else if (currentDecision.getFournisseurID() != null && !currentDecision.getFournisseurID().isEmpty()) {
                for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                    Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                    if (f.getFournisseurID().equalsIgnoreCase(currentDecision.getFournisseurID())) {
                        cboFournisseur.setSelectedIndex(i);
                        break;
                    }
                }
                rdbFournisseur.setSelected(true);
            } else if (currentDecision.getStructureBenefID() != null && !currentDecision.getStructureBenefID().isEmpty()) {
                for (int i = 0; i < cboStructure.getItemCount(); i++) {
                    Structure s = (Structure) cboStructure.getItemAt(i);
                    if (s.getStructureID().equalsIgnoreCase(currentDecision.getStructureBenefID())) {
                        cboStructure.setSelectedIndex(i);
                        break;
                    }
                }
                rdbStructure.setSelected(true);
            } else {
                txtBenefAutre.setText(currentDecision.getBeneficiaire());
                rdbAutre.setSelected(true);
            }
            for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
                Structure s = (Structure) cboStructureImputation.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentDecision.getStructureID())) {
                    cboStructureImputation.setSelectedIndex(i);
                    break;
                }
            }

            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentDecision.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentDecision.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void loadStructureOrganisation() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            return;
        }
        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(o.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);

            cboStructureImputation.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructureImputation.setSelectedIndex(-1);
        }

    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    private void loadModeleDecision(String millesime, String organisationID) {
        List<DecisionModele> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getDecisionService().getModeleByOrganisation(millesime, organisationID);
        } catch (Exception e) {
            list = null;
        }
        if (list != null) {
            cboModeleDecision.setModel(new DefaultComboBoxModel(list.toArray()));
            cboModeleDecision.setSelectedIndex(-1);
        }

    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        if (txtReference.getText().isEmpty()) {
            JOptionPane.showConfirmDialog(null, "Veuillez saisir la référence de la décision");
            return false;
        }
        DecisionModele m = (DecisionModele) cboModeleDecision.getSelectedItem();
        if (m == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez choisir le modèle de décision");
            return false;
        }
        if (txtObjet.getText().isEmpty()) {
            JOptionPane.showConfirmDialog(null, "Veuillez saisir l'objet de la décision ");
            return false;
        }

        //control beneficiare
        if (rdbAgent.isSelected()) {
            if (agentComp.getMatricule().isEmpty()) {
                JOptionPane.showConfirmDialog(null, "Veuillez saisir le matricule de l'agent bénéficiaire ");
                return false;
            }
        }
        if (rdbFournisseur.isSelected()) {
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            if (f == null) {
                JOptionPane.showConfirmDialog(null, "Veuillez sélectionner le fournisseur ");
                return false;
            }
        }
        if (rdbStructure.isSelected()) {
            Structure s = (Structure) cboStructure.getSelectedItem();
            if (s == null) {
                JOptionPane.showConfirmDialog(null, "Veuillez sélectionner la structure bénéficiare ");
                return false;
            }
        }
        if (rdbAutre.isSelected()) {
            if (txtBenefAutre.getText().isEmpty()) {
                JOptionPane.showConfirmDialog(null, "Veuillez saisir le libellé du bénéficiare ");
                return false;
            }
        }
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op == null) {
            JOptionPane.showConfirmDialog(null, "Veuillez sélectionner l'imputation budgétaire");
            return false;
        }
        if (txtMontant.getText().isEmpty()) {
            JOptionPane.showConfirmDialog(null, "Veuillez saisir le montant de la mise à disposition au bénéficiare ");
            return false;
        }

        return true;
    }

    private void remplirDecision() {
        currentDecision.setReference(txtReference.getText().trim());
        currentDecision.setDateSignature(dtpDateSignature.getDate());
        currentDecision.setObjet(txtObjet.getText());
        currentDecision.setSignataire(txtSignataire.getText());
        DecisionModele m = (DecisionModele) cboModeleDecision.getSelectedItem();
        currentDecision.setModeleID(m.getModeleID());
        Number nbr = (Number) txtMontant.getValue();
        currentDecision.setMontant(BigDecimal.valueOf(nbr.longValue()));
        if (rdbAgent.isSelected()) {
            currentDecision.setMatricule(agentComp.getMatricule());
            currentDecision.setBeneficiaire("[" + agentComp.getMatricule() + "] " + agentComp.getNomComplet());
            currentDecision.setFournisseurID(null);
            currentDecision.setStructureBenefID(null);
        } else if (rdbFournisseur.isSelected()) {
            currentDecision.setMatricule(null);
            Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
            currentDecision.setBeneficiaire(f.getNumContribuable() + " - " + f.getRaisonSociale());
            currentDecision.setFournisseurID(f.getFournisseurID());
            currentDecision.setStructureBenefID(null);
        } else if (rdbStructure.isSelected()) {
            Structure s = (Structure) cboStructure.getSelectedItem();
            currentDecision.setMatricule(null);
            currentDecision.setBeneficiaire(s.getLibelle());
            currentDecision.setFournisseurID(null);
            currentDecision.setStructureBenefID(s.getStructureID());
        } else if (rdbAutre.isSelected()) {
            currentDecision.setMatricule(null);
            currentDecision.setBeneficiaire(txtBenefAutre.getText().trim());
            currentDecision.setFournisseurID(null);
            currentDecision.setStructureBenefID(null);
        }
        Structure s = (Structure) cboStructureImputation.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        Organisation org = (Organisation) cboOrganisation.getSelectedItem();
        Exercice exo = (Exercice) cboExercice.getSelectedItem();

        currentDecision.setStructureID(s.getStructureID());
        currentDecision.setTacheID(o.getTacheID());
        currentDecision.setActiviteID(a.getActiviteID());
        currentDecision.setOrganisationID(org.getOrganisationID());
        currentDecision.setMillesime(exo.getMillesime());

        currentDecision.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentDecision.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        benefGroup = new javax.swing.ButtonGroup();
        pEntete = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        btnModeleDecision = new javax.swing.JButton();
        splitpane = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        treeDecision = new javax.swing.JTree();
        jPanel1 = new javax.swing.JPanel();
        pBouton = new javax.swing.JPanel();
        btnNouveau = new javax.swing.JButton();
        btnEnregistrer = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        btnEditerDecision = new javax.swing.JButton();
        pDetailDecision = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        dtpDateSignature = new org.jdesktop.swingx.JXDatePicker();
        jPanel2 = new javax.swing.JPanel();
        agentComp = new cm.eusoworks.component.AgentComponent();
        rdbAgent = new javax.swing.JRadioButton();
        rdbFournisseur = new javax.swing.JRadioButton();
        cboFournisseur = new javax.swing.JComboBox();
        rdbStructure = new javax.swing.JRadioButton();
        cboStructure = new javax.swing.JComboBox();
        rdbAutre = new javax.swing.JRadioButton();
        txtBenefAutre = new javax.swing.JTextField();
        pObjetCommande = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        cboStructureImputation = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        cboModeleDecision = new javax.swing.JComboBox();
        btnApercu = new javax.swing.JButton();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        txtSignataire = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Outil de montage des bons de commande administratif");

        pEntete.setBackground(new java.awt.Color(204, 204, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        btnModeleDecision.setText("Editeur de modèle ...");
        btnModeleDecision.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnModeleDecisionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pEnteteLayout = new javax.swing.GroupLayout(pEntete);
        pEntete.setLayout(pEnteteLayout);
        pEnteteLayout.setHorizontalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(cboOrganisation, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 265, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 113, Short.MAX_VALUE)
                .addComponent(btnModeleDecision)
                .addGap(25, 25, 25))
        );
        pEnteteLayout.setVerticalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(btnModeleDecision))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        getContentPane().add(pEntete, java.awt.BorderLayout.NORTH);

        splitpane.setDividerLocation(250);

        treeDecision.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                treeDecisionValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(treeDecision);

        splitpane.setLeftComponent(jScrollPane1);

        jPanel1.setLayout(new java.awt.BorderLayout());

        pBouton.setBackground(new java.awt.Color(153, 153, 255));
        pBouton.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 20, 5));

        btnNouveau.setText("Nouvelle décision ...");
        btnNouveau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNouveauActionPerformed(evt);
            }
        });
        pBouton.add(btnNouveau);

        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        pBouton.add(btnEnregistrer);

        btnSupprimer.setText("Supprimer ");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        pBouton.add(btnSupprimer);

        btnEditerDecision.setText("Editer la décision ...");
        btnEditerDecision.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditerDecisionActionPerformed(evt);
            }
        });
        pBouton.add(btnEditerDecision);

        jPanel1.add(pBouton, java.awt.BorderLayout.NORTH);

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("REFERENCE : ");

        jLabel2.setText("Date de signature : ");

        jPanel2.setBackground(new java.awt.Color(204, 204, 255));
        jPanel2.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "BENEFICIAIRE", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 12), new java.awt.Color(0, 102, 153))); // NOI18N

        benefGroup.add(rdbAgent);
        rdbAgent.setSelected(true);
        rdbAgent.setText("Agent");
        rdbAgent.setOpaque(false);
        rdbAgent.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbAgentItemStateChanged(evt);
            }
        });

        benefGroup.add(rdbFournisseur);
        rdbFournisseur.setText("Fournisseur ");
        rdbFournisseur.setOpaque(false);
        rdbFournisseur.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbFournisseurItemStateChanged(evt);
            }
        });

        cboFournisseur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboFournisseurActionPerformed(evt);
            }
        });

        benefGroup.add(rdbStructure);
        rdbStructure.setText("Structure");
        rdbStructure.setOpaque(false);
        rdbStructure.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbStructureItemStateChanged(evt);
            }
        });

        benefGroup.add(rdbAutre);
        rdbAutre.setText("Autre : ");
        rdbAutre.setOpaque(false);
        rdbAutre.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                rdbAutreItemStateChanged(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(rdbFournisseur)
                    .addComponent(rdbAgent, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(rdbAutre, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(rdbStructure, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(19, 19, 19)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtBenefAutre, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(cboStructure, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cboFournisseur, javax.swing.GroupLayout.Alignment.TRAILING, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(agentComp, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 439, Short.MAX_VALUE))))
                .addGap(24, 24, 24))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdbAgent))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbFournisseur)
                    .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbStructure)
                    .addComponent(cboStructure, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbAutre)
                    .addComponent(txtBenefAutre, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "IMPUTATION", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 1, 14), new java.awt.Color(0, 102, 204))); // NOI18N
        pObjetCommande.setLayout(null);

        jLabel6.setText("Tâche : ");
        pObjetCommande.add(jLabel6);
        jLabel6.setBounds(17, 50, 70, 20);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(17, 80, 80, 20);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(120, 50, 400, 20);

        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(120, 80, 400, 20);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(20, 20, 70, 20);

        cboStructureImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureImputationActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboStructureImputation);
        cboStructureImputation.setBounds(120, 20, 400, 20);

        jLabel9.setText("Montant : ");
        pObjetCommande.add(jLabel9);
        jLabel9.setBounds(20, 120, 70, 30);

        txtMontant.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtMontant.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        pObjetCommande.add(txtMontant);
        txtMontant.setBounds(120, 120, 160, 28);

        jLabel4.setText("Modèle de décision : ");

        btnApercu.setText("Aperçu");
        btnApercu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApercuActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel10.setText("Objet : ");

        txtObjet.setColumns(20);
        txtObjet.setRows(2);
        jScrollPane2.setViewportView(txtObjet);

        jLabel11.setText("Signataire : ");

        javax.swing.GroupLayout pDetailDecisionLayout = new javax.swing.GroupLayout(pDetailDecision);
        pDetailDecision.setLayout(pDetailDecisionLayout);
        pDetailDecisionLayout.setHorizontalGroup(
            pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDetailDecisionLayout.createSequentialGroup()
                .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addComponent(pObjetCommande, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jPanel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(pDetailDecisionLayout.createSequentialGroup()
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 96, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 445, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pDetailDecisionLayout.createSequentialGroup()
                            .addComponent(jLabel4)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(cboModeleDecision, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(btnApercu, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pDetailDecisionLayout.createSequentialGroup()
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 73, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(33, 33, 33)
                            .addComponent(jScrollPane2))
                        .addGroup(pDetailDecisionLayout.createSequentialGroup()
                            .addComponent(jLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(dtpDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(18, 18, 18)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(txtSignataire, javax.swing.GroupLayout.PREFERRED_SIZE, 233, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(47, Short.MAX_VALUE))
        );
        pDetailDecisionLayout.setVerticalGroup(
            pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDetailDecisionLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDetailDecisionLayout.createSequentialGroup()
                        .addGap(33, 33, 33)
                        .addComponent(jLabel10)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pDetailDecisionLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)))
                .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(dtpDateSignature, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(txtSignataire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pDetailDecisionLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboModeleDecision, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnApercu))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(pObjetCommande, javax.swing.GroupLayout.PREFERRED_SIZE, 163, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );

        jPanel1.add(pDetailDecision, java.awt.BorderLayout.CENTER);

        splitpane.setRightComponent(jPanel1);

        getContentPane().add(splitpane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNouveauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNouveauActionPerformed
        // TODO add your handling code here:
        currentDecision = null;
        initDecisionUI();
    }//GEN-LAST:event_btnNouveauActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            loadStructureOrganisation();
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
            if (e != null) {
                loadDateDecision();
                loadModeleDecision(e.getMillesime(), o.getOrganisationID());
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }

            if (o != null) {
                loadDateDecision();
                loadModeleDecision(e.getMillesime(), o.getOrganisationID());
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void btnModeleDecisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnModeleDecisionActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            JOptionPane.showMessageDialog(this, "Sélectionnez l'organisation ");
            return;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            JOptionPane.showMessageDialog(this, "Sélectionnez l'exercice ");
            return;
        }
        DecisionModeleDialog dialog = new DecisionModeleDialog(this, true, o.getOrganisationID(), e.getMillesime());
        dialog.setVisible(true);
    }//GEN-LAST:event_btnModeleDecisionActionPerformed

    private void cboFournisseurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboFournisseurActionPerformed
        // TODO add your handling code here:
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
    }//GEN-LAST:event_cboFournisseurActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void cboStructureImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureImputationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            JOptionPane.showMessageDialog(this, "Sélectionnez l'organisation ");
            return;
        }
        Exercice e = null;
        try {
            e = (Exercice) cboExercice.getSelectedItem();
        } catch (Exception exx) {
            e = null;
        }

        if (e == null) {
//            JOptionPane.showMessageDialog(this, "Sélectionnez l'exercice ");
            return;
        }
        Structure s = null;
        try {
            s = (Structure) cboStructureImputation.getSelectedItem();
        } catch (Exception ex) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(e.getMillesime(),
                        o.getOrganisationID(), s.getStructureID());
            } catch (Exception exx) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureImputationActionPerformed

    private void btnApercuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApercuActionPerformed
        // TODO add your handling code here:
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                    if (o == null) {
                        JOptionPane.showMessageDialog(null, "Sélectionnez l'organisation ");
                        return;
                    }
                    Exercice e = (Exercice) cboExercice.getSelectedItem();
                    if (e == null) {
                        JOptionPane.showMessageDialog(null, "Sélectionnez l'exercice ");
                        return;
                    }
                    DecisionModele model = (DecisionModele) cboModeleDecision.getSelectedItem();
                    if (model == null) {
                        JOptionPane.showMessageDialog(null, "Sélectionnez le modèle de la décision ");
                        return;
                    }
                    DecisionModeleDialog dialog = new DecisionModeleDialog(me, false, o.getOrganisationID(), e.getMillesime(),
                            model);
                    dialog.setVisible(true);
                } catch (Exception e) {
                }
            }
        });
    }//GEN-LAST:event_btnApercuActionPerformed

    private void rdbAgentItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbAgentItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbAgent.isSelected()) {
            agentComp.setEnabled(true);
        }
    }//GEN-LAST:event_rdbAgentItemStateChanged

    private void rdbFournisseurItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbFournisseurItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbFournisseur.isSelected()) {
            cboFournisseur.setEnabled(true);
        }
    }//GEN-LAST:event_rdbFournisseurItemStateChanged

    private void rdbStructureItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbStructureItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbStructure.isSelected()) {
            cboStructure.setEnabled(true);
        }
    }//GEN-LAST:event_rdbStructureItemStateChanged

    private void rdbAutreItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_rdbAutreItemStateChanged
        // TODO add your handling code here:
        disableBenef();
        if (rdbAutre.isSelected()) {
            txtBenefAutre.setEnabled(true);
        }
    }//GEN-LAST:event_rdbAutreItemStateChanged

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentDecision == null) {
                currentDecision = new Decision();
                remplirDecision();
                try {
                    String newDecisionID = GrecoServiceFactory.getDecisionService().ajouterDecision(currentDecision);
                    currentDecision.setDecisionID(newDecisionID);
                    GrecoSession.notifications.success();
                    loadDateDecision();
                    JOptionPane.showMessageDialog(this, "Décision enregistré avec succès ");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            } else {
                remplirDecision();
                try {
                    GrecoServiceFactory.getDecisionService().modifierDecision(currentDecision);
                    GrecoSession.notifications.success();
                    loadDateDecision();
                    JOptionPane.showMessageDialog(this, "Décision enregistré modifié ");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (currentDecision != null) {
            int res = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir supprimer cetionte décision ? ",
                    "GRECO", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getDecisionService().supprimerDecision(currentDecision.getDecisionID(), GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Décision supprimé avec succès  ");
                    loadDateDecision();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void treeDecisionValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_treeDecisionValueChanged
        // TODO add your handling code here:

        Object o = treeDecision.getLastSelectedPathComponent();
        if (o instanceof DefaultMutableTreeNode) {
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) o;
            if (node.getUserObject() instanceof Decision) {
                currentDecision = (Decision) node.getUserObject();
                initDecisionUI();
            }
        }
    }//GEN-LAST:event_treeDecisionValueChanged

    private void btnEditerDecisionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditerDecisionActionPerformed
        // TODO add your handling code here:
        Decision d = GrecoServiceFactory.getDecisionService().getDecision(currentDecision.getDecisionID());
        final DecisionModele modele = GrecoServiceFactory.getDecisionService().getModele(d.getModeleID());
        String contenu = modele.getContenu();
        contenu = contenu.replace("@@reference@@", d.getReference());
        contenu = contenu.replace("@@millesime@@", d.getMillesime());
        contenu = contenu.replace("@@BUDGET@@", d.getBudget());
        contenu = contenu.replace("@@ORGANISATION@@", d.getOrganisationLibelle());
        contenu = contenu.replace("@@beneficiaire@@", d.getBeneficiaire());
        contenu = contenu.replace("@@montant@@", d.getMontant().toString());
        contenu = contenu.replace("@@montantEnLettre@@", StringUtil.getMontantEnLettre(Locale.FRENCH, d.getMontant()));
        contenu = contenu.replace("@@imputation@@", d.getImputation());
        try {
            contenu = contenu.replace("@@objet@@", d.getObjet());
        } catch (Exception e) {
        }
        try {
            contenu = contenu.replace("@@signataire@@", d.getSignataire());
        } catch (Exception e) {
        }
        
        
        final String texte = contenu;
        //impression
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = new HashMap();
                            parameters.put("entete1Fr", modele.getEntete1Fr());
                            parameters.put("entete2Fr", modele.getEntete2Fr());
                            parameters.put("entete3Fr", modele.getEntete3Fr());
                            parameters.put("entete4Fr", modele.getEntete4Fr());
                            parameters.put("entete5Fr", modele.getEntete5Fr());
                            
                            parameters.put("entete1Us", modele.getEntete1Us());
                            parameters.put("entete2Us", modele.getEntete2Us());
                            parameters.put("entete3Us", modele.getEntete3Us());
                            parameters.put("entete4Us", modele.getEntete4Us());
                            parameters.put("entete5Us", modele.getEntete5Us());
                            
                            parameters.put("texte", texte);
                            JRHelper.viewReport(fonctions.apercu(), parameters, null, null, null);

                        } catch (Exception ex) {
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });

    }//GEN-LAST:event_btnEditerDecisionActionPerformed

    private void disableBenef() {
        agentComp.setEnabled(false);
        cboFournisseur.setEnabled(false);
        cboStructure.setEnabled(false);
        txtBenefAutre.setEnabled(false);
        txtBenefAutre.setText("");
    }

    private void imprimer(final Bca b) {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueBCAReport> list = new ArrayList<>();
                            list = GrecoServiceFactory.getReportService().getBcaLignesReport(b.getBcaID());

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("logoEntete", mesImages.logoOrganisation());
                            parameters.put("user", GrecoSession.USER_CONNECTED.getLogin() + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("montantEnLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, b.getMontantTTC()) + "  francs CFA");
                            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
                            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

                            JRHelper.viewReport(fonctions.bonCommandeAdministratif(), parameters, new JRBeanCollectionDataSource(list), null, null);

                        } catch (Exception ex) {
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void loadDateDecision() {
        DefaultMutableTreeNode root = new DefaultMutableTreeNode("Liste des décisions");
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getDecisionService().getDateDecisionByOrganisation(e.getMillesime(), o.getOrganisationID());
        } catch (Exception ex) {
        }
        if (list != null) {
            for (Date date : list) {
                DefaultMutableTreeNode nodeDate = new DefaultMutableTreeNode(date);
                List<Decision> l = GrecoServiceFactory.getDecisionService().getDecisionByOrganisationAndDate(e.getMillesime(),
                        o.getOrganisationID(), date);
                if (l != null) {
                    for (Decision decision : l) {
                        DefaultMutableTreeNode nodeDecision = new DefaultMutableTreeNode(decision);
                        nodeDate.add(nodeDecision);
                    }
                }
                root.add(nodeDate);
            }
        }
        treeDecision.removeAll();
        treeDecision.setModel(new DefaultTreeModel(root));
//        DefaultMutableTreeNode n = (DefaultMutableTreeNode) treeDecision.getModel().getRoot();
//        treeDecision.getp
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DecisionFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DecisionFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DecisionFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DecisionFrame.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DecisionFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.ButtonGroup benefGroup;
    private javax.swing.JButton btnApercu;
    private javax.swing.JButton btnEditerDecision;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnModeleDecision;
    private javax.swing.JButton btnNouveau;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboFournisseur;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboModeleDecision;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboStructureImputation;
    private javax.swing.JComboBox cboTache;
    private org.jdesktop.swingx.JXDatePicker dtpDateSignature;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel pBouton;
    private javax.swing.JPanel pDetailDecision;
    private javax.swing.JPanel pEntete;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JRadioButton rdbAgent;
    private javax.swing.JRadioButton rdbAutre;
    private javax.swing.JRadioButton rdbFournisseur;
    private javax.swing.JRadioButton rdbStructure;
    private javax.swing.JSplitPane splitpane;
    private javax.swing.JTree treeDecision;
    private javax.swing.JTextField txtBenefAutre;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.JTextField txtSignataire;
    // End of variables declaration//GEN-END:variables
}
