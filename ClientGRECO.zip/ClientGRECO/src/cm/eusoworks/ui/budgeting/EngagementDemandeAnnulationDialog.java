/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.DialogOpenMode;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.EngagementTypeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.TableColumn;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementDemandeAnnulationDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<VueEngagementDossier> listDossiers = ObservableCollections.observableList(new ArrayList<VueEngagementDossier>());
    VueEngagementDossier selectedDossier = null;
    List<VueEngagementDossier> dossiersSelectionnée = null;

    GrecoReports fonctions = new GrecoReports();
    int wSearch = 600, hSearch = 300;
    int openMode = DialogOpenMode.enregistre;
//    private CurvesProgressPanel glasspane;

    public EngagementDemandeAnnulationDialog(java.awt.Frame parent, boolean modal, int mode) {
        super(parent, modal);
        initComponents();
        setSize(780, 550);
        this.openMode = mode;
        initMode();
        panelRecherche.setBounds((int) ((getWidth() - wSearch) / 2), (int) ((getHeight() - hSearch) / 2), wSearch, hSearch);
        glasspane.setText("Recherche des dossiers correspondant aux critères ...");
//        this.setGlassPane(glasspane);
        loadOrganisations();
        loadExercicesBudgetisation();
        loadTypeEngagement();
        setLocationRelativeTo(null);

        TableColumn colorColumn = tableDossiers.getColumn(1);
        colorColumn.setCellRenderer(new EngagementTypeRenderer());
    }

    public List<VueEngagementDossier> getListDossiers() {
        return listDossiers;
    }

    public void setListDossiers(List<VueEngagementDossier> listDossiers) {
        this.listDossiers = listDossiers;
    }

    public VueEngagementDossier getSelectedDossier() {
        return selectedDossier;
    }

    public void setSelectedDossier(VueEngagementDossier selectedDossier) {
        this.selectedDossier = selectedDossier;
    }

    public List<VueEngagementDossier> getDossiersSelectionnée() {
        return dossiersSelectionnée;
    }

    public void setDossiersSelectionnée(List<VueEngagementDossier> dossiersSelectionnée) {
        this.dossiersSelectionnée = dossiersSelectionnée;
    }

    private void initMode() {
        loadTypeEngagement();
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            } else {
                cboExercice.setSelectedIndex(cboExercice.getItemCount() - 1);
            }
        }
    }

    private void loadTypeEngagement() {
        List<EngagementType> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getEngagementService().getEngagementType();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            list.add(null);
            cboTypeengagement.setModel(new DefaultComboBoxModel(list.toArray()));
            cboTypeengagement.setSelectedIndex(-1);
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        return true;
    }

    private void search(boolean advanced) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String numdossier = ((String) txtnumDossier.getValue());
        String etat = EtatDossier.getListeEtat(this.openMode);
        String engagementType = null;
        String cpte = null;
        Date dateEnregDebut = null;
        Date dateEnregFin = null;
        Date dateValidDebut = null;
        Date dateValidFin = null;
        String beneficiare = null;

        if (advanced) {
            EngagementType et = (EngagementType) cboTypeengagement.getSelectedItem();
            if (et != null) {
                engagementType = et.getTypeID();
            }
            cpte = txtCompteBudgetaire.getText().isEmpty() ? null : txtCompteBudgetaire.getText();
            dateEnregDebut = dtpEnregistrementDebut.getDate();
            dateEnregFin = dtpEnregistrementfin.getDate();
            dateValidDebut = dtpDateValidationDebut.getDate();
            dateValidFin = dtpDateValidationFin.getDate();
            beneficiare = txtBeneficiaire.getText().isEmpty() ? null : txtBeneficiaire.getText();
        }

        glasspane.attente();
        List<VueEngagementDossier> l = GrecoServiceFactory.getEngagementService().getDossiers(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut, dateEnregFin, dateValidDebut, dateValidFin, beneficiare);
        listDossiers.clear();
        if (l != null) {
            lblRecherche.setText(l.size() + " dossier(s) trouvé(s)");
            for (VueEngagementDossier v : l) {
                listDossiers.add(v);
            }
        } else {
            lblRecherche.setText("aucun dossier trouvé");
        }
        glasspane.arret();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        panelEntete = new javax.swing.JPanel();
        panelExercice = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        txtnumDossier = new javax.swing.JFormattedTextField();
        lblRecherche = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        btnOptions = new cm.eusoworks.tools.ui.GButton();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel13 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        panelRecherche = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cboTypeengagement = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        txtCompteBudgetaire = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        dtpEnregistrementDebut = new org.jdesktop.swingx.JXDatePicker();
        dtpEnregistrementfin = new org.jdesktop.swingx.JXDatePicker();
        dtpDateValidationDebut = new org.jdesktop.swingx.JXDatePicker();
        dtpDateValidationFin = new org.jdesktop.swingx.JXDatePicker();
        txtBeneficiaire = new javax.swing.JTextField();
        btnRechercheAvance = new cm.eusoworks.tools.ui.GButton();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        panelTable = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tableDossiers = new org.jdesktop.swingx.JXTable();
        panelSuppression = new javax.swing.JPanel();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Demande d'annulation des dossiers adressée au Contrôleur Financier");
        setResizable(false);

        panelEntete.setLayout(new java.awt.CardLayout());

        panelExercice.setBackground(new java.awt.Color(255, 255, 255));
        panelExercice.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setMinimumSize(new java.awt.Dimension(0, 0));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice ");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 44, 76, 30));

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });
        jPanel2.add(cboExercice, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 50, 193, -1));

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("N° de dossier : ");
        jPanel2.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 92, -1, 26));

        try {
            txtnumDossier.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("U######")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtnumDossier.setFont(new java.awt.Font("Arial Black", 0, 16)); // NOI18N
        txtnumDossier.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtnumDossierKeyReleased(evt);
            }
        });
        jPanel2.add(txtnumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(122, 92, 104, -1));

        lblRecherche.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblRecherche.setForeground(new java.awt.Color(91, 118, 173));
        lblRecherche.setText("Résultats de la recherche : ");
        jPanel2.add(lblRecherche, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, 342, 20));

        jPanel1.setOpaque(false);
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 0));

        btnOptions.setForeground(new java.awt.Color(0, 0, 0));
        btnOptions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/search.png"))); // NOI18N
        btnOptions.setText("Options...     ");
        btnOptions.setCouleur(3);
        btnOptions.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btnOptions.setStyle(1);
        btnOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOptionsActionPerformed(evt);
            }
        });
        jPanel1.add(btnOptions);

        btnRechercher.setText("Rechercher ...");
        btnRechercher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnRechercher.setStyle(3);
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });
        jPanel1.add(btnRechercher);

        jPanel2.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 160, 350, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 19, 92, -1));

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        jPanel2.add(cboOrganisation, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 18, 629, -1));

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_erreur.png"))); // NOI18N
        jPanel2.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 130, -1, -1));

        jLabel2.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgannulationbord.png"))); // NOI18N
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 770, 260));

        panelExercice.add(jPanel2, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelExercice, "exercice");

        panelRecherche.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(125, 161, 237));

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Recherche avancée ");
        jPanel5.add(jLabel3);

        panelRecherche.add(jPanel5, java.awt.BorderLayout.NORTH);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jLabel4.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel4.setText("Type d'engagement ");

        cboTypeengagement.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel5.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel5.setText("Compte budgétaire ");

        txtCompteBudgetaire.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0"))));

        jLabel6.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel6.setText("Date d'enregistrement entre le ");

        jLabel9.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel9.setText("et le ");

        jLabel10.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel10.setText("Date de validation entre le ");

        jLabel11.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel11.setText("et le ");

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire (intitulé)");

        dtpEnregistrementfin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dtpEnregistrementfinActionPerformed(evt);
            }
        });

        btnRechercheAvance.setText("Rechercher les dossiers répondant aux critères ");
        btnRechercheAvance.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRechercheAvance.setStyle(3);
        btnRechercheAvance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercheAvanceActionPerformed(evt);
            }
        });

        btnRetour.setForeground(new java.awt.Color(0, 0, 0));
        btnRetour.setText("<<< Retour     ");
        btnRetour.setCouleur(3);
        btnRetour.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel4)
                        .addGap(84, 84, 84)
                        .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, 155, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel5)
                        .addGap(87, 87, 87)
                        .addComponent(txtCompteBudgetaire, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel10)
                        .addGap(47, 47, 47)
                        .addComponent(dtpDateValidationDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(16, 16, 16)
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(dtpDateValidationFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 182, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, 296, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(113, 113, 113)
                        .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(223, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel4))
                    .addComponent(cboTypeengagement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(2, 2, 2)
                        .addComponent(jLabel5))
                    .addComponent(txtCompteBudgetaire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateValidationDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpDateValidationFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(8, 8, 8)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtBeneficiaire, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelRecherche.add(jPanel6, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelRecherche, "recherche");

        getContentPane().add(panelEntete, java.awt.BorderLayout.NORTH);

        panelTable.setLayout(new java.awt.BorderLayout());

        tableDossiers.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableDossiers.setGridColor(new java.awt.Color(204, 204, 204));
        tableDossiers.setRowHeight(24);
        tableDossiers.setSelectionBackground(new java.awt.Color(91, 118, 173));
        tableDossiers.setShowGrid(true);
        tableDossiers.getTableHeader().setReorderingAllowed(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listDossiers}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${check}"));
        columnBinding.setColumnName("Supprimé ?");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${type}"));
        columnBinding.setColumnName("T");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("N° Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Beneficiaire");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${motifAnnulationOrdo}"));
        columnBinding.setColumnName("Motif d'annulation");
        columnBinding.setColumnClass(String.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedDossier}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableDossiers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableDossiersMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setMinWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(30);
            tableDossiers.getColumnModel().getColumn(0).setMaxWidth(40);
            tableDossiers.getColumnModel().getColumn(1).setMinWidth(30);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableDossiers.getColumnModel().getColumn(1).setMaxWidth(30);
            tableDossiers.getColumnModel().getColumn(2).setMinWidth(100);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(100);
            tableDossiers.getColumnModel().getColumn(2).setMaxWidth(150);
            tableDossiers.getColumnModel().getColumn(3).setMinWidth(110);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(110);
            tableDossiers.getColumnModel().getColumn(3).setMaxWidth(110);
            tableDossiers.getColumnModel().getColumn(4).setMinWidth(200);
            tableDossiers.getColumnModel().getColumn(4).setPreferredWidth(200);
            tableDossiers.getColumnModel().getColumn(4).setMaxWidth(250);
        }

        panelTable.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        getContentPane().add(panelTable, java.awt.BorderLayout.CENTER);

        btnSupprimer.setText("Demander l'annulation des dossiers");
        btnSupprimer.setCouleur(1);
        btnSupprimer.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        panelSuppression.add(btnSupprimer);

        getContentPane().add(panelSuppression, java.awt.BorderLayout.PAGE_END);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void dtpEnregistrementfinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dtpEnregistrementfinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dtpEnregistrementfinActionPerformed

    private void btnRechercheAvanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercheAvanceActionPerformed
        // recherche des elements
        rechercher(true);
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRechercheAvanceActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // recherche des elements
        rechercher(false);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void btnOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOptionsActionPerformed
        // TODO add your handling code here:
        optionsRecherche();
    }//GEN-LAST:event_btnOptionsActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void txtnumDossierKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtnumDossierKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            rechercher(false);
        }
    }//GEN-LAST:event_txtnumDossierKeyReleased

    private void tableDossiersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableDossiersMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if ((this.openMode == DialogOpenMode.enregistre) || (this.openMode == DialogOpenMode.modifie)) {
                modifierDossier();
            } else if ((this.openMode == DialogOpenMode.reserve)) {
                reserver();
            } else if ((this.openMode == DialogOpenMode.reservation_annule)) {
                reservation_annuler();
            } else if ((this.openMode == DialogOpenMode.liquidation)) {
                liquidation();
            }
        }
    }//GEN-LAST:event_tableDossiersMouseClicked

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        demandeAnnulation();
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void demandeAnnulation() {
        List<VueEngagementDossier> selList = new ArrayList<>();
        for (VueEngagementDossier v : listDossiers) {
            if (v.isCheck()) {
                if(v.getMotifAnnulationOrdo() == null || v.getMotifAnnulationOrdo().trim().isEmpty()){
                    GrecoOptionPane.showWarningDialog("Saisir le motif d'annulation du dossier : "+v.getNumDossier());
                    return;
                }
                selList.add(v);
            }
        }
        StringBuffer s = new StringBuffer();
        s.append("Etes-vous sûr de bien vouloir demander l'annulation de ces dossiers : (" + selList.size() + ") ?");
        if (selList.size() > 0) {
            StringBuffer echecString = new StringBuffer();
            int errorcount = 0;
            echecString.append("Dossiers n'ayant pas pu etre supprimés \n\n");
            int res = GrecoOptionPane.showConfirmDialog(s.toString());
            if (res == JOptionPane.YES_OPTION) {
                glasspane.attente();
                for (VueEngagementDossier d : selList) {
                    try {
//                        GrecoServiceFactory.getEngagementService().supprimer(d.getEngagementID(),
//                                GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
//                        GrecoSession.notifications.success();
                    } catch (Exception e) {
                        errorcount++;
                        GrecoSession.notifications.echec();
                        echecString.append("\n");
                        echecString.append(d.getNumDossier());
                        echecString.append("  ");
                        echecString.append(d.getBeneficiaire());
                    }
                }
                if (errorcount > 0) {
                    GrecoOptionPane.showWarningDialog(echecString.toString());
                }
                glasspane.arret();
            }
            //recharger la liste
//            search(true);
        }else {
            GrecoOptionPane.showInformationDialog("Veuillez sélectionner les dossiers à annuler SVP");
        }
    }

    private void reservation_annuler() {
        try {
            if (selectedDossier == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier à annuler SVP");
                return;
            } else {
                ReservationAnnulationDialog dialog = new ReservationAnnulationDialog(me, true, selectedDossier);
                dialog.setVisible(true);
                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }

        } catch (Exception e) {
        }
    }

    private void valider() {
        try {
            if (selectedDossier == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier ");
                return;
            } else {
                Engagement e = GrecoServiceFactory.getEngagementService().getEngagement(selectedDossier.getEngagementID());
                if (e != null) {
                    EngagementVisaDialog dialog = new EngagementVisaDialog(me, true, e);
                    dialog.setVisible(true);
                }

                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }

        } catch (Exception e) {
        }
    }

    private void valider_annule() {
        try {
            if (selectedDossier == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier ");
                return;
            } else {
                int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir annuler votre VISA sur le dossier " + selectedDossier.getNumDossier() + " ?");
                if (res == JOptionPane.YES_OPTION) {
                    //motif de rejet
                    String motif = GrecoOptionPane.showInputDialog("Saisir le motif d'annulation SVP", "   Annuler le VISA CF   ");
                    if (!motif.isEmpty()) {
                        glasspane.attente();
                        try {
                            GrecoServiceFactory.getEngagementService().valider_annuler(selectedDossier.getEngagementID(),
                                    motif, GrecoSession.USER_CONNECTED.getLogin());
                            GrecoSession.notifications.success();
                        } catch (Exception e) {
                            GrecoSession.notifications.echec();
                            glasspane.arret();
                        }
                        glasspane.arret();
                    }
                }
                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }
        } catch (Exception e) {
        }
    }

    private void reserver() {
        try {
            if (selectedDossier == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier à réserver SVP");
                return;
            } else {
                ReservationDialog dialog = new ReservationDialog(me, true, selectedDossier);
                dialog.setVisible(true);
                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }

        } catch (Exception e) {
        }
    }

    private void liquidation() {
        try {
            if (selectedDossier == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier à liquider SVP");
                return;
            } else {
                EngagementLiquidationDialog dialog = new EngagementLiquidationDialog(me, true, null, 3);
                dialog.setVisible(true);
                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }

        } catch (Exception e) {
        }
    }

    private void validerLiquidation() {
        try {
            if (selectedDossier == null) {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier à valider SVP");
                return;
            } else {
                EngagementLiquidationDialog dialog = new EngagementLiquidationDialog(me, true, null, 3);
                dialog.setVisible(true);
                //rechercher les dossiers apres la saisie du nouveau
                rechercher(false);
            }

        } catch (Exception e) {
        }
    }

    private void nouveauDossier() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                if (o == null) {
                    GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
                    return;
                }
                Exercice ex = (Exercice) cboExercice.getSelectedItem();
                if (ex == null) {
                    GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
                    return;
                }
                try {
                    EngagementDialog dialog = new EngagementDialog(me, true, ex, o, null);
                    dialog.setVisible(true);
                    //rechercher les dossiers apres la saisie du nouveau
                    rechercher(false);
                } catch (Exception e) {
                }
            }
        });
    }

    private void modifierDossier() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                if (o == null) {
                    GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
                    return;
                }
                Exercice ex = (Exercice) cboExercice.getSelectedItem();
                if (ex == null) {
                    GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
                    return;
                }
                if (selectedDossier == null) {
                    GrecoOptionPane.showWarningDialog("Veuillez sélectionner un dossier à modifier ou à supprimer SVP");
                    return;
                }
                try {
                    glasspane.setText("Ouverture de l'engagement ...");
                    glasspane.attente();
                    Engagement e = GrecoServiceFactory.getEngagementService().getEngagement(selectedDossier.getEngagementID());
                    EngagementDialog dialog = new EngagementDialog(me, true, ex, o, e);
                    glasspane.arret();
                    dialog.setVisible(true);
                    //rechercher les dossiers apres la saisie du nouveau
                    rechercher(false);
                } catch (Exception e) {
                    glasspane.arret();
                }
            }
        });
    }

    private void rechercher(boolean advanced) {
//        glasspane.attente();
        search(advanced);
//        glasspane.arret();
    }

    private void optionsRecherche() {
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "recherche");
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(EngagementDemandeAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(EngagementDemandeAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(EngagementDemandeAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(EngagementDemandeAnnulationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new EngagementSearchDialog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnOptions;
    private cm.eusoworks.tools.ui.GButton btnRechercheAvance;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboTypeengagement;
    private org.jdesktop.swingx.JXDatePicker dtpDateValidationDebut;
    private org.jdesktop.swingx.JXDatePicker dtpDateValidationFin;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementDebut;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementfin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblRecherche;
    private javax.swing.JPanel panelEntete;
    private javax.swing.JPanel panelExercice;
    private javax.swing.JPanel panelRecherche;
    private javax.swing.JPanel panelSuppression;
    private javax.swing.JPanel panelTable;
    private org.jdesktop.swingx.JXTable tableDossiers;
    private javax.swing.JTextField txtBeneficiaire;
    private javax.swing.JFormattedTextField txtCompteBudgetaire;
    private javax.swing.JFormattedTextField txtnumDossier;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
