/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.Mandatement;
import cm.eusoworks.entities.view.VueLiquidationReport;
import cm.eusoworks.entities.view.VueMandatementReport;
import cm.eusoworks.entities.view.VuePaieBulletin;
import cm.eusoworks.entities.view.VuePaieRecapRubrique;
import cm.eusoworks.entities.view.VuePaieRubrique;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.util.DateUtil;
import com.siicore.util.StringUtil;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 *
 * @author ouethy
 */
public class EngagementMandatementDialog extends GrecoTemplateDialog {

    public static int MODE_ENREGISTRE = 1;
    public static int MODE_SUPPRESSION = 2;
    public static int MODE_VALIDATION = 3;
    public static int MODE_ANNULATION_VALIDATION = 4;
    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    GrecoReports fonctions = new GrecoReports();
    int mode = MODE_ENREGISTRE;

    Liquidation selectedLiquidation = null;
    Engagement currentEngagement;
    Mandatement currentMandatement;

    public EngagementMandatementDialog(JFrame parent, boolean modal, Liquidation liquidation, int modeValide) {
        super(parent, true);
        initComponents();
        this.mode = modeValide;
        setPreferredSize(new Dimension(850, 476));
        try {
            setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Mandatement du Dossier N°:  ");
        } catch (Exception e) {
        }

        initMode();
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.selectedLiquidation = liquidation;
        setLocationRelativeTo(null);

        initEngagementUI();

    }

    private void initMode() {
        switch (this.mode) {
            case 1:
                btnAction.setText("Enregistrer le mandatement");
                dtpDateMandatement.setDate(new Date());
                break;
        }
    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getTypeID());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {

        currentEngagement = GrecoServiceFactory.getEngagementService().getEngagement(selectedLiquidation.getEngagementID());
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        txtNumDossier.setText(currentEngagement.getNumDossier());
        txtObjet.setText(currentEngagement.getObjet().trim());

        btnBeneficiare.setText(currentEngagement.getBeneficiaire());

        try {
            txtMontant.setValue(currentEngagement.getMontantTTC());
        } catch (Exception e) {
        }

        txtMontantIR.setValue(selectedLiquidation.getMontantIR());
        txtMontantNAP.setValue(selectedLiquidation.getMontantNAP());
        txtMontantRG.setValue(selectedLiquidation.getMontantRG());
        txtMontantTVA.setValue(selectedLiquidation.getMontantTVA());

        // rechercher l'ordonnancement rattache a cette liquidation
        txtMontantMandatement.setValue(selectedLiquidation.getMontantTTC());
        loadMandatement();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        benefGroup = new javax.swing.ButtonGroup();
        radioGroup = new javax.swing.ButtonGroup();
        validGroup = new javax.swing.ButtonGroup();
        jSplitPane1 = new javax.swing.JSplitPane();
        panelInfos = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtMontantNAP = new javax.swing.JFormattedTextField();
        txtMontantIR = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtMontantTVA = new javax.swing.JFormattedTextField();
        txtMontantRG = new javax.swing.JFormattedTextField();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        dtpDateMandatement = new org.jdesktop.swingx.JXDatePicker();
        btnAction = new cm.eusoworks.tools.ui.GButton();
        btnFermer = new cm.eusoworks.tools.ui.GButton();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();
        agentComp = new cm.eusoworks.component.AgentComponent();
        jLabel3 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtMontantMandatement = new javax.swing.JFormattedTextField();
        gButton1 = new cm.eusoworks.tools.ui.GButton();
        jLabel10 = new javax.swing.JLabel();
        txtRIB = new javax.swing.JFormattedTextField();
        jPanel2 = new javax.swing.JPanel();
        rdbValidation = new javax.swing.JRadioButton();
        rdbRejet = new javax.swing.JRadioButton();
        jLabel15 = new javax.swing.JLabel();
        jXLabel1 = new org.jdesktop.swingx.JXLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtObservations = new javax.swing.JTextArea();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        btnValidation = new cm.eusoworks.tools.ui.GButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jXLabel2 = new org.jdesktop.swingx.JXLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtObservationsAnnulation = new javax.swing.JTextArea();
        btnRetourAnnuler = new cm.eusoworks.tools.ui.GButton();
        btnAnnulation = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Liquidation ");

        panelInfos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        panelInfos.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 181, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        panelInfos.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 180, -1));

        jLabel2.setText("Montant :");
        panelInfos.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 80, 30));

        txtMontant.setEnabled(false);
        panelInfos.add(txtMontant, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 180, 30));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        panelInfos.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        panelInfos.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        panelInfos.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 270, 30));
        panelInfos.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        panelInfos.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 180, 50));

        txtReference.setEditable(false);
        txtReference.setEnabled(false);
        panelInfos.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 180, -1));
        panelInfos.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 260, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        panelInfos.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 86, 22));

        jLabel1.setForeground(new java.awt.Color(51, 204, 0));
        jLabel1.setText("RUBRIQUES DE LIQUIDATION");
        panelInfos.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 247, -1));

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("NET A PAYER : ");
        panelInfos.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, 100, 30));

        txtMontantNAP.setEditable(false);
        txtMontantNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantNAP.setEnabled(false);
        txtMontantNAP.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        txtMontantNAP.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtMontantNAPActionPerformed(evt);
            }
        });
        panelInfos.add(txtMontantNAP, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 310, 160, 30));

        txtMontantIR.setEditable(false);
        txtMontantIR.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantIR.setEnabled(false);
        txtMontantIR.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        panelInfos.add(txtMontantIR, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 340, 160, 30));

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("IR : ");
        panelInfos.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 340, 110, 30));

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("TVA : ");
        panelInfos.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 110, 30));

        txtMontantTVA.setEditable(false);
        txtMontantTVA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantTVA.setEnabled(false);
        txtMontantTVA.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        panelInfos.add(txtMontantTVA, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 370, 160, 30));

        txtMontantRG.setEditable(false);
        txtMontantRG.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantRG.setEnabled(false);
        txtMontantRG.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        panelInfos.add(txtMontantRG, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 400, 160, 30));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("RETENUE GAR : ");
        panelInfos.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 400, 110, 30));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgannulationbord.png"))); // NOI18N
        panelInfos.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 540));

        jSplitPane1.setLeftComponent(panelInfos);

        pDetails.setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Date de mandatement : ");

        dtpDateMandatement.setEnabled(false);

        btnAction.setText("Enregistrer le mandatement");
        btnAction.setCouleur(2);
        btnAction.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAction.setStyle(2);
        btnAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionActionPerformed(evt);
            }
        });

        btnFermer.setText("Fermer");
        btnFermer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnFermer.setStyle(3);
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });

        btnSupprimer.setText("Supprimer");
        btnSupprimer.setCouleur(1);
        btnSupprimer.setStyle(2);
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });

        jLabel3.setText("Ordonnateur : ");

        jLabel6.setText("Montant TTC : ");

        txtMontantMandatement.setEditable(false);
        txtMontantMandatement.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.00"))));
        txtMontantMandatement.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N

        gButton1.setText("Imprimer l'Ordre de Paiement");
        gButton1.setStyle(2);
        gButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                gButton1ActionPerformed(evt);
            }
        });

        jLabel10.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel10.setText("RIB Bancaire : ");

        try {
            txtRIB.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-#####-###########-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtRIB.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(215, 215, 215)
                        .addComponent(btnAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnFermer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(28, 28, 28)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtMontantMandatement, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dtpDateMandatement, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, 506, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(28, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(gButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(71, 71, 71))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dtpDateMandatement, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMontantMandatement, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(gButton1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 253, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnFermer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(40, 40, 40))
        );

        pDetails.add(jPanel1, "liquidation");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        validGroup.add(rdbValidation);
        rdbValidation.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        rdbValidation.setForeground(new java.awt.Color(0, 153, 51));
        rdbValidation.setSelected(true);
        rdbValidation.setText("Valider la liquidation ");
        rdbValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbValidationActionPerformed(evt);
            }
        });

        validGroup.add(rdbRejet);
        rdbRejet.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rdbRejet.setForeground(new java.awt.Color(204, 51, 0));
        rdbRejet.setText("Rejeter ");

        jLabel15.setText("Observations ");

        jXLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jXLabel1.setText("La validation de cette liquidation permet d'effetuer le mandatement dans la suite de la procedure\n\nLe rejet arrete le processus de traitement de ce dossier a cette etape");
        jXLabel1.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jXLabel1.setLineWrap(true);

        txtObservations.setColumns(20);
        txtObservations.setRows(5);
        jScrollPane6.setViewportView(txtObservations);

        btnRetour.setCouleur(3);
        btnRetour.setLabel("Retour");
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        btnValidation.setText("Valider");
        btnValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnValidationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jXLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdbValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdbRejet, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(164, 164, 164)
                                .addComponent(btnValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jXLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(rdbValidation)
                        .addGap(39, 39, 39)
                        .addComponent(rdbRejet))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 84, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnValidation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pDetails.add(jPanel2, "validation");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setText("Observations ");

        jXLabel2.setForeground(new java.awt.Color(102, 0, 0));
        jXLabel2.setText("L'annulation de la validation n'est possible que si elle n'a pas encore fait l'objet d'un mandatement");
        jXLabel2.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jXLabel2.setLineWrap(true);

        txtObservationsAnnulation.setColumns(20);
        txtObservationsAnnulation.setRows(5);
        jScrollPane7.setViewportView(txtObservationsAnnulation);

        btnRetourAnnuler.setCouleur(3);
        btnRetourAnnuler.setLabel("Retour");
        btnRetourAnnuler.setStyle(1);
        btnRetourAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourAnnulerActionPerformed(evt);
            }
        });

        btnAnnulation.setText("Annuler la validation");
        btnAnnulation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jXLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 688, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(btnRetourAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(164, 164, 164)
                        .addComponent(btnAnnulation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jXLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 132, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRetourAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnnulation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pDetails.add(jPanel3, "annulation");

        jSplitPane1.setRightComponent(pDetails);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents


    private void btnActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionActionPerformed
        // TODO add your handling code here:
        switch (this.mode) {
            case 1:
                enregistrerLiquidation();
                break;
        }
    }//GEN-LAST:event_btnActionActionPerformed

    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnFermerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (selectedLiquidation != null) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer cette liquidation ?");
            if (res == JOptionPane.YES_OPTION) {
                supprimerLiquidation();
            }
        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void rdbValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbValidationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbValidationActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void btnValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnValidationActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir valider cette liquidation ?");
        if (res == JOptionPane.YES_OPTION) {
            valider();
        }
    }//GEN-LAST:event_btnValidationActionPerformed

    private void btnRetourAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourAnnulerActionPerformed
        // TODO add your handling code here:
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }//GEN-LAST:event_btnRetourAnnulerActionPerformed

    private void btnAnnulationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulationActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir annuler la validation de cette liquidation ?");
        if (res == JOptionPane.YES_OPTION) {
            annuler();
        }

    }//GEN-LAST:event_btnAnnulationActionPerformed

    private void txtMontantNAPActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtMontantNAPActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtMontantNAPActionPerformed

    private void gButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_gButton1ActionPerformed
        // TODO add your handling code here:
        imprimer(currentMandatement);
//        imprimerBulletinPaie();
        imprimerPaieRecap();
    }//GEN-LAST:event_gButton1ActionPerformed

    private void imprimer(final Mandatement b) {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VueMandatementReport> list = new ArrayList<>();
                            list = GrecoServiceFactory.getReportService().getMandatementReport(currentMandatement.getMandatementID());

                            GrecoImages mesImages = new GrecoImages();

                            parameters.put("logo", mesImages.logoOrganisation());
//                            parameters.put("user", GrecoSession.USER_CONNECTED.getLogin() + " [" + GrecoSession.USER_CONNECTED.getNomComplet() + "]");
                            parameters.put("napLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, b.getMontantMandate()) + "  francs CFA");
//                            parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitle());
//                            parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

                            JRHelper.viewReport(fonctions.mandat(), parameters, new JRBeanCollectionDataSource(list), null, null);

                        } catch (Exception ex) {
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void imprimerBulletinPaie() {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            glasspane.attente();
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            VuePaieBulletin fiche = GrecoServiceFactory.getReportService().getPaieBulletin(null, null, null, null);
                            if (fiche != null) {
                                List<VuePaieBulletin> bulletinPaie = new ArrayList<>();
                                bulletinPaie.add(fiche);

                                //sub reports stream
                                InputStream base = fonctions.paieRubriqueBase();
                                InputStream retenues = fonctions.paieRubriqueRetenues();
                                InputStream net = fonctions.paieRubriqueNet();

                                //sub report data collection
                                List<VuePaieRubrique> dataBase = GrecoServiceFactory.getReportService().getPaieRubriquesBase(null, null, null, null);
                                List<VuePaieRubrique> dataRetenues = GrecoServiceFactory.getReportService().getPaieRubriquesRetenues(null, null, null, null);
                                List<VuePaieRubrique> dataNet = GrecoServiceFactory.getReportService().getPaieRubriquesNet(null, null, null, null);

                                GrecoImages mesImages = new GrecoImages();

                                parameters.put("logo", mesImages.logoOrganisation());
                                parameters.put("montantEnLettre", StringUtil.getMontantEnLettre(Locale.FRENCH, fiche.getNetAPayer()) + "  francs CFA");
                                parameters.put("rubriqueBase", base);
                                parameters.put("rubriqueRetenues", retenues);
                                parameters.put("rubriqueNet", net);
                                parameters.put("dataCollectionBase", dataBase);
                                parameters.put("dataCollectionRetenue", dataRetenues);
                                parameters.put("dataCollectionNet", dataNet);

                                JRHelper.viewReport(fonctions.paieBulletin(), parameters, new JRBeanCollectionDataSource(bulletinPaie), null, null);
                            }

                        } catch (Exception ex) {
                            glasspane.arret();
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        glasspane.arret();
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void imprimerPaieRecap() {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SwingUtilities.invokeLater(new Runnable() {

            @Override
            public void run() {
                Thread con = new Thread(new Runnable() {

                    @Override
                    public void run() {
                        try {
                            glasspane.attente();
                            HashMap parameters = fonctions.mainParameters();
                            ////////////////////////////////////////////////
                            List<VuePaieRecapRubrique> fiche = GrecoServiceFactory.getReportService().getPaieRecapCotisations(null, null);
                            if (fiche != null) {
                                //sub reports stream
                                InputStream base = fonctions.paieRubriqueBase();
                                InputStream retenues = fonctions.paieRubriqueRetenues();
                                InputStream net = fonctions.paieRubriqueNet();

                                GrecoImages mesImages = new GrecoImages();

                                parameters.put("logo", mesImages.logoOrganisation());
                                parameters.put("periodeDebut", DateUtil.date(2016, 5, 1));
                                parameters.put("periodeFin", DateUtil.date(2016, 5, 31));
  

                                JRHelper.viewReport(fonctions.paieRecapCotisation(), parameters, new JRBeanCollectionDataSource(fiche), null, null);
                            }

                        } catch (Exception ex) {
                            glasspane.arret();
                            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                        }
                        glasspane.arret();
                        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
                    }
                }, "Performer");
                con.start();
            }
        });
    }

    private void annuler() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("Validation de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationValiderAnnuler(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedLiquidation.getLiquidationID(), txtObservationsAnnulation.getText().trim(), selectedLiquidation.getEngagementID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Liquidation annulee avec succès ");
                        btnAction.setVisible(false);
                        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE L'ANNULATION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void valider() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("Validation de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationValider(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedLiquidation.getLiquidationID(), txtObservations.getText().trim(), rdbValidation.isSelected() ? true : false, selectedLiquidation.getEngagementID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Liquidation validee avec succès ");
                        ((CardLayout) pDetails.getLayout()).show(pDetails, "validation");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA VALIDATION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private boolean controlData() {

        if (agentComp.getMatricule() == null || agentComp.getMatricule().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le matricule de l'ordonnateur ");
            return false;
        }

        return true;
    }

    private void enregistrerLiquidation() {
        if (controlData()) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        glasspane.setText("enregistrement de la dépense ....");
                        glasspane.attente();
                        if (currentMandatement == null) {
                            try {
                                GrecoServiceFactory.getEngagementService().MandatementEnregistrement(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                        null, selectedLiquidation.getLiquidationID(), agentComp.getMatricule(), BigDecimal.valueOf(((Number) txtMontantMandatement.getValue()).longValue()), txtRIB.getText());

                                loadMandatement();

                                GrecoSession.notifications.success();

                                GrecoOptionPane.showSuccessDialog("Mandatement enregistré avec succès ");
                                glasspane.arret();
                            } catch (GrecoException e) {
                                glasspane.arret();
                                GrecoSession.notifications.echec();
                                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                return;
                            } catch (Exception e) {
                                glasspane.arret();
                                e.printStackTrace();
                                GrecoSession.notifications.echec();
                                JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        } else {
                            try {

                                GrecoServiceFactory.getEngagementService().MandatementModifier(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                        currentMandatement.getMandatementID(), agentComp.getMatricule(), txtRIB.getText());
                                GrecoSession.notifications.success();
                                GrecoOptionPane.showSuccessDialog("Mandatement modifiee avec succès ");
                                glasspane.arret();
                            } catch (Exception e) {
                                glasspane.arret();
                                e.printStackTrace();
                                //currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }

                        glasspane.arret();

                    } catch (Exception e) {
                    }
                }
            });

        }
    }

    private void loadMandatement() {
        currentMandatement = GrecoServiceFactory.getEngagementService().MandatementFindByLiquidation(selectedLiquidation.getLiquidationID());
        if (currentEngagement != null) {
            agentComp.setMatricule(currentMandatement.getOrdonnateur());
            txtRIB.setText(currentMandatement.getRib());
        }

    }

    private void supprimerLiquidation() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("enregistrement de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationSupprimer(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC, selectedLiquidation.getLiquidationID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Cette Liquidation a bien ete supprime de la liste ");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA SUPPRESSION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void validerLiquidation() {
        ((CardLayout) pDetails.getLayout()).show(pDetails, "validation");
    }

    private void disableComponents() {
        txtMontantIR.setEditable(false);
        txtMontantNAP.setEditable(false);
        txtMontantRG.setEditable(false);
        txtMontantTVA.setEditable(false);
    }

    private void enableComponents() {
        txtMontantIR.setEditable(true);
        txtMontantNAP.setEditable(true);
        txtMontantRG.setEditable(true);
        txtMontantTVA.setEditable(true);
    }

    private void afficherCout() {
        try {
//            btnTTC.setText(txtMontant.getText());
        } catch (Exception e) {
        }
    }

    public Liquidation getSelectedLiquidation() {
        return selectedLiquidation;
    }

    public void setSelectedLiquidation(Liquidation selectedLiquidation) {
        this.selectedLiquidation = selectedLiquidation;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private javax.swing.ButtonGroup benefGroup;
    private cm.eusoworks.tools.ui.GButton btnAction;
    private cm.eusoworks.tools.ui.GButton btnAnnulation;
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnFermer;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private cm.eusoworks.tools.ui.GButton btnRetourAnnuler;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private cm.eusoworks.tools.ui.GButton btnValidation;
    private org.jdesktop.swingx.JXDatePicker dtpDateMandatement;
    private cm.eusoworks.tools.ui.GButton gButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSplitPane jSplitPane1;
    private org.jdesktop.swingx.JXLabel jXLabel1;
    private org.jdesktop.swingx.JXLabel jXLabel2;
    private javax.swing.JLabel lblType;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel panelInfos;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JRadioButton rdbRejet;
    private javax.swing.JRadioButton rdbValidation;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtMontantIR;
    private javax.swing.JFormattedTextField txtMontantMandatement;
    private javax.swing.JFormattedTextField txtMontantNAP;
    private javax.swing.JFormattedTextField txtMontantRG;
    private javax.swing.JFormattedTextField txtMontantTVA;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextArea txtObservations;
    private javax.swing.JTextArea txtObservationsAnnulation;
    private javax.swing.JFormattedTextField txtRIB;
    private javax.swing.JTextField txtReference;
    private javax.swing.ButtonGroup validGroup;
    // End of variables declaration//GEN-END:variables
}
