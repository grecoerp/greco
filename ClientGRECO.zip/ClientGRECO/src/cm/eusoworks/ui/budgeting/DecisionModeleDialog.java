/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import java.awt.Component;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextPane;

/**
 *
 * @author macbookair
 */
public class DecisionModeleDialog extends JDialog {

    /**
     * Creates new form NomenclatureDialog
     */
    String organisationID;
    String millesime;
    DecisionModele currentModele = null;

    public DecisionModeleDialog(JFrame parent, boolean modal, String organisationID, String millesime) {
        super(parent, modal);
        initComponents();
        this.organisationID = organisationID;
        this.millesime = millesime;
        setPreferredSize(new Dimension(857, 540));
        setLocationRelativeTo(null);
        setResizable(true);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Modèle de décision ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        loadModeles();
        pack();
    }

    public DecisionModeleDialog(JFrame parent, boolean modal, String organisationID, String millesime, DecisionModele modele) {
        this(parent, modal, organisationID, millesime);
        currentModele = modele;
        initModeleUI();
    }

    private void initModeleUI() {
        if (currentModele == null) {
            txtDescription.setText("");
            editeurModele.setText("");
            txtEntete1.setText(""); txtEntete1Us.setText("");
            txtEntete2.setText(""); txtEntete2Us.setText("");
            txtEntete3.setText(""); txtEntete3Us.setText("");
            txtEntete4.setText(""); txtEntete4Us.setText("");
            txtEntete5.setText(""); txtEntete5Us.setText("");
        } else {
            txtDescription.setText(currentModele.getDescription());
            editeurModele.setText(currentModele.getContenu());
            txtEntete1.setText(currentModele.getEntete1Fr());
            txtEntete2.setText(currentModele.getEntete2Fr());
            txtEntete3.setText(currentModele.getEntete3Fr());
            txtEntete4.setText(currentModele.getEntete4Fr());
            txtEntete5.setText(currentModele.getEntete5Fr());
            
            txtEntete1Us.setText(currentModele.getEntete1Us());
            txtEntete2Us.setText(currentModele.getEntete2Us());
            txtEntete3Us.setText(currentModele.getEntete3Us());
            txtEntete4Us.setText(currentModele.getEntete4Us());
            txtEntete5Us.setText(currentModele.getEntete5Us());
        }
    }

    private void loadModeles() {
        jListModele.removeAll();
        List<DecisionModele> l = new ArrayList<>();
        try {
            l = GrecoServiceFactory.getDecisionService().getModeleByOrganisation(millesime, organisationID);
        } catch (Exception e) {
            e.printStackTrace();
        }
        jListModele.setListData(l.toArray());

    }

    private boolean controlData() {
        boolean res = true;
        if (txtDescription.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir la description du modèle", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (editeurModele.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le modèle de décision à enregistrer", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return res;
    }

    private void remplirModele() {
        currentModele.setDescription(txtDescription.getText());
        currentModele.setContenu(editeurModele.getText());
        currentModele.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentModele.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
        
        currentModele.setMillesime(millesime);
        currentModele.setOrganisationID(organisationID);
        
        currentModele.setEntete1Fr(txtEntete1.getText().trim());
        currentModele.setEntete2Fr(txtEntete2.getText().trim());
        currentModele.setEntete3Fr(txtEntete3.getText().trim());
        currentModele.setEntete4Fr(txtEntete4.getText().trim());
        currentModele.setEntete5Fr(txtEntete5.getText().trim());
        
        currentModele.setEntete1Us(txtEntete1Us.getText().trim());
        currentModele.setEntete2Us(txtEntete2Us.getText().trim());
        currentModele.setEntete3Us(txtEntete3Us.getText().trim());
        currentModele.setEntete4Us(txtEntete4Us.getText().trim());
        currentModele.setEntete5Us(txtEntete5Us.getText().trim());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panelBouton = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        cboBalise = new javax.swing.JComboBox();
        btnInserer = new javax.swing.JButton();
        splitPane = new javax.swing.JSplitPane();
        pDetails = new javax.swing.JPanel();
        pDescription = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDescription = new javax.swing.JTextArea();
        jPanel1 = new javax.swing.JPanel();
        btnEnregistrer = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        editeurModele = new editor.EditeurTexte();
        jPanel3 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtEntete1 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtEntete2 = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtEntete3 = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtEntete4 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtEntete5 = new javax.swing.JTextArea();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jScrollPane8 = new javax.swing.JScrollPane();
        txtEntete1Us = new javax.swing.JTextArea();
        jScrollPane9 = new javax.swing.JScrollPane();
        txtEntete2Us = new javax.swing.JTextArea();
        jScrollPane10 = new javax.swing.JScrollPane();
        txtEntete3Us = new javax.swing.JTextArea();
        jScrollPane11 = new javax.swing.JScrollPane();
        txtEntete4Us = new javax.swing.JTextArea();
        jScrollPane12 = new javax.swing.JScrollPane();
        txtEntete5Us = new javax.swing.JTextArea();
        pListModele = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListModele = new javax.swing.JList();
        jPanel2 = new javax.swing.JPanel();
        btnAjouter = new javax.swing.JButton();
        btnDupliquer = new javax.swing.JButton();

        panelBouton.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Balises : ");
        panelBouton.add(jLabel2);

        cboBalise.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "@@reference@@", "@@objet@@", "@@signataire@@", "@@millesime@@", "@@BUDGET@@", "@@ORGANISATION@@", "@@beneficiaire@@", "@@montant@@", "@@montantEnLettre@@", "@@imputation@@" }));
        panelBouton.add(cboBalise);

        btnInserer.setText("Insérer ");
        btnInserer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInsererActionPerformed(evt);
            }
        });
        panelBouton.add(btnInserer);

        getContentPane().add(panelBouton, java.awt.BorderLayout.NORTH);

        splitPane.setDividerLocation(250);

        pDetails.setLayout(new java.awt.BorderLayout(0, 10));

        pDescription.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel1.setText("Description : ");
        pDescription.add(jLabel1);

        txtDescription.setColumns(80);
        txtDescription.setLineWrap(true);
        txtDescription.setRows(2);
        jScrollPane2.setViewportView(txtDescription);

        pDescription.add(jScrollPane2);

        pDetails.add(pDescription, java.awt.BorderLayout.NORTH);

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnregistrer);

        btnSupprimer.setText("Supprimer ");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel1.add(btnSupprimer);

        pDetails.add(jPanel1, java.awt.BorderLayout.SOUTH);

        jTabbedPane1.addTab("Contenu du modèle", editeurModele);

        jLabel8.setText("Entête 1 : ");

        txtEntete1.setColumns(20);
        txtEntete1.setLineWrap(true);
        txtEntete1.setRows(2);
        jScrollPane3.setViewportView(txtEntete1);

        jLabel9.setText("Entête 2 : ");

        txtEntete2.setColumns(20);
        txtEntete2.setLineWrap(true);
        txtEntete2.setRows(2);
        jScrollPane4.setViewportView(txtEntete2);

        jLabel10.setText("Entête 3 : ");

        txtEntete3.setColumns(20);
        txtEntete3.setLineWrap(true);
        txtEntete3.setRows(2);
        jScrollPane5.setViewportView(txtEntete3);

        jLabel11.setText("Entête 4 : ");

        txtEntete4.setColumns(20);
        txtEntete4.setLineWrap(true);
        txtEntete4.setRows(2);
        jScrollPane6.setViewportView(txtEntete4);

        jLabel12.setText("Entête 5 : ");

        txtEntete5.setColumns(20);
        txtEntete5.setLineWrap(true);
        txtEntete5.setRows(2);
        jScrollPane7.setViewportView(txtEntete5);

        jLabel3.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel3.setText("Francais");

        jLabel4.setFont(new java.awt.Font("Arial Black", 1, 14)); // NOI18N
        jLabel4.setText("Anglais");

        txtEntete1Us.setColumns(20);
        txtEntete1Us.setLineWrap(true);
        txtEntete1Us.setRows(2);
        jScrollPane8.setViewportView(txtEntete1Us);

        txtEntete2Us.setColumns(20);
        txtEntete2Us.setLineWrap(true);
        txtEntete2Us.setRows(2);
        jScrollPane9.setViewportView(txtEntete2Us);

        txtEntete3Us.setColumns(20);
        txtEntete3Us.setLineWrap(true);
        txtEntete3Us.setRows(2);
        jScrollPane10.setViewportView(txtEntete3Us);

        txtEntete4Us.setColumns(20);
        txtEntete4Us.setLineWrap(true);
        txtEntete4Us.setRows(2);
        jScrollPane11.setViewportView(txtEntete4Us);

        txtEntete5Us.setColumns(20);
        txtEntete5Us.setLineWrap(true);
        txtEntete5Us.setRows(2);
        jScrollPane12.setViewportView(txtEntete5Us);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane7))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane6))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane5))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane4))
                            .addGroup(jPanel3Layout.createSequentialGroup()
                                .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(161, 161, 161)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(jScrollPane12)
                        .addComponent(jScrollPane11)
                        .addComponent(jScrollPane10)
                        .addComponent(jScrollPane9)
                        .addComponent(jScrollPane8, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(64, 64, 64)
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 101, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(56, 56, 56))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel4)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(jScrollPane8)
                        .addGap(28, 28, 28)
                        .addComponent(jScrollPane9)
                        .addGap(32, 32, 32)
                        .addComponent(jScrollPane10)
                        .addGap(36, 36, 36)
                        .addComponent(jScrollPane11)
                        .addGap(32, 32, 32)
                        .addComponent(jScrollPane12, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane3)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(28, 28, 28)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane4)
                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane5)
                            .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(36, 36, 36)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane6)
                            .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jScrollPane7)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap())
        );

        jTabbedPane1.addTab("Entetes", jPanel3);

        pDetails.add(jTabbedPane1, java.awt.BorderLayout.CENTER);

        splitPane.setRightComponent(pDetails);

        pListModele.setLayout(new java.awt.BorderLayout());

        jListModele.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListModeleMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jListModele);

        pListModele.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnAjouter.setText("Nouveau modèle...");
        btnAjouter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAjouterActionPerformed(evt);
            }
        });
        jPanel2.add(btnAjouter);

        btnDupliquer.setText("Dupliquer ...");
        btnDupliquer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDupliquerActionPerformed(evt);
            }
        });
        jPanel2.add(btnDupliquer);

        pListModele.add(jPanel2, java.awt.BorderLayout.SOUTH);

        splitPane.setLeftComponent(pListModele);

        getContentPane().add(splitPane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAjouterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAjouterActionPerformed
        // TODO add your handling code here:
        currentModele = null;
        initModeleUI();
    }//GEN-LAST:event_btnAjouterActionPerformed

    private void jListModeleMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListModeleMouseClicked
        // TODO add your handling code here:
        if (jListModele.getSelectedValue() != null) {
            currentModele = (DecisionModele) jListModele.getSelectedValue();
            initModeleUI();
        }
    }//GEN-LAST:event_jListModeleMouseClicked

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (jListModele.getSelectedValue() != null) {
            DecisionModele d = (DecisionModele) jListModele.getSelectedValue();
            int res = JOptionPane.showConfirmDialog(this, "Etes-vous sûr de vouloir supprimer ce modele \n" + d.getDescription(), "GRECO", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getDecisionService().supprimerModele(d.getModeleID(), GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Décision supprimé avec succès ");
                    loadModeles();
                    currentModele = null;
                    initModeleUI();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentModele == null) {
                currentModele = new DecisionModele();
                remplirModele();
                try {
                    String newModeleID = GrecoServiceFactory.getDecisionService().ajouterModele(currentModele);
                    currentModele.setModeleID(newModeleID);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Modèle de décision enregistré avec succès ");
                    loadModeles();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            } else {
                remplirModele();
                try {
                    GrecoServiceFactory.getDecisionService().modifierModele(currentModele);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Modèle de décision enregistré avec succès ");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnInsererActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInsererActionPerformed
        // TODO add your handling code here:
        int i = editeurModele.getComponentCount();
        Component[] listComp = editeurModele.getComponents();
        for (int j = 0; j < i; j++) {
            Component object = listComp[j];
            if (object instanceof JScrollPane) {
                Component c = ((JScrollPane) object).getViewport().getComponent(0);
                JTextPane p = (JTextPane) c;
                int pos = p.getCaretPosition();
                String balise = (String) cboBalise.getSelectedItem();
                if (balise != null) {
                    try {
                        p.getDocument().insertString(pos, balise, null);
                        p.getDocument().insertString(pos + balise.length(), " ", null);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        }
    }//GEN-LAST:event_btnInsererActionPerformed

    private void btnDupliquerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDupliquerActionPerformed
        // TODO add your handling code here:
        if (jListModele.getSelectedValue() != null) {
            DecisionModele c = (DecisionModele) jListModele.getSelectedValue();
            int res = JOptionPane.showConfirmDialog(this, "Etes-vous sur de vouloir dupliquer ce modèle ?", "GRECO", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                String name = JOptionPane.showInputDialog("saisir une courte description du nouveau modèle à enregistrer");
                if (name != null && !name.isEmpty()) {
                    try {
                        GrecoServiceFactory.getDecisionService().dupliquerModele(c.getModeleID(), name);
                        GrecoSession.notifications.success();
                        loadModeles();
                        JOptionPane.showMessageDialog(this, "Le Modèle a été dupliqué ");
                    } catch (Exception e) {
                        GrecoSession.notifications.echec();
                        e.printStackTrace();
                        return;
                    }
                }
            }
        }
    }//GEN-LAST:event_btnDupliquerActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAjouter;
    private javax.swing.JButton btnDupliquer;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnInserer;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboBalise;
    private editor.EditeurTexte editeurModele;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jListModele;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane10;
    private javax.swing.JScrollPane jScrollPane11;
    private javax.swing.JScrollPane jScrollPane12;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JScrollPane jScrollPane8;
    private javax.swing.JScrollPane jScrollPane9;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JPanel pDescription;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListModele;
    private javax.swing.JPanel panelBouton;
    private javax.swing.JSplitPane splitPane;
    private javax.swing.JTextArea txtDescription;
    private javax.swing.JTextArea txtEntete1;
    private javax.swing.JTextArea txtEntete1Us;
    private javax.swing.JTextArea txtEntete2;
    private javax.swing.JTextArea txtEntete2Us;
    private javax.swing.JTextArea txtEntete3;
    private javax.swing.JTextArea txtEntete3Us;
    private javax.swing.JTextArea txtEntete4;
    private javax.swing.JTextArea txtEntete4Us;
    private javax.swing.JTextArea txtEntete5;
    private javax.swing.JTextArea txtEntete5Us;
    // End of variables declaration//GEN-END:variables
}
