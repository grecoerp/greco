/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.EngagementDroits;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueEngagementJournal;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WPanelFacture;
import com.siicore.util.StringUtil;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementVisaDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();
    Bca currentBca = null;
    OrdreMission currentOM = null;
    Decision currentDecision = null;
    Engagement currentEngagement = null;

    List<EngagementDroits> listRetenues = ObservableCollections.observableList(new ArrayList<EngagementDroits>());
    EngagementDroits selectedRetenue = null;

    List<VueEngagementJournal> journal = ObservableCollections.observableList(new ArrayList<VueEngagementJournal>());
    //composant
    WPanelFacture bcaFacture = null;

    public EngagementVisaDialog(JFrame parent, boolean modal, Engagement current) {
        super(parent, true);
        initComponents();
        setPreferredSize(new Dimension(504, 476));
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Dossier N°:  " + current.getNumDossier());
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.currentEngagement = current;
        setLocationRelativeTo(null);
        loadStructureOrganisation();
        loadJournal();
        initEngagementUI();
    }

    private void loadJournal() {
        List<VueEngagementJournal> list = GrecoServiceFactory.getEngagementService().getJournal(currentEngagement.getEngagementID());
        if (list != null & !list.isEmpty()) {
            journal.clear();
            for (VueEngagementJournal v : list) {
                journal.add(v);
            }
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(currentEngagement.getOrganisationID());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructureImputation.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructureImputation.setSelectedIndex(-1);
        }

    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getTypeID());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        txtNumDossier.setText(currentEngagement.getNumDossier());
        txtObjet.setText(currentEngagement.getObjet().trim());
        txtReference.setText(currentEngagement.getReference().trim());
        try {
            dtpDatesignature.setDate(currentEngagement.getDateSignature());
        } catch (Exception e) {
            dtpDatesignature.setDate(null);
        }
        btnBeneficiare.setText(currentEngagement.getBeneficiaire());

        try {
            txtMontant.setValue(currentEngagement.getMontantTTC());
        } catch (Exception e) {
        }
        //charger les droits a liquider
        List<EngagementDroits> list = GrecoServiceFactory.getDroitsService().listeDroitsEngagement(currentEngagement.getEngagementID());
        if (list != null && !list.isEmpty()) {
            listRetenues.clear();
            for (EngagementDroits e : list) {
                listRetenues.add(e);
            }
            calculerNAP();
        }

        //appeler une fonction pour calculer le nap et les retenues
        afficherCout();

        for (int i = 0; i < cboStructureImputation.getItemCount(); i++) {
            Structure s = (Structure) cboStructureImputation.getItemAt(i);
            if (s.getStructureID().equalsIgnoreCase(currentEngagement.getStructureID())) {
                cboStructureImputation.setSelectedIndex(i);
                break;
            }
        }

        for (int i = 0; i < cboTache.getItemCount(); i++) {
            Activite f = (Activite) cboTache.getItemAt(i);
            if (f.getActiviteID().equalsIgnoreCase(currentEngagement.getActiviteID())) {
                cboTache.setSelectedIndex(i);
                break;
            }
        }
        for (int i = 0; i < cboImputation.getItemCount(); i++) {
            OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
            if (f.getTacheID().equalsIgnoreCase(currentEngagement.getTacheID())) {
                cboImputation.setSelectedIndex(i);
                break;
            }
        }
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        radioGroup = new javax.swing.ButtonGroup();
        tabbedPane = new javax.swing.JTabbedPane();
        panelInfos = new javax.swing.JPanel();
        pDetailDecision = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnFermer = new cm.eusoworks.tools.ui.GButton();
        jPanel2 = new javax.swing.JPanel();
        pObjetCommande = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        cboStructureImputation = new javax.swing.JComboBox();
        btnTTC = new cm.eusoworks.tools.ui.GButton();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        txtSignataire = new javax.swing.JTextField();
        dtpDatesignature = new org.jdesktop.swingx.JXDatePicker();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        panelTaxes = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jScrollPane3 = new javax.swing.JScrollPane();
        tableTaxes = new org.jdesktop.swingx.JXTable();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txtNAP = new javax.swing.JFormattedTextField();
        jLabel15 = new javax.swing.JLabel();
        txtRetenues = new javax.swing.JFormattedTextField();
        txtRIB = new javax.swing.JFormattedTextField();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        lblVisa = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtVisaMotif = new javax.swing.JTextArea();
        lblVisaMotif = new javax.swing.JLabel();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        rdbRejet = new javax.swing.JRadioButton();
        rdbValider = new javax.swing.JRadioButton();
        txtCaptcha = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Saise des dossiers d'engagements");

        tabbedPane.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        panelInfos.setLayout(new java.awt.CardLayout());

        pDetailDecision.setBackground(new java.awt.Color(255, 255, 255));
        pDetailDecision.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 50, 5));

        btnFermer.setText("Fermer la fenêtre");
        btnFermer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });
        jPanel3.add(btnFermer);

        jPanel1.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 204));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "IMPUTATION", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Tahoma", 0, 12))); // NOI18N
        pObjetCommande.setOpaque(false);
        pObjetCommande.setLayout(null);

        jLabel6.setText("Tâche : ");
        pObjetCommande.add(jLabel6);
        jLabel6.setBounds(20, 60, 70, 30);

        jLabel3.setText("Imputation : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(20, 100, 80, 30);

        cboTache.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboTacheItemStateChanged(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(110, 60, 480, 30);

        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(110, 100, 290, 30);

        jLabel5.setText("Structure : ");
        pObjetCommande.add(jLabel5);
        jLabel5.setBounds(20, 20, 70, 30);

        cboStructureImputation.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                cboStructureImputationItemStateChanged(evt);
            }
        });
        pObjetCommande.add(cboStructureImputation);
        cboStructureImputation.setBounds(110, 20, 480, 30);

        btnTTC.setText("0");
        btnTTC.setCouleur(4);
        btnTTC.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnTTC.setStyle(3);
        btnTTC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnTTCMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnTTCMouseExited(evt);
            }
        });
        pObjetCommande.add(btnTTC);
        btnTTC.setBounds(410, 100, 180, 30);

        jPanel2.add(pObjetCommande, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 298, 600, 139));

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        jPanel2.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 227, 181, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        jPanel2.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 11, 166, -1));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        jPanel2.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        jPanel2.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 55, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        jPanel2.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 250, 590, 30));
        jPanel2.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(288, 11, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        jPanel2.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 55, 496, 50));

        txtReference.setEditable(false);
        jPanel2.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 119, 496, -1));

        txtSignataire.setEditable(false);
        jPanel2.add(txtSignataire, new org.netbeans.lib.awtextra.AbsoluteConstraints(104, 153, 496, -1));

        dtpDatesignature.setEditable(false);
        jPanel2.add(dtpDatesignature, new org.netbeans.lib.awtextra.AbsoluteConstraints(106, 187, 177, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        jPanel2.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 86, 22));

        jLabel19.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel19.setText("signataire : ");
        jPanel2.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 154, 86, 22));

        jLabel20.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel20.setText("Date : ");
        jPanel2.add(jLabel20, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 187, 86, 22));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgEngagementConsultation.png"))); // NOI18N
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 630, 440));

        jPanel1.add(jPanel2, java.awt.BorderLayout.CENTER);

        pDetailDecision.add(jPanel1, java.awt.BorderLayout.CENTER);

        panelInfos.add(pDetailDecision, "dossier");

        tabbedPane.addTab("Informations générales", panelInfos);

        panelTaxes.setBackground(new java.awt.Color(255, 255, 255));

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(153, 153, 153));
        jLabel9.setText("MONTANT TTC :");

        txtMontant.setEditable(false);
        txtMontant.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtMontant.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtMontant.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        tableTaxes.setShowGrid(true);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listRetenues}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableTaxes);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Rubrique");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${sigleFr}"));
        columnBinding.setColumnName("Abbréviation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${taux}"));
        columnBinding.setColumnName("Taux (%)");
        columnBinding.setColumnClass(Double.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedRetenue}"), tableTaxes, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jScrollPane3.setViewportView(tableTaxes);
        if (tableTaxes.getColumnModel().getColumnCount() > 0) {
            tableTaxes.getColumnModel().getColumn(1).setResizable(false);
            tableTaxes.getColumnModel().getColumn(1).setPreferredWidth(30);
            tableTaxes.getColumnModel().getColumn(2).setResizable(false);
            tableTaxes.getColumnModel().getColumn(2).setPreferredWidth(30);
        }

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(153, 153, 153));
        jLabel13.setText("TAXES ET AUTRES RETENUES");

        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel14.setForeground(new java.awt.Color(153, 153, 153));
        jLabel14.setText("MONTANT NET A PAYER :");

        txtNAP.setEditable(false);
        txtNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtNAP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtNAP.setEnabled(false);
        txtNAP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(153, 153, 153));
        jLabel15.setText("TOTAL DES RETENUES :");

        txtRetenues.setEditable(false);
        txtRetenues.setForeground(new java.awt.Color(102, 0, 102));
        txtRetenues.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtRetenues.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRetenues.setEnabled(false);
        txtRetenues.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N

        try {
            txtRIB.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####-#####-###########-##")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtRIB.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N

        jLabel1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel1.setText("RIB DU FOURNISSEUR :");

        lblVisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/visadenied.png"))); // NOI18N

        txtVisaMotif.setColumns(20);
        txtVisaMotif.setLineWrap(true);
        txtVisaMotif.setRows(2);
        jScrollPane1.setViewportView(txtVisaMotif);

        lblVisaMotif.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblVisaMotif.setText("Observations ");

        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.setCouleur(4);
        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });

        radioGroup.add(rdbRejet);
        rdbRejet.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rdbRejet.setForeground(new java.awt.Color(255, 0, 0));
        rdbRejet.setSelected(true);
        rdbRejet.setText("Rejeter");
        rdbRejet.setOpaque(false);
        rdbRejet.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbRejetActionPerformed(evt);
            }
        });

        radioGroup.add(rdbValider);
        rdbValider.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        rdbValider.setForeground(new java.awt.Color(51, 153, 0));
        rdbValider.setText("Valider");
        rdbValider.setOpaque(false);
        rdbValider.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbValiderActionPerformed(evt);
            }
        });

        txtCaptcha.setEditable(false);
        txtCaptcha.setBackground(new java.awt.Color(204, 204, 204));
        txtCaptcha.setFont(new java.awt.Font("Arial Black", 0, 24)); // NOI18N
        txtCaptcha.setHorizontalAlignment(javax.swing.JTextField.CENTER);

        javax.swing.GroupLayout panelTaxesLayout = new javax.swing.GroupLayout(panelTaxes);
        panelTaxes.setLayout(panelTaxesLayout);
        panelTaxesLayout.setHorizontalGroup(
            panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTaxesLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtMontant, javax.swing.GroupLayout.PREFERRED_SIZE, 181, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 600, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(20, Short.MAX_VALUE))
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 264, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 436, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(rdbRejet, javax.swing.GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE)
                            .addComponent(rdbValider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(panelTaxesLayout.createSequentialGroup()
                                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                        .addComponent(jLabel14, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(jLabel15, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 173, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)
                                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtRetenues, javax.swing.GroupLayout.PREFERRED_SIZE, 178, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(panelTaxesLayout.createSequentialGroup()
                                .addComponent(lblVisa)
                                .addGap(18, 18, 18)
                                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(panelTaxesLayout.createSequentialGroup()
                                        .addComponent(txtCaptcha, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 448, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblVisaMotif, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 434, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        panelTaxesLayout.setVerticalGroup(
            panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTaxesLayout.createSequentialGroup()
                .addGap(7, 7, 7)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtMontant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel13)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addGap(41, 41, 41)
                        .addComponent(rdbRejet)
                        .addGap(18, 18, 18)
                        .addComponent(rdbValider)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtRetenues, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNAP, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtRIB, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblVisa)
                    .addGroup(panelTaxesLayout.createSequentialGroup()
                        .addComponent(lblVisaMotif)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 51, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addGroup(panelTaxesLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtCaptcha, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        tabbedPane.addTab("VISAS", panelTaxes);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnTTCMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTTCMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_btnTTCMouseEntered

    private void btnTTCMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnTTCMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_btnTTCMouseExited

    private void calculerNAP() {
        Number ttc;
        if (txtMontant.getValue() == null) {
            ttc = new Long(0);
        } else {
            ttc = (Number) txtMontant.getValue();
        }
        long taxe = 0;
        //si la liste des retenues existe, recalculer les montants
        if (listRetenues.size() > 0) {
            List<EngagementDroits> l = new ArrayList<>();
            for (EngagementDroits d : listRetenues) {
                double t = d.getTaux();
                double m = t * ttc.doubleValue() / 100;
                d.setMontant(new BigDecimal(m));
                l.add(d);
            }
            listRetenues.clear();
            for (EngagementDroits e : l) {
                listRetenues.add(e);
            }
        }
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (EngagementDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
        long nap = ttc.longValue() - taxe;
        txtNAP.setValue(nap);
    }

    private void getRetenue() {

        long taxe = 0;
        //recuperer les taxes
        if (listRetenues.size() > 0) {
            for (EngagementDroits droit : listRetenues) {
                taxe = taxe + droit.getMontant().longValue();
            }
        }
        txtRetenues.setValue(taxe);
    }
    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnFermerActionPerformed

    private void cboStructureImputationItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboStructureImputationItemStateChanged
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructureImputation.getSelectedItem();
        } catch (Exception ex) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(currentEngagement.getMillesime(),
                        currentEngagement.getOrganisationID(), s.getStructureID());
            } catch (Exception exx) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureImputationItemStateChanged

    private void cboTacheItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_cboTacheItemStateChanged
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();

        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheItemStateChanged

    private void rdbRejetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbRejetActionPerformed
        // TODO add your handling code here:
        lblVisaMotif.setText("Motif(s) du rejet de ce dossier");
        lblVisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/visadenied.png")));
    }//GEN-LAST:event_rdbRejetActionPerformed

    private void rdbValiderActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbValiderActionPerformed
        // TODO add your handling code here:
        lblVisaMotif.setText("Visa avec Observations ?");
        lblVisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/visaapprouved.png")));
    }//GEN-LAST:event_rdbValiderActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        valider();
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void valider() {
        String msg = "";
        boolean activer = false;
        if (rdbRejet.isSelected()) {
            if (txtVisaMotif.getText().trim().isEmpty()) {
                GrecoOptionPane.showInformationDialog("Vous n'avez pas saisit le motif du rejet");
                return;
            }
            activer = false;
            msg = "Etes-vous sur de vouloir rejeter ce dossier ?";
        } else {
            activer = true;
            msg = "Etes-vous sur de certains de vouloir valider ce dossier ?";
        }
        String motif = txtVisaMotif.getText().trim();
        int res = GrecoOptionPane.showConfirmDialog(msg);
        if (res == JOptionPane.YES_OPTION) {
            glasspane.attente();
            try {
                String captcha = "";
                captcha = GrecoServiceFactory.getEngagementService().valider(currentEngagement.getEngagementID(), activer, motif, GrecoSession.USER_CONNECTED.getLogin());
                GrecoSession.notifications.success();
                txtCaptcha.setText(captcha);
                btnEnregistrer.setVisible(false);
                GrecoOptionPane.showSuccessDialog( "Opération effectuée avec succès. \n Veuillez marquer le numéro suivant sur la fiche d'engagement : \n"+captcha);
                glasspane.arret();
            } catch (Exception e) {
                txtCaptcha.setText("");
                GrecoSession.notifications.echec();
                GrecoOptionPane.showErrorDialog("Echec de l'opération");
                glasspane.arret();
            }
        }
    }

    private void disableComponents() {
        btnBeneficiare.setEnabled(false);
        cboStructureImputation.setEnabled(false);
        cboTache.setEnabled(false);
        cboImputation.setEnabled(false);
        txtMontant.setEnabled(true);
        txtObjet.setEditable(false);
        txtReference.setEditable(false);
        txtSignataire.setEditable(false);
    }

    private void afficherCout() {
        try {
            btnTTC.setText(txtMontant.getText());
        } catch (Exception e) {
        }
    }

    public List<EngagementDroits> getListRetenues() {
        return listRetenues;
    }

    public void setListRetenues(List<EngagementDroits> listRetenues) {
        this.listRetenues = listRetenues;
    }

    public EngagementDroits getSelectedRetenue() {
        return selectedRetenue;
    }

    public void setSelectedRetenue(EngagementDroits selectedRetenue) {
        this.selectedRetenue = selectedRetenue;
    }

    public List<VueEngagementJournal> getJournal() {
        return journal;
    }

    public void setJournal(List<VueEngagementJournal> journal) {
        this.journal = journal;
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnFermer;
    private cm.eusoworks.tools.ui.GButton btnTTC;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboStructureImputation;
    private javax.swing.JComboBox cboTache;
    private org.jdesktop.swingx.JXDatePicker dtpDatesignature;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblType;
    private javax.swing.JLabel lblVisa;
    private javax.swing.JLabel lblVisaMotif;
    private javax.swing.JPanel pDetailDecision;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel panelInfos;
    private javax.swing.JPanel panelTaxes;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JRadioButton rdbRejet;
    private javax.swing.JRadioButton rdbValider;
    private javax.swing.JTabbedPane tabbedPane;
    private org.jdesktop.swingx.JXTable tableTaxes;
    private javax.swing.JTextField txtCaptcha;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtNAP;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JFormattedTextField txtRIB;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtRetenues;
    private javax.swing.JTextField txtSignataire;
    private javax.swing.JTextArea txtVisaMotif;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
