/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.model.Bordereau;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.view.VueEngagementBordereau;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.ui.renderer.EngagementTypeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Image;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.TableColumn;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class BordereauEditionDialog extends GrecoTemplateDialog {

    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Bordereau> listBordereaux = ObservableCollections.observableList(new ArrayList<Bordereau>());
    Bordereau selectedDossier = null;

    GrecoReports fonctions = new GrecoReports();
    int wSearch = 600, hSearch = 300;
    List<VueEngagementDossier> listDossiersBordereau = ObservableCollections.observableList(new ArrayList<VueEngagementDossier>());
    VueEngagementDossier selectedDossierBordereau = null;
//    private CurvesProgressPanel glasspane;

    public BordereauEditionDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        setSize(780, 600);
        glasspane.setText("Recherche des dossiers correspondant aux critères ...");
        loadOrganisations();
        loadExercicesBudgetisation();
        setLocationRelativeTo(null);

        TableColumn colorColumn = tableDossiers.getColumn(3);
        colorColumn.setCellRenderer(new EngagementTypeRenderer());
    }

    public List<Bordereau> getListBordereaux() {
        return listBordereaux;
    }

    public void setListBordereaux(List<Bordereau> listBordereaux) {
        this.listBordereaux = listBordereaux;
    }

    public Bordereau getSelectedDossier() {
        return selectedDossier;
    }

    public void setSelectedDossier(Bordereau selectedDossier) {
        this.selectedDossier = selectedDossier;
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            } else {
                cboExercice.setSelectedIndex(cboExercice.getItemCount() - 1);
            }
        }
    }

    private boolean controlData() {
        boolean res = false;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'organisme");
            return false;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            JOptionPane.showMessageDialog(null, "Veuillez sélectionner l'exercice budgétaire");
            return false;
        }
        return true;
    }

    private void search(boolean advanced) {
        String organisationID = ((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID();
        String millesime = ((Exercice) cboExercice.getSelectedItem()).getMillesime();
        String numdossier = txtNumDossier.getText().trim().isEmpty() ? null : txtNumDossier.getText().trim();
        String numBordereau = txtNumBordereau.getText().trim().isEmpty() ? null : txtNumBordereau.getText().trim();
        Date dateEnregDebut = dtpEnregistrementDebut.getDate();
        Date dateEnregFin = dtpEnregistrementfin.getDate();
        int typeTransmission = panelBordereau.getTypeTransmission();

        glasspane.attente();
        List<Bordereau> l = GrecoServiceFactory.getEngagementService().getBordereauTransmission(organisationID, millesime, numBordereau, numdossier, dateEnregDebut, dateEnregFin, typeTransmission);
        listBordereaux.clear();
        listDossiersBordereau.clear();
        if (l != null) {
            for (Bordereau b : l) {
                listBordereaux.add(b);
            }
        }
        glasspane.arret();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        panelEntete = new javax.swing.JPanel();
        panelExercice = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        lblTypeBordereau = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        dtpEnregistrementDebut = new org.jdesktop.swingx.JXDatePicker();
        jLabel14 = new javax.swing.JLabel();
        dtpEnregistrementfin = new org.jdesktop.swingx.JXDatePicker();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtNumBordereau = new javax.swing.JTextField();
        txtNumDossier = new javax.swing.JTextField();
        btnOptions = new cm.eusoworks.tools.ui.GButton();
        btnRechercher = new cm.eusoworks.tools.ui.GButton();
        panelRecherche = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        btnRechercheAvance = new cm.eusoworks.tools.ui.GButton();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        panelBordereau = new cm.eusoworks.component.BordereauPanelComponent();
        jSplitPane1 = new javax.swing.JSplitPane();
        scrollBordereau = new javax.swing.JScrollPane();
        tableBordereaux = new org.jdesktop.swingx.JXTable();
        scrollDossier = new javax.swing.JScrollPane();
        tableDossiers = new org.jdesktop.swingx.JXTable();
        panelSuppression = new javax.swing.JPanel();
        btnEditionBordereau = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Réedition des bordereaux de transmission des dossiers");

        panelEntete.setLayout(new java.awt.CardLayout());

        panelExercice.setBackground(new java.awt.Color(255, 255, 255));
        panelExercice.setLayout(new java.awt.BorderLayout());

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        jLabel8.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel8.setText("Exercice ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        lblTypeBordereau.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTypeBordereau.setForeground(new java.awt.Color(91, 118, 173));
        lblTypeBordereau.setText("aucun type de bodereau sélectionné");

        jLabel13.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel13.setText("Date entre le ");

        jLabel14.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel14.setText("et le ");

        dtpEnregistrementfin.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dtpEnregistrementfinActionPerformed(evt);
            }
        });

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setText("N° de bordereau : ");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("N° de dossier : ");

        btnOptions.setForeground(new java.awt.Color(0, 0, 0));
        btnOptions.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/search.png"))); // NOI18N
        btnOptions.setText("Choisir le Type de bordereau ...");
        btnOptions.setCouleur(3);
        btnOptions.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        btnOptions.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOptionsActionPerformed(evt);
            }
        });

        btnRechercher.setText("Rechercher  ...");
        btnRechercher.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        btnRechercher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercherActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 92, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(16, 16, 16)
                                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(334, Short.MAX_VALUE))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txtNumBordereau)
                            .addComponent(txtNumDossier, javax.swing.GroupLayout.DEFAULT_SIZE, 185, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRechercher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(134, 134, 134))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(lblTypeBordereau, javax.swing.GroupLayout.PREFERRED_SIZE, 387, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel7))
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(dtpEnregistrementfin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNumBordereau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtNumDossier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(btnRechercher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(26, 26, 26)
                .addComponent(lblTypeBordereau)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        panelExercice.add(jPanel2, java.awt.BorderLayout.WEST);

        panelEntete.add(panelExercice, "exercice");

        panelRecherche.setLayout(new java.awt.BorderLayout());

        jPanel5.setBackground(new java.awt.Color(125, 161, 237));

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Choix du type de bordereau");
        jPanel5.add(jLabel3);

        panelRecherche.add(jPanel5, java.awt.BorderLayout.NORTH);

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        btnRechercheAvance.setText("Rechercher ");
        btnRechercheAvance.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRechercheAvance.setStyle(3);
        btnRechercheAvance.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRechercheAvanceActionPerformed(evt);
            }
        });

        btnRetour.setForeground(new java.awt.Color(0, 0, 0));
        btnRetour.setText("<<< Retour     ");
        btnRetour.setCouleur(3);
        btnRetour.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(panelBordereau, javax.swing.GroupLayout.PREFERRED_SIZE, 442, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 128, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 126, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panelBordereau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addGap(78, 78, 78)
                        .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btnRechercheAvance, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        panelRecherche.add(jPanel6, java.awt.BorderLayout.CENTER);

        panelEntete.add(panelRecherche, "recherche");

        getContentPane().add(panelEntete, java.awt.BorderLayout.NORTH);

        jSplitPane1.setDividerLocation(400);

        tableBordereaux.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        tableBordereaux.setGridColor(new java.awt.Color(204, 204, 204));
        tableBordereaux.setRowHeight(24);
        tableBordereaux.setSelectionBackground(new java.awt.Color(91, 118, 173));
        tableBordereaux.setShowGrid(true);
        tableBordereaux.getTableHeader().setReorderingAllowed(false);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listBordereaux}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableBordereaux);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numBordereau}"));
        columnBinding.setColumnName("N° Bordereau");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateGeneration}"));
        columnBinding.setColumnName("Date Generation");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${source}"));
        columnBinding.setColumnName("Source");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${destination}"));
        columnBinding.setColumnName("Destination");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedDossier}"), tableBordereaux, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableBordereaux.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableBordereauxMouseClicked(evt);
            }
        });
        scrollBordereau.setViewportView(tableBordereaux);
        if (tableBordereaux.getColumnModel().getColumnCount() > 0) {
            tableBordereaux.getColumnModel().getColumn(0).setResizable(false);
            tableBordereaux.getColumnModel().getColumn(0).setPreferredWidth(100);
            tableBordereaux.getColumnModel().getColumn(1).setPreferredWidth(75);
            tableBordereaux.getColumnModel().getColumn(3).setMinWidth(110);
            tableBordereaux.getColumnModel().getColumn(3).setPreferredWidth(110);
            tableBordereaux.getColumnModel().getColumn(3).setMaxWidth(110);
        }

        jSplitPane1.setLeftComponent(scrollBordereau);

        tableDossiers.setRowHeight(27);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listDossiersBordereau}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numDossier}"));
        columnBinding.setColumnName("N° Dossier");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montant}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${beneficiaire}"));
        columnBinding.setColumnName("Benef");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${type}"));
        columnBinding.setColumnName("Type");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedDossierBordereau}"), tableDossiers, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableDossiers.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableDossiersMouseClicked(evt);
            }
        });
        scrollDossier.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setResizable(false);
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(80);
        }

        jSplitPane1.setRightComponent(scrollDossier);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        panelSuppression.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnEditionBordereau.setText("Réediter le bordereau sélectionné");
        btnEditionBordereau.setCouleur(2);
        btnEditionBordereau.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEditionBordereau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEditionBordereauActionPerformed(evt);
            }
        });
        panelSuppression.add(btnEditionBordereau);

        getContentPane().add(panelSuppression, java.awt.BorderLayout.PAGE_END);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            Exercice e = null;
            try {
                e = (Exercice) cboExercice.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            Organisation o = null;
            try {
                o = (Organisation) cboOrganisation.getSelectedItem();
            } catch (Exception ex) {
            }
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void btnRechercheAvanceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercheAvanceActionPerformed
        // recherche des elements
        if (panelBordereau.getTypeTransmission() == -1) {
            lblTypeBordereau.setText("Aucun type de bordereau choisit");
        } else {
            lblTypeBordereau.setText(EtatDossier.getString(panelBordereau.getTypeTransmission()));
        }
        rechercher(true);
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
    }//GEN-LAST:event_btnRechercheAvanceActionPerformed

    private void btnRechercherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRechercherActionPerformed
        // recherche des elements
        if (panelBordereau.getTypeTransmission() == -1) {
            lblTypeBordereau.setText("Aucun type de bordereau choisit");
        } else {
            lblTypeBordereau.setText(EtatDossier.getString(panelBordereau.getTypeTransmission()));
        }
        rechercher(true);
    }//GEN-LAST:event_btnRechercherActionPerformed

    private void btnOptionsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOptionsActionPerformed
        // TODO add your handling code here:
        optionsRecherche();
    }//GEN-LAST:event_btnOptionsActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "exercice");
        if (panelBordereau.getTypeTransmission() == -1) {
            lblTypeBordereau.setText("Aucun type de bordereau choisit");
        } else {
            lblTypeBordereau.setText(EtatDossier.getString(panelBordereau.getTypeTransmission()));
        }
    }//GEN-LAST:event_btnRetourActionPerformed

    private void tableBordereauxMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableBordereauxMouseClicked
        // TODO add your handling code here:
        listDossiersBordereau.clear();
        if (selectedDossier != null) {
            List<VueEngagementDossier> listDossiers = null;
            glasspane.attente();
            try {
                listDossiers = GrecoServiceFactory.getEngagementService().getDossiersByNumBordereau(selectedDossier.getNumBordereau());
                if (listDossiers != null && !listDossiers.isEmpty()) {
                    for (VueEngagementDossier v : listDossiers) {
                        listDossiersBordereau.add(v);
                    }
                }
            } catch (Exception e) {
                glasspane.arret();
            }
            glasspane.arret();
        }
    }//GEN-LAST:event_tableBordereauxMouseClicked

    private void btnEditionBordereauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEditionBordereauActionPerformed
        // TODO add your handling code here:
        if (selectedDossier != null) {
            impressionBordereau(selectedDossier.getNumBordereau());
        }
    }//GEN-LAST:event_btnEditionBordereauActionPerformed

    private void impressionBordereau(String code) {
        //impression du bordereau
        Organisation o = new Organisation();
        try {
            o = GrecoServiceFactory.getOrganisationService().rechercherByCode("01").get(0);
        } catch (Exception e) {
        }

        GrecoReports fonctions = new GrecoReports();
        GrecoImages logo = new GrecoImages();
        Image armoirieCM = null;//new siiResources.Images();
        HashMap parameters = fonctions.mainParameters();
        parameters.put("chapitreFR", o.getLibelleFr());
        parameters.put("chapitreEN", o.getLibelleUs());
        parameters.put("armoirieCM", armoirieCM);
        parameters.put("logo", logo.logoOrganisation());
        parameters.put("app", logo.logo());
        parameters.put("user", GrecoSession.USER_CONNECTED.getNom());
        parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
        parameters.put("PARAM_DispositifUS", "basé sur le noyau GRECO");

        List<VueEngagementBordereau> contentBordereau = new ArrayList<>();

        contentBordereau = GrecoServiceFactory.getReportService().getBordereauTransmission(code);
        JRDataSource dataSource = new JRBeanCollectionDataSource(contentBordereau);
        try {
            JasperPrint print = JasperFillManager.fillReport(fonctions.bordereauTransmission(), parameters, dataSource);
            JRHelper.viewReport(print);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void dtpEnregistrementfinActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dtpEnregistrementfinActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dtpEnregistrementfinActionPerformed

    private void tableDossiersMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableDossiersMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if (selectedDossierBordereau != null) {
                final Engagement e = GrecoServiceFactory.getEngagementService().getEngagementByDossier(selectedDossierBordereau.getNumDossier());
                if (e != null) {
                    glasspane.attente();
                    SwingUtilities.invokeLater(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                EngagementConsultationDialog frame = new EngagementConsultationDialog(me, true, e);
                                frame.setVisible(true);
                            } catch (Exception e) {
                                e.printStackTrace();
                            }
                        }
                    });
                    glasspane.arret();
                }
            }
        }
    }//GEN-LAST:event_tableDossiersMouseClicked

    private void rechercher(boolean advanced) {
        search(advanced);
    }

    private void optionsRecherche() {
        ((CardLayout) panelEntete.getLayout()).show(panelEntete, "recherche");
    }

    public List<VueEngagementDossier> getListDossiersBordereau() {
        return listDossiersBordereau;
    }

    public void setListDossiersBordereau(List<VueEngagementDossier> listDossiersBordereau) {
        this.listDossiersBordereau = listDossiersBordereau;
    }

    public VueEngagementDossier getSelectedDossierBordereau() {
        return selectedDossierBordereau;
    }

    public void setSelectedDossierBordereau(VueEngagementDossier selectedDossierBordereau) {
        this.selectedDossierBordereau = selectedDossierBordereau;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BordereauEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BordereauEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BordereauEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BordereauEditionDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
//                new EngagementSearchDialog().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnEditionBordereau;
    private cm.eusoworks.tools.ui.GButton btnOptions;
    private cm.eusoworks.tools.ui.GButton btnRechercheAvance;
    private cm.eusoworks.tools.ui.GButton btnRechercher;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementDebut;
    private org.jdesktop.swingx.JXDatePicker dtpEnregistrementfin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblTypeBordereau;
    private cm.eusoworks.component.BordereauPanelComponent panelBordereau;
    private javax.swing.JPanel panelEntete;
    private javax.swing.JPanel panelExercice;
    private javax.swing.JPanel panelRecherche;
    private javax.swing.JPanel panelSuppression;
    private javax.swing.JScrollPane scrollBordereau;
    private javax.swing.JScrollPane scrollDossier;
    private org.jdesktop.swingx.JXTable tableBordereaux;
    private org.jdesktop.swingx.JXTable tableDossiers;
    private javax.swing.JTextField txtNumBordereau;
    private javax.swing.JTextField txtNumDossier;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
