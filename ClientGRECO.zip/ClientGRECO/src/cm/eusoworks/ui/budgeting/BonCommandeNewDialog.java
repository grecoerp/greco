/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.BcaArticles;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.facture.WLigneFacture;
import java.awt.Toolkit;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
public class BonCommandeNewDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    String millesime;
    String organisationID;
    Bca currentBCA = null;
    Organisation org;

    public BonCommandeNewDialog(JFrame parent, boolean modal, String millesime, Organisation org, Bca bca) {
        super(parent, modal);
        initComponents();
        bcaFacture.setActiverRefFacture(false);
        bcaFacture.setActiverObjetFacture(false);
        this.millesime = millesime;
        this.org = org;
        this.organisationID = org.getOrganisationID();
        loadStructureOrganisation();
        loadFournisseurs();
        AutoCompleteDecorator.decorate(cboFournisseur);
        //AutoCompleteDecorator.decorate(cboImputation);
        this.currentBCA = bca;
        initBCAInfos();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Etablissement d'un bon de commande administratif ");
        pack();
        setSize(750, 560);
        setLocationRelativeTo(null);
    }

    private void initBCAInfos() {
        txtEntete1.setText(this.org.getLibelle());
        if (currentBCA != null) {
            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                Structure s = (Structure) cboStructure.getItemAt(i);
                if (s.getStructureID().equalsIgnoreCase(currentBCA.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboFournisseur.getItemCount(); i++) {
                Fournisseur f = (Fournisseur) cboFournisseur.getItemAt(i);
                if (f.getFournisseurID().equalsIgnoreCase(currentBCA.getFournisseurID())) {
                    cboFournisseur.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboTache.getItemCount(); i++) {
                Activite f = (Activite) cboTache.getItemAt(i);
                if (f.getActiviteID().equalsIgnoreCase(currentBCA.getActiviteID())) {
                    cboTache.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboImputation.getItemCount(); i++) {
                OperationBudgetaire f = (OperationBudgetaire) cboImputation.getItemAt(i);
                if (f.getTacheID().equalsIgnoreCase(currentBCA.getTacheID())) {
                    cboImputation.setSelectedIndex(i);
                    break;
                }
            }
            txtObjet.setText(currentBCA.getObjet());
            txtReference.setText(currentBCA.getReference());
            agentComp.setMatricule(currentBCA.getMatriculeOrdo());
            txtEntete1.setText(currentBCA.getEntete1());
            txtEntete2.setText(currentBCA.getEntete2());
            txtEntete3.setText(currentBCA.getEntete3());
            txtEntete4.setText(currentBCA.getEntete4());
            txtEntete5.setText(currentBCA.getEntete5());

            /**
             * *******chargements des lignes de la facture *****************
             */
            bcaFacture.setTauxIR(currentBCA.getTauxIR());
            bcaFacture.setTauxTVA(currentBCA.getTauxTVA());
            List<BcaArticles> list = new ArrayList<>();
            list = GrecoServiceFactory.getBonCommandeService().getBCALignes(currentBCA.getBcaID());
            int ordre = 0;
            for (BcaArticles l : list) {
                WLigneFacture wlf = new WLigneFacture(l.getAmId(), ordre);
                wlf.setReference(l.getRefArticle());
                wlf.setDesignation(l.getDesignation());
                wlf.setId(l.getAmId());
                wlf.setIndex(l.getNumOrdre());
                wlf.setPrixUnitaire(l.getPrixUnitaire().doubleValue());
                Double marge = l.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                wlf.setPuMax(l.getPrixUnitaire().doubleValue() + marge);
                wlf.setPuMin(Double.valueOf(0));
                wlf.setQuantite((int) l.getQuantite());
                bcaFacture.getLignesFacture().ajouterLigne(wlf);
                ordre++;
            }
        }
    }

    private void loadStructureOrganisation() {

        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(this.organisationID);
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
            cboStructure.setSelectedIndex(-1);
        }

    }

    private void loadFournisseurs() {
        List<Fournisseur> list = new ArrayList<>();
        try {
            list = GrecoServiceFactory.getFournisseurService().getListFournisseur();
        } catch (Exception e) {
            list = null;
        }

        if (list != null && !list.isEmpty()) {
            cboFournisseur.setModel(new DefaultComboBoxModel(list.toArray()));
            cboFournisseur.setSelectedIndex(-1);
        }
    }

    private void remplirBCA() {
        Structure s = (Structure) cboStructure.getSelectedItem();
        Fournisseur f = (Fournisseur) cboFournisseur.getSelectedItem();
        Activite a = (Activite) cboTache.getSelectedItem();
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();

        currentBCA.setObjet(txtObjet.getText().trim());
        currentBCA.setReference(txtReference.getText().trim());

        currentBCA.setEntete1(txtEntete1.getText().trim());
        currentBCA.setEntete2(txtEntete2.getText().trim());
        currentBCA.setEntete3(txtEntete3.getText().trim());
        currentBCA.setEntete4(txtEntete4.getText().trim());
        currentBCA.setEntete5(txtEntete5.getText().trim());

        currentBCA.setFournisseurID(f.getFournisseurID());
        currentBCA.setTacheID(o.getTacheID());
        currentBCA.setMillesime(millesime);
        currentBCA.setOrganisationID(organisationID);
        currentBCA.setMatriculeOrdo(agentComp.getMatricule());
        currentBCA.setStructureID(s.getStructureID());
        currentBCA.setActiviteID(a.getActiviteID());

        currentBCA.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentBCA.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        //montant de la facture
        List<WLigneFacture> l = bcaFacture.getLignesFacture().getLignes();
        if (l != null && !l.isEmpty()) {
            currentBCA.setMontantTTC(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantTTC()));
            currentBCA.setMontantHT(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantHT()));
            currentBCA.setTauxIR((float) bcaFacture.getTauxIR());
            currentBCA.setTauxTVA((float) bcaFacture.getTauxTVA());
            currentBCA.setNap(BigDecimal.valueOf(bcaFacture.getLignesFacture().getMontantNetAPayer()));
        }
    }

    private boolean controlData() {
        boolean res = true;
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner la structure");
            return false;
        }
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
        if (f == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner le prestataire de service");
            return false;
        }
        if (agentComp.getMatricule() == null) {
            GrecoOptionPane.showErrorDialog("Veuillez saisir le matricule de l'ordonnateur ");
            return false;
        }
        Activite a = (Activite) cboTache.getSelectedItem();
        if (a == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner la tâche ");
            return false;
        }
        OperationBudgetaire o = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner l'imputation ");
            return false;
        }
        if (txtObjet.getText().isEmpty()) {
            GrecoOptionPane.showErrorDialog("Veuillez sélectionner l'objet de la commande ");
            return false;
        }
        //existence des articles commandes 
        List<WLigneFacture> articles = new ArrayList<>();
        List<WLigneFacture> l = bcaFacture.getLignesFacture().getLignes();
        if (l != null && !l.isEmpty()) {
            for (WLigneFacture art : l) {
                if (art.getReference() != null && !(art.getDesignation()).isEmpty()) {
                    articles.add(art);
                }
            }
        }
        if (articles.isEmpty()) {
            GrecoOptionPane.showErrorDialog("Vous n'avez pas saisi les articles commandes SVP");
            return false;
        }

        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        ongletBCA = new javax.swing.JTabbedPane();
        pAccueil = new javax.swing.JPanel();
        pOrdonnateur = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        agentComp = new cm.eusoworks.component.AgentComponent();
        pPrestataire = new javax.swing.JPanel();
        cboFournisseur = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtAdresseFournisseur = new javax.swing.JTextArea();
        pObjetCommande = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        cboImputation = new javax.swing.JComboBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        jLabel7 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        btnEnregistrer = new javax.swing.JButton();
        jLabel21 = new javax.swing.JLabel();
        txtDisponible = new javax.swing.JFormattedTextField();
        pDetailCommande = new javax.swing.JPanel();
        bcaFacture = new com.siicore.facture.WPanelFacture(){
            @Override
            public void loadRowData(WLigneFacture wlf) {
                chargerLigne(wlf);
            }

            @Override
            public boolean validationFacture() {
                return validerFacture();
            }
        };
        pEntete = new javax.swing.JPanel();
        jLabel8 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtEntete1 = new javax.swing.JTextArea();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtEntete2 = new javax.swing.JTextArea();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtEntete3 = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtEntete4 = new javax.swing.JTextArea();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtEntete5 = new javax.swing.JTextArea();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        ongletBCA.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);

        pAccueil.setLayout(null);

        pOrdonnateur.setBackground(new java.awt.Color(227, 226, 226));
        pOrdonnateur.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Ordonnateur ", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 204))); // NOI18N

        jLabel5.setText("Structure : ");

        jLabel6.setText("Matricule : ");

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pOrdonnateurLayout = new javax.swing.GroupLayout(pOrdonnateur);
        pOrdonnateur.setLayout(pOrdonnateurLayout);
        pOrdonnateurLayout.setHorizontalGroup(
            pOrdonnateurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOrdonnateurLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pOrdonnateurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pOrdonnateurLayout.createSequentialGroup()
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cboStructure, javax.swing.GroupLayout.PREFERRED_SIZE, 247, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pOrdonnateurLayout.createSequentialGroup()
                        .addComponent(jLabel6)
                        .addGap(18, 18, 18)
                        .addComponent(agentComp, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(17, Short.MAX_VALUE))
        );
        pOrdonnateurLayout.setVerticalGroup(
            pOrdonnateurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOrdonnateurLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pOrdonnateurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cboStructure, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pOrdonnateurLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(agentComp, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(29, Short.MAX_VALUE))
        );

        pAccueil.add(pOrdonnateur);
        pOrdonnateur.setBounds(0, 11, 386, 130);

        pPrestataire.setBackground(new java.awt.Color(226, 226, 226));
        pPrestataire.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Prestataire de service", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 255))); // NOI18N

        cboFournisseur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboFournisseurActionPerformed(evt);
            }
        });

        txtAdresseFournisseur.setEditable(false);
        txtAdresseFournisseur.setColumns(20);
        txtAdresseFournisseur.setFont(new java.awt.Font("Arial", 0, 10)); // NOI18N
        txtAdresseFournisseur.setLineWrap(true);
        txtAdresseFournisseur.setRows(2);
        jScrollPane1.setViewportView(txtAdresseFournisseur);

        javax.swing.GroupLayout pPrestataireLayout = new javax.swing.GroupLayout(pPrestataire);
        pPrestataire.setLayout(pPrestataireLayout);
        pPrestataireLayout.setHorizontalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pPrestataireLayout.createSequentialGroup()
                .addGroup(pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboFournisseur, 0, 272, Short.MAX_VALUE)
                    .addGroup(pPrestataireLayout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(jScrollPane1)))
                .addContainerGap())
        );
        pPrestataireLayout.setVerticalGroup(
            pPrestataireLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pPrestataireLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cboFournisseur, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(13, Short.MAX_VALUE))
        );

        pAccueil.add(pPrestataire);
        pPrestataire.setBounds(386, 11, 290, 126);

        pObjetCommande.setBackground(new java.awt.Color(204, 204, 255));
        pObjetCommande.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Objet de la commande ...", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Lucida Grande", 0, 13), new java.awt.Color(0, 102, 204))); // NOI18N
        pObjetCommande.setLayout(null);

        jLabel2.setText("Tâche : ");
        pObjetCommande.add(jLabel2);
        jLabel2.setBounds(16, 24, 87, 20);

        jLabel3.setText("Reference : ");
        pObjetCommande.add(jLabel3);
        jLabel3.setBounds(20, 160, 87, 30);

        jLabel4.setText("Objet : ");
        pObjetCommande.add(jLabel4);
        jLabel4.setBounds(16, 94, 87, 50);

        cboTache.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboTacheActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboTache);
        cboTache.setBounds(113, 27, 550, 27);

        cboImputation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboImputationActionPerformed(evt);
            }
        });
        pObjetCommande.add(cboImputation);
        cboImputation.setBounds(113, 65, 550, 20);

        txtObjet.setColumns(20);
        txtObjet.setRows(2);
        jScrollPane2.setViewportView(txtObjet);

        pObjetCommande.add(jScrollPane2);
        jScrollPane2.setBounds(113, 94, 550, 50);

        jLabel7.setText("Imputation : ");
        pObjetCommande.add(jLabel7);
        jLabel7.setBounds(16, 62, 87, 30);

        txtReference.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtReference.setText("______________/2016/MPT/SG/DAG/SDBM/SBM-FST");
        pObjetCommande.add(txtReference);
        txtReference.setBounds(110, 156, 560, 40);

        pAccueil.add(pObjetCommande);
        pObjetCommande.setBounds(0, 152, 688, 210);

        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        pAccueil.add(btnEnregistrer);
        btnEnregistrer.setBounds(455, 367, 166, 43);

        jLabel21.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(204, 0, 0));
        jLabel21.setText("Disponible : ");
        pAccueil.add(jLabel21);
        jLabel21.setBounds(20, 370, 90, 30);

        txtDisponible.setEditable(false);
        txtDisponible.setForeground(new java.awt.Color(255, 0, 0));
        txtDisponible.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtDisponible.setFont(new java.awt.Font("Tahoma", 0, 22)); // NOI18N
        pAccueil.add(txtDisponible);
        txtDisponible.setBounds(120, 370, 260, 30);

        ongletBCA.addTab("Commande", pAccueil);

        pDetailCommande.setLayout(new java.awt.BorderLayout());
        pDetailCommande.add(bcaFacture, java.awt.BorderLayout.CENTER);

        ongletBCA.addTab("Articles commandés", pDetailCommande);

        jLabel8.setText("Entête 1 : ");

        txtEntete1.setColumns(20);
        txtEntete1.setRows(2);
        jScrollPane3.setViewportView(txtEntete1);

        jLabel9.setText("Entête 2 : ");

        txtEntete2.setColumns(20);
        txtEntete2.setRows(2);
        jScrollPane4.setViewportView(txtEntete2);

        jLabel10.setText("Entête 3 : ");

        txtEntete3.setColumns(20);
        txtEntete3.setRows(2);
        jScrollPane5.setViewportView(txtEntete3);

        jLabel11.setText("Entête 4 : ");

        txtEntete4.setColumns(20);
        txtEntete4.setRows(2);
        jScrollPane6.setViewportView(txtEntete4);

        jLabel12.setText("Entête 5 : ");

        txtEntete5.setColumns(20);
        txtEntete5.setRows(2);
        jScrollPane7.setViewportView(txtEntete5);

        javax.swing.GroupLayout pEnteteLayout = new javax.swing.GroupLayout(pEntete);
        pEntete.setLayout(pEnteteLayout);
        pEnteteLayout.setHorizontalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 552, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(131, Short.MAX_VALUE))
        );
        pEnteteLayout.setVerticalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane3)
                    .addComponent(jLabel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(28, 28, 28)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane4)
                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane5)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane6)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jScrollPane7)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(81, Short.MAX_VALUE))
        );

        ongletBCA.addTab("Entete de  présentation", pEntete);

        getContentPane().add(ongletBCA, "card3");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboFournisseurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboFournisseurActionPerformed
        // TODO add your handling code here:
        Fournisseur f = null;
        try {
            f = (Fournisseur) cboFournisseur.getSelectedItem();
        } catch (Exception e) {
            f = null;
        }
        if (f != null) {
            txtAdresseFournisseur.setText(f.getRaisonSociale() + " \n" + f.getAdresse() + "\n RC :" + f.getRegistreCommerce());
        }

    }//GEN-LAST:event_cboFournisseurActionPerformed

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        Structure s = null;
        try {
            s = (Structure) cboStructure.getSelectedItem();
        } catch (Exception e) {
            s = null;
        }
        if (s != null) {
            cboTache.removeAll();
            cboImputation.removeAll();
            List<Activite> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getActiviteService().getListTacheBudgetiseByStructure(millesime, organisationID, s.getStructureID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(l.toArray()));
                cboTache.setSelectedIndex(-1);
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {

            Number dispo;
            if (txtDisponible.getValue() != null) {
                dispo = (Number) txtDisponible.getValue();
                double ttc = bcaFacture.getLignesFacture().getMontantTTC();
                if (ttc > dispo.doubleValue()) {
                    int rep = GrecoOptionPane.showConfirmDialog("Le disponible sur l'imputation est insuffant pour couvrir ce BCA. Voulez vous neanmoins enregistrer le BCA ?");
                    if (rep == JOptionPane.NO_OPTION) {
                        return;
                    }
                }
                if (currentBCA == null) {
                    currentBCA = new Bca();
                    remplirBCA();
                    try {
                        String newBcaID = GrecoServiceFactory.getBonCommandeService().ajouter(currentBCA);
                        currentBCA.setBcaID(newBcaID);
//                    GrecoSession.notifications.success();
//                    JOptionPane.showMessageDialog(this, "Bon de commande enregistré avec succès ");
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    }
                } else {
                    remplirBCA();
                    try {
                        GrecoServiceFactory.getBonCommandeService().modifier(currentBCA);
//                    GrecoSession.notifications.success();
//                    JOptionPane.showMessageDialog(this, "Bon de commande modifié ");
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    }
                }
                //enregistrement des lignes du bca
                try {
                    //suppression de toutes les lignes
                    GrecoServiceFactory.getBonCommandeService().supprimerTousArticles(currentBCA.getBcaID(),
                            GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
                    //enregistrement des nouvelles
                    int nbLigneErronees = 0;
                    List<WLigneFacture> list = bcaFacture.getLignesFacture().getLignes();
                    for (WLigneFacture wlf : list) {
                        if (wlf.getReference() != null && !StringUtil.isNullOrEmpty(wlf.getDesignation())) {
                            BcaArticles l = new BcaArticles();
                            l.setAmId(wlf.getId().toString());
                            l.setBcaID(currentBCA.getBcaID());
                            l.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                            l.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                            l.setPrixUnitaire(BigDecimal.valueOf(wlf.getPrixUnitaire()));
                            l.setQuantite(wlf.getQuantite());

                            try {
                                GrecoServiceFactory.getBonCommandeService().ajouterLigne(l);
                            } catch (Exception e) {
                                nbLigneErronees++;
                            }
                        }
                    }
                    if (nbLigneErronees > 0) {
                        Toolkit.getDefaultToolkit().beep();
                        GrecoOptionPane.showWarningDialog(
                                "Enregistrement du bon de commande avec erreurs \n" + nbLigneErronees + "ligne(s) de la facture n'ont pas pu être enregistrées.\n\n" + "Veuillez réessayer SVP ...");
                    } else {
                        GrecoOptionPane.showSuccessDialog("Bon de commande enregistré avec succès");
                    }
                } catch (Exception e) {
                }
            }

        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void cboTacheActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboTacheActionPerformed
        // TODO add your handling code here:
        Activite a = null;
        cboImputation.removeAll();
        try {
            a = (Activite) cboTache.getSelectedItem();
        } catch (Exception e) {
            a = null;
        }
        if (a != null) {
            List<OperationBudgetaire> l = new ArrayList<>();
            try {
                l = GrecoServiceFactory.getOperationService().getListOperationByActivite(a.getActiviteID());
            } catch (Exception e) {
                l = null;
            }
            if (l != null && !l.isEmpty()) {
                cboImputation.setModel(new DefaultComboBoxModel(l.toArray()));
                cboImputation.setSelectedIndex(-1);
            }
        }
    }//GEN-LAST:event_cboTacheActionPerformed

    private void cboImputationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboImputationActionPerformed
        // TODO add your handling code here:
        OperationBudgetaire op = (OperationBudgetaire) cboImputation.getSelectedItem();
        if (op != null) {
            BigDecimal montant = GrecoServiceFactory.getOperationService().getDisponible(op);
            txtDisponible.setValue(montant);
        }
    }//GEN-LAST:event_cboImputationActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.component.AgentComponent agentComp;
    private com.siicore.facture.WPanelFacture bcaFacture;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JComboBox cboFournisseur;
    private javax.swing.JComboBox cboImputation;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JTabbedPane ongletBCA;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pDetailCommande;
    private javax.swing.JPanel pEntete;
    private javax.swing.JPanel pObjetCommande;
    private javax.swing.JPanel pOrdonnateur;
    private javax.swing.JPanel pPrestataire;
    private javax.swing.JTextArea txtAdresseFournisseur;
    private javax.swing.JFormattedTextField txtDisponible;
    private javax.swing.JTextArea txtEntete1;
    private javax.swing.JTextArea txtEntete2;
    private javax.swing.JTextArea txtEntete3;
    private javax.swing.JTextArea txtEntete4;
    private javax.swing.JTextArea txtEntete5;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    // End of variables declaration//GEN-END:variables

    public void chargerLigne(WLigneFacture wlf) {
        try {
            Article am = GrecoServiceFactory.getMercurialeService().getArticle(millesime, wlf.getReference().toString());
            if (am != null) {
                wlf.setDesignation(am.getDesignation());
                Double prixLocalite = am.getPrixDeReference().doubleValue();
                Double marge = am.getPrixDeReference().doubleValue() * GrecoSession.MERCURIALE_MARGE;
                wlf.setPrixUnitaire(prixLocalite);
                wlf.setPuMin(Double.valueOf(0));
                wlf.setPuMax(prixLocalite + marge);
                wlf.setQuantite(1);
                wlf.setReference(am.getRefArticle());
                wlf.setId(am.getAmId());
            }
        } catch (Exception e) {

        }
    }

    public boolean validerFacture() {
        return true;
    }

}
