/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.EngagementDroits;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.renderer.LiquidationStatusRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableColumnModel;
import javax.swing.table.TableColumn;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author ouethy
 */
public class EngagementLiquidationDialog extends GrecoTemplateDialog {

    public static int MODE_ENREGISTRE = 1;
    public static int MODE_SUPPRESSION = 2;
    public static int MODE_VALIDATION = 3;
    public static int MODE_ANNULATION_VALIDATION = 4;
    /**
     * Creates new form MercurialeBrowser
     */
    JFrame me;
    List<Date> list;
    GrecoReports fonctions = new GrecoReports();
    Bca currentBca = null;
    OrdreMission currentOM = null;
    Decision currentDecision = null;
    VueEngagementDossier currentEngagement = null;
    int mode = MODE_ENREGISTRE;

    List<EngagementDroits> listRetenues = ObservableCollections.observableList(new ArrayList<EngagementDroits>());
    EngagementDroits selectedRetenue = null;

    List<Liquidation> listLiquidations = ObservableCollections.observableList(new ArrayList<Liquidation>());
    Liquidation selectedLiquidation = null;

    String currentLiquidationID = null;

    public EngagementLiquidationDialog(JFrame parent, boolean modal, VueEngagementDossier current, int modeValide) {
        super(parent, true);
        initComponents();
        this.mode = modeValide;
        setPreferredSize(new Dimension(850, 476));
        try {
            setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Liquidation du Dossier N°:  " + current.getNumDossier());
        } catch (Exception e) {
        }

        initMode();
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        this.currentEngagement = current;
        setLocationRelativeTo(null);

        TableColumn colorColumn = ((DefaultTableColumnModel) tblLiquidationListe.getColumnModel()).getColumn(3);
        colorColumn.setCellRenderer(new LiquidationStatusRenderer());

        initEngagementUI();

    }

    private void initMode() {
        switch (this.mode) {
            case 1:
                btnAction.setText("Enregistrer une liquidation");
                dtpDateLiquidation.setDate(new Date());
                break;
            case 3:
                disableComponents();
                btnSupprimer.setVisible(false);
                btnAnnuler.setVisible(false);
                btnAction.setText("Valider la liquidation");
                break;
            case 4:
                disableComponents();
                btnSupprimer.setVisible(false);
                btnAnnuler.setVisible(false);
                btnAction.setText("Annuler la Validation");
                break;
        }
    }

    private void afficheIcon() {
        int t = Integer.valueOf(currentEngagement.getType());
        switch (t) {
            case 1: //BC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eBC.png"))));
                break;
            case 2: //LC
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eLC.png"))));
                break;
            case 3: //MA
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eMA.png"))));
                break;
            case 4: //OM
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eOM.png"))));
                break;
            case 5: //MAD
                lblType.setIcon((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/eDE.png"))));
                break;
        }

    }

    private void initEngagementUI() {
        try {
            afficheIcon();
        } catch (Exception e) {
        }
        txtNumDossier.setText(currentEngagement.getNumDossier());
        txtObjet.setText(currentEngagement.getObjet().trim());
        txtReference.setText(currentEngagement.getCompte());

        btnBeneficiare.setText(currentEngagement.getBeneficiaire());

        try {
            txtMontant.setValue(currentEngagement.getMontant());
        } catch (Exception e) {
        }
        // charger les liquidations deja enregistrees
        loadLiquidations();;

        //charger les droits a liquider
////        List<EngagementDroits> list = GrecoServiceFactory.getDroitsService().listeDroitsEngagement(currentEngagement.getEngagementID());
////        if (list != null && !list.isEmpty()) {
////            listRetenues.clear();
////            for (EngagementDroits e : list) {
////                listRetenues.add(e);
////            }
////            calculerNAP();
////        }
        //appeler une fonction pour calculer le nap et les retenues
//        afficherCout();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        benefGroup = new javax.swing.ButtonGroup();
        radioGroup = new javax.swing.ButtonGroup();
        validGroup = new javax.swing.ButtonGroup();
        jSplitPane1 = new javax.swing.JSplitPane();
        panelInfos = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtMontant = new javax.swing.JFormattedTextField();
        jLabel17 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        btnBeneficiare = new cm.eusoworks.tools.ui.GButton();
        lblType = new javax.swing.JLabel();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        txtReference = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel18 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblLiquidationListe = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        txtMontantRestantLiquider = new javax.swing.JFormattedTextField();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        txtMontantNAP = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        txtMontantIR = new javax.swing.JFormattedTextField();
        jLabel7 = new javax.swing.JLabel();
        txtMontantTVA = new javax.swing.JFormattedTextField();
        jLabel9 = new javax.swing.JLabel();
        txtMontantRG = new javax.swing.JFormattedTextField();
        jLabel10 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtPieces = new javax.swing.JTextArea();
        jLabel11 = new javax.swing.JLabel();
        jScrollPane4 = new javax.swing.JScrollPane();
        txtLivrables = new javax.swing.JTextArea();
        jLabel13 = new javax.swing.JLabel();
        dtpDateLiquidation = new org.jdesktop.swingx.JXDatePicker();
        btnAnnuler = new cm.eusoworks.tools.ui.GButton();
        btnAction = new cm.eusoworks.tools.ui.GButton();
        btnFermer = new cm.eusoworks.tools.ui.GButton();
        jLabel14 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtObjetLiquidation = new javax.swing.JTextArea();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();
        jPanel2 = new javax.swing.JPanel();
        rdbValidation = new javax.swing.JRadioButton();
        rdbRejet = new javax.swing.JRadioButton();
        jLabel15 = new javax.swing.JLabel();
        jXLabel1 = new org.jdesktop.swingx.JXLabel();
        jSeparator2 = new javax.swing.JSeparator();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtObservations = new javax.swing.JTextArea();
        btnRetour = new cm.eusoworks.tools.ui.GButton();
        btnValidation = new cm.eusoworks.tools.ui.GButton();
        jPanel3 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jXLabel2 = new org.jdesktop.swingx.JXLabel();
        jSeparator3 = new javax.swing.JSeparator();
        jScrollPane7 = new javax.swing.JScrollPane();
        txtObservationsAnnulation = new javax.swing.JTextArea();
        btnRetourAnnuler = new cm.eusoworks.tools.ui.GButton();
        btnAnnulation = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Liquidation ");

        panelInfos.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel12.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel12.setText("Bénéficiaire : ");
        panelInfos.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 200, 181, 17));

        txtNumDossier.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        txtNumDossier.setEnabled(false);
        panelInfos.add(txtNumDossier, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 60, 180, -1));

        jLabel2.setText("Montant :");
        panelInfos.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 90, 80, 30));

        txtMontant.setEnabled(false);
        panelInfos.add(txtMontant, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 90, 180, 30));

        jLabel17.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel17.setText("N° Dossier : ");
        panelInfos.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 60, 90, 32));

        jLabel16.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel16.setText("Objet : ");
        panelInfos.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 120, 86, 50));

        btnBeneficiare.setCouleur(4);
        btnBeneficiare.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        btnBeneficiare.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        btnBeneficiare.setIconTextGap(2);
        panelInfos.add(btnBeneficiare, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 220, 270, 30));
        panelInfos.add(lblType, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 10, 52, 32));

        txtObjet.setEditable(false);
        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Arial", 0, 11)); // NOI18N
        txtObjet.setLineWrap(true);
        txtObjet.setRows(2);
        txtObjet.setEnabled(false);
        jScrollPane2.setViewportView(txtObjet);

        panelInfos.add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 120, 180, 50));

        txtReference.setEditable(false);
        txtReference.setEnabled(false);
        panelInfos.add(txtReference, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 170, 180, -1));
        panelInfos.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 270, 260, -1));

        jLabel18.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        jLabel18.setText("Référence : ");
        panelInfos.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 170, 86, 22));

        tblLiquidationListe.setRowHeight(23);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listLiquidations}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblLiquidationListe);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${numOrdre}"));
        columnBinding.setColumnName("No");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${montantTTC}"));
        columnBinding.setColumnName("Montant");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateLiquidation}"));
        columnBinding.setColumnName("Date");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${etat}"));
        columnBinding.setColumnName("Statut");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedLiquidation}"), tblLiquidationListe, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tblLiquidationListe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblLiquidationListeMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblLiquidationListe);
        if (tblLiquidationListe.getColumnModel().getColumnCount() > 0) {
            tblLiquidationListe.getColumnModel().getColumn(0).setResizable(false);
            tblLiquidationListe.getColumnModel().getColumn(0).setPreferredWidth(20);
            tblLiquidationListe.getColumnModel().getColumn(1).setPreferredWidth(100);
            tblLiquidationListe.getColumnModel().getColumn(2).setPreferredWidth(75);
            tblLiquidationListe.getColumnModel().getColumn(3).setPreferredWidth(25);
        }

        panelInfos.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, 280, 140));

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(102, 0, 102));
        jLabel3.setText("Liquidation(s) deja effectuee(s)");
        panelInfos.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 290, 270, -1));

        txtMontantRestantLiquider.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtMontantRestantLiquider.setHorizontalAlignment(javax.swing.JTextField.CENTER);
        txtMontantRestantLiquider.setEnabled(false);
        txtMontantRestantLiquider.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        panelInfos.add(txtMontantRestantLiquider, new org.netbeans.lib.awtextra.AbsoluteConstraints(44, 480, 180, 40));

        jLabel6.setText("Montant restant a liquider  : ");
        panelInfos.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 460, 210, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/bgannulationbord.png"))); // NOI18N
        panelInfos.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 290, 540));

        jSplitPane1.setLeftComponent(panelInfos);

        pDetails.setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setForeground(new java.awt.Color(51, 204, 0));
        jLabel1.setText("RUBRIQUES DE LIQUIDATION");

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel4.setText("NET A PAYER : ");

        txtMontantNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantNAP.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel5.setText("IR : ");

        txtMontantIR.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantIR.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel7.setText("TVA : ");

        txtMontantTVA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantTVA.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel9.setText("RETENUE GAR : ");

        txtMontantRG.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtMontantRG.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N

        jLabel10.setForeground(new java.awt.Color(51, 204, 0));
        jLabel10.setText("PIECES JUSTIFICATIVES DU SERVICE FAIT");

        txtPieces.setColumns(20);
        txtPieces.setRows(5);
        jScrollPane3.setViewportView(txtPieces);

        jLabel11.setForeground(new java.awt.Color(51, 153, 0));
        jLabel11.setText("LIVRABLES ");

        txtLivrables.setColumns(20);
        txtLivrables.setRows(5);
        jScrollPane4.setViewportView(txtLivrables);

        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(204, 0, 0));
        jLabel13.setText("Date de liquidation : ");

        dtpDateLiquidation.setEnabled(false);

        btnAnnuler.setText("Effacer tout");
        btnAnnuler.setCouleur(3);
        btnAnnuler.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAnnuler.setStyle(1);
        btnAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerActionPerformed(evt);
            }
        });

        btnAction.setText("Enregistrer la liquidation");
        btnAction.setCouleur(2);
        btnAction.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAction.setStyle(2);
        btnAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActionActionPerformed(evt);
            }
        });

        btnFermer.setText("Fermer");
        btnFermer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnFermer.setStyle(3);
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });

        jLabel14.setForeground(new java.awt.Color(51, 153, 0));
        jLabel14.setText("OBJET DE LA LIQUIDATION ");

        txtObjetLiquidation.setColumns(20);
        txtObjetLiquidation.setRows(5);
        jScrollPane5.setViewportView(txtObjetLiquidation);

        btnSupprimer.setText("Supprimer");
        btnSupprimer.setCouleur(1);
        btnSupprimer.setStyle(2);
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(30, 30, 30)
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 303, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(dtpDateLiquidation, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txtMontantNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtMontantIR, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtMontantTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(txtMontantRG, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 287, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 253, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(43, 43, 43)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 410, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(160, 160, 160)
                        .addComponent(btnAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(btnAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(btnFermer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(57, 57, 57)
                        .addComponent(btnSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel10))
                .addGap(4, 4, 4)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txtMontantNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txtMontantIR, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txtMontantTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, 0)
                        .addComponent(txtMontantRG, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addGap(14, 14, 14)
                        .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel14)
                        .addGap(14, 14, 14)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel13)
                .addGap(3, 3, 3)
                .addComponent(dtpDateLiquidation, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btnAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(btnFermer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(btnSupprimer, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(34, 34, 34))
        );

        pDetails.add(jPanel1, "liquidation");

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));

        validGroup.add(rdbValidation);
        rdbValidation.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        rdbValidation.setForeground(new java.awt.Color(0, 153, 51));
        rdbValidation.setSelected(true);
        rdbValidation.setText("Valider la liquidation ");
        rdbValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbValidationActionPerformed(evt);
            }
        });

        validGroup.add(rdbRejet);
        rdbRejet.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        rdbRejet.setForeground(new java.awt.Color(204, 51, 0));
        rdbRejet.setText("Rejeter ");

        jLabel15.setText("Observations ");

        jXLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jXLabel1.setText("La validation de cette liquidation permet d'effetuer le mandatement dans la suite de la procedure\n\nLe rejet arrete le processus de traitement de ce dossier a cette etape");
        jXLabel1.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jXLabel1.setLineWrap(true);

        txtObservations.setColumns(20);
        txtObservations.setRows(5);
        jScrollPane6.setViewportView(txtObservations);

        btnRetour.setCouleur(3);
        btnRetour.setLabel("Retour");
        btnRetour.setStyle(1);
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        btnValidation.setText("Valider");
        btnValidation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnValidationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jXLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(rdbValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 277, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(rdbRejet, javax.swing.GroupLayout.PREFERRED_SIZE, 263, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(jPanel2Layout.createSequentialGroup()
                                .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(164, 164, 164)
                                .addComponent(btnValidation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(24, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel2Layout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel15, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 341, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(57, 57, 57))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jXLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(52, 52, 52)
                        .addComponent(rdbValidation)
                        .addGap(39, 39, 39)
                        .addComponent(rdbRejet))
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addGap(35, 35, 35)
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 60, Short.MAX_VALUE)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRetour, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnValidation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pDetails.add(jPanel2, "validation");

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        jLabel19.setText("Observations ");

        jXLabel2.setForeground(new java.awt.Color(102, 0, 0));
        jXLabel2.setText("L'annulation de la validation n'est possible que si elle n'a pas encore fait l'objet d'un mandatement");
        jXLabel2.setFont(new java.awt.Font("Arial", 0, 20)); // NOI18N
        jXLabel2.setLineWrap(true);

        txtObservationsAnnulation.setColumns(20);
        txtObservationsAnnulation.setRows(5);
        jScrollPane7.setViewportView(txtObservationsAnnulation);

        btnRetourAnnuler.setCouleur(3);
        btnRetourAnnuler.setLabel("Retour");
        btnRetourAnnuler.setStyle(1);
        btnRetourAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourAnnulerActionPerformed(evt);
            }
        });

        btnAnnulation.setText("Annuler la validation");
        btnAnnulation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 728, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jXLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 713, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel19, javax.swing.GroupLayout.PREFERRED_SIZE, 192, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 688, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addComponent(btnRetourAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(164, 164, 164)
                        .addComponent(btnAnnulation, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(71, 71, 71)
                .addComponent(jXLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(41, 41, 41)
                .addComponent(jSeparator3, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29)
                .addComponent(jLabel19)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 132, Short.MAX_VALUE)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnRetourAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnAnnulation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(31, 31, 31))
        );

        pDetails.add(jPanel3, "annulation");

        jSplitPane1.setRightComponent(pDetails);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void loadLiquidations() {
        if (currentEngagement != null) {
            List<Liquidation> list = GrecoServiceFactory.getEngagementService().liquidationByEngagement(currentEngagement.getEngagementID());
            if (list != null && !list.isEmpty()) {
                listLiquidations.clear();
                long valide = 0;
                for (Liquidation l : list) {
                    listLiquidations.add(l);
                    if (l.getEtat() == EtatDossier.liquide_validation) {
                        valide = valide + l.getMontantTTC().longValue();
                    }
                }
                long reste = currentEngagement.getMontant().longValue() - valide;
                txtMontantRestantLiquider.setValue(reste);
            }else if(list.isEmpty()){
                listLiquidations = new ArrayList<>();
            }
        }
    }

    private void showSelectedLiquidation() {
        if (selectedLiquidation != null) {
            txtLivrables.setText(selectedLiquidation.getLivrables());
            txtObjetLiquidation.setText(selectedLiquidation.getObjet());
            txtPieces.setText(selectedLiquidation.getPieces());
            txtMontantIR.setValue(selectedLiquidation.getMontantIR());
            txtMontantNAP.setValue(selectedLiquidation.getMontantNAP());
            txtMontantRG.setValue(selectedLiquidation.getMontantRG());
            txtMontantTVA.setValue(selectedLiquidation.getMontantTVA());
            dtpDateLiquidation.setDate(selectedLiquidation.getDateLiquidation());
            currentLiquidationID = selectedLiquidation.getLiquidationID();
        }
    }

    private void btnAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerActionPerformed
        // TODO add your handling code here:
        txtLivrables.setText("");
        txtObjetLiquidation.setText("");
        txtPieces.setText("");
        txtMontantIR.setValue(null);
        txtMontantNAP.setValue(null);
        txtMontantRG.setValue(null);
        txtMontantTVA.setValue(null);
        currentLiquidationID = null;
        txtObservations.setText("");
        txtObservationsAnnulation.setText("");
    }//GEN-LAST:event_btnAnnulerActionPerformed

    private void btnActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActionActionPerformed
        // TODO add your handling code here:
        switch (this.mode) {
            case 1:
                enregistrerLiquidation();
                break;
            case 2:
                supprimerLiquidation();
                break;
            case 3:
                validerLiquidation();
                break;
            case 4:
                ((CardLayout) pDetails.getLayout()).show(pDetails, "annulation");
                break;
        }
    }//GEN-LAST:event_btnActionActionPerformed

    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_btnFermerActionPerformed

    private void tblLiquidationListeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblLiquidationListeMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if (selectedLiquidation != null) {
                showSelectedLiquidation();
                if (mode != 4) {        
                    if (selectedLiquidation.getEtat() == EtatDossier.liquide_validation) {
                        disableComponents();
                        btnAction.setVisible(false);
                        btnAnnuler.setVisible(false);
                    } else {
                        enableComponents();
                        btnAction.setVisible(true);
                        btnAnnuler.setVisible(true);
                    }
                }else {
                    if (selectedLiquidation.getEtat() == EtatDossier.liquide_validation) {
                        disableComponents();
                        btnAction.setVisible(true);
                        btnAnnuler.setVisible(false);
                    } else {
                        disableComponents();
                        btnAction.setVisible(false);
                        btnAnnuler.setVisible(false);
                    }
                }

            }
        }
    }//GEN-LAST:event_tblLiquidationListeMouseClicked

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (selectedLiquidation != null) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer cette liquidation ?");
            if (res == JOptionPane.YES_OPTION) {
                supprimerLiquidation();
            }
        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void rdbValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbValidationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbValidationActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void btnValidationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnValidationActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir valider cette liquidation ?");
        if (res == JOptionPane.YES_OPTION) {
            valider();
        }
    }//GEN-LAST:event_btnValidationActionPerformed

    private void btnRetourAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourAnnulerActionPerformed
        // TODO add your handling code here:
        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
    }//GEN-LAST:event_btnRetourAnnulerActionPerformed

    private void btnAnnulationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulationActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir annuler la validation de cette liquidation ?");
        if (res == JOptionPane.YES_OPTION) {
            annuler();
        }

    }//GEN-LAST:event_btnAnnulationActionPerformed

    private void annuler() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("Validation de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationValiderAnnuler(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedLiquidation.getLiquidationID(), txtObservationsAnnulation.getText().trim(), selectedLiquidation.getEngagementID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Liquidation annulee avec succès ");
                        btnAnnulerActionPerformed(null);
                        loadLiquidations();
                        btnAction.setVisible(false);
                        ((CardLayout) pDetails.getLayout()).show(pDetails, "liquidation");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE L'ANNULATION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void valider() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("Validation de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationValider(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                selectedLiquidation.getLiquidationID(), txtObservations.getText().trim(), rdbValidation.isSelected() ? true : false, selectedLiquidation.getEngagementID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Liquidation validee avec succès ");
                        btnAnnulerActionPerformed(null);
                        loadLiquidations();
                        ((CardLayout) pDetails.getLayout()).show(pDetails, "validation");
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA VALIDATION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private boolean controlData() {

        if (txtPieces.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir la liste des pieces justificatives du service fait");
            return false;
        }
        if (txtLivrables.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir les livrables obtenus suite a la realisation de cet engagement");
            return false;
        }
        if (txtObjetLiquidation.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Veuillez saisir l'objet de cette liquidation. Est-ce un decompte? une avance de demarrage....");
            return false;
        }

        Number nap = (Number) txtMontantNAP.getValue();
        if (nap == null || nap.doubleValue() <= 0) {
            GrecoOptionPane.showWarningDialog("Le montant NAP de cette liquidation est incorrect.");
            return false;
        }

        return true;
    }

    private void enregistrerLiquidation() {
        if (controlData()) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {

                        glasspane.setText("enregistrement de la dépense ....");
                        glasspane.attente();
                        if (currentLiquidationID == null) {
                            try {
                                Number tva = txtMontantTVA.getValue() == null ? 0 : ((Number) txtMontantTVA.getValue());
                                Number ir = txtMontantIR.getValue() == null ? 0 : ((Number) txtMontantIR.getValue());
                                Number nap = txtMontantNAP.getValue() == null ? 0 : ((Number) txtMontantNAP.getValue());
                                Number rg = txtMontantRG.getValue() == null ? 0 : ((Number) txtMontantRG.getValue());
                                GrecoServiceFactory.getEngagementService().liquidationEnregistrement(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                        currentLiquidationID, currentEngagement.getEngagementID(), txtObjetLiquidation.getText().trim(), BigDecimal.valueOf(tva.longValue()), BigDecimal.valueOf(ir.longValue()), BigDecimal.valueOf(nap.longValue()), BigDecimal.valueOf(rg.longValue()), currentEngagement.getBeneficiaire(), txtPieces.getText().trim(), txtLivrables.getText().trim());
                                GrecoSession.notifications.success();
                                GrecoOptionPane.showSuccessDialog("Liquidation enregistré avec succès ");
                                btnAnnulerActionPerformed(null);
                                loadLiquidations();
                                glasspane.arret();
                            } catch (GrecoException e) {
                                glasspane.arret();
                                currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                return;
                            } catch (Exception e) {
                                glasspane.arret();
                                e.printStackTrace();
                                currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        } else {
                            try {
                                Number tva = txtMontantTVA.getValue() == null ? 0 : ((Number) txtMontantTVA.getValue());
                                Number ir = txtMontantIR.getValue() == null ? 0 : ((Number) txtMontantIR.getValue());
                                Number nap = txtMontantNAP.getValue() == null ? 0 : ((Number) txtMontantNAP.getValue());
                                Number rg = txtMontantRG.getValue() == null ? 0 : ((Number) txtMontantRG.getValue());
                                GrecoServiceFactory.getEngagementService().liquidationModifier(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC,
                                        currentLiquidationID, currentEngagement.getEngagementID(), txtObjetLiquidation.getText().trim(), BigDecimal.valueOf(tva.longValue()), BigDecimal.valueOf(ir.longValue()), BigDecimal.valueOf(nap.longValue()), BigDecimal.valueOf(rg.longValue()), currentEngagement.getBeneficiaire(), txtPieces.getText().trim(), txtLivrables.getText().trim());
                                GrecoSession.notifications.success();
                                GrecoOptionPane.showSuccessDialog("Liquidation modifiee avec succès ");
                                //btnAnnulerActionPerformed(null);
                                loadLiquidations();
                                glasspane.arret();
                            } catch (GrecoException e) {
                                glasspane.arret();
                                currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                ManageException.show(e, GrecoSession.USER_LANGUAGE);
                                return;
                            } catch (Exception e) {
                                glasspane.arret();
                                e.printStackTrace();
                                currentLiquidationID = null;
                                GrecoSession.notifications.echec();
                                JOptionPane.showMessageDialog(null, "ECHEC DE L'ENREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                        }

                        glasspane.arret();

                    } catch (Exception e) {
                    }
                }
            });

        }
    }

    private void supprimerLiquidation() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {

                    glasspane.setText("enregistrement de la dépense ....");
                    glasspane.attente();

                    try {
                        GrecoServiceFactory.getEngagementService().liquidationSupprimer(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME + "/" + GrecoSession.USER_ADRESSE_MAC, selectedLiquidation.getLiquidationID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Cette Liquidation a bien ete supprime de la liste ");
                        btnAnnulerActionPerformed(null);
                        loadLiquidations();
                        glasspane.arret();
                    } catch (GrecoException e) {
                        glasspane.arret();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        return;
                    } catch (Exception e) {
                        glasspane.arret();
                        e.printStackTrace();
                        selectedLiquidation = null;
                        GrecoSession.notifications.echec();
                        JOptionPane.showMessageDialog(null, "ECHEC DE LA SUPPRESSION \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                        return;
                    }

                    glasspane.arret();

                } catch (Exception e) {
                }
            }
        });

    }

    private void validerLiquidation() {
        ((CardLayout) pDetails.getLayout()).show(pDetails, "validation");
    }

    private void disableComponents() {
        txtMontantIR.setEditable(false);
        txtMontantNAP.setEditable(false);
        txtMontantRG.setEditable(false);
        txtMontantTVA.setEditable(false);
        txtObjetLiquidation.setEditable(false);
        txtLivrables.setEditable(false);
        txtPieces.setEditable(false);
        btnAnnuler.setVisible(false);
    }

    private void enableComponents() {
        txtMontantIR.setEditable(true);
        txtMontantNAP.setEditable(true);
        txtMontantRG.setEditable(true);
        txtMontantTVA.setEditable(true);
        txtObjetLiquidation.setEditable(true);
        txtLivrables.setEditable(true);
        txtPieces.setEditable(true);
        btnAnnuler.setVisible(true);
    }

    private void afficherCout() {
        try {
//            btnTTC.setText(txtMontant.getText());
        } catch (Exception e) {
        }
    }

    public List<EngagementDroits> getListRetenues() {
        return listRetenues;
    }

    public void setListRetenues(List<EngagementDroits> listRetenues) {
        this.listRetenues = listRetenues;
    }

    public EngagementDroits getSelectedRetenue() {
        return selectedRetenue;
    }

    public void setSelectedRetenue(EngagementDroits selectedRetenue) {
        this.selectedRetenue = selectedRetenue;
    }

    public List<Liquidation> getListLiquidations() {
        return listLiquidations;
    }

    public void setListLiquidations(List<Liquidation> listLiquidations) {
        this.listLiquidations = listLiquidations;
    }

    public Liquidation getSelectedLiquidation() {
        return selectedLiquidation;
    }

    public void setSelectedLiquidation(Liquidation selectedLiquidation) {
        this.selectedLiquidation = selectedLiquidation;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup benefGroup;
    private cm.eusoworks.tools.ui.GButton btnAction;
    private cm.eusoworks.tools.ui.GButton btnAnnulation;
    private cm.eusoworks.tools.ui.GButton btnAnnuler;
    private cm.eusoworks.tools.ui.GButton btnBeneficiare;
    private cm.eusoworks.tools.ui.GButton btnFermer;
    private cm.eusoworks.tools.ui.GButton btnRetour;
    private cm.eusoworks.tools.ui.GButton btnRetourAnnuler;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private cm.eusoworks.tools.ui.GButton btnValidation;
    private org.jdesktop.swingx.JXDatePicker dtpDateLiquidation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSplitPane jSplitPane1;
    private org.jdesktop.swingx.JXLabel jXLabel1;
    private org.jdesktop.swingx.JXLabel jXLabel2;
    private javax.swing.JLabel lblType;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel panelInfos;
    private javax.swing.ButtonGroup radioGroup;
    private javax.swing.JRadioButton rdbRejet;
    private javax.swing.JRadioButton rdbValidation;
    private javax.swing.JTable tblLiquidationListe;
    private javax.swing.JTextArea txtLivrables;
    private javax.swing.JFormattedTextField txtMontant;
    private javax.swing.JFormattedTextField txtMontantIR;
    private javax.swing.JFormattedTextField txtMontantNAP;
    private javax.swing.JFormattedTextField txtMontantRG;
    private javax.swing.JFormattedTextField txtMontantRestantLiquider;
    private javax.swing.JFormattedTextField txtMontantTVA;
    private javax.swing.JTextField txtNumDossier;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextArea txtObjetLiquidation;
    private javax.swing.JTextArea txtObservations;
    private javax.swing.JTextArea txtObservationsAnnulation;
    private javax.swing.JTextArea txtPieces;
    private javax.swing.JTextField txtReference;
    private javax.swing.ButtonGroup validGroup;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
