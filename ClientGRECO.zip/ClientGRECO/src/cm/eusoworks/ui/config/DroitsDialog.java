/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.HighlightPredicate;
import org.jdesktop.swingx.renderer.DefaultListRenderer;

/**
 *
 * @author macbookair
 */
public class DroitsDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private Droits currentDroit = null;
    private Localite locality;

    public DroitsDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        jListDroits.setRolloverEnabled(true);
        jListDroits.setCellRenderer(new DefaultListRenderer());
        jListDroits.addHighlighter(new ColorHighlighter(HighlightPredicate.ROLLOVER_ROW, new Color(135, 164, 190), Color.white));
        loadDroits();
        initUI();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Droits à liquider lors du traitement de la dépense ");
        setPreferredSize(new Dimension(750, 500));
        pack();
        setLocationRelativeTo(null);
    }

    private void loadDroits() {
        List<Droits> list = new ArrayList<Droits>();
        try {
            list = GrecoServiceFactory.getDroitsService().listeDroits();
        } catch (Exception e) {
            list = null;
        }
        jListDroits.removeAll();
        if (list != null) {
            jListDroits.setListData(list.toArray());
        }
    }

    private void initUI() {
        if (currentDroit == null) {
            txtAbbreviation.clear();
            txtLibelle.clear();
        } else {
            try {
                txtAbbreviation.setTextFr(currentDroit.getSigleFr());
            } catch (Exception e) {
            }
            try {
                txtAbbreviation.setTextUs(currentDroit.getSigleUs());
            } catch (Exception e) {
            }
            try {
                txtLibelle.setTextFr(currentDroit.getLibelleFr());
            } catch (Exception e) {
            }
            try {
                txtLibelle.setTextUs(currentDroit.getLibelleUs());
            } catch (Exception e) {
            }
            //initialisation des type
            if (currentDroit.isNAP()) {
                rdbNAP.setSelected(true);
            } else if (currentDroit.isIR()) {
                rdbIR.setSelected(true);
            } else if (currentDroit.isTVA()) {
                rdbTVA.setSelected(true);
            } else if (currentDroit.isRG()) {
                rdbRG.setSelected(true);
            } else if (currentDroit.isCaution()) {
                rdbCaution.setSelected(true);
            } else if (currentDroit.isPenalite()) {
                rdbPenalite.setSelected(true);
            } else if (currentDroit.isDepotDivers()) {
                rdbDepot.setSelected(true);
            } else if (currentDroit.isPrecompte()) {
                rdbPrecompte.setSelected(true);
            }
        }
    }

    private void remplirCurrentDroit() {
        currentDroit.setLibelleFr(txtLibelle.getTextFr().toUpperCase());
        currentDroit.setLibelleUs(txtLibelle.getTextUs().toUpperCase());
        currentDroit.setSigleFr(txtAbbreviation.getTextFr());
        currentDroit.setSigleUs(txtAbbreviation.getTextUs());
        currentDroit.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentDroit.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
        initialiseType();
    }

    private void initialiseType() {
        currentDroit.setNAP(false);
        currentDroit.setTVA(false);
        currentDroit.setIR(false);
        currentDroit.setRG(false);
        currentDroit.setCaution(false);
        currentDroit.setPenalite(false);
        currentDroit.setDepotDivers(false);
        currentDroit.setPrecompte(false);

        currentDroit.setNAP(rdbNAP.isSelected());
        currentDroit.setIR(rdbIR.isSelected());
        currentDroit.setTVA(rdbTVA.isSelected());
        currentDroit.setRG(rdbRG.isSelected());
        currentDroit.setCaution(rdbCaution.isSelected());
        currentDroit.setDepotDivers(rdbDepot.isSelected());
        currentDroit.setPenalite(rdbPenalite.isSelected());
        currentDroit.setPrecompte(rdbPrecompte.isSelected());

}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jSplitPane1 = new javax.swing.JSplitPane();
        pListPC = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListDroits = new org.jdesktop.swingx.JXList();
        jPanel3 = new javax.swing.JPanel();
        btnAddDroit = new cm.eusoworks.tools.ui.GButton();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtAbbreviation = new editor.EditorRTF();
        txtLibelle = new editor.EditorRTF();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        lblLocalite = new javax.swing.JLabel();
        lblCategorie = new javax.swing.JLabel();
        lblFonction = new javax.swing.JLabel();
        rdbNAP = new javax.swing.JRadioButton();
        rdbTVA = new javax.swing.JRadioButton();
        rdbIR = new javax.swing.JRadioButton();
        rdbRG = new javax.swing.JRadioButton();
        rdbCaution = new javax.swing.JRadioButton();
        rdbPenalite = new javax.swing.JRadioButton();
        rdbDepot = new javax.swing.JRadioButton();
        rdbPrecompte = new javax.swing.JRadioButton();
        jLabel1 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des droits à liquider");

        pListPC.setLayout(new java.awt.BorderLayout());

        jListDroits.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListDroits.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jListDroits.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jListDroits.setSelectionForeground(new java.awt.Color(0, 102, 255));
        jListDroits.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListDroitsMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jListDroits);

        pListPC.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 15, 5));

        btnAddDroit.setText("Ajouter un droit à liquider");
        btnAddDroit.setCouleur(2);
        btnAddDroit.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAddDroit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddDroitActionPerformed(evt);
            }
        });
        jPanel3.add(btnAddDroit);

        pListPC.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jSplitPane1.setLeftComponent(pListPC);

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);
        jPanel1.add(txtAbbreviation);
        txtAbbreviation.setBounds(110, 120, 320, 70);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(110, 20, 320, 80);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Abbréviation : ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(0, 120, 110, 50);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Designation :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(0, 20, 100, 50);

        lblLocalite.setForeground(new java.awt.Color(0, 153, 102));
        jPanel1.add(lblLocalite);
        lblLocalite.setBounds(390, 370, 300, 20);

        lblCategorie.setForeground(new java.awt.Color(255, 153, 0));
        jPanel1.add(lblCategorie);
        lblCategorie.setBounds(390, 290, 300, 20);
        jPanel1.add(lblFonction);
        lblFonction.setBounds(390, 330, 300, 20);

        buttonGroup1.add(rdbNAP);
        rdbNAP.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbNAP.setMnemonic('N');
        rdbNAP.setText("Net à payer (NAP)");
        rdbNAP.setActionCommand("N");
        rdbNAP.setOpaque(false);
        jPanel1.add(rdbNAP);
        rdbNAP.setBounds(10, 260, 180, 23);

        buttonGroup1.add(rdbTVA);
        rdbTVA.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbTVA.setMnemonic('T');
        rdbTVA.setText("Taxe sur la Valeur Ajoutée (TVA)");
        rdbTVA.setActionCommand("T");
        rdbTVA.setOpaque(false);
        jPanel1.add(rdbTVA);
        rdbTVA.setBounds(220, 260, 240, 23);

        buttonGroup1.add(rdbIR);
        rdbIR.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbIR.setMnemonic('I');
        rdbIR.setText("Impôts sur le Revenu (IR)");
        rdbIR.setActionCommand("I");
        rdbIR.setOpaque(false);
        jPanel1.add(rdbIR);
        rdbIR.setBounds(10, 290, 190, 23);

        buttonGroup1.add(rdbRG);
        rdbRG.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbRG.setMnemonic('P');
        rdbRG.setText("Retenue de garantie");
        rdbRG.setActionCommand("R");
        rdbRG.setOpaque(false);
        jPanel1.add(rdbRG);
        rdbRG.setBounds(220, 290, 230, 23);

        buttonGroup1.add(rdbCaution);
        rdbCaution.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbCaution.setMnemonic('C');
        rdbCaution.setText("Cautionnement");
        rdbCaution.setActionCommand("C");
        rdbCaution.setOpaque(false);
        jPanel1.add(rdbCaution);
        rdbCaution.setBounds(10, 320, 180, 23);

        buttonGroup1.add(rdbPenalite);
        rdbPenalite.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbPenalite.setMnemonic('P');
        rdbPenalite.setText("Pénalités");
        rdbPenalite.setActionCommand("P");
        rdbPenalite.setOpaque(false);
        jPanel1.add(rdbPenalite);
        rdbPenalite.setBounds(220, 320, 160, 23);

        buttonGroup1.add(rdbDepot);
        rdbDepot.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbDepot.setMnemonic('D');
        rdbDepot.setText("Dépôts divers");
        rdbDepot.setActionCommand("D");
        rdbDepot.setOpaque(false);
        jPanel1.add(rdbDepot);
        rdbDepot.setBounds(10, 350, 180, 23);

        buttonGroup1.add(rdbPrecompte);
        rdbPrecompte.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbPrecompte.setMnemonic('E');
        rdbPrecompte.setText("Précompte ");
        rdbPrecompte.setActionCommand("E");
        rdbPrecompte.setOpaque(false);
        jPanel1.add(rdbPrecompte);
        rdbPrecompte.setBounds(220, 350, 210, 23);

        jLabel1.setBackground(new java.awt.Color(153, 153, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Options");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 230, 90, 22);
        jPanel1.add(jSeparator1);
        jSeparator1.setBounds(130, 240, 310, 10);

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 1, 5));

        btnEnregistrer.setText("    Enregistrer    ");
        btnEnregistrer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnEnregistrer.setStyle(1);
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnSupprimer.setText("      Supprimer   ");
        btnSupprimer.setCouleur(1);
        btnSupprimer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnSupprimer.setStyle(3);
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel2.add(btnSupprimer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        jSplitPane1.setRightComponent(pDetails);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enregistrer() {
        if (controlData()) {
            int erreur = 0;
            if (currentDroit == null) {
                currentDroit = new Droits();
                remplirCurrentDroit();
                try {

                    GrecoServiceFactory.getDroitsService().ajouter(currentDroit, erreur);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Rubrique enregistré", "RESULTAT", JOptionPane.INFORMATION_MESSAGE);
                    loadDroits();
                    initUI();
                } catch (GrecoException ex) {
                    currentDroit = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else { // modification de l'organisation 
                remplirCurrentDroit();
                try {
                    GrecoServiceFactory.getDroitsService().modifier(currentDroit, erreur);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Rubrique enregistré", "RESULTAT", JOptionPane.INFORMATION_MESSAGE);
                    loadDroits();
                    initUI();
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }

    private void supprimer() {
        if (!currentDroit.getDroitID().isEmpty()) {
            int reponse = JOptionPane.showConfirmDialog(this, "Estes-vous sur de vouloir supprimer cette rubrique " + "\n" + currentDroit.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getDroitsService().supprimer(currentDroit.getDroitID());
                    GrecoSession.notifications.success();
                    loadDroits();
                    currentDroit = null;
                    initUI();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }

    private void addNewDroit() {
        currentDroit = null;
        initUI();
    }
    private void jListDroitsMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListDroitsMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            currentDroit = (Droits) jListDroits.getSelectedValue();
            initUI();
        }
    }//GEN-LAST:event_jListDroitsMouseClicked

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        enregistrer();
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        supprimer();
        loadDroits();
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAddDroitActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddDroitActionPerformed
        // TODO add your handling code here:
        addNewDroit();
    }//GEN-LAST:event_btnAddDroitActionPerformed

    private boolean controlData() {
        boolean res = true;

        if (txtLibelle.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le libellé ", "ATTENTION", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtAbbreviation.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir l'abbréviation", "ATTENTION", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (buttonGroup1.getSelection() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez choisir le type de rubrique parmis les options proposées SVP", "ATTENTION", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                

}
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DroitsDialog.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 

catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DroitsDialog.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 

catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DroitsDialog.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } 

catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DroitsDialog.class  

.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                DroitsDialog dialog = new DroitsDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
        public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAddDroit;
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private org.jdesktop.swingx.JXList jListDroits;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblCategorie;
    private javax.swing.JLabel lblFonction;
    private javax.swing.JLabel lblLocalite;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListPC;
    private javax.swing.JRadioButton rdbCaution;
    private javax.swing.JRadioButton rdbDepot;
    private javax.swing.JRadioButton rdbIR;
    private javax.swing.JRadioButton rdbNAP;
    private javax.swing.JRadioButton rdbPenalite;
    private javax.swing.JRadioButton rdbPrecompte;
    private javax.swing.JRadioButton rdbRG;
    private javax.swing.JRadioButton rdbTVA;
    private editor.EditorRTF txtAbbreviation;
    private editor.EditorRTF txtLibelle;
    // End of variables declaration//GEN-END:variables
}
