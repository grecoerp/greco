/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Agence;
import cm.eusoworks.entities.model.Banque;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author macbookair
 */
public class BanqueDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private Banque currentBQ;
    private Agence currentAG;

    public BanqueDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        loadBanques();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Repertoire des banques ");
    }

    private void loadBanques() {
        List<Banque> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getBanqueService().banqueListe();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            jListBanques.removeAll();
            jListBanques.setListData(list.toArray());
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "banque");
        } else {
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "accueil");
        }

    }

    private void initUI() {
        if (currentBQ == null) {
            txtCodeBanque.setValue(null);
            txtCodeBanque.setEnabled(true);
            txtCodeIBAN.setText("");
            txtCodeSWIFT.setText("");
            txtSigle.setText("");
            txtDesignation.setText("");
            txtSiege.setText("");
            txtAdresse.setText("");
            
            List<Agence> list = new ArrayList();    
            jListAgence.removeAll();
            jListAgence.setListData(list.toArray());

        } else {
            txtCodeBanque.setValue(currentBQ.getCode());
            txtCodeBanque.setEnabled(false);
            txtCodeIBAN.setText(currentBQ.getIban());
            txtCodeSWIFT.setText(currentBQ.getSwift());
            txtSigle.setText(currentBQ.getSigle());
            txtDesignation.setText(currentBQ.getDesignation());
            txtSiege.setText(currentBQ.getVille());
            txtAdresse.setText(currentBQ.getAdresse());

            loadAgences(currentBQ.getCode());
        }
    }

    private void initUIagence() {
        if (currentAG == null) {
            txtCodeAgence.setValue(null);
            txtCodeAgence.setEnabled(true);
            txtDesignationAgence.setText("");
            txtSiegeAgence.setText("");
            txtAdresseAgence.setText("");
        } else {
            txtCodeAgence.setValue(currentAG.getCode());
            txtCodeAgence.setEnabled(false);
            txtDesignationAgence.setText(currentAG.getDesignation());
            txtSiegeAgence.setText(currentAG.getVille());
            txtAdresseAgence.setText(currentAG.getAdresse());
        }
    }

    private void loadAgences(String codeBanque) {
        List<Agence> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getBanqueService().agenceListe(codeBanque);
        } catch (Exception e) {
            list = new ArrayList<>();
        }
        if (list != null && !list.isEmpty()) {
            jListAgence.removeAll();
            jListAgence.setListData(list.toArray());
        }

    }

    private void remplirCurrentBanque() {
        currentBQ.setCode(txtCodeBanque.getText().trim());
        currentBQ.setIban(txtCodeIBAN.getText().trim());
        currentBQ.setSwift(txtCodeSWIFT.getText().trim());
        currentBQ.setDesignation(txtDesignation.getText().trim().toUpperCase());
        currentBQ.setSigle(txtSigle.getText().trim().toUpperCase());
        currentBQ.setVille(txtSiege.getText().trim());
        currentBQ.setAdresse(txtAdresse.getText().trim());
        currentBQ.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentBQ.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
    }

    private void remplirCurrentAgence() {
        currentAG.setCode(txtCodeAgence.getText().trim());
        currentAG.setCodeBanque(txtCodeBanque.getText().trim());
        currentAG.setDesignation(txtDesignationAgence.getText().trim());
        currentAG.setVille(txtSiegeAgence.getText().trim());
        currentAG.setAdresse(txtAdresseAgence.getText().trim());
        currentAG.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentAG.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pAccueil = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnNewOrg = new javax.swing.JButton();
        pListBanque = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListBanques = new javax.swing.JList();
        pDetailsBanque = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCodeBanque = new javax.swing.JFormattedTextField();
        txtCodeIBAN = new javax.swing.JTextField();
        txtCodeSWIFT = new javax.swing.JTextField();
        txtSigle = new javax.swing.JTextField();
        txtSiege = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtDesignation = new javax.swing.JTextArea();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtAdresse = new javax.swing.JTextArea();
        btnAgence = new cm.eusoworks.tools.ui.GButton();
        jLabel9 = new javax.swing.JLabel();
        jScrollPane7 = new javax.swing.JScrollPane();
        jListAgence = new javax.swing.JList();
        jPanel2 = new javax.swing.JPanel();
        btnNouvelleBanque = new cm.eusoworks.tools.ui.GButton();
        btnEnregistrer = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        btnAnnuler = new javax.swing.JButton();
        pDetailsAgence = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        lblLocalite1 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        txtCodeAgence = new javax.swing.JFormattedTextField();
        txtSiegeAgence = new javax.swing.JTextField();
        jScrollPane5 = new javax.swing.JScrollPane();
        txtDesignationAgence = new javax.swing.JTextArea();
        jScrollPane6 = new javax.swing.JScrollPane();
        txtAdresseAgence = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        btnNouvelleAgence = new cm.eusoworks.tools.ui.GButton();
        btnEnregistrerAgence = new javax.swing.JButton();
        btnSupprimerAgence = new javax.swing.JButton();
        btnAnnulerAgence = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Aucune banque cree.");

        btnNewOrg.setText("Ajouter une banque");
        btnNewOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewOrgActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pAccueilLayout = new javax.swing.GroupLayout(pAccueil);
        pAccueil.setLayout(pAccueilLayout);
        pAccueilLayout.setHorizontalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(btnNewOrg))
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(254, Short.MAX_VALUE))
        );
        pAccueilLayout.setVerticalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(jLabel1)
                .addGap(65, 65, 65)
                .addComponent(btnNewOrg)
                .addContainerGap(195, Short.MAX_VALUE))
        );

        getContentPane().add(pAccueil, "accueil");

        pListBanque.setLayout(new java.awt.BorderLayout());

        jListBanques.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListBanquesMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jListBanques);

        pListBanque.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getContentPane().add(pListBanque, "banque");

        pDetailsBanque.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("Code IBAN : ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 40, 120, 30);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Code SWIFT : ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 70, 110, 30);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Designation :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 140, 120, 80);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Code Banque : ");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 10, 120, 30);

        jLabel5.setText("Sigle : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(20, 100, 60, 30);

        jLabel6.setText("Siege social :   ");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(20, 230, 110, 30);

        jLabel8.setText("Adresse :   ");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(20, 270, 110, 80);

        try {
            txtCodeBanque.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel1.add(txtCodeBanque);
        txtCodeBanque.setBounds(150, 10, 140, 30);
        jPanel1.add(txtCodeIBAN);
        txtCodeIBAN.setBounds(150, 40, 270, 26);
        jPanel1.add(txtCodeSWIFT);
        txtCodeSWIFT.setBounds(150, 70, 270, 26);
        jPanel1.add(txtSigle);
        txtSigle.setBounds(150, 100, 140, 30);
        jPanel1.add(txtSiege);
        txtSiege.setBounds(150, 230, 270, 30);

        txtDesignation.setColumns(20);
        txtDesignation.setRows(5);
        jScrollPane2.setViewportView(txtDesignation);

        jPanel1.add(jScrollPane2);
        jScrollPane2.setBounds(150, 140, 270, 84);

        txtAdresse.setColumns(20);
        txtAdresse.setRows(5);
        jScrollPane3.setViewportView(txtAdresse);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(150, 270, 270, 84);

        btnAgence.setText("Ajouter/Modifier");
        btnAgence.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAgenceActionPerformed(evt);
            }
        });
        jPanel1.add(btnAgence);
        btnAgence.setBounds(601, 320, 160, 29);

        jLabel9.setText("Liste des agences ");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(460, 10, 140, 30);

        jListAgence.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListAgenceMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(jListAgence);

        jPanel1.add(jScrollPane7);
        jScrollPane7.setBounds(460, 40, 330, 270);

        pDetailsBanque.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5));

        btnNouvelleBanque.setText("+");
        btnNouvelleBanque.setCouleur(2);
        btnNouvelleBanque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNouvelleBanqueActionPerformed(evt);
            }
        });
        jPanel2.add(btnNouvelleBanque);

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnSupprimer.setText("Supprimer");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel2.add(btnSupprimer);

        btnAnnuler.setText("Annuler");
        btnAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerActionPerformed(evt);
            }
        });
        jPanel2.add(btnAnnuler);

        pDetailsBanque.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetailsBanque, "detailsBanque");

        pDetailsAgence.setLayout(new java.awt.BorderLayout());

        jPanel3.setBackground(new java.awt.Color(204, 204, 204));
        jPanel3.setLayout(null);

        jLabel12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel12.setText("Designation :");
        jPanel3.add(jLabel12);
        jLabel12.setBounds(20, 50, 120, 80);

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel13.setText("Code Agence : ");
        jPanel3.add(jLabel13);
        jLabel13.setBounds(20, 10, 120, 30);

        lblLocalite1.setForeground(new java.awt.Color(0, 153, 102));
        jPanel3.add(lblLocalite1);
        lblLocalite1.setBounds(330, 300, 300, 20);

        jLabel15.setText("Siege social :   ");
        jPanel3.add(jLabel15);
        jLabel15.setBounds(20, 140, 110, 30);

        jLabel16.setText("Adresse :   ");
        jPanel3.add(jLabel16);
        jLabel16.setBounds(20, 180, 110, 80);

        try {
            txtCodeAgence.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#####")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        jPanel3.add(txtCodeAgence);
        txtCodeAgence.setBounds(150, 10, 140, 30);
        jPanel3.add(txtSiegeAgence);
        txtSiegeAgence.setBounds(150, 140, 410, 30);

        txtDesignationAgence.setColumns(20);
        txtDesignationAgence.setRows(5);
        jScrollPane5.setViewportView(txtDesignationAgence);

        jPanel3.add(jScrollPane5);
        jScrollPane5.setBounds(150, 50, 410, 84);

        txtAdresseAgence.setColumns(20);
        txtAdresseAgence.setRows(5);
        jScrollPane6.setViewportView(txtAdresseAgence);

        jPanel3.add(jScrollPane6);
        jScrollPane6.setBounds(150, 180, 410, 84);

        pDetailsAgence.add(jPanel3, java.awt.BorderLayout.CENTER);

        jPanel4.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5));

        btnNouvelleAgence.setText("+");
        btnNouvelleAgence.setCouleur(2);
        btnNouvelleAgence.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNouvelleAgenceActionPerformed(evt);
            }
        });
        jPanel4.add(btnNouvelleAgence);

        btnEnregistrerAgence.setText("Enregistrer agence");
        btnEnregistrerAgence.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerAgenceActionPerformed(evt);
            }
        });
        jPanel4.add(btnEnregistrerAgence);

        btnSupprimerAgence.setText("Supprimer");
        btnSupprimerAgence.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerAgenceActionPerformed(evt);
            }
        });
        jPanel4.add(btnSupprimerAgence);

        btnAnnulerAgence.setText("Annuler");
        btnAnnulerAgence.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerAgenceActionPerformed(evt);
            }
        });
        jPanel4.add(btnAnnulerAgence);

        pDetailsAgence.add(jPanel4, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetailsAgence, "detailsAgence");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewOrgActionPerformed
        // TODO add your handling code here:
        currentBQ = null;
        initUI();
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsBanque");
    }//GEN-LAST:event_btnNewOrgActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlDataBanque()) {
            if (currentBQ == null) {
                currentBQ = new Banque();
                remplirCurrentBanque();
                try {
                    GrecoServiceFactory.getBanqueService().banqueAjout(currentBQ);
                    GrecoSession.notifications.success();
                    loadBanques();
                } catch (GrecoException ex) {
                    currentBQ = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else {
                remplirCurrentBanque();
                try {
                    GrecoServiceFactory.getBanqueService().banqueModifier(currentBQ);
                    GrecoSession.notifications.success();
                    loadBanques();
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (currentBQ != null) {
            int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir supprimer la banque " + currentBQ.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getBanqueService().banqueSupprimer(currentBQ.getCode(), false);
                    GrecoSession.notifications.success();
                    loadBanques();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }
        }else{
            GrecoOptionPane.showErrorDialog("Aucune banque selectionne pour la suppression ");
        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerActionPerformed
        // TODO add your handling code here:
       // ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "banque");
        loadBanques();
    }//GEN-LAST:event_btnAnnulerActionPerformed

    private void jListBanquesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListBanquesMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            Banque bq = (Banque) jListBanques.getSelectedValue();
            if (bq != null) {
                currentBQ = bq;
                initUI();
                ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsBanque");
            }

        }
    }//GEN-LAST:event_jListBanquesMouseClicked

    private void btnEnregistrerAgenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerAgenceActionPerformed
        // TODO add your handling code here:
        if (controlDataAgence()) {
            if (currentAG == null) {
                currentAG = new Agence();
                remplirCurrentAgence();
                try {
                    GrecoServiceFactory.getBanqueService().agenceAjout(currentAG);
                    GrecoSession.notifications.success();
                    loadAgences(currentBQ.getCode());
                } catch (GrecoException ex) {
                    currentAG = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else {
                remplirCurrentAgence();
                try {
                    GrecoServiceFactory.getBanqueService().agenceModifier(currentAG);
                    GrecoSession.notifications.success();
                    loadAgences(currentBQ.getCode());
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsBanque");
        }

    }//GEN-LAST:event_btnEnregistrerAgenceActionPerformed

    private void btnSupprimerAgenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerAgenceActionPerformed
        // TODO add your handling code here:
        if (currentAG != null) {
            int reponse = GrecoOptionPane.showConfirmDialog("Etes vous sur de vouloir supprimer l'agence " + currentAG.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getBanqueService().agenceSupprimer(currentBQ.getCode(), currentAG.getCode());
                    GrecoSession.notifications.success();
                    loadAgences(currentBQ.getCode());
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsBanque");
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }

        }
    }//GEN-LAST:event_btnSupprimerAgenceActionPerformed

    private void btnAnnulerAgenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerAgenceActionPerformed
        // TODO add your handling code here:
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsBanque");
    }//GEN-LAST:event_btnAnnulerAgenceActionPerformed

    private void jListAgenceMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListAgenceMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            Agence ag = (Agence) jListAgence.getSelectedValue();
            if (ag != null) {
                currentAG = ag;
                initUIagence();
                ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsAgence");
            }

        }
    }//GEN-LAST:event_jListAgenceMouseClicked

    private void btnAgenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAgenceActionPerformed
        // TODO add your handling code here:
        if (currentBQ != null) {
            currentAG = null;
            Agence a = (Agence) jListAgence.getSelectedValue();
            if (a != null) {
                currentAG = a;
                initUIagence();
            }
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "detailsAgence");
        }else {
            GrecoOptionPane.showInformationDialog("Selectionnez au prealable la banque SVP");
        }

    }//GEN-LAST:event_btnAgenceActionPerformed

    private void btnNouvelleBanqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNouvelleBanqueActionPerformed
        // TODO add your handling code here:
        currentBQ = null;
        initUI();
    }//GEN-LAST:event_btnNouvelleBanqueActionPerformed

    private void btnNouvelleAgenceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNouvelleAgenceActionPerformed
        // TODO add your handling code here:
        currentAG = null;
        initUIagence();
    }//GEN-LAST:event_btnNouvelleAgenceActionPerformed

    private boolean controlDataBanque() {
        boolean res = true;
        if (txtCodeBanque.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Code banque manquant ");
            return false;
        }
        if (txtSigle.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Sigle/Abbreviation de la banque manquant ");
            return false;
        }
        if (txtDesignation.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Intitule de la banque manquant ");
            return false;
        }

        return res;
    }

    private boolean controlDataAgence() {
        boolean res = true;
        if (txtCodeAgence.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Code agence manquant ");
            return false;
        }
        if (txtDesignationAgence.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Intitule de l'agence manquant ");
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BanqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BanqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BanqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BanqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                BanqueDialog dialog = new BanqueDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAgence;
    private javax.swing.JButton btnAnnuler;
    private javax.swing.JButton btnAnnulerAgence;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnEnregistrerAgence;
    private javax.swing.JButton btnNewOrg;
    private cm.eusoworks.tools.ui.GButton btnNouvelleAgence;
    private cm.eusoworks.tools.ui.GButton btnNouvelleBanque;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JButton btnSupprimerAgence;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JList jListAgence;
    private javax.swing.JList jListBanques;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JLabel lblLocalite1;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pDetailsAgence;
    private javax.swing.JPanel pDetailsBanque;
    private javax.swing.JPanel pListBanque;
    private javax.swing.JTextArea txtAdresse;
    private javax.swing.JTextArea txtAdresseAgence;
    private javax.swing.JFormattedTextField txtCodeAgence;
    private javax.swing.JFormattedTextField txtCodeBanque;
    private javax.swing.JTextField txtCodeIBAN;
    private javax.swing.JTextField txtCodeSWIFT;
    private javax.swing.JTextArea txtDesignation;
    private javax.swing.JTextArea txtDesignationAgence;
    private javax.swing.JTextField txtSiege;
    private javax.swing.JTextField txtSiegeAgence;
    private javax.swing.JTextField txtSigle;
    // End of variables declaration//GEN-END:variables
}
