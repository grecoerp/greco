/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.NiveauOrganique;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.HighlightPredicate;
import org.jdesktop.swingx.renderer.DefaultListRenderer;

/**
 *
 * @author macbookair
 */
public class UniteOrganiqueDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private UniteOrganique currentUniteOrganique;

    public UniteOrganiqueDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        jListOrganisation.setRolloverEnabled(true);
        jListOrganisation.setCellRenderer(new DefaultListRenderer());
        jListOrganisation.addHighlighter(new ColorHighlighter(HighlightPredicate.ROLLOVER_ROW, new Color(135, 164, 190), Color.white));
        loadOrganisations();
        //loadUniteOrganiques();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : "+"Gestion des unités organiques");
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }
    private void loadUniteOrganiques() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if(o == null){
            return;
        }
        List<UniteOrganique> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getUniteOrganiqueService().listeUniteOrganique(o.getOrganisationID());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            jListOrganisation.setListData(list.toArray());
            cboUniteOrganiqueParent.setModel(new DefaultComboBoxModel(list.toArray()));
            ((CardLayout) pUniteOrganiques.getLayout()).show(pUniteOrganiques, "list");
        } else {
            ((CardLayout) pUniteOrganiques.getLayout()).show(pUniteOrganiques, "accueil");
        }
    }
    
    
    private void loadNiveauOrganiques() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            return;
        }
        List<NiveauOrganique> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getUniteOrganiqueService().listeNiveauOrganique(o.getOrganisationID());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboNiveauOrganique.setModel(new DefaultComboBoxModel(list.toArray()));
        } 
    }

    private void initUI() {
        if (currentUniteOrganique == null) {
            txtNumOrdre.setValue(null);
            txtLibelle.clear();
            txtMissions.clear();
            colorChooser.setColor(null);
        } else {
            try {
                UniteOrganique parent = GrecoServiceFactory.getUniteOrganiqueService().rechercherById(currentUniteOrganique.getUniteOrganiqueParentID());
                cboUniteOrganiqueParent.setSelectedItem(parent);
            } catch (Exception e) {
                cboUniteOrganiqueParent.setSelectedItem(null);
            }
            
            
            txtNumOrdre.setText(String.valueOf( currentUniteOrganique.getOrdre()));
            txtLibelle.setTextFr(currentUniteOrganique.getLibelleFr());
            txtLibelle.setTextUs(currentUniteOrganique.getLibelleUs());
            colorChooser.setColor(currentUniteOrganique.getR(), currentUniteOrganique.getG(), currentUniteOrganique.getB());
            txtMissions.setTextFr(currentUniteOrganique.getMissionsFr()==null?"":currentUniteOrganique.getMissionsFr());
            txtMissions.setTextUs(currentUniteOrganique.getMissionsUs()==null?"":currentUniteOrganique.getMissionsUs());
        }
    }

    private void remplirCurrentOrganisation() {
        currentUniteOrganique.setOrdre(Integer.valueOf( txtNumOrdre.getText()));
        currentUniteOrganique.setLibelleFr(txtLibelle.getTextFr().toUpperCase());
        currentUniteOrganique.setLibelleUs(txtLibelle.getTextUs().toUpperCase());
        currentUniteOrganique.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentUniteOrganique.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
        Color color = colorChooser.getColor();
        currentUniteOrganique.setR(color.getRed());
        currentUniteOrganique.setG(color.getGreen());
        currentUniteOrganique.setB(color.getBlue());
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        currentUniteOrganique.setOrganisationID(o.getOrganisationID());
        UniteOrganique parent = (UniteOrganique) cboUniteOrganiqueParent.getSelectedItem();
        currentUniteOrganique.setUniteOrganiqueParentID(parent.getUniteOrganiqueID());
        currentUniteOrganique.setMissionsFr(txtMissions.getTextFr());
        currentUniteOrganique.setMissionsUs(txtMissions.getTextUs());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pOrganisation = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox<>();
        pUniteOrganiques = new javax.swing.JPanel();
        pAccueil = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnNewOrg = new javax.swing.JButton();
        pDetails = new javax.swing.JPanel();
        tabbedPane = new javax.swing.JTabbedPane();
        jPanel1 = new javax.swing.JPanel();
        txtLibelle = new editor.EditorRTF();
        txtNumOrdre = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        colorChooser = new javax.swing.JColorChooser();
        cboUniteOrganiqueParent = new javax.swing.JComboBox<>();
        jLabel5 = new javax.swing.JLabel();
        cboNiveauOrganique = new javax.swing.JComboBox<>();
        jPanel4 = new javax.swing.JPanel();
        txtMissions = new editor.EditorRTF();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        btnAnnuler = new javax.swing.JButton();
        pListOrg = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListOrganisation = new org.jdesktop.swingx.JXList();
        jPanel3 = new javax.swing.JPanel();
        btnAddOrg = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("cm/eusoworks/properties/UniteOrganiqueDialog"); // NOI18N
        setTitle(bundle.getString("title")); // NOI18N

        jLabel3.setText("Organisation : ");
        pOrganisation.add(jLabel3);

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        pOrganisation.add(cboOrganisation);

        getContentPane().add(pOrganisation, java.awt.BorderLayout.PAGE_START);

        pUniteOrganiques.setLayout(new java.awt.CardLayout());

        jLabel1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText(bundle.getString("anyCreation")); // NOI18N

        btnNewOrg.setText(bundle.getString("addUniteOrg")); // NOI18N
        btnNewOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewOrgActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pAccueilLayout = new javax.swing.GroupLayout(pAccueil);
        pAccueil.setLayout(pAccueilLayout);
        pAccueilLayout.setHorizontalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(btnNewOrg))
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(68, 68, 68)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 501, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        pAccueilLayout.setVerticalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(jLabel1)
                .addGap(65, 65, 65)
                .addComponent(btnNewOrg)
                .addContainerGap(234, Short.MAX_VALUE))
        );

        pUniteOrganiques.add(pAccueil, "accueil");

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(null);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(210, 100, 380, 70);

        txtNumOrdre.setEditable(false);
        try {
            txtNumOrdre.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("#")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtNumOrdre.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jPanel1.add(txtNumOrdre);
        txtNumOrdre.setBounds(200, 50, 60, 38);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText(bundle.getString("numOrdre")); // NOI18N
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 50, 180, 40);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText(bundle.getString("DESIGNATION")); // NOI18N
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 100, 140, 50);
        jPanel1.add(colorChooser);
        colorChooser.setBounds(0, 200, 620, 240);

        cboUniteOrganiqueParent.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cboUniteOrganiqueParent);
        cboUniteOrganiqueParent.setBounds(200, 10, 390, 27);

        jLabel5.setText("Unite Organique Parent : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(10, 10, 180, 30);

        cboNiveauOrganique.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        cboNiveauOrganique.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboNiveauOrganique.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboNiveauOrganiqueActionPerformed(evt);
            }
        });
        jPanel1.add(cboNiveauOrganique);
        cboNiveauOrganique.setBounds(270, 47, 320, 40);

        tabbedPane.addTab("Details", jPanel1);

        jPanel4.setLayout(new java.awt.BorderLayout());
        jPanel4.add(txtMissions, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Missions organiques", jPanel4);

        pDetails.add(tabbedPane, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5));

        btnEnregistrer.setText(bundle.getString("ENREGISTRER ")); // NOI18N
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnSupprimer.setText(bundle.getString("SUPPRIMER")); // NOI18N
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel2.add(btnSupprimer);

        btnAnnuler.setText(bundle.getString("ANNULER")); // NOI18N
        btnAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerActionPerformed(evt);
            }
        });
        jPanel2.add(btnAnnuler);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        pUniteOrganiques.add(pDetails, "details");

        pListOrg.setLayout(new java.awt.BorderLayout());

        jListOrganisation.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jListOrganisation.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListOrganisation.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jListOrganisation.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jListOrganisation.setSelectionForeground(new java.awt.Color(0, 102, 255));
        jListOrganisation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListOrganisationMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jListOrganisation);

        pListOrg.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 15, 5));

        btnAddOrg.setText(bundle.getString("addUniteOrg")); // NOI18N
        btnAddOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddOrgActionPerformed(evt);
            }
        });
        jPanel3.add(btnAddOrg);

        pListOrg.add(jPanel3, java.awt.BorderLayout.SOUTH);

        pUniteOrganiques.add(pListOrg, "list");

        getContentPane().add(pUniteOrganiques, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewOrgActionPerformed
        // TODO add your handling code here:
        currentUniteOrganique = null;
        initUI();
        ((CardLayout) pUniteOrganiques.getLayout()).show(pUniteOrganiques, "details");
    }//GEN-LAST:event_btnNewOrgActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentUniteOrganique == null) {
                currentUniteOrganique = new UniteOrganique();
                remplirCurrentOrganisation();
                int error = 1;
                try {
                    error = GrecoServiceFactory.getUniteOrganiqueService().ajouter(currentUniteOrganique, error);
                    GrecoSession.notifications.success();
                    loadUniteOrganiques();
                } catch (GrecoException ex) {
                    currentUniteOrganique = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else { // modification de l'organisation 
                remplirCurrentOrganisation();
                int error = 1;
                try {
                    error = GrecoServiceFactory.getUniteOrganiqueService().modifier(currentUniteOrganique, error);
                    GrecoSession.notifications.success();
                    loadUniteOrganiques();
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (!currentUniteOrganique.getUniteOrganiqueID().isEmpty()) {
            int reponse = JOptionPane.showConfirmDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/UniteOrganiqueDialog").getString("deleteQuestion")+currentUniteOrganique.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getUniteOrganiqueService().supprimer(currentUniteOrganique.getUniteOrganiqueID());
                    GrecoSession.notifications.success();
                    loadUniteOrganiques();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }

        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAddOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddOrgActionPerformed
        // TODO add your handling code here:
        btnNewOrgActionPerformed(null);
    }//GEN-LAST:event_btnAddOrgActionPerformed

    private void jListOrganisationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListOrganisationMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            currentUniteOrganique = (UniteOrganique) jListOrganisation.getSelectedValue();
            initUI();
            if (currentUniteOrganique != null) {
                ((CardLayout) pUniteOrganiques.getLayout()).show(pUniteOrganiques, "details");
            }

        }
    }//GEN-LAST:event_jListOrganisationMouseClicked

    private void btnAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerActionPerformed
        // TODO add your handling code here:
        loadUniteOrganiques();
        ((CardLayout) pUniteOrganiques.getLayout()).show(pUniteOrganiques, "list");
    }//GEN-LAST:event_btnAnnulerActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        loadUniteOrganiques();
        loadNiveauOrganiques();
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void cboNiveauOrganiqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboNiveauOrganiqueActionPerformed
        // TODO add your handling code here:
        NiveauOrganique n = (NiveauOrganique) cboNiveauOrganique.getSelectedItem();
        if(n != null){
            txtNumOrdre.setText( String.valueOf(n.getNiveauOrganiqueID().intValue()));
        }else {
            txtNumOrdre.setValue(null);
        }
        
    }//GEN-LAST:event_cboNiveauOrganiqueActionPerformed

    private boolean controlData() {
        boolean res = true;
        UniteOrganique p = (UniteOrganique) cboUniteOrganiqueParent.getSelectedItem();
        if(p == null){
            GrecoOptionPane.showWarningDialog("Veuillez selectionner l'unite organique parent SVP");
        }
        
        if (txtNumOrdre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/UniteOrganiqueDialog").getString("pleaseNumero"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtLibelle.getTextFr().isEmpty() || txtLibelle.getTextUs().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/UniteOrganiqueDialog").getString("pleaseLabel"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if(colorChooser.getColor() == null){
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/UniteOrganiqueDialog").getString("pleaseColor"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UniteOrganiqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UniteOrganiqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UniteOrganiqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UniteOrganiqueDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UniteOrganiqueDialog dialog = new UniteOrganiqueDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddOrg;
    private javax.swing.JButton btnAnnuler;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnNewOrg;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JComboBox<String> cboNiveauOrganique;
    private javax.swing.JComboBox<String> cboOrganisation;
    private javax.swing.JComboBox<String> cboUniteOrganiqueParent;
    private javax.swing.JColorChooser colorChooser;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private org.jdesktop.swingx.JXList jListOrganisation;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListOrg;
    private javax.swing.JPanel pOrganisation;
    private javax.swing.JPanel pUniteOrganiques;
    private javax.swing.JTabbedPane tabbedPane;
    private editor.EditorRTF txtLibelle;
    private editor.EditorRTF txtMissions;
    private javax.swing.JFormattedTextField txtNumOrdre;
    // End of variables declaration//GEN-END:variables
}
