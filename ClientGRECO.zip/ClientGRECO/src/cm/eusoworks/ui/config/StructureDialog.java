/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PosteComptable;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.HighlightPredicate;
import org.jdesktop.swingx.renderer.DefaultListRenderer;

/**
 *
 * @author macbookair
 */
public class StructureDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private Structure currentStructure = null;
    private Organisation lastOrganisation = new Organisation("-11111");
    private Localite locality;
    private Categorie category;
    private Fonction fonction;
    private int mode;

    public static int MODE_NORMAL = 1;
    public static int MODE_STRUCTURE_BUDGETAIRE = 2;

    public StructureDialog(JFrame parent, boolean modal, int mode) {
        super(parent, modal);
        initComponents();
        this.mode = mode;
        jListstructure.setRolloverEnabled(true);
        jListstructure.setCellRenderer(new DefaultListRenderer());
        jListstructure.addHighlighter(new ColorHighlighter(HighlightPredicate.ROLLOVER_ROW, new Color(135, 164, 190), Color.white));
        loadOrganisations();
        // loadUniteOrganiques();
        initUI();
        initMode();
//        initHierarchie();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Gestion des structures de l'organisme ");
        setPreferredSize(new Dimension(1000, 650));
        pack();
    }

    public StructureDialog(JFrame parent, boolean modal) {
        this(parent, modal, MODE_NORMAL);
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
                initHierarchie();
            }

        }
    }

    private void loadUniteOrganiques() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            return;
        }
        List<UniteOrganique> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getUniteOrganiqueService().listeUniteOrganique(o.getOrganisationID());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboUniteOrganique.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboUniteOrganique.setSelectedIndex(0);
            }
        }
    }

    private void loadPosteComptables() {
        List<PosteComptable> list = new ArrayList();

        if (locality != null) {
            try {
                list = GrecoServiceFactory.getPosteComptableService().getPosteComptableOfLocalite(locality.getCode());
            } catch (Exception e) {
            }
        }
        if (list != null && !list.isEmpty()) {
            cboPosteComptable.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboPosteComptable.setSelectedIndex(0);
            } else {
                cboPosteComptable.setSelectedIndex(-1);
            }
        }
    }

    private void loadStructureOrganisation() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            List<Structure> list = new ArrayList<Structure>();
            try {
                list = GrecoServiceFactory.getOrganisationService().listeStructuresOrganisation(o.getOrganisationID());
            } catch (Exception e) {
                list = null;
            }
            jListstructure.removeAll();
            if (list != null && !list.isEmpty()) {
                cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
                cboStructure.setSelectedIndex(-1);
                jListstructure.setListData(list.toArray());
            }

        }
    }

    private void initHierarchie() {
        Structure root = new Structure("-1", "Organigramme " + GrecoAppConfig.getOrgSigleFr());

        DefaultMutableTreeNode rootNode = new DefaultMutableTreeNode(root);

        List<Structure> listRacines = new ArrayList<>();
        try {
            Organisation o = (Organisation) cboOrganisation.getSelectedItem();
            if (o != null) {
                listRacines = GrecoServiceFactory.getOrganisationService().listeStructuresFilles(o.getOrganisationID(), null);
                if (listRacines != null && !listRacines.isEmpty()) {
                    for (int i = 0; i < listRacines.size(); i++) {
                        Structure s = listRacines.get(i);
                        DefaultMutableTreeNode node = new DefaultMutableTreeNode(s);
                        if (s.getChilds() > 0) {
                            node.add(new DefaultMutableTreeNode());
                        }
                        rootNode.add(node);
                    }
                    treeStructure.setModel(new DefaultTreeModel(rootNode));
                }
            }

        } catch (Exception e) {
            listRacines = null;
            e.printStackTrace();
        }

        //
    }

    private void initMode() {
        if (this.mode == MODE_STRUCTURE_BUDGETAIRE) {
            initStructureBudgetaire();
        }
    }

    private void initStructureBudgetaire() {
        try {
            category = GrecoServiceFactory.getNomenclatureService().getCategorie("89");
            lblCategorie.setText(category.toString());
            txtCodeCategorie.setText(category.getCode());
            btnSelectCategorie.setEnabled(false);
        } catch (Exception e) {
        }
        try {
            fonction = GrecoServiceFactory.getNomenclatureService().getFonction("311");
            lblFonction.setText(fonction.toString());
            btnSelectFonction.setEnabled(false);
        } catch (Exception e) {
        }
        try {
            locality = GrecoServiceFactory.getNomenclatureService().getLocalite("00");
            lblLocalite.setText(locality.toString());
            btnSelectionnerLocalite.setEnabled(false);
            txtCodeLocalite.setText(locality.getCode().substring(0, 2));
            btnSelectionnerLocaliteActionPerformed(null);
        } catch (Exception e) {
        }

    }

    private void initUI() {

        if (currentStructure == null) {
            try {
                cboOrganisation.setSelectedIndex(-1);
            } catch (Exception e) {
            }

            cboStructure.setSelectedIndex(-1);
            cboUniteOrganique.setSelectedIndex(-1);
            txtAbbreviation.clear();
            txtLibelle.clear();
            category = null;
            lblCategorie.setText("");
            fonction = null;
            lblFonction.setText("");
            locality = null;
            lblLocalite.setText("");
            cboPosteComptable.setSelectedIndex(-1);
            txtCodeCategorie.setText(null);
            txtCodeLocalite.setText(null);
            txtNumeroOrdre.setText(null);
            dtpDateCreation.setDate(new Date());
            dtpDateCessation.setDate(null);
            chkActive.setSelected(true);

        } else {
            for (int i = 0; i < cboOrganisation.getItemCount(); i++) {
                Organisation o = (Organisation) cboOrganisation.getItemAt(i);
                if (currentStructure.getOrganisationID().equalsIgnoreCase(o.getOrganisationID())) {
                    cboOrganisation.setSelectedIndex(i);
                    break;
                }
            }
            if (currentStructure.getStructureParentID() != null) {
                for (int i = 0; i < cboStructure.getItemCount(); i++) {
                    Structure s = (Structure) cboStructure.getItemAt(i);
                    if (currentStructure.getStructureParentID().equalsIgnoreCase(s.getStructureID())) {
                        cboStructure.setSelectedIndex(i);
                        break;
                    }
                }
            }

            for (int i = 0; i < cboUniteOrganique.getItemCount(); i++) {
                UniteOrganique u = (UniteOrganique) cboUniteOrganique.getItemAt(i);
                if (currentStructure.getUniteOrganiqueID().equalsIgnoreCase(u.getUniteOrganiqueID())) {
                    cboUniteOrganique.setSelectedIndex(i);
                    break;
                }
            }
            txtAbbreviation.setTextFr(currentStructure.getAbbreviationFr());
            txtAbbreviation.setTextUs(currentStructure.getAbbreviationUs());
            txtLibelle.setTextFr(currentStructure.getLibelleFr());
            txtLibelle.setTextUs(currentStructure.getLibelleUs());

            //categorie de service
            try {
                Categorie c = GrecoServiceFactory.getNomenclatureService().getCategorie(currentStructure.getCategorieCode());
                if (c != null) {
                    category = c;
                    lblCategorie.setText(c.getLibelle());
                }
            } catch (Exception e) {
            }

            try {
                Fonction f = GrecoServiceFactory.getNomenclatureService().getFonction(currentStructure.getFonctionCode());
                if (f != null) {
                    fonction = f;
                    lblFonction.setText(f.getLibelle());
                }
            } catch (Exception e) {
            }
            try {
                Localite l = GrecoServiceFactory.getNomenclatureService().getLocalite(currentStructure.getLocaliteCode());
                if (l != null) {
                    locality = l;
                    lblLocalite.setText(l.getLibelle());
                    //poste comptables
                    loadPosteComptables();
                    for (int i = 0; i < cboPosteComptable.getItemCount(); i++) {
                        PosteComptable p = (PosteComptable) cboPosteComptable.getItemAt(i);
                        if (currentStructure.getPosteComptableID().equalsIgnoreCase(p.getPosteComptableID())) {
                            cboPosteComptable.setSelectedIndex(i);
                            break;
                        }
                    }
                }
            } catch (Exception e) {
            }
            //numero d'ordre
            txtCodeCategorie.setText(currentStructure.getCode().substring(0, 2));
            txtCodeLocalite.setText(currentStructure.getCode().substring(2, 4));
            txtNumeroOrdre.setText(currentStructure.getCode().substring(4));

            dtpDateCreation.setDate(currentStructure.getDateCreation());
            dtpDateCessation.setDate(currentStructure.getDateCessation());
            chkActive.setSelected(currentStructure.getActif());

        }
    }

    private void remplirCurrentStructure() {
        currentStructure.setOrganisationID(((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID());
        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s == null) {
            currentStructure.setStructureParentID(null);
        } else {
            currentStructure.setStructureParentID(s.getStructureID());
        }
        currentStructure.setUniteOrganiqueID(((UniteOrganique) cboUniteOrganique.getSelectedItem()).getUniteOrganiqueID());

        currentStructure.setAbbreviationFr(txtAbbreviation.getTextFr().toUpperCase());
        currentStructure.setAbbreviationUs(txtAbbreviation.getTextUs().toUpperCase());
        currentStructure.setLibelleFr(txtLibelle.getTextFr());
        currentStructure.setLibelleUs(txtLibelle.getTextUs());

        currentStructure.setCategorieCode(category.getCode());
        currentStructure.setFonctionCode(fonction.getCode());
        currentStructure.setLocaliteCode(locality.getCode());

        currentStructure.setPosteComptableID(((PosteComptable) cboPosteComptable.getSelectedItem()).getPosteComptableID());
        StringBuilder code = new StringBuilder();
        code.append(txtCodeCategorie.getText().trim());
        code.append(txtCodeLocalite.getText().trim());
        code.append(txtNumeroOrdre.getText().trim());
        currentStructure.setCode(code.toString().trim());

        currentStructure.setDateCreation(dtpDateCreation.getDate());
        currentStructure.setDateCessation(dtpDateCessation.getDate());
        currentStructure.setActif(chkActive.isSelected());
        currentStructure.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentStructure.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        splitpane = new javax.swing.JSplitPane();
        jScrollPane1 = new javax.swing.JScrollPane();
        treeStructure = new javax.swing.JTree();
        jSplitPane1 = new javax.swing.JSplitPane();
        pListPC = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListstructure = new org.jdesktop.swingx.JXList();
        jPanel3 = new javax.swing.JPanel();
        btnAddOrg = new javax.swing.JButton();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtAbbreviation = new editor.EditorRTF();
        txtLibelle = new editor.EditorRTF();
        dtpDateCreation = new org.jdesktop.swingx.JXDatePicker();
        dtpDateCessation = new org.jdesktop.swingx.JXDatePicker();
        chkActive = new javax.swing.JCheckBox();
        txtNumeroOrdre = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        btnSelectionnerLocalite = new javax.swing.JButton();
        lblLocalite = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        cboUniteOrganique = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        cboPosteComptable = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnSelectCategorie = new javax.swing.JButton();
        btnSelectFonction = new javax.swing.JButton();
        lblCategorie = new javax.swing.JLabel();
        lblFonction = new javax.swing.JLabel();
        txtCodeCategorie = new javax.swing.JFormattedTextField();
        txtCodeLocalite = new javax.swing.JFormattedTextField();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        setPreferredSize(new java.awt.Dimension(955, 600));

        splitpane.setDividerLocation(250);

        treeStructure.addTreeExpansionListener(new javax.swing.event.TreeExpansionListener() {
            public void treeExpanded(javax.swing.event.TreeExpansionEvent evt) {
                treeStructureTreeExpanded(evt);
            }
            public void treeCollapsed(javax.swing.event.TreeExpansionEvent evt) {
            }
        });
        treeStructure.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                treeStructureMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(treeStructure);

        splitpane.setLeftComponent(jScrollPane1);

        pListPC.setLayout(new java.awt.BorderLayout());

        jListstructure.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListstructure.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jListstructure.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jListstructure.setSelectionForeground(new java.awt.Color(0, 102, 255));
        jListstructure.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListstructureMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jListstructure);

        pListPC.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 15, 5));

        btnAddOrg.setText("Ajouter une nouvelle structure");
        btnAddOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddOrgActionPerformed(evt);
            }
        });
        jPanel3.add(btnAddOrg);

        pListPC.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jSplitPane1.setLeftComponent(pListPC);

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(null);
        jPanel1.add(txtAbbreviation);
        txtAbbreviation.setBounds(210, 130, 430, 64);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(210, 210, 430, 60);
        jPanel1.add(dtpDateCreation);
        dtpDateCreation.setBounds(210, 510, 140, 26);
        jPanel1.add(dtpDateCessation);
        dtpDateCessation.setBounds(540, 510, 140, 26);

        chkActive.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkActive.setSelected(true);
        chkActive.setText("Structure active ?");
        chkActive.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        chkActive.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel1.add(chkActive);
        chkActive.setBounds(480, 460, 160, 40);

        try {
            txtNumeroOrdre.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtNumeroOrdre.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jPanel1.add(txtNumeroOrdre);
        txtNumeroOrdre.setBounds(330, 450, 80, 38);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("Code de la structure : ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 450, 160, 30);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Sigle : ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 130, 88, 40);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Designation :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 210, 140, 40);

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel5.setText("Date de creation : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(20, 510, 130, 20);

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel6.setText("Date de cessation : ");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(390, 510, 140, 20);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme/Administration  :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 20, 180, 17);

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        jPanel1.add(cboOrganisation);
        cboOrganisation.setBounds(210, 20, 420, 27);

        jLabel8.setText("Localité :");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(20, 370, 100, 30);

        btnSelectionnerLocalite.setText("sélectionner une localité ");
        btnSelectionnerLocalite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectionnerLocaliteActionPerformed(evt);
            }
        });
        jPanel1.add(btnSelectionnerLocalite);
        btnSelectionnerLocalite.setBounds(210, 370, 170, 29);

        lblLocalite.setForeground(new java.awt.Color(0, 153, 102));
        jPanel1.add(lblLocalite);
        lblLocalite.setBounds(390, 370, 300, 20);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Structure hiérarchique : ");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 44, 170, 30);

        cboStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboStructureActionPerformed(evt);
            }
        });
        jPanel1.add(cboStructure);
        cboStructure.setBounds(210, 50, 420, 27);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Unité organique : ");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(20, 84, 140, 30);

        jPanel1.add(cboUniteOrganique);
        cboUniteOrganique.setBounds(210, 90, 420, 27);

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Poste comptable : ");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(20, 410, 140, 20);

        jPanel1.add(cboPosteComptable);
        cboPosteComptable.setBounds(210, 410, 420, 27);

        jLabel11.setText("Catégorie de service :");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(20, 290, 140, 20);

        jLabel12.setText("Fonction : ");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(20, 330, 100, 20);

        btnSelectCategorie.setText("Sélectionner une catégorie : ");
        btnSelectCategorie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectCategorieActionPerformed(evt);
            }
        });
        jPanel1.add(btnSelectCategorie);
        btnSelectCategorie.setBounds(210, 290, 170, 29);

        btnSelectFonction.setText("Sélectionner la fontion : ");
        btnSelectFonction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectFonctionActionPerformed(evt);
            }
        });
        jPanel1.add(btnSelectFonction);
        btnSelectFonction.setBounds(210, 330, 170, 29);

        lblCategorie.setForeground(new java.awt.Color(255, 153, 0));
        jPanel1.add(lblCategorie);
        lblCategorie.setBounds(390, 290, 300, 20);
        jPanel1.add(lblFonction);
        lblFonction.setBounds(390, 330, 300, 20);

        try {
            txtCodeCategorie.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCodeCategorie.setEnabled(false);
        txtCodeCategorie.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jPanel1.add(txtCodeCategorie);
        txtCodeCategorie.setBounds(210, 450, 60, 38);

        try {
            txtCodeLocalite.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCodeLocalite.setEnabled(false);
        txtCodeLocalite.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jPanel1.add(txtCodeLocalite);
        txtCodeLocalite.setBounds(270, 450, 60, 38);

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 15, 5));

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnSupprimer.setText("Supprimer");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel2.add(btnSupprimer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        jSplitPane1.setRightComponent(pDetails);

        splitpane.setRightComponent(jSplitPane1);

        getContentPane().add(splitpane, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentStructure == null) {
                currentStructure = new Structure();
                remplirCurrentStructure();
                try {
                    GrecoServiceFactory.getOrganisationService().ajouterStructure(currentStructure);
                    GrecoSession.notifications.success();
                    loadStructureOrganisation();
                    initUI();
                } catch (GrecoException ex) {
                    currentStructure = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else { // modification de l'organisation 
                remplirCurrentStructure();
                try {
                    GrecoServiceFactory.getOrganisationService().modifierStructure(currentStructure);
                    GrecoSession.notifications.success();
                    loadStructureOrganisation();
                    initUI();
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (!currentStructure.getStructureID().isEmpty()) {
            int reponse = JOptionPane.showConfirmDialog(this, "Estes-vous sur de vouloir supprimer la structure " + "\n" + currentStructure.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getOrganisationService().supprimerStructure(currentStructure.getStructureID());
                    GrecoSession.notifications.success();
                    loadStructureOrganisation();
                    currentStructure = null;
                    initUI();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAddOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddOrgActionPerformed
        // TODO add your handling code here:
        currentStructure = null;
        initUI();
        btnSelectCategorie.setEnabled(true);
        btnSelectFonction.setEnabled(true);
        btnSelectionnerLocalite.setEnabled(true);

    }//GEN-LAST:event_btnAddOrgActionPerformed

    private void jListstructureMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListstructureMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            currentStructure = (Structure) jListstructure.getSelectedValue();
            initUI();
        }
    }//GEN-LAST:event_jListstructureMouseClicked

    private void btnSelectionnerLocaliteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectionnerLocaliteActionPerformed
        // TODO add your handling code here:
        final ViewLocaliteDialog dialog = new ViewLocaliteDialog(null, true);
        dialog.setVisible(true);
        locality = dialog.getSelectedLocalite();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if (locality == null) {
            lblLocalite.setForeground(Color.red);
            lblLocalite.setText("Attention!!! aucune localité choisie");
            txtCodeLocalite.setText("");
        } else {
            lblLocalite.setForeground(new Color(0, 153, 102));
            lblLocalite.setText(locality.getLibelle(Locale.getDefault()));
            txtCodeLocalite.setText(locality.getCode().substring(0, 2));
        }
        loadPosteComptables();


    }//GEN-LAST:event_btnSelectionnerLocaliteActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        loadStructureOrganisation();
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (!o.getOrganisationID().equals(lastOrganisation.getOrganisationID())) {
            lastOrganisation.setOrganisationID(o.getOrganisationID());
            initHierarchie();
        }

    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void btnSelectCategorieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectCategorieActionPerformed
        // TODO add your handling code here:
        final ViewCategorieDialog dialog = new ViewCategorieDialog(null, true);
        dialog.setVisible(true);
        category = dialog.getSelectedCategorie();
        if (category.getNiveauID() != GrecoSession.optionNiveau.getCa().intValue()) {
            category = null;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if (category == null) {
            lblCategorie.setForeground(Color.red);
            lblCategorie.setText("Attention!!! aucune catégorie de service choisie");
            txtCodeCategorie.setText("");
        } else {
            lblCategorie.setForeground(new Color(0, 153, 102));
            lblCategorie.setText(category.getLibelle(Locale.getDefault()));
            txtCodeCategorie.setText(category.getCode());
        }
    }//GEN-LAST:event_btnSelectCategorieActionPerformed

    private void btnSelectFonctionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectFonctionActionPerformed
        // TODO add your handling code here:
        final ViewFonctionDialog dialog = new ViewFonctionDialog(null, true);
        dialog.setVisible(true);
        fonction = dialog.getSelectedFonction();
        if (fonction.getNiveauID() != GrecoSession.optionNiveau.getFu()) {
            fonction = null;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if (fonction == null) {
            lblFonction.setForeground(Color.red);
            lblFonction.setText("Attention!!! aucune fonction secondaire choisie");
        } else {
            lblFonction.setForeground(new Color(0, 153, 102));
            lblFonction.setText(fonction.getLibelle(Locale.getDefault()));
        }
    }//GEN-LAST:event_btnSelectFonctionActionPerformed

    private void treeStructureTreeExpanded(javax.swing.event.TreeExpansionEvent evt) {//GEN-FIRST:event_treeStructureTreeExpanded
        // TODO add your handling code here:
        Object o = evt.getPath().getLastPathComponent();
        DefaultMutableTreeNode node = (DefaultMutableTreeNode) o;
        Structure s = (Structure) node.getUserObject();
        List<Structure> list = new ArrayList<Structure>();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeStructuresFilles(s.getOrganisationID(), s.getStructureID());
        } catch (Exception e) {
            list = null;
        }
        node.removeAllChildren();
        if (list != null && !list.isEmpty()) {
            for (Structure st : list) {
                DefaultMutableTreeNode n = new DefaultMutableTreeNode(st);
                if (st.getChilds() > 0) {
                    n.add(new DefaultMutableTreeNode());
                }
                node.add(n);
            }
        }
        ((DefaultTreeModel) treeStructure.getModel()).reload(node);

    }//GEN-LAST:event_treeStructureTreeExpanded

    private void treeStructureMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeStructureMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            Object o = treeStructure.getSelectionPath().getLastPathComponent();
            DefaultMutableTreeNode node = (DefaultMutableTreeNode) o;
            Structure s = (Structure) node.getUserObject();
            if (!s.getStructureID().equalsIgnoreCase("-1")) {
                currentStructure = s;
                initUI();
            }
        }
    }//GEN-LAST:event_treeStructureMouseClicked

    private void cboStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboStructureActionPerformed
        // TODO add your handling code here:
        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s != null) {
            List<UniteOrganique> list = new ArrayList();
            try {
                list = GrecoServiceFactory.getUniteOrganiqueService().getUniteOrganiqueFillesForStructure(s.getStructureID());
            } catch (Exception e) {
            }
            if (list != null && !list.isEmpty()) {
                cboUniteOrganique.setModel(new DefaultComboBoxModel(list.toArray()));
                if (list.size() == 1) {
                    cboUniteOrganique.setSelectedIndex(0);
                }
            }
        }
    }//GEN-LAST:event_cboStructureActionPerformed

    private boolean controlData() {
        boolean res = true;
        UniteOrganique u = (UniteOrganique) cboUniteOrganique.getSelectedItem();
        if (u == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une unité organique ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtAbbreviation.getTextFr().isEmpty() || txtAbbreviation.getTextUs().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("pleaseSigle"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtLibelle.getTextFr().isEmpty() || txtLibelle.getTextUs().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("pleaseLibelle"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (category == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la catégorie de service", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (fonction == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la fonction secondaire ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (locality == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la localite geographique dans laquelle le poste comptable est crée", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        PosteComptable p = (PosteComptable) cboPosteComptable.getSelectedItem();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Sélectionner le poste comptable rattaché à cette structure", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtNumeroOrdre.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez entrer le numéro d'ordre de la structure", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StructureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StructureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StructureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StructureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                StructureDialog dialog = new StructureDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddOrg;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnSelectCategorie;
    private javax.swing.JButton btnSelectFonction;
    private javax.swing.JButton btnSelectionnerLocalite;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboPosteComptable;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboUniteOrganique;
    private javax.swing.JCheckBox chkActive;
    private org.jdesktop.swingx.JXDatePicker dtpDateCessation;
    private org.jdesktop.swingx.JXDatePicker dtpDateCreation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private org.jdesktop.swingx.JXList jListstructure;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblCategorie;
    private javax.swing.JLabel lblFonction;
    private javax.swing.JLabel lblLocalite;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListPC;
    private javax.swing.JSplitPane splitpane;
    private javax.swing.JTree treeStructure;
    private editor.EditorRTF txtAbbreviation;
    private javax.swing.JFormattedTextField txtCodeCategorie;
    private javax.swing.JFormattedTextField txtCodeLocalite;
    private editor.EditorRTF txtLibelle;
    private javax.swing.JFormattedTextField txtNumeroOrdre;
    // End of variables declaration//GEN-END:variables
}
