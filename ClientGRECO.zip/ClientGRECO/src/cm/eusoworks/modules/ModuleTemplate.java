/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.modules;

import cm.eusoworks.component.EtiketNote1;
import cm.eusoworks.component.EtiketNote2;
import cm.eusoworks.component.EtiketNote3;
import cm.eusoworks.component.EtiketNote4;
import cm.eusoworks.component.EtiketNote5;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.context.NotesDialog;
import cm.eusoworks.entities.model.Notes;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import java.awt.Cursor;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.SwingUtilities;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author jeanemmanuel
 */
public class ModuleTemplate extends javax.swing.JFrame {

    protected JLayeredPane frameLayer = null;
    protected String moduleID;
    protected JFrame me;
    protected List<Notes> listeNotes = ObservableCollections.observableList(new ArrayList<Notes>());
    Notes selectedNote;

    /**
     * Creates new form ModuleTemplate
     */
    public ModuleTemplate(String modID) {
        initComponents();
        this.moduleID = modID;
        frameLayer = getLayeredPane();
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        lblMemo.setBounds(100, 200, 175, 165);
        frameLayer.add(lblMemo, JLayeredPane.POPUP_LAYER);

        scrollNote.setBounds(270, 250, 650, 345);
        scrollNote.setVisible(false);
        frameLayer.add(scrollNote, JLayeredPane.POPUP_LAYER);

        loadNotes(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_CONNECTED.getLogin());
        afficherNotes();

        me = this;
    }

    public void actualiserNotes(){
        loadNotes(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_CONNECTED.getLogin());
        removeNotes();
        afficherNotes();
    }
    
    protected void loadNotes(String proprietaire, String destinataire) {
        List<Notes> lst = GrecoServiceFactory.getOrganisationService().noteRechercher(null, null, moduleID, destinataire, new Date(), null, proprietaire, -1);
        listeNotes.clear();
        if (lst != null && !lst.isEmpty()) {
            lblMemo.setText("" + lst.size());
            for (Notes n : lst) {
                listeNotes.add(n);
            }
        } else {
            lblMemo.setText("");
        }
    }

    private void removeNotes() {
        int oldnb = 0;
        int nb = frameLayer.getComponentCount();
        while ((nb != 0) && (oldnb != nb)) {
            for (int i = 0; i < nb; i++) {
                Object c = frameLayer.getComponent(i);
                if (c instanceof EtiketNote1 || c instanceof EtiketNote2 || c instanceof EtiketNote3 || c instanceof EtiketNote4 || c instanceof EtiketNote5) {
                    frameLayer.remove(i);
                    break;
                }
            }
            oldnb = nb;
            nb = frameLayer.getComponentCount();
        }

        frameLayer.repaint();
    }

    private void afficherNotes() {
        int nbEtik = 5;
        int[] oldIndex = {1, 2, 3, 4, 5};
        int[] newIndex = {1, 2, 3, 4, 5};

        Random rand = new Random();
        int r, i;
        int x = 200;
        int y = 250;

        if (listeNotes != null && !listeNotes.isEmpty()) {
            for (Notes n : listeNotes) {
                r = rand.nextInt(nbEtik);
                i = newIndex[r];
                //affichage de l'etiket a lindex r
                switch (i) {
                    case 1:
                        EtiketNote1 note1 = new EtiketNote1(n, this);
                        note1.setBounds(x+25, y, note1.getWidth(), note1.getHeight());
                        frameLayer.add(note1, JLayeredPane.PALETTE_LAYER);
                        break;
                    case 2:
                        EtiketNote2 note2 = new EtiketNote2(n, this);
                        note2.setBounds(x+250, y-80, note2.getWidth(), note2.getHeight());
                        frameLayer.add(note2, JLayeredPane.PALETTE_LAYER);
                        break;
                    case 3:
                        EtiketNote3 note3 = new EtiketNote3(n, this);
                        note3.setBounds(x+400, y+150, note3.getWidth(), note3.getHeight());
                        frameLayer.add(note3, JLayeredPane.PALETTE_LAYER);
                        break;
                    case 4:
                        EtiketNote4 note4 = new EtiketNote4(n, this);
                        note4.setBounds(x+125, y+140, note4.getWidth(), note4.getHeight());
                        frameLayer.add(note4, JLayeredPane.PALETTE_LAYER);
                        break;
                    case 5:
                        EtiketNote5 note5 = new EtiketNote5(n, this);
                        note5.setBounds(x+190, y+260, note5.getWidth(), note5.getHeight());
                        frameLayer.add(note5, JLayeredPane.PALETTE_LAYER);
                        break;
                }
                // sauvegarder le tableau actuel 
                oldIndex = new int[newIndex.length];
                for (int j = 0; j < newIndex.length; j++) {
                    oldIndex[j] = newIndex[j]; 
                }
                // creer un nouveau tableau en retirant cette etiket
                nbEtik--;
                if (nbEtik == 0) {
                    //reinitialiser les tableaux
                    nbEtik = 5;
                    newIndex = new int[]{1, 2, 3, 4, 5};
                    x = x + 75;
                    y = y + 200;
                } else {
                    newIndex = new int[nbEtik];
                    int k = 0;
                    for (int j = 0; j < oldIndex.length; j++) {
                        if (oldIndex[j] != i) {
                            newIndex[k] = oldIndex[j];
                            k++;
                        };
                    }
                }

            }
        } else {
            removeNotes();
        }
    }

    public List<Notes> getListeNotes() {
        return listeNotes;
    }

    public void setListeNotes(List<Notes> listeNotes) {
        this.listeNotes = listeNotes;
    }

    public Notes getSelectedNote() {
        return selectedNote;
    }

    public void setSelectedNote(Notes selectedNote) {
        this.selectedNote = selectedNote;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        lblMemo = new javax.swing.JLabel();
        notePopupMenu = new javax.swing.JPopupMenu();
        nmuNouvelleNote = new javax.swing.JMenuItem();
        jSeparator1 = new javax.swing.JPopupMenu.Separator();
        mnuMesNotesCrees = new javax.swing.JMenuItem();
        mnuMesNotesDestinees = new javax.swing.JMenuItem();
        mnuToutesMesNotes = new javax.swing.JMenuItem();
        jSeparator2 = new javax.swing.JPopupMenu.Separator();
        mnuAfficherTableau = new javax.swing.JMenuItem();
        mnuAfficherEtiquettes = new javax.swing.JMenuItem();
        jSeparator3 = new javax.swing.JPopupMenu.Separator();
        mnuNerienAfficher = new javax.swing.JMenuItem();
        scrollNote = new javax.swing.JScrollPane();
        tableNotes = new org.jdesktop.swingx.JXTable();

        lblMemo.setFont(new java.awt.Font("Arial", 1, 60)); // NOI18N
        lblMemo.setForeground(new java.awt.Color(0, 102, 204));
        lblMemo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblMemo.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/etiket.png"))); // NOI18N
        lblMemo.setText("03");
        lblMemo.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblMemo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                lblMemoMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                lblMemoMouseReleased(evt);
            }
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblMemoMouseClicked(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblMemoMouseExited(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblMemoMouseEntered(evt);
            }
        });

        nmuNouvelleNote.setText("Nouvelle note ...");
        nmuNouvelleNote.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nmuNouvelleNoteActionPerformed(evt);
            }
        });
        notePopupMenu.add(nmuNouvelleNote);
        notePopupMenu.add(jSeparator1);

        mnuMesNotesCrees.setText("je veux voir les notes que j'ai cree");
        mnuMesNotesCrees.setToolTipText("");
        mnuMesNotesCrees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuMesNotesCreesActionPerformed(evt);
            }
        });
        notePopupMenu.add(mnuMesNotesCrees);

        mnuMesNotesDestinees.setText("je veux voir les notes dont je suis le destinataire");
        mnuMesNotesDestinees.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuMesNotesDestineesActionPerformed(evt);
            }
        });
        notePopupMenu.add(mnuMesNotesDestinees);

        mnuToutesMesNotes.setText("je veux voir toutes les notes qui me concernent");
        mnuToutesMesNotes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuToutesMesNotesActionPerformed(evt);
            }
        });
        notePopupMenu.add(mnuToutesMesNotes);
        notePopupMenu.add(jSeparator2);

        mnuAfficherTableau.setText("Afficher les notes dans un tableau");
        mnuAfficherTableau.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAfficherTableauActionPerformed(evt);
            }
        });
        notePopupMenu.add(mnuAfficherTableau);

        mnuAfficherEtiquettes.setText("Afficher les notes en forme d'etiquette");
        mnuAfficherEtiquettes.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuAfficherEtiquettesActionPerformed(evt);
            }
        });
        notePopupMenu.add(mnuAfficherEtiquettes);
        notePopupMenu.add(jSeparator3);

        mnuNerienAfficher.setText("Ne plus afficher les Memos");
        mnuNerienAfficher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                mnuNerienAfficherActionPerformed(evt);
            }
        });
        notePopupMenu.add(mnuNerienAfficher);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listeNotes}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableNotes);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${objet}"));
        columnBinding.setColumnName("Objet");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${dateAffichage}"));
        columnBinding.setColumnName("Depuis le ");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${userUpdate}"));
        columnBinding.setColumnName("Auteur");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${statut}"));
        columnBinding.setColumnName("Statut");
        columnBinding.setColumnClass(Integer.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedNote}"), tableNotes, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tableNotes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableNotesMouseClicked(evt);
            }
        });
        scrollNote.setViewportView(tableNotes);
        if (tableNotes.getColumnModel().getColumnCount() > 0) {
            tableNotes.getColumnModel().getColumn(0).setPreferredWidth(300);
            tableNotes.getColumnModel().getColumn(1).setPreferredWidth(80);
            tableNotes.getColumnModel().getColumn(2).setPreferredWidth(100);
            tableNotes.getColumnModel().getColumn(3).setPreferredWidth(50);
        }

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 544, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 312, Short.MAX_VALUE)
        );

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblMemoMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMemoMouseEntered
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_lblMemoMouseEntered

    private void lblMemoMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMemoMouseExited
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_lblMemoMouseExited

    private void lblMemoMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMemoMousePressed
        // TODO add your handling code here:
        showNotePopupMenu(evt);
    }//GEN-LAST:event_lblMemoMousePressed

    private void lblMemoMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMemoMouseReleased
        // TODO add your handling code here:
        showNotePopupMenu(evt);
    }//GEN-LAST:event_lblMemoMouseReleased

    private void nmuNouvelleNoteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nmuNouvelleNoteActionPerformed
        // TODO add your handling code here:
        nouvelleNote();
    }//GEN-LAST:event_nmuNouvelleNoteActionPerformed

    private void mnuAfficherEtiquettesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuAfficherEtiquettesActionPerformed
        // TODO add your handling code here:
        removeNotes();
        scrollNote.setVisible(false);
        afficherNotes();
    }//GEN-LAST:event_mnuAfficherEtiquettesActionPerformed

    private void mnuAfficherTableauActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuAfficherTableauActionPerformed
        // TODO add your handling code here:
        removeNotes();
        scrollNote.setVisible(true);
    }//GEN-LAST:event_mnuAfficherTableauActionPerformed

    private void mnuNerienAfficherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuNerienAfficherActionPerformed
        // TODO add your handling code here:
        removeNotes();
        scrollNote.setVisible(false);
    }//GEN-LAST:event_mnuNerienAfficherActionPerformed

    private void tableNotesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableNotesMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if (selectedNote != null) {
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            NotesDialog frame = new NotesDialog(me, true, selectedNote, moduleID);
                            frame.setVisible(true);
                            loadNotes(null, null);
                        } catch (Exception e) {
                        }
                    }
                });
            } else {
                GrecoOptionPane.showWarningDialog("Aucun Memo a affciher... ");
            }
        }
    }//GEN-LAST:event_tableNotesMouseClicked

    private void mnuMesNotesCreesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuMesNotesCreesActionPerformed
        // TODO add your handling code here:
        loadNotes(GrecoSession.USER_CONNECTED.getLogin(), null);
        removeNotes();
        scrollNote.setVisible(false);
        afficherNotes();
    }//GEN-LAST:event_mnuMesNotesCreesActionPerformed

    private void mnuMesNotesDestineesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuMesNotesDestineesActionPerformed
        // TODO add your handling code here:
        loadNotes(null, GrecoSession.USER_CONNECTED.getLogin());
        removeNotes();
        scrollNote.setVisible(false);
        afficherNotes();
    }//GEN-LAST:event_mnuMesNotesDestineesActionPerformed

    private void mnuToutesMesNotesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_mnuToutesMesNotesActionPerformed
        // TODO add your handling code here:
        loadNotes(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_CONNECTED.getLogin());
        removeNotes();
        scrollNote.setVisible(false);
        afficherNotes();
    }//GEN-LAST:event_mnuToutesMesNotesActionPerformed

    private void lblMemoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblMemoMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    try {
                        NotesDialog frame = new NotesDialog(me, true, null, moduleID);
                        frame.setVisible(true);
                        loadNotes(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_CONNECTED.getLogin());
                    } catch (Exception e) {
                    }
                }
            });
        }
    }//GEN-LAST:event_lblMemoMouseClicked

    private void nouvelleNote() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    NotesDialog frame = new NotesDialog(me, true, null, moduleID);
                    frame.setVisible(true);
                    //recharger les notes et actualiser les etiquettes et tableaux 
                    loadNotes(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_CONNECTED.getLogin());
                } catch (Exception e) {
                }
            }
        });
    }

    private void showNotePopupMenu(MouseEvent evt) {
        if (evt.isPopupTrigger()) {
            notePopupMenu.setLocation(evt.getXOnScreen(), evt.getYOnScreen());
            notePopupMenu.setEnabled(true);
            notePopupMenu.setVisible(true);
            notePopupMenu.show(lblMemo, evt.getX(), evt.getY());
        }
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPopupMenu.Separator jSeparator1;
    private javax.swing.JPopupMenu.Separator jSeparator2;
    private javax.swing.JPopupMenu.Separator jSeparator3;
    private javax.swing.JLabel lblMemo;
    private javax.swing.JMenuItem mnuAfficherEtiquettes;
    private javax.swing.JMenuItem mnuAfficherTableau;
    private javax.swing.JMenuItem mnuMesNotesCrees;
    private javax.swing.JMenuItem mnuMesNotesDestinees;
    private javax.swing.JMenuItem mnuNerienAfficher;
    private javax.swing.JMenuItem mnuToutesMesNotes;
    private javax.swing.JMenuItem nmuNouvelleNote;
    private javax.swing.JPopupMenu notePopupMenu;
    private javax.swing.JScrollPane scrollNote;
    private org.jdesktop.swingx.JXTable tableNotes;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
