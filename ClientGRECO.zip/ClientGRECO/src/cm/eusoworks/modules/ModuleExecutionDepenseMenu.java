/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.modules;

import cm.eusoworks.entities.view.VueUsersFonctionnalite;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author jeanemmanuel
 */
public class ModuleExecutionDepenseMenu {

    private static List<VueUsersFonctionnalite> listFonctions;

    public static List<VueUsersFonctionnalite> getListMenus() {
        listFonctions = new ArrayList<>();
        VueUsersFonctionnalite e0 = new VueUsersFonctionnalite("EXD0", "", "Modèles d'actes", "", "EXD0", 5, "1000", true);
        listFonctions.add(e0);
        VueUsersFonctionnalite e00 = new VueUsersFonctionnalite("EXD00", "EXD0", "Etablir un Bon de Commande Administratif", "", "EXD00", 5, "1000", true);
        listFonctions.add(e00);
        VueUsersFonctionnalite e01 = new VueUsersFonctionnalite("EXD01", "EXD0", "Etablir un Ordre de Mission", "", "EXD01", 5, "1000", true);
        listFonctions.add(e01);
        VueUsersFonctionnalite e02 = new VueUsersFonctionnalite("EXD02", "EXD0", "Etablir une décision ", "", "EXD02", 5, "1000", true);
        listFonctions.add(e02);
        VueUsersFonctionnalite e1 = new VueUsersFonctionnalite("EXD1", "", "Engagement", "", "EXD1", 5, "1000", true);
        listFonctions.add(e1);
        VueUsersFonctionnalite e11 = new VueUsersFonctionnalite("EXD11", "EXD1", "Saisie et modification d'une dépense", "", "EXD11", 5, "1000", true);
        listFonctions.add(e11);
        VueUsersFonctionnalite e12 = new VueUsersFonctionnalite("EXD12", "EXD1", "Réservation de crédit", "", "EXD12", 5, "1000", true);
        listFonctions.add(e12);
        VueUsersFonctionnalite e13 = new VueUsersFonctionnalite("EXD13", "EXD1", "Annulation de la réservation de crédit ", "", "EXD13", 5, "1000", true);
        listFonctions.add(e13);
        VueUsersFonctionnalite e14 = new VueUsersFonctionnalite("EXD14", "EXD1", "Transmission pour Contrôle de Conformité", "", "EXD14", 5, "1000", true);
        listFonctions.add(e14);
        VueUsersFonctionnalite e15 = new VueUsersFonctionnalite("EXD15", "EXD1", "Annulation de la Transmission pour Controle de Conformité", "", "EXD15", 5, "1000", true);
        listFonctions.add(e15);
        VueUsersFonctionnalite e17 = new VueUsersFonctionnalite("EXD17", "EXD1", "Réception des dossiers pour contrôle de conformité", "", "EXD17", 5, "1000", true);
        listFonctions.add(e17);
        VueUsersFonctionnalite e18 = new VueUsersFonctionnalite("EXD18", "EXD1", "Contrôle de Conformité", "", "EXD18", 5, "1000", true);
        listFonctions.add(e18);
        VueUsersFonctionnalite e19 = new VueUsersFonctionnalite("EXD19", "EXD1", "Annulation du Contrôle de Conformité", "", "EXD19", 5, "1000", true);
        listFonctions.add(e19);
        VueUsersFonctionnalite e110 = new VueUsersFonctionnalite("EXD110", "EXD1", "Génération d'un bordereau de rejet", "", "EXD110", 5, "1000", true);
        listFonctions.add(e110);
        VueUsersFonctionnalite e111 = new VueUsersFonctionnalite("EXD111", "EXD1", "Transmission pour Liquidation des droits", "", "EXD111", 5, "1000", true);
        listFonctions.add(e111);
        VueUsersFonctionnalite e112 = new VueUsersFonctionnalite("EXD112", "EXD1", "Annulation de la Transmission pour Liquidation", "", "EXD112", 5, "1000", true);
        listFonctions.add(e112);
        VueUsersFonctionnalite e114 = new VueUsersFonctionnalite("EXD114", "EXD1", "Demande d'annulation d'un dossier ...", "", "EXD114", 5, "1000", true);
        listFonctions.add(e114);
        VueUsersFonctionnalite e115 = new VueUsersFonctionnalite("EXD115", "EXD1", "Annulation de la dépense", "", "EXD115", 5, "1000", true);
        listFonctions.add(e115);
        VueUsersFonctionnalite e2 = new VueUsersFonctionnalite("EXD2", "", "Liquidation", "", "EXD2", 5, "1000", true);
        listFonctions.add(e2);
        VueUsersFonctionnalite e20 = new VueUsersFonctionnalite("EXD20", "EXD2", "Réception des dossiers pour liquidation", "", "EXD20", 5, "1000", true);
        listFonctions.add(e20);
        VueUsersFonctionnalite e21 = new VueUsersFonctionnalite("EXD21", "EXD2", "Saisie des éléments de liquidation", "", "EXD21", 5, "1000", true);
        listFonctions.add(e21);
        VueUsersFonctionnalite e22 = new VueUsersFonctionnalite("EXD22", "EXD2", "Supprimer une liquidation", "", "EXD22", 5, "1000", true);
        listFonctions.add(e22);
        VueUsersFonctionnalite e24 = new VueUsersFonctionnalite("EXD24", "EXD2", "Validation de la liquidation", "", "EXD24", 5, "1000", true);
        listFonctions.add(e24);
        VueUsersFonctionnalite e25 = new VueUsersFonctionnalite("EXD25", "EXD2", "Annuler la validation d'une liquidation", "", "EXD25", 5, "1000", true);
        listFonctions.add(e25);
        VueUsersFonctionnalite e3 = new VueUsersFonctionnalite("EXD3", "", "Mandatement", "", "EXD3", 5, "1000", true);
        listFonctions.add(e3);
        VueUsersFonctionnalite e30 = new VueUsersFonctionnalite("EXD30", "EXD3", "Nouveau Mandat de Paiement", "", "EXD30", 5, "1000", true);
        listFonctions.add(e30);
        VueUsersFonctionnalite e31 = new VueUsersFonctionnalite("EXD31", "EXD3", "Annuler un mandat de paiement", "", "EXD31", 5, "1000", true);
        listFonctions.add(e31);
        VueUsersFonctionnalite e32 = new VueUsersFonctionnalite("EXD32", "EXD3", "Transmission pour contrôle de la régularité", "", "EXD32", 5, "1000", true);
        listFonctions.add(e32);
        VueUsersFonctionnalite e33 = new VueUsersFonctionnalite("EXD33", "EXD3", "Annuler la transmission pour contrôle de régularité", "", "EXD33", 5, "1000", true);
        listFonctions.add(e33);
        VueUsersFonctionnalite e35 = new VueUsersFonctionnalite("EXD35", "EXD3", "Réception des dossiers pour Contrôle de la régularité", "", "EXD35", 5, "1000", true);
        listFonctions.add(e35);
        VueUsersFonctionnalite e36 = new VueUsersFonctionnalite("EXD36", "EXD3", "Controle de la régularité des Pièces", "", "EXD36", 5, "1000", true);
        listFonctions.add(e36);
        VueUsersFonctionnalite e38 = new VueUsersFonctionnalite("EXD38", "EXD3", "Transmission des mandats au Comptable", "", "EXD38", 5, "1000", true);
        listFonctions.add(e38);
        VueUsersFonctionnalite e39 = new VueUsersFonctionnalite("EXD39", "EXD3", "Mandat rejetés par le Comptable ", "", "EXD39", 5, "1000", true);
        listFonctions.add(e39);
        VueUsersFonctionnalite e310 = new VueUsersFonctionnalite("EXD310", "EXD3", "Annulation de la transmission au comptable", "", "EXD310", 5, "1000", true);
        listFonctions.add(e310);
        VueUsersFonctionnalite e4 = new VueUsersFonctionnalite("EXD4", "", "Paiement", "", "EXD4", 5, "1000", true);
        listFonctions.add(e4);
        VueUsersFonctionnalite e40 = new VueUsersFonctionnalite("EXD40", "EXD4", "Programmation des paiements", "", "EXD40", 5, "1000", true);
        listFonctions.add(e40);
        VueUsersFonctionnalite e41 = new VueUsersFonctionnalite("EXD41", "EXD4", "Edition des Supports de Paiement", "", "EXD41", 5, "1000", true);
        listFonctions.add(e41);
        VueUsersFonctionnalite e42 = new VueUsersFonctionnalite("EXD42", "EXD4", "Edition des Duplicata des Support de Paiement", "", "EXD42", 5, "1000", true);
        listFonctions.add(e42);
        VueUsersFonctionnalite e43 = new VueUsersFonctionnalite("EXD43", "EXD4", "Enregistrer un Précompte", "", "EXD43", 5, "1000", true);
        listFonctions.add(e43);
        VueUsersFonctionnalite e44 = new VueUsersFonctionnalite("EXD44", "EXD4", "Validation de la créance", "", "EXD44", 5, "1000", true);
        listFonctions.add(e44);
        VueUsersFonctionnalite e5 = new VueUsersFonctionnalite("EXD5", "", "Editions", "", "EXD5", 5, "1000", true);
        listFonctions.add(e5);
        VueUsersFonctionnalite e50 = new VueUsersFonctionnalite("EXD50", "EXD5", "Plan de Travail", "", "EXD50", 5, "1000", true);
        listFonctions.add(e50);
        VueUsersFonctionnalite e52 = new VueUsersFonctionnalite("EXD52", "EXD5", "Livre-journal des engagements", "", "EXD52", 5, "1000", true);
        listFonctions.add(e52);
        VueUsersFonctionnalite e53 = new VueUsersFonctionnalite("EXD53", "EXD5", "Edition des documents associés à la dépense", "", "EXD53", 5, "1000", true);
        listFonctions.add(e53);
        VueUsersFonctionnalite e54 = new VueUsersFonctionnalite("EXD54", "EXD5", "Réedition des bordereaux de transmission", "", "EXD54", 5, "1000", true);
        listFonctions.add(e54);

        return listFonctions;
    }

    public static List<VueUsersFonctionnalite> getListMenusRoot() {
        List<VueUsersFonctionnalite> list = new ArrayList<>();
        for (VueUsersFonctionnalite v : listFonctions) {
            if (v.getIdParent().isEmpty()) {
                list.add(v);
            }
        }
        return list;
    }

    public static List<VueUsersFonctionnalite> getListMenusChilds(String idParent) {
        List<VueUsersFonctionnalite> list = new ArrayList<>();
        for (VueUsersFonctionnalite v : listFonctions) {
            if (v.getIdParent().equalsIgnoreCase(idParent)) {
                list.add(v);
            }
        }
        return list;
    }

    public static List<VueUsersFonctionnalite> getListMenusRootByProfil(List<String> profils) {
        List<VueUsersFonctionnalite> list = new ArrayList<>();
        for (VueUsersFonctionnalite v : listFonctions) {
            if (v.getIdParent().isEmpty()) {
                if (profils.contains(v.getCode())) {
                    list.add(v);
                }
            }
        }
        return list;
    }

    public static List<VueUsersFonctionnalite> getListMenusChildsByProfil(String idParent, List<String> profils) {
        List<VueUsersFonctionnalite> list = new ArrayList<>();
        for (VueUsersFonctionnalite v : listFonctions) {
            if (v.getIdParent().equalsIgnoreCase(idParent)) {
                if (profils.contains(v.getCode())) {
                    list.add(v);
                }
            }
        }
        return list;
    }
}
