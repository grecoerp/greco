/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.renderer;


import cm.eusoworks.resources.images.GrecoImages;
import java.awt.Component;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.TableCellRenderer;
import org.jdesktop.swingx.renderer.AbstractRenderer;
import org.jdesktop.swingx.renderer.CellContext;
import org.jdesktop.swingx.renderer.ComponentProvider;
import org.jdesktop.swingx.renderer.JRendererLabel;
import org.jdesktop.swingx.renderer.TableCellContext;

/**
 *
 * @author akodjou
 */
public class BonRechercheTableRenderer extends AbstractRenderer implements TableCellRenderer {

    private TableCellContext cellContext;
    public static final int COL_BENEFICIAIRE = 1;
    public static final int COL_ETAT = 4;
    public static final int COL_CERTIFICAT_ETAT = 3;
    GrecoImages mesImages = new GrecoImages();

    public BonRechercheTableRenderer() {
        this(null);
    }

    public BonRechercheTableRenderer(ComponentProvider<?> provider) {
        super(provider);
        this.cellContext = new TableCellContext();
    }

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        if (value instanceof String) {
            String txt = (value == null ? "" : value.toString());
            if (column == COL_BENEFICIAIRE) {
//                Contribuable c = ExecutionServiceFactory.getContribuableService().getContribuableById(value.toString());
                txt = value.toString(); //c.getRaisonSociale();
            }
            cellContext.installContext(table, txt, row, column, isSelected, hasFocus,
                    true, true);
        } else if (value instanceof Integer) {
//            if (column == COL_ETAT) {
//                cellContext.installContext(table, Etat.getMode(((Integer)value).shortValue()), row, column, isSelected, hasFocus,
//                        true, true);
//            }

        } else if (value instanceof Short) {
//                cellContext.installContext(table, Etat.getMode((Short) value), row, column, isSelected, hasFocus,
//                        true, true);

        } else if (value instanceof BigDecimal) {
            try {
                javax.swing.text.NumberFormatter formatter = new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"));
                cellContext.installContext(table, formatter.valueToString(value), row, column, isSelected, hasFocus,
                        true, true);
            } catch (Exception ex) {
                cellContext.installContext(table, (value == null ? "" : value.toString()), row, column, isSelected, hasFocus,
                        true, true);
//                Logger.getLogger(EtatAccreditationCellRenderer.class.getName()).log(Level.SEVERE, null, ex);
            }

        } else if (value instanceof Date) {
            SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
            Date val = (Date) value;
            cellContext.installContext(table, format.format(val), row, column, isSelected, hasFocus,
                    true, true);

        } else if (value instanceof Boolean) {
            javax.swing.ImageIcon icon = null;
            if (Boolean.TRUE.equals(value)) {
                icon = new javax.swing.ImageIcon(mesImages.pouceON());
                ((JLabel) getComponentProvider().getRendererComponent(cellContext)).setIcon(icon);
            } else {
                icon = new javax.swing.ImageIcon(mesImages.pouceOFF());
                ((JLabel) getComponentProvider().getRendererComponent(cellContext)).setIcon(icon);
            }
            cellContext.installContext(table, value, row, column, isSelected, hasFocus,
                    true, true);
        } else {
            cellContext.installContext(table, (value == null ? "" : value.toString()), row, column, isSelected, hasFocus,
                    true, true);
        }
        Component comp = componentController.getRendererComponent(cellContext);
        cellContext.replaceValue(null);

        return comp;
    }

    protected ComponentProvider<?> createDefaultComponentProvider() {
        return new MyLabelProvider();
    }

    class MyLabelProvider extends ComponentProvider<JLabel> {

        @Override
        protected void format(CellContext context) {
            rendererComponent.setIcon(getValueAsIcon(context));
            rendererComponent.setText(getValueAsString(context));
        }

        @Override
        protected void configureState(CellContext context) {
            rendererComponent.setHorizontalAlignment(getHorizontalAlignment());
        }

        @Override
        protected JLabel createRendererComponent() {
//          JRendererLabel label=new JRendererLabel();
//          label.setOpaque(false);
//          label.setHorizontalAlignment(JRendererLabel.LEFT);
//           label.setFont(new java.awt.Font("Tahoma", 0, 14));
            return new JRendererLabel();
        }
    }
}

