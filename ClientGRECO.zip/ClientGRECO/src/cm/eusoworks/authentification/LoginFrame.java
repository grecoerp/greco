/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.authentification;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.OrgOptions;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Users;
import cm.eusoworks.modules.ModulePaneFrame;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tools.ui.ProgressPane;
import java.awt.HeadlessException;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.UIManager;
import javax.swing.UIManager.LookAndFeelInfo;

/**
 *
 * @author macbookair
 */
public class LoginFrame extends javax.swing.JFrame implements ActionListener {

    private Point offset;
    private final Object[] selectionValues = {java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("localIP"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("ip1"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("ip2"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("ip3"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("ip4"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("ip5")};
    private final ProgressPane glasspane;
    private JFrame me;
    int widthFrame = 514, heightFrame = 340;
    int corner = 45;

    /**
     * Creates new form LoginFrame
     */
    public LoginFrame(String defaultLoginName) {
        //        system look and feel
        try {
            for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            // If Nimbus is not available, you can set the GUI to another look and feel.
        }

        initComponents();

        GrecoAppConfig.initOrganisation(GrecoAppConfig.CCAA);
        initLogo(GrecoAppConfig.CCAA);
        lblOrganisation.setText(GrecoAppConfig.getOrgSigleFr());

        setSize(widthFrame, heightFrame);
        glasspane = new ProgressPane(java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("SIGNING"), 25, GrecoSession.USER_SOUND_ON, true);
        this.setGlassPane(glasspane);
        // setShape(new RoundRectangle2D.Float(0, 0, widthFrame, heightFrame, corner, corner));
        setLocationRelativeTo(null);
        me = this;
        
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Ouverture de session ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        txtUserName.setText(defaultLoginName == null ? "" : defaultLoginName);
        btnConnexion.setVisible(false);
        txtUserName.setEnabled(false);
        txtPassword.setEnabled(false);
        
        Timer animation = new Timer(50, this);
        animation.start();

    }

    public LoginFrame() {
        this("");
    }

    private void initLogo(int i) {
        switch (i) {
            case GrecoAppConfig.FSPF_MINFOF:
                lblOrganisation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/fspf.png")));
                break;
            case GrecoAppConfig.CNRPH:
                lblOrganisation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/cnrph.png")));
                break;
            case GrecoAppConfig.ENAM:
                lblOrganisation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/enam.png")));
                break;
            case GrecoAppConfig.CSPH:
                lblOrganisation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/csph.png")));
                break;
            case GrecoAppConfig.CCAA:
                lblOrganisation.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/logoCCA.png")));
                break;
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        contentPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        txtUserName = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        linkServeur = new org.jdesktop.swingx.JXHyperlink();
        curvesPanel1 = new cm.eusoworks.tools.ui.CurvesPanel();
        lblOrganisation = new javax.swing.JLabel();
        btnLangue = new cm.eusoworks.tools.ui.GToogleButton();
        btnQuitter = new cm.eusoworks.tools.ui.GButton();
        btnConnexion = new cm.eusoworks.tools.ui.GButton();
        jLabel5 = new javax.swing.JLabel();

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/login - Copie.png"))); // NOI18N
        jLabel3.setNextFocusableComponent(txtUserName);
        jLabel3.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel3MouseDragged(evt);
            }
        });
        jLabel3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel3MousePressed(evt);
            }
        });

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        contentPanel.setBackground(new java.awt.Color(255, 255, 255));
        contentPanel.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        contentPanel.setLayout(null);

        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame"); // NOI18N
        jLabel1.setText(bundle.getString("USERNAME : ")); // NOI18N
        contentPanel.add(jLabel1);
        jLabel1.setBounds(220, 80, 110, 30);

        jLabel2.setForeground(new java.awt.Color(153, 153, 153));
        jLabel2.setText(bundle.getString("PASSWORD :")); // NOI18N
        contentPanel.add(jLabel2);
        jLabel2.setBounds(220, 120, 110, 30);

        txtUserName.setFont(new java.awt.Font("Lucida Grande", 0, 16)); // NOI18N
        txtUserName.setNextFocusableComponent(txtPassword);
        txtUserName.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                txtUserNameMouseClicked(evt);
            }
        });
        contentPanel.add(txtUserName);
        txtUserName.setBounds(305, 80, 180, 40);

        txtPassword.setFont(new java.awt.Font("Lucida Grande", 0, 16)); // NOI18N
        txtPassword.setNextFocusableComponent(btnConnexion);
        txtPassword.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtPasswordKeyReleased(evt);
            }
        });
        contentPanel.add(txtPassword);
        txtPassword.setBounds(305, 114, 180, 40);

        linkServeur.setForeground(new java.awt.Color(255, 255, 255));
        linkServeur.setText(bundle.getString("SERVEUR ...")); // NOI18N
        linkServeur.setClickedColor(new java.awt.Color(204, 204, 204));
        linkServeur.setUnclickedColor(new java.awt.Color(255, 255, 255));
        linkServeur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                linkServeurActionPerformed(evt);
            }
        });
        contentPanel.add(linkServeur);
        linkServeur.setBounds(170, 266, 80, 30);

        curvesPanel1.setLayout(null);

        lblOrganisation.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        lblOrganisation.setForeground(new java.awt.Color(51, 51, 51));
        lblOrganisation.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblOrganisation.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        lblOrganisation.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        curvesPanel1.add(lblOrganisation);
        lblOrganisation.setBounds(30, 40, 100, 100);

        btnLangue.setFalseText("EN");
        btnLangue.setTrueText("FR");
        curvesPanel1.add(btnLangue);
        btnLangue.setBounds(315, 110, 160, 29);

        contentPanel.add(curvesPanel1);
        curvesPanel1.setBounds(0, 50, 510, 210);

        btnQuitter.setText("Quitter");
        btnQuitter.setCouleur(3);
        btnQuitter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnQuitterActionPerformed(evt);
            }
        });
        contentPanel.add(btnQuitter);
        btnQuitter.setBounds(30, 270, 90, 29);

        btnConnexion.setText("Ouvrir la session");
        btnConnexion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnConnexionActionPerformed(evt);
            }
        });
        contentPanel.add(btnConnexion);
        btnConnexion.setBounds(310, 270, 170, 30);

        jLabel5.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(51, 51, 51));
        jLabel5.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        jLabel5.setText(bundle.getString("COPYRIGHT")); // NOI18N
        jLabel5.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                jLabel5MouseDragged(evt);
            }
        });
        jLabel5.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                jLabel5MousePressed(evt);
            }
        });
        contentPanel.add(jLabel5);
        jLabel5.setBounds(0, 0, 510, 40);

        getContentPane().add(contentPanel, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jLabel3MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MouseDragged
        // TODO add your handling code here:
        Point where = evt.getPoint();
        where.translate(-offset.x, -offset.y);
        Point loc = this.getLocationOnScreen();
        loc.translate(where.x, where.y);
        this.setLocation(loc.x, loc.y);
    }//GEN-LAST:event_jLabel3MouseDragged

    private void jLabel3MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel3MousePressed
        // TODO add your handling code here:
        offset = evt.getPoint();
    }//GEN-LAST:event_jLabel3MousePressed

    private void linkServeurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_linkServeurActionPerformed
        // TODO add your handling code here:
        String adresseIP = "";
        adresseIP = (String) JOptionPane.showInternalInputDialog(this.getContentPane(), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("serverIPAdress"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("SERVER'S LINK"), JOptionPane.PLAIN_MESSAGE, null, selectionValues, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("localIP"));
        if (adresseIP != null && !adresseIP.isEmpty()) {
            GrecoAppConfig.setHOSTNAME(adresseIP);
            GrecoAppConfig.setCtx(null);
            GrecoServiceFactory.closeService();
        }
    }//GEN-LAST:event_linkServeurActionPerformed

    private void txtPasswordKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtPasswordKeyReleased
        // TODO add your handling code here:
        if (evt.getKeyCode() == KeyEvent.VK_ENTER) {
            login();
        }
    }//GEN-LAST:event_txtPasswordKeyReleased

    private void btnQuitterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnQuitterActionPerformed
        // TODO add your handling code here:
        quitter();
    }//GEN-LAST:event_btnQuitterActionPerformed

    private void btnConnexionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnConnexionActionPerformed
        // TODO add your handling code here:
        login();
    }//GEN-LAST:event_btnConnexionActionPerformed

    private void txtUserNameMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_txtUserNameMouseClicked
        // TODO add your handling code here:
        if (txtUserName.getText().length() > 0) {
            txtUserName.setSelectionStart(0);
            txtUserName.setSelectionEnd(txtUserName.getText().length());
            txtUserName.setCaretPosition(txtUserName.getText().length());
        }
    }//GEN-LAST:event_txtUserNameMouseClicked

    private void jLabel5MousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MousePressed
        // TODO add your handling code here:
        offset = evt.getPoint();
    }//GEN-LAST:event_jLabel5MousePressed

    private void jLabel5MouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jLabel5MouseDragged
        // TODO add your handling code here:
        Point where = evt.getPoint();
        where.translate(-offset.x, -offset.y);
        Point loc = this.getLocationOnScreen();
        loc.translate(where.x, where.y);
        this.setLocation(loc.x, loc.y);
    }//GEN-LAST:event_jLabel5MouseDragged

    public void connected() {
        txtUserName.setEnabled(true);
        txtPassword.setEnabled(true);
        btnConnexion.setVisible(true);
        curvesPanel1.setVertRougeJaune();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
//        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
//        } catch (ClassNotFoundException ex) {
//            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (InstantiationException ex) {
//            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (IllegalAccessException ex) {
//            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
//            java.util.logging.Logger.getLogger(LoginFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
//        }
        //</editor-fold>

        /* Create and display the form */
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                LoginFrame f = new LoginFrame();
                f.setVisible(true);
//f.connected();
                new Thread(new Runnable() {
                    public void run() {
                        GrecoServiceFactory.getUserService().rechercher("KINGKONG");
                        SwingUtilities.invokeLater(new Runnable() {
                            public void run() {
                                f.connected();
                            }
                        });
                    }
                }).start();

            }
        });
    }

    private void quitter() {
        Toolkit.getDefaultToolkit().beep();
        int res = GrecoOptionPane.showConfirmDialog(java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("exitSystem"));
        if (res == JOptionPane.YES_OPTION) {
            GrecoSession.notifications.exit();
            System.exit(0);
        }
    }

    private void login() {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Thread con;
                con = new Thread(new Runnable() {
                    @Override
                    public void run() {
                        glasspane.start();
                        try {
                            
                            
                            String login = txtUserName.getText().trim();
                            if (login == null || login.isEmpty()) {
                                glasspane.stop();
                                Toolkit.getDefaultToolkit().beep();
                                JOptionPane.showMessageDialog(null, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("validUserName"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("signInTitle"), JOptionPane.INFORMATION_MESSAGE);
                                return;
                            }
                            String password = String.valueOf(txtPassword.getPassword());
                            if (password == null || password.isEmpty()) {
                                glasspane.stop();
                                Toolkit.getDefaultToolkit().beep();
                                JOptionPane.showMessageDialog(null, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("validPassword"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("signInTitle"), JOptionPane.INFORMATION_MESSAGE);
                                return;
                            }
                            Users userCon = GrecoServiceFactory.getUserService().rechercher(Crypto.encrypt(login));
                            if (userCon == null) {
                                glasspane.stop();
                                SwingUtilities.invokeLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        GrecoSession.notifications.echec();
                                    }
                                });
                                JOptionPane.showMessageDialog(null, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("userSeemWrong"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("signInTitle"), JOptionPane.ERROR_MESSAGE);
                                return;
                            }
                            if (!userCon.getLogin().isEmpty() && userCon.getActif() == false) {
                                glasspane.stop();
                                Toolkit.getDefaultToolkit().beep();
                                JOptionPane.showMessageDialog(null, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("userDisabled"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("signInTitle"), JOptionPane.WARNING_MESSAGE);
                                return;
                            }
                            boolean auth = GrecoServiceFactory.getUserService().authentifier(userCon.getLogin(), Crypto.crypterPassword(Crypto.decrypt(userCon.getLogin()), password));
                            if (!auth) {
                                glasspane.stop();
                                SwingUtilities.invokeLater(new Runnable() {
                                    @Override
                                    public void run() {
                                        GrecoSession.notifications.echec();
                                    }
                                });
                                JOptionPane.showMessageDialog(null, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("UserPasswordNoMatch"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/LoginFrame").getString("signInTitle"), JOptionPane.ERROR_MESSAGE);
                                return;
                            }

                            SimpleDateFormat s = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss");
                            GrecoSession.connectionTime = s.format(new Date());
                            // sauvegarde de l'utilisateur connecte
                            GrecoSession.USER_CONNECTED = userCon;
                            //recuperation de l'adresse IP de la machine hote 
                            java.net.InetAddress net;
                            try {
                                net = java.net.Inet4Address.getLocalHost();
                                GrecoSession.USER_ADRESSE_IP = Crypto.encrypt(net.getHostAddress());
                                GrecoSession.USER_HOST_NAME = Crypto.encrypt(net.getHostName());
                                //recuperation de l'adresse MAC
                                NetworkInterface ni;
                                try {
                                    ni = NetworkInterface.getByInetAddress(net);
                                    byte[] mac = ni.getHardwareAddress();
                                    StringBuilder sb = new StringBuilder();
                                    try {
                                        for (int i = 0; i < mac.length; i++) {
                                            sb.append(String.format("%02X%s", mac[i], (i < mac.length - 1) ? "-" : ""));
                                        }
                                    } catch (Exception e) {
                                    }

                                    GrecoSession.USER_ADRESSE_MAC = Crypto.encrypt(sb.toString());
                                } catch (SocketException ex) {
                                    Logger.getLogger(LoginFrame.class.getName()).log(Level.SEVERE, null, ex);
                                }

                            } catch (UnknownHostException exception) {
                                System.out.println("Impossible de recuperer l'adresse IP de la machine hote");
                            }
                            // sauvegarde de la connexion
                            try {
                                GrecoServiceFactory.getUserService().saveConnection(userCon.getLogin(), GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                                        Crypto.encrypt("Connexion au systeme"), userCon.getLogin(), Crypto.getMD5(GrecoSession.USER_HOST_NAME));
                            } catch (Exception e) {
                            }

                            //chargement des parametres utilisateurs son, langue, skin, ...
                            GrecoSession.initUserPreferences();
                            //chargement des modules 
                            GrecoSession.notifications.connect();

                            //langue de travail
                            Locale.setDefault(btnLangue.isChecked()?Locale.FRENCH:Locale.ENGLISH);
                            GrecoSession.USER_LANGUAGE = btnLangue.isChecked()?Locale.FRENCH:Locale.ENGLISH;
                            
                            //chargement des options
                            List<Organisation> list = new ArrayList();
                            try {
                                list = GrecoServiceFactory.getOrganisationService().listeOrganisationActives();
                                if (list != null && list.size() == 1) {
                                    OrgOptions op = GrecoServiceFactory.getOrganisationService().getOptionOrganisation((list.get(0)).getOrganisationID());
                                    if (op != null) {
                                        GrecoAppConfig.setAppAbbreviation(op.getAppAbreviationFr());
                                        GrecoAppConfig.setAppAbbreviationFr(op.getAppAbreviationFr());
                                        GrecoAppConfig.setAppAbbreviationUs(op.getAppAbreviationUs());
                                        GrecoAppConfig.setAppTitleFr(op.getAppTitleFr());
                                        GrecoAppConfig.setAppTitleUs(op.getAppTitleUs());
                                        GrecoAppConfig.setPaysFr(op.getPaysFr());
                                        GrecoAppConfig.setPaysUS(op.getPaysUs());
                                        GrecoAppConfig.setDeviseFr(op.getDeviseFr());
                                        GrecoAppConfig.setDeviseUS(op.getDeviseUs());
                                        GrecoAppConfig.setOrgSigleFr(op.getOrgSigleFr());
                                        GrecoAppConfig.setOrgSigleUs(op.getOrgSigleUs());
                                        GrecoAppConfig.setOrgLibelleFr(op.getOrgLibelleFr());
                                        GrecoAppConfig.setOrgLibelleUS(op.getOrgLibelleUs());
                                        GrecoAppConfig.setOrgContact(op.getOrgContact());
                                    }
                                }
                            } catch (Exception e) {
                            }

                            //arret du glasspane 
                            glasspane.stop();
                            //lancement de la fenetre des modules au choix 
                            me.dispose();
                            ModulePaneFrame modulePaneFrame = new ModulePaneFrame();
                        } catch (HeadlessException e) {
                            glasspane.stop();
                        }
                    }
                }, "Performer");
                con.start();
            }
        });

    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnConnexion;
    private cm.eusoworks.tools.ui.GToogleButton btnLangue;
    private cm.eusoworks.tools.ui.GButton btnQuitter;
    private javax.swing.JPanel contentPanel;
    private cm.eusoworks.tools.ui.CurvesPanel curvesPanel1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel lblOrganisation;
    private org.jdesktop.swingx.JXHyperlink linkServeur;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtUserName;
    // End of variables declaration//GEN-END:variables

    @Override
    public void actionPerformed(ActionEvent e) {
        curvesPanel1.repaint();
    }
}
