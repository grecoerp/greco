/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.component;

import cm.eusoworks.entities.enumeration.MercurialeMode;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.budgeting.MercurialeNewDialog;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.JOptionPane;
import org.jdesktop.swingx.JXDatePicker;

/**
 *
 * @author jeanemmanuel
 */
public class MercurialeComponent extends javax.swing.JPanel {

    private MercurialeTableModel modeleTable = null;
    BigDecimal sommeHT;
    BigDecimal sommeTVA;
    BigDecimal sommeIR;
    BigDecimal sommeTTC;
    BigDecimal sommeNAP;
    double tauxTVA;
    double tauxIR;
    boolean factureValid = false;
    
    int modePresentation;
    String millesime;
    /**
     * Creates new form MercurialeComponent
     */
    public MercurialeComponent() {
        initComponents();
        millesime = "50";
        dtpDateEmission.setDate(new Date());
        modeleTable = new MercurialeTableModel(this, millesime);
        tableLigne.setModel(modeleTable);
        tableLigne.setRowHeight(25);
        tableLigne.setShowGrid(true);
        scrollTable.setViewportView(tableLigne);
        if (tableLigne.getColumnModel().getColumnCount() > 0) {
            tableLigne.getColumnModel().getColumn(0).setResizable(false);
            tableLigne.getColumnModel().getColumn(0).setPreferredWidth(130);
            tableLigne.getColumnModel().getColumn(1).setPreferredWidth(400);
            tableLigne.getColumnModel().getColumn(2).setPreferredWidth(120);
            tableLigne.getColumnModel().getColumn(3).setResizable(false);
            tableLigne.getColumnModel().getColumn(3).setPreferredWidth(60);
            tableLigne.getColumnModel().getColumn(4).setPreferredWidth(130);
            tableLigne.getColumnModel().getColumn(5).setResizable(false);
            tableLigne.getColumnModel().getColumn(5).setPreferredWidth(150);
        }
        tableLigne.getColumnModel().getColumn(0).setCellEditor(new MercurialeArticleEditor());
        tableLigne.getColumnModel().getColumn(4).setCellRenderer(new MercurialeArticleRenderer());
    }

    public int getModePresentation() {
        return modePresentation;
    }

    public void setModePresentation(int modePresentation) {
        this.modePresentation = modePresentation;
        modeleTable.setMode(modePresentation);
        if(modePresentation == MercurialeMode.MODE_FACTURE){
            pEntete.setVisible(true);
            pTotaux.setVisible(true);
        }else {
            pEntete.setVisible(false);
            pTotaux.setVisible(false);
        }
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
        modeleTable.setMillesime(millesime);
    }
    
    public String getObjet(){
        return txtObjet.getText().trim();
    }
    
    public void setObjet(String objet){
        this.txtObjet.setText(objet);
    }

    public String getReference(){
        return txtReference.getText().trim();
    }
    
    public void setReference(String ref){
        this.txtReference.setText(ref);
    }

    
    public void calculTotaux(BigDecimal sommeHT, boolean valid){
        this.sommeHT = sommeHT;
        Number tva = (Number) (txtTVA.getValue() == null ? 0: txtTVA.getValue());
        Number ir = (Number) (txtIR.getValue() == null ? 0: txtIR.getValue());
        this.tauxTVA = tva.doubleValue()/100;
        this.tauxIR = ir.doubleValue()/100;
        Number ht = sommeHT;
        sommeTVA = BigDecimal.valueOf( ht.doubleValue()*this.tauxTVA);
        sommeIR = BigDecimal.valueOf(ht.doubleValue()*this.tauxIR);
        sommeTTC = BigDecimal.valueOf(ht.doubleValue()*(1+this.tauxTVA));
        sommeNAP = BigDecimal.valueOf(ht.doubleValue()*(1-this.tauxIR));
        
        txTotalHT.setValue(this.sommeHT);
        txtTotalTVA.setValue(sommeTVA);
        txtTotalIR.setValue(sommeIR);
        txtTotalNAP.setValue(sommeNAP);
        txtTotalTTC.setValue(sommeTTC);
        
        this.factureValid = valid;
        
        if(factureValid){
            lblVisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/visaapprouved.png"))); 
            Color color = new Color(0,128,0);
            lblNAP.setForeground(color);
            lblTTC.setForeground(color);
            txtTotalTTC.setForeground(color);
            txtTotalNAP.setForeground(color);
        }else {
            lblVisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/visadenied.png"))); 
            Color color = Color.red;
            lblNAP.setForeground(color);
            lblTTC.setForeground(color);
            txtTotalTTC.setForeground(color);
            txtTotalNAP.setForeground(color);
        }
    }
    
    public Date getDateEmission(){
        return dtpDateEmission.getDate();
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pArticleMercuriale = new javax.swing.JPanel();
        pEntete = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        dtpDateEmission = new org.jdesktop.swingx.JXDatePicker();
        txtReference = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        txtObjet = new javax.swing.JTextArea();
        pTableContents = new javax.swing.JPanel();
        scrollTable = new javax.swing.JScrollPane();
        tableLigne = new org.jdesktop.swingx.JXTable();
        jPanel1 = new javax.swing.JPanel();
        btnAddLigne = new cm.eusoworks.tools.ui.GButton();
        btnDeleteLigne = new cm.eusoworks.tools.ui.GButton();
        btnNewArticle = new cm.eusoworks.tools.ui.GButton();
        pTotaux = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txTotalHT = new javax.swing.JFormattedTextField();
        jLabel8 = new javax.swing.JLabel();
        txtTotalTVA = new javax.swing.JFormattedTextField();
        jLabel9 = new javax.swing.JLabel();
        txtTotalIR = new javax.swing.JFormattedTextField();
        lblNAP = new javax.swing.JLabel();
        txtTotalNAP = new javax.swing.JFormattedTextField();
        lblTTC = new javax.swing.JLabel();
        txtTotalTTC = new javax.swing.JFormattedTextField();
        jLabel4 = new javax.swing.JLabel();
        txtTVA = new javax.swing.JFormattedTextField();
        txtIR = new javax.swing.JFormattedTextField();
        jLabel5 = new javax.swing.JLabel();
        lblVisa = new javax.swing.JLabel();

        setLayout(new java.awt.BorderLayout());

        pArticleMercuriale.setSize(new java.awt.Dimension(800, 400));
        pArticleMercuriale.setLayout(new java.awt.BorderLayout(0, 3));

        pEntete.setBackground(new java.awt.Color(255, 255, 255));

        jLabel1.setText("Date : ");

        jLabel2.setText("Reference : ");

        jLabel3.setText("Objet : ");

        txtObjet.setColumns(20);
        txtObjet.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        txtObjet.setRows(2);
        jScrollPane1.setViewportView(txtObjet);

        javax.swing.GroupLayout pEnteteLayout = new javax.swing.GroupLayout(pEntete);
        pEntete.setLayout(pEnteteLayout);
        pEnteteLayout.setHorizontalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10))
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 82, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)))
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addComponent(dtpDateEmission, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(141, 141, 141)
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jScrollPane1))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pEnteteLayout.setVerticalGroup(
            pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pEnteteLayout.createSequentialGroup()
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pEnteteLayout.createSequentialGroup()
                        .addGap(1, 1, 1)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(dtpDateEmission, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pEnteteLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        pArticleMercuriale.add(pEntete, java.awt.BorderLayout.NORTH);

        pTableContents.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pTableContents.setLayout(new java.awt.BorderLayout());

        tableLigne.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "REFERENCE", "DESIGNATION", "UNITE", "QTE", "PRIX UNIT.", "PRIX TOTAL"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                true, false, false, true, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tableLigne.setRowHeight(25);
        tableLigne.setShowGrid(true);
        scrollTable.setViewportView(tableLigne);

        pTableContents.add(scrollTable, java.awt.BorderLayout.CENTER);

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 4, 2));

        btnAddLigne.setText("+");
        btnAddLigne.setStyle(1);
        btnAddLigne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddLigneActionPerformed(evt);
            }
        });
        jPanel1.add(btnAddLigne);

        btnDeleteLigne.setText("-");
        btnDeleteLigne.setCouleur(3);
        btnDeleteLigne.setStyle(2);
        btnDeleteLigne.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnDeleteLigneActionPerformed(evt);
            }
        });
        jPanel1.add(btnDeleteLigne);

        btnNewArticle.setText("...");
        btnNewArticle.setStyle(3);
        btnNewArticle.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewArticleActionPerformed(evt);
            }
        });
        jPanel1.add(btnNewArticle);

        pTableContents.add(jPanel1, java.awt.BorderLayout.NORTH);

        pArticleMercuriale.add(pTableContents, java.awt.BorderLayout.CENTER);

        pTotaux.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(0, 153, 255));
        jLabel7.setText("TOTAL HT");

        txTotalHT.setEditable(false);
        txTotalHT.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(51, 153, 255), null));
        txTotalHT.setForeground(new java.awt.Color(0, 153, 255));
        txTotalHT.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txTotalHT.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txTotalHT.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N

        jLabel8.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 102, 0));
        jLabel8.setText("TVA");

        txtTotalTVA.setEditable(false);
        txtTotalTVA.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(51, 153, 255), null));
        txtTotalTVA.setForeground(new java.awt.Color(255, 102, 0));
        txtTotalTVA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtTotalTVA.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalTVA.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N

        jLabel9.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 102, 0));
        jLabel9.setText("IR");

        txtTotalIR.setEditable(false);
        txtTotalIR.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(51, 153, 255), null));
        txtTotalIR.setForeground(new java.awt.Color(255, 102, 0));
        txtTotalIR.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtTotalIR.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalIR.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N

        lblNAP.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        lblNAP.setText("NET A PAYER");

        txtTotalNAP.setEditable(false);
        txtTotalNAP.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(51, 153, 255), null));
        txtTotalNAP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtTotalNAP.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalNAP.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N

        lblTTC.setFont(new java.awt.Font("Arial", 1, 13)); // NOI18N
        lblTTC.setText("TOTAL TTC");

        txtTotalTTC.setEditable(false);
        txtTotalTTC.setBorder(javax.swing.BorderFactory.createEtchedBorder(new java.awt.Color(51, 153, 255), null));
        txtTotalTTC.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtTotalTTC.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtTotalTTC.setFont(new java.awt.Font("Arial", 1, 15)); // NOI18N

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 102, 0));
        jLabel4.setText("TVA (%)");

        txtTVA.setForeground(new java.awt.Color(255, 102, 0));
        txtTVA.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.000"))));
        txtTVA.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtTVA.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtTVAFocusLost(evt);
            }
        });
        txtTVA.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtTVAKeyReleased(evt);
            }
        });

        txtIR.setForeground(new java.awt.Color(255, 102, 0));
        txtIR.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#0.000"))));
        txtIR.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        txtIR.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtIRFocusLost(evt);
            }
        });
        txtIR.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtIRKeyReleased(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 102, 0));
        jLabel5.setText("IR (%)");

        lblVisa.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/visadenied.png"))); // NOI18N

        javax.swing.GroupLayout pTotauxLayout = new javax.swing.GroupLayout(pTotaux);
        pTotaux.setLayout(pTotauxLayout);
        pTotauxLayout.setHorizontalGroup(
            pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pTotauxLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel4, javax.swing.GroupLayout.DEFAULT_SIZE, 60, Short.MAX_VALUE)
                    .addComponent(jLabel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtIR, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(119, 119, 119)
                .addComponent(lblVisa, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 117, Short.MAX_VALUE)
                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pTotauxLayout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txTotalHT, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pTotauxLayout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txtTotalTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pTotauxLayout.createSequentialGroup()
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txtTotalIR, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pTotauxLayout.createSequentialGroup()
                        .addComponent(lblNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txtTotalNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pTotauxLayout.createSequentialGroup()
                        .addComponent(lblTTC, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(4, 4, 4)
                        .addComponent(txtTotalTTC, javax.swing.GroupLayout.PREFERRED_SIZE, 161, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(20, 20, 20))
        );
        pTotauxLayout.setVerticalGroup(
            pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pTotauxLayout.createSequentialGroup()
                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(pTotauxLayout.createSequentialGroup()
                        .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pTotauxLayout.createSequentialGroup()
                                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel7, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txTotalHT, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTotalTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtTotalIR, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addGroup(pTotauxLayout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, 0)
                                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txtIR, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(txtTVA, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtTotalNAP, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lblVisa, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pTotauxLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblTTC, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtTotalTTC, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(15, Short.MAX_VALUE))
        );

        pArticleMercuriale.add(pTotaux, java.awt.BorderLayout.SOUTH);

        add(pArticleMercuriale, java.awt.BorderLayout.CENTER);
    }// </editor-fold>//GEN-END:initComponents

    private void btnAddLigneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddLigneActionPerformed
        // TODO add your handling code here:
        Article a = new Article();
        modeleTable.addArticle(a);
    }//GEN-LAST:event_btnAddLigneActionPerformed

    private void btnDeleteLigneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnDeleteLigneActionPerformed
        // TODO add your handling code here:
        int[] selection = tableLigne.getSelectedRows();
        if (selection.length > 0) {
            int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir supprimer ces lignes ??");
            if (res == JOptionPane.YES_OPTION) {
                for (int i = selection.length - 1; i >= 0; i--) {
                    modeleTable.removeArticle(selection[i]);
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Aucune ligne a retirer. Veuillez selectionner une ligne SVP");
        }

    }//GEN-LAST:event_btnDeleteLigneActionPerformed

    private void btnNewArticleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewArticleActionPerformed
        // TODO add your handling code here:
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                MercurialeNewDialog m = new MercurialeNewDialog(null, true);
                m.setVisible(false);
            }
        });
    }//GEN-LAST:event_btnNewArticleActionPerformed

    private void txtTVAFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtTVAFocusLost
        // TODO add your handling code here:
        calculTotaux(this.sommeHT, this.factureValid);
    }//GEN-LAST:event_txtTVAFocusLost

    private void txtTVAKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtTVAKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER || evt.getKeyCode() == KeyEvent.VK_TAB){
            calculTotaux(this.sommeHT, this.factureValid);
        }
    }//GEN-LAST:event_txtTVAKeyReleased

    private void txtIRFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtIRFocusLost
        // TODO add your handling code here:
        calculTotaux(this.sommeHT, this.factureValid);
    }//GEN-LAST:event_txtIRFocusLost

    private void txtIRKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtIRKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER || evt.getKeyCode() == KeyEvent.VK_TAB){
            calculTotaux(this.sommeHT, this.factureValid);
        }
    }//GEN-LAST:event_txtIRKeyReleased

    public BigDecimal getSommeHT() {
        return sommeHT;
    }

    public void setSommeHT(BigDecimal sommeHT) {
        this.sommeHT = sommeHT;
    }

    public BigDecimal getSommeTVA() {
        return sommeTVA;
    }

    public void setSommeTVA(BigDecimal sommeTVA) {
        this.sommeTVA = sommeTVA;
    }

    public BigDecimal getSommeIR() {
        return sommeIR;
    }

    public void setSommeIR(BigDecimal sommeIR) {
        this.sommeIR = sommeIR;
    }

    public BigDecimal getSommeTTC() {
        return sommeTTC;
    }

    public void setSommeTTC(BigDecimal sommeTTC) {
        this.sommeTTC = sommeTTC;
    }

    public BigDecimal getSommeNAP() {
        return sommeNAP;
    }

    public void setSommeNAP(BigDecimal sommeNAP) {
        this.sommeNAP = sommeNAP;
    }

    public double getTauxTVA() {
        return tauxTVA;
    }

    public void setTauxTVA(double tauxTVA) {
        this.tauxTVA = tauxTVA;
    }

    public double getTauxIR() {
        return tauxIR;
    }

    public void setTauxIR(double tauxIR) {
        this.tauxIR = tauxIR;
    }

    public boolean isFactureValid() {
        return factureValid;
    }

    public void setFactureValid(boolean factureValid) {
        this.factureValid = factureValid;
    }

    public JXDatePicker getDtpDateEmission() {
        return dtpDateEmission;
    }

    public void setDtpDateEmission(JXDatePicker dtpDateEmission) {
        this.dtpDateEmission = dtpDateEmission;
    }

    public List<Article> getListArticleMercuriale() {
        return modeleTable.getDataList();
    }
    
    public void setListArticleMercuriale(List<Article> arts) {
        if(arts == null) arts = new ArrayList<>();
         modeleTable.setDataList(arts);
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAddLigne;
    private cm.eusoworks.tools.ui.GButton btnDeleteLigne;
    private cm.eusoworks.tools.ui.GButton btnNewArticle;
    private org.jdesktop.swingx.JXDatePicker dtpDateEmission;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblNAP;
    private javax.swing.JLabel lblTTC;
    private javax.swing.JLabel lblVisa;
    private javax.swing.JPanel pArticleMercuriale;
    private javax.swing.JPanel pEntete;
    private javax.swing.JPanel pTableContents;
    private javax.swing.JPanel pTotaux;
    private javax.swing.JScrollPane scrollTable;
    private org.jdesktop.swingx.JXTable tableLigne;
    private javax.swing.JFormattedTextField txTotalHT;
    private javax.swing.JFormattedTextField txtIR;
    private javax.swing.JTextArea txtObjet;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtTVA;
    private javax.swing.JFormattedTextField txtTotalIR;
    private javax.swing.JFormattedTextField txtTotalNAP;
    private javax.swing.JFormattedTextField txtTotalTTC;
    private javax.swing.JFormattedTextField txtTotalTVA;
    // End of variables declaration//GEN-END:variables
}
