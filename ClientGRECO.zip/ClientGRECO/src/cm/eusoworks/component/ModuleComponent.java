/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.component;

import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.modules.ModuleBudgetisationFrame;
import cm.eusoworks.modules.ModuleConfigurationFrame;
import cm.eusoworks.modules.ModuleExecutionDepenseFrame;
import cm.eusoworks.modules.ModuleExecutionRecetteFrame;
import cm.eusoworks.modules.ModulePrefFrame;
import cm.eusoworks.modules.ModuleProfilerFrame;
import cm.eusoworks.context.MySound;
import cm.eusoworks.ui.caisse.forms.CaisseTicketDialog;
import cm.eusoworks.ui.config.ProfilDialog;
import cm.eusoworks.ui.config.UsersListDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import org.jdesktop.swingx.JXHyperlink;

/**
 *
 * @author macbookair
 */
public class ModuleComponent extends JXHyperlink implements ActionListener {

    private Modules mod;

    ModuleConfigurationFrame configrationFrame = null;
    ModulePrefFrame prefFrame = null;
    ModuleBudgetisationFrame budgetisationFrame = null;
    ModuleExecutionDepenseFrame depenseFrame = null;
    ModuleExecutionRecetteFrame recetteFrame = null;
    UsersListDialog userFrame = null;
    ProfilDialog profilFrame = null;
    ModuleProfilerFrame profilerFrame = null;
    CaisseTicketDialog caisse = null;
//    ModuleMarchePPMFrame marchePPMFrame = null;

    MySound beepSound = new MySound();

    public ModuleComponent(Modules mod) {
        this.mod = mod;
        try {
            this.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/" + mod.getIcon()))); // NOI18N
        } catch (Exception e) {
        }
        try {
            this.setRolloverIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/" + mod.getIconRoll()))); // NOI18N
        } catch (Exception e) {
        }
        this.setText(mod.getLibelle(GrecoSession.USER_LANGUAGE));
        this.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        this.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        this.setIconTextGap(2);
        this.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        this.setFocusable(false);
        this.setUnclickedColor(Color.BLACK);
        this.setClickedColor(Color.gray);
        this.addActionListener(this);
        this.setPreferredSize(new Dimension(140, 90));
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        beepSound.doubleBeep();
        if (mod.getSystemeID().equals(Systeme.PREVISION)) {
            if (mod.getModuleID().trim().equalsIgnoreCase(Modules.BUDGETISATION_ANNUELLE)) {
                if(budgetisationFrame == null){
                    budgetisationFrame = new ModuleBudgetisationFrame();      
                }
                budgetisationFrame.setVisible(true);
//                if (caisse == null) {
//                    caisse = new CaisseTicketDialog(null, true);
//                }
//                caisse.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.MARCHE_PLAN_PASSATION)) {
//                if(marchePPMFrame == null){
//                    marchePPMFrame = new ModuleMarchePPMFrame();
//                }
//                marchePPMFrame.setVisible(true);
                return;
            }
        } else if (mod.getSystemeID().equals(Systeme.EXECUTION)) {
            if (mod.getModuleID().trim().equalsIgnoreCase(Modules.DEPENSES)) {
                if (depenseFrame == null) {
                    depenseFrame = new ModuleExecutionDepenseFrame(Modules.DEPENSES);
                }
                depenseFrame.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.RECETTES)) {
                if (recetteFrame == null) {
                    recetteFrame = new ModuleExecutionRecetteFrame();
                }
                recetteFrame.setVisible(true);
                return;
            }
        } else if (mod.getSystemeID().equals(Systeme.ADMINISTRATION)) {
            if (mod.getModuleID().trim().equalsIgnoreCase(Modules.CONFIGURATION)) {
                if (configrationFrame == null) {
                    configrationFrame = new ModuleConfigurationFrame();
                }
                configrationFrame.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.PREFERENCES)) {
                if (prefFrame == null) {
                    prefFrame = new ModulePrefFrame();
                }
                prefFrame.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.UTILISATEURS)) {
                if (userFrame == null) {
                    userFrame = new UsersListDialog(null, true);
                }
                userFrame.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.PROFILS_UTILISATEUR)) {
                if (profilFrame == null) {
                    profilFrame = new ProfilDialog(null, true);
                }
                profilFrame.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.PROFILS_UTILISATEUR)) {
                if (profilFrame == null) {
                    profilFrame = new ProfilDialog(null, true);
                }
                profilFrame.setVisible(true);
                return;
            } else if (mod.getModuleID().trim().equalsIgnoreCase(Modules.PROFILEUR)) {
                if (profilerFrame == null) {
                    profilerFrame = new ModuleProfilerFrame();
                }
                profilerFrame.setVisible(true);
                return;

            }
        }
    }
}
