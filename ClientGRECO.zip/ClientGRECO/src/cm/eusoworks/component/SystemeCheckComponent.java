/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.component;

import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author macbookair
 */
public class SystemeCheckComponent extends JButton implements ActionListener {

    private static final long serialVersionUID = -6290622947931566069L;
    private static boolean REPAINT_SHADOW = true;

    private static Color COLOR1 = new Color(125, 161, 237);
    private static Color COLOR2 = new Color(91, 118, 173);

    private int couleur = 0;
    private int arcW = 15, arcH = 15;

    JPanel panelModules;
    String loginUser;
    Systeme systeme;
    Modules module;
    boolean habilite;
    boolean isModule = false;

    private final MouseAdapter MLISTENER = new MouseAdapter() {
        @Override
        public void mouseEntered(MouseEvent me) {
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        public void mouseExited(MouseEvent me) {
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }
    };

    public SystemeCheckComponent() {
        this(null, 0, null, true);
    }

    public SystemeCheckComponent(Systeme sys, int couleur, JPanel panelModules, boolean habilite) {
        super();
        setCouleur(couleur);
        this.panelModules = panelModules;
        this.systeme = sys;
        this.habilite = habilite;
        isModule = false;
        try {
            setText(sys.getLibelle());
        } catch (Exception e) {
            setText("composant");
        }
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setHabilite(habilite);
        setSize(92, 35);
        addMouseListener(MLISTENER);
        addActionListener(this);
    }

    public SystemeCheckComponent(Modules mod, int couleur, JPanel panelModules, boolean habilite, boolean isModule) {
        super();
        setCouleur(couleur);
        this.panelModules = panelModules;
        this.module = mod;
        this.habilite = habilite;
        isModule = isModule;
        try {
            setText(mod.getLibelle());
        } catch (Exception e) {
            setText("composant");
        }
        setContentAreaFilled(false);
        setBorderPainted(false);
        setFocusPainted(false);
        setHabilite(habilite);
        setSize(92, 35);
        addMouseListener(MLISTENER);
        addActionListener(this);
    }

    public int getCouleur() {
        return couleur;
    }

    public void setCouleur(int couleur) {
        this.couleur = couleur;
        getColor1();
        getColor2();
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g.create();
        setOpaque(false);
        int h = getHeight();
        int w = getWidth();
        float tran = 0.9f;//0.1f + pct * 0.9f;

        COLOR1 = getColor1();
        COLOR2 = getColor2();

        GradientPaint GP = new GradientPaint(0, 0, COLOR1, 0, h, COLOR2, true);
        g2d.setPaint(GP);

        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        GradientPaint p1;
        GradientPaint p2;

        if (habilite) {
            p1 = new GradientPaint(0, 0, COLOR1, 0, h - 1, COLOR2);
        } else {
            p1 = new GradientPaint(0, 0, Color.gray, 0, h - 1, Color.gray);
        }

        g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
        RoundRectangle2D.Float r2d = new RoundRectangle2D.Float(0, 0, w - 1, h - 1, 20, 20);
        Shape clip = g2d.getClip();
        g2d.clip(r2d);
//        g2d.fillRect(0, 0, w, h);
        g2d.setClip(clip);
        g2d.setPaint(p1);
        g2d.drawRoundRect(0, 0, w - 1, h - 1, 20, 20);
        if (habilite) {
            g2d.fillRoundRect(0, 0, w - 1, h - 1, 20, 20);
            g2d.fillRoundRect(5, (h - 10) / 2, 10, 10, 10, 10);
            g2d.setPaint(Color.white);
            g2d.fillRoundRect(5 + 3, ((h - 10) / 2) + 3, 4, 4, 5, 5);
        }

        g2d.dispose();

        super.paintComponent(g);
    }

    public Color getColor1() {
        Color c = new Color(0, 153, 0);
        return c;
    }

    public Color getColor2() {
        Color c = new Color(0, 153, 51);
        return c;
    }

    public boolean isHabilite() {
        return habilite;
    }

    public void setHabilite(boolean habilite) {
        this.habilite = habilite;
        if (habilite) {
            setForeground( Color.white /*getColor1()*/);
        } else {
            setForeground(Color.darkGray);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
////////        if (!isModule) {
////////            List<Modules> myModules = GrecoServiceFactory.getSystemeService().getModuleListWithHabilitation(GrecoSession.USER_CONNECTED.getLogin(), this.systeme.getSystemeID());
////////            ProfilDialog.panelModules.removeAll();
////////            if (myModules != null && !myModules.isEmpty()) {
////////                ProfilDialog.panelModules.setLayout(new GridLayout(myModules.size(), 1, 5, 10));
////////                for (Modules m : myModules) {
////////                    SystemeCheckComponent sc = new SystemeCheckComponent(m, 0, panelModules, false, true);
////////                    ProfilDialog.panelModules.add(sc);
////////                }
////////                ProfilDialog.splitModule.validate();
////////            }
////////        }
////////        activer();
    }

    private void activer() {
////////        if (!isModule) {
////////            Component[] comps = ProfilDialog.panelSysteme.getComponents();
////////            for (int i = 0; i < comps.length; i++) {
////////                Component c = comps[i];
////////                if (c instanceof SystemeCheckComponent) {
////////                    ((SystemeCheckComponent) c).habilite = false;
////////                }
////////            }
////////            this.habilite = true;
////////            ProfilDialog.panelSysteme.repaint();
////////        } else {
////////            Component[] comps = ProfilDialog.panelModules.getComponents();
////////            for (int i = 0; i < comps.length; i++) {
////////                Component c = comps[i];
////////                if (c instanceof SystemeCheckComponent) {
////////                    ((SystemeCheckComponent) c).habilite = false;
////////                }
////////            }
////////            this.habilite = true;
////////            ProfilDialog.splitModule.validate();
////////        }
    }
}
