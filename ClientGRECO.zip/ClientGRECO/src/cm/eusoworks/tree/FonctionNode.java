/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tree;

import cm.eusoworks.entities.model.Fonction;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author macbookair
 */
public class FonctionNode extends DefaultMutableTreeNode{
    private Fonction fonction;

    public FonctionNode() {
        this(null);
    } 
    public FonctionNode(Fonction cat) {
        fonction = cat;
    }

    @Override
    public String toString() {
        return (fonction == null)?"aucune fonction":fonction.toString();
    }

    public Fonction getFonction() {
        return fonction;
    }
  
    public int getNiveauID(){
        return (fonction == null)?-1:fonction.getNiveauID();
    }
    
    public String getParentCode(){
        return (fonction == null)?null:fonction.getParentCode();
    }
    
    public String getCode(){
        return (fonction == null)?"-1":fonction.getCode();
    }
}
