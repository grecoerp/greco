/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tree;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JTree;
import javax.swing.tree.TreeCellRenderer;

/**
 *
 * @author macbookair
 */
public class NomenclatureTreeRenderer implements TreeCellRenderer{

    @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean selected, boolean expanded, boolean leaf, int row, boolean hasFocus) {
        JLabel node = new JLabel();
        if(value instanceof CategorieNode){
            
            CategorieNode o = (CategorieNode) value;
            if(o.getCode() == null){
                node.setFont(new Font("Times", Font.BOLD, 20));
            }else {
                node.setFont(new Font("Times", Font.PLAIN, 18));
            }
            if(o.getChildCount() == 0){
                node.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/leafNomenclature.png")));
                node.setFont(new Font("Arial", Font.ITALIC, 15));
                node.setForeground(new Color(122, 135, 243));
            }
            if(selected ){
                node.setOpaque(true);
                node.setForeground(Color.white);
                node.setBackground(new Color(137, 150, 243));
            }
            node.setText(o.toString()+"     ");
        }
        else if(value instanceof CompteNode){
            
            CompteNode o = (CompteNode) value;
            if(o.getCode() == null){
                node.setFont(new Font("Times", Font.BOLD, 20));
            }else {
                node.setFont(new Font("Times", Font.PLAIN, 18));
            }
            if(o.getChildCount() == 0){
                node.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/leafNomenclature.png")));
                node.setFont(new Font("Arial", Font.ITALIC, 15));
                node.setForeground(new Color(122, 135, 243));
                
            }
            if(selected ){
                node.setOpaque(true);
                node.setForeground(Color.white);
                node.setBackground(new Color(137, 150, 243));
            }
            node.setText(o.toString()+"     ");
        }
        else if(value instanceof FonctionNode){
            
            FonctionNode o = (FonctionNode) value;
            if(o.getCode() == null){
                node.setFont(new Font("Times", Font.BOLD, 20));
            }else {
                node.setFont(new Font("Times", Font.PLAIN, 18));
            }
            if(o.getChildCount() == 0){
                node.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/leafNomenclature.png")));
                node.setFont(new Font("Arial", Font.ITALIC, 15));
                node.setForeground(new Color(122, 135, 243));
            }
            if(selected ){
                node.setOpaque(true);
                node.setForeground(Color.white);
                node.setBackground(new Color(137, 150, 243));
            }
            node.setText(o.toString()+"     ");
        }
        else if(value instanceof LocaliteNode){
            
            LocaliteNode o = (LocaliteNode) value;
            if(o.getCode() == null){
                node.setFont(new Font("Times", Font.BOLD, 20));
            }else {
                node.setFont(new Font("Times", Font.PLAIN, 18));
            }
            if(o.getChildCount() == 0){
                node.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/leafNomenclature.png")));
                node.setFont(new Font("Arial", Font.ITALIC, 15));
                node.setForeground(new Color(122, 135, 243));
            }
            if(selected ){
                node.setOpaque(true);
                node.setForeground(Color.white);
                node.setBackground(new Color(137, 150, 243));
            }
            node.setText(o.toString()+"     ");
        }
        return node;
    }
    
}
