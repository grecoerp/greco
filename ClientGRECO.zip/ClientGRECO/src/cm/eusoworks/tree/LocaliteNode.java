/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tree;

import cm.eusoworks.entities.model.Localite;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author macbookair
 */
public class LocaliteNode extends DefaultMutableTreeNode{
    private Localite localite;

    public LocaliteNode() {
        this(null);
    } 
    public LocaliteNode(Localite cat) {
        localite = cat;
    }

    @Override
    public String toString() {
        return (localite == null)?"aucune localite":localite.toString();
    }

    public Localite getLocalite() {
        return localite;
    }
  
    public int getNiveauID(){
        return (localite == null)?-1:localite.getNiveauID();
    }
    
    public String getParentCode(){
        return (localite == null)?null:localite.getParentCode();
    }
    
    public String getCode(){
        return (localite == null)?"-1":localite.getCode();
    }
}
