/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp.entities.generated;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * //@author cwam
 */
//@Entity
//@Table(name = "PrepaCdmtDocument")
//@NamedQueries({
    //@NamedQuery(name = "GenGrecoDocument.findAll", query = "SELECT g FROM GenGrecoDocument g")})
public class GenGrecoDocument implements Serializable {
    private static final long serialVersionUID = 1L;

    protected String documentId;
    protected String exMillesime;
    protected String chCode;
    protected String introFrancais;
    protected String introAnglais;
    protected String chapitre1Francais;
    protected String chapitre1Anglais;
    protected String section11Francais;
    protected String section11Anglais;
    protected String paragraphe111Francais;
    protected String paragraphe111Anglais;
    protected String paragraphe112Francais;
    protected String paragraphe112Anglais;
    protected String paragraphe113Francais;
    protected String paragraphe113Anglais;
    protected String section12Francais;
    protected String section12Anglais;
    protected String paragraphe121Francais;
    protected String paragraphe121Anglais;
    protected String paragraphe122Francais;
    protected String paragraphe122Anglais;
    protected String chapitre2Francais;
    protected String chapitre2Anglais;
    protected String section21Francais;
    protected String section21Anglais;
    protected String paragraphe211Francais;
    protected String paragraphe211Anglais;
    protected String paragraphe212Francais;
    protected String paragraphe212Anglais;
    protected String paragraphe213Francais;
    protected String paragraphe213Anglais;
    protected String section22Francais;
    protected String section22Anglais;
    protected String paragraphe221Francais;
    protected String paragraphe221Anglais;
    protected String paragraphe222Francais;
    protected String paragraphe222Anglais;
    protected String paragraphe223Francais;
    protected String paragraphe223Anglais;
    protected String section23Francais;
    protected String section23Anglais;
    protected String paragraphe231Francais;
    protected String paragraphe231Anglais;
    protected String paragraphe232Francais;
    protected String paragraphe232Anglais;
    protected String chapitre3Francais;
    protected String chapitre3Anglais;
    protected String section31Francais;
    protected String section31Anglais;
    protected String section32Francais;
    protected String section32Anglais;
    protected String section33Francais;
    protected String section33Anglais;
    protected String section34Francais;
    protected String section34Anglais;
    protected String section35Francais;
    protected String section35Anglais;
    protected String section36Francais;
    protected String section36Anglais;
    protected String section37Francais;
    protected String section37Anglais;
    protected String chapitre4Francais;
    protected String chapitre4Anglais;
    protected String section41Francais;
    protected String section41Anglais;
    protected String section42Francais;
    protected String section42Anglais;
    protected String section43Francais;
    protected String section43Anglais;
    protected String userMaj;
    protected Date dateMaj;
    protected Boolean lockFrancais;
    protected Boolean lockAnglais;

    public GenGrecoDocument() {
    }

    public GenGrecoDocument(String documentId) {
        this.documentId = documentId;
    }

    public String getDocumentId() {
        return documentId;
    }

    public void setDocumentId(String documentId) {
        this.documentId = documentId;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getChCode() {
        return chCode;
    }

    public void setChCode(String chCode) {
        this.chCode = chCode;
    }

    public String getIntroFrancais() {
        return introFrancais;
    }

    public void setIntroFrancais(String introFrancais) {
        this.introFrancais = introFrancais;
    }

    public String getIntroAnglais() {
        return introAnglais;
    }

    public void setIntroAnglais(String introAnglais) {
        this.introAnglais = introAnglais;
    }

    public String getChapitre1Francais() {
        return chapitre1Francais;
    }

    public void setChapitre1Francais(String chapitre1Francais) {
        this.chapitre1Francais = chapitre1Francais;
    }

    public String getChapitre1Anglais() {
        return chapitre1Anglais;
    }

    public void setChapitre1Anglais(String chapitre1Anglais) {
        this.chapitre1Anglais = chapitre1Anglais;
    }

    public String getSection11Francais() {
        return section11Francais;
    }

    public void setSection11Francais(String section11Francais) {
        this.section11Francais = section11Francais;
    }

    public String getSection11Anglais() {
        return section11Anglais;
    }

    public void setSection11Anglais(String section11Anglais) {
        this.section11Anglais = section11Anglais;
    }

    public String getParagraphe111Francais() {
        return paragraphe111Francais;
    }

    public void setParagraphe111Francais(String paragraphe111Francais) {
        this.paragraphe111Francais = paragraphe111Francais;
    }

    public String getParagraphe111Anglais() {
        return paragraphe111Anglais;
    }

    public void setParagraphe111Anglais(String paragraphe111Anglais) {
        this.paragraphe111Anglais = paragraphe111Anglais;
    }

    public String getParagraphe112Francais() {
        return paragraphe112Francais;
    }

    public void setParagraphe112Francais(String paragraphe112Francais) {
        this.paragraphe112Francais = paragraphe112Francais;
    }

    public String getParagraphe112Anglais() {
        return paragraphe112Anglais;
    }

    public void setParagraphe112Anglais(String paragraphe112Anglais) {
        this.paragraphe112Anglais = paragraphe112Anglais;
    }

    public String getParagraphe113Francais() {
        return paragraphe113Francais;
    }

    public void setParagraphe113Francais(String paragraphe113Francais) {
        this.paragraphe113Francais = paragraphe113Francais;
    }

    public String getParagraphe113Anglais() {
        return paragraphe113Anglais;
    }

    public void setParagraphe113Anglais(String paragraphe113Anglais) {
        this.paragraphe113Anglais = paragraphe113Anglais;
    }

    public String getSection12Francais() {
        return section12Francais;
    }

    public void setSection12Francais(String section12Francais) {
        this.section12Francais = section12Francais;
    }

    public String getSection12Anglais() {
        return section12Anglais;
    }

    public void setSection12Anglais(String section12Anglais) {
        this.section12Anglais = section12Anglais;
    }

    public String getParagraphe121Francais() {
        return paragraphe121Francais;
    }

    public void setParagraphe121Francais(String paragraphe121Francais) {
        this.paragraphe121Francais = paragraphe121Francais;
    }

    public String getParagraphe121Anglais() {
        return paragraphe121Anglais;
    }

    public void setParagraphe121Anglais(String paragraphe121Anglais) {
        this.paragraphe121Anglais = paragraphe121Anglais;
    }

    public String getParagraphe122Francais() {
        return paragraphe122Francais;
    }

    public void setParagraphe122Francais(String paragraphe122Francais) {
        this.paragraphe122Francais = paragraphe122Francais;
    }

    public String getParagraphe122Anglais() {
        return paragraphe122Anglais;
    }

    public void setParagraphe122Anglais(String paragraphe122Anglais) {
        this.paragraphe122Anglais = paragraphe122Anglais;
    }

    public String getChapitre2Francais() {
        return chapitre2Francais;
    }

    public void setChapitre2Francais(String chapitre2Francais) {
        this.chapitre2Francais = chapitre2Francais;
    }

    public String getChapitre2Anglais() {
        return chapitre2Anglais;
    }

    public void setChapitre2Anglais(String chapitre2Anglais) {
        this.chapitre2Anglais = chapitre2Anglais;
    }

    public String getSection21Francais() {
        return section21Francais;
    }

    public void setSection21Francais(String section21Francais) {
        this.section21Francais = section21Francais;
    }

    public String getSection21Anglais() {
        return section21Anglais;
    }

    public void setSection21Anglais(String section21Anglais) {
        this.section21Anglais = section21Anglais;
    }

    public String getParagraphe211Francais() {
        return paragraphe211Francais;
    }

    public void setParagraphe211Francais(String paragraphe211Francais) {
        this.paragraphe211Francais = paragraphe211Francais;
    }

    public String getParagraphe211Anglais() {
        return paragraphe211Anglais;
    }

    public void setParagraphe211Anglais(String paragraphe211Anglais) {
        this.paragraphe211Anglais = paragraphe211Anglais;
    }

    public String getParagraphe212Francais() {
        return paragraphe212Francais;
    }

    public void setParagraphe212Francais(String paragraphe212Francais) {
        this.paragraphe212Francais = paragraphe212Francais;
    }

    public String getParagraphe212Anglais() {
        return paragraphe212Anglais;
    }

    public void setParagraphe212Anglais(String paragraphe212Anglais) {
        this.paragraphe212Anglais = paragraphe212Anglais;
    }

    public String getParagraphe213Francais() {
        return paragraphe213Francais;
    }

    public void setParagraphe213Francais(String paragraphe213Francais) {
        this.paragraphe213Francais = paragraphe213Francais;
    }

    public String getParagraphe213Anglais() {
        return paragraphe213Anglais;
    }

    public void setParagraphe213Anglais(String paragraphe213Anglais) {
        this.paragraphe213Anglais = paragraphe213Anglais;
    }

    public String getSection22Francais() {
        return section22Francais;
    }

    public void setSection22Francais(String section22Francais) {
        this.section22Francais = section22Francais;
    }

    public String getSection22Anglais() {
        return section22Anglais;
    }

    public void setSection22Anglais(String section22Anglais) {
        this.section22Anglais = section22Anglais;
    }

    public String getParagraphe221Francais() {
        return paragraphe221Francais;
    }

    public void setParagraphe221Francais(String paragraphe221Francais) {
        this.paragraphe221Francais = paragraphe221Francais;
    }

    public String getParagraphe221Anglais() {
        return paragraphe221Anglais;
    }

    public void setParagraphe221Anglais(String paragraphe221Anglais) {
        this.paragraphe221Anglais = paragraphe221Anglais;
    }

    public String getParagraphe222Francais() {
        return paragraphe222Francais;
    }

    public void setParagraphe222Francais(String paragraphe222Francais) {
        this.paragraphe222Francais = paragraphe222Francais;
    }

    public String getParagraphe222Anglais() {
        return paragraphe222Anglais;
    }

    public void setParagraphe222Anglais(String paragraphe222Anglais) {
        this.paragraphe222Anglais = paragraphe222Anglais;
    }

    public String getParagraphe223Francais() {
        return paragraphe223Francais;
    }

    public void setParagraphe223Francais(String paragraphe223Francais) {
        this.paragraphe223Francais = paragraphe223Francais;
    }

    public String getParagraphe223Anglais() {
        return paragraphe223Anglais;
    }

    public void setParagraphe223Anglais(String paragraphe223Anglais) {
        this.paragraphe223Anglais = paragraphe223Anglais;
    }

    public String getSection23Francais() {
        return section23Francais;
    }

    public void setSection23Francais(String section23Francais) {
        this.section23Francais = section23Francais;
    }

    public String getSection23Anglais() {
        return section23Anglais;
    }

    public void setSection23Anglais(String section23Anglais) {
        this.section23Anglais = section23Anglais;
    }

    public String getChapitre3Francais() {
        return chapitre3Francais;
    }

    public void setChapitre3Francais(String chapitre3Francais) {
        this.chapitre3Francais = chapitre3Francais;
    }

    public String getChapitre3Anglais() {
        return chapitre3Anglais;
    }

    public void setChapitre3Anglais(String chapitre3Anglais) {
        this.chapitre3Anglais = chapitre3Anglais;
    }

    public String getSection31Francais() {
        return section31Francais;
    }

    public void setSection31Francais(String section31Francais) {
        this.section31Francais = section31Francais;
    }

    public String getSection31Anglais() {
        return section31Anglais;
    }

    public void setSection31Anglais(String section31Anglais) {
        this.section31Anglais = section31Anglais;
    }

    public String getSection32Francais() {
        return section32Francais;
    }

    public void setSection32Francais(String section32Francais) {
        this.section32Francais = section32Francais;
    }

    public String getSection32Anglais() {
        return section32Anglais;
    }

    public void setSection32Anglais(String section32Anglais) {
        this.section32Anglais = section32Anglais;
    }

    public String getSection33Francais() {
        return section33Francais;
    }

    public void setSection33Francais(String section33Francais) {
        this.section33Francais = section33Francais;
    }

    public String getSection33Anglais() {
        return section33Anglais;
    }

    public void setSection33Anglais(String section33Anglais) {
        this.section33Anglais = section33Anglais;
    }

    public String getSection34Francais() {
        return section34Francais;
    }

    public void setSection34Francais(String section34Francais) {
        this.section34Francais = section34Francais;
    }

    public String getSection34Anglais() {
        return section34Anglais;
    }

    public void setSection34Anglais(String section34Anglais) {
        this.section34Anglais = section34Anglais;
    }

    public String getSection35Francais() {
        return section35Francais;
    }

    public void setSection35Francais(String section35Francais) {
        this.section35Francais = section35Francais;
    }

    public String getSection35Anglais() {
        return section35Anglais;
    }

    public void setSection35Anglais(String section35Anglais) {
        this.section35Anglais = section35Anglais;
    }

    public String getSection36Francais() {
        return section36Francais;
    }

    public void setSection36Francais(String section36Francais) {
        this.section36Francais = section36Francais;
    }

    public String getSection36Anglais() {
        return section36Anglais;
    }

    public void setSection36Anglais(String section36Anglais) {
        this.section36Anglais = section36Anglais;
    }

    public String getSection37Francais() {
        return section37Francais;
    }

    public void setSection37Francais(String section37Francais) {
        this.section37Francais = section37Francais;
    }

    public String getSection37Anglais() {
        return section37Anglais;
    }

    public void setSection37Anglais(String section37Anglais) {
        this.section37Anglais = section37Anglais;
    }

    public String getChapitre4Francais() {
        return chapitre4Francais;
    }

    public void setChapitre4Francais(String chapitre4Francais) {
        this.chapitre4Francais = chapitre4Francais;
    }

    public String getChapitre4Anglais() {
        return chapitre4Anglais;
    }

    public void setChapitre4Anglais(String chapitre4Anglais) {
        this.chapitre4Anglais = chapitre4Anglais;
    }

    public String getSection41Francais() {
        return section41Francais;
    }

    public void setSection41Francais(String section41Francais) {
        this.section41Francais = section41Francais;
    }

    public String getSection41Anglais() {
        return section41Anglais;
    }

    public void setSection41Anglais(String section41Anglais) {
        this.section41Anglais = section41Anglais;
    }

    public String getSection42Francais() {
        return section42Francais;
    }

    public void setSection42Francais(String section42Francais) {
        this.section42Francais = section42Francais;
    }

    public String getSection42Anglais() {
        return section42Anglais;
    }

    public void setSection42Anglais(String section42Anglais) {
        this.section42Anglais = section42Anglais;
    }

    public String getSection43Francais() {
        return section43Francais;
    }

    public void setSection43Francais(String section43Francais) {
        this.section43Francais = section43Francais;
    }

    public String getSection43Anglais() {
        return section43Anglais;
    }

    public void setSection43Anglais(String section43Anglais) {
        this.section43Anglais = section43Anglais;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    public Boolean getLockFrancais() {
        return lockFrancais;
    }

    public void setLockFrancais(Boolean lockFrancais) {
        this.lockFrancais = lockFrancais;
    }

    public Boolean getLockAnglais() {
        return lockAnglais;
    }

    public void setLockAnglais(Boolean lockAnglais) {
        this.lockAnglais = lockAnglais;
    }

    public String getParagraphe231Francais() {
        return paragraphe231Francais;
    }

    public void setParagraphe231Francais(String paragraphe231Francais) {
        this.paragraphe231Francais = paragraphe231Francais;
    }

    public String getParagraphe231Anglais() {
        return paragraphe231Anglais;
    }

    public void setParagraphe231Anglais(String paragraphe231Anglais) {
        this.paragraphe231Anglais = paragraphe231Anglais;
    }

    public String getParagraphe232Francais() {
        return paragraphe232Francais;
    }

    public void setParagraphe232Francais(String paragraphe232Francais) {
        this.paragraphe232Francais = paragraphe232Francais;
    }

    public String getParagraphe232Anglais() {
        return paragraphe232Anglais;
    }

    public void setParagraphe232Anglais(String paragraphe232Anglais) {
        this.paragraphe232Anglais = paragraphe232Anglais;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (documentId != null ? documentId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof GenGrecoDocument)) {
            return false;
        }
        GenGrecoDocument other = (GenGrecoDocument) object;
        if ((this.documentId == null && other.documentId != null) || (this.documentId != null && !this.documentId.equals(other.documentId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "GenPGrecoDocument[ documentId=" + documentId + " ]";
    }
    
}
