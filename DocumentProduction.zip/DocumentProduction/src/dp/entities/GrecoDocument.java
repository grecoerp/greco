/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp.entities;


import dp.entities.generated.GenGrecoDocument;
import java.io.Serializable;
import java.util.Locale;

/**
 *
 * @author cwam
 */
public class GrecoDocument extends GenGrecoDocument implements Serializable {

    private static final long serialVersionUID = 1L;

    public String getIntro() {
        return getIntro(Locale.getDefault());
    }

    public String getIntro(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return introAnglais;
            } else {
                return introFrancais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setIntro(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setIntroAnglais(valeur);
            } else {
                setIntroFrancais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getChapitre1() {
        return getChapitre1(Locale.getDefault());
    }

    public String getChapitre1(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return chapitre1Anglais;
            } else {
                return chapitre1Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setChapitre1(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setChapitre1Anglais(valeur);
            } else {
                setChapitre1Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection11() {
        return getSection11(Locale.getDefault());
    }

    public String getSection11(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section11Anglais;
            } else {
                return section11Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection11(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection11Anglais(valeur);
            } else {
                setSection11Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe111() {
        return getParagraphe111(Locale.getDefault());
    }

    public String getParagraphe111(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe111Anglais;
            } else {
                return paragraphe111Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe111(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe111Anglais(valeur);
            } else {
                setParagraphe111Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe112() {
        return getParagraphe112(Locale.getDefault());
    }

    public String getParagraphe112(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe112Anglais;
            } else {
                return paragraphe112Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe112(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe112Anglais(valeur);
            } else {
                setParagraphe112Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe113() {
        return getParagraphe113(Locale.getDefault());
    }

    public String getParagraphe113(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe113Anglais;
            } else {
                return paragraphe113Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe113(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe113Anglais(valeur);
            } else {
                setParagraphe113Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection12() {
        return getSection12(Locale.getDefault());
    }

    public String getSection12(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section12Anglais;
            } else {
                return section12Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection12(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection12Anglais(valeur);
            } else {
                setSection12Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe121() {
        return getParagraphe121(Locale.getDefault());
    }

    public String getParagraphe121(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe121Anglais;
            } else {
                return paragraphe121Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe121(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe121Anglais(valeur);
            } else {
                setParagraphe121Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe122() {
        return getParagraphe122(Locale.getDefault());
    }

    public String getParagraphe122(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe122Anglais;
            } else {
                return paragraphe122Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe122(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe122Anglais(valeur);
            } else {
                setParagraphe122Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getChapitre2() {
        return getChapitre2(Locale.getDefault());
    }

    public String getChapitre2(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return chapitre2Anglais;
            } else {
                return chapitre2Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setChapitre2(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setChapitre2Anglais(valeur);
            } else {
                setChapitre2Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection21() {
        return getSection21(Locale.getDefault());
    }

    public String getSection21(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section21Anglais;
            } else {
                return section21Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection21(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection21Anglais(valeur);
            } else {
                setSection21Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe211() {
        return getParagraphe211(Locale.getDefault());
    }

    public String getParagraphe211(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe211Anglais;
            } else {
                return paragraphe211Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe211(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe211Anglais(valeur);
            } else {
                setParagraphe211Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe212() {
        return getParagraphe212(Locale.getDefault());
    }

    public String getParagraphe212(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe212Anglais;
            } else {
                return paragraphe212Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe212(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe212Anglais(valeur);
            } else {
                setParagraphe212Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe213() {
        return getParagraphe213(Locale.getDefault());
    }

    public String getParagraphe213(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe213Anglais;
            } else {
                return paragraphe213Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe213(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe213Anglais(valeur);
            } else {
                setParagraphe213Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection22() {
        return getSection22(Locale.getDefault());
    }

    public String getSection22(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section22Anglais;
            } else {
                return section22Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection22(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection22Anglais(valeur);
            } else {
                setSection22Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe221() {
        return getParagraphe221(Locale.getDefault());
    }

    public String getParagraphe221(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe221Anglais;
            } else {
                return paragraphe221Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe221(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe221Anglais(valeur);
            } else {
                setParagraphe221Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe222() {
        return getParagraphe222(Locale.getDefault());
    }

    public String getParagraphe222(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe222Anglais;
            } else {
                return paragraphe222Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe222(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe222Anglais(valeur);
            } else {
                setParagraphe222Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe223() {
        return getParagraphe223(Locale.getDefault());
    }

    public String getParagraphe223(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe223Anglais;
            } else {
                return paragraphe223Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe223(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe223Anglais(valeur);
            } else {
                setParagraphe223Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection23() {
        return getSection23(Locale.getDefault());
    }

    public String getSection23(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section23Anglais;
            } else {
                return section23Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection23(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection23Anglais(valeur);
            } else {
                setSection23Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getChapitre3() {
        return getChapitre3(Locale.getDefault());
    }

    public String getChapitre3(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return chapitre3Anglais;
            } else {
                return chapitre3Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setChapitre3(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setChapitre3Anglais(valeur);
            } else {
                setChapitre3Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection31() {
        return getSection31(Locale.getDefault());
    }

    public String getSection31(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section31Anglais;
            } else {
                return section31Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection31(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection31Anglais(valeur);
            } else {
                setSection31Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection32() {
        return getSection32(Locale.getDefault());
    }

    public String getSection32(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section32Anglais;
            } else {
                return section32Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection32(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection32Anglais(valeur);
            } else {
                setSection32Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection33() {
        return getSection33(Locale.getDefault());
    }

    public String getSection33(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section33Anglais;
            } else {
                return section33Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection33(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection33Anglais(valeur);
            } else {
                setSection33Francais(valeur);
            }
        } catch (Exception e) {
        }
    }


    public String getChapitre4() {
        return getChapitre4(Locale.getDefault());
    }

    public String getChapitre4(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return chapitre4Anglais;
            } else {
                return chapitre4Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setChapitre4(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setChapitre4Anglais(valeur);
            } else {
                setChapitre4Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection41() {
        return getSection41(Locale.getDefault());
    }

    public String getSection41(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section41Anglais;
            } else {
                return section41Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection41(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection41Anglais(valeur);
            } else {
                setSection41Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection42() {
        return getSection42(Locale.getDefault());
    }

    public String getSection42(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section42Anglais;
            } else {
                return section42Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection42(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection42Anglais(valeur);
            } else {
                setSection42Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getSection43() {
        return getSection43(Locale.getDefault());
    }

    public String getSection43(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return section43Anglais;
            } else {
                return section43Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setSection43(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setSection43Anglais(valeur);
            } else {
                setSection43Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public Boolean getLock() {
        return getLock(Locale.getDefault());
    }

    public Boolean getLock(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return lockAnglais;
            } else {
                return lockFrancais;
            }
        } catch (Exception e) {
            return false;
        }
    }

    public void setLock(Locale locale, Boolean valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setLockAnglais(valeur);
            } else {
                setLockFrancais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String toString() {
        return getIntro();
    }

    public String getParagraphe231() {
        return getParagraphe231(Locale.getDefault());
    }

    public String getParagraphe231(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe231Anglais;
            } else {
                return paragraphe231Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe231(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe231Anglais(valeur);
            } else {
                setParagraphe231Francais(valeur);
            }
        } catch (Exception e) {
        }
    }

    public String getParagraphe232() {
        return getParagraphe232(Locale.getDefault());
    }

    public String getParagraphe232(Locale locale) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                return paragraphe232Anglais;
            } else {
                return paragraphe232Francais;
            }
        } catch (Exception e) {
            return "";
        }
    }

    public void setParagraphe232(Locale locale, String valeur) {
        try {
            if (locale.equals(Locale.ENGLISH)) {
                setParagraphe232Anglais(valeur);
            } else {
                setParagraphe232Francais(valeur);
            }
        } catch (Exception e) {
        }
    }
}
