package dp.imgresources;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.InputStream;

/**
 *
 * @author cwam
 */
public class Stream {

    public InputStream getDelegFile() {
        try {
            return getClass().getResourceAsStream("/images/edpfcr.png");
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream getRemonteeFile() {
        try {
            return getClass().getResourceAsStream("/images/rmtfrg.png");
        } catch (Exception e) {
            return null;
        }
    }
}
