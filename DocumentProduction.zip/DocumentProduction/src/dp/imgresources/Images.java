package dp.imgresources;

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
import java.awt.Image;
import javax.swing.ImageIcon;

/**
 *
 * @author cwam
 */
public class Images {

    public Image getImage(String nom_image) {
        try {
            return new ImageIcon(getClass().getResource("/images/"+nom_image)).getImage();
        } catch (Exception e) {
            return null;
        }
    }
    public Image logo() {
        try {
            return new ImageIcon(getClass().getResource("/images/logo.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgOui() {
        try {
            return new ImageIcon(getClass().getResource("/images/oui.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image accept() {
        try {
            return new ImageIcon(getClass().getResource("/images/accept.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image exclamation() {
        try {
            return new ImageIcon(getClass().getResource("/images/exclamation.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgNon() {
        try {
            return new ImageIcon(getClass().getResource("/images/non.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgYes() {
        try {
            return new ImageIcon(getClass().getResource("/images/check.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgNo() {
        try {
            return new ImageIcon(getClass().getResource("/images/cancel.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image carteDuCameroun() {
        try {
            return new ImageIcon(getClass().getResource("/images/Carte_du_Cameroun.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image image_Drapeau() {
        try {
            return new ImageIcon(getClass().getResource("/images/drapeau.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image image_Etoile() {
        try {
//            return new ImageIcon(getClass().getResource("/images/star.jpg")).getImage();
            return new ImageIcon(getClass().getResource("/images/etoile.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image image_DrapeauHautGauche() {
        try {
            return new ImageIcon(getClass().getResource("/images/drapeauHtGche.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image image_DrapeauHautDroite() {
        try {
            return new ImageIcon(getClass().getResource("/images/drapeauHtDte.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgArmoirieCM() {
        try {
            return new ImageIcon(getClass().getResource("/images/armoirieCM.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgProjet() {
        try {
            return new ImageIcon(getClass().getResource("/images/projet.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image imgArmoirieCouleur() {
        try {
            return new ImageIcon(getClass().getResource("/images/armoirieCouleur.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image bourseMINFI() {
        try {
            return new ImageIcon(getClass().getResource("/images/bourseMINFI.png")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image pyramide() {
        try {
            return new ImageIcon(getClass().getResource("/images/pyramide.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image caisseAvprojet() {
        try {
            return new ImageIcon(getClass().getResource("/images/caisseAvprojet.png")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image logoMINEPAT() {
        try {
            return new ImageIcon(getClass().getResource("/images/logoMINEPAT.jpg")).getImage();
        } catch (Exception e) {
            return null;
        }
    }

    public Image enteteOrdreMission() {
        try {
            return new ImageIcon(getClass().getResource("/images/entete_ordre_mission.png")).getImage();
        } catch (Exception e) {
            return null;
        }
    }
}
