/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 *
 * @author ouethy
 */
public class GrecoLangue {

    private static final String bundleName = GlobalParameters.rootPackageName+"/resources/cdmtLangue";
    private static ResourceBundle bundle = ResourceBundle.getBundle(bundleName);

    public static void reloadBundle() {
        bundle = ResourceBundle.getBundle(bundleName);
    }

    public static String texte(String key) {
        try {
            return bundle.getString(key);
        } catch (Exception e) {
            return "...";
        }
    }

    public static String texte(String key, Locale locale) {
        if (locale.equals(Locale.ENGLISH)) {
            return texteEN(key);
        } else {
            return texteFR(key);
        }
    }

    public static String texteEN(String key) {
        try {
            return ResourceBundle.getBundle(bundleName, new Locale("en")).getString(key);
        } catch (Exception e) {
            return "...";
        }
    }

    public static String texteFR(String key) {
        try {
            return ResourceBundle.getBundle(bundleName, new Locale("fr")).getString(key);
        } catch (Exception e) {
            return "...";
        }
    }
    public static final String PLF_DRAFT = "PLF_DRAFT";
    public static final String CHAPITRE = "CHAPITRE";
    public static final String PAYS = "PAYS";
    public static final String SOMMAIRE = "SOMMAIRE";
    //
    public static final String CDMT = "CDMT";
    public static final String VERSION = "VERSION";
    public static final String SOMMAIRE_ANNEXE = "SOMMAIRE_ANNEXE";
    //
    public static final String ANNEXE = "ANNEXE";
    public static final String ANNEXE_1 = "ANNEXE_1";
    public static final String ANNEXE_2_PART1 = "ANNEXE_2_PART1";
    public static final String ANNEXE_2_PART2 = "ANNEXE_2_PART2";
    public static final String ANNEXE_3_PART1 = "ANNEXE_3_PART1";
    public static final String ANNEXE_3_PART2 = "ANNEXE_3_PART2";
    public static final String ANNEXE_4 = "ANNEXE_4";
    public static final String ANNEXE_5 = "ANNEXE_5";
//    public static final String ANNEXE_6 = "ANNEXE_6";
    public static final String PRESENTATION_PROGRAMME = "PRESENTATION_PROGRAMME";
    public static final String STRATEGIE_PROGRAMME = "STRATEGIE_PROGRAMME";
    public static final String PRESENTATION_ACTIONS = "PRESENTATION_ACTIONS";
    public static final String CADRE_LOGIQUE_PROGRAMME = "CADRE_LOGIQUE_PROGRAMME";
    public static final String PROGRAMME = "PROGRAMME";
    public static final String PROGRAMMES = "PROGRAMMES";
    public static final String ACTION = "ACTION";
//
    public static final String CADRE_LOGIQUE_DU_PROGRAMME = "CADRE_LOGIQUE_DU_PROGRAMME";
    public static final String Actions_du_programme = "Actions_du_programme";
    public static final String Objectif = "Objectif_";
    public static final String Libelle = "Libelle";
    public static final String Indicateurs = "Indicateurs_";
    public static final String Niveau_cible = "Niveau_cible";
    public static final String Niveau_Ref = "Niveau_Ref";
    public static final String Source_de_verification = "Source_de_verification";
    public static final String CADRE_LOGIQUE_CHAPITRE = "CADRE_LOGIQUE_CHAPITRE";
    public static final String Programmes_du_chapitre = "Programmes_du_chapitre";
//
    public static final String EN_Milliers_FCFA = "EN_Milliers_FCFA";
    public static final String EN_FCFA = "EN_FCFA";
    public static final String Programmation_financiere_N_N2 = "Programmation_financiere_N_N2";
    public static final String BUDGETISATION_N = "BUDGETISATION_N";
    public static final String TOTAL_CHAPITRE = "TOTAL_CHAPITRE";
    public static final String AE = "AE";
    public static final String CP = "CP";
    public static final String ANNEE_N = "ANNEE_N";
    public static final String ANNEE_N1 = "ANNEE_N1";
    public static final String ANNEE_N2 = "ANNEE_N2";

}
