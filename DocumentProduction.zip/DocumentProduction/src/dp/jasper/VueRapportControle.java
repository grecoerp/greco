/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp.jasper;

import com.siicore.util.DateUtil;

/**
 *
 * @author DGLS
 */
public class VueRapportControle {

    private String code;
    private Boolean okFr;
    private Boolean requiredFr;
    private String libelleFr;
    private Boolean okUs;
    private Boolean requiredUs;
    private String libelleUs;
    private String exLibelleFrancais;
    private String exLibelleAnglais;
    private String chLibelleFrancais;
    private String chLibelleAnglais;
    private String exMillesime;
    private String chCodeChapitre;
    private int annee;

    public VueRapportControle(String code) {
        this.code = code;
//        this.exLibelleFrancais = chapitre.getTblExercice().getExLibelleFr();
//        this.exLibelleAnglais = chapitre.getTblExercice().getExLibelleUs();
//        this.chLibelleFrancais = chapitre.getChLibelleFr();
//        this.chLibelleAnglais = chapitre.getChLibelleUs();
//        this.exMillesime = chapitre.getTblChapitrePK().getExMillesime();
//        this.chCodeChapitre = chapitre.getTblChapitrePK().getChCodeChapitre();
//        this.annee = DateUtil.getYear(chapitre.getTblExercice().getExDateDebut());
    }

    public String getChCodeChapitre() {
        return chCodeChapitre;
    }

    public void setChCodeChapitre(String chCodeChapitre) {
        this.chCodeChapitre = chCodeChapitre;
    }

    public String getChLibelleAnglais() {
        return chLibelleAnglais;
    }

    public void setChLibelleAnglais(String chLibelleAnglais) {
        this.chLibelleAnglais = chLibelleAnglais;
    }

    public String getChLibelleFrancais() {
        return chLibelleFrancais;
    }

    public void setChLibelleFrancais(String chLibelleFrancais) {
        this.chLibelleFrancais = chLibelleFrancais;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getExLibelleAnglais() {
        return exLibelleAnglais;
    }

    public void setExLibelleAnglais(String exLibelleAnglais) {
        this.exLibelleAnglais = exLibelleAnglais;
    }

    public String getExLibelleFrancais() {
        return exLibelleFrancais;
    }

    public void setExLibelleFrancais(String exLibelleFrancais) {
        this.exLibelleFrancais = exLibelleFrancais;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Boolean getOkFr() {
        return okFr;
    }

    public void setOkFr(Boolean okFr) {
        this.okFr = okFr;
    }

    public Boolean getOkUs() {
        return okUs;
    }

    public void setOkUs(Boolean okUs) {
        this.okUs = okUs;
    }

    public Boolean getRequiredFr() {
        return requiredFr;
    }

    public void setRequiredFr(Boolean requiredFr) {
        this.requiredFr = requiredFr;
    }

    public Boolean getRequiredUs() {
        return requiredUs;
    }

    public void setRequiredUs(Boolean requiredUs) {
        this.requiredUs = requiredUs;
    }

    public int getAnnee() {
        return annee;
    }

    public void setAnnee(int annee) {
        this.annee = annee;
    }
}
