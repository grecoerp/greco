package dp;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.GrayColor;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfShading;
import com.itextpdf.text.pdf.PdfShadingPattern;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.text.pdf.ShadingColor;
import com.siicore.cls.CleValeur;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import javax.swing.ImageIcon;

public class GrecoPdfPageEventHelper extends PdfPageEventHelper {

//////////////////////////////    private Image pdfBGImage = null;
////////////////////////////    private java.awt.Image bgImage;
////////////////////////////    private TblChapitre chapitre;
////////////////////////////    private String enteteLFI;
////////////////////////////    private String typeRapport;
////////////////////////////    private String enteteHeaderGauche;
////////////////////////////    private String enteteHeaderDroiteH;
////////////////////////////    private String enteteHeaderDroiteB;
////////////////////////////    private String enteteSame;
////////////////////////////    private String piedSame;
////////////////////////////    private boolean printHeader = false;
////////////////////////////    private boolean printFooter = false;
////////////////////////////    private boolean printBG = false;
////////////////////////////    private BaseColor baseColor;
////////////////////////////    private int style = 0;
////////////////////////////    public final static int style_Default = 0;
////////////////////////////    public final static int style_PageOpposite = 1;
////////////////////////////    public final static int style_PageOppositeSame = 2;
////////////////////////////    private int startPage = 0;
////////////////////////////    private int currentPage;
////////////////////////////    private String baseFontName;
////////////////////////////    private List<CleValeur> sommaires = new ArrayList<>();
////////////////////////////    private boolean printRecto;
////////////////////////////
////////////////////////////    public int getCurrentPage(int startPage) {
////////////////////////////        try {
////////////////////////////            return startPage + currentPage;
////////////////////////////        } catch (Exception e) {
////////////////////////////            return startPage;
////////////////////////////        }
////////////////////////////    }
////////////////////////////
////////////////////////////    public void addSommaire(String code) {
////////////////////////////        sommaires.add(new CleValeur(code, String.valueOf(getCurrentPage()), ""));
////////////////////////////    }
////////////////////////////
////////////////////////////    public List<CleValeur> getSommaires() {
////////////////////////////        return sommaires;
////////////////////////////    }
////////////////////////////
////////////////////////////    public int getCurrentPage() {
////////////////////////////        return getCurrentPage(startPage);
////////////////////////////    }
////////////////////////////
////////////////////////////    public void setPrintFooter(boolean printFooter) {
////////////////////////////        this.printFooter = printFooter;
////////////////////////////    }
////////////////////////////
////////////////////////////    public void setPrintHeader(boolean printHeader) {
////////////////////////////        this.printHeader = printHeader;
////////////////////////////    }
////////////////////////////
////////////////////////////    public void setPrintBG(boolean printBG) {
////////////////////////////        this.printBG = printBG;
////////////////////////////    }
////////////////////////////
////////////////////////////    public boolean isPrintBGPage() {
////////////////////////////        return printBG || printHeader || printFooter;
////////////////////////////    }
////////////////////////////
//////////////////////////////    public void setEnteteHeader(String enteteHeaderGauche, String enteteHeaderDroiteH, String enteteHeaderDroiteB) {
//////////////////////////////        this.enteteHeaderGauche = enteteHeaderGauche;
//////////////////////////////        this.enteteHeaderDroiteH = enteteHeaderDroiteH;
//////////////////////////////        this.enteteHeaderDroiteB = enteteHeaderDroiteB;
//////////////////////////////    }
////////////////////////////    public void setTextForHeaderSameType(String entete) {
////////////////////////////        this.enteteSame = entete;
////////////////////////////    }
////////////////////////////
////////////////////////////    public void setTextForFooterSameType(String pied) {
////////////////////////////        this.piedSame = pied;
////////////////////////////    }
////////////////////////////
////////////////////////////    public Image getBackGroundImage(PdfWriter writer, Document document) {
//////////////////////////////        if (pdfBGImage == null) {
////////////////////////////        try {
////////////////////////////            PdfContentByte byte1 = new PdfContentByte(writer);
////////////////////////////            Image pdfBGImage = Image.getInstance(byte1, bgImage, 1);
////////////////////////////            float x, y, w, h;
////////////////////////////            if (pdfBGImage.getWidth() < pdfBGImage.getHeight()) {
////////////////////////////                // image en portrait
////////////////////////////                x = document.left();
////////////////////////////                y = document.bottom();
////////////////////////////                w = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
////////////////////////////                h = document.getPageSize().getHeight();
////////////////////////////            } else {
////////////////////////////                // image en paysage
////////////////////////////                x = document.left();
////////////////////////////                y = document.bottom();
////////////////////////////                w = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
////////////////////////////                h = w * (pdfBGImage.getHeight() / pdfBGImage.getWidth());
////////////////////////////                y = (document.getPageSize().getHeight() - h) / 2;
////////////////////////////            }
////////////////////////////            pdfBGImage.setAbsolutePosition(x, y);
////////////////////////////            pdfBGImage.scaleToFit(w, h);
////////////////////////////            pdfBGImage.setBorderWidth(1);
////////////////////////////            pdfBGImage.setScaleToFitHeight(true);
////////////////////////////            return pdfBGImage;
////////////////////////////        } catch (Exception ex) {
////////////////////////////            printBG = false;
////////////////////////////            return null;
////////////////////////////        }
//////////////////////////////        }
////////////////////////////
////////////////////////////    }
////////////////////////////
////////////////////////////    public static Image getItextImage(PdfWriter writer, java.awt.Image awt) {
////////////////////////////        ImageIcon c = new ImageIcon(awt);
////////////////////////////        return getItextImage(writer, awt, c.getIconWidth(), c.getIconHeight());
////////////////////////////    }
////////////////////////////
////////////////////////////    public static Image getItextImage(PdfWriter writer, java.awt.Image awt, float width, float height) {
////////////////////////////        Image itextImage = null;
////////////////////////////        try {
////////////////////////////            PdfContentByte byte1 = new PdfContentByte(writer);
////////////////////////////            itextImage = Image.getInstance(byte1, awt, 1);
////////////////////////////            itextImage.scaleAbsolute(width, height);
////////////////////////////        } catch (Exception ex) {
////////////////////////////        }
////////////////////////////        return itextImage;
////////////////////////////    }
////////////////////////////
////////////////////////////    public static Image getItextImage(PdfWriter writer, java.awt.Image awt, float percent) {
////////////////////////////        Image itextImage = null;
////////////////////////////        try {
////////////////////////////            PdfContentByte byte1 = new PdfContentByte(writer);
////////////////////////////            itextImage = Image.getInstance(byte1, awt, 1);
////////////////////////////            itextImage.scalePercent(percent);
//////////////////////////////            itextImage.setScaleToFitHeight(true);
////////////////////////////        } catch (Exception ex) {
////////////////////////////        }
////////////////////////////        return itextImage;
////////////////////////////    }
////////////////////////////
////////////////////////////    public GrecoPdfPageEventHelper(String enteteLFI, String typeRapport,
////////////////////////////            String enteteHeaderGauche, String enteteHeaderDroiteH, String enteteHeaderDroiteB, boolean printRecto,
////////////////////////////            TblChapitre chapitre, java.awt.Image bgImage, BaseColor baseColor, int style, String baseFontName) {
////////////////////////////        this.bgImage = bgImage;
////////////////////////////        this.chapitre = chapitre;
////////////////////////////        this.enteteLFI = enteteLFI;
////////////////////////////        this.typeRapport = typeRapport;
////////////////////////////        this.baseColor = baseColor;
////////////////////////////        this.enteteHeaderGauche = enteteHeaderGauche;
////////////////////////////        this.enteteHeaderDroiteH = enteteHeaderDroiteH;
////////////////////////////        this.enteteHeaderDroiteB = enteteHeaderDroiteB;
////////////////////////////        this.style = style;
////////////////////////////        this.baseFontName = baseFontName;
////////////////////////////        this.printRecto = printRecto;
////////////////////////////    }
////////////////////////////
////////////////////////////    public GrecoPdfPageEventHelper(String pied, boolean printRecto, TblChapitre chapitre,
////////////////////////////            java.awt.Image bgImage, BaseColor baseColor, String baseFontName) {
////////////////////////////        this.bgImage = bgImage;
////////////////////////////        this.chapitre = chapitre;
////////////////////////////        this.enteteLFI = "";
////////////////////////////        this.typeRapport = "";
////////////////////////////        this.baseColor = baseColor;
////////////////////////////        this.enteteHeaderGauche = "";
////////////////////////////        this.enteteHeaderDroiteH = "";
////////////////////////////        this.enteteHeaderDroiteB = "";
////////////////////////////        this.style = style_PageOppositeSame;
////////////////////////////        this.baseFontName = baseFontName;
////////////////////////////        this.enteteSame = "";
////////////////////////////        this.piedSame = pied;
////////////////////////////        this.printRecto = printRecto;
////////////////////////////    }
////////////////////////////
////////////////////////////    public static void doRectangle(PdfContentByte cb, Rectangle rect, float lineWidth, BaseColor color) {
//////////////////////////////        float aj = lineWidth / 2;
//////////////////////////////        doLine(cb, rect.getLeft() - aj, rect.getTop(), rect.getRight() + aj, rect.getTop(), lineWidth, color);
//////////////////////////////        doLine(cb, rect.getRight(), rect.getTop(), rect.getRight(), rect.getBottom(), lineWidth, color);
//////////////////////////////        doLine(cb, rect.getRight() + aj, rect.getBottom(), rect.getLeft() - aj, rect.getBottom(), lineWidth, color);
//////////////////////////////        doLine(cb, rect.getLeft(), rect.getBottom(), rect.getLeft(), rect.getTop(), lineWidth, color);
////////////////////////////        rect.setBorder(Rectangle.BOX);
////////////////////////////        rect.setBorderWidth(lineWidth);
////////////////////////////        rect.setBorderColor(color);
////////////////////////////        cb.rectangle(rect);
////////////////////////////    }
////////////////////////////
////////////////////////////    public static void doRectangle(PdfContentByte cb, Rectangle rect, float lineWidth, BaseColor color, BaseColor fill) {
//////////////////////////////        doRectangle(cb, rect, lineWidth, color);
//////////////////////////////        cb.moveTo((rect.getLeft() + rect.getRight()) / 2, (rect.getTop() + rect.getBottom()) / 2);
////////////////////////////        //cb.circle((rect.getLeft() + rect.getRight()) / 2, (rect.getTop() + rect.getBottom()) / 2, 10);
////////////////////////////        rect.setBorder(Rectangle.BOX);
////////////////////////////        rect.setBorderWidth(lineWidth);
////////////////////////////        rect.setBorderColor(color);
////////////////////////////        rect.setBackgroundColor(fill);
////////////////////////////        cb.rectangle(rect);
////////////////////////////    }
////////////////////////////
////////////////////////////    public static void doLine(PdfContentByte cb, float x1, float y1, float x2, float y2, float lineWidth, BaseColor color) {
////////////////////////////        cb.resetRGBColorStroke();
////////////////////////////        cb.setColorStroke(color);
////////////////////////////        cb.setLineWidth(lineWidth);
////////////////////////////        cb.moveTo(x1, y1);
////////////////////////////        cb.lineTo(x2, y2);
////////////////////////////        cb.stroke();
////////////////////////////    }
////////////////////////////
////////////////////////////    public static void doCircle(PdfContentByte cb, float x, float y, BaseColor color) {
////////////////////////////        cb.resetRGBColorStroke();
////////////////////////////        cb.setColorStroke(color);
////////////////////////////        cb.circle(x, y, 10);
////////////////////////////        cb.stroke();
////////////////////////////    }
////////////////////////////
////////////////////////////    public static void doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth) {
////////////////////////////        doTexte(cb, x, y, texte, f, align, hLigne, maxWidth, false);
////////////////////////////    }
////////////////////////////
//////////////////////////////////////////////////    public static void doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth, boolean inverseTexte) {
//////////////////////////////////////////////////        cb.setColorFill(f.getColor());
//////////////////////////////////////////////////        cb.setFontAndSize(f.getBaseFont(), f.getSize());
//////////////////////////////////////////////////        Chunk c = new Chunk(texte, f);
//////////////////////////////////////////////////        float w = c.getWidthPoint();
//////////////////////////////////////////////////        if (w < maxWidth) {
//////////////////////////////////////////////////            doTexte(cb, x, y, texte, f, align);
//////////////////////////////////////////////////        } else {
//////////////////////////////////////////////////            List<String> l = Arrays.asList(texte.split(" "));
//////////////////////////////////////////////////
//////////////////////////////////////////////////            String str = "";
//////////////////////////////////////////////////            List<String> textes = new ArrayList<>();
//////////////////////////////////////////////////            if (inverseTexte) {
//////////////////////////////////////////////////                for (int i = l.size(); i > 0; i--) {
//////////////////////////////////////////////////                    String s = l.get(i - 1);
//////////////////////////////////////////////////                    c = new Chunk(s + " " + str, f);
//////////////////////////////////////////////////                    if (c.getWidthPoint() > maxWidth) {
//////////////////////////////////////////////////                        textes.add(str);
//////////////////////////////////////////////////                        str = s;
//////////////////////////////////////////////////                    } else {
//////////////////////////////////////////////////                        str = s + " " + str;
//////////////////////////////////////////////////                    }
//////////////////////////////////////////////////                }
//////////////////////////////////////////////////            } else {
//////////////////////////////////////////////////                for (String s : l) {
//////////////////////////////////////////////////                    c = new Chunk(str + " " + s, f);
//////////////////////////////////////////////////                    if (c.getWidthPoint() > maxWidth) {
//////////////////////////////////////////////////                        textes.add(str);
//////////////////////////////////////////////////                        str = s;
//////////////////////////////////////////////////                    } else {
//////////////////////////////////////////////////                        str += " " + s;
//////////////////////////////////////////////////                    }
//////////////////////////////////////////////////                }
//////////////////////////////////////////////////            }
//////////////////////////////////////////////////            if (!str.isEmpty()) {
//////////////////////////////////////////////////                textes.add(str);
//////////////////////////////////////////////////            }
//////////////////////////////////////////////////            doTextes(cb, x, y, textes, f, align, hLigne);
//////////////////////////////////////////////////        }
//////////////////////////////////////////////////    }
////////////////////////////    public static int doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth, boolean inverseTexte) {
////////////////////////////        cb.setColorFill(f.getColor());
////////////////////////////        cb.setFontAndSize(f.getBaseFont(), f.getSize());
////////////////////////////        Chunk c = new Chunk(texte, f);
////////////////////////////        float w = c.getWidthPoint();
////////////////////////////        int nbLigne = 1;
////////////////////////////        if (w < maxWidth) {
////////////////////////////            doTexte(cb, x, y, texte, f, align);
////////////////////////////        } else {
////////////////////////////            List<String> l = Arrays.asList(texte.split(" "));
////////////////////////////
////////////////////////////            String str = "";
////////////////////////////            List<String> textes = new ArrayList<>();
////////////////////////////            if (inverseTexte) {
////////////////////////////                for (int i = l.size(); i > 0; i--) {
////////////////////////////                    String s = l.get(i - 1);
////////////////////////////                    c = new Chunk(s + " " + str, f);
////////////////////////////                    if (c.getWidthPoint() > maxWidth) {
////////////////////////////                        if (!str.isEmpty()) {
////////////////////////////                            textes.add(str);
////////////////////////////                        }
////////////////////////////
////////////////////////////                        str = s;
////////////////////////////                    } else {
////////////////////////////                        str = s + " " + str;
////////////////////////////                    }
////////////////////////////                }
////////////////////////////            } else {
////////////////////////////                for (String s : l) {
////////////////////////////                    c = new Chunk(str + " " + s, f);
////////////////////////////                    if (c.getWidthPoint() > maxWidth) {
////////////////////////////                        textes.add(str);
////////////////////////////                        str = s;
////////////////////////////                    } else {
////////////////////////////                        str += " " + s;
////////////////////////////                    }
////////////////////////////                }
////////////////////////////            }
////////////////////////////            if (!str.isEmpty()) {
////////////////////////////                textes.add(str);
////////////////////////////            }
////////////////////////////            if (inverseTexte && hLigne < 0) {
////////////////////////////                String tmp;
////////////////////////////                int s = textes.size();
////////////////////////////                for (int i = 0; i < s / 2; i++) {
////////////////////////////                    tmp = textes.get(i);
////////////////////////////                    textes.set(i, textes.get(s - i - 1));
////////////////////////////                    textes.set(s - i - 1, tmp);
////////////////////////////                }
////////////////////////////            }
////////////////////////////            nbLigne = textes.size();
////////////////////////////            doTextes(cb, x, y, textes, f, align, hLigne);
////////////////////////////        }
////////////////////////////        return nbLigne;
////////////////////////////    }
////////////////////////////
////////////////////////////    public static float getLen(String texte, Font f) {
////////////////////////////        try {
////////////////////////////            return new Chunk(texte, f).getWidthPoint();
////////////////////////////        } catch (Exception e) {
////////////////////////////            return 0;
////////////////////////////        }
////////////////////////////    }
////////////////////////////
////////////////////////////    public static float doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align) {
////////////////////////////        cb.beginText();
////////////////////////////        float w = new Chunk(texte, f).getWidthPoint();
////////////////////////////        cb.setColorFill(f.getColor());
////////////////////////////        cb.setFontAndSize(f.getBaseFont(), f.getSize());
////////////////////////////        cb.showTextAligned(align, texte.trim(), x, y, 0);
////////////////////////////        cb.endText();
////////////////////////////        return w;
////////////////////////////    }
////////////////////////////
////////////////////////////    public static float doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float underLineWidth) {
////////////////////////////        cb.beginText();
////////////////////////////        cb.setColorFill(f.getColor());
////////////////////////////        cb.setFontAndSize(f.getBaseFont(), f.getSize());
////////////////////////////        cb.showTextAligned(align, texte.trim(), x, y, 0);
////////////////////////////        cb.endText();
////////////////////////////        float w = new Chunk(texte, f).getWidthPoint();
////////////////////////////        switch (align) {
////////////////////////////            case PdfContentByte.ALIGN_LEFT:
////////////////////////////                doLine(cb, x, y - 2, x + w, y - 2, underLineWidth, f.getColor());
////////////////////////////                break;
////////////////////////////            case PdfContentByte.ALIGN_CENTER:
////////////////////////////                doLine(cb, x - w / 2, y - 2, x + w / 2, y - 2, underLineWidth, f.getColor());
////////////////////////////                break;
////////////////////////////            case PdfContentByte.ALIGN_RIGHT:
////////////////////////////                doLine(cb, x - w, y - 2, x, y - 2, underLineWidth, f.getColor());
////////////////////////////                break;
////////////////////////////            default:
////////////////////////////        }
////////////////////////////        return w;
////////////////////////////    }
////////////////////////////
////////////////////////////    public static void doTextes(PdfContentByte cb, float x, float y, List<String> array, Font f, int align, float hLigne) {
////////////////////////////        cb.beginText();
////////////////////////////        cb.setColorFill(f.getColor());
////////////////////////////        cb.setFontAndSize(f.getBaseFont(), f.getSize());
////////////////////////////        cb.showTextAligned(align, array.get(0).trim(), x, y, 0);
////////////////////////////        array.remove(0);
////////////////////////////        int i = 1;
////////////////////////////        for (String str : array) {
////////////////////////////            //cb.moveTextWithLeading(0, hLigne);
////////////////////////////            //cb.showText(str);
////////////////////////////            cb.showTextAligned(align, str.trim(), x, y + (i++) * hLigne, 0);
////////////////////////////        }
////////////////////////////        cb.endText();
////////////////////////////    }
////////////////////////////
////////////////////////////    @Override
////////////////////////////    public void onStartPage(PdfWriter writer, Document document) {
////////////////////////////        currentPage = document.getPageNumber();
////////////////////////////        PdfContentByte cb = writer.getDirectContentUnder();
////////////////////////////        try {
////////////////////////////            if (printBG) {
////////////////////////////                cb.addImage(getBackGroundImage(writer, document));
////////////////////////////            }
////////////////////////////        } catch (Exception ex) {
//////////////////////////////            ex.printStackTrace();
////////////////////////////        }
////////////////////////////
////////////////////////////        Font bfh = null;
////////////////////////////        Font bff = null;
////////////////////////////        Font bfNum = null;
////////////////////////////        try {
////////////////////////////            bfh = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 8.5F, Font.NORMAL, baseColor);
////////////////////////////            bff = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 6F, Font.NORMAL, baseColor);
////////////////////////////            bfNum = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 11F, Font.NORMAL, baseColor);
////////////////////////////        } catch (Exception ex) {
//////////////////////////////            ex.printStackTrace();
////////////////////////////        }
////////////////////////////
////////////////////////////        float w = (document.right() - document.left()) / 3;
////////////////////////////        float hl = 11;
////////////////////////////        // Header Page
////////////////////////////        if (printHeader) {
////////////////////////////            addPageHeader(cb, document, bfh, bff, bfNum, w, hl);
////////////////////////////        }
////////////////////////////        // Footer page
////////////////////////////        if (printFooter) {
////////////////////////////            addPageFooter(cb, document, bff, hl);
////////////////////////////        }
////////////////////////////    }
////////////////////////////
////////////////////////////    private void addPageHeader(PdfContentByte cb, Document document, Font bfh, Font bff, Font bfNum, float w, float hl) {
////////////////////////////        bfNum.setColor(BaseColor.WHITE);
////////////////////////////        switch (style) {
////////////////////////////            case style_PageOpposite:
////////////////////////////                if (getCurrentPage() % 2 == 0 || printRecto) {
////////////////////////////                    // PAGE A GAUCHE
////////////////////////////                    doTexte(cb, document.left() + 5, document.top() + hl * 2 + 2, enteteHeaderGauche, bfh, PdfContentByte.ALIGN_LEFT);
////////////////////////////                    doLine(cb, document.left(), document.top() + hl * 2, document.right() + document.rightMargin(), document.top() + hl * 2, 0.5F, baseColor);
////////////////////////////                    Rectangle rect = new Rectangle(document.left() - 16, document.top() + 0.5F * hl, document.left(), document.top() + 2.75F * hl);
////////////////////////////                    doRectangle(cb, rect, 1, BaseColor.LIGHT_GRAY, BaseColor.LIGHT_GRAY);
////////////////////////////                    doTexte(cb, document.left() - 8, document.top() + 0.5F * hl + 3, String.valueOf(getCurrentPage()), bfNum, PdfContentByte.ALIGN_CENTER);
////////////////////////////                } else {
////////////////////////////                    // PAGE A DROITE
////////////////////////////                    doTexte(cb, document.right() - 5, document.top() + hl * 2 + 2, enteteHeaderDroiteB, bfh, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doTexte(cb, document.right() - 5, document.top() + hl + 2, ""/*enteteHeaderDroiteB*/, bfh, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doLine(cb, 0, document.top() + hl * 2, document.right(), document.top() + hl * 2, 0.5F, baseColor);
////////////////////////////                    Rectangle rect = new Rectangle(document.right(), document.top() + 0.5F * hl, document.right() + 16, document.top() + 2.75F * hl);
////////////////////////////                    doRectangle(cb, rect, 1, BaseColor.LIGHT_GRAY, BaseColor.LIGHT_GRAY);
////////////////////////////                    doTexte(cb, document.right() + 8, document.top() + 0.5F * hl + 3, String.valueOf(getCurrentPage()), bfNum, PdfContentByte.ALIGN_CENTER);
////////////////////////////                }
////////////////////////////                break;
////////////////////////////            case style_PageOppositeSame:
////////////////////////////                if (getCurrentPage() % 2 == 0 || printRecto) {
////////////////////////////                    // PAGE A GAUCHE
////////////////////////////                    doTexte(cb, document.left() + 5, document.top() + hl * 2 + 2, enteteSame, bfh, PdfContentByte.ALIGN_LEFT);
////////////////////////////                    doLine(cb, document.left(), document.top() + hl * 2, document.right(), document.top() + hl * 2, 0.5F, baseColor);
////////////////////////////                    Rectangle rect = new Rectangle(document.left() - 16, document.top() + 0.5F * hl, document.left(), document.top() + 2.75F * hl);
////////////////////////////                    doRectangle(cb, rect, 1, BaseColor.LIGHT_GRAY, BaseColor.LIGHT_GRAY);
////////////////////////////                    doTexte(cb, document.left() - 8, document.top() + 0.5F * hl + 3, String.valueOf(getCurrentPage()), bfNum, PdfContentByte.ALIGN_CENTER);
////////////////////////////                } else {
////////////////////////////                    // PAGE A DROITE
////////////////////////////                    doTexte(cb, document.right() - 5, document.top() + hl * 2 + 2, enteteSame, bfh, PdfContentByte.ALIGN_RIGHT);
//////////////////////////////                    doTexte(cb, document.right() - 5, document.top() + hl + 2, ""/*enteteHeaderDroiteB*/, bfh, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doLine(cb, document.left(), document.top() + hl * 2, document.right(), document.top() + hl * 2, 0.5F, baseColor);
////////////////////////////                    Rectangle rect = new Rectangle(document.right(), document.top() + 0.5F * hl, document.right() + 16, document.top() + 2.75F * hl);
////////////////////////////                    doRectangle(cb, rect, 1, BaseColor.LIGHT_GRAY, BaseColor.LIGHT_GRAY);
////////////////////////////                    doTexte(cb, document.right() + 8, document.top() + 0.5F * hl + 3, String.valueOf(getCurrentPage()), bfNum, PdfContentByte.ALIGN_CENTER);
////////////////////////////                }
////////////////////////////                break;
////////////////////////////            default:
////////////////////////////                doLine(cb, document.left(), document.top() + hl * 3, document.right(), document.top() + hl * 3, 0.5F, baseColor);
////////////////////////////                doTexte(cb, document.right(), document.top() + hl * 3 + 2, enteteLFI, bfh, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                doLine(cb, document.left(), document.top() + hl * 2, document.left() - hl + 2 * w, document.top() + hl * 2, 0.5F, baseColor);
////////////////////////////                doTexte(cb, document.left(), document.top() + hl * 2 + 2, enteteHeaderGauche, bfh, PdfContentByte.ALIGN_LEFT);
////////////////////////////                doLine(cb, document.left() - hl + 2 * w, document.top() + hl * 2, document.left() + 2 * w, document.top() + hl, 0.5F, baseColor);
////////////////////////////                doTexte(cb, document.left() + 2.5F * w, document.top() + hl + 2, typeRapport, bfh, PdfContentByte.ALIGN_CENTER);
////////////////////////////                doLine(cb, document.left() + 2 * w, document.top() + hl, document.right(), document.top() + hl, 0.5F, baseColor);
////////////////////////////        }
////////////////////////////    }
////////////////////////////
////////////////////////////    private void addPageFooter(PdfContentByte cb, Document document, Font bff, float hl) {
////////////////////////////        switch (style) {
////////////////////////////            case style_PageOppositeSame:
////////////////////////////                if (getCurrentPage() % 2 == 0 || printRecto) {
////////////////////////////                    // PAGE A GAUCHE)
////////////////////////////                    doLine(cb, document.left(), document.bottom() - 4, document.right(), document.bottom() - 4, 0.5F, baseColor);
////////////////////////////                    //doLine(cb, (document.left() + document.right()) / 2, document.bottom() - 4, document.right() + document.rightMargin(), document.bottom() - 4, 0.5F, baseColor);
////////////////////////////                    ////doTexte(cb, document.right(), document.bottom() - hl, String.valueOf(getPageNumber(document)), bff, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doTexte(cb, document.left(), document.bottom() - hl, piedSame, bff, PdfContentByte.ALIGN_LEFT);
////////////////////////////                } else {
////////////////////////////                    // PAGE DE DROITE
////////////////////////////                    doLine(cb, document.left(), document.bottom() - 4, document.right(), document.bottom() - 4, 0.5F, baseColor);
////////////////////////////                    //doTexte(cb, document.right(), document.bottom() - hl, String.valueOf(getPageNumber(document)), bff, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doTexte(cb, document.right(), document.bottom() - hl, piedSame, bff, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                }
////////////////////////////                break;
////////////////////////////            case style_PageOpposite:
////////////////////////////            default:
////////////////////////////                if (getCurrentPage() % 2 == 0 || printRecto) {
////////////////////////////                    // PAGE A GAUCHE)
////////////////////////////                    doLine(cb, document.left(), document.bottom() - 4, document.right() + document.rightMargin(), document.bottom() - 4, 0.5F, baseColor);
////////////////////////////                    //doLine(cb, (document.left() + document.right()) / 2, document.bottom() - 4, document.right() + document.rightMargin(), document.bottom() - 4, 0.5F, baseColor);
////////////////////////////                    ////doTexte(cb, document.right(), document.bottom() - hl, String.valueOf(getPageNumber(document)), bff, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doTexte(cb, document.left(), document.bottom() - hl, chapitre.getTblChapitrePK().getChCodeChapitre() + " - " + chapitre.getChLibelle(), bff, PdfContentByte.ALIGN_LEFT);
////////////////////////////                } else {
////////////////////////////                    // PAGE DE DROITE
////////////////////////////                    float l = getLen(enteteLFI + "/" + typeRapport, bff);
////////////////////////////                    doLine(cb, 0, document.bottom() - 4, document.left() + l + 5, document.bottom() - 4, 0.5F, baseColor);
////////////////////////////                    //doTexte(cb, document.right(), document.bottom() - hl, String.valueOf(getPageNumber(document)), bff, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                    doTexte(cb, document.left() + l + 5, document.bottom() - hl, enteteLFI + "/" + typeRapport, bff, PdfContentByte.ALIGN_RIGHT);
////////////////////////////                }
////////////////////////////        }
////////////////////////////    }
////////////////////////////
////////////////////////////    @Override
////////////////////////////    public void onGenericTag(PdfWriter writer, Document document, Rectangle rect, String text) {
////////////////////////////        switch (text) {
////////////////////////////            case "ellipse": {
////////////////////////////                PdfContentByte cb = writer.getDirectContent();
////////////////////////////                cb.setRGBColorStroke(0xFF, 0x00, 0x00);
////////////////////////////                cb.ellipse(rect.getLeft(), rect.getBottom() - 5f,
////////////////////////////                        rect.getRight(), rect.getTop());
////////////////////////////                cb.stroke();
////////////////////////////                cb.resetRGBColorStroke();
////////////////////////////                break;
////////////////////////////            }
////////////////////////////            case "box": {
////////////////////////////                PdfContentByte cb = writer.getDirectContentUnder();
////////////////////////////                rect.setBackgroundColor(new BaseColor(0xa5, 0x2a, 0x2a));
////////////////////////////                cb.rectangle(rect);
////////////////////////////                break;
////////////////////////////            }
////////////////////////////        }
////////////////////////////        addSommaire(text);
////////////////////////////    }
//    private Image pdfBGImage = null;
    private java.awt.Image bgImage;
    private String enteteLFI;
    private String typeRapport;
    private String enteteHeader;
    private String enteteHeaderH;
    private String enteteHeaderB;
    private boolean printHeader = false;
    private boolean printFooter = false;
    private boolean printBG = false;
    private BaseColor baseColor;
    private int startPage = 0;
    private int currentPage;
    private String baseFontName;
    private String baseFontNameBold;
    private Locale locale;
    private List<CleValeur> sommaires = new ArrayList<>();
    private List<Integer> updatePageInfo = new ArrayList<>();
//    private boolean printRecto=false;

    public int getCurrentPage(int startPage) {
        try {
            return startPage + currentPage;
        } catch (Exception e) {
            return startPage;
        }
    }

    public boolean updatePageInfo(int page) {
        if (updatePageInfo == null) {
            return false;
        }
        if (updatePageInfo.isEmpty()) {
            return false;
        }
        return updatePageInfo.contains(page);
    }

//    public List<Integer> getUpdatePageInfo() {
//        return updatePageInfo;
//    }
    public void addSommaire(String code) {
        sommaires.add(new CleValeur(code, String.valueOf(getCurrentPage()), ""));
    }

    public void addSommaire(String code, int decal) {
        sommaires.add(new CleValeur(code, String.valueOf(decal + getCurrentPage()), ""));
    }

    public List<CleValeur> getSommaires() {
        return sommaires;
    }

    public int getCurrentPage() {
        return getCurrentPage(startPage);
    }

    public void setPrintFooter(boolean printFooter) {
        this.printFooter = printFooter;
    }

    public void setPrintHeader(boolean printHeader) {
        this.printHeader = printHeader;
    }

    public void setPrintBG(boolean printBG) {
        this.printBG = printBG;
    }

    public boolean isPrintBGPage() {
        return printBG || printHeader || printFooter;
    }

//    public void setEnteteHeader(String enteteHeaderGauche, String enteteHeaderDroiteH, String enteteHeaderDroiteB) {
//        this.enteteHeaderGauche = enteteHeaderGauche;
//        this.enteteHeaderDroiteH = enteteHeaderDroiteH;
//        this.enteteHeaderDroiteB = enteteHeaderDroiteB;
//    }
    public void setTextForHeader(String entete) {
        this.enteteHeader = entete;
    }

    public Image getBackGroundImage(PdfWriter writer, Document document) {
//        if (pdfBGImage == null) {
        try {
            PdfContentByte byte1 = new PdfContentByte(writer);
            Image pdfBGImage = Image.getInstance(byte1, bgImage, 1);
            float x, y, w, h;
            if (pdfBGImage.getWidth() < pdfBGImage.getHeight()) {
                // image en portrait
                x = document.left();
                y = document.bottom();
                w = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
                h = document.getPageSize().getHeight();
            } else {
                // image en paysage
                x = document.left();
                y = document.bottom();
                w = document.getPageSize().getWidth() - document.leftMargin() - document.rightMargin();
                h = w * (pdfBGImage.getHeight() / pdfBGImage.getWidth());
                y = (document.getPageSize().getHeight() - h) / 2;
            }
            pdfBGImage.setAbsolutePosition(x, y);
            pdfBGImage.scaleToFit(w, h);
            pdfBGImage.setBorderWidth(1);
            pdfBGImage.setScaleToFitHeight(true);
            return pdfBGImage;
        } catch (Exception ex) {
            printBG = false;
            return null;
        }
//        }

    }

    public static Image getItextImage(PdfWriter writer, java.awt.Image awt) {
        ImageIcon c = new ImageIcon(awt);
        return getItextImage(writer, awt, c.getIconWidth(), c.getIconHeight());
    }

    public static Image getItextImage(PdfWriter writer, java.awt.Image awt, float width, float height) {
        Image itextImage = null;
        try {
            PdfContentByte byte1 = new PdfContentByte(writer);
            itextImage = Image.getInstance(byte1, awt, 1);
            itextImage.scaleAbsolute(width, height);
        } catch (Exception ex) {
        }
        return itextImage;
    }

    public static Image getItextImage(PdfWriter writer, java.awt.Image awt, float percent) {
        Image itextImage = null;
        try {
            PdfContentByte byte1 = new PdfContentByte(writer);
            itextImage = Image.getInstance(byte1, awt, 1);
            itextImage.scalePercent(percent);
//            itextImage.setScaleToFitHeight(true);
        } catch (Exception ex) {
        }
        return itextImage;
    }

    public GrecoPdfPageEventHelper(String enteteLFI, String typeRapport,
            java.awt.Image bgImage, String baseFontName, String baseFontNameBold, Locale locale, BaseColor baseColor) {
        this.bgImage = bgImage;
//        this.chapitre = chapitre;
        this.enteteLFI = enteteLFI;
        this.typeRapport = typeRapport;
        this.baseFontName = baseFontName;
        this.baseFontNameBold = baseFontNameBold;
        this.locale = locale;
        this.baseColor = baseColor;
    }

    public static void doRectangle(PdfContentByte cb, Rectangle rect, float lineWidth, BaseColor color) {
//        float aj = lineWidth / 2;
//        doLine(cb, rect.getLeft() - aj, rect.getTop(), rect.getRight() + aj, rect.getTop(), lineWidth, color);
//        doLine(cb, rect.getRight(), rect.getTop(), rect.getRight(), rect.getBottom(), lineWidth, color);
//        doLine(cb, rect.getRight() + aj, rect.getBottom(), rect.getLeft() - aj, rect.getBottom(), lineWidth, color);
//        doLine(cb, rect.getLeft(), rect.getBottom(), rect.getLeft(), rect.getTop(), lineWidth, color);
        rect.setBorder(Rectangle.BOX);
        rect.setBorderWidth(lineWidth);
        rect.setBorderColor(color);
        cb.rectangle(rect);
    }

    public static void doRectangle(PdfContentByte cb, Rectangle rect, float lineWidth, BaseColor color, BaseColor fill) {
//        doRectangle(cb, rect, lineWidth, color);
//        cb.moveTo((rect.getLeft() + rect.getRight()) / 2, (rect.getTop() + rect.getBottom()) / 2);
        //cb.circle((rect.getLeft() + rect.getRight()) / 2, (rect.getTop() + rect.getBottom()) / 2, 10);
        rect.setBorder(Rectangle.BOX);
        rect.setBorderWidth(lineWidth);
        rect.setBorderColor(color);
        rect.setBackgroundColor(fill);
        cb.rectangle(rect);
    }

    public static void doLine(PdfContentByte cb, float x1, float y1, float x2, float y2, float lineWidth, BaseColor color) {
        cb.resetRGBColorStroke();
        cb.setColorStroke(color);
        cb.setLineWidth(lineWidth);
        cb.moveTo(x1, y1);
        cb.lineTo(x2, y2);
        cb.stroke();
    }

    public static void doCircle(PdfContentByte cb, float x, float y, BaseColor color) {
        cb.resetRGBColorStroke();
        cb.setColorStroke(color);
        cb.circle(x, y, 10);
        cb.stroke();
    }

    public static void doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth, int forceNumberOfLigne) {
        doTexte(cb, x, y, texte, f, align, hLigne, maxWidth, false, forceNumberOfLigne);
    }

    public static void doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth) {
        doTexte(cb, x, y, texte, f, align, hLigne, maxWidth, false, -1);
    }

//////////////////////    public static void doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth, boolean inverseTexte) {
//////////////////////        cb.setColorFill(f.getColor());
//////////////////////        cb.setFontAndSize(f.getBaseFont(), f.getSize());
//////////////////////        Chunk c = new Chunk(texte, f);
//////////////////////        float w = c.getWidthPoint();
//////////////////////        if (w < maxWidth) {
//////////////////////            doTexte(cb, x, y, texte, f, align);
//////////////////////        } else {
//////////////////////            List<String> l = Arrays.asList(texte.split(" "));
//////////////////////
//////////////////////            String str = "";
//////////////////////            List<String> textes = new ArrayList<>();
//////////////////////            if (inverseTexte) {
//////////////////////                for (int i = l.size(); i > 0; i--) {
//////////////////////                    String s = l.get(i - 1);
//////////////////////                    c = new Chunk(s + " " + str, f);
//////////////////////                    if (c.getWidthPoint() > maxWidth) {
//////////////////////                        textes.add(str);
//////////////////////                        str = s;
//////////////////////                    } else {
//////////////////////                        str = s + " " + str;
//////////////////////                    }
//////////////////////                }
//////////////////////            } else {
//////////////////////                for (String s : l) {
//////////////////////                    c = new Chunk(str + " " + s, f);
//////////////////////                    if (c.getWidthPoint() > maxWidth) {
//////////////////////                        textes.add(str);
//////////////////////                        str = s;
//////////////////////                    } else {
//////////////////////                        str += " " + s;
//////////////////////                    }
//////////////////////                }
//////////////////////            }
//////////////////////            if (!str.isEmpty()) {
//////////////////////                textes.add(str);
//////////////////////            }
//////////////////////            doTextes(cb, x, y, textes, f, align, hLigne);
//////////////////////        }
//////////////////////    }
    public static int doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float hLigne, float maxWidth, boolean inverseTexte, int forceNumberOfLigne) {
        cb.setColorFill(f.getColor());
        cb.setFontAndSize(f.getBaseFont(), f.getSize());
        Chunk c = new Chunk(texte, f);
        float w = c.getWidthPoint();
        int nbLigne = 1;
        if (w < maxWidth) {
            doTexte(cb, x, y, texte, f, align);
        } else {
            List<String> l = Arrays.asList(texte.split(" "));

            String str = "";
            List<String> textes = new ArrayList<>();
            if (inverseTexte) {
                for (int i = l.size(); i > 0; i--) {
                    String s = l.get(i - 1);
                    c = new Chunk(s + " " + str, f);
                    if (c.getWidthPoint() > maxWidth) {
                        if (!str.isEmpty()) {
                            textes.add(str);
                        }

                        str = s;
                    } else {
                        str = s + " " + str;
                    }
                }
            } else {
                for (String s : l) {
                    c = new Chunk(str + " " + s, f);
                    if (c.getWidthPoint() > maxWidth) {
                        textes.add(str);
                        str = s;
                    } else {
                        str += " " + s;
                    }
                }
            }
            if (!str.isEmpty()) {
                textes.add(str);
            }
            if (inverseTexte && hLigne < 0) {
                String tmp;
                int s = textes.size();
                for (int i = 0; i < s / 2; i++) {
                    tmp = textes.get(i);
                    textes.set(i, textes.get(s - i - 1));
                    textes.set(s - i - 1, tmp);
                }
            }
            if (forceNumberOfLigne > 0) {
                while (textes.size() > forceNumberOfLigne) {
                    textes.remove(textes.size() - 1);
                }
                textes.set(textes.size() - 1, textes.get(textes.size() - 1).concat("..."));
            }
            nbLigne = textes.size();
            doTextes(cb, x, y, textes, f, align, hLigne);
        }
        return nbLigne;
    }

    public static float getLen(String texte, Font f) {
        try {
            return new Chunk(texte, f).getWidthPoint();
        } catch (Exception e) {
            return 0;
        }
    }

    public static float doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align) {
        cb.beginText();
        float w = new Chunk(texte, f).getWidthPoint();
        cb.setColorFill(f.getColor());
        cb.setFontAndSize(f.getBaseFont(), f.getSize());
        cb.showTextAligned(align, texte.trim(), x, y, 0);
        cb.endText();
        return w;
    }

    public static float doTexte(PdfContentByte cb, float x, float y, String texte, Font f, int align, float underLineWidth) {
        cb.beginText();
        cb.setColorFill(f.getColor());
        cb.setFontAndSize(f.getBaseFont(), f.getSize());
        cb.showTextAligned(align, texte.trim(), x, y, 0);
        cb.endText();
        float w = new Chunk(texte, f).getWidthPoint();
        switch (align) {
            case PdfContentByte.ALIGN_LEFT:
                doLine(cb, x, y - 2, x + w, y - 2, underLineWidth, f.getColor());
                break;
            case PdfContentByte.ALIGN_CENTER:
                doLine(cb, x - w / 2, y - 2, x + w / 2, y - 2, underLineWidth, f.getColor());
                break;
            case PdfContentByte.ALIGN_RIGHT:
                doLine(cb, x - w, y - 2, x, y - 2, underLineWidth, f.getColor());
                break;
            default:
        }
        return w;
    }

    public static void doTextes(PdfContentByte cb, float x, float y, List<String> array, Font f, int align, float hLigne) {
        cb.beginText();
        cb.setColorFill(f.getColor());
        cb.setFontAndSize(f.getBaseFont(), f.getSize());
        cb.showTextAligned(align, array.get(0).trim(), x, y, 0);
        array.remove(0);
        int i = 1;
        for (String str : array) {
            //cb.moveTextWithLeading(0, hLigne);
            //cb.showText(str);
            cb.showTextAligned(align, str.trim(), x, y + (i++) * hLigne, 0);
        }
        cb.endText();
    }

    @Override
    public void onStartPage(PdfWriter writer, Document document) {
        currentPage = document.getPageNumber();
        PdfContentByte cb = writer.getDirectContentUnder();
        try {
            if (printBG) {
                cb.addImage(getBackGroundImage(writer, document));
            }
        } catch (Exception ex) {
//            ex.printStackTrace();
        }

        Font bfh = null;
        Font bff = null;
        Font bfhBold = null;
        try {
            bfh = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 8.5F, Font.NORMAL, BaseColor.BLACK);
            bfhBold = new Font(BaseFont.createFont(baseFontNameBold, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 11F, Font.NORMAL, BaseColor.BLACK);
            bff = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.NOT_EMBEDDED), 6F, Font.NORMAL, BaseColor.BLACK);
        } catch (Exception ex) {
//            ex.printStackTrace();
        }

        float w = (document.right() - document.left()) / 5;
        float hl = 13;
        // Header Page
        if (printHeader) {
            addPageHeader(cb, document, bfhBold, bfh, w, hl, hl - 4);
        }
        // Footer page
        if (printFooter) {
            addPageFooter(cb, document, bff, hl);
        }
        if (printHeader || printFooter) {
            updatePageInfo.add(currentPage);
        }
    }

    private void addPageHeader(PdfContentByte cb, Document document, Font bfhBold, Font bfh, float w, float hl1, float hl2) {

        doLine(cb, document.left(), document.top() + hl2 * 2 + hl1, document.right(), document.top() + hl2 * 2 + hl1, 0.5F, BaseColor.BLACK);
        doTexte(cb, document.right(), document.top() + hl2 * 2 + hl1 + 2, enteteLFI, bfh, PdfContentByte.ALIGN_RIGHT);
        doLine(cb, document.left(), document.top() + hl2 * 2, document.left() - hl2 + 3 * w, document.top() + hl2 * 2, 0.5F, BaseColor.BLACK);
        doTexte(cb, document.left(), document.top() + hl2 * 2 + 2, enteteHeader, bfhBold, PdfContentByte.ALIGN_LEFT, hl1, document.right() - document.left(), 1);
        doLine(cb, document.left() - hl2 + 3 * w, document.top() + hl2 * 2, document.left() + 3 * w, document.top() + hl2, 0.5F, BaseColor.BLACK);
        doTexte(cb, document.left() + 4F * w, document.top() + hl2 + 2, typeRapport, bfh, PdfContentByte.ALIGN_CENTER);
        doLine(cb, document.left() + 3 * w, document.top() + hl2, document.right(), document.top() + hl2, 0.5F, BaseColor.BLACK);
    }

    private void addPageFooter(PdfContentByte cb, Document document, Font bff, float hl) {
        doLine(cb, document.left(), document.bottom() - 6, document.right(), document.bottom() - 6, 0.5F, BaseColor.BLACK);
        //doLine(cb, (document.left() + document.right()) / 2, document.bottom() - 4, document.right() + document.rightMargin(), document.bottom() - 4, 0.5F, baseColor);
        /*Cette ligne est mise à jour dans la finalisation du document pour avoir page X/Y*/
        //        doTexte(cb, document.right(), document.bottom() - hl, String.valueOf(currentPage), bff, PdfContentByte.ALIGN_RIGHT);
////////        doTexte(cb, document.left(), document.bottom() - hl, CdmtLangue.texte(CdmtLangue.CHAPITRE, locale) + " " + chapitre.getTblChapitrePK().getChCodeChapitre() + " " + chapitre.getChLibelle(), bff, PdfContentByte.ALIGN_LEFT);
    }

    @Override
    public void onGenericTag(PdfWriter writer, Document document, Rectangle rect, String text) {
        if (text.equals("ACTION")) {
            PdfContentByte cb = writer.getDirectContentUnder();
            cb.saveState();
            float x1 = rect.getLeft() - 4;
            float y1 = rect.getBottom() - 4;
            float w = rect.getWidth() + 8;
            float h = rect.getHeight() + 4;
            float x2 = x1 + 1.5F * w;
            float y2 = y1 + 2 * h;

            PdfShading axial = PdfShading.simpleAxial(writer, x1, y1, x2, y2, baseColor, BaseColor.YELLOW);// new BaseColor(251, 102, 19));
//            cb.circle(x1, y1, 3);
//            cb.stroke();
//            cb.circle(x2, y2, 3);
//            cb.stroke();
            PdfShadingPattern axialPattern = new PdfShadingPattern(axial);
            cb.setShadingFill(axialPattern);
            cb.setColorStroke(new GrayColor(0.8f));
            ShadingColor axialColor = new ShadingColor(axialPattern);
            cb.setColorFill(axialColor);
//            cb.setRGBColorFill(155, 20, 47);
//            cb.circle(rect.getLeft() - 4, rect.getBottom() - 4, 20);
            cb.roundRectangle(x1, y1, w, h, 4);
            cb.fillStroke();
            cb.restoreState();
        } else {
            if (!text.equals("TITRE")) {
                addSommaire(text);
            }
            PdfContentByte cb = writer.getDirectContentUnder();
            cb.saveState();
            PdfShading axial = PdfShading.simpleAxial(writer,
                    36, 716, 396, 788, baseColor, new BaseColor(251, 102, 19));
            PdfShadingPattern axialPattern = new PdfShadingPattern(axial);
            cb.setShadingFill(axialPattern);
            cb.roundRectangle(rect.getLeft() - 15, rect.getBottom() + 2, 10, 4, 0);
            cb.fill();
            cb.restoreState();
        }
    }

    public static List<String> getListeTexte(PdfContentByte cb, String texte, Font f, float maxWidth, boolean inverseTexte) {
        cb.setColorFill(f.getColor());
        cb.setFontAndSize(f.getBaseFont(), f.getSize());
        Chunk c = new Chunk(texte, f);
        float w = c.getWidthPoint();
        List<String> ls = new ArrayList<>();
        if (w < maxWidth) {
            ls.add(texte);
        } else {
            List<String> l = Arrays.asList(texte.split(" "));

            String str = "";
            List<String> textes = new ArrayList<>();
            if (inverseTexte) {
                for (int i = l.size(); i > 0; i--) {
                    String s = l.get(i - 1);
                    c = new Chunk(s + " " + str, f);
                    if (c.getWidthPoint() > maxWidth) {
                        if (!str.isEmpty()) {
                            textes.add(str);
                        }

                        str = s;
                    } else {
                        str = s + " " + str;
                    }
                }
            } else {
                for (String s : l) {
                    c = new Chunk(str + " " + s, f);
                    if (c.getWidthPoint() > maxWidth) {
                        textes.add(str);
                        str = s;
                    } else {
                        str += " " + s;
                    }
                }
            }
            if (!str.isEmpty()) {
                textes.add(str);
            }
            if (inverseTexte) {
                String tmp;
                int s = textes.size();
                for (int i = 0; i < s / 2; i++) {
                    tmp = textes.get(i);
                    textes.set(i, textes.get(s - i - 1));
                    textes.set(s - i - 1, tmp);
                }
            }
            if (!textes.isEmpty()) {
                ls.addAll(textes);
            }
        }
        return ls;
    }
}