/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp;

/**
 *
 * @author DGLS
 */
public class DocumentProduction {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Apercu ap = new dp.Apercu();
        ap.setVisible(true);
    }
}
