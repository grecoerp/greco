/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp;

import com.siicore.util.StringUtil;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author macbookair
 */
public class GrecoDocNode extends DefaultMutableTreeNode {

    public static int NODE_NO_TYPE = 0; // ne rien afficher 1
    public static int NODE_ROOT_CDMT = 0; // afficher a droite le chapitre et le titre rapport annuel de performance 2
    // ou afficher les noeuds sous forme d'icone cliquables
    public static int NODE_TEXTE = 2; // afficher a droite l'editeur de texte 3
    //
    public static final String INTRODUCTION = "INTRODUCTION";
    //
    public static final String CHAPITRE_1 = "CHAPITRE_1";
    public static final String SECTION_11 = "SECTION_11";
    public static final String PARAGRAPHE_111 = "PARAGRAPHE_111";
    public static final String PARAGRAPHE_112 = "PARAGRAPHE_112";
    public static final String PARAGRAPHE_113 = "PARAGRAPHE_113";
    public static final String SECTION_12 = "SECTION_12";
//    public static final String PARAGRAPHE_121 = "PARAGRAPHE_121";
//    public static final String PARAGRAPHE_122 = "PARAGRAPHE_122";
    //
    public static final String CHAPITRE_2 = "CHAPITRE_2";
    public static final String SECTION_21 = "SECTION_21";
    public static final String PARAGRAPHE_211 = "PARAGRAPHE_211";
    public static final String PARAGRAPHE_212 = "PARAGRAPHE_212";
    public static final String PARAGRAPHE_213 = "PARAGRAPHE_213";
    public static final String SECTION_22 = "SECTION_22";
    public static final String PARAGRAPHE_221 = "PARAGRAPHE_221";
    public static final String PARAGRAPHE_222 = "PARAGRAPHE_222";
    public static final String PARAGRAPHE_223 = "PARAGRAPHE_223";
    public static final String SECTION_23 = "SECTION_23";
    public static final String PARAGRAPHE_231 = "PARAGRAPHE_231";
    public static final String PARAGRAPHE_232 = "PARAGRAPHE_232";
    //
    public static final String CHAPITRE_3 = "CHAPITRE_3";
    public static final String SECTION_31 = "SECTION_31";
    public static final String SECTION_32 = "SECTION_32";
    public static final String SECTION_33 = "SECTION_33";
//    public static final String SECTION_34 = "SECTION_34";
//    public static final String SECTION_35 = "SECTION_35";
//    public static final String SECTION_36 = "SECTION_36";
//    public static final String SECTION_37 = "SECTION_37";
    //
    public static final String CHAPITRE_4 = "CHAPITRE_4";
    public static final String SECTION_41 = "SECTION_41";
    public static final String SECTION_42 = "SECTION_42";
    public static final String SECTION_43 = "SECTION_43";
    //
    private String id;
    private String libelle;
    private String titreSection;
    private int typeContent;
    private int niveau;
    //

    public GrecoDocNode() {
        this(null, "", NODE_NO_TYPE, 0, "");
    }

    public GrecoDocNode(String id, String titre, int type, int niveau, String libelle) {
        this.id = id;
        this.titreSection = titre;
        this.typeContent = type;
        this.niveau = niveau;
        this.libelle = libelle;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLibelle() {
        return StringUtil.emptyIfNull(libelle);
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getNiveau() {
        return niveau;
    }

    public void setNiveau(int niveau) {
        this.niveau = niveau;
    }

    public int getTypeContent() {
        return typeContent;
    }

    public void setTypeContent(int type) {
        this.typeContent = type;
    }

    public String toString() {
        return libelle;
    }

    public String getTitreSection() {
        return titreSection;
    }

    public void setTitreSection(String titreSection) {
        this.titreSection = titreSection;
    }
}
