/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.html.simpleparser.HTMLWorker;
import com.itextpdf.text.html.simpleparser.StyleSheet;
import com.itextpdf.text.pdf.BaseFont;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfCopy;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.PdfStamper;
import com.itextpdf.text.pdf.PdfWriter;
import com.itextpdf.tool.xml.XMLWorkerHelper;
import com.siicore.cls.CleValeur;
import com.siicore.component.InfiniteProgressPanel;
import com.siicore.util.MessageUI;
import com.siicore.util.StringUtil;
import com.siicore.util.WRapport;
import dp.entities.GrecoDocument;
import dp.imgresources.ImageLoader;
import java.awt.Desktop;
import java.awt.Image;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.io.StringReader;
import java.math.BigDecimal;
import java.nio.charset.Charset;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import net.sf.jasperreports.engine.JasperExportManager;
import net.sf.jasperreports.engine.JasperPrint;

/**
 *
 * @author Christian WAM
 */
public class GrecoGeneratePdf {

    int anneeDeb;
    int anneeFin;
    private String enteteLFI;
    private String enteteHeaderGauche;
    private String enteteHeaderDroiteH;
    private String enteteHeaderDroiteB;
    private java.awt.Image bgImage;
    private String baseFontName;
    private String baseFontNameBold;
    private String baseFontNameNarrow;
    private String baseFontNameNarrowBold;
//    private Font f1;
//    private Font f2;
//    private Font f3;
    private Font aBig22;
    private Font aBold22;
    private Font aBold12;
    private Font aNormal12U;
    private Font aBold11;
    private static Font aNormal11;
    private Font aBold10;
    private Font aBold9;
    private Font aBold9U;
    private Font aBold8;
    private Font aNormal10;
    private Font aNormal9;
    private Font aNormal8;
    private Font aNormal6;
    private Font aNarrow7;
    private Font aNarrow8;
    private Font aNarrow9;
    private Font aNarrowB9;
    private Font obFont;
    private Locale locale;
    private static final float spaceBefore = 15;
//    private java.awt.Image armoirie;
    private InfiniteProgressPanel glassPane;
    private int progress = 1;
    private static WRapport rapport;
    private boolean isDraft;
    //
    private int unite = 1;

    //
   ImageLoader mesImages = new ImageLoader();
    //
//    private boolean printRecto;
    private static boolean useHtmlWorker = true;
//    private boolean printCoverBgImage = true;
    //
//    private BaseColor colChap = new BaseColor(192, 80, 77);
    private BaseColor colCdmt = new BaseColor(112, 146, 190);//140, 215, 60);//155, 187, 89);
    private GrecoDocument cdmt;
    private String glassText;
    //
////////    ReportElab reportElab = new ReportElab();
////////    ReportsPrepa reportsPrepa = new ReportsPrepa();
    Image pyramide = null;// new Images().pyramide();
    //
////////    List<VuePSFECadreLogique> cadreLogiques = new ArrayList<>();
////////    List<PrepaProgramme> programmes = new ArrayList<>();
////////    HashMap<String, List<PrepaAction>> mapActions = new HashMap<>();
    HashMap<String, Integer> nbIndParAction = new HashMap<>();
    HashMap<String, Integer> nbIndParObjectif = new HashMap<>();
////////    HashMap<String, List<PrepaProgramme>> mapProgrammes = new HashMap<>();
    HashMap<String, Integer> nbIndParProgramme = new HashMap<>();
    HashMap<String, Integer> nbIndParObjectifProgramme = new HashMap<>();

    private static final float defaultCellMinHeight = 20;

    private void initFont() {
        try {
            aBig22 = new Font(BaseFont.createFont(baseFontNameBold, BaseFont.CP1252, BaseFont.EMBEDDED), 22, Font.BOLD, BaseColor.BLACK);
            aBold22 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 22, Font.BOLD, BaseColor.BLACK);

            aBold12 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 12, Font.BOLD, BaseColor.BLACK);
            aNormal12U = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 12, Font.NORMAL + Font.UNDERLINE, BaseColor.BLACK);

            aBold11 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 11, Font.BOLD, BaseColor.BLACK);
            aNormal11 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 11, Font.NORMAL, BaseColor.BLACK);

            aBold10 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 10, Font.BOLD, BaseColor.BLACK);
            aBold9 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 9, Font.BOLD, BaseColor.BLACK);
            aBold9U = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 9, Font.BOLD + Font.UNDERLINE, BaseColor.BLACK);
            aBold8 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 8, Font.BOLD, BaseColor.BLACK);

            aNormal10 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 10, Font.NORMAL, BaseColor.BLACK);
            aNormal9 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 9, Font.NORMAL, BaseColor.BLACK);
            aNormal8 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 8, Font.NORMAL, BaseColor.BLACK);
            aNormal6 = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 6, Font.NORMAL, BaseColor.BLACK);

            aNarrow7 = new Font(BaseFont.createFont(baseFontNameNarrow, BaseFont.CP1252, BaseFont.EMBEDDED), 7, Font.NORMAL, BaseColor.BLACK);
            aNarrow8 = new Font(BaseFont.createFont(baseFontNameNarrow, BaseFont.CP1252, BaseFont.EMBEDDED), 8, Font.NORMAL, BaseColor.BLACK);
            aNarrow9 = new Font(BaseFont.createFont(baseFontNameNarrow, BaseFont.CP1252, BaseFont.EMBEDDED), 9, Font.NORMAL, BaseColor.BLACK);

            aNarrowB9 = new Font(BaseFont.createFont(baseFontNameNarrow, BaseFont.CP1252, BaseFont.EMBEDDED), 9, Font.BOLD, BaseColor.BLACK);

            obFont = new Font(aBold11);
            obFont.setColor(colCdmt);

        } catch (Exception exception) {
        }
    }

    public GrecoGeneratePdf(Locale locale, int anneeDeb, int anneeFin,
            String enteteLFI, String enteteHeaderGauche, String enteteHeaderDroiteH, String enteteHeaderDroiteB,
            java.awt.Image bgImage, int startPage, 
            String baseFontName, String baseFontNameBold, String baseFontNameNarrow, String baseFontNameNarrowBold,
            InfiniteProgressPanel glassPane, boolean isDraft) {
        cdmt = new GrecoDocument();
        this.locale = locale;
////////        this.chapitre = chapitre;
        
        //donnees par defaut pour les texte 
        /***********************/
        cdmt.setIntro(locale, "La loi portant Regime Financier de l'Etat a instituee le Budget Programme comme mode de gestion axee sur les resultats avec une emphase");
        cdmt.setChapitre1(locale, "chapitre I, premiere partie introduit un ensemble de grands concepts ");
        cdmt.setParagraphe111(locale, "Paragraphe 111 rempli ici pour faire apparaitre le 1.1.1 dans le document. Cest son contenu qui est ici");
        this.anneeDeb = anneeDeb;
        this.anneeFin = anneeFin;
        this.enteteLFI = enteteLFI;
        this.enteteHeaderGauche = enteteHeaderGauche;
        this.enteteHeaderDroiteH = enteteHeaderDroiteH;
        this.enteteHeaderDroiteB = enteteHeaderDroiteB;
        this.bgImage = bgImage;
        this.baseFontName = baseFontName;
        this.baseFontNameBold = baseFontNameBold;
        this.baseFontNameNarrow = baseFontNameNarrow;
        this.baseFontNameNarrowBold = baseFontNameNarrowBold;
        initFont();
        this.glassPane = glassPane;
        glassText = "";
        if (glassPane != null) {
            glassText = glassPane.getText();
        }
        this.isDraft = isDraft;
//        programmes.clear();
//        programmes.addAll(PrepaServiceFactory.getDestinationService().getProgrammesFull(chapitre.getTblChapitrePK()));
    }

    private void doProgress() {
        if (glassPane != null) {
            glassPane.setText(glassText + " " + (progress < 100 ? progress++ : 100) + "%");
        } else {
            System.out.println(glassText + " " + (progress < 100 ? progress++ : 100) + "%");
        }
    }


    private String getTexte(String key) {
        return GrecoLangue.texte(key, locale).replace("{ANNEE_N-3}", String.valueOf(anneeDeb - 3)).replace("{ANNEE_N-2}", String.valueOf(anneeDeb - 2)).replace("{ANNEE_N-1}", String.valueOf(anneeDeb - 1)).replace("{ANNEE_N}", String.valueOf(anneeDeb)).replace("{ANNEE_N+1}", String.valueOf(anneeDeb + 1)).replace("{ANNEE_N+2}", String.valueOf(anneeDeb + 2)).replace("{ANNEE_N+3}", String.valueOf(anneeDeb + 3));
    }

    public void exportReport(JFrame parent, JasperPrint couverture, boolean inMultiPrint, String fName) {
        // Document document = new Document(PageSize.A4, 36, 72, 108, 180);
        // 28pts = 1cm
        // 42pts = 1.5cm
        // 70pts = 2.5cm
        Rectangle pagesize = new Rectangle(PageSize.A4);
        
        /******* DOCUMENT A4 avec les marges de gauche, droite, haut et bas *******/
        Document pdf = new Document(pagesize, 42, 42, 52, 28); //Old 70

        try {
            File fich = File.createTempFile("greco", "cdmt");
            String tmppath = fich.getParentFile().getPath();

            PdfWriter writer = PdfWriter.getInstance(pdf, new FileOutputStream(tmppath + "/HtmlTransformed.pdf"));
            GrecoPdfPageEventHelper eventHelper = new GrecoPdfPageEventHelper(enteteLFI, getTexte(GrecoLangue.CDMT), null, baseFontNameNarrow, baseFontNameNarrowBold, locale, colCdmt);
            writer.setPageEvent(eventHelper);
            writer.setLinearPageMode();
            pdf.open();
            doProgress();
            pdf.addTitle(getTexte(GrecoLangue.CDMT) + " " + anneeDeb + "-" + anneeFin);
////////            pdf.addSubject(chapitre.getAbreviationWithCode());
            pdf.addCreator("GRECO");
            pdf.addAuthor("FST");

            // DEBUT DOCUMENT
            addPageDeGarde(eventHelper, pdf, writer, baseFontName);
            doProgress();
            addSommaire(null, eventHelper, pdf, writer, true);
            int nbPageSommaire = eventHelper.getCurrentPage();
            doProgress();
            addIntroduction(eventHelper, pdf, writer, fich);
            doProgress();
            addChapitre1(eventHelper, pdf, writer, fich);
            doProgress();
            addChapitre2(eventHelper, pdf, writer, fich);
            doProgress();
            addChapitre3(eventHelper, pdf, writer, fich);
            doProgress();
            addChapitre4(eventHelper, pdf, writer, fich);
            doProgress();

            // FIN DOCUMENT
            List sommaires = eventHelper.getSommaires();

            float right = pdf.right();
            float bottom = pdf.bottom();

            pdf.close();
            writer.close();
            doProgress();

            PdfReader pdfReader = null;
            pdfReader = new PdfReader(tmppath + "/HtmlTransformed.pdf");
            PdfStamper stamper = new PdfStamper(pdfReader, new FileOutputStream(tmppath + "/HtmlTransformed2.pdf"));
//            Image img = Image.getInstance("watermark.jpg");
//            img.setAbsolutePosition(200, 400);
            PdfContentByte under;
            float hl = 13;
            Font bff = new Font(BaseFont.createFont(baseFontName, BaseFont.CP1252, BaseFont.EMBEDDED), 6, Font.NORMAL, BaseColor.BLACK);

            int total = pdfReader.getNumberOfPages() + 1;
            for (int i = 1; i < total; i++) {
                try {
                    under = stamper.getUnderContent(i);
                    if (eventHelper.updatePageInfo(i)) {
                        GrecoPdfPageEventHelper.doTexte(under, right, bottom - hl, "" + i /*+ "/" + totalPage*/, bff, PdfContentByte.ALIGN_RIGHT);
                    }
                } catch (Exception e) {
                }
            }
            stamper.close();
            pdfReader.close();
            doProgress();
            pdfReader = new PdfReader(tmppath + "/HtmlTransformed2.pdf");
            //reader.selectPages("o");
            int totalPage = pdfReader.getNumberOfPages();
            Document documentAnnexe = new Document();

            if (StringUtil.isNullOrEmpty(fName)) {
                fName = ""; ////PSFEApp.getPpaDir() + "/" + "cdmt" + "_" + chapitre.getTblChapitrePK().getChCodeChapitre() +/*+ annee +*/ "_" + (locale.equals(Locale.ENGLISH) ? "en" : "fr") /*+ "_" + chapitre.getAbreviationWithCode()*/ + ".pdf";
            }

////////            PdfCopy copyAnnexe = new PdfCopy(documentAnnexe, new FileOutputStream(tmppath + "/HtmlTransformed2Annexe.pdf"));
////////            documentAnnexe.open();
////////
////////            totalPage += copiePage(copyAnnexe, getTitlePage("5.1.", totalPage, getTexte(GrecoLangue.ANNEXE) + " 1", getTexte(GrecoLangue.ANNEXE_1)));
////////            sommaires.add(new CleValeur("5.1.", String.valueOf(totalPage - 1), ""));
////////            JasperPrint print = getMatriceCadreLogique(totalPage, getTexte(GrecoLangue.ANNEXE) + " 1");
////////            doProgress();
////////            totalPage += copiePage(copyAnnexe, JasperExportManager.exportReportToPdf(print));
////////
////////            totalPage += copiePage(copyAnnexe, getTitlePage("5.2.", totalPage, getTexte(GrecoLangue.ANNEXE) + " 2", getTexte(GrecoLangue.ANNEXE_2_PART1), getTexte(GrecoLangue.ANNEXE_2_PART2)));
////////            sommaires.add(new CleValeur("5.2.", String.valueOf(totalPage - 1), ""));
////////            print = getAnnexePrograFin("PG", totalPage, getTexte(GrecoLangue.ANNEXE_2_PART1) + "\n" + getTexte(GrecoLangue.ANNEXE_2_PART2), getTexte(GrecoLangue.ANNEXE) + " 2");
////////            doProgress();
////////            totalPage += copiePage(copyAnnexe, JasperExportManager.exportReportToPdf(print));
////////
////////            totalPage += copiePage(copyAnnexe, getTitlePage("5.3.", totalPage, getTexte(GrecoLangue.ANNEXE) + " 3", getTexte(GrecoLangue.ANNEXE_3_PART1), getTexte(GrecoLangue.ANNEXE_3_PART2)));
////////            sommaires.add(new CleValeur("5.3.", String.valueOf(totalPage - 1), ""));
////////            print = getAnnexePrograFin("AT", totalPage, getTexte(GrecoLangue.ANNEXE_3_PART1) + "\n" + getTexte(GrecoLangue.ANNEXE_3_PART2), getTexte(GrecoLangue.ANNEXE) + " 3");
////////            doProgress();
////////            totalPage += copiePage(copyAnnexe, JasperExportManager.exportReportToPdf(print));

//            totalPage += copiePage(copyAnnexe, getTitlePage("5.4.", totalPage, getTexte(GrecoLangue.ANNEXE) + " 4", getTexte(GrecoLangue.ANNEXE_4)));
//            sommaires.add(new CleValeur("5.4.", String.valueOf(totalPage - 1), ""));
//            print = getAnnexe(4, totalPage);
//            doProgress();
//            totalPage += copiePage(copyAnnexe, JasperExportManager.exportReportToPdf(print));
//
//            totalPage += copiePage(copyAnnexe, getTitlePage("5.5.", totalPage, getTexte(GrecoLangue.ANNEXE) + " 5", getTexte(GrecoLangue.ANNEXE_5)));
//            sommaires.add(new CleValeur("5.5.", String.valueOf(totalPage - 1), ""));
//            print = getAnnexe(5, totalPage);
//            doProgress();
//            totalPage += copiePage(copyAnnexe, JasperExportManager.exportReportToPdf(print));
//            totalPage += copiePage(copyAnnexe, getTitlePage("5.6.", totalPage, getTexte(GrecoLangue.ANNEXE) + " 6", getTexte(GrecoLangue.ANNEXE_6)));
//            sommaires.add(new CleValeur("5.6.", String.valueOf(totalPage - 1), ""));
//            print = getAnnexe(6, totalPage);
//            doProgress();
//            totalPage += copiePage(copyAnnexe, JasperExportManager.exportReportToPdf(print));
////////            documentAnnexe.close();
            Document document = new Document();
            //FINAL
            PdfCopy copy = new PdfCopy(document, new FileOutputStream(fName));
            document.open();
            document.addTitle(getTexte(GrecoLangue.CDMT) + " " + anneeDeb + "-" + anneeFin);
////////            document.addSubject(chapitre.getAbreviationWithCode());
            document.addCreator("PROBMIS");
            document.addAuthor("MINFI");
            if (couverture != null) {
                PdfReader rCouv = new PdfReader(JasperExportManager.exportReportToPdf(couverture));
                copy.addPage(copy.getImportedPage(rCouv, 1));
            }
            doProgress();

            //SOMMAIRE
            totalPage += copiePage(copy, getDocumentStart("SOMMAIR", sommaires), 2);
            doProgress();

            for (int i = nbPageSommaire - 1; i < pdfReader.getNumberOfPages(); i++) {
                copy.addPage(copy.getImportedPage(pdfReader, i + 1));
            }
////////            pdfReader = new PdfReader(tmppath + "/HtmlTransformed2Annexe.pdf");
////////            for (int i = 0; i < pdfReader.getNumberOfPages(); i++) {
////////                copy.addPage(copy.getImportedPage(pdfReader, i + 1));
////////            }
            document.close();
            copy.close();
            pdfReader.close();

            document.close();
            progress = 100;
            doProgress();
//
//            parseHtml(htmltexts, writer, document, fich);

            if (!inMultiPrint) {
                MessageUI.info(parent, "CDMT", "<html>Document généré:<p/><b>" + fName.replace("/", "\\") + "<b/></html>");
                try {
                    Desktop.getDesktop().open(new File(fName));
                } catch (Exception ex) {
//                if (MessageUI.question(parent, "", "Voulez-vous enregistrer le document généré?")) {
//                    WDirChooserDialog d = new WDirChooserDialog(parent, "Enregistrement du RAP", "Nom du fichier", fName);
//                    d.setVisible(true);
//                    String f = d.getDirName();
//                    if (!StringUtil.isNullOrEmpty(f)) {
//                        FileUtil.copy(fPath, f + fName);
//                    }
//                }
                }
                //openPdf("...", tmppath + "/HtmlTransformed.pdf");
            }
        } catch (Exception ex) {
               ex.printStackTrace();
        }
    }

    public static Paragraph getJustifiedParagraph(String texte, Font f, float spacing) {
        Paragraph p = new Paragraph(texte, f);
        p.setAlignment(Element.ALIGN_JUSTIFIED);
        p.setSpacingBefore(spacing);
        p.setSpacingAfter(spacing);
        return p;
    }

    private static String formatBgColor(String htmltext) {
        if (!htmltext.contains("<td")) {
            return htmltext;
        }

        String[] chs = htmltext.split("<td");
        StringBuilder html = new StringBuilder(chs[0]);
        String color;
        Pattern p = Pattern.compile("style=\"([^\"]*)", Pattern.CASE_INSENSITIVE);
        Matcher m = null;
        for (int i = 1; i < chs.length; i++) {
            color = chs[i];
            m = p.matcher(color);
            if (m.find()) {
                String[] cls = m.group(0).split(";");
                color = "";
                for (int j = 0; j < cls.length; j++) {
                    if (cls[j].toLowerCase().contains("background")) {
                        color = " bgcolor = \"" + cls[j].toUpperCase().replace("BACKGROUND", "").replace(":", "").replace("=", "").replace(";", "") + "\";";
                        break;
                    }
                }
            } else {
                color = "";
            }
            html.append("<td").append(color).append(chs[i]);
        }
        return html.toString();
    }

    private static String formatHtmlText(String htmltext) {
        try {
            htmltext = htmltext.replace("\n", " ");

            if (htmltext.toLowerCase().contains("<td")) {
                Pattern p = null;
                Matcher m = null;
                String word0 = "";
                String[] word1;
                int v = 0;
                p = Pattern.compile(".*<td[^>]*style=\"([^\"]*)", Pattern.CASE_INSENSITIVE);
                m = p.matcher(htmltext);
                while (m.find()) {
                    word0 = m.group(1);
                    word1 = word0.split(";");

                    htmltext = htmltext.replace(word0, "border:0.1pt;" + word1[0] + ";" + word1[word1.length - 3] + ";" + word1[word1.length - 2]);
                    v++;
                }
                htmltext = formatBgColor(htmltext);
//                htmltext = htmltext.replace("<td", "<td bgcolor = \"#CCCCCC\";");
            }

            htmltext = htmltext.replaceAll("<( )*a([^>])*><b><( )*span([^>])*>", "");
            htmltext = htmltext.replaceAll("(<( )*(/)( )*span( )*>)</b>(<( )*(/)( )*a( )*>)", "");

            htmltext = htmltext.replaceAll("<( )*a([^>])*><( )*span([^>])*>", "");
            htmltext = htmltext.replaceAll("(<( )*(/)( )*span( )*>)(<( )*(/)( )*a( )*>)", "");

            htmltext = htmltext.replaceAll("<( )*a([^>])*>", "");
            htmltext = htmltext.replaceAll("(<( )*(/)( )*a( )*>)", "");

            htmltext = htmltext.replaceAll("<( )*img([^>])*>", "");
            htmltext = htmltext.replaceAll("<( )*hr([^>])*>", "");

//            htmltext = htmltext.replace("background", "bgcolor");
//            htmltext = htmltext.replace("<br>", "<br/>");
            List<String> lbr = Arrays.asList(htmltext.split("<br"));
            htmltext = lbr.get(0);
            for (int i = 1; i < lbr.size(); i++) {
                htmltext = htmltext + "<br" + lbr.get(i).replaceFirst(">", "/>");
            }

            htmltext = htmltext.replaceAll("<p[^>]*class=\"([^\"]*)", "<p class=\"");
            htmltext = htmltext.replace("class=\"\"", "");

            htmltext = htmltext.replaceAll("<( )*table", "<table");
            List<String> l = Arrays.asList(htmltext.split("<table"));
            List<String> lf = new ArrayList();
            lf.add(l.get(0));
            for (int i = 1; i < l.size(); i++) {
                List<String> l0 = Arrays.asList(l.get(i).split("table>"));
                lf.add("<table" + l0.get(0));
                for (int j = 1; j < l0.size(); j++) {
                    lf.add("table>" + l0.get(j));
                }
            }
            htmltext = "";
            for (String s : lf) {
                if (s.startsWith("<table")) {
                    htmltext = htmltext + s;
                } else {
                    s = s.replaceAll("<( )*p([^>])*>", "<p style=\"text-align:justify;font-size:12.0pt;\">");
                    s = s.replaceAll("(<( )*(/)( )*p( )*>)", "</p>");

                    s = s.replaceAll("<( )*span([^>])*>", "<span style=\"text-align:justify;font-size:12.0pt;\">");
                    s = s.replaceAll("(<( )*(/)( )*span( )*>)", "</span>");
                    htmltext = htmltext + s;
                }
            }

            htmltext = htmltext.replaceAll("text-indent: -", "text-indent: ");
            htmltext = htmltext.replaceAll("<table[^>]*style=\"([^\"]*)\"", "<table border=\"0.25\" cellspacing=\"0\" cellpadding=\"5\"");
            htmltext = htmltext.replace("1.0", "0.25");
            htmltext = htmltext.replace("border=\"1\"", "border=\"0.25\"");
        } catch (Exception e) {
        }
//        System.err.println(htmltext);
        return htmltext;
    }

    public static void parseHtml(String section, String htmltext, PdfWriter writer, Document document, float spaceBefore, File fich) {
        String finalHtml = "";
        try {
            if (StringUtil.isNullOrEmpty(extractTextFromHtml(htmltext))) {
                return;
            }
            if (spaceBefore > 0) {
                Paragraph p = new Paragraph();
                p.setSpacingBefore(spaceBefore);
                document.add(p);
            }
            if (htmltext.toLowerCase().startsWith("{\\rtf")) {
                document.add(getJustifiedParagraph(StringUtil.rtfToTexte(htmltext), aNormal11, 0));
                return;
            }
            //List<String> htmltexts = new ArrayList<>();
            if (!htmltext.trim().toUpperCase().startsWith("<HTML")) {
                htmltext = "<html><body>".concat(htmltext).concat("</body></html>");
            }
            finalHtml = htmltext;
            htmltext = htmltext.replace("text-align: left", "text-align: justify");//text-align: left
            htmltext = formatHtmlText(htmltext);
            if (!htmltext.isEmpty()) {
                String[] chs = htmltext.split("src=\"file:///");
                finalHtml = "";
                if (chs.length > 1) {
                    finalHtml += chs[0];
                    for (int i = 1; i < chs.length; i++) {
                        finalHtml += ("src=\"");
                        chs[i] = chs[i].replaceFirst(">", "/>");
                        finalHtml += chs[i];
                    }
                } else {
                    finalHtml = htmltext;
                }
                final Path tmppath = fich.toPath();

                Runtime.getRuntime().addShutdownHook(new Thread() {

                    @Override
                    public void run() {
//                        System*.out.println("Deleting the temporary folder ...");
                        try (DirectoryStream<Path> ds = Files.newDirectoryStream(tmppath)) {
                            for (Path file : ds) {
                                Files.delete(file);
                            }
                            Files.delete(tmppath);
                        } catch (Exception e) {
//                            System*.err.println(e);
                        }
//                        System*.out.println("Shutdown-hook completed...");
                    }
                });
                if (useHtmlWorker) {
                    StringReader reader = new StringReader(finalHtml);
                    StyleSheet styles = new StyleSheet();
                    styles.loadTagStyle("ol", "indent", "15");
                    styles.loadTagStyle("ul", "indent", "15");
                    styles.loadTagStyle("li", "leading", "15");
                    ArrayList cc = (ArrayList) HTMLWorker.parseToList(reader, styles);
                    for (int i = 0; i < cc.size(); i++) {
                        Element elem = (Element) cc.get(i);
                        document.add(elem);
                    }
                } else {
                    FileOutputStream htmlfile = new FileOutputStream(fich);
                    ObjectOutputStream os = new ObjectOutputStream(htmlfile);
                    os.writeObject(finalHtml);
                    os.close();
                    Charset v = Charset.forName("UTF-8");
                    XMLWorkerHelper.getInstance().parseXHtml(writer, document, new FileInputStream(fich), v);
                    Files.delete(fich.toPath());
                }
            }

//            try (PrintWriter fp = FileUtil.appendText("e:/tempFile.txt")) {
//                fp.print(finalHtml);
//                fp.close();
//            }
        } catch (Exception ex) {
            if (rapport != null) {
                rapport.ajouterLigne("");
                rapport.ajouterLigne("");
                rapport.ajouterLigne("");
                rapport.ajouterLigne("");
                rapport.ajouterLigne("SECTION: " + section);
                rapport.ajouterLigne("-----------------------------");
                rapport.ajouterLigne("ERREUR: ");
                rapport.ajouterLigne(ex.getMessage());
                rapport.ajouterLigne("---HTML--------------------------");
                rapport.ajouterLigne(finalHtml);
            }
            System.err.println("SECTION: " + section);
            System.err.println("-----------------------------");
            System.err.println("ERREUR: ");
            System.err.println(ex.getMessage());
        }
    }

    private void printBkgText(Document document, PdfWriter writer) {
        Font f = new Font(aNormal10.getBaseFont(), 20, Font.NORMAL, BaseColor.LIGHT_GRAY);
        GrecoPdfPageEventHelper.doTexte(writer.getDirectContent(),
                (document.left() + document.right()) / 2,
                (document.top() + document.bottom()) / 2, " ", f, PdfContentByte.ALIGN_CENTER);
    }

    private void addPageIntercallaire(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, boolean forceBkg, String txt/*, boolean verifPage, boolean newSection*/) {
        try {
            eventHelper.setPrintBG(forceBkg);
            eventHelper.setPrintFooter(forceBkg);
            eventHelper.setPrintHeader(forceBkg);
//            if (printRecto) {
//                return;
//            }
            document.newPage();
            document.add(new Paragraph(" "));
            int p = eventHelper.getCurrentPage();
            if (p % 2 == 0) {
                document.newPage();
                document.add(new Paragraph(" "));
                if (!forceBkg) {
                    printBkgText(document, writer);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void addIntroduction(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, File tmpFile) {
        try {
            addPageIntercallaire(eventHelper, document, writer, false, " ");
//            eventHelper.setPrintBG(false);
//            eventHelper.setPrintFooter(false);
//            eventHelper.setPrintHeader(false);
//            document.newPage();
            document.add(new Paragraph(getTexte(GrecoDocNode.INTRODUCTION), aBold12));
            eventHelper.addSommaire("INTRODUCTION");
            float pos = writer.getVerticalPosition(false) - 2;
            GrecoPdfPageEventHelper.doLine(writer.getDirectContent(), document.left(), pos, document.right(), pos, 0.5F, colCdmt);
            parseHtml("INTRODUCTION", cdmt.getIntro(locale), writer, document, spaceBefore, tmpFile);
//            addPageIntercallaire(eventHelper, document, writer, false, " ");
        } catch (Exception e) {
        }
    }

    private void addPageDeGarde(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, String fontNormal) {
        try {
            eventHelper.setPrintBG(false);
            eventHelper.setPrintFooter(false);
            eventHelper.setPrintHeader(false);
            PdfContentByte cb = writer.getDirectContent();

            try {
                //java.awt.Image bg = mesImages.getImage("couvertureRapBordCM.png");
                com.itextpdf.text.Image itext = GrecoPdfPageEventHelper.getItextImage(writer, bgImage, document.getPageSize().getWidth(), document.getPageSize().getHeight());
                itext.setAbsolutePosition(0, 0);
//                if (printCoverBgImage) 
                {
                    document.add(itext);
                }
            } catch (Exception exception) {
                String ch = "";
            }

//            RaPdfPageEventHelper.doRectangle(cb, new Rectangle(17, document.top() + document.topMargin(), decBande, document.top() + document.topMargin() - 500), 2, couleurDocument, couleurDocument);
            Font fPays = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 18, Font.NORMAL, BaseColor.BLACK);
            Font fDevise = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 10, Font.NORMAL, BaseColor.BLACK);
            Font fTitre1 = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 20, Font.BOLD, BaseColor.BLACK);
            Font fTitre2 = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 16, Font.BOLD, BaseColor.BLACK);

            Font fPPA = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 14, Font.NORMAL, BaseColor.BLACK);

            Font fChapCode = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 16, Font.BOLD, BaseColor.BLACK);
            Font fChapLib = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 14, Font.BOLD, BaseColor.BLACK);

            Font fVersion = new Font(BaseFont.createFont(fontNormal, BaseFont.CP1252, BaseFont.EMBEDDED), 16, Font.NORMAL, BaseColor.GRAY);

            float decY = /*typeCadre ?*/ -50;// : 0;
            float decBande = /*typeCadre ?*/ 50;// : 0;

            float xC = decBande / 2 + (document.left() + document.right() - decBande) / 2;
//            if (printCoverBgImage) 
            {
                GrecoPdfPageEventHelper.doTexte(cb, xC, decY + document.top() + document.topMargin() / 3, getTexte(GrecoLangue.PAYS), fPays, PdfContentByte.ALIGN_CENTER);
            }
            float yPays = decY + document.top() + document.topMargin() / 3 - 5 - fDevise.getSize();
//            if (printCoverBgImage) 
            {
//                GrecoPdfPageEventHelper.doTexte(cb, xC, yPays, getTexte(GrecoLangue.DEVISE), fDevise, PdfContentByte.ALIGN_CENTER);
            }

            float hFinal = 60;
            try {
                java.awt.Image img = mesImages.imgArmoirieCouleur();
                float hImg = new ImageIcon(img).getIconHeight();
                float p = (hFinal * 100) / hImg;

                com.itextpdf.text.Image itext = GrecoPdfPageEventHelper.getItextImage(writer, img, p);
                itext.setAbsolutePosition(xC - itext.getScaledWidth() / 2, yPays - hFinal - 50);//- itext.getScaledHeight());
//                if (printCoverBgImage) 
                {
                    document.add(itext);
                }
            } catch (Exception exception) {
                String ch = "";
            }

//            float[] widths1 = {1F, 6F, 1F};
//            PdfPTable tab = new PdfPTable(widths1);
//            tab.addCell(getCellWithoutBorder(getTexte(GrecoLangue.PLF_DRAFT), fTitre1, 3, 1, 0));
//            tab.addCell(getCellWithoutBorder(getTexte(GrecoLangue.PR_EXERCICE).replace("{0}", String.valueOf(annee)), fTitre2, 3, 1, 30F));
//            tab.addCell(getCellWithoutBorder(getTexte(GrecoLangue.PPA), fPPA, 3, 1, 170F));
//            tab.addCell(getCellWithoutBorder("", aNormal10, 1, 2, 0));
//            tab.addCell(getCellBorder(getTexte(GrecoLangue.CHAPITRE) + " ".concat(chapitre.getTblChapitrePK().getChCodeChapitre()), fChapCode, 1, 1, 40F, true, false, true, true));
//            tab.addCell(getCellWithoutBorder("", aNormal10, 1, 2, 0));
//            tab.addCell(getCellBorder(chapitre.getChLibelle(locale), fChapLib, 1, 1, 100F, false, true, true, true));
//            tab.setSpacingBefore(fPays.getSize() + fDevise.getSize() + hFinal + 100);
//            document.add(new Paragraph(" "));
//            document.add(tab);
            float largeur = (document.right() - document.left());
//            xC = document.left();
//            GrecoPdfPageEventHelper.doTexte(cb, xC + largeur / 2, yPays - 150, , fTitre1, PdfContentByte.ALIGN_CENTER, fTitre1.getSize() + 3, largeur, true);
//            GrecoPdfPageEventHelper.doTexte(cb, xC + largeur / 2, yPays - 150 - fTitre1.getSize(), , fTitre2, PdfContentByte.ALIGN_CENTER);
//
//            GrecoPdfPageEventHelper.doTexte(cb, xC + largeur / 2, yPays - 300, , fPPA, PdfContentByte.ALIGN_CENTER);
//
//            GrecoPdfPageEventHelper.doTexte(cb, xC + largeur / 2, yPays - 400, getTexte(GrecoLangue.CHAPITRE) + " ".concat(chapitre.getTblChapitrePK().getChCodeChapitre()), fChapCode, PdfContentByte.ALIGN_CENTER);
//
//            GrecoPdfPageEventHelper.doTexte(cb, xC + largeur / 2, yPays - 450, chapitre.getChLibelle(locale), fChapLib, PdfContentByte.ALIGN_CENTER, -(fChapLib.getSize() + 3), largeur/2, true);
//
            largeur = GrecoPdfPageEventHelper.getLen(getTexte(GrecoLangue.VERSION).toUpperCase(), fVersion);
            xC = decBande / 2 + (document.left() + document.right() - decBande) / 2;
            GrecoPdfPageEventHelper.doLine(cb, xC - largeur / 2, -decY + document.bottom() + 25, xC + largeur / 2, -decY + document.bottom() + 25, 2, BaseColor.GRAY);
            GrecoPdfPageEventHelper.doTexte(cb, xC, -decY + document.bottom() + 25 + 5, getTexte(GrecoLangue.VERSION).toUpperCase(), fVersion, PdfContentByte.ALIGN_CENTER);
            GrecoPdfPageEventHelper.doLine(cb, xC - largeur / 2, -decY + document.bottom() + 25 + 5 + fVersion.getSize(), xC + largeur / 2, -decY + document.bottom() + 25 + 5 + fVersion.getSize(), 2, BaseColor.GRAY);

//            if (printRecto) {
//                return;
//            }
            document.newPage();
            document.add(new Paragraph(" "));
//            addPageIntercallaire(eventHelper, document, writer, false, " ");
        } catch (Exception e) {
        }
    }


    private void addLigneSommaire(PdfPTable tbl, Font f, String num, int numAlign, String libelleGras, String libelle, String index, float height) {
        addLigneSommaire(tbl, f, num, numAlign, libelleGras, true, libelle, index, height, true);
    }

    private void addLigneSommaire(PdfPTable tbl, Font f, String num, int numAlign, String libelleGras, boolean useGras, String libelle, String index, float height, boolean upper) {
        try {

            Font fg = new Font(f.getBaseFont(), f.getSize(), useGras ? Font.BOLD : f.getStyle());

            PdfPCell ch = new PdfPCell();
            ch.setFixedHeight(height);
            ch.setColspan(3);
            ch.setBorder(0);
            Paragraph p = new Paragraph(new Phrase(num.replace("_", ""), f));
            p.setAlignment(numAlign);
            PdfPCell cell1 = new PdfPCell();
            cell1.addElement(p);
            cell1.setHorizontalAlignment(numAlign);

            p = new Paragraph();
            PdfPCell cell2 = new PdfPCell();
            p.add(new Phrase(upper ? libelleGras.toUpperCase() : libelleGras, fg));
            p.add(new Phrase(upper ? libelle.trim().toUpperCase() : libelle.trim(), f));
            cell2.addElement(p);
//            cell2.addElement(new Phrase(libelle.trim().toUpperCase(), f));

            p = new Paragraph(new Phrase(index, f));
            PdfPCell cell3 = new PdfPCell();
            cell3.addElement(p);

            cell1.setBorder(0);
            cell2.setBorder(0);
            cell3.setBorder(0);

            cell1.setVerticalAlignment(PdfPTable.ALIGN_TOP);
            cell2.setVerticalAlignment(PdfPTable.ALIGN_TOP);
            cell3.setVerticalAlignment(PdfPTable.ALIGN_TOP);
            cell3.setHorizontalAlignment(PdfPTable.ALIGN_RIGHT);

            if (height > 0) {
                tbl.addCell(ch);
            }
            if (StringUtil.isNullOrEmpty(num)) {
                cell2.setColspan(2);
                tbl.addCell(cell2);
            } else {
                tbl.addCell(cell1);
                tbl.addCell(cell2);
            }
            tbl.addCell(cell3);
            if (height > 0) {
                tbl.addCell(ch);
            }
        } catch (Exception ex) {
//            ex.printStackTrace();
        }
    }

    private String getIndexSommaire(String cle, List<CleValeur> valeurs) {
        try {
            if (valeurs == null) {
                return "";
            }
            if (valeurs.isEmpty()) {
                return "";
            }
            for (CleValeur cl : valeurs) {
                if (cl.getCode().equals(cle)) {
                    return cl.getLibelleFr();
                }
            }
        } catch (Exception e) {
        }
        return "";
    }

    private void forceNewPage(PdfWriter writer) {
        if (writer != null) {
            float pos = writer.getVerticalPosition(false);
            if (pos < 200) {
                writer.getDirectContent().getPdfDocument().newPage();
            }
        }
    }

    private void addSommaire(List<CleValeur> valeurs, GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, boolean newPageAfter) {
        try {
            eventHelper.setPrintBG(false);
            eventHelper.setPrintFooter(false);
            eventHelper.setPrintHeader(false);
            document.newPage();
            Font f31 = new Font(aBold22);
            f31.setColor(colCdmt);
            document.add(new Paragraph(getTexte(GrecoLangue.SOMMAIRE), f31));
            float pos = writer.getVerticalPosition(false) - 2;
            PdfContentByte cb = writer.getDirectContent();
            GrecoPdfPageEventHelper.doLine(cb, document.left(), pos, document.right(), pos, 0.5F, colCdmt);

            pos -= 50;
            f31 = new Font(aBold12);
            f31.setColor(colCdmt);
            Font f32 = aNormal10;
            Font f33 = aNormal9;
            Font f33i = new Font(f33);
            f33i.setStyle(Font.ITALIC);
            //f33i.setSize(f33i.getSize() - 1);

            float h1 = 9;
            float h2 = 3;
            float h3 = 1;
            float h4 = 0;
            float[] widths1 = {1f, 11f, 0.7f};
            PdfPTable table = new PdfPTable(widths1);
            table.setWidthPercentage(95);
            table.setHorizontalAlignment(Element.ALIGN_RIGHT);
            //new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }

            addLigneSommaire(table, f31, "_", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.INTRODUCTION), getIndexSommaire("INTRODUCTION", valeurs), h1);
            addLigneSommaire(table, f31, "1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.CHAPITRE_1), getIndexSommaire("1.", valeurs), h1);
            addLigneSommaire(table, f32, "1.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_11), getIndexSommaire("1.1.", valeurs), h2);
            addLigneSommaire(table, f33, "1.1.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_111), getIndexSommaire("1.1.1.", valeurs), h3);
            addLigneSommaire(table, f33, "1.1.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_112), getIndexSommaire("1.1.2.", valeurs), h3);
            addLigneSommaire(table, f33, "1.1.3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_113), getIndexSommaire("1.1.3.", valeurs), h3);
            addLigneSommaire(table, f32, "1.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_12), getIndexSommaire("1.2.", valeurs), h2);
//            addLigneSommaire(table, f33, "1.2.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_121), getIndexSommaire("1.2.1.", valeurs), h3);
//            addLigneSommaire(table, f33, "1.2.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_122), getIndexSommaire("1.2.2.", valeurs), h3);
            int indPg = 1;
//////////            for (PrepaProgramme pg : programmes) {
//////////                addLigneSommaire(table, f33, "1.2." + indPg + ".", Element.ALIGN_LEFT, "PROGRAMME " + pg.getPgCodeLRFE() + ": ", false, pg.getPgLibelle(locale), getIndexSommaire("1.2." + indPg + ".", valeurs), h3, true);
//////////
////////////                addLigneSommaire(table, f33i, "1.2." + indPg + ".a.", Element.ALIGN_LEFT, "", false, getTexte(GrecoLangue.PRESENTATION_PROGRAMME), getIndexSommaire("1.2." + indPg + ".a.", valeurs), h4, false);
////////////                addLigneSommaire(table, f33i, "1.2." + indPg + ".b.", Element.ALIGN_LEFT, "", false, getTexte(GrecoLangue.STRATEGIE_PROGRAMME), getIndexSommaire("1.2." + indPg + ".b.", valeurs), h4, false);
////////////                addLigneSommaire(table, f33i, "1.2." + indPg + ".c.", Element.ALIGN_LEFT, "", false, getTexte(GrecoLangue.PRESENTATION_ACTIONS), getIndexSommaire("1.2." + indPg + ".c.", valeurs), h4, false);
////////////                addLigneSommaire(table, f33i, "1.2." + indPg + ".d.", Element.ALIGN_LEFT, "", false, getTexte(GrecoLangue.CADRE_LOGIQUE_PROGRAMME), getIndexSommaire("1.2." + indPg + ".d.", valeurs), h4, false);
//////////                addLigneSommaire(table, f33i, "_", Element.ALIGN_LEFT, "a. ", false, getTexte(GrecoLangue.PRESENTATION_PROGRAMME), getIndexSommaire("1.2." + indPg + ".a.", valeurs), h4, false);
//////////                addLigneSommaire(table, f33i, "_", Element.ALIGN_LEFT, "b. ", false, getTexte(GrecoLangue.STRATEGIE_PROGRAMME), getIndexSommaire("1.2." + indPg + ".b.", valeurs), h4, false);
//////////                addLigneSommaire(table, f33i, "_", Element.ALIGN_LEFT, "c. ", false, getTexte(GrecoLangue.PRESENTATION_ACTIONS), getIndexSommaire("1.2." + indPg + ".c.", valeurs), h4, false);
//////////                addLigneSommaire(table, f33i, "_", Element.ALIGN_LEFT, "d. ", false, getTexte(GrecoLangue.CADRE_LOGIQUE_PROGRAMME), getIndexSommaire("1.2." + indPg + ".d.", valeurs), h4, false);
//////////
//////////                indPg++;
//////////            }

            //
            forceNewPage(writer);
            addLigneSommaire(table, f31, "2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.CHAPITRE_2), getIndexSommaire("2.", valeurs), h1);
            addLigneSommaire(table, f32, "2.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_21), getIndexSommaire("2.1.", valeurs), h2);
            addLigneSommaire(table, f33, "2.1.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_211), getIndexSommaire("2.1.1.", valeurs), h3);
            addLigneSommaire(table, f33, "2.1.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_212), getIndexSommaire("2.1.2.", valeurs), h3);
            addLigneSommaire(table, f33, "2.1.3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_213), getIndexSommaire("2.1.3.", valeurs), h3);
            addLigneSommaire(table, f32, "2.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_22), getIndexSommaire("2.2.", valeurs), h2);
            addLigneSommaire(table, f33, "2.2.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_221), getIndexSommaire("2.2.1.", valeurs), h3);
            addLigneSommaire(table, f33, "2.2.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_222), getIndexSommaire("2.2.2.", valeurs), h3);
            addLigneSommaire(table, f33, "2.2.3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_223), getIndexSommaire("2.2.3.", valeurs), h3);
            addLigneSommaire(table, f32, "2.3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_23), getIndexSommaire("2.3.", valeurs), h2);
            addLigneSommaire(table, f33, "2.3.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_231), getIndexSommaire("2.3.1.", valeurs), h3);
            addLigneSommaire(table, f33, "2.3.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.PARAGRAPHE_232), getIndexSommaire("2.3.2.", valeurs), h3);
            //
            forceNewPage(writer);
            addLigneSommaire(table, f31, "3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.CHAPITRE_3), getIndexSommaire("3.", valeurs), h1);
            addLigneSommaire(table, f32, "3.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_31), getIndexSommaire("3.1.", valeurs), h2);
            addLigneSommaire(table, f32, "3.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_32), getIndexSommaire("3.2.", valeurs), h2);
            addLigneSommaire(table, f32, "3.3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_33), getIndexSommaire("3.3.", valeurs), h2);
            //
            forceNewPage(writer);
            addLigneSommaire(table, f31, "4.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.CHAPITRE_4), getIndexSommaire("4.", valeurs), h1);
            addLigneSommaire(table, f32, "4.1.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_41), getIndexSommaire("4.1.", valeurs), h2);
            addLigneSommaire(table, f32, "4.2.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_42), getIndexSommaire("4.2.", valeurs), h2);
            addLigneSommaire(table, f32, "4.3.", Element.ALIGN_LEFT, "", getTexte(GrecoDocNode.SECTION_43), getIndexSommaire("4.3.", valeurs), h2);

            forceNewPage(writer);
            addLigneSommaire(table, f31, "_", Element.ALIGN_LEFT, "", getTexte(GrecoLangue.SOMMAIRE_ANNEXE), getIndexSommaire(GrecoLangue.SOMMAIRE_ANNEXE, valeurs), h1);
            addLigneSommaire(table, f32, "1 -", Element.ALIGN_LEFT, "", getTexte(GrecoLangue.ANNEXE_1), getIndexSommaire("5.1.", valeurs), h2);
            addLigneSommaire(table, f32, "2 -", Element.ALIGN_LEFT, "", getTexte(GrecoLangue.ANNEXE_2_PART1) + " " + getTexte(GrecoLangue.ANNEXE_2_PART2), getIndexSommaire("5.2.", valeurs), h2);
            addLigneSommaire(table, f32, "3 -", Element.ALIGN_LEFT, "", getTexte(GrecoLangue.ANNEXE_3_PART1) + " " + getTexte(GrecoLangue.ANNEXE_3_PART2), getIndexSommaire("5.3.", valeurs), h2);
            
            document.add(new Paragraph(" "));
            document.add(table);
            if (newPageAfter) {
                document.newPage();
            }
        } catch (Exception e) {
        }
    }

    private void addSectionMainPage(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, String index, List<String> titles, Font f) {
////////        try {
////////            eventHelper.setPrintBG(false);
////////            eventHelper.setPrintFooter(false);
////////            eventHelper.setPrintHeader(false);
////////            document.newPage();
////////            document.add(new Paragraph());
////////            float top = (document.bottom() + document.top()) / 2;
////////            top -= (f.getSize() * -1.5F) * titles.size();
////////            if (StringUtil.isNullOrEmpty(index)) {
////////                GrecoPdfPageEventHelper.doTextes(writer.getDirectContent(), (document.left() + document.right()) / 2, top, titles, f, PdfContentByte.ALIGN_CENTER, f.getSize() * -1.5F);
////////            } else {
////////                GrecoPdfPageEventHelper.doTextes(writer.getDirectContent(), (document.left() + document.right()) / 4, top, titles, f, PdfContentByte.ALIGN_LEFT, f.getSize() * -1.5F);
////////                GrecoPdfPageEventHelper.doTexte(writer.getDirectContent(), (document.left() + document.right()) / 4 - 10, top, index, f, PdfContentByte.ALIGN_RIGHT, f.getSize() * -1.5F);
////////            }
////////            //addPageIntercallaire(document);
////////        } catch (Exception e) {
////////        }
    }

    private void initCL(Object ob) {
////////        if (ob instanceof TblChapitre) {
////////            cadreLogiques = ServiceFactory.getReportService().getCadreLogiqueChapitre(chapitre.getTblChapitrePK().getExMillesime(), chapitre.getTblChapitrePK().getChCodeChapitre(), null, locale);
////////            String chCode = cadreLogiques.get(0).getChCode();
////////            mapProgrammes.clear();
////////            nbIndParProgramme.clear();
////////            nbIndParObjectifProgramme.clear();
////////
////////            List<PrepaProgramme> programms = new ArrayList<>();
////////
////////            int curIndOb;
////////            int curIndPg;
////////
////////            String pgCode = cadreLogiques.get(0).getPgCodeProgramme();
////////            String obCode = cadreLogiques.get(0).getObCode();
////////            PrepaProgramme pgg = new PrepaProgramme(pgCode);
////////            curIndPg = 0;
////////            curIndOb = 0;
////////
////////            pgg.setPgCodeLRFE(pgCode);
////////            pgg.setPgLibelleFrancais(cadreLogiques.get(0).getPgLibelle());
////////            pgg.setPgLibelleAnglais(cadreLogiques.get(0).getPgLibelle());
////////            for (VuePSFECadreLogique cl : cadreLogiques) {
////////                try {
////////                    if (!cl.getChCode().equals(chCode)) {
////////                        //Nouveau Chapitre
////////                        nbIndParObjectifProgramme.put(obCode, curIndOb);
////////                        nbIndParProgramme.put(pgCode, curIndPg);
////////                        programms.add(pgg);
////////                        curIndPg = 0;
////////                        curIndOb = 0;
////////                        pgCode = cl.getPgCodeProgramme();
////////                        obCode = cl.getObCode();
////////                        pgg = new PrepaProgramme(pgCode);
////////
////////                        pgg.setPgCodeLRFE(pgCode);
////////                        pgg.setPgLibelleFrancais(cl.getPgLibelle());
////////                        pgg.setPgLibelleAnglais(cl.getPgLibelle());
////////
////////                        mapProgrammes.put(chCode, programms);
////////                        programms = new ArrayList<>();
////////                        chCode = cl.getChCode();
////////                    }
////////
////////                    if (!cl.getPgCodeProgramme().equals(pgCode)) {
////////                        //Nouvelle action
////////
////////                        nbIndParProgramme.put(pgCode, curIndPg);
////////                        nbIndParObjectifProgramme.put(obCode, curIndOb);
////////                        curIndPg = 0;
////////                        curIndOb = 0;
////////                        programms.add(pgg);
////////                        pgCode = cl.getPgCodeProgramme();
////////                        obCode = cl.getObCode();
////////                        pgg = new PrepaProgramme(pgCode);
////////                        pgg.setPgCodeLRFE(pgCode);
////////                        pgg.setPgLibelleFrancais(cl.getPgLibelle());
////////                        pgg.setPgLibelleAnglais(cl.getPgLibelle());
////////                    }
////////                    if (!cl.getObCode().equals(obCode)) {
////////                        //Nouvel objectif
////////                        nbIndParObjectifProgramme.put(obCode, curIndOb);
////////                        obCode = cl.getObCode();
////////                        curIndOb = 0;
////////                    }
////////                    curIndPg++;
////////                    curIndOb++;
////////                } catch (Exception e) {
////////                    String ch = "";
////////                }
////////            }
////////            nbIndParObjectifProgramme.put(obCode, curIndOb);
////////            nbIndParProgramme.put(pgCode, curIndPg);
////////            programms.add(pgg);
////////            mapProgrammes.put(chCode, programms);
////////        }
////////
////////        if (ob instanceof PrepaProgramme) {
////////            PrepaProgramme prog = (PrepaProgramme) ob;
////////            cadreLogiques = ServiceFactory.getReportService().getCadreLogique(prog.getExMillesime(), prog.getChCodeChapitre(), prog.getTblPSFEProgrammePK(), null, locale);
////////            String pgCode = cadreLogiques.get(0).getPgCodeProgramme();
////////            mapActions.clear();
////////            nbIndParAction.clear();
////////            nbIndParObjectif.clear();
////////
////////            List<PrepaAction> actions = new ArrayList<>();
////////
////////            int curIndOb;
////////            int curIndAc;
////////
////////            String acCode = cadreLogiques.get(0).getAcCodeAction();
////////            String obCode = cadreLogiques.get(0).getObCode();
////////            PrepaAction acc = new PrepaAction(pgCode + "." + acCode);
////////            curIndAc = 0;
////////            curIndOb = 0;
////////
////////            acc.setAcCodeLRFE(acCode);
////////            acc.setAcLibelleFrancais(cadreLogiques.get(0).getAcLibelle());
////////            acc.setAcLibelleAnglais(cadreLogiques.get(0).getAcLibelle());
////////            for (VuePSFECadreLogique cl : cadreLogiques) {
////////                try {
////////                    if (!cl.getPgCodeProgramme().equals(pgCode)) {
////////                        //Nouveau programme
////////                        nbIndParObjectif.put(obCode, curIndOb);
////////                        nbIndParAction.put(pgCode + "." + acCode, curIndAc);
////////                        actions.add(acc);
////////                        curIndAc = 0;
////////                        curIndOb = 0;
////////                        acCode = cl.getAcCodeAction();
////////                        obCode = cl.getObCode();
////////                        acc = new PrepaAction(pgCode + "." + acCode);
////////
////////                        acc.setAcCodeLRFE(acCode);
////////                        acc.setAcLibelleFrancais(cl.getAcLibelle());
////////                        acc.setAcLibelleAnglais(cl.getAcLibelle());
////////
////////                        mapActions.put(pgCode, actions);
////////                        actions = new ArrayList<>();
////////                        pgCode = cl.getPgCodeProgramme();
////////                    }
////////
////////                    if (!cl.getAcCodeAction().equals(acCode)) {
////////                        //Nouvelle action
////////
////////                        nbIndParAction.put(pgCode + "." + acCode, curIndAc);
////////                        nbIndParObjectif.put(obCode, curIndOb);
////////                        curIndAc = 0;
////////                        curIndOb = 0;
////////                        actions.add(acc);
////////                        acCode = cl.getAcCodeAction();
////////                        obCode = cl.getObCode();
////////                        acc = new PrepaAction(pgCode + "." + acCode);
////////                        acc.setAcCodeLRFE(acCode);
////////                        acc.setAcLibelleFrancais(cl.getAcLibelle());
////////                        acc.setAcLibelleAnglais(cl.getAcLibelle());
////////                    }
////////                    if (!cl.getObCode().equals(obCode)) {
////////                        //Nouvel objectif
////////                        nbIndParObjectif.put(obCode, curIndOb);
////////                        obCode = cl.getObCode();
////////                        curIndOb = 0;
////////                    }
////////                    curIndAc++;
////////                    curIndOb++;
////////                } catch (Exception e) {
////////                    String ch = "";
////////                }
////////            }
////////            nbIndParObjectif.put(obCode, curIndOb);
////////            nbIndParAction.put(pgCode + "." + acCode, curIndAc);
////////            actions.add(acc);
////////            mapActions.put(pgCode, actions);
////////        }
    }

    private void addTableauBudget( Document document, PdfWriter writer) {
////////        try {
////////
//////////            BaseColor cl_bg1 = new BaseColor(0, 0, 51);
////////            BaseColor cl_bg2 = colCdmt;//new BaseColor(136, 176, 97);
//////////            BaseColor cl_bg3 = new BaseColor(212, 235, 189);
////////
////////            float[] widths1 = {341, 85, 85};
////////            PdfPCell c;
////////
////////            PdfPTable table = new PdfPTable(widths1);
////////            table.setSpacingBefore(spaceBefore);
////////            table.setWidthPercentage(100);
////////
////////            Font a10 = new Font(aBold10);
////////            a10.setColor(BaseColor.WHITE);
////////            Font a9 = new Font(a10);
////////            a9.setSize(9);
////////            Font a8 = new Font(a10);
////////            a8.setSize(8);
////////            //
////////            table.addCell(getCellWithoutBorder(" ", aNormal6, 2, 1, 10));
////////            table.addCell(getCellWithoutBorder(getTexte(GrecoLangue.EN_FCFA), aNormal6, 1, 1, 10, PdfPTable.ALIGN_CENTER));
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.BUDGETISATION_N), a10), 1, 1);
////////            c.setMinimumHeight(25);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.AE), a10), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.CP), a10), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            BigDecimal ae = BigDecimal.ZERO;
////////            BigDecimal cp = BigDecimal.ZERO;
////////
////////            for (VueElab2015BudgetAeCpNatDep p : prog) {
////////                c = new PdfPCell();
////////                c.addElement(new Paragraph(getTexte(GrecoLangue.PROGRAMME) + " " + p.getCode(), aBold9U));
////////                //getCell(fromLocal(pg.getPgLibelleFrancais(), pg.getPgLibelleAnglais()), aBold9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP)
////////                c.addElement(new Phrase(p.getLibelle(), aNormal9));
////////                table.addCell(c);
////////
//////////                table.addCell(getCell("PROGR. " + p.getCode(), aBold8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP, 30f));
//////////
//////////                table.addCell(getCell(p.getLibelle(), aNormal9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                try {
////////                    table.addCell(getCell(getMontantFormate(p.getAe()), aNarrow9, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////
////////                try {
////////                    table.addCell(getCell(getMontantFormate(p.getCp()), aNarrow9, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    ae = ae.add(p.getAe());
////////                } catch (Exception e) {
////////                }
////////                try {
////////                    cp = cp.add(p.getCp());
////////                } catch (Exception e) {
////////                }
////////            }
////////            c = getCell(getTexte(GrecoLangue.TOTAL_CHAPITRE), aBold9, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_MIDDLE);
////////            c.setColspan(1);
////////            table.addCell(c);
////////
////////            try {
////////                table.addCell(getCell(getMontantFormate(ae), aNarrowB9, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_MIDDLE));
////////            } catch (Exception e) {
////////                table.addCell(getCell("", aBold9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_MIDDLE));
////////            }
////////
////////            try {
////////                table.addCell(getCell(getMontantFormate(cp), aNarrowB9, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_MIDDLE));
////////            } catch (Exception e) {
////////                table.addCell(getCell("", aBold9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_MIDDLE));
////////            }
////////            document.add(table);
////////        } catch (Exception e) {
////////            String ch = "";
////////        }
    }

    private void addCadreLogiqueChapitre(Integer anneeIntermediaire, Document document, PdfWriter writer) {
////////        try {
////////            initCL(chapitre);
////////            List l = new ArrayList();
////////
////////            BaseColor cl_bg1 = new BaseColor(0, 0, 51);
////////            BaseColor cl_bg2 = new BaseColor(136, 176, 97);
////////            BaseColor cl_bg3 = new BaseColor(212, 235, 189);
////////
////////            String ch = "";// cadreLogiques.get(0).getPgCodeProgramme();
////////            String pg = "";//cadreLogiques.get(0).getAcCodeAction();
////////            String ob = "";//cadreLogiques.get(0).getObCode();
////////            float[] widths1 = {20, 120, 120, 120, 35, 35, 61};
////////            PdfPTable table = null;
////////            // Ajout des cadres logiques
////////            PdfPCell c;
////////            for (VuePSFECadreLogique cl : cadreLogiques) {
////////                if (!ch.equals(cl.getChCode())) {
////////                    if (table != null) {
////////                        document.add(table);
////////                    }
////////                    doProgress();
////////                    // Nouveau chapitre
////////                    ch = cl.getChCode();
////////                    pg = "";
////////                    ob = "";
////////                    table = new PdfPTable(widths1);
////////                    table.setSpacingBefore(spaceBefore);
////////                    table.setWidthPercentage(100);
////////
////////                    Font a10 = new Font(aBold10);
////////                    a10.setColor(BaseColor.WHITE);
////////                    Font a9 = new Font(a10);
////////                    a9.setSize(9);
////////                    Font a8 = new Font(a10);
////////                    a8.setSize(8);
//////////                    c = getCellWithoutBorder(getTexte(GrecoLangue.CADRE_LOGIQUE_DU_PROGRAMME) + " " + cl.getPgCodeProgramme(), aBold12, 7, 1, 20);
//////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
//////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
//////////                    c.setIndent(25);
//////////                    table.addCell(c);
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.CHAPITRE) + " " + cl.getChCode() + ": " + cl.getChLibelle(), a10), 7, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg1);
////////                    c.setMinimumHeight(50);
////////                    table.addCell(c);
////////                    //
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Programmes_du_chapitre), a9), 2, 2);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Objectif), a9), 1, 2);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Indicateurs), a9), 4, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Libelle), a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Niveau_Ref), a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////                    String t = getTexte(GrecoLangue.Niveau_cible);
////////                    if (anneeIntermediaire != null) {
////////                        t = "Niveau " + anneeIntermediaire;
////////                    }
////////                    c = getCellBorder(new Phrase(t, a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Source_de_verification), a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////                }
////////
////////                if (!pg.equals(cl.getPgCodeProgramme())) {
////////                    //Nouveau programme
////////                    pg = cl.getPgCodeProgramme();
////////                    ob = "";
////////                    if (writer != null) {
////////                        float pos = writer.getVerticalPosition(false);
////////                        if (pos < 200) {
////////                            writer.getDirectContent().getPdfDocument().newPage();
////////                        }
////////                    }
////////
////////                    int nbInd = nbIndParProgramme.get(pg); //ServiceFactory.getActionService().getIndicateursCountByAction(pg.getId());
////////                    if (nbInd <= 0) {
////////                        nbInd = 1;
////////                    }
////////                    c = getCellBorder(new Phrase(pg, aNormal8), 1, nbInd);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_TOP);
////////                    c.setBackgroundColor(cl_bg3);
////////                    table.addCell(c);
////////
////////                    c = getCell(cl.getPgLibelle(), aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP);
////////                    c.setRowspan(nbInd);
////////                    table.addCell(c);
////////                }
////////                if (!ob.equals(cl.getObCode())) {
////////                    ob = cl.getObCode();
////////                    int nbInd = nbIndParObjectifProgramme.get(ob); //ServiceFactory.getActionService().getIndicateursCountByAction(pg.getId());
////////                    if (nbInd <= 0) {
////////                        nbInd = 1;
////////                    }
////////                    c = getCellBorder(new Phrase(cl.getObLibelle(), aNormal8), 1, nbInd);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_TOP);
//////////                    c.setBackgroundColor(cl_bg3);
////////                    table.addCell(c);
////////
////////                }
////////
////////                try {
////////                    table.addCell(getCell(cl.getInLibelle(), aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    table.addCell(getCell(getMontantFormate(cl.getInValeurRef()), aNarrow7, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    table.addCell(getCell(getMontantFormate(anneeIntermediaire == null ? cl.getInValeurCible() : cl.getInValeurIntermediaire1()), aNarrow7, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    table.addCell(getCell(cl.getInSourceVerification(), aNarrow7, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////            }
////////            document.add(table);
////////        } catch (Exception e) {
////////        }
    }

    private void addCadreLogique(Integer anneeIntermediaire, Document document, PdfWriter writer) {
////////        try {
////////            initCL(prog);
////////            List l = new ArrayList();
////////
////////            BaseColor cl_bg1 = new BaseColor(0, 0, 51);
////////            BaseColor cl_bg2 = new BaseColor(136, 176, 97);
////////            BaseColor cl_bg3 = new BaseColor(212, 235, 189);
////////
////////            String pg = "";// cadreLogiques.get(0).getPgCodeProgramme();
////////            String ac = "";//cadreLogiques.get(0).getAcCodeAction();
////////            String ob = "";//cadreLogiques.get(0).getObCode();
////////            float[] widths1 = {20, 120, 120, 120, 35, 35, 61};
////////            PdfPTable table = null;
////////            // Ajout des cadres logiques
////////            PdfPCell c;
////////            for (VuePSFECadreLogique cl : cadreLogiques) {
////////                if (!pg.equals(cl.getPgCodeProgramme())) {
////////                    if (table != null) {
////////                        document.add(table);
////////                    }
////////                    doProgress();
////////                    // Nouveau Programme
////////                    pg = cl.getPgCodeProgramme();
////////                    ac = "";
////////                    ob = "";
////////                    table = new PdfPTable(widths1);
////////                    table.setSpacingBefore(spaceBefore);
////////                    table.setWidthPercentage(100);
////////
////////                    Font a10 = new Font(aBold10);
////////                    a10.setColor(BaseColor.WHITE);
////////                    Font a9 = new Font(a10);
////////                    a9.setSize(9);
////////                    Font a8 = new Font(a10);
////////                    a8.setSize(8);
//////////                    c = getCellWithoutBorder(getTexte(GrecoLangue.CADRE_LOGIQUE_DU_PROGRAMME) + " " + cl.getPgCodeProgramme(), aBold12, 7, 1, 20);
//////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
//////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
//////////                    c.setIndent(25);
//////////                    table.addCell(c);
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.PROGRAMME) + " " + cl.getPgCodeProgramme() + ": " + cl.getPgLibelle(), a10), 7, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg1);
////////                    c.setMinimumHeight(50);
////////                    table.addCell(c);
////////                    //
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Actions_du_programme), a9), 2, 2);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Objectif), a9), 1, 2);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Indicateurs), a9), 4, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Libelle), a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Niveau_Ref), a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////                    String t = getTexte(GrecoLangue.Niveau_cible);
////////                    if (anneeIntermediaire != null) {
////////                        t = "Niveau " + anneeIntermediaire;
////////                    }
////////                    c = getCellBorder(new Phrase(t, a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////
////////                    c = getCellBorder(new Phrase(getTexte(GrecoLangue.Source_de_verification), a8), 1, 1);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////                    c.setBackgroundColor(cl_bg2);
////////                    table.addCell(c);
////////                }
////////
////////                if (!ac.equals(cl.getAcCodeAction())) {
////////                    //Nouvelle action
////////                    ac = cl.getAcCodeAction();
////////                    ob = "";
////////                    if (writer != null) {
////////                        float pos = writer.getVerticalPosition(false);
////////                        if (pos < 200) {
////////                            writer.getDirectContent().getPdfDocument().newPage();
////////                        }
////////                    }
////////
////////                    int nbInd = nbIndParAction.get(pg + "." + ac); //ServiceFactory.getActionService().getIndicateursCountByAction(pg.getId());
////////                    if (nbInd <= 0) {
////////                        nbInd = 1;
////////                    }
////////                    c = getCellBorder(new Phrase(ac, aNormal8), 1, nbInd);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_TOP);
////////                    c.setBackgroundColor(cl_bg3);
////////                    table.addCell(c);
////////
////////                    c = getCell(cl.getAcLibelle(), aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP);
////////                    c.setRowspan(nbInd);
////////                    table.addCell(c);
////////                }
////////                if (!ob.equals(cl.getObCode())) {
////////                    ob = cl.getObCode();
////////                    int nbInd = nbIndParObjectif.get(ob); //ServiceFactory.getActionService().getIndicateursCountByAction(pg.getId());
////////                    if (nbInd <= 0) {
////////                        nbInd = 1;
////////                    }
////////                    c = getCellBorder(new Phrase(cl.getObLibelle(), aNormal8), 1, nbInd);
////////                    c.setHorizontalAlignment(PdfPTable.ALIGN_LEFT);
////////                    c.setVerticalAlignment(PdfPTable.ALIGN_TOP);
//////////                    c.setBackgroundColor(cl_bg3);
////////                    table.addCell(c);
////////
////////                }
////////
////////                try {
////////                    table.addCell(getCell(cl.getInLibelle(), aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    table.addCell(getCell(getMontantFormate(cl.getInValeurRef()), aNarrow7, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    table.addCell(getCell(getMontantFormate(anneeIntermediaire == null ? cl.getInValeurCible() : cl.getInValeurIntermediaire1()), aNarrow7, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////                try {
////////                    table.addCell(getCell(cl.getInSourceVerification(), aNarrow7, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                } catch (Exception e) {
////////                    table.addCell(getCell("", aNormal8, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////                }
////////            }
////////            document.add(table);
////////        } catch (Exception e) {
////////        }
    }

    private void addProgramme(String indexPg, GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer,File tmpFile) {
////////        try {
////////            document.add(getParagraphTitle(writer, indexPg/*.concat("a.")*/, getTexte(GrecoLangue.PROGRAMME).toUpperCase() + " " + programme.getPgCodeLRFE() + ": " + programme.getPgLibelle(locale), aBold12, 10));
////////
////////            document.add(getParagraphTitle(writer, indexPg.concat("a."), "", "a. " + getTexte(GrecoLangue.PRESENTATION_PROGRAMME), aNormal12U, 10, false));
////////            eventHelper.addSommaire(indexPg.concat("a."));
////////            parseHtml(getTexte(GrecoLangue.PRESENTATION_PROGRAMME).toUpperCase() + programme.getPgCodeLRFE(), programme.getPgPresentation(locale), writer, document, spaceBefore, tmpFile);
////////            doProgress();
////////
////////            document.add(getParagraphTitle(writer, indexPg.concat("b."), "", "b. " + getTexte(GrecoLangue.STRATEGIE_PROGRAMME), aNormal12U, 0, false));
////////            eventHelper.addSommaire(indexPg.concat("b."));
////////            parseHtml(getTexte(GrecoLangue.STRATEGIE_PROGRAMME).toUpperCase() + programme.getPgCodeLRFE(), programme.getPgPlanStrategique(locale), writer, document, spaceBefore, tmpFile);
////////            doProgress();
////////
////////            document.add(getParagraphTitle(writer, indexPg.concat("c."), "", "c. " + getTexte(GrecoLangue.PRESENTATION_ACTIONS), aNormal12U, 0, false));
////////            eventHelper.addSommaire(indexPg.concat("c."));
////////            List<PrepaAction> actions = PrepaServiceFactory.getDestinationService().getActionsParProgrammeFull(PSFEApp.userConnected.getUtLogin(), programme.getTblPSFEProgrammePK());
////////
////////            for (PrepaAction ac : actions) {
////////                document.add(getSimpleList(getTexte(GrecoLangue.ACTION) + " ".concat(ac.getAcCodeLRFE()).concat(":"), ac.getAcLibelle().toUpperCase(), obFont, aNormal11));
////////                parseHtml("", ac.getAcPresentation(locale), writer, document, 15, tmpFile);
////////            }
////////            doProgress();
////////            document.add(new Paragraph(" "));
////////            document.add(getParagraphTitle(writer, indexPg.concat("d."), "", "d. " + getTexte(GrecoLangue.CADRE_LOGIQUE_PROGRAMME), aNormal12U, 0, false));
////////            eventHelper.addSommaire(indexPg.concat("d."));
////////            addCadreLogique(null, programme, document, writer);
////////            doProgress();
////////
////////        } catch (Exception e) {
////////        }
    }

    private void addChapitre1(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, File tmpFile) {
        try {
            List l = new ArrayList();
//            addPageIntercallaire(eventHelper, document, writer, false, " ");
            l.add("1.");
            l.add("");
            l.addAll(GrecoPdfPageEventHelper.getListeTexte(writer.getDirectContent(), getTexte(GrecoDocNode.CHAPITRE_1).toUpperCase(), aBig22, (document.getPageSize().getWidth() * 4) / 5, false));
            eventHelper.setPrintHeader(false);
            eventHelper.setPrintFooter(false);
            if (eventHelper.getCurrentPage() % 2 == 1) {
                document.newPage();
                document.add(new Paragraph(" "));
            }

            addSectionMainPage(eventHelper, document, writer, "", l, aBig22);
            eventHelper.addSommaire("1.");
            eventHelper.setTextForHeader(getTexte(GrecoDocNode.CHAPITRE_1).toUpperCase());
            doProgress();
            document.newPage();
            document.add(new Paragraph(" "));
            eventHelper.setPrintHeader(true);
            eventHelper.setPrintFooter(true);
            document.newPage();
            document.add(new Paragraph(" "));
            document.add(getParagraphTitle(writer, "1.1.", getTexte(GrecoDocNode.SECTION_11).toUpperCase(), aBold12, spaceBefore));
            parseHtml("1.1.", cdmt.getSection11(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "1.1.1.", getTexte(GrecoDocNode.PARAGRAPHE_111).toUpperCase(), aBold12, spaceBefore));
            parseHtml("1.1.1.", cdmt.getParagraphe111(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "1.1.2.", getTexte(GrecoDocNode.PARAGRAPHE_112).toUpperCase(), aBold12, spaceBefore));
            parseHtml("1.1.2.", cdmt.getParagraphe112(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "1.1.3.", getTexte(GrecoDocNode.PARAGRAPHE_113).toUpperCase(), aBold12, spaceBefore));
            parseHtml("1.1.3.", cdmt.getParagraphe113(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "1.2.", getTexte(GrecoDocNode.SECTION_12).toUpperCase(), aBold12, spaceBefore));
            parseHtml("1.2.", cdmt.getSection12(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(new Paragraph(" "));
            document.add(getParagraphTitle(writer, "", "", getTexte(GrecoLangue.CADRE_LOGIQUE_CHAPITRE), aNormal12U, 0, false));
            addCadreLogiqueChapitre(null, document, writer);

            doProgress();
            int indPg = 1;
////////            for (PrepaProgramme p : programmes) {
////////                addProgramme("1.2." + indPg++ + ".", eventHelper, document, writer, p, tmpFile);
////////                document.add(new Paragraph(" "));
////////            }
//            document.add(getParagraphTitle(writer, "1.2.1.", getTexte(GrecoDocNode.PARAGRAPHE_121).toUpperCase(), aBold12, spaceBefore));
//            parseHtml("1.2.1.", cdmt.getParagraphe121(locale), writer, document, spaceBefore, tmpFile);
//            doProgress();
//            document.add(getParagraphTitle(writer, "1.2.2.", getTexte(GrecoDocNode.PARAGRAPHE_122).toUpperCase(), aBold12, spaceBefore));
//            parseHtml("1.2.2.", cdmt.getParagraphe122(locale), writer, document, spaceBefore, tmpFile);
//            doProgress();
        } catch (Exception e) {
        }
    }

    private void addChapitre2(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, File tmpFile) {
        try {
            List l = new ArrayList();
//            addPageIntercallaire(eventHelper, document, writer, false, " ");
            l.add("2.");
            l.add("");
            l.addAll(GrecoPdfPageEventHelper.getListeTexte(writer.getDirectContent(), getTexte(GrecoDocNode.CHAPITRE_2).toUpperCase(), aBig22, (document.getPageSize().getWidth() * 4) / 5, false));
            eventHelper.setPrintHeader(false);
            eventHelper.setPrintFooter(false);
            if (eventHelper.getCurrentPage() % 2 == 1) {
                document.newPage();
                document.add(new Paragraph(" "));
            }

            addSectionMainPage(eventHelper, document, writer, "", l, aBig22);
            eventHelper.addSommaire("2.");
            eventHelper.setTextForHeader(getTexte(GrecoDocNode.CHAPITRE_2).toUpperCase());
            doProgress();
            document.newPage();
            document.add(new Paragraph(" "));
            eventHelper.setPrintHeader(true);
            eventHelper.setPrintFooter(true);
            document.newPage();
            document.add(new Paragraph(" "));
            document.add(getParagraphTitle(writer, "2.1.", getTexte(GrecoDocNode.SECTION_21).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.1.", cdmt.getSection21(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.1.1.", getTexte(GrecoDocNode.PARAGRAPHE_211).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.1.1.", cdmt.getParagraphe211(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.1.2.", getTexte(GrecoDocNode.PARAGRAPHE_212).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.1.2.", cdmt.getParagraphe212(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.1.3.", getTexte(GrecoDocNode.PARAGRAPHE_213).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.1.3.", cdmt.getParagraphe213(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.2.", getTexte(GrecoDocNode.SECTION_22).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.2.", cdmt.getSection22(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.2.1.", getTexte(GrecoDocNode.PARAGRAPHE_221).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.2.1.", cdmt.getParagraphe221(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.2.2.", getTexte(GrecoDocNode.PARAGRAPHE_222).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.2.2.", cdmt.getParagraphe222(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.2.3.", getTexte(GrecoDocNode.PARAGRAPHE_223).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.2.3.", cdmt.getParagraphe223(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.3.", getTexte(GrecoDocNode.SECTION_23).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.3.", cdmt.getSection23(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.3.1.", getTexte(GrecoDocNode.PARAGRAPHE_231).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.3.1.", cdmt.getParagraphe221(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "2.3.2.", getTexte(GrecoDocNode.PARAGRAPHE_232).toUpperCase(), aBold12, spaceBefore));
            parseHtml("2.3.2.", cdmt.getParagraphe222(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
        } catch (Exception e) {
        }
    }

    private void addChapitre3(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, File tmpFile) {
        try {
            List l = new ArrayList();
            addPageIntercallaire(eventHelper, document, writer, false, " ");
            l.add("3.");
            l.add("");
            l.addAll(GrecoPdfPageEventHelper.getListeTexte(writer.getDirectContent(), getTexte(GrecoDocNode.CHAPITRE_3).toUpperCase(), aBig22, (document.getPageSize().getWidth() * 4) / 5, false));
            eventHelper.setPrintHeader(false);
            eventHelper.setPrintFooter(false);
            if (eventHelper.getCurrentPage() % 2 == 1) {
                document.newPage();
                document.add(new Paragraph(" "));
            }

            addSectionMainPage(eventHelper, document, writer, "", l, aBig22);
            eventHelper.addSommaire("3.");
            eventHelper.setTextForHeader(getTexte(GrecoDocNode.CHAPITRE_3).toUpperCase());
            doProgress();
            document.newPage();
            document.add(new Paragraph(" "));
            eventHelper.setPrintHeader(true);
            eventHelper.setPrintFooter(true);
            document.newPage();
            document.add(new Paragraph(" "));
            document.add(getParagraphTitle(writer, "3.1.", getTexte(GrecoDocNode.SECTION_31).toUpperCase(), aBold12, spaceBefore));
            parseHtml("3.1.", cdmt.getSection31(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "3.2.", getTexte(GrecoDocNode.SECTION_32).toUpperCase(), aBold12, spaceBefore));
            parseHtml("3.2.", cdmt.getSection32(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "3.3.", getTexte(GrecoDocNode.SECTION_33).toUpperCase(), aBold12, spaceBefore));
            parseHtml("3.3.", cdmt.getSection33(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
////////            addTableau33(chapitre.getTblChapitrePK(), document);
////////            doProgress();
            
        } catch (Exception e) {
        }
    }

    private void addChapitre4(GrecoPdfPageEventHelper eventHelper, Document document, PdfWriter writer, File tmpFile) {
        try {
            List l = new ArrayList();
//            addPageIntercallaire(eventHelper, document, writer, false, " ");
            l.add("4.");
            l.add("");
            l.addAll(GrecoPdfPageEventHelper.getListeTexte(writer.getDirectContent(), getTexte(GrecoDocNode.CHAPITRE_4).toUpperCase(), aBig22, (document.getPageSize().getWidth() * 4) / 5, false));
            eventHelper.setPrintHeader(false);
            eventHelper.setPrintFooter(false);
            if (eventHelper.getCurrentPage() % 2 == 1) {
                document.newPage();
                document.add(new Paragraph(" "));
            }

            addSectionMainPage(eventHelper, document, writer, "", l, aBig22);
            eventHelper.addSommaire("4.");
            eventHelper.setTextForHeader(getTexte(GrecoDocNode.CHAPITRE_4).toUpperCase());
            doProgress();
            document.newPage();
            document.add(new Paragraph(" "));
            eventHelper.setPrintHeader(true);
            eventHelper.setPrintFooter(true);
            document.newPage();
            document.add(new Paragraph(" "));
            document.add(getParagraphTitle(writer, "4.1.", getTexte(GrecoDocNode.SECTION_41).toUpperCase(), aBold12, spaceBefore));
            parseHtml("4.1.", cdmt.getSection41(locale), writer, document, spaceBefore, tmpFile);
////////            for (PrepaProgramme p : programmes) {
////////                addCadreLogique(anneeDeb + 1, p, document, writer);
////////                document.add(new Paragraph(" "));
////////            }
            doProgress();
            document.add(getParagraphTitle(writer, "4.2.", getTexte(GrecoDocNode.SECTION_42).toUpperCase(), aBold12, spaceBefore));
            parseHtml("4.2.", cdmt.getSection42(locale), writer, document, spaceBefore, tmpFile);
            doProgress();
            document.add(getParagraphTitle(writer, "4.3.", getTexte(GrecoDocNode.SECTION_43).toUpperCase(), aBold12, spaceBefore));
            parseHtml("4.3.", cdmt.getSection43(locale), writer, document, spaceBefore, tmpFile);
////////            addTableauBudget(
////////                    Integration.getElaborationReportService().getElab2015BudgetAeCpNatDepParProgramme(
////////                            chapitre.getTblChapitrePK().getExMillesime(), chapitre.getTblChapitrePK().getChCodeChapitre(), locale.equals(Locale.ENGLISH)),
////////                    document, writer);
////////            doProgress();
        } catch (Exception e) {
        }
    }

    private PdfPTable getParagraphTitle(PdfWriter writer, String tag, /*String num,*/ String libelle, Font f11/*, Font f2*/, float spaceBefore) {
        return getParagraphTitle(writer, tag, tag, libelle, f11, spaceBefore, true);
    }

    private PdfPTable getParagraphTitle(PdfWriter writer, String tag, String num, String libelle, Font f11, float spaceBefore, boolean upper) {
        if (writer != null) {
            float pos = writer.getVerticalPosition(false);
            if (pos < 170) {
                writer.getDirectContent().getPdfDocument().newPage();
            }
        }
        //String num = tag;
        float[] widths1 = {1f, 11f};
        PdfPTable table = new PdfPTable(widths1);

        table.setWidthPercentage(95);
        table.setHorizontalAlignment(Element.ALIGN_RIGHT);
        String libelle2 = "";
        PdfPCell cell1 = new PdfPCell();
        Chunk c = new Chunk(num, f11);
        if (!StringUtil.isNullOrEmpty(tag)) {
            c.setGenericTag(tag);
        }
        Paragraph p = new Paragraph(c);
//        p.setAlignment(Element.ALIGN_TOP);
        p.setSpacingAfter(0);
        cell1.addElement(p);

        PdfPCell cell2 = new PdfPCell();
        p = new Paragraph();
//        p.setAlignment(Element.ALIGN_TOP);
//        p.setSpacingAfter(3);
        c = new Chunk(upper ? libelle.trim().toUpperCase() : libelle.trim(), f11);
        if (StringUtil.isNullOrEmpty(tag)) {
            c.setGenericTag("TITRE");
        }
        p.add(c);

        cell1.setBorder(0);
        cell2.setBorder(0);

        table.setSpacingBefore(spaceBefore);//25);
//        table.setSpacingAfter(10);//25);

        table.addCell(cell1);
        if (StringUtil.isNullOrEmpty(libelle2)) {
            cell2.addElement(p);
            table.addCell(cell2);
            return table;
        }

        p.add(new Chunk(upper ? libelle2.trim().toUpperCase() : libelle2.trim(), f11));
        cell2.addElement(p);
        table.addCell(cell2);
        return table;
    }

    private PdfPTable getSimpleList(String num, String libelle, Font f1, Font f2) {
        float[] widths1 = {0.1f, 1.7f, 8.2f};
        PdfPTable table = new PdfPTable(widths1);
        table.setWidthPercentage(100);
        table.setHorizontalAlignment(PdfPTable.ALIGN_RIGHT);
        PdfPCell cell0 = new PdfPCell();
        cell0.setBorder(0);

        PdfPCell cell1 = new PdfPCell();
        Chunk c = new Chunk(num, f1);
        cell1.addElement(c);

        PdfPCell cell2 = new PdfPCell();
        c = new Chunk(libelle.trim(), f2);
        cell2.addElement(c);

        cell1.setBorder(0);
        cell2.setBorder(0);

        cell1.setVerticalAlignment(Element.ALIGN_TOP);
        cell1.setHorizontalAlignment(Element.ALIGN_CENTER);
        cell2.setVerticalAlignment(Element.ALIGN_TOP);
        cell1.setHorizontalAlignment(Element.ALIGN_JUSTIFIED);

        table.addCell(cell0);
        table.addCell(cell1);
        table.addCell(cell2);
        return table;
    }

    public static String extractTextFromHtml(String source) {
        if (StringUtil.isNullOrEmpty(source)) {
            source = "";
        }
        try {
            String result;

            // Remove HTML Development formatting
            // Replace line breaks with space
            // because browsers inserts space
            result = source.toLowerCase().replace("\r", " ");
            // Replace line breaks with space
            // because browsers inserts space
            result = result.replace("\n", " ");
            // Remove step-formatting
            result = result.replace("\t", "");
            // Remove repeating spaces because browsers ignore them

            result = result.replaceAll("( )+", " ");

            // Remove the header (prepare first by clearing attributes)
            result = result.replaceAll("<( )*head([^>])*>", "<head>");
            result = result.replaceAll("(<( )*(/)( )*head( )*>)", "</head>");
            result = result.replaceAll("(<head>).*(</head>)", "");

            // remove all scripts (prepare first by clearing attributes)
            result = result.replaceAll("<( )*script([^>])*>", "<script>");
            result = result.replaceAll("(<( )*(/)( )*script( )*>)", "</script>");
            //result = result.replaceAll(
            //         @"(<script>)([^(<script>\.</script>)])*(</script>)",
            //         ""
            //         );
            result = result.replaceAll("(<script>).*(</script>)", "");

            // remove all styles (prepare first by clearing attributes)
            result = result.replaceAll("<( )*style([^>])*>", "<style>");
            result = result.replaceAll("(%<( )*(/)( )*style( )*>)", "</style>");
            result = result.replaceAll("(<style>).*(</style>)", "");

            // insert tabs in spaces of <td> tags
            result = result.replaceAll("<( )*td([^>])*>", "\t");

            // insert line breaks in places of <BR> and <LI> tags
            result = result.replaceAll("<( )*br( )*>", "\r");
            result = result.replaceAll("<( )*li( )*>", "\r");

            // insert line paragraphs (double line breaks) in place
            // if <P>, <DIV> and <TR> tags
            result = result.replaceAll("<( )*div([^>])*>", "\r\r");
            result = result.replaceAll("<( )*tr([^>])*>", "\r\r");
            result = result.replaceAll("<( )*p([^>])*>", "\r\r");

            // Remove remaining tags like <a>, links, images,
            // comments etc - anything that's enclosed inside < >
            result = result.replaceAll("<[^>]*>", "");

            // replace special characters:
            result = result.replaceAll("&bull;", " * ");
            result = result.replaceAll("&lsaquo;", "<");
            result = result.replaceAll("&rsaquo;", ">");
            result = result.replaceAll("&trade;", "(tm)");
            result = result.replaceAll("&frasl;", "/");
            result = result.replaceAll("&lt;", "<");
            result = result.replaceAll("&gt;", ">");
            result = result.replaceAll("&copy;", "(c)");
            result = result.replaceAll("&reg;", "(r)");
            // Remove all others. More can be added, see
            // http://hotwired.lycos.com/webmonkey/reference/special_characters/
            result = result.replaceAll("&(.{2,6});", "");

            // for testing
            //result.replaceAll(
            //       this.txtRegex.Text,""
            //       );
            // make line breaking consistent
            result = result.replace("\n", "\r");

            // Remove extra line breaks and tabs:
            // replace over 2 breaks with 2 and over 4 tabs with 4.
            // Prepare first to remove any whitespaces in between
            // the escaped characters and remove redundant tabs in between line breaks
            result = result.replaceAll("(\r)( )+(\r)", "");// "\r\r");
            result = result.replaceAll("(\t)( )+(\t)", "");// "\t\t");
            result = result.replaceAll("(\t)( )+(\r)", "");// "\t\r");
            result = result.replaceAll("(\r)( )+(\t)", "");// "\r\t");
            // Remove redundant tabs
            result = result.replaceAll("(\r)(\t)+(\r)", "");// "\r\r");
            // Remove multiple tabs following a line break with just one tab
            result = result.replaceAll("(\r)(\t)+", "");// "\r\t");
            // Initial replacement target string for line breaks
//            String breaks = "\r\r\r";
//            // Initial replacement target string for tabs
//            String tabs = "\t\t\t\t\t";
//            for (int index = 0; index < result.length(); index++) {
//                result = result.replace(breaks, "\r\r");
//                result = result.replace(tabs, "\t\t\t\t");
//                breaks = breaks + "\r";
//                tabs = tabs + "\t";
//            }

            // That's it.
            return result.trim();
        } catch (Exception ex) {
            return source;
        }
    }

    private String getLibelleUnite() {
        switch (unite) {
            case 1:
                return getTexte(GrecoLangue.EN_FCFA);
            case 1000:
                return getTexte(GrecoLangue.EN_Milliers_FCFA);
        }
        return "";
    }

    private JasperPrint getAnnexePrograFin(String niveau, int startPage, String titre, String libelleAnnexe) {
        JasperPrint print = null;
////////        try {
////////            //Obtention des données
////////            List list = Integration.getElaborationReportService().getElabTableauPrograFin(chapitre.getTblChapitrePK().getExMillesime(),
////////                    chapitre.getTblChapitrePK().getChCodeChapitre(), "BIP", niveau.replace("AT", ""), Long.valueOf(unite), null);
////////            if (list == null) {
////////                list = new ArrayList();
////////            }
////////            if (list.isEmpty()) {
////////                list.add(new VueElabTableauPrograFin());
////////            }
////////            doProgress();
////////            // generation du pdf
////////            HashMap param = reportElab.mainParameters(pyramide);
////////            param.put("PARAM_Niveau", niveau);
////////            param.put("PARAM_Titre", titre);
////////            param.put("PARAM_DebutPage", startPage);
////////            param.put("PARAM_Page_Prefix", "");
////////            param.put("PARAM_Page_Suffixe", "");
////////            param.put("lbl_Unite", getLibelleUnite());
////////            param.put("lbl_Unite_FR", getLibelleUnite());
////////            if (!StringUtil.isNullOrEmpty(libelleAnnexe)) {
////////                param.put("annexe", libelleAnnexe);
////////            }
////////
////////            print = JRHelper.getJasperPrint(niveau.equals("AT") ? reportElab.programmationFinanciereAtTa() : reportElab.programmationFinancierePgAc(), param, new JRBeanCollectionDataSource(list));
////////        } catch (Exception e) {
////////        }
        return print;
    }

    private JasperPrint getAnnexe(int index, int startPage) {
        JasperPrint print = null;
////////        try {
////////            // generation du pdf
////////            HashMap param = reportElab.mainParameters(pyramide);
////////            param.put("PARAM_DebutPage", (print == null) ? startPage : startPage + print.getPages().size());
////////            param.put("PARAM_Page_Prefix", "");
////////            param.put("PARAM_Page_Suffixe", "");
////////            param.put("PARAM_Draft", "");
////////            param.put("PARAM_Draft", "");
////////            param.put("lbl_Unite", getLibelleUnite);
////////            param.put("lbl_Unite_FR", getLibelleUnite);
////////            if (index == 5) {
////////                String exMillesime = chapitre.getTblChapitrePK().getExMillesime();
////////                String chCode = chapitre.getTblChapitrePK().getChCodeChapitre();
////////                String typeBudget = null;
////////                String niveau = null;
////////                int unite = 1000;
////////                Boolean resIn = null;
////////                Date dateDebut = null;
////////                Date dateFin = null;
////////                List list = Integration.getElaborationReportService().getTableauPrograFinPgGm(exMillesime, chCode, typeBudget, niveau, unite, resIn, dateDebut, dateFin);
////////                if (list == null) {
////////                    list = new ArrayList();
////////                }
////////                if (list.isEmpty()) {
////////                    list.add(new VueElabTableauPrograFinPgGm());
////////                }
////////                print = JRHelper.getJasperPrint(reportElab.programmationFinancierePgGm(), param, new JRBeanCollectionDataSource(list));
////////            } else {
////////                print = JRHelper.getJasperPrint(reportsPrepa.budgetEtatPageVierge(), param, new JRBeanCollectionDataSource(Collections.EMPTY_LIST));
////////            }
////////        } catch (Exception e) {
////////        }
        return print;
    }
   
    private JasperPrint getMatriceCadreLogique(int startPage, String libelleAnnexe) {
        JasperPrint print = null;
////////        for (VueTacheBrowserEntete2 pg : PrepaServiceFactory.getDestinationService().getProgrammesAllegesPS(chapitre.getTblChapitrePK())) {
////////            try {
////////                //Obtention des données
////////                List list = Integration.getElaborationReportService().getElab2015MatriceCadreLogique(pg.getId());
////////                if (list == null) {
////////                    list = new ArrayList();
////////                }
////////                if (list.isEmpty()) {
////////                    list.add(new VueElabMatriceCadreLogique());
////////                }
////////                doProgress();
////////                // generation du pdf
////////                HashMap param = reportElab.mainParameters(pyramide);
//////////            param.put("PARAM_Niveau", niveau);
//////////            param.put("PARAM_Titre", titre);
////////                param.put("PARAM_DebutPage", (print == null) ? startPage : startPage + print.getPages().size());
////////                param.put("PARAM_Page_Prefix", "");
////////                param.put("PARAM_Page_Suffixe", "");
////////                if (!StringUtil.isNullOrEmpty(libelleAnnexe)) {
////////                    param.put("annexe", libelleAnnexe);
////////                }
////////                print = JRHelper.mergeDocuments(print, JRHelper.getJasperPrint(reportElab.matriceCadreLogique(), param, new JRBeanCollectionDataSource(list)));
////////            } catch (Exception e) {
////////            }
////////        }
        return print;
    }

    public String getTitlePage(String id, int currentPage, String code, String texte1) {
        return getTitlePage(id, currentPage, code, texte1, "");
    }

    public String getTitlePage(String id, int currentPage, String code, String texte1, String texte2) {
        texte1 = texte1.toUpperCase();
        texte2 = texte2.toUpperCase();
        Rectangle pagesize = new Rectangle(PageSize.A4);
        // 28pts = 1cm
        // 42pts = 1.5cm
        // 70pts = 2.5cm
        Document document = new Document(pagesize, 42, 42, 52, 28); //Old 70

        String path = null;
        try {
            //Path dir = Files.createTempDirectory("probmis", f);
            File fich = File.createTempFile("probmis", "cdmt");
            path = fich.getParentFile().getPath() + "/HtmlTransformed" + id + ".pdf";

            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
            GrecoPdfPageEventHelper eventHelper = new GrecoPdfPageEventHelper(enteteLFI, getTexte(GrecoLangue.CDMT), null, baseFontNameNarrow, baseFontNameNarrowBold, locale, colCdmt);
            writer.setPageEvent(eventHelper);
            writer.setLinearPageMode();
            document.open();
            doProgress();
            document.addTitle(getTexte(GrecoLangue.CDMT) + " " + anneeDeb + "-" + anneeFin);
////////            document.addSubject(chapitre.getAbreviationWithCode());
            document.addCreator("PROBMIS");
            document.addAuthor("MINFI");

            // DEBUT DOCUMENT
            doProgress();
            List l = new ArrayList();
//            addPageIntercallaire(eventHelper, document, writer, false, " ");
            l.add(code);
            l.add("");
            l.addAll(GrecoPdfPageEventHelper.getListeTexte(writer.getDirectContent(), texte1, aBig22, (document.getPageSize().getWidth() * 4) / 5, false));
            l.addAll(GrecoPdfPageEventHelper.getListeTexte(writer.getDirectContent(), texte2, aBig22, (document.getPageSize().getWidth() * 4) / 5, false));
            eventHelper.setPrintHeader(false);
            eventHelper.setPrintFooter(false);
            if (currentPage % 2 == 0) {
                document.newPage();
                document.add(new Paragraph(" "));
            }

            addSectionMainPage(eventHelper, document, writer, "", l, aBig22);
//            eventHelper.addSommaire(code);
//            eventHelper.setTextForHeader(texte);
//            doProgress();
            document.newPage();
            document.add(new Paragraph(" "));
//            eventHelper.setPrintHeader(true);
//            eventHelper.setPrintFooter(true);
//            document.newPage();
//            document.add(new Paragraph(" "));
////            parseHtml(getTexte(GrecoLangue.CHAPITRE_4_CODE).toUpperCase(), "" + ppa.getPpaPrioriteNationale(locale), writer, document, spaceBefore, tmpFile);
//            doProgress();

            document.close();
            // FIN DOCUMENT
            //document.newPage();
        } catch (Exception ex) {
            path = null;
        }
        return path;
    }

    public String getDocumentPart(String id) {
        Rectangle pagesize = new Rectangle(PageSize.A4);
        // 28pts = 1cm
        // 42pts = 1.5cm
        // 70pts = 2.5cm
        Document document = new Document(pagesize, 42, 42, 52, 28); //Old 70

        String path = null;
        try {
            //Path dir = Files.createTempDirectory("probmis", f);
            File fich = File.createTempFile("probmis", "cdmt");
            path = fich.getParentFile().getPath() + "/HtmlTransformed" + id + ".pdf";

            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
            GrecoPdfPageEventHelper eventHelper = new GrecoPdfPageEventHelper(enteteLFI, getTexte(GrecoLangue.CDMT),  null, baseFontNameNarrow, baseFontNameNarrowBold, locale, colCdmt);
            writer.setPageEvent(eventHelper);
            writer.setLinearPageMode();
            document.open();
            doProgress();
            document.addTitle(getTexte(GrecoLangue.CDMT) + " " + anneeDeb + "-" + anneeFin);
////////            document.addSubject(chapitre.getAbreviationWithCode());
            document.addCreator("PROBMIS");
            document.addAuthor("MINFI");

            // DEBUT DOCUMENT
            document.close();
            // FIN DOCUMENT
            //document.newPage();
        } catch (Exception ex) {
            path = null;
        }
        return path;
    }

    public String getDocumentStart(String id, List sommaires) {
        Rectangle pagesize = new Rectangle(PageSize.A4);
        // 28pts = 1cm
        // 42pts = 1.5cm
        // 70pts = 2.5cm
        Document document = new Document(pagesize, 42, 42, 52, 28); //Old 70

        String path = null;
        try {
            //Path dir = Files.createTempDirectory("probmis", f);
            File fich = File.createTempFile("probmis", "cdmt");
            path = fich.getParentFile().getPath() + "/HtmlTransformed" + id + ".pdf";

            PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(path));
            GrecoPdfPageEventHelper eventHelper = new GrecoPdfPageEventHelper(enteteLFI, getTexte(GrecoLangue.CDMT), null, baseFontNameNarrow, baseFontNameNarrowBold, locale, colCdmt);
            writer.setPageEvent(eventHelper);
            writer.setLinearPageMode();
            document.open();
            doProgress();
            document.addTitle(getTexte(GrecoLangue.CDMT) + " " + anneeDeb + "-" + anneeFin);
////////            document.addSubject(chapitre.getAbreviationWithCode());
            document.addCreator("PROBMIS");
            document.addAuthor("MINFI");

            // DEBUT DOCUMENT
            addPageDeGarde(eventHelper, document, writer, baseFontName);
            doProgress();
            addSommaire(sommaires, eventHelper, document, writer, true);
            doProgress();

            document.close();
            // FIN DOCUMENT
            //document.newPage();
        } catch (Exception ex) {
            path = null;
        }
        return path;
    }

    private int copiePage(PdfCopy copy, String fileName) {
        return copiePage(copy, fileName, 1);
    }

    private int copiePage(PdfCopy copy, String fileName, int startPage) {
        int copie = 0;
        try {
            PdfReader rAnnexe = new PdfReader(fileName);
            doProgress();

            for (int i = startPage - 1; i < rAnnexe.getNumberOfPages(); i++) {
                copy.addPage(copy.getImportedPage(rAnnexe, i + 1));
                copie++;
            }
            rAnnexe.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return copie;
    }

    private int copiePage(PdfCopy copy, byte[] fileName) {
        int copie = 0;
        try {
            PdfReader rAnnexe = new PdfReader(fileName);
            doProgress();
            for (int i = 0; i < rAnnexe.getNumberOfPages(); i++) {
                copy.addPage(copy.getImportedPage(rAnnexe, i + 1));
                copie++;
            }
            rAnnexe.close();
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return copie;
    }


    private PdfPCell getCellBorder(String texte, Font f, int colSpan, int rowSpan, int hAlign, boolean top, boolean bottom, boolean left, boolean right) {
        PdfPCell c = new PdfPCell(new Phrase(texte, f));
        c.setRowspan(rowSpan);
        c.setColspan(colSpan);
//        c.setBorder(1);
//        c.setBorderWidth(0.25F);
        if (!bottom) {
            c.setBorderWidthBottom(0F);
        }
        if (!left) {
            c.setBorderWidthLeft(0F);
        }
        if (!right) {
            c.setBorderWidthRight(0F);
        }
        if (!top) {
            c.setBorderWidthTop(0F);
        }
        c.setHorizontalAlignment(hAlign);
        c.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return c;
    }

    private PdfPCell getCellBorder(String texte, Font f, int colSpan, int rowSpan, boolean top, boolean bottom, boolean left, boolean right) {
        return getCellBorder(texte, f, colSpan, rowSpan, Element.ALIGN_CENTER, top, bottom, left, right);
    }

    private PdfPCell getCellWithoutBorder(String texte, Font f, int colSpan, int rowSpan, float height, int hAlign) {
        PdfPCell c = new PdfPCell(new Phrase(texte, f));
        c.setBorder(0);
        c.setRowspan(rowSpan);
        c.setColspan(colSpan);
        if (height > 0) {
            c.setFixedHeight(height);
        }
        c.setHorizontalAlignment(hAlign);
        c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
        return c;
    }

    private PdfPCell getCellWithoutBorder(String texte, Font f, int colSpan, int rowSpan, float height) {
        return getCellWithoutBorder(texte, f, colSpan, rowSpan, height, PdfPTable.ALIGN_CENTER);
    }

    private PdfPCell getCellBorder(Phrase texte, int colSpan, int rowSpan) {
        PdfPCell c = new PdfPCell(texte);
        c.setRowspan(rowSpan);
        c.setColspan(colSpan);
//        c.setHorizontalAlignment(hAlign);
//        c.setVerticalAlignment(Element.ALIGN_MIDDLE);
        return c;
    }

    private PdfPCell getCell(String texte, Font f, int hAlign, int vAlign, BaseColor bgColor, Float minimumHeight) {
        try {
            PdfPCell c = new PdfPCell(new Phrase(texte, f));
            c.setHorizontalAlignment(hAlign);
            c.setVerticalAlignment(vAlign);
            c.setBackgroundColor(bgColor);
            if (minimumHeight != null) {
                c.setMinimumHeight(minimumHeight);
            }
            return c;
        } catch (Exception e) {
            return new PdfPCell();
        }
    }

    private PdfPCell getCell(String texte, Font f, int hAlign, int vAlign) {
        return getCell(texte, f, hAlign, vAlign, BaseColor.WHITE, defaultCellMinHeight);
    }

    private PdfPCell getCell(String texte, Font f, int hAlign, int vAlign, Float minimumHeight) {
        return getCell(texte, f, hAlign, vAlign, BaseColor.WHITE, minimumHeight);
    }

    private String getMontantFormate(Number montant) {
        String ch = StringUtil.formatNumber(montant);
        return StringUtil.isNullOrEmpty(ch) ? " " : ch;
    }


    private void addTableau33(Document document) {

////////        List<VueElabTableauPrograFin> list = Integration.getElaborationReportService().getElabTableauPrograFin(pk.getExMillesime(), pk.getChCodeChapitre(), null, "PG_BF_BIP", Long.valueOf(unite), null);
////////        if (list == null) {
////////            list = new ArrayList();
////////        }
////////        if (list.isEmpty()) {
////////            list.add(new VueElabTableauPrograFin());
////////        }
////////        try {
////////
//////////            BaseColor cl_bg1 = new BaseColor(0, 0, 51);
////////            BaseColor cl_bg2 = colCdmt;//new BaseColor(136, 176, 97);
//////////            BaseColor cl_bg3 = new BaseColor(212, 235, 189);
////////
////////            float[] widths1 = {231, 80, 80, 80, 80};
////////            PdfPTable table = null;
////////            PdfPCell c;
////////
////////            table = new PdfPTable(widths1);
////////            table.setSpacingBefore(spaceBefore);
////////            table.setWidthPercentage(100);
////////
////////            Font a10 = new Font(aBold10);
////////            a10.setColor(BaseColor.WHITE);
////////            Font a9 = new Font(a10);
////////            a9.setSize(9);
////////            Font a8 = new Font(a10);
////////            a8.setSize(8);
////////            //
////////            table.addCell(getCellWithoutBorder(" ", aNormal6, 4, 1, 10));
////////            table.addCell(getCellWithoutBorder(getTexte(GrecoLangue.EN_FCFA), aNormal6, 1, 1, 10, PdfPTable.ALIGN_CENTER));
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.PROGRAMMES), a8), 1, 3);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setMinimumHeight(45);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.Programmation_financiere_N_N2), a8), 4, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            c.setMinimumHeight(20);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.ANNEE_N), a8), 2, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setFixedHeight(20);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.ANNEE_N1), a8), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.ANNEE_N2), a8), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.AE), a8), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.CP), a8), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.CP), a8), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            c = getCellBorder(new Phrase(getTexte(GrecoLangue.CP), a8), 1, 1);
////////            c.setHorizontalAlignment(PdfPTable.ALIGN_CENTER);
////////            c.setVerticalAlignment(PdfPTable.ALIGN_MIDDLE);
////////            c.setBackgroundColor(cl_bg2);
////////            table.addCell(c);
////////
////////            BigDecimal ae = BigDecimal.ZERO;
////////            BigDecimal cp1 = BigDecimal.ZERO;
////////            BigDecimal cp2 = BigDecimal.ZERO;
////////            BigDecimal cp3 = BigDecimal.ZERO;
////////
////////            BigDecimal tae = BigDecimal.ZERO;
////////            BigDecimal tcp1 = BigDecimal.ZERO;
////////            BigDecimal tcp2 = BigDecimal.ZERO;
////////            BigDecimal tcp3 = BigDecimal.ZERO;
////////
////////            HashMap<VueElabTableauPrograFin, List<VueElabTableauPrograFin>> map = new HashMap();
////////
////////            VueElabTableauPrograFin cour = list.get(0).getCopie();
////////
////////            List<VueElabTableauPrograFin> prog = new ArrayList<>();
////////            List<VueElabTableauPrograFin> detail = new ArrayList<>();
////////
////////            for (VueElabTableauPrograFin p : list) {
////////                try {
////////                    if (!p.getPgCodeLRFE().equals(cour.getPgCodeLRFE())) {
////////                        //Nouveau programme
////////                        cour.setAe(ae);
////////                        cour.setCp1(cp1);
////////                        cour.setCp2(cp2);
////////                        cour.setCp3(cp3);
////////
////////                        map.put(cour, detail);
////////                        prog.add(cour);
////////                        ae = BigDecimal.ZERO;
////////                        cp1 = BigDecimal.ZERO;
////////                        cp2 = BigDecimal.ZERO;
////////                        cp3 = BigDecimal.ZERO;
////////                        detail = new ArrayList<>();
////////                        cour = p.getCopie();
////////                        detail.add(p);
////////                    } else {
////////                        detail.add(p);
////////                    }
////////
////////                    try {
////////                        ae = ae.add(p.getAe());
////////                        tae = tae.add(p.getAe());
////////                    } catch (Exception e) {
////////                    }
////////                    try {
////////                        cp1 = cp1.add(p.getCp1());
////////                        tcp1 = tcp1.add(p.getCp1());
////////                    } catch (Exception e) {
////////                    }
////////                    try {
////////                        cp2 = cp2.add(p.getCp2());
////////                        tcp2 = tcp2.add(p.getCp2());
////////                    } catch (Exception e) {
////////                    }
////////                    try {
////////                        cp3 = cp3.add(p.getCp3());
////////                        tcp3 = tcp3.add(p.getCp3());
////////                    } catch (Exception e) {
////////                    }
////////
////////                } catch (Exception e) {
////////                    String ch = "";
////////                }
////////            }
////////            map.put(cour, detail);
////////            prog.add(cour);
////////
////////            for (VueElabTableauPrograFin pg : prog) {
////////                c = new PdfPCell();
////////                c.addElement(new Paragraph(getTexte(GrecoLangue.PROGRAMME) + " " + pg.getPgCodeLRFE(), aBold9U));
////////                //getCell(fromLocal(pg.getPgLibelleFrancais(), pg.getPgLibelleAnglais()), aBold9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP)
////////                c.addElement(new Phrase(fromLocal(pg.getPgLibelleFrancais(), pg.getPgLibelleAnglais()), aBold9));
////////                table.addCell(c);
////////
////////                addFormattedCell(table, pg.getAe(), 1, 1, true);
////////                addFormattedCell(table, pg.getCp1(), 1, 1, true);
////////                addFormattedCell(table, pg.getCp2(), 1, 1, true);
////////                addFormattedCell(table, pg.getCp3(), 1, 1, true);
////////                for (VueElabTableauPrograFin d : map.get(pg)) {
////////                    table.addCell(getCell(fromLocal(d.getAcLibelleFrancais(), d.getAcLibelleAnglais()), aNormal9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP));
////////
////////                    addFormattedCell(table, d.getAe(), 1, 1);
////////                    addFormattedCell(table, d.getCp1(), 1, 1);
////////                    addFormattedCell(table, d.getCp2(), 1, 1);
////////                    addFormattedCell(table, d.getCp3(), 1, 1);
////////                }
////////            }
////////            c = getCell(getTexte(GrecoLangue.TOTAL_CHAPITRE), aBold9, PdfPTable.ALIGN_MIDDLE, PdfPTable.ALIGN_MIDDLE);
////////            c.setColspan(1);
////////            table.addCell(c);
////////            addFormattedCell(table, tae, 1, 1, true);
////////            addFormattedCell(table, tcp1, 1, 1, true);
////////            addFormattedCell(table, tcp2, 1, 1, true);
////////            addFormattedCell(table, tcp3, 1, 1, true);
////////            document.add(table);
////////        } catch (Exception e) {
////////        }
    }

    private void addFormattedCell(PdfPTable table, BigDecimal montant, int colSpan, int rowSpan) {
        addFormattedCell(table, montant, colSpan, rowSpan, false);
    }

    private void addFormattedCell(PdfPTable table, BigDecimal montant, int colSpan, int rowSpan, boolean useBold) {
        PdfPCell c;
        try {
            c = getCell(getMontantFormate(montant), useBold ? aNarrowB9 : aNarrow9, PdfPTable.ALIGN_RIGHT, PdfPTable.ALIGN_TOP);
        } catch (Exception e) {
            c = getCell("", aNormal9, PdfPTable.ALIGN_LEFT, PdfPTable.ALIGN_TOP);
        }
        c.setColspan(colSpan);
        c.setRowspan(rowSpan);
        table.addCell(c);
    }

    private String fromLocal(String fr, String us) {
        try {
            if (Locale.ENGLISH.equals(locale)) {
                return us;
            }
            return fr;
        } catch (Exception e) {
        }
        return "";
    }
}
