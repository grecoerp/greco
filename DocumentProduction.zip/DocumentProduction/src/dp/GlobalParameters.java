/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp;

/**
 *
 * @author DGLS
 */
public class GlobalParameters {
    
    public static String rootPackageName = "dp";
    public static String defaultDocNamePDF = "Doc_Synthese_";
}
