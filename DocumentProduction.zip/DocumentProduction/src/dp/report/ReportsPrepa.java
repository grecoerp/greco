/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp.report;

import java.io.InputStream;
import java.util.HashMap;

/**
 *
 * @author akodjou
 */
public class ReportsPrepa {

//    public static final String budgetEtat = "budgetEtat.jasper";
//    public static final String budgetEtatGraphe1 = "budgetEtatGraphe1.jasper";
//    public static final String budgetEtatGraphe2 = "budgetEtatGraphe2.jasper";
//    public static final String budgetEtatRecap = "budgetEtatRecap.jasper";
//    public static final String budgetEtatSommaire = "budgetEtatSommaire.jasper";
//
    public static final String rpt2012cos = "2012cos.jasper";
    public static final String rpt2012pap01 = "2012pap01.jasper";
    public static final String rpt2012pap01ListePG = "2012pap01ListePG.jasper";
    public static final String rpt2012pap02 = "2012pap02.jasper";
    public static final String rpt2012pap03 = "2012pap03.jasper";
    public static final String rpt2012pap04 = "2012pap04.jasper";
    public static final String rpt2012pap05 = "2012pap05.jasper";
    public static final String rpt2012pap06 = "2012pap06.jasper";
    public static final String rpt2012pap07 = "2012pap07.jasper";
    public static final String rpt2012pap08 = "2012pap08.jasper";
    public static final String rpt2012pap09 = "2012pap09.jasper";
    public static final String rpt2012pap10 = "2012pap10.jasper";
    public static final String rpt2012MatriceAT = "2012MatriceAT.jasper";
    public static final String rpt2012MatriceCDMT = "2012MatriceCDMT.jasper";
    public static final String rpt2012MatriceCDMTCouverture = "2012MatriceCDMTCouverture.jasper";
    public static final String rpt2012MatriceCDMTIndicateurs = "2012MatriceCDMTIndicateurs.jasper";
    public static final String rpt2012MatricePG = "2012MatricePG.jasper";
    public static final String rpt2012MatriceTA = "2012MatriceTA.jasper";
    public static final String rpt2012section = "2012section.jasper";
    public static final String rpt2012MatriceBudget = "2012MatriceBudget.jasper";
    public static final String rpt2012PAPBudget = "2012pap10Budget.jasper";
    //
    public static final String budgetEtatChapitreComparaisonProjetDefinitif = "budgetEtatChapitreComparaisonProjetDefinitif.jasper";
    //
    public static final String budgetEtatCategorie = "budgetEtatCategorie.jasper";
    public static final String budgetEtatCategorieDefinitif = "budgetEtatCategorieDefinitif.jasper";
    public static final String budgetEtatCategorieGraphe = "budgetEtatCategorieGraphe.jasper";
    public static final String budgetEtatCategorieRecap = "budgetEtatCategorieRecap.jasper";
    public static final String budgetEtatCamembert = "budgetEtatCamembert.jasper";
    public static final String budgetEtatChapitre = "budgetEtatChapitre.jasper";
    public static final String budgetEtatChapitreDefinitif = "budgetEtatChapitreDefinitif.jasper";
    public static final String budgetEtatChapitreGraphe1 = "budgetEtatChapitreGraphe1.jasper";
    public static final String budgetEtatChapitreGraphe2 = "budgetEtatChapitreGraphe2.jasper";
    public static final String budgetEtatChapitreIntercallaire = "budgetEtatChapitreIntercallaire.jasper";
    public static final String budgetEtatChapitreRecap = "budgetEtatChapitreRecap.jasper";
    public static final String budgetEtatChapitreSommaire = "budgetEtatChapitreSommaire.jasper";
    public static final String budgetEtatHistogramme = "budgetEtatHistogramme.jasper";
    public final static String budgetParMinistereEtRegion = "budgetParMinistereEtRegion.jasper";
    public final static String budgetEtatCategorieChapitreEtRegion = "budgetEtatCategorieChapitreEtRegion.jasper";
    public final static String budgetEtatCategorieRegionEtChapitre = "budgetEtatCategorieRegionEtChapitre.jasper";
    public final static String budgetEtatCategorieRegionEtArticle = "budgetEtatCategorieRegionEtArticle.jasper";
    public final static String budgetEtatCategorieRegionEtArticleDefinitif = "budgetEtatCategorieRegionEtArticleDefinitif.jasper";
    public static final String budgetEtatSecteurCouverture = "budgetEtatSecteurCouverture.jasper";
    public static final String budgetEtatSecteurGraphe1 = "budgetEtatSecteurGraphe1.jasper";
    public static final String budgetEtatSecteurGraphe2 = "budgetEtatSecteurGraphe2.jasper";
    public static final String budgetEtatChapitreNonRepOuNouv = "budgetEtatChapitreNonRepOuNouv.jasper";
    public static final String budgetEtatInterCallaire = "budgetEtatInterCallaire.jasper";
    public static final String budgetEtatTitre = "budgetEtatPageTitre.jasper";
    public static final String budgetEtatPageVierge = "budgetEtatPageVierge.jasper";
    public static final String cadrageGrandeMasse = "cadrageGrandeMasse.jasper";
    public static final String cadrageGrandeMassePG = "cadrageGrandeMassePG.jasper";
    public static final String cadreLogique = "CadreLogique.jasper";
    public static final String cadreLogiqueSimple = "CadreLogiqueSimple.jasper";
    public static final String chargeBudgetaire = "chargeBudgetaire.jasper";
    public static final String chargeBudgetairePGAC = "chargeBudgetairePGAC.jasper";
    public static final String couverturePaysage = "couverturePaysage.jasper";
    public static final String couverturePaysageBIP = "couverturePaysageBIP.jasper";
    public static final String couverturePortrait = "couverturePortrait.jasper";
    public static final String couverturePortraitBIP = "couverturePortraitBIP.jasper";
    public static final String depenseFpPgAcObIn = "DepenseFpPgAcObIn.jasper";
    public static final String depensePgAcObIn = "DepensePgAcObIn.jasper";
    public static final String depensePgAcObInFree = "DepensePgAcObInFree.jasper";
    public static final String depenseFpPgAcObInPaysage = "DepenseFpPgAcObInPaysage.jasper";
    public static final String depenseFpPgAcObInComitePaysage = "DepenseFpPgAcObInComitePaysage.jasper";
    public static final String depensesParFonctionEtNatureEco = "depensesParFonctionEtNatureEco.jasper";
    public static final String depensesParSecteurEtNatureEco = "depensesParSecteurEtNatureEco.jasper";
    public static final String depensesParFctPgAr = "DepensesParFctPgAr.jasper";
    public static final String developpementDepenses = "developpementDepenses.jasper";
    public static final String evolutionMasseSalariale = "EvolutionMasseSalariale.jasper";
    public static final String ficheDeCollecte = "ficheDeCollecte.jasper";
    public static final String ficheDeCollecteAECP = "ficheDeCollecteAECP.jasper";
    public static final String fonctionParChapitre = "fonctionParChapitre.jasper";
    public static final String jpi = "jpi.jasper";
    public static final String jpi_PTA = "jpi_PTA.jasper";
    public static final String jpi_recap = "jpi_recap.jasper";
    public static final String listeProgramme = "listeProgramme.jasper";
    public static final String listeProgrammePaysage = "listeProgrammePaysage.jasper";
    public static final String ppa_rtf = "ppa_rtf.jasper";
    public static final String ppa_html = "ppa_html.jasper";
    public static final String ppa_PresentationActions_rtf = "ppa_PresentationActions_rtf.jasper";
    public static final String ppa_PresentationActions_html = "ppa_PresentationActions_html.jasper";
    //public static final String ppa_CadreLogiqueSimple = "ppa_CadreLogiqueSimple.jasper";
    public static final String ppa_CadreLogique = "ppa_CadreLogique.jasper";
    public static final String ppa_PresentationCredit = "ppa_PresentationCredit.jasper";
    public static final String ppa_PresentationCreditRecap = "ppa_PresentationCreditRecap.jasper";
    public static final String ppa_PresentationProgramme_html = "ppa_PresentationProgramme_html.jasper";
    public static final String ppa_PresentationProgramme_rtf = "ppa_PresentationProgramme_rtf.jasper";
    public static final String ppa_PresentationProgrammeActionsRecap_html = "ppa_PresentationProgrammeActionsRecap_html.jasper";
    public static final String ppa_PresentationProgrammeActionsRecap_rtf = "ppa_PresentationProgrammeActionsRecap_rtf.jasper";
    //public static final String ppa_PresentationProgrammeEtActions = "ppa_PresentationProgrammeEtActions.jasper";
    public static final String ppa_PresentationProgrammeStrategie_html = "ppa_PresentationProgrammeStrategie_html.jasper";
    public static final String ppa_PresentationProgrammeStrategie_rtf = "ppa_PresentationProgrammeStrategie_rtf.jasper";
    public static final String ppa_ProgrammeObjectif = "ppa_ProgrammeObjectif.jasper";
    public static final String ppa_Programme_html = "ppa_Programme_html.jasper";
    public static final String ppa_Programme_rtf = "ppa_Programme_rtf.jasper";
    public static final String ppa_ProgrammeCredit = "ppa_ProgrammeCredit.jasper";
    public static final String ppa_Projet_sommaire = "ppa_Projet_sommaire.jasper";
    public static final String ppa_Projet_html = "ppa_Projet_html.jasper";
    public static final String ppa_Projet_rtf = "ppa_Projet_rtf.jasper";
    public static final String ppa_Projet_NoteExplicative_html = "ppa_Projet_NoteExplicative_html.jasper";
    public static final String ppa_Projet_NoteExplicative_rtf = "ppa_Projet_NoteExplicative_rtf.jasper";
    public static final String ppa_Section_html = "ppa_Section_html.jasper";
    public static final String ppa_Section_rtf = "ppa_Section_rtf.jasper";
    public static final String ppa_SectionSubRep_html = "ppa_SectionSubRep_html.jasper";
    public static final String ppa_SectionSubRep_rtf = "ppa_SectionSubRep_rtf.jasper";
    public static final String ppa_Projet_PG = "ppa_Projet_PG.jasper";
    public static final String ppa_Projet_single_html = "ppa_Projet_single_html.jasper";
    public static final String ppa_Projet_single_rtf = "ppa_Projet_single_rtf.jasper";
    public static final String ppa_ChargeBudgetaire = "ppa_ChargeBudgetaire.jasper";
    //public static final String ppa_Projet_RTFDesc = "ppa_Projet_RTFDesc.jasper";
    public static final String projetBIP = "projetBIP.jasper";
    public static final String projetBIP_detail = "projetBIP_detail.jasper";
    public static final String projetMINEPAT = "projetMINEPAT.jasper";
    public static final String pta = "pta.jasper";
    public static final String rapportDuplicationATArticle = "rapportDuplicationATArticle.jasper";
    public static final String traceParagraphe = "traceParagraphe.jasper";
    public static final String traceParagrapheJournalier = "traceParagrapheJournalier.jasper";
    //
    public static final String ficheEngagement = "ficheEngagement.jasper";
    public static final String ficheProjet_SF = "ficheProjet_SF.jasper";
    public static final String ficheProjet = "ficheProjet.jasper";
    public static final String ficheProjet_ProgTriennale = "ficheProjet_ProgTriennale.jasper";
    public static final String ficheProjet_Extrant = "ficheProjet_Extrant.jasper";
    public static final String ficheProjet_Etape = "ficheProjet_Etape.jasper";
    public static final String ficheProjet_Emploi = "ficheProjet_Emploi.jasper";
    public static final String ficheProjet_Effet = "ficheProjet_Effet.jasper";
    public static final String ficheProjet_Charge = "ficheProjet_Charge.jasper";
    public static final String comiteStatistiques = "comiteStatistiques.jasper";
    public static final String comiteCdmtBudgetComparaison = "2012ComparaisonProgrammation.jasper";
    //
    public static final String cadrageBf = "cadrageBf.jasper";
    public static final String cadrageBip = "cadrageBip.jasper";
    public static final String cadrageBfBip = "cadrageBfBip.jasper";
    //
    public static final String cadrageBf_saisie = "cadrageBf-saisie.jasper";
    public static final String cadrageBip_saisie = "cadrageBip-saisie.jasper";
    //
    public static final String fta = "fta.jasper";
    public static final String ftaDisponible = "ftadisponible.jasper";
    public static final String ftaPresentation = "ftaPresentation.jasper";
    //
    public static final String minepatBudgetisationPG = "minepatBudgetisationPG.jasper";
    public static final String minepatContenuProjets = "minepatContenuProjets.jasper";
    public static final String minepatDepenseARPA = "minepatDepenseARPA.jasper";
    public static final String minepatElementsDeContenuActions = "minepatElementsDeContenuActions.jasper";
    public static final String minepatJournalProjetChImPortrait = "minepatJournalProjetChImPortrait.jasper";
    public static final String minepatJournalProjetChPgAcPj = "minepatJournalProjetChPgAcPj.jasper";
    public static final String minepatJournalProjetChPgAcPjPortrait = "minepatJournalProjetChPgAcPjPortrait.jasper";
    public static final String minepatJournalProjetChPgAcRgPortrait = "minepatJournalProjetChPgAcRgPortrait.jasper";
    public static final String minepatJournalProjetRgChPortrait = "minepatJournalProjetRgChPortrait.jasper";
    public static final String minepatSynthesePG = "minepatSynthesePG.jasper";
    public final static String minepatPointage = "minepatPointage.jasper";
    public final static String minepatPointageRegion = "minepatPointageRegion.jasper";
    public final static String minepatJournalProjetChRgPortrait2013 = "2013minepatJournalProjetChRgPortrait.jasper";
    public final static String minepatJournalProjetRgDeChPortrait2013 = "2013minepatJournalProjetRgDeChPortrait.jasper";
    //
    public static final String comiteCheck = "comiteCheck.jasper";
    //
    public static final String CODE_EX = "exMillesime";
    public static final String CODE_CH = "chCode";
    public static final String CODE_FP = "fpCode";
    public static final String CODE_SE = "seCode";
    public static final String CODE_FS = "fsCode";
    public static final String CODE_PG = "pgCodeProgramme";
    public static final String CODE_AC = "acCodeAction";
    public static final String CODE_AT = "atCodeActivite";
    public static final String CODE_TA = "taCodeTache";
    public static final String CODE_PA = "paCodePara";
    public static final String CODE_AR = "arCode";
    public static final String CODE_RG = "rgCode";
    public static final String CODE_NE = "neCode";
    public static final String CODE_SF = "sfCodeSrcFin";
    public static final String CODE_MG = "mgCodeMGestion";
    public static final String CODE_UNITE = "unite";
    private static String reportDir = "jasper/";

    public String getTitle(String code) {
        switch (code) {
            case chargeBudgetaire:
                return "Charges budgétaires";
            case pta:
                return "Plan de Travail Annuel";
            case ficheDeCollecte:
            case ficheDeCollecteAECP:
                return "Fiche de collecte";
            case ppa_html:
            case ppa_rtf:
                return "Projet de performance des administrations";
            case jpi:
                return "Journal des projets(Par programmes et actions)";
            case chargeBudgetairePGAC:
                return "Charges budgétaires par programmes et actions";
            case projetMINEPAT:
                return "Journal des projets d'investissement";
            case projetBIP:
                return "Budget d'investissement public (BIP)";
            case depensesParFctPgAr:
                return "Depenses par fonction, programme et article";
            case depenseFpPgAcObIn:
            case depenseFpPgAcObInPaysage:
                return "Depenses de l'Etat par fonction, programme et objectif avec indicateurs de performance";
            case listeProgramme:
                return "Liste des programmes par fonction principale";
            case budgetEtatChapitre:
                return "Depenses de l'etat par chapitre, section, article et paragraphe";
            case evolutionMasseSalariale:
                return "Evolution des effectifs et de la masse salariale";
            case fonctionParChapitre:
                return "Liste des fonctions principales par chapitre";
            default:
                return "";
        }
    }

    public String getParamList(String code) {
        switch (code) {
            case chargeBudgetaire:
                return "exMillesime,chCode,fsCode,sfCodeSrcFin,unite";
            case pta:
                return "exMillesime,chCode,fpCode,pgCodeProgramme,acCodeAction,atCodeActivite,taCodeTache,paCodePara,arCode,rgCode,neCode,mgCodeMGestion,sfCodeSrcFin,unite";
            case ficheDeCollecte:
            case ficheDeCollecteAECP:
                return "exMillesime,chCode,fpCode,pgCodeProgramme,acCodeAction,atCodeActivite,taCodeTache,neCode";
            case ppa_html:
            case ppa_rtf:
                return "exMillesime,chCode,fpCode,pgCodeProgramme";
            case jpi:
                return "exMillesime,chCode";//,arCode,fpCode,sfCodeSrcFin,pgCodeProgramme,acCodeAction,rgCode,unite";
            case chargeBudgetairePGAC:
                return "exMillesime,chCode,seCode,fpCode,pgCodeProgramme,acCodeAction,sfCodeSrcFin,unite";
            case projetMINEPAT:
                return "exMillesime,chCode,arCode,rgCode,unite";
            case projetBIP:
                return "exMillesime,chCode";
            case depenseFpPgAcObIn:
            case depenseFpPgAcObInPaysage:
                return "exMillesime,chCode,fpCode,pgCodeProgramme,acCodeAction,unite";
            case depensesParFctPgAr:
                return "exMillesime,chCode,unite";
            case budgetEtatChapitre:
                return "exMillesime,chCode,unite";
            case evolutionMasseSalariale:
                return "exMillesime,chCode";
            case listeProgramme:
                return "exMillesime,chCode";
            case fonctionParChapitre:
                return "exMillesime";
            default:
                return "";
        }
    }

    public String getRequiredList(String code) {
        switch (code) {
            case chargeBudgetaire:
                return "exMillesime,chCode";
            case pta:
                return "exMillesime,chCode";
            case ficheDeCollecte:
            case ficheDeCollecteAECP:
                return "exMillesime,chCode";
            case ppa_html:
            case ppa_rtf:
                return "exMillesime,chCode,fpCode";
            case jpi:
                return "exMillesime,chCode";
            case chargeBudgetairePGAC:
                return "exMillesime,chCode";
            case projetMINEPAT:
                return "exMillesime";
            case projetBIP:
                return "exMillesime";
            case depenseFpPgAcObIn:
            case depenseFpPgAcObInPaysage:
                return "exMillesime,chCode";
            case depensesParFctPgAr:
                return "exMillesime,chCode";
            case budgetEtatChapitre:
                return "exMillesime";
            case evolutionMasseSalariale:
                return "exMillesime,chCode";
            case listeProgramme:
                return "exMillesime";
            case fonctionParChapitre:
                return "exMillesime";
            default:
                return "";
        }
    }

    public InputStream pta(boolean isDraft) {
        try {
            return getClass().getResourceAsStream(reportDir + "pta" + (isDraft ? "_draft" : "") + ".jasper");
        } catch (Exception e) {
            return null;
        }
    }

    //<editor-fold defaultstate="collapsed" desc=" PPA">
    public InputStream ppa(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_html : ppa_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_PresentationCredit() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_PresentationCredit);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_PresentationCreditRecap() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_PresentationCreditRecap);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_ProgrammeObjectif() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_ProgrammeObjectif);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_PresentationActions(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_PresentationActions_html : ppa_PresentationActions_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_PresentationProgramme(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_PresentationProgramme_html : ppa_PresentationProgramme_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_CadreLogique() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_CadreLogique);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_PresentationProgrammeStrategie(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_PresentationProgrammeStrategie_html : ppa_PresentationProgrammeStrategie_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_Programme(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_Programme_html : ppa_Programme_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_ProgrammeCredit() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_ProgrammeCredit);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_PresentationProgrammeActionsRecap(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_PresentationProgrammeActionsRecap_html : ppa_PresentationProgrammeActionsRecap_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_Projet_PG() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_Projet_PG);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_Section(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_Section_html : ppa_Section_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_SectionSubRep(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_SectionSubRep_html : ppa_SectionSubRep_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_Projet_sommaire() {
        try {
            return getClass().getResourceAsStream(reportDir +  ppa_Projet_sommaire);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_Projet(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_Projet_html : ppa_Projet_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_Projet_NoteExplicative(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_Projet_NoteExplicative_html : ppa_Projet_NoteExplicative_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream _ppa_Projet_single(boolean isHtml) {
        try {
            return getClass().getResourceAsStream(reportDir + (isHtml ? ppa_Projet_single_html : ppa_Projet_single_rtf));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ppa_ChargeBudgetaire() {
        try {
            return getClass().getResourceAsStream(reportDir + ppa_ChargeBudgetaire);
        } catch (Exception e) {
            return null;
        }
    }

    //</editor-fold>
    public InputStream chargeBudgetaire() {
        try {
            return getClass().getResourceAsStream(reportDir + chargeBudgetaire);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream chargeBudgetairePGAC() {
        try {
            return getClass().getResourceAsStream(reportDir + chargeBudgetairePGAC);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream cadrageGrandeMasse() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageGrandeMasse);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream cadrageGrandeMassePG() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageGrandeMassePG);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream jpi() {
        try {
            return getClass().getResourceAsStream(reportDir + jpi);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream jpi_PTA() {
        try {
            return getClass().getResourceAsStream(reportDir + jpi_PTA);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream jpi_recap() {
        try {
            return getClass().getResourceAsStream(reportDir + jpi_recap);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ficheDeCollecte() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheDeCollecte);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ficheDeCollecteAECP() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheDeCollecteAECP);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream developpementDepenses() {
        try {
            return getClass().getResourceAsStream(reportDir + developpementDepenses);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream cadreLogique() {
        try {
            return getClass().getResourceAsStream(reportDir + cadreLogique);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream cadreLogiqueSimple() {
        try {
            return getClass().getResourceAsStream(reportDir + cadreLogiqueSimple);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream projetMINEPAT() {
        try {
            return getClass().getResourceAsStream(reportDir + projetMINEPAT);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream projetBIP() {
        try {
            return getClass().getResourceAsStream(reportDir + projetBIP);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream projetBIP_detail() {
        try {
            return getClass().getResourceAsStream(reportDir + projetBIP_detail);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depenseFpPgAcObIn() {
        try {
            return getClass().getResourceAsStream(reportDir + depenseFpPgAcObIn);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depensesParFonctionEtNatureEco() {
        try {
            return getClass().getResourceAsStream(reportDir + depensesParFonctionEtNatureEco);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depensesParSecteurEtNatureEco() {
        try {
            return getClass().getResourceAsStream(reportDir + depensesParSecteurEtNatureEco);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depenseFpPgAcObInPaysage() {
        try {
            return getClass().getResourceAsStream(reportDir + depenseFpPgAcObInPaysage);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depensePgAcObIn(boolean freeVersion) {
        try {
            return getClass().getResourceAsStream(reportDir + (freeVersion ? depensePgAcObInFree : depensePgAcObIn));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depenseFpPgAcObInComite() {
        try {
            return getClass().getResourceAsStream(reportDir + depenseFpPgAcObInComitePaysage);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream depensesParFctPgAr() {
        try {
            return getClass().getResourceAsStream(reportDir + depensesParFctPgAr);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream listeProgramme(boolean paysage) {
        try {
            return getClass().getResourceAsStream(reportDir + (paysage ? listeProgrammePaysage : listeProgramme));
        } catch (Exception e) {
            return null;
        }
    }

    //<editor-fold defaultstate="collapsed" desc=" BUDGET">
    public InputStream budgetEtatPageVide() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatInterCallaire);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatTitre() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatTitre);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatPageVierge() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatPageVierge);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreNonRepOuNouv() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreNonRepOuNouv);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitre(boolean isDraft) {
        try {
            return getClass().getResourceAsStream(reportDir + (isDraft ? budgetEtatChapitre : budgetEtatChapitreDefinitif));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreSommaire() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreSommaire);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreRecap() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreRecap);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCategorieChapitreEtRegion() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatCategorieChapitreEtRegion);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCategorieRegionEtChapitre() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatCategorieRegionEtChapitre);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCategorieRegionEtArticle(boolean isDraft) {
        try {
            return getClass().getResourceAsStream(reportDir + (isDraft ? budgetEtatCategorieRegionEtArticle : budgetEtatCategorieRegionEtArticleDefinitif));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetParMinistereEtRegion() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetParMinistereEtRegion);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCamembert() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatCamembert);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreIntercallaire() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreIntercallaire);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatHistogramme() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatHistogramme);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatSecteurCouverture() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatSecteurCouverture);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatSecteurGraphe1() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatSecteurGraphe1);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatSecteurGraphe2() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatSecteurGraphe2);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreGraphe1() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreGraphe1);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreGraphe2() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreGraphe2);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCategorie(boolean isDraft) {
        try {
            return getClass().getResourceAsStream(reportDir + (isDraft ? budgetEtatCategorie : budgetEtatCategorieDefinitif));
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCategorieGraphe() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatCategorieGraphe);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatCategorieRecap() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatCategorieRecap);
        } catch (Exception e) {
            return null;
        }
    }

    //</editor-fold>
    public InputStream fonctionParChapitre() {
        try {
            return getClass().getResourceAsStream(reportDir + fonctionParChapitre);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream couverturePaysage() {
        try {
            return getClass().getResourceAsStream(reportDir + couverturePaysage);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream couverturePaysageBIP() {
        try {
            return getClass().getResourceAsStream(reportDir + couverturePaysageBIP);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream couverturePortrait() {
        try {
            return getClass().getResourceAsStream(reportDir + couverturePortrait);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream evolutionMasseSalariale() {
        try {
            return getClass().getResourceAsStream(reportDir + evolutionMasseSalariale);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream getReport(String report) {
        try {
            return getClass().getResourceAsStream(reportDir + report);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream budgetEtatChapitreComparaisonProjetDefinitif() {
        try {
            return getClass().getResourceAsStream(reportDir + budgetEtatChapitreComparaisonProjetDefinitif);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rapportDuplicationATArticle() {
        try {
            return getClass().getResourceAsStream(reportDir + rapportDuplicationATArticle);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream traceParagraphe() {
        try {
            return getClass().getResourceAsStream(reportDir + traceParagraphe);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream traceParagrapheJournalier() {
        try {
            return getClass().getResourceAsStream(reportDir + traceParagrapheJournalier);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012cos() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012cos);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap01() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap01);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap01ListePG() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap01ListePG);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap02() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap02);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap03() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap03);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap04() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap04);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap05() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap05);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap06() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap06);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap07() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap07);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap08() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap08);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap09() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap09);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012pap10() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012pap10);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatriceAT() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatriceAT);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatriceCDMT() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatriceCDMT);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatriceCDMTCouverture() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatriceCDMTCouverture);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatriceCDMTIndicateurs() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatriceCDMTIndicateurs);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatricePG() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatricePG);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatriceBudget() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatriceBudget);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012PAPBudget() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012PAPBudget);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012MatriceTA() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012MatriceTA);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream rpt2012section() {
        try {
            return getClass().getResourceAsStream(reportDir + rpt2012section);
        } catch (Exception e) {
            return null;
        }

    }

    public HashMap mainParameters() {
        HashMap parameters = new HashMap();
        parameters.put("paysFR", "REPUBLIQUE DU CAMEROUN");
        parameters.put("paysEN", "REPUBLIC OF CAMEROON");
        parameters.put("deviseFR", "PAIX - TRAVAIL - PATRIE");
        parameters.put("deviseEN", "PEACE - WORK - FATHERLAND");
        parameters.put("chapitreFR", "");
        parameters.put("chapitreEN", "");
        parameters.put("serviceFR", "SECRETARIAT GENERAL");
        parameters.put("serviceEN", "GENERAL SECRETARY");
        return parameters;
    }

    public InputStream ficheEngagement() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheEngagement);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ficheProjet_SF() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_SF);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ficheProjet() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream ficheProjet_ProgTriennale() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_ProgTriennale);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheProjet_Extrant() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_Extrant);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheProjet_Etape() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_Etape);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheProjet_Emploi() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_Emploi);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheProjet_Effet() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_Effet);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheProjet_Charge() {
        try {
            return getClass().getResourceAsStream(reportDir + ficheProjet_Charge);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getComiteStatistiques() {
        try {
            return getClass().getResourceAsStream(reportDir + comiteStatistiques);
        } catch (Exception e) {
            return null;
        }
    }

    public String libelleUnite(long unite) {
        if (unite == 1) {
            return "en FCFA";
        }
        if (unite == 1000) {
            return "en milliers de FCFA";
        }
        if (unite == 1000000) {
            return "en millions de FCFA";
        }
        if (unite == 1000000000) {
            return "en milliards de FCFA";
        }
        return "";
    }

    public InputStream getComiteCdmtBudgetComparaison() {
        try {
            return getClass().getResourceAsStream(reportDir + comiteCdmtBudgetComparaison);
        } catch (Exception e) {
            return null;
        }
    }

    public InputStream getFta() {
        try {
            return getClass().getResourceAsStream(reportDir + fta);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream getFtaDisponible() {
        try {
            return getClass().getResourceAsStream(reportDir + ftaDisponible);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getFtaPresentation() {
        try {
            return getClass().getResourceAsStream(reportDir + ftaPresentation);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getCadrageBfBip() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageBfBip);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getCadrageBf() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageBf);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getCadrageBip() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageBip);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getCadrageBfSaisie() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageBf_saisie);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream getCadrageBipSaisie() {
        try {
            return getClass().getResourceAsStream(reportDir + cadrageBip_saisie);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatBudgetisationPG() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatBudgetisationPG);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatContenuProjets() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatContenuProjets);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatDepenseARPA() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatDepenseARPA);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatElementsDeContenuActions() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatElementsDeContenuActions);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatDetailOpChIm() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetChImPortrait);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatDetailOpChPgAcPj() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetChPgAcPjPortrait);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatJournalProjetChPgAcPj() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetChPgAcPj);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatSynthesePG() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatSynthesePG);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatDetailOpChPgAcRg() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetChPgAcRgPortrait);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatJournalProjetRgChPortrait() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetRgChPortrait);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream comiteCheck() {
        try {
            return getClass().getResourceAsStream(reportDir + comiteCheck);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatPointage(boolean isRegion) {
        try {
            return getClass().getResourceAsStream(reportDir + (isRegion ? minepatPointageRegion : minepatPointage));
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatJournalProjetChRgPortrait2013() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetChRgPortrait2013);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream minepatJournalProjetRgDeChPortrait2013() {
        try {
            return getClass().getResourceAsStream(reportDir + minepatJournalProjetRgDeChPortrait2013);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream couverturePortraitBIP() {
        try {
            return getClass().getResourceAsStream(reportDir + couverturePortraitBIP);
        } catch (Exception ex) {
            return null;
        }
    }
}
