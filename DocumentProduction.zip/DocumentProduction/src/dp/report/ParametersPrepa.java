/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package dp.report;

import dp.GlobalParameters;
import java.awt.Image;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Locale;
import java.util.ResourceBundle;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 *
 * @author cwam
 */
public class ParametersPrepa {

    private Image armoirie;
    private Image drapeau;
    private Image etoile;
//    org.jdesktop.application.ResourceMap resourceMap = org.jdesktop.application.Application.getInstance(com.siic.dgls.psfe.PSFEApp.class).getContext().getResourceMap(ParametersPrepa.class);
    private ResourceBundle bundle;
    private ResourceBundle bundleFR = ResourceBundle.getBundle(GlobalParameters.rootPackageName+"/report/resources/ParametersPrepa", Locale.FRENCH);
    private ResourceBundle bundleUS = ResourceBundle.getBundle(GlobalParameters.rootPackageName+"/report/resources/ParametersPrepa", Locale.ENGLISH);
    private Locale locale;
    public final static short ppaDecallageSommaire = 5;

    public ParametersPrepa(Image etoile, Image armoirie, Image drapeau, Locale locale) {
        this.armoirie = armoirie;
        this.drapeau = drapeau;
        this.etoile = etoile;
        this.locale = locale;
        bundle = ResourceBundle.getBundle(GlobalParameters.rootPackageName+"/report/resources/ParametersPrepa", locale);
    }

    public ParametersPrepa() {
        this(null, null, null, Locale.getDefault());
    }

    public ParametersPrepa(Locale locale) {
        this(null, null, null, locale);
    }

    public ParametersPrepa(Image etoile, Image armoirie, Image drapeau) {
        this(etoile, armoirie, drapeau, Locale.getDefault());
    }

    public Locale getLocale() {
        return locale;
    }

    public void setLocale(Locale locale) {
        this.locale = locale;
        bundle = ResourceBundle.getBundle(GlobalParameters.rootPackageName+"/report/resources/ParametersPrepa", locale);
    }

    public String getLabel(String label) {
        try {
            return bundle.getString(label);
            //return resourceMap.getString(label);
        } catch (Exception e) {
            return "";
        }
    }

    public String getLabelFR(String label) {
        try {
            return bundleFR.getString(label);
            //return resourceMap.getString(label);
        } catch (Exception e) {
            return "";
        }
    }

    public String getLabelUS(String label) {
        try {
            return bundleUS.getString(label);
            //return resourceMap.getString(label);
        } catch (Exception e) {
            return "";
        }
    }

    public HashMap mainParameters() {
        return mainParameters(false, true);
    }

    private HashMap mainParameters(boolean resetPays, boolean resetDevise) {
        HashMap parameters = new HashMap();
        parameters.put("paysFR", (resetPays ? "" : "REPUBLIQUE DU CAMEROUN"));
        parameters.put("paysEN", (resetPays ? "" : "REPUBLIC OF CAMEROON"));
        parameters.put("deviseFR", (resetDevise ? "" : "PAIX - TRAVAIL - PATRIE"));
        parameters.put("deviseEN", (resetDevise ? "" : "PEACE - WORK - FATHERLAND"));
        parameters.put("chapitreFR", "");
        parameters.put("chapitreEN", "");
        parameters.put("serviceFR", "");
        parameters.put("serviceEN", "");
        return parameters;
    }

    public String libelleUnite(long unite) {
        if (unite == 1) {
            return getLabel(uniteUnit);
        }
        if (unite == 1000) {
            return getLabel(uniteKilo);
        }
        if (unite == 1000000) {
            return getLabel(uniteMega);
        }
        if (unite == 1000000000) {
            return getLabel(uniteGiga);
        }
        return "";
    }

    public HashMap budgetEtatCamembert(String titreGraphe, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblTotal", getLabel(budgetEtatCamembert_lblTotal));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatChapitre_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblSecteur", getLabel(budgetEtatCamembert_lblSecteur));
        parameters.put("lblGrapheTitre", titreGraphe);
        parameters.put("lblBudget", getLabel(budgetEtatChapitre_lblBudget));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatCamembert_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatCamembert_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("PARAM_Titre", "");//getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatChapitre(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitre_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatChapitre_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatChapitre_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("lblTotal", getLabel(budgetEtatChapitre_lblTotal));
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitre_lblPartieTitre));
        parameters.put("lblPartie", getLabel(budgetEtatChapitre_lblPartie));
        parameters.put("PARAM_Titre", getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatChapitreCompareprojetDefinitif(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", getLabel(budgetEtatChapitre_lblProjet));
        parameters.put("lblDefinitif", getLabel(budgetEtatChapitre_lblDefinitif));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitre_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatChapitre_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatChapitre_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("lblTotal", getLabel(budgetEtatChapitre_lblTotal));
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitre_lblPartieTitre));
        parameters.put("lblPartie", getLabel(budgetEtatChapitre_lblPartie));
        parameters.put("PARAM_Titre", getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatCategorieRegion(boolean vueParRegion, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblRegion", getLabel(lblRegion));
        parameters.put("lblDepartement", getLabel(lblDepartement));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitre_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatChapitre_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatChapitre_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("lblTotal", getLabel(budgetEtatChapitre_lblTotal));
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitre_lblPartieTitre));
        parameters.put("lblPartie", getLabel(budgetEtatChapitre_lblPartie));
        parameters.put("PARAM_Titre", (vueParRegion ? titreBudgetEtatCategorieRegionEtChapitre() : titreBudgetEtatCategorieChapitreEtRegion()));
        return parameters;
    }

    public HashMap budgetEtatChapitreGraphe1(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatChapitre_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitreGraphe1_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatChapitreGraphe1_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatChapitreGraphe1_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("PARAM_Titre", getLabel(budgetEtatChapitre_PARAM_Titre));
        parameters.put("lblPartie", getLabel(budgetEtatChapitreGraphe1_lblPartie));
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitreGraphe1_lblPartieTitre));
        parameters.put("lblPartie11", getLabel(budgetEtatChapitreGraphe1_lblPartie11));
        parameters.put("lblPartie11Titre", getLabel(budgetEtatChapitreGraphe1_lblPartie11Titre));
        parameters.put("lblPartie12", getLabel(budgetEtatChapitreGraphe1_lblPartie12));
        parameters.put("lblPartie12Titre", getLabel(budgetEtatChapitreGraphe1_lblPartie12Titre));
        return parameters;
    }

    public HashMap budgetEtatChapitreGraphe2(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatChapitre_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitreGraphe2_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatChapitreGraphe2_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatChapitreGraphe2_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("lblPartie13", getLabel(budgetEtatChapitreGraphe2_lblPartie13));
        parameters.put("lblPartie13Titre", getLabel(budgetEtatChapitreGraphe2_lblPartie13Titre));
        parameters.put("lblPartie14", getLabel(budgetEtatChapitreGraphe2_lblPartie14));
        parameters.put("lblPartie14Titre", getLabel(budgetEtatChapitreGraphe2_lblPartie14Titre));
        parameters.put("PARAM_Titre", getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatChapitreIntercallaire(String chCode, String chLibelle, Image arrierePlan) {
        HashMap parameters = new HashMap();
        parameters.put("lblChapitre", getLabel(budgetEtatChapitreIntercallaire_lblChapitre));
        parameters.put("PARAM_ChLibelle", chLibelle);
        parameters.put("PARAM_ChCode", chCode);
        parameters.put("PARAM_ImageFond", arrierePlan);
        return parameters;
    }

    public HashMap budgetEtatChapitreRecap(String titre, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitreRecap_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblVersion", getLblVersion());
        parameters.put("lblDotation", getLabel(budgetEtatChapitreRecap_lblDotation));
        parameters.put("lblPrevision", getLabel(budgetEtatChapitreRecap_lblPrevision));
        parameters.put("lblEnteteRecapitulatif", getLabel(budgetEtatChapitreRecap_lblEnteteRecapitulatif));
        parameters.put("lblCode", getLabel(budgetEtatChapitreRecap_lblCode));
        parameters.put("lblLibelle", getLabel(budgetEtatChapitreRecap_lblLibelle));
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatChapitreRecap_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatChapitreRecap_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("lblTotal", getLabel(budgetEtatChapitreRecap_lblTotal));
        parameters.put("lblPartie", getLabel(budgetEtatChapitreRecap_lblPartie));
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitreRecap_lblPartieTitre));
        parameters.put("PARAM_Titre", titre);
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        return parameters;
    }

    public HashMap budgetEtatChapitreRecap(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        return budgetEtatChapitreRecap(getLabel(budgetEtatChapitre_PARAM_Titre), uniteMontant, page_Prefix, page_Suffixe, debutPage, isDraft);
    }

    public HashMap budgetEtatChapitreSommaire(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatChapitreSommaire_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblVersion", getLblVersion());
        parameters.put("lblSommaire", getLabel(budgetEtatChapitreSommaire_lblSommaire));
        parameters.put("lblPartie1", getLabel(budgetEtatChapitreSommaire_lblPartie1));
        parameters.put("lblPartie1Titre", getLabel(budgetEtatChapitreSommaire_lblPartie1Titre));
        parameters.put("lblPartie11", getLabel(budgetEtatChapitreSommaire_lblPartie11));
        parameters.put("lblPartie11Titre", getLabel(budgetEtatChapitreSommaire_lblPartie11Titre));
        parameters.put("lblPartie12", getLabel(budgetEtatChapitreSommaire_lblPartie12));
        parameters.put("lblPartie12Titre", getLabel(budgetEtatChapitreSommaire_lblPartie12Titre));
        parameters.put("lblPartie13", getLabel(budgetEtatChapitreSommaire_lblPartie13));
        parameters.put("lblPartie13Titre", getLabel(budgetEtatChapitreSommaire_lblPartie13Titre));
        parameters.put("lblPartie14", getLabel(budgetEtatChapitreSommaire_lblPartie14));
        parameters.put("lblPartie14Titre", getLabel(budgetEtatChapitreSommaire_lblPartie14Titre));
        parameters.put("lblPartie2", getLabel(budgetEtatChapitreSommaire_lblPartie2));
        parameters.put("lblPartie2Titre", getLabel(budgetEtatChapitreSommaire_lblPartie2Titre));
        parameters.put("lblPartie3", getLabel(budgetEtatChapitreSommaire_lblPartie3));
        parameters.put("lblPartie3Titre", getLabel(budgetEtatChapitreSommaire_lblPartie3Titre));
        parameters.put("PARAM_Titre", getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatHistogramme(String titreGraphe, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblTotal", getLabel(budgetEtatHistogramme_lblTotal));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatChapitre_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblSecteur", getLabel(budgetEtatHistogramme_lblSecteur));
        parameters.put("lblGrapheTitre", titreGraphe);
        parameters.put("lblBudget", getLabel(budgetEtatChapitre_lblBudget));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatHistogramme_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatHistogramme_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("PARAM_Titre", "");// getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatInterCallaire(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft, String lblIntercallaire) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLabel(budgetEtatInterCallaire_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatInterCallaire_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatInterCallaire_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatInterCallaire_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatInterCallaire_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatInterCallaire_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatInterCallaire_lblAnnee));
        //parameters.put("nbPageIntro", getLabel(budgetEtatInterCallaire_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblIntercallaire", lblIntercallaire);
        return parameters;
    }

    public HashMap budgetEtatSecteurCouverture(Image arrierePlan) {
        HashMap parameters = new HashMap();
        parameters.put("lblChapitre", getLabel(budgetEtatSecteurCouverture_lblChapitre));
        parameters.put("PARAM_ImageFond", arrierePlan);
        return parameters;
    }

    public HashMap budgetEtatCategorieGraphe(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(budgetEtatCategorieGraphe_chapitreFR));
        parameters.put("serviceFR", "");//getLabel(budgetEtatCategorieGraphe_serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(budgetEtatCategorieGraphe_deviseFR));
        parameters.put("chapitreEN", "");//getLabel(budgetEtatCategorieGraphe_chapitreEN));
        parameters.put("serviceEN", "");//getLabel(budgetEtatCategorieGraphe_serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(budgetEtatCategorieGraphe_deviseEN));
        parameters.put("uniteMontant", uniteMontant);//getLabel(budgetEtatCategorieGraphe_uniteMontant));
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatChapitre_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
//        parameters.put("nbPageIntro", getLabel(budgetEtatCategorieGraphe_nbPageIntro));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
//        parameters.put("PARAM_CodeDC", getLabel(budgetEtatCategorieGraphe_PARAM_CodeDC));
//        parameters.put("PARAM_CodeDI", getLabel(budgetEtatCategorieGraphe_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("PARAM_Titre", titreDecentralisation());
//        parameters.put("lblPartie", getLabel(budgetEtatCategorieGraphe_lblPartie));
//        parameters.put("lblPartieTitre", getLabel(budgetEtatCategorieGraphe_lblPartieTitre));
        parameters.put("lblPartie11Titre", getLabel(budgetEtatCategorieGraphe_lblPartie11Titre));
//        parameters.put("chCode", chCode);
        return parameters;
    }

    public HashMap budgetEtatCategorieRecap(String caCode, String caLibelle, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(budgetEtatChapitre_chapitreFR));
        parameters.put("serviceFR", "");//getLabel(budgetEtatChapitre_serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(budgetEtatChapitre_deviseFR));
        parameters.put("chapitreEN", "");//getLabel(budgetEtatChapitre_chapitreEN));
        parameters.put("serviceEN", "");//getLabel(budgetEtatChapitre_serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(budgetEtatChapitre_deviseEN));
        parameters.put("uniteMontant", uniteMontant);//getLabel(budgetEtatChapitre_uniteMontant));
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lblArticle", getLabel(budgetEtatChapitre_lblArticle));
        parameters.put("lblParagraphe", getLabel(budgetEtatChapitre_lblParagraphe));
        parameters.put("lblDotation", getLabel(budgetEtatChapitre_lblDotation));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblVersion", getLabel(lblVersion));
        parameters.put("lblPrevision", getLabel(budgetEtatChapitreRecap_lblPrevision));
        parameters.put("lblEnteteRecapitulatif", getLabel(budgetEtatChapitreRecap_lblEnteteRecapitulatif));
        parameters.put("lblCode", "");//caCode);
        parameters.put("lblLibelle", "");//caLibelle);
//parameters.put("PARAM_CodeDC",getLabel(budgetEtatChapitre_PARAM_CodeDC));
//parameters.put("PARAM_CodeDI",getLabel(budgetEtatChapitre_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("lblTotal", getLabel(budgetEtatChapitre_lblTotal));
        parameters.put("lblPartie", getLabel(budgetEtatChapitre_lblPartie));
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitre_lblPartieTitre));
        parameters.put("PARAM_Titre", titreDecentralisation());
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblCategorie", "");// getLabel(lblCategorie));
        return parameters;
    }

    public HashMap budgetEtatSecteurGraphe1(String titre, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblTotal", getLabel(budgetEtatSecteurGraphe1_lblTotal));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatSecteurGraphe1_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatSecteurGraphe1_lblAnnee));
        parameters.put("lblSecteur", getLabel(budgetEtatSecteurGraphe1_lblSecteur));
        parameters.put("lblGrapheTitre", titre);
        parameters.put("lblBudget", getLabel(budgetEtatChapitre_lblBudget));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatSecteurGraphe1_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatSecteurGraphe1_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("PARAM_Titre", "");//getLabel(budgetEtatChapitre_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetEtatSecteurGraphe2(String titre, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblTotal", getLabel(budgetEtatSecteurGraphe2_lblTotal));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatSecteurGraphe2_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatSecteurGraphe2_lblAnnee));
        parameters.put("lblSecteur", getLabel(budgetEtatSecteurGraphe2_lblSecteur));
        parameters.put("lblGrapheTitre", titre);
        parameters.put("lblBudget", getLabel(budgetEtatSecteurGraphe2_lblBudget));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        //parameters.put("PARAM_CodeDC", getLabel(budgetEtatSecteurGraphe2_PARAM_CodeDC));
        //parameters.put("PARAM_CodeDI", getLabel(budgetEtatSecteurGraphe2_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC));
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI));
        parameters.put("PARAM_Titre", "");//getLabel(budgetEtatSecteurGraphe2_PARAM_Titre));
        return parameters;
    }

    public HashMap budgetPageVideAvecEnteteChapitre(int annee, String titre, String chCode, String chLibelle, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//, getLabel(budgetEtatInterCallaire_chapitreFR));
        parameters.put("serviceFR", "");//, getLabel(budgetEtatInterCallaire_serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//, getLabel(budgetEtatInterCallaire_deviseFR));
        parameters.put("chapitreEN", "");//, getLabel(budgetEtatInterCallaire_chapitreEN));
        parameters.put("serviceEN", "");//, getLabel(budgetEtatInterCallaire_serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//, getLabel(budgetEtatInterCallaire_deviseEN));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatInterCallaire_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatInterCallaire_lblAnnee));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        //parameters.put("lblPartieTitre", getLabel(budgetEtatChapitreGraphe1_lblPartieTitre));
        //parameters.put("lblPartie", getLabel(budgetEtatChapitreGraphe1_lblPartie));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblChapitre", getLabel(lblCHAPITRE));
        parameters.put("PARAM_chLibelle", chLibelle);
        parameters.put("PARAM_chCodeChapitre", chCode);
        parameters.put("PARAM_annee", annee);
        parameters.put("PARAM_Titre", titre);
        return parameters;

    }

    public HashMap budgetPageChapitreTitre(String partie, String titre) {
        HashMap parameters = new HashMap();
        parameters.put("lblPartieTitre", titre);
        parameters.put("lblPartie", partie);
        return parameters;
    }

    public HashMap budgetPageVideAvecEnteteSecteur(int annee, String titre, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//, getLabel(budgetEtatInterCallaire_chapitreFR));
        parameters.put("serviceFR", "");//, getLabel(budgetEtatInterCallaire_serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");//, getLabel(budgetEtatInterCallaire_deviseFR));
        parameters.put("chapitreEN", "");//, getLabel(budgetEtatInterCallaire_chapitreEN));
        parameters.put("serviceEN", "");//, getLabel(budgetEtatInterCallaire_serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");//, getLabel(budgetEtatInterCallaire_deviseEN));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(budgetEtatInterCallaire_lblTitre));
        parameters.put("lblAnnee", getLabel(budgetEtatInterCallaire_lblAnnee));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lblPartieTitre", getLabel(budgetEtatChapitreGraphe1_lblPartieTitre));
        parameters.put("lblPartie", getLabel(budgetEtatChapitreGraphe1_lblPartie));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblChapitre", "");
        parameters.put("PARAM_chLibelle", "");
        parameters.put("PARAM_chCodeChapitre", "");
        parameters.put("PARAM_annee", annee);
        parameters.put("PARAM_Titre", titre);
        return parameters;
    }

    public HashMap budgetPageVierge(boolean afficherPied, String page_Prefix, String page_Suffixe, int debutPage, String lblIntercallaire) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_AfficherPied", afficherPied);
        parameters.put("lblIntercallaire", lblIntercallaire);
        return parameters;
    }

    public HashMap budgetParMinistereEtRegion(String lblFinex, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");
        parameters.put("serviceFR", "");
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");
        parameters.put("chapitreEN", "");
        parameters.put("serviceEN", "");
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblTotal", getLabel(budgetEtatChapitre_lblTotal));
        parameters.put("lblChapitre", getLblCHAPITRE());
        parameters.put("lblSection", getLabel(budgetEtatChapitre_lblSection));
        parameters.put("lbLibelle", getLabel(budgetParMinistereEtRegion_lbLibelle));
        parameters.put("lblBF", getLabel(budgetParMinistereEtRegion_lblBF));
        parameters.put("lblBIP", getLabel(budgetParMinistereEtRegion_lblBIP));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_Titre", titrebudgetParMinistereEtRegion() + (lblFinex.isEmpty() ? "" : "\n(" + lblFinex + ")"));
        parameters.put("lblSC", getLabel(budgetParMinistereEtRegion_lblSC));
        parameters.put("lblSE", getLabel(budgetParMinistereEtRegion_lblSE));
        parameters.put("lblSCE", getLabel(budgetParMinistereEtRegion_lblSCE));
        parameters.put("lblPresentationPar", getLabel(budgetParMinistereEtRegion_lblPresentationPar));
        parameters.put("lblTaux", getLabel(budgetParMinistereEtRegion_lblTaux));
        return parameters;
    }

//
//    public HashMap CadrageAll() {
//        HashMap parameters = new HashMap();
//        parameters.put("PARAM_Pays", getLabel(param_Pays));
//        parameters.put("PARAM_Devise", getLabel(param_Devise));
//        //parameters.put("PARAM_Logo",);
//        parameters.put("PARAM_PREPA_BUD", getLabel(CadrageAll_PARAM_PREPA_BUD));
//        parameters.put("PARAM_Titre", getLabel(CadrageAll_PARAM_Titre));
//        parameters.put("PARAM_LibelleMinistre", getLabel(CadrageAll_PARAM_LibelleMinistre));
//        parameters.put("PARAM_LocalisationPC", getLabel(CadrageAll_PARAM_LocalisationPC));
//        parameters.put("PARAM_Armoirie",armoirie);
//        parameters.put("PARAM_Drapeau",drapeau);
//        parameters.put("PARAM_Code", getLabel(CadrageAll_PARAM_Code));
//        parameters.put("PARAM_Libelle", getLabel(CadrageAll_PARAM_Libelle));
//        parameters.put("PARAM_LibelleUnite", getLabel(CadrageAll_PARAM_LibelleUnite));
//        parameters.put("PARAM_LibelleCB", getLabel(CadrageAll_PARAM_LibelleCB));
//        parameters.put("PARAM_Cout", getLabel(CadrageAll_PARAM_Cout));
//        parameters.put("PARAM_PROJET", getLabel(CadrageAll_PARAM_PROJET));
//        parameters.put("PARAM_Chapitre", getLabel(CadrageAll_PARAM_Chapitre));
//        parameters.put("PARAM_TYPE_CADRAGE", getLabel(CadrageAll_PARAM_TYPE_CADRAGE));
//        return parameters;
//    }
//
//    public HashMap CadrageGrandeMasse() {
//        HashMap parameters = new HashMap();
//        parameters.put("PARAM_Pays", getLabel(param_Pays));
//        parameters.put("PARAM_Devise", getLabel(param_Devise));
//        //parameters.put("PARAM_Logo",);
//        parameters.put("PARAM_PREPA_BUD", getLabel(CadrageGrandeMasse_PARAM_PREPA_BUD));
//        parameters.put("PARAM_Titre", getLabel(CadrageGrandeMasse_PARAM_Titre));
//        parameters.put("PARAM_LibelleMinistre", getLabel(CadrageGrandeMasse_PARAM_LibelleMinistre));
//        parameters.put("PARAM_LocalisationPC", getLabel(CadrageGrandeMasse_PARAM_LocalisationPC));
//        parameters.put("PARAM_Armoirie",armoirie);
//        parameters.put("PARAM_Drapeau",drapeau);
//        parameters.put("PARAM_Code", getLabel(CadrageGrandeMasse_PARAM_Code));
//        parameters.put("PARAM_Libelle", getLabel(CadrageGrandeMasse_PARAM_Libelle));
//        parameters.put("PARAM_LibelleUnite", getLabel(CadrageGrandeMasse_PARAM_LibelleUnite));
//        parameters.put("PARAM_LibelleCB", getLabel(CadrageGrandeMasse_PARAM_LibelleCB));
//        parameters.put("PARAM_Cout", getLabel(CadrageGrandeMasse_PARAM_Cout));
//        parameters.put("PARAM_PROJET", getLabel(CadrageGrandeMasse_PARAM_PROJET));
//        parameters.put("PARAM_Chapitre", getLabel(CadrageGrandeMasse_PARAM_Chapitre));
//        parameters.put("PARAM_TYPE_CADRAGE", getLabel(CadrageGrandeMasse_PARAM_TYPE_CADRAGE));
//        return parameters;
//    }
//
//    public HashMap CadrageSourceFin() {
//        HashMap parameters = new HashMap();
//        parameters.put("PARAM_Pays", getLabel(CadrageSourceFin_ param_Pays));
//        parameters.put("PARAM_Devise", getLabel(CadrageSourceFin param_Devise));
//        //parameters.put("PARAM_Logo",);
//        parameters.put("PARAM_PREPA_BUD", getLabel(CadrageSourceFin_PARAM_PREPA_BUD));
//        parameters.put("PARAM_Titre", getLabel(CadrageSourceFin_PARAM_Titre));
//        parameters.put("PARAM_LibelleMinistre", getLabel(CadrageSourceFin_PARAM_LibelleMinistre));
//        parameters.put("PARAM_LocalisationPC", getLabel(CadrageSourceFin_PARAM_LocalisationPC));
//        parameters.put("PARAM_Armoirie",armoirie);
//        parameters.put("PARAM_Drapeau",drapeau);
//        parameters.put("PARAM_Code", getLabel(CadrageSourceFin_PARAM_Code));
//        parameters.put("PARAM_Libelle", getLabel(CadrageSourceFin_PARAM_Libelle));
//        parameters.put("PARAM_LibelleUnite", getLabel(CadrageSourceFin_PARAM_LibelleUnite));
//        parameters.put("PARAM_LibelleCB", getLabel(CadrageSourceFin_PARAM_LibelleCB));
//        parameters.put("PARAM_Cout", getLabel(CadrageSourceFin_PARAM_Cout));
//        parameters.put("PARAM_PROJET", getLabel(CadrageSourceFin_PARAM_PROJET));
//        parameters.put("PARAM_Chapitre", getLabel(CadrageSourceFin_PARAM_Chapitre));
//        parameters.put("PARAM_TYPE_CADRAGE", getLabel(CadrageSourceFin_PARAM_TYPE_CADRAGE));
//        return parameters;
//    }
//
//    public HashMap CadreLogique() {
//        HashMap parameters = new HashMap();
//        parameters.put("chapitreFR", getLabel(CadreLogique_chapitreFR));
//        parameters.put("serviceFR", getLabel(CadreLogique_serviceFR));
//        parameters.put("paysFR", getLabel(CadreLogique_paysFR));
//        parameters.put("deviseFR", getLabel(CadreLogique_deviseFR));
//        parameters.put("chapitreEN", getLabel(CadreLogique_chapitreEN));
//        parameters.put("serviceEN", getLabel(CadreLogique_serviceEN));
//        parameters.put("paysEN", getLabel(CadreLogique_paysEN));
//        parameters.put("deviseEN", getLabel(CadreLogique_deviseEN));
//        parameters.put("uniteMontant", getLabel(CadreLogique_uniteMontant));
//        //parameters.put("logo",);
//        parameters.put("afficherGrapique", getLabel(CadreLogique_afficherGrapique));
//        parameters.put("lbl_Taches", getLabel(CadreLogique_lbl_Taches));
//        parameters.put("lbl_SommeOP", getLabel(CadreLogique_lbl_SommeOP));
//        parameters.put("lbl_Fin", getLabel(CadreLogique_lbl_Fin));
//        parameters.put("lbl_Debut", getLabel(CadreLogique_lbl_Debut));
//        parameters.put("lbl_Cadrage", getLabel(CadreLogique_lbl_Cadrage));
//        parameters.put("lbl_Source", getLabel(CadreLogique_lbl_Source));
//        parameters.put("lbl_Localite", getLabel(CadreLogique_lbl_Localite));
//        parameters.put("lbl_Equilibre", getLabel(CadreLogique_lbl_Equilibre));
//        parameters.put("lbl_PSFE", getLabel(CadreLogique_lbl_PSFE));
//        parameters.put("lbl_Programme", getLabel(CadreLogique_lbl_Programme));
//        parameters.put("lbl_CoutTache", getLabel(CadreLogique_lbl_CoutTache));
//        parameters.put("lbl_SF", getLabel(CadreLogique_lbl_SF));
//        return parameters;
//    }
//
//    public HashMap chargeBudgetaire(String unite) {
//        HashMap parameters = new HashMap();
//        parameters.put("PARAM_Pays", getLabel(param_Pays));
//        parameters.put("PARAM_Devise", getLabel(param_Devise));
//        //parameters.put("PARAM_Logo",);
//        parameters.put("PARAM_PREPA_BUD", getLabel(chargeBudgetaire_PARAM_PREPA_BUD));
//        parameters.put("PARAM_Titre", getLabel(chargeBudgetaire_PARAM_Titre));
//        parameters.put("PARAM_LibelleMinistre", getLabel(chargeBudgetaire_PARAM_LibelleMinistre));
//        parameters.put("PARAM_LocalisationPC", getLabel(chargeBudgetaire_PARAM_LocalisationPC));
//        parameters.put("PARAM_Armoirie", armoirie);
//        parameters.put("PARAM_Drapeau", drapeau);
//        parameters.put("PARAM_Imputation", getLabel(chargeBudgetaire_PARAM_Imputation));
//        parameters.put("PARAM_Libelle", getLabel(chargeBudgetaire_PARAM_Libelle));
//        parameters.put("PARAM_LibelleUnite", unite);
//        parameters.put("PARAM_LibelleCB", getLabel(chargeBudgetaire_PARAM_LibelleCB));
//        parameters.put("PARAM_EVALUATION_BES_CRED", getLabel(chargeBudgetaire_PARAM_EVALUATION_BES_CRED));
//        parameters.put("PARAM_DOTBASE", getLabel(chargeBudgetaire_PARAM_DOTBASE));
//        parameters.put("PARAM_AJUST", getLabel(chargeBudgetaire_PARAM_AJUST));
//        parameters.put("PARAM_TOTAL_CP", getLabel(chargeBudgetaire_PARAM_TOTAL_CP));
//        //parameters.put("PARAM_PROJET", getLabel(chargeBudgetaire_PARAM_PROJET));
//        parameters.put("PARAM_Chapitre", getLabel(chargeBudgetaire_PARAM_Chapitre));
//        parameters.put("PARAM_MAJ_PROJBUD", getLabel(chargeBudgetaire_PARAM_MAJ_PROJBUD));
//        parameters.put("PARAM_PRESENTATION_FCT", getLabel(chargeBudgetaire_PARAM_PRESENTATION_FCT));
//        return parameters;
//    }
    public HashMap chargeBudgetairePGAC(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isProgramme, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_Titre", getLabel(chargeBudgetairePGAC_PARAM_Titre));
        parameters.put("lblLocalisationPC", getLabel(chargeBudgetairePGAC_lblLocalisationPC));
        parameters.put("PARAM_Armoirie", armoirie);
        parameters.put("PARAM_Drapeau", drapeau);
        parameters.put("PARAM_Etoile", etoile);
        parameters.put("lblImputation", getLabel(chargeBudgetairePGAC_lblImputation));
        parameters.put("lblLibelle", getLabel(chargeBudgetairePGAC_lblLibelle));
        parameters.put("lblLibelleUnite", uniteMontant);
        parameters.put("lblEVALUATION_BES_CRED", getLabel(chargeBudgetairePGAC_lblEVALUATION_BES_CRED));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));
        parameters.put("lblChapitre", getLabel(chargeBudgetairePGAC_lblChapitre));
        parameters.put("lblPRESENTATION", getLabel(chargeBudgetairePGAC_lblPRESENTATION));
        parameters.put("lblPartie", getLabel(chargeBudgetairePGAC_lblPartie));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblTotalGl", getLabel(chargeBudgetairePGAC_lblTotalGl));
        parameters.put("lblParagraphe", getLabel(chargeBudgetairePGAC_lblParagraphe));
        parameters.put("lblArticle", getLabel(chargeBudgetairePGAC_lblArticle));
        parameters.put("lblSecteur", getLabel(chargeBudgetairePGAC_lblSecteur));
        parameters.put("lblFonction", getLabel(chargeBudgetairePGAC_lblFonction));
        parameters.put("lblProgramme", getLabel(chargeBudgetairePGAC_lblProgramme));
        parameters.put("lblAction", getLabel(chargeBudgetairePGAC_lblAction));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_IsPrgramme", isProgramme);
        parameters.put("uniteMontant", uniteMontant);
        return parameters;
    }

    public HashMap couvertureBudget(boolean imprimerDrapeau, boolean imprimerBande, boolean imprimerCMR, String entete1, String enetete2, String titre, String label, String code, String libelle, boolean afficherCadre) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_Pays", (imprimerCMR ? getLabel(param_Pays) : ""));
        parameters.put("PARAM_Devise", (imprimerCMR ? getLabel(param_Devise) : ""));
        parameters.put("PARAM_Drapeau", drapeau);
        parameters.put("PARAM_Armoirie", armoirie);
        parameters.put("PARAM_Etoile", etoile);
        parameters.put("PARAM_ChLibelle", libelle);
        parameters.put("PARAM_ChCode", code);
        parameters.put("PARAM_TitrePrincipale1", entete1);
        parameters.put("PARAM_TitrePrincipale2", enetete2);
        parameters.put("PARAM_Titre", titre);
        parameters.put("lblVersion", getLblVersion());
        parameters.put("lblChapitre", label);
        parameters.put("PARAM_AfficherCadre", afficherCadre);
        parameters.put("PARAM_AfficherBande", imprimerBande);
        parameters.put("PARAM_AfficherDrapeau", imprimerDrapeau);
        return parameters;
    }

    public HashMap depenseFpPgAcObIn(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lblFPProgramme", getLabel(DepenseFpPgAcObIn_lblFPProgramme).toUpperCase());
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", getLabel(DepenseFpPgAcObIn_PARAM_Titre));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblObjectif", getLabel(DepenseFpPgAcObIn_lblObjectif));
        parameters.put("lblIndicateur", getLabel(DepenseFpPgAcObIn_lblIndicateur));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));
        parameters.put("lblFP", getLabel(DepenseFpPgAcObIn_lblFP));
        parameters.put("lblProgramme", getLabel(DepenseFpPgAcObIn_lblProgramme));
        parameters.put("lblTotal", getLabel(DepenseFpPgAcObIn_lblTotal));
        return parameters;
    }

    public HashMap depensePgAcObIn(String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
//        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lblFPProgramme", getLabel(DepenseFpPgAcObIn_lblProgramme));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", getLabel(DepensePgAcObIn_PARAM_Titre_Comite));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblObjectif", getLabel(DepenseFpPgAcObIn_lblObjectif));
        parameters.put("lblIndicateur", getLabel(DepenseFpPgAcObIn_lblIndicateur));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));
        parameters.put("lblFP", getLabel(DepenseFpPgAcObIn_lblFP));
        parameters.put("lblProgramme", getLabel(DepenseFpPgAcObIn_lblProgramme));
        parameters.put("lblTotal", getLabel(DepenseFpPgAcObIn_lblTotal));
        return parameters;
    }

    public HashMap depenseFpPgAcObInPaysage(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft, boolean formComite) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lblFPProgramme", getLabel(DepenseFpPgAcObInPaysage_lblFPProgramme));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(DepenseFpPgAcObInPaysage_lblChapitre));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", getLabel(formComite ? DepenseFpPgAcObInPaysage_PARAM_Titre_Comite : DepenseFpPgAcObInPaysage_PARAM_Titre));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblObjectif", getLabel(DepenseFpPgAcObInPaysage_lblObjectif));
        parameters.put("lblIndicateur", getLabel(DepenseFpPgAcObInPaysage_lblIndicateur));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));
        parameters.put("lblProgramme", getLabel(DepenseFpPgAcObInPaysage_lblProgramme));
        parameters.put("lblFP", getLabel(DepenseFpPgAcObInPaysage_lblFP));
        parameters.put("lblAction", getLabel(DepenseFpPgAcObInPaysage_lblAction));
        parameters.put("lblTotal", getLabel(DepenseFpPgAcObInPaysage_lblTotal));
        return parameters;
    }

    public HashMap depensesParFctPgAr(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblTitre", getLabel(DepensesParFctPgAr_lblTitre));
        parameters.put("lblAnnee", getLabel(DepensesParFctPgAr_lblAnnee));
        parameters.put("lblChapitre", getLabel(DepensesParFctPgAr_lblChapitre));
        parameters.put("PARAM_Titre", getLabel(DepensesParFctPgAr_PARAM_Titre));
        parameters.put("PARAM_BudgetEtat", getLabel(DepensesParFctPgAr_PARAM_BudgetEtat));
        parameters.put("lblProgramme", getLabel(DepensesParFctPgAr_lblProgramme));
        parameters.put("lblArticle", getLabel(DepensesParFctPgAr_lblArticle));
        parameters.put("lblFP", getLabel(DepensesParFctPgAr_lblFP));
        parameters.put("lblCumul", getLabel(DepensesParFctPgAr_lblCumul));
        parameters.put("lblDI", getLabel(DepensesParFctPgAr_lblDI));
        parameters.put("lblDC", getLabel(DepensesParFctPgAr_lblDC));
        parameters.put("lblTotal", getLabel(DepensesParFctPgAr_lblTotal));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));
        parameters.put("lblVersion", getLblVersion());
        return parameters;
    }

    public HashMap developpementDepenses(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");
        parameters.put("serviceFR", "");
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");
        parameters.put("chapitreEN", "");
        parameters.put("serviceEN", "");
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblChapitre", getLblCHAPITRE());
        parameters.put("lblAnnee", getAnnee().toUpperCase());
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblPrevision", getLabel(budgetEtatChapitreRecap_lblPrevision));
        parameters.put("lblCode", getLabel(budgetEtatChapitreRecap_lblCode));
        parameters.put("lblLibelle", getLabel(budgetEtatChapitreRecap_lblLibelle));
//      parameters.put("PARAM_CodeDC",getLabel(developpementDepenses_PARAM_CodeDC));
//      parameters.put("PARAM_CodeDI",getLabel(developpementDepenses_PARAM_CodeDI));
        parameters.put("PARAM_LibelleDC", getLabel(budgetEtatChapitre_PARAM_LibelleDC).toUpperCase());
        parameters.put("PARAM_LibelleDI", getLabel(budgetEtatChapitre_PARAM_LibelleDI).toUpperCase());
        parameters.put("lblTotal", getLabel(budgetEtatChapitreRecap_lblTotal));
        parameters.put("PARAM_Titre", titreDeveloppementDepenses());
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat).toUpperCase());
        return parameters;
    }

    public HashMap depensesParFonctionEtNatureEco(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");
        parameters.put("serviceFR", "");
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");
        parameters.put("chapitreEN", "");
        parameters.put("serviceEN", "");
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", titreDepensesParFonctionEtNatureEco());
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblNE", getLabel(depensesParFS_SEEtNatureEco_lblNE));
        parameters.put("lblFS", getLabel(depensesParFonctionEtNatureEco_lblFS));
        parameters.put("lblChapitre", getLblCHAPITRE());
        return parameters;
    }

    public HashMap depensesParSecteurEtNatureEco(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");
        parameters.put("serviceFR", "");
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", "");
        parameters.put("chapitreEN", "");
        parameters.put("serviceEN", "");
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", "");
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", titreDepensesParSecteurEtNatureEco());
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblNE", getLabel(depensesParFS_SEEtNatureEco_lblNE));
        parameters.put("lblSE", getLabel(depensesParSecteurEtNatureEco_lblSE));
        return parameters;
    }

    public HashMap evolutionMasseSalariale(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isFicheMinisterielle, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(EvolutionMasseSalariale_lblChapitre));
        parameters.put("PARAM_Titre", getLabel(EvolutionMasseSalariale_PARAM_Titre));
        parameters.put("PARAM_Fonctionnaires", getLabel(EvolutionMasseSalariale_PARAM_Fonctionnaires));
        parameters.put("PARAM_PersonnelCodeTravail", getLabel(EvolutionMasseSalariale_PARAM_PersonnelCodeTravail));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("lblCategories", getLabel(EvolutionMasseSalariale_lblCategories));
        parameters.put("lblEffectifs", getLabel(EvolutionMasseSalariale_lblEffectifs));
        parameters.put("lblMS", getLabel(EvolutionMasseSalariale_lblMS));
        parameters.put("lblEvolution", getLabel(EvolutionMasseSalariale_lblEvolution));
        parameters.put("lblSousTotal", getLabel(EvolutionMasseSalariale_lblSousTotal));
        parameters.put("lblPersSoldeGlobale", getLabel(EvolutionMasseSalariale_lblPersSoldeGlobale));
        parameters.put("lblTotalGl", getLabel(EvolutionMasseSalariale_lblTotalGl));
        parameters.put("lblDescMS", getLabel(EvolutionMasseSalariale_lblDescMS));
        parameters.put("lblVersion", getLblVersion());
        parameters.put("PARAM_IS_FICHE_MIN", isFicheMinisterielle);
        parameters.put("lblTypeFiche", getLabel(EvolutionMasseSalariale_lblTypeFiche));
        return parameters;
    }

    public HashMap ficheDeCollecte(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("PARAM_Titre", getLabel(ficheDeCollecte_PARAM_Titre));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(ficheDeCollecte_lblChapitre));
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblProgramme", getLabel(ficheDeCollecte_lblProgramme));
        parameters.put("lblintituleAction", getLabel(ficheDeCollecte_lblintituleAction));
        parameters.put("lblIntituleActivite", getLabel(ficheDeCollecte_lblIntituleActivite));
        parameters.put("lblIntituleTache", getLabel(ficheDeCollecte_lblIntituleTache));
        parameters.put("lblSection", getLabel(ficheDeCollecte_lblSection));
        parameters.put("lbluniteAdministrative", getLabel(ficheDeCollecte_lbluniteAdministrative));
        parameters.put("lblCode", getLabel(ficheDeCollecte_lblCode));
        parameters.put("lblListeNE", getLabel(ficheDeCollecte_lblListeNE));
        parameters.put("lblLibelle", getLabel(ficheDeCollecte_lblLibelle));
        parameters.put("lblCout", getLabel(ficheDeCollecte_lblCout));
        parameters.put("lblCoutTache", getLabel(ficheDeCollecte_lblCoutTache));
        parameters.put("lblCoutActivite", getLabel(ficheDeCollecte_lblCoutActivite));
        parameters.put("lblCoutAction", getLabel(ficheDeCollecte_lblCoutAction));
        parameters.put("lblCoutProgramme", getLabel(ficheDeCollecte_lblCoutProgramme));
        parameters.put("lblCoutChapitre", getLabel(ficheDeCollecte_lblCoutChapitre));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));

        return parameters;
    }

    public HashMap fonctionParChapitre(String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", getLabel(fonctionParChapitre_PARAM_Titre));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblFP", getLabel(fonctionParChapitre_lblFP));
        return parameters;
    }
//
//    public HashMap jpi() {
//        HashMap parameters = new HashMap();
//        parameters.put("PARAM_Pays", getLabel(param_Pays));
//        parameters.put("PARAM_Devise", getLabel(param_Devise));
//        //parameters.put("PARAM_Logo",);
//        parameters.put("PARAM_Description", getLabel(jpi_PARAM_Description));
//        parameters.put("PARAM_Titre", getLabel(jpi_PARAM_Titre));
//        parameters.put("PARAM_LibelleMinistre", getLabel(jpi_PARAM_LibelleMinistre));
//        parameters.put("PARAM_LibelleSection", getLabel(jpi_PARAM_LibelleSection));
//        parameters.put("PARAM_Armoirie",armoirie);
//        parameters.put("PARAM_Drapeau",drapeau);
//        parameters.put("PARAM_LibelleUnite", getLabel(jpi_PARAM_LibelleUnite));
//        parameters.put("PARAM_PROGRAMME", getLabel(jpi_PARAM_PROGRAMME));
//        parameters.put("PARAM_CHAPITRE", getLabel(jpi_PARAM_CHAPITRE));
//        parameters.put("PARAM_TOTAL", getLabel(jpi_PARAM_TOTAL));
//        parameters.put("PARAM_Page_Prefix", getLabel(jpi_page_Prefix);
//        parameters.put("PARAM_Page_Suffixe", getLabel(jpi_page_Suffixe);
//        parameters.put("PARAM_DebutPage", getLabel(jpi_debutPage);
//        parameters.put("PARAM_NoteExplicative", getLabel(jpi_PARAM_NoteExplicative));
//        parameters.put("PARAM_TexteNoteExplicative", getLabel(jpi_PARAM_TexteNoteExplicative));
//        parameters.put("PARAM_Sommaire", getLabel(jpi_PARAM_Sommaire));
//        parameters.put("chapitreFR", getLabel(jpi_chapitreFR));
//        parameters.put("serviceFR", getLabel(jpi_serviceFR));
//        parameters.put("paysFR", getLabel(jpi_paysFR));
//        parameters.put("deviseFR", getLabel(jpi_deviseFR));
//        parameters.put("chapitreEN", getLabel(jpi_chapitreEN));
//        parameters.put("serviceEN", getLabel(jpi_serviceEN));
//        parameters.put("paysEN", getLabel(jpi_paysEN));
//        parameters.put("deviseEN", getLabel(jpi_deviseEN));
//        parameters.put("PARAM_Projet", getLabel(jpi_PARAM_Projet));
//        parameters.put("PARAM_LibelleRecap", getLabel(jpi_PARAM_LibelleRecap));
//        parameters.put("PARAM_PageRecap", getLabel(jpi_PARAM_PageRecap));
//        return parameters;
//    }
//
//    public HashMap jpi_PTA() {
//        HashMap parameters = new HashMap();
//        parameters.put("chapitreFR", getLabel(jpi_PTA_chapitreFR));
//        parameters.put("serviceFR", getLabel(jpi_PTA_serviceFR));
//        parameters.put("paysFR", getLabel(jpi_PTA_paysFR));
//        parameters.put("deviseFR", getLabel(jpi_PTA_deviseFR));
//        parameters.put("chapitreEN", getLabel(jpi_PTA_chapitreEN));
//        parameters.put("serviceEN", getLabel(jpi_PTA_serviceEN));
//        parameters.put("paysEN", getLabel(jpi_PTA_paysEN));
//        parameters.put("deviseEN", getLabel(jpi_PTA_deviseEN));
//        parameters.put("uniteMontant", getLabel(jpi_PTA_uniteMontant));
//        //parameters.put("logo",);
//        parameters.put("lbl_Operation", getLabel(jpi_PTA_lbl_Operation));
//        parameters.put("lbl_Titre", getLabel(jpi_PTA_lbl_Titre));
//        parameters.put("lbl_Projet", getLabel(jpi_PTA_lbl_Projet));
//        parameters.put("lbl_Total", getLabel(jpi_PTA_lbl_Total));
//        parameters.put("lbl_Cout", getLabel(jpi_PTA_lbl_Cout));
//        parameters.put("lbl_Region", getLabel(jpi_PTA_lbl_Region));
//        parameters.put("lbl_Departement", getLabel(jpi_PTA_lbl_Departement));
//        parameters.put("lbl_Arrondissement", getLabel(jpi_PTA_lbl_Arrondissement));
//        parameters.put("lbl_PosteComptable", getLabel(jpi_PTA_lbl_PosteComptable));
//        parameters.put("lbl_Localite", getLabel(jpi_PTA_lbl_Localite));
//        parameters.put("lbl_MG", getLabel(jpi_PTA_lbl_MG));
//        parameters.put("lbl_MMarche", getLabel(jpi_PTA_lbl_MMarche));
//        parameters.put("lbl_Gestionnaire", getLabel(jpi_PTA_lbl_Gestionnaire));
//        parameters.put("lbl_CodeBudgetaire", getLabel(jpi_PTA_lbl_CodeBudgetaire));
//        parameters.put("lbl_Chapitre", getLabel(jpi_PTA_lbl_Chapitre));
//        parameters.put("lbl_Action", getLabel(jpi_PTA_lbl_Action));
//        parameters.put("lbl_Programme", getLabel(jpi_PTA_lbl_Programme));
//        parameters.put("PARAM_Page_Prefix", getLabel(jpi_PTA_page_Prefix);
//        parameters.put("PARAM_Page_Suffixe", getLabel(jpi_PTA_page_Suffixe);
//        parameters.put("PARAM_DebutPage", getLabel(jpi_PTA_debutPage);
//        parameters.put("PARAM_CoutTotal", getLabel(jpi_PTA_PARAM_CoutTotal));
//        parameters.put("PARAM_Index", getLabel(jpi_PTA_PARAM_Index));
//        return parameters;
//    }
//
//    public HashMap jpi_recap() {
//        HashMap parameters = new HashMap();
//        parameters.put("PARAM_Pays", getLabel(jpi_recap_ param_Pays));
//        parameters.put("PARAM_Devise", getLabel(jpi_recap param_Devise));
//        //parameters.put("PARAM_Logo",);
//        parameters.put("PARAM_Description", getLabel(jpi_recap_PARAM_Description));
//        parameters.put("PARAM_Titre", getLabel(jpi_recap_PARAM_Titre));
//        parameters.put("PARAM_LibelleMinistre", getLabel(jpi_recap_PARAM_LibelleMinistre));
//        parameters.put("PARAM_LibelleSection", getLabel(jpi_recap_PARAM_LibelleSection));
//        parameters.put("PARAM_Armoirie",armoirie);
//        parameters.put("PARAM_Drapeau",drapeau);
//        parameters.put("PARAM_LibelleUnite", getLabel(jpi_recap_PARAM_LibelleUnite));
//        parameters.put("PARAM_PROGRAMME", getLabel(jpi_recap_PARAM_PROGRAMME));
//        parameters.put("PARAM_CHAPITRE", getLabel(jpi_recap_PARAM_CHAPITRE));
//        parameters.put("PARAM_TOTAL", getLabel(jpi_recap_PARAM_TOTAL));
//        parameters.put("PARAM_Page_Prefix", getLabel(jpi_recap_page_Prefix);
//        parameters.put("PARAM_Page_Suffixe", getLabel(jpi_recap_page_Suffixe);
//        parameters.put("PARAM_DebutPage", getLabel(jpi_recap_debutPage);
//        parameters.put("PARAM_NoteExplicative", getLabel(jpi_recap_PARAM_NoteExplicative));
//        parameters.put("PARAM_TexteNoteExplicative", getLabel(jpi_recap_PARAM_TexteNoteExplicative));
//        parameters.put("PARAM_Recap", getLabel(jpi_recap_PARAM_Recap));
//        parameters.put("chapitreFR", getLabel(jpi_recap_chapitreFR));
//        parameters.put("serviceFR", getLabel(jpi_recap_serviceFR));
//        parameters.put("paysFR", getLabel(jpi_recap_paysFR));
//        parameters.put("deviseFR", getLabel(jpi_recap_deviseFR));
//        parameters.put("chapitreEN", getLabel(jpi_recap_chapitreEN));
//        parameters.put("serviceEN", getLabel(jpi_recap_serviceEN));
//        parameters.put("paysEN", getLabel(jpi_recap_paysEN));
//        parameters.put("deviseEN", getLabel(jpi_recap_deviseEN));
//        parameters.put("PARAM_Projet", getLabel(jpi_recap_PARAM_Projet));
//        parameters.put("PARAM_LibelleRecap", getLabel(jpi_recap_PARAM_LibelleRecap));
//        parameters.put("PARAM_PageRecap", getLabel(jpi_recap_PARAM_PageRecap));
//        return parameters;
//    }
//

    public HashMap listeProgramme(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean isDraft) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lblFPProgramme", getLabel(listeProgramme_lblFPProgramme));
        parameters.put("lblProjet", (isDraft ? getLabel(budgetEtatChapitre_lblProjet) : getLabel(budgetEtatChapitre_lblDefinitif)));
        parameters.put("lblAnnee", getLabel(budgetEtatChapitre_lblAnnee));
        parameters.put("lblChapitre", getLabel(budgetEtatChapitre_lblChapitre));
        parameters.put("PARAM_BudgetEtat", getLabel(budgetEtatChapitre_PARAM_BudgetEtat));
        parameters.put("PARAM_Titre", getLabel(listeProgramme_PARAM_Titre));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("lblObjectif", getLabel(listeProgramme_lblObjectif));
        parameters.put("lblIndicateur", getLabel(listeProgramme_lblIndicateur));
        parameters.put("lblAE", getLabel(lblAE));
        parameters.put("lblCP", getLabel(lblCP));
        parameters.put("lblProgramme", getLabel(listeProgramme_lblProgramme));
        parameters.put("lblFP", getLabel(listeProgramme_lblFP));
        parameters.put("lblAction", getLabel(listeProgramme_lblAction));
        return parameters;
    }
//
//    public HashMap pageVersionPaysage() {
//        HashMap parameters = new HashMap();
//        parameters.put("chapitreFR", getLabel(pageVersionPaysage_chapitreFR));
//        parameters.put("serviceFR", getLabel(pageVersionPaysage_serviceFR));
//        parameters.put("paysFR", getLabel(pageVersionPaysage_paysFR));
//        parameters.put("deviseFR", getLabel(pageVersionPaysage_deviseFR));
//        parameters.put("chapitreEN", getLabel(pageVersionPaysage_chapitreEN));
//        parameters.put("serviceEN", getLabel(pageVersionPaysage_serviceEN));
//        parameters.put("paysEN", getLabel(pageVersionPaysage_paysEN));
//        parameters.put("deviseEN", getLabel(pageVersionPaysage_deviseEN));
//        parameters.put("uniteMontant", getLabel(pageVersionPaysage_uniteMontant));
//        //parameters.put("logo",);
//        parameters.put("lblProgramme", getLabel(pageVersionPaysage_lblProgramme));
//        parameters.put("PARAM_Page_Prefix", getLabel(pageVersionPaysage_page_Prefix);
//        parameters.put("PARAM_Page_Suffixe", getLabel(pageVersionPaysage_page_Suffixe);
//        parameters.put("PARAM_DebutPage", getLabel(pageVersionPaysage_debutPage);
//        parameters.put("lblProjet"*, getLabel(pageVersionPaysage_lblProjet));
//        parameters.put("lblTitre", getLabel(pageVersionPaysage_lblTitre));
//        parameters.put("lblAnnee", getLabel(pageVersionPaysage_lblAnnee));
//        parameters.put("lblChapitre", getLabel(pageVersionPaysage_lblChapitre));
//        parameters.put("PARAM_Titre", getLabel(pageVersionPaysage_PARAM_Titre));
//        parameters.put("PARAM_BudgetEtat", getLabel(pageVersionPaysage_PARAM_BudgetEtat));
//        parameters.put("lblArticle", getLabel(pageVersionPaysage_lblArticle));
//        parameters.put("lblFP", getLabel(pageVersionPaysage_lblFP));
//        parameters.put("lblCumul", getLabel(pageVersionPaysage_lblCumul));
//        parameters.put("lblDI", getLabel(pageVersionPaysage_lblDI));
//        parameters.put("lblDC", getLabel(pageVersionPaysage_lblDC));
//        parameters.put("lblTotal", getLabel(pageVersionPaysage_lblTotal));
//        parameters.put("lblAE", getLabel(pageVersionPaysage_lblAE));
//        parameters.put("lblCP", getLabel(pageVersionPaysage_lblCP));
//        parameters.put("lblVersion", getLabel(pageVersionPaysage_lblVersion));
//        return parameters;
//    }

    public HashMap ppa(String noteExplicative, int sommaire1, int sommaire2, int sommaire3, int sommaire4, int sommaire5, int sommaire6) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_Pays", getLabel(param_Pays));
        parameters.put("PARAM_Devise", getLabel(param_Devise));
        parameters.put("PARAM_Drapeau", drapeau);
        parameters.put("PARAM_Armoirie", armoirie);
        parameters.put("PARAM_Etoile", etoile);
        //parameters.put("PARAM_Logo",);
        parameters.put("PARAM_Titre", getLabel(ppa_PARAM_Titre));
        parameters.put("PARAM_LibelleMinistre", getLabel(ppa_PARAM_LibelleMinistre));
        parameters.put("PARAM_NoteExplicative", getLabel(ppa_PARAM_NoteExplicative));
        parameters.put("PARAM_TexteNoteExplicative", noteExplicative);
        parameters.put("PARAM_ResponsableProgramme", getLabel(ppa_PARAM_ResponsableProgramme));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PARAM_LibelleProgramme));
        parameters.put("PARAM_Sommaire", getLabel(ppa_PARAM_Sommaire));
        parameters.put("PARAM_Sommaire_1", getLabel(ppa_PARAM_Sommaire_1));
        parameters.put("PARAM_Sommaire_2", getLabel(ppa_PARAM_Sommaire_2));
        parameters.put("PARAM_Sommaire_3", getLabel(ppa_PARAM_Sommaire_3));
        parameters.put("PARAM_Sommaire_4", getLabel(ppa_PARAM_Sommaire_4));
        parameters.put("PARAM_Sommaire_5", getLabel(ppa_PARAM_Sommaire_5));
        parameters.put("PARAM_Sommaire_6", getLabel(ppa_PARAM_Sommaire_6));
        parameters.put("VALEUR_SommairePage_1", sommaire1);
        parameters.put("VALEUR_SommairePage_2", sommaire2);
        parameters.put("VALEUR_SommairePage_3", sommaire3);
        parameters.put("VALEUR_SommairePage_4", sommaire4);
        parameters.put("VALEUR_SommairePage_5", sommaire5);
        parameters.put("VALEUR_SommairePage_6", sommaire6);
        parameters.put("PARAM_CoordonnateurProgramme", getLabel(ppa_PARAM_CoordonnateurProgramme));
        return parameters;
    }

    public HashMap ppa_CadreLogiqueSimple(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("lblTitre_CL", getLabel(ppa_CadreLogique_lblTitre_CL));
        parameters.put("lblProgramme", getLabel(ppa_CadreLogique_lblProgramme));
        parameters.put("lbl_Objectif", getLabel(ppa_CadreLogique_lbl_Objectif));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lblListeAction", getLabel(ppa_CadreLogique_lblListeAction));
        return parameters;
    }

    public HashMap ppa_PresentationActions(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage,
            JRBeanCollectionDataSource jrdsDetail, InputStream etatDetail, JRBeanCollectionDataSource jrdsObjectif, InputStream etatObjectif, String prefixPiedPage) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Actions", getLabel(ppa_PresentationActions_PARAM_Titre_Actions));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationActions_PARAM_LibelleProgramme));
        parameters.put("PARAM_LibellePresentationProgramme", getLabel(ppa_PresentationActions_PARAM_LibellePresentationProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_LibellePresentationAction", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".3       ") + getLabel(ppa_PresentationActions_PARAM_LibellePresentationAction));
        parameters.put("PARAM_Libelle_StrategieProgramme", getLabel(ppa_PresentationActions_PARAM_Libelle_StrategieProgramme));
        parameters.put("PARAM_LibelleRecap", getLabel(ppa_PresentationActions_PARAM_LibelleRecap));
        parameters.put("PARAM_TitreObjectifs", getLabel(ppa_PresentationActions_PARAM_TitreObjectifs));
        parameters.put("jrds_Detail", jrdsDetail);
        parameters.put("sousEtat_Detail", etatDetail);
        parameters.put("jrds_Objectif", jrdsObjectif);
        parameters.put("sousEtat_Objectif", etatObjectif);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lbl_Objectif", getLabel(ppa_PresentationActions_lbl_Objectif));
        parameters.put("lbl_Indicateur", getLabel(ppa_PresentationActions_lbl_Indicateur));
        parameters.put("lbl_Valeur", getLabel(ppa_PresentationActions_lbl_Valeur));
        parameters.put("lbl_Date", getLabel(ppa_PresentationActions_lbl_Date));
        parameters.put("lbl_UniteMesure", getLabel(ppa_PresentationActions_lbl_UniteMesure));
        parameters.put("lbl_Cible", getLabel(ppa_PresentationActions_lbl_Cible));
        parameters.put("lbl_Reference", getLabel(ppa_PresentationActions_lbl_Reference));
        parameters.put("lbl_Action", getLabel(ppa_PresentationActions_lbl_Action));
        parameters.put("PARAM_PrefixPiedPage", prefixPiedPage);
        return parameters;
    }

    public HashMap ppa_PresentationCredit(Short styleIndex, String plf, String libellePPA, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, String prefixPiedPage) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Credit", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".4       ") + getLabel(ppa_PresentationCredit_PARAM_Titre_Credit));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationCredit_PARAM_LibelleProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_CL_Action", getLabel(ppa_PresentationCredit_PARAM_CL_Action));
        parameters.put("PARAM_CL_DepenseCourante", getLabel(ppa_PresentationCredit_PARAM_CL_DepenseCourante));
        parameters.put("PARAM_CL_DepenseInvestissement", getLabel(ppa_PresentationCredit_PARAM_CL_DepenseInvestissement));
        parameters.put("PARAM_CL_DepenseOpFin", getLabel(ppa_PresentationCredit_PARAM_CL_DepenseOpFin));
        parameters.put("PARAM_CL_Total", getLabel(ppa_PresentationCredit_PARAM_CL_Total));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        //parameters.put("PARAM_Sommaire", getLabel(ppa_PARAM_Sommaire));
        parameters.put("PARAM_uniteMontant", uniteMontant);
        parameters.put("PARAM_CL_AE", getLabel(ppa_PresentationCredit_PARAM_CL_AE));
        parameters.put("PARAM_CL_CP", getLabel(ppa_PresentationCredit_PARAM_CL_CP));
        parameters.put("PARAM_PrefixPiedPage", prefixPiedPage);
        return parameters;
    }

    public HashMap ppa_PresentationCreditRecap(Short styleIndex, String titre, String plf, String libellePPA, String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, String chCode, String chLibelle) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Credit", getLabel(ppa_PresentationCreditRecap_PARAM_Titre_Credit));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationCreditRecap_PARAM_LibelleProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_CL_Programme", getLabel(ppa_PresentationCreditRecap_PARAM_CL_Programme));
        parameters.put("PARAM_CL_DepenseCourante", getLabel(ppa_PresentationCreditRecap_PARAM_CL_DepenseCourante));
        parameters.put("PARAM_CL_DepenseInvestissement", getLabel(ppa_PresentationCreditRecap_PARAM_CL_DepenseInvestissement));
        parameters.put("PARAM_CL_DepenseOpFin", getLabel(ppa_PresentationCreditRecap_PARAM_CL_DepenseOpFin));
        parameters.put("PARAM_CL_Total", getLabel(ppa_PresentationCreditRecap_PARAM_CL_Total));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_Sommaire", getLabel(ppa_PARAM_Sommaire));
        parameters.put("uniteMontant", uniteMontant);
        parameters.put("PARAM_CL_CP", getLabel(ppa_PresentationCreditRecap_PARAM_CL_CP));
        parameters.put("PARAM_CL_CP_FULL", getLabel(ppa_PresentationCreditRecap_PARAM_CL_CP_FULL));
        parameters.put("PARAM_CL_AE", getLabel(ppa_PresentationCreditRecap_PARAM_CL_AE));
        parameters.put("PARAM_CL_AE_FULL", getLabel(ppa_PresentationCreditRecap_PARAM_CL_AE_FULL));
        parameters.put("lblChapitre", getLabel(lblCHAPITRE));
        parameters.put("PARAM_TitrePartie", titre);
        parameters.put("chCodeChapitre", chCode);
        parameters.put("chLibelle", chLibelle);
        return parameters;
    }

    public HashMap ppa_PresentationProgramme(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage,
            JRBeanCollectionDataSource jrdsDetail, InputStream etatDetail, JRBeanCollectionDataSource jrdsObjectif, InputStream etatObjectif, String prefixPiedPage) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Actions", getLabel(ppa_PresentationProgramme_PARAM_Titre_Actions));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationProgramme_PARAM_LibelleProgramme));
        parameters.put("PARAM_LibellePresentationProgramme", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".1       ") + getLabel(ppa_PresentationProgramme_PARAM_LibellePresentationProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_LibellePresentationAction", getLabel(ppa_PresentationProgramme_PARAM_LibellePresentationAction));
        parameters.put("PARAM_Libelle_StrategieProgramme", getLabel(ppa_PresentationProgramme_PARAM_Libelle_StrategieProgramme));
        parameters.put("PARAM_LibelleRecap", getLabel(ppa_PresentationProgramme_PARAM_LibelleRecap));
        parameters.put("PARAM_TitreObjectifs", getLabel(ppa_PresentationProgramme_PARAM_TitreObjectifs));
        parameters.put("jrds_Detail", jrdsDetail);
        parameters.put("sousEtat_Detail", etatDetail);
        parameters.put("jrds_Objectif", jrdsObjectif);
        parameters.put("sousEtat_Objectif", etatObjectif);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lbl_Objectif", getLabel(ppa_PresentationProgramme_lbl_Objectif));
        parameters.put("lbl_Indicateur", getLabel(ppa_PresentationProgramme_lbl_Indicateur));
        parameters.put("lbl_Valeur", getLabel(ppa_PresentationProgramme_lbl_Valeur));
        parameters.put("lbl_Date", getLabel(ppa_PresentationProgramme_lbl_Date));
        parameters.put("lbl_UniteMesure", getLabel(ppa_PresentationProgramme_lbl_UniteMesure));
        parameters.put("lbl_Cible", getLabel(ppa_PresentationProgramme_lbl_Cible));
        parameters.put("lbl_Reference", getLabel(ppa_PresentationProgramme_lbl_Reference));
        parameters.put("lbl_Action", getLabel(ppa_PresentationProgramme_lbl_Action));
        parameters.put("PARAM_PrefixPiedPage", prefixPiedPage);
        return parameters;
    }

    public HashMap ppa_ProgrammeFull(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage,
            JRBeanCollectionDataSource jrdsDetail, InputStream etatDetail,
            JRBeanCollectionDataSource jrdsObjectif, InputStream etatObjectif,
            JRBeanCollectionDataSource jrdsCredit, InputStream etatCredit,
            String prefixPiedPage, String uniteMontant) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Actions", getLabel(ppa_PresentationProgramme_PARAM_Titre_Actions));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationProgramme_PARAM_LibelleProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_LibellePresentationAction", getLabel(ppa_PresentationProgramme_PARAM_LibellePresentationAction));
        parameters.put("PARAM_Libelle_StrategieProgramme", getLabel(ppa_PresentationProgramme_PARAM_Libelle_StrategieProgramme));
        parameters.put("PARAM_LibelleRecap", getLabel(ppa_PresentationProgramme_PARAM_LibelleRecap));
        parameters.put("PARAM_TitreObjectifs", getLabel(ppa_PresentationProgramme_PARAM_TitreObjectifs));
        parameters.put("jrds_Detail", jrdsDetail);
        parameters.put("sousEtat_Detail", etatDetail);
        parameters.put("jrds_Objectif", jrdsObjectif);
        parameters.put("sousEtat_Objectif", etatObjectif);
        parameters.put("jrds_Credit", jrdsCredit);
        parameters.put("sousEtat_Credit", etatCredit);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lbl_Objectif", getLabel(ppa_PresentationProgramme_lbl_Objectif));
        parameters.put("lbl_Indicateur", getLabel(ppa_PresentationProgramme_lbl_Indicateur));
        parameters.put("lbl_Valeur", getLabel(ppa_PresentationProgramme_lbl_Valeur));
        parameters.put("lbl_Date", getLabel(ppa_PresentationProgramme_lbl_Date));
        parameters.put("lbl_UniteMesure", getLabel(ppa_PresentationProgramme_lbl_UniteMesure));
        parameters.put("lbl_Cible", getLabel(ppa_PresentationProgramme_lbl_Cible));
        parameters.put("lbl_Reference", getLabel(ppa_PresentationProgramme_lbl_Reference));
        parameters.put("lbl_Action", getLabel(ppa_PresentationProgramme_lbl_Action));
        parameters.put("PARAM_PrefixPiedPage", prefixPiedPage);
        //
        parameters.put("PARAM_LibellePresentationProgramme", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".1       ") + getLabel(ppa_PresentationProgramme_PARAM_LibellePresentationProgramme));
        //
        parameters.put("PARAM_Libelle_StrategieProgramme", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".2       ") + getLabel(ppa_PresentationProgrammeStrategie_PARAM_Libelle_StrategieProgramme));
        //
        parameters.put("PARAM_LibellePresentationAction", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".3       ") + getLabel(ppa_PresentationActions_PARAM_LibellePresentationAction));
        //
        parameters.put("PARAM_Titre_Credit", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".4       ") + getLabel(ppa_PresentationCredit_PARAM_Titre_Credit));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationCredit_PARAM_LibelleProgramme));
        parameters.put("PARAM_CL_Action", getLabel(ppa_PresentationCredit_PARAM_CL_Action));
        parameters.put("PARAM_CL_DepenseCourante", getLabel(ppa_PresentationCredit_PARAM_CL_DepenseCourante));
        parameters.put("PARAM_CL_DepenseInvestissement", getLabel(ppa_PresentationCredit_PARAM_CL_DepenseInvestissement));
        parameters.put("PARAM_CL_DepenseOpFin", getLabel(ppa_PresentationCredit_PARAM_CL_DepenseOpFin));
        parameters.put("PARAM_CL_Total", getLabel(ppa_PresentationCredit_PARAM_CL_Total));
        parameters.put("PARAM_uniteMontant", uniteMontant);
        parameters.put("PARAM_CL_AE", getLabel(ppa_PresentationCredit_PARAM_CL_AE));
        parameters.put("PARAM_CL_CP", getLabel(ppa_PresentationCredit_PARAM_CL_CP));

        return parameters;
    }

    public HashMap ppa_PresentationProgrammeActionsRecap(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("lbl_Action", getLabel(ppa_PresentationProgrammeActionsRecap_lbl_Action));
        return parameters;
    }

    public HashMap ppa_PresentationProgrammeEtActions(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage,
            JRBeanCollectionDataSource jrdsDetail, InputStream etatDetail, JRBeanCollectionDataSource jrdsObjectif, InputStream etatObjectif) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Actions", getLabel(ppa_PresentationProgrammeEtActions_PARAM_Titre_Actions));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationProgrammeEtActions_PARAM_LibelleProgramme));
        parameters.put("PARAM_LibellePresentationProgramme", getLabel(ppa_PresentationProgrammeEtActions_PARAM_LibellePresentationProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_LibellePresentationAction", getLabel(ppa_PresentationProgrammeEtActions_PARAM_LibellePresentationAction));
        parameters.put("PARAM_Libelle_StrategieProgramme", getLabel(ppa_PresentationProgrammeEtActions_PARAM_Libelle_StrategieProgramme));
        parameters.put("PARAM_LibelleRecap", getLabel(ppa_PresentationProgrammeEtActions_PARAM_LibelleRecap));
        parameters.put("PARAM_TitreObjectifs", getLabel(ppa_PresentationProgrammeEtActions_PARAM_TitreObjectifs));
        parameters.put("jrds_Detail", jrdsDetail);
        parameters.put("sousEtat_Detail", etatDetail);
        parameters.put("jrds_Objectif", jrdsObjectif);
        parameters.put("sousEtat_Objectif", etatObjectif);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lbl_Objectif", getLabel(ppa_PresentationProgrammeEtActions_lbl_Objectif));
        parameters.put("lbl_Indicateur", getLabel(ppa_PresentationProgrammeEtActions_lbl_Indicateur));
        parameters.put("lbl_Valeur", getLabel(ppa_PresentationProgrammeEtActions_lbl_Valeur));
        parameters.put("lbl_Date", getLabel(ppa_PresentationProgrammeEtActions_lbl_Date));
        parameters.put("lbl_UniteMesure", getLabel(ppa_PresentationProgrammeEtActions_lbl_UniteMesure));
        parameters.put("lbl_Cible", getLabel(ppa_PresentationProgrammeEtActions_lbl_Cible));
        parameters.put("lbl_Reference", getLabel(ppa_PresentationProgrammeEtActions_lbl_Reference));
        parameters.put("lbl_Action", getLabel(ppa_PresentationProgrammeEtActions_lbl_Action));
        return parameters;
    }

    public HashMap ppa_PresentationProgrammeStrategie(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage,
            JRBeanCollectionDataSource jrdsDetail, InputStream etatDetail, JRBeanCollectionDataSource jrdsObjectif, InputStream etatObjectif, String prefixPiedPage) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Actions", getLabel(ppa_PresentationProgrammeStrategie_PARAM_Titre_Actions));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PresentationProgrammeStrategie_PARAM_LibelleProgramme));
        parameters.put("PARAM_LibellePresentationProgramme", getLabel(ppa_PresentationProgrammeStrategie_PARAM_LibellePresentationProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_LibellePresentationAction", getLabel(ppa_PresentationProgrammeStrategie_PARAM_LibellePresentationAction));
        parameters.put("PARAM_Libelle_StrategieProgramme", (styleIndex == null ? "" : Short.toString((short) (ppaDecallageSommaire + styleIndex.shortValue())) + ".2       ") + getLabel(ppa_PresentationProgrammeStrategie_PARAM_Libelle_StrategieProgramme));
        parameters.put("PARAM_LibelleRecap", getLabel(ppa_PresentationProgrammeStrategie_PARAM_LibelleRecap));
        parameters.put("PARAM_TitreObjectifs", getLabel(ppa_PresentationProgrammeStrategie_PARAM_TitreObjectifs));
        parameters.put("jrds_Detail", jrdsDetail);
        parameters.put("sousEtat_Detail", etatDetail);
        parameters.put("jrds_Objectif", jrdsObjectif);
        parameters.put("sousEtat_Objectif", etatObjectif);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lbl_Objectif", getLabel(ppa_PresentationProgrammeStrategie_lbl_Objectif));
        parameters.put("lbl_Indicateur", getLabel(ppa_PresentationProgrammeStrategie_lbl_Indicateur));
        parameters.put("lbl_Valeur", getLabel(ppa_PresentationProgrammeStrategie_lbl_Valeur));
        parameters.put("lbl_Date", getLabel(ppa_PresentationProgrammeStrategie_lbl_Date));
        parameters.put("lbl_UniteMesure", getLabel(ppa_PresentationProgrammeStrategie_lbl_UniteMesure));
        parameters.put("lbl_Cible", getLabel(ppa_PresentationProgrammeStrategie_lbl_Cible));
        parameters.put("lbl_Reference", getLabel(ppa_PresentationProgrammeStrategie_lbl_Reference));
        parameters.put("lbl_Action", getLabel(ppa_PresentationProgrammeStrategie_lbl_Action));
        parameters.put("PARAM_PrefixPiedPage", prefixPiedPage);
        return parameters;
    }

    public HashMap ppa_ProgrammeObjectif(Short styleIndex, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage,
            JRBeanCollectionDataSource jrdsDetail, InputStream etatDetail, JRBeanCollectionDataSource jrdsObjectif, InputStream etatObjectif) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_Titre_Actions", getLabel(ppa_ProgrammeObjectif_PARAM_Titre_Actions));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_ProgrammeObjectif_PARAM_LibelleProgramme));
        parameters.put("PARAM_LibellePresentationProgramme", getLabel(ppa_ProgrammeObjectif_PARAM_LibellePresentationProgramme));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_LibellePresentationAction", getLabel(ppa_ProgrammeObjectif_PARAM_LibellePresentationAction));
        parameters.put("PARAM_Libelle_StrategieProgramme", getLabel(ppa_ProgrammeObjectif_PARAM_Libelle_StrategieProgramme));
        parameters.put("PARAM_LibelleRecap", getLabel(ppa_ProgrammeObjectif_PARAM_LibelleRecap));
        parameters.put("PARAM_TitreObjectifs", getLabel(ppa_ProgrammeObjectif_PARAM_TitreObjectifs));
        parameters.put("jrds_Detail", jrdsDetail);
        parameters.put("sousEtat_Detail", etatDetail);
        parameters.put("jrds_Objectif", jrdsObjectif);
        parameters.put("sousEtat_Objectif", etatObjectif);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lbl_Objectif", getLabel(ppa_ProgrammeObjectif_lbl_Objectif));
        parameters.put("lbl_Indicateur", getLabel(ppa_ProgrammeObjectif_lbl_Indicateur));
        parameters.put("lbl_Valeur", getLabel(ppa_ProgrammeObjectif_lbl_Valeur));
        parameters.put("lbl_Date", getLabel(ppa_ProgrammeObjectif_lbl_Date));
        parameters.put("lbl_UniteMesure", getLabel(ppa_ProgrammeObjectif_lbl_UniteMesure));
        parameters.put("lbl_Cible", getLabel(ppa_ProgrammeObjectif_lbl_Cible));
        parameters.put("lbl_Reference", getLabel(ppa_ProgrammeObjectif_lbl_Reference));
        parameters.put("lbl_Action", getLabel(ppa_ProgrammeObjectif_lbl_Action));
        return parameters;
    }

    public HashMap ppa_CadreLogique(Short styleIndex, String titre, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage, String chCode, String chLibelle) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("lblTitre_CL", getLabel(ppa_CadreLogique_lblTitre_CL));
        parameters.put("lblProgramme", getLabel(ppa_CadreLogique_lblProgramme));
        parameters.put("lbl_Objectif", getLabel(ppa_CadreLogique_lbl_Objectif));
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("lblListeAction", getLabel(ppa_CadreLogique_lblListeAction));
        parameters.put("lblChapitre", getLabel(lblCHAPITRE));
        parameters.put("chCodeChapitre", chCode);
        parameters.put("chLibelle", chLibelle);
        parameters.put("PARAM_Titre", titre);
        parameters.put("lblLibelle", getLabel(ppa_CadreLogique_lblLibelle));
        parameters.put("lblIndicateurs", getLabel(ppa_CadreLogique_lblIndicateurs));
        parameters.put("lblNiveauRef", getLabel(ppa_CadreLogique_lblNiveauRef));
        parameters.put("lblNiveauCible", getLabel(ppa_CadreLogique_lblNiveauCible));
        parameters.put("lblSourceVerif", getLabel(ppa_CadreLogique_lblSourceVerif));

        return parameters;
    }

    public HashMap ppa_Projet(String noteExplicative) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_Pays", getLabel(param_Pays));
        parameters.put("PARAM_Devise", getLabel(param_Devise));
        //parameters.put("PARAM_Logo",);
        parameters.put("PARAM_NoteExplicative", getLabel(ppa_PARAM_NoteExplicative));
        parameters.put("PARAM_TexteNoteExplicative", noteExplicative);
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_PARAM_LibelleProgramme));
        parameters.put("PARAM_Sommaire", getLabel(ppa_PARAM_Sommaire));
        parameters.put("PARAM_Sommaire_1", getLabel(ppa_PARAM_MainSommaire_1));
        //parameters.put("PARAM_Page_1", getLabel(ppa_Projet_PARAM_Page_1));
        parameters.put("PARAM_Sommaire_11", getLabel(ppa_PARAM_MainSommaire_11));
        //parameters.put("PARAM_Page_11", getLabel(ppa_Projet_PARAM_Page_11));
        parameters.put("PARAM_Sommaire_12", getLabel(ppa_PARAM_MainSommaire_12));
        //parameters.put("PARAM_Page_12", getLabel(ppa_Projet_PARAM_Page_12));
        parameters.put("PARAM_Sommaire_13", getLabel(ppa_PARAM_MainSommaire_13));
        //parameters.put("PARAM_Page_13", getLabel(ppa_Projet_PARAM_Page_13));
        parameters.put("PARAM_Sommaire_131", getLabel(ppa_PARAM_MainSommaire_131));
        //parameters.put("PARAM_Page_131", getLabel(ppa_Projet_PARAM_Page_131));
        parameters.put("PARAM_Sommaire_132", getLabel(ppa_PARAM_MainSommaire_132));
        //parameters.put("PARAM_Page_132", getLabel(ppa_Projet_PARAM_Page_132));
        parameters.put("PARAM_Sommaire_14", getLabel(ppa_PARAM_MainSommaire_14));
        //parameters.put("PARAM_Page_14", getLabel(ppa_Projet_PARAM_Page_14));
        parameters.put("PARAM_Sommaire_15", getLabel(ppa_PARAM_MainSommaire_15));
        //parameters.put("PARAM_Page_15", getLabel(ppa_Projet_PARAM_Page_15));
        //parameters.put("PARAM_Sommaire_16", getLabel(ppa_PARAM_MainSommaire_16));
        //parameters.put("PARAM_Page_16", getLabel(ppa_Projet_PARAM_Page_16));
        parameters.put("PARAM_Sommaire_2", getLabel(ppa_PARAM_MainSommaire_2));
        //parameters.put("PARAM_Page_2", getLabel(ppa_Projet_PARAM_Page_2));
        parameters.put("PARAM_Sommaire_Annexe", getLabel(ppa_PARAM_MainSommaire_Annexe));
        parameters.put("PARAM_Sommaire_Annexe_1", getLabel(ppa_PARAM_MainSommaire_Annexe_1));

        parameters.put("PARAM_Armoirie", armoirie);
        parameters.put("PARAM_Drapeau", drapeau);
        parameters.put("PARAM_Etoile", etoile);
        parameters.put("PARAM_NIV_TITRE", Integer.valueOf(ppaDecallageSommaire));
        return parameters;
    }

    public HashMap ppa_Projet_PG(Short styleIndex, String sommaire) {
        HashMap parameters = new HashMap();
        if (styleIndex != null) {
            parameters.put("PARAM_StyleIndex", styleIndex);
        }
        parameters.put("PARAM_ResponsableProgramme", getLabel(ppa_Projet_PG_PARAM_ResponsableProgramme));
        parameters.put("PARAM_LibelleProgramme", getLabel(ppa_Projet_PG_PARAM_LibelleProgramme));
        parameters.put("PARAM_CoordonnateurProgramme", getLabel(ppa_Projet_PG_PARAM_CoordonnateurProgramme));
        parameters.put("PARAM_Sommaire", sommaire);//getLabel(ppa_PARAM_Sommaire));
        return parameters;
    }

    public HashMap ppa_Section(String titre, String plf, String libellePPA, String page_Prefix, String page_Suffixe, int debutPage, String chCode, String chLibelle) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_PLF", plf);
        parameters.put("PARAM_LibellePAP", libellePPA);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_Titre", titre);
        parameters.put("lblChapitre", getLabel(lblCHAPITRE));
        parameters.put("chCodeChapitre", chCode);
        parameters.put("chLibelle", chLibelle);
        return parameters;
    }

    public HashMap projetBIP(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, Image carteCameroun, Image drapeauHtGche, Image drapeauHtDte) {
        HashMap parameters = new HashMap();
        parameters.put("PARAM_Pays", getLabel(param_Pays));
        parameters.put("PARAM_Devise", getLabel(param_Devise));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lbl_Titre", getLabel(projetBIP_lbl_Titre));
        parameters.put("lbl_Projet", getLabel(projetBIP_lbl_Projet));
        parameters.put("lbl_Total", getLabel(projetBIP_lbl_Total));
        parameters.put("lbl_Chapitre", getLabel(projetBIP_lbl_Chapitre));
        parameters.put("lbl_Interne", getLabel(projetBIP_lbl_Interne));
        parameters.put("lbl_Externe", getLabel(projetBIP_lbl_Externe));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_CoutTotal", getLabel(projetBIP_PARAM_CoutTotal));
        parameters.put("PARAM_Index", getLabel(projetBIP_PARAM_Index));
        parameters.put("PARAM_CAMEROUN", carteCameroun);
        parameters.put("lbl_AE", getLabel(projetBIP_lbl_AE));
        parameters.put("lbl_CP", getLabel(projetBIP_lbl_CP));
        parameters.put("lbl_Investissement", getLabel(projetBIP_lbl_Investissement));
        parameters.put("PARAM_Drapeau", drapeau);
        parameters.put("PARAM_Armoirie", armoirie);
        parameters.put("PARAM_Etoile", etoile);
        parameters.put("PARAM_DrapeauHtGche", drapeauHtGche);
        parameters.put("PARAM_DrapeauHtDte", drapeauHtDte);
        return parameters;
    }

    public HashMap projetBIP_detail(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, Image carteCameroun) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lbl_Titre", getLabel(projetBIP_detail_lbl_Titre));
        parameters.put("lbl_Projet", getLabel(projetBIP_detail_lbl_Projet));
        parameters.put("lbl_Total", getLabel(projetBIP_detail_lbl_Total));
        parameters.put("lbl_Chapitre", getLabel(projetBIP_detail_lbl_Chapitre));
        parameters.put("lbl_Interne", getLabel(projetBIP_detail_lbl_Interne));
        parameters.put("lbl_Externe", getLabel(projetBIP_detail_lbl_Externe));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_CoutTotal", getLabel(projetBIP_detail_PARAM_CoutTotal));
        parameters.put("PARAM_Index", getLabel(projetBIP_detail_PARAM_Index));
        parameters.put("PARAM_CAMEROUN", carteCameroun);
        parameters.put("lbl_AE", getLabel(projetBIP_detail_lbl_AE));
        parameters.put("lbl_CP", getLabel(projetBIP_detail_lbl_CP));
        parameters.put("lbl_Investissement", getLabel(projetBIP_detail_lbl_Investissement));
        return parameters;
    }

    public HashMap projetMINEPAT(String uniteMontant, String page_Prefix, String page_Suffixe, int debutPage, boolean dsIsEmpty, Image carteCameroun) {
        HashMap parameters = new HashMap();
        parameters.put("chapitreFR", "");//getLabel(chapitreFR));
        parameters.put("serviceFR", "");//getLabel(serviceFR));
        parameters.put("paysFR", getLabel(paysFR));
        parameters.put("deviseFR", getLabel(deviseFR));
        parameters.put("chapitreEN", "");//getLabel(chapitreEN));
        parameters.put("serviceEN", "");//getLabel(serviceEN));
        parameters.put("paysEN", getLabel(paysEN));
        parameters.put("deviseEN", getLabel(deviseEN));
        parameters.put("uniteMontant", uniteMontant);
        //parameters.put("logo",);
        parameters.put("lbl_Operation", getLabel(projetMINEPAT_lbl_Operation));
        parameters.put("lbl_Titre", getLabel(projetMINEPAT_lbl_Titre));
        parameters.put("lbl_Projet", getLabel(projetMINEPAT_lbl_Projet));
        parameters.put("lbl_Total", getLabel(projetMINEPAT_lbl_Total));
        parameters.put("lbl_Cout", getLabel(projetMINEPAT_lbl_Cout));
        parameters.put("lbl_Region", getLabel(projetMINEPAT_lbl_Region));
        parameters.put("lbl_Departement", getLabel(projetMINEPAT_lbl_Departement));
        parameters.put("lbl_Arrondissement", getLabel(projetMINEPAT_lbl_Arrondissement));
        parameters.put("lbl_PosteComptable", getLabel(projetMINEPAT_lbl_PosteComptable));
        parameters.put("lbl_Localite", getLabel(projetMINEPAT_lbl_Localite));
        parameters.put("lbl_MG", getLabel(projetMINEPAT_lbl_MG));
        parameters.put("lbl_MMarche", getLabel(projetMINEPAT_lbl_MMarche));
        parameters.put("lbl_Gestionnaire", getLabel(projetMINEPAT_lbl_Gestionnaire));
        parameters.put("lbl_CodeBudgetaire", getLabel(projetMINEPAT_lbl_CodeBudgetaire));
        parameters.put("lbl_Chapitre", getLabel(projetMINEPAT_lbl_Chapitre));
        parameters.put("lbl_Action", getLabel(projetMINEPAT_lbl_Action));
        parameters.put("lbl_Programme", getLabel(projetMINEPAT_lbl_Programme));
        parameters.put("PARAM_Page_Prefix", page_Prefix);
        parameters.put("PARAM_Page_Suffixe", page_Suffixe);
        parameters.put("PARAM_DebutPage", debutPage);
        parameters.put("PARAM_CoutTotal", getLabel(projetMINEPAT_PARAM_CoutTotal));
        parameters.put("PARAM_Index", getLabel(projetMINEPAT_PARAM_Index));
        parameters.put("PARAM_CAMEROUN", carteCameroun);
        parameters.put("DS_Is_Empty", dsIsEmpty);
        return parameters;
    }
    //
    //public static final String chapitreFR = "chapitreFR";
    //public static final String serviceFR = "serviceFR";
    public static final String paysFR = "paysFR";
    public static final String deviseFR = "deviseFR";
    //public static final String chapitreEN = "chapitreEN";
    //public static final String serviceEN = "serviceEN";
    public static final String paysEN = "paysEN";
    public static final String deviseEN = "deviseEN";
    //
    public final static String param_Pays = "PARAM_Pays";
    public final static String param_Devise = "PARAM_Devise";
    public final static String lblVersion = "lblVersion";
    public final static String lblCHAPITRE = "lblCHAPITRE";
    public final static String lblPLFDraft = "lblPLFDraft";
    public final static String lblPLFDefinitif = "lblPLFDefinitif";
    public final static String lblPrExercice = "lblPrExercice";
    public final static String lblAnnee = "lblAnnee";
    public final static String lblAE = "lblAE";
    public final static String lblCP = "lblCP";
    public final static String lblRegion = "lblRegion";
    public final static String lblDepartement = "lblDepartement";
    //
    public final static String developpementDepensesTitre = "developpementDepensesTitre";
    public final static String depensesParFonctionEtNatureEcoTitre = "depensesParFonctionEtNatureEcoTitre";
    public final static String depensesParSecteurEtNatureEcoTitre = "depensesParSecteurEtNatureEcoTitre";
    public final static String depensesParFS_SEEtNatureEco_lblNE = "depensesParFS_SEEtNatureEco_lblNE";
    public final static String depensesParFonctionEtNatureEco_lblFS = "depensesParFonctionEtNatureEco_lblFS";
    public final static String depensesParSecteurEtNatureEco_lblSE = "depensesParSecteurEtNatureEco_lblSE";
    //
    public final static String lblCategorie = "lblCategorie";
    public final static String decentralisationTitre = "decentralisationTitre";
    //
    public final static String bd_libelleAutreChapSE = "bd_libelleAutreChapSE";
    public final static String bd_libelleAutreChapCA = "bd_libelleAutreChapCA";
    public final static String bd_libelleDC = "bd_libelleDC";
    public final static String bd_libelleDI = "bd_libelleDI";
    public final static String bd_LibelleResteDep = "bd_LibelleResteDep";
    public final static String bd_libelleTousChapitres = "bd_libelleTousChapitres";
    public final static String bd_libelleSC = "bd_libelleSC";
    public final static String bd_libelleSEXT = "bd_libelleSEXT";
    public final static String bd_libelleSETR = "bd_libelleSETR";
    //
    public final static String budgetEtatTitre = "budgetEtatTitre";
    public final static String budgetEtatHistoGrapheTitre = "budgetEtatHistoGrapheTitre";
    public final static String budgetEtatCamGrapheTitre = "budgetEtatCamGrapheTitre";
    public final static String budgetEtatCamDIGrapheTitre = "budgetEtatCamDIGrapheTitre";
    public final static String budgetEtatCamDCGrapheTitre = "budgetEtatCamDCGrapheTitre";
    public final static String budgetEtatCamembert_lblTotal = "budgetEtatCamembert_lblTotal";
    public final static String budgetEtatCamembert_lblSecteur = "budgetEtatCamembert_lblSecteur";
    public final static String budgetEtatCamembert_lblGrapheTitre = "budgetEtatCamembert_lblGrapheTitre";
    public final static String budgetEtatCategorieChapitreEtRegionTitre = "budgetEtatCategorieChapitreEtRegionTitre";
    public final static String budgetEtatCategorieRegionEtChapitreTitre = "budgetEtatCategorieRegionEtChapitreTitre";
    //
    public final static String budgetSecteurGraphe1 = "budgetSecteurGraphe1";
    public final static String budgetSecteurGraphe2 = "budgetSecteurGraphe2";
    public final static String budgetSecteurGraphe3 = "budgetSecteurGraphe3";
    public final static String budgetSecteurGraphe4 = "budgetSecteurGraphe4";
    //
    public final static String budgetEtatCategorieGraphe_lblPartie11Titre = "budgetEtatCategorieGraphe_lblPartie11Titre";
    //
    public final static String budgetEtatChapitre_lblChapitre = "budgetEtatChapitre_lblChapitre";
    public final static String budgetEtatChapitre_lblSection = "budgetEtatChapitre_lblSection";
    public final static String budgetEtatChapitre_lblArticle = "budgetEtatChapitre_lblArticle";
    public final static String budgetEtatChapitre_lblParagraphe = "budgetEtatChapitre_lblParagraphe";
    public final static String budgetEtatChapitre_lblDotation = "budgetEtatChapitre_lblDotation";
    public final static String budgetEtatChapitre_lblProjet = "budgetEtatChapitre_lblProjet";
    public final static String budgetEtatChapitre_lblDefinitif = "budgetEtatChapitre_lblDefinitif";
    public final static String budgetEtatChapitre_PARAM_BudgetEtat = "budgetEtatChapitre_PARAM_BudgetEtat";
    public final static String budgetEtatChapitre_PARAM_LibelleDC = "budgetEtatChapitre_PARAM_LibelleDC";
    public final static String budgetEtatChapitre_PARAM_LibelleDI = "budgetEtatChapitre_PARAM_LibelleDI";
    public final static String budgetEtatChapitre_lblTotal = "budgetEtatChapitre_lblTotal";
    public final static String budgetEtatChapitre_lblPartieTitre = "budgetEtatChapitre_lblPartieTitre";
    public final static String budgetEtatChapitre_lblPartie = "budgetEtatChapitre_lblPartie";
    public final static String budgetEtatChapitre_PARAM_Titre = "budgetEtatChapitre_PARAM_Titre";
    public final static String budgetEtatChapitre_lblBudget = "budgetEtatChapitre_lblBudget";
    public final static String budgetEtatChapitre_lblTitre = "budgetEtatChapitre_lblTitre";
    public final static String budgetEtatChapitre_lblAnnee = "budgetEtatChapitre_lblAnnee";
//
    public final static String budgetEtatChapitreGraphe1_lblPartie = "budgetEtatChapitreGraphe1_lblPartie";
    public final static String budgetEtatChapitreGraphe1_lblPartieTitre = "budgetEtatChapitreGraphe1_lblPartieTitre";
    public final static String budgetEtatChapitreGraphe1_lblPartie11 = "budgetEtatChapitreGraphe1_lblPartie11";
    public final static String budgetEtatChapitreGraphe1_lblPartie11Titre = "budgetEtatChapitreGraphe1_lblPartie11Titre";
    public final static String budgetEtatChapitreGraphe1_lblPartie12 = "budgetEtatChapitreGraphe1_lblPartie12";
    public final static String budgetEtatChapitreGraphe1_lblPartie12Titre = "budgetEtatChapitreGraphe1_lblPartie12Titre";
//
    public final static String budgetEtatChapitreGraphe2_lblPartie13 = "budgetEtatChapitreGraphe2_lblPartie13";
    public final static String budgetEtatChapitreGraphe2_lblPartie13Titre = "budgetEtatChapitreGraphe2_lblPartie13Titre";
    public final static String budgetEtatChapitreGraphe2_lblPartie14 = "budgetEtatChapitreGraphe2_lblPartie14";
    public final static String budgetEtatChapitreGraphe2_lblPartie14Titre = "budgetEtatChapitreGraphe2_lblPartie14Titre";
//
    public final static String budgetEtatChapitreIntercallaire_lblChapitre = "budgetEtatChapitreIntercallaire_lblChapitre";
//
    public final static String budgetEtatChapitreRecap_lblDotation = "budgetEtatChapitreRecap_lblDotation";
    public final static String budgetEtatChapitreRecap_lblPrevision = "budgetEtatChapitreRecap_lblPrevision";
    public final static String budgetEtatChapitreRecap_lblEnteteRecapitulatif = "budgetEtatChapitreRecap_lblEnteteRecapitulatif";
    public final static String budgetEtatChapitreRecap_lblCode = "budgetEtatChapitreRecap_lblCode";
    public final static String budgetEtatChapitreRecap_lblLibelle = "budgetEtatChapitreRecap_lblLibelle";
    public final static String budgetEtatChapitreRecap_lblTotal = "budgetEtatChapitreRecap_lblTotal";
    public final static String budgetEtatChapitreRecap_lblPartie = "budgetEtatChapitreRecap_lblPartie";
    public final static String budgetEtatChapitreRecap_lblPartieTitre = "budgetEtatChapitreRecap_lblPartieTitre";
//
    public final static String budgetEtatChapitreSommaire_lblSommaire = "budgetEtatChapitreSommaire_lblSommaire";
    public final static String budgetEtatChapitreSommaire_lblPartie1 = "budgetEtatChapitreSommaire_lblPartie1";
    public final static String budgetEtatChapitreSommaire_lblPartie1Titre = "budgetEtatChapitreSommaire_lblPartie1Titre";
    public final static String budgetEtatChapitreSommaire_lblPartie11 = "budgetEtatChapitreSommaire_lblPartie11";
    public final static String budgetEtatChapitreSommaire_lblPartie11Titre = "budgetEtatChapitreSommaire_lblPartie11Titre";
    public final static String budgetEtatChapitreSommaire_lblPartie12 = "budgetEtatChapitreSommaire_lblPartie12";
    public final static String budgetEtatChapitreSommaire_lblPartie12Titre = "budgetEtatChapitreSommaire_lblPartie12Titre";
    public final static String budgetEtatChapitreSommaire_lblPartie13 = "budgetEtatChapitreSommaire_lblPartie13";
    public final static String budgetEtatChapitreSommaire_lblPartie13Titre = "budgetEtatChapitreSommaire_lblPartie13Titre";
    public final static String budgetEtatChapitreSommaire_lblPartie14 = "budgetEtatChapitreSommaire_lblPartie14";
    public final static String budgetEtatChapitreSommaire_lblPartie14Titre = "budgetEtatChapitreSommaire_lblPartie14Titre";
    public final static String budgetEtatChapitreSommaire_lblPartie2 = "budgetEtatChapitreSommaire_lblPartie2";
    public final static String budgetEtatChapitreSommaire_lblPartie2Titre = "budgetEtatChapitreSommaire_lblPartie2Titre";
    public final static String budgetEtatChapitreSommaire_lblPartie3 = "budgetEtatChapitreSommaire_lblPartie3";
    public final static String budgetEtatChapitreSommaire_lblPartie3Titre = "budgetEtatChapitreSommaire_lblPartie3Titre";
//
    public final static String budgetEtatHistogramme_lblTotal = "budgetEtatHistogramme_lblTotal";
    public final static String budgetEtatHistogramme_lblSecteur = "budgetEtatHistogramme_lblSecteur";
    //public final static String budgetEtatHistogramme_lblGrapheTitre = "budgetEtatHistogramme_lblGrapheTitre";
//
    public final static String budgetEtatInterCallaire_lblChapitre = "budgetEtatInterCallaire_lblChapitre";
    public final static String budgetEtatInterCallaire_lblSection = "budgetEtatInterCallaire_lblSection";
    public final static String budgetEtatInterCallaire_lblArticle = "budgetEtatInterCallaire_lblArticle";
    public final static String budgetEtatInterCallaire_lblParagraphe = "budgetEtatInterCallaire_lblParagraphe";
    public final static String budgetEtatInterCallaire_lblDotation = "budgetEtatInterCallaire_lblDotation";
    //public final static String budgetEtatInterCallaire_lblProjet = "budgetEtatInterCallaire_lblProjet";
    public final static String budgetEtatInterCallaire_lblTitre = "budgetEtatInterCallaire_lblTitre";
    public final static String budgetEtatInterCallaire_lblAnnee = "budgetEtatInterCallaire_lblAnnee";
//
    public final static String budgetEtatSecteurCouverture_lblChapitre = "budgetEtatSecteurCouverture_lblChapitre";
//
    public final static String budgetEtatSecteurGraphe1_lblTotal = "budgetEtatSecteurGraphe1_lblTotal";
    //public final static String budgetEtatSecteurGraphe1_lblProjet = "budgetEtatSecteurGraphe1_lblProjet";
    public final static String budgetEtatSecteurGraphe1_lblTitre = "budgetEtatSecteurGraphe1_lblTitre";
    public final static String budgetEtatSecteurGraphe1_lblAnnee = "budgetEtatSecteurGraphe1_lblAnnee";
    public final static String budgetEtatSecteurGraphe1_lblSecteur = "budgetEtatSecteurGraphe1_lblSecteur";
    //public final static String budgetEtatSecteurGraphe1_lblGrapheTitre = "budgetEtatSecteurGraphe1_lblGrapheTitre";
//
    public final static String budgetEtatSecteurGraphe2_lblTotal = "budgetEtatSecteurGraphe2_lblTotal";
    //public final static String budgetEtatSecteurGraphe2_lblProjet = "budgetEtatSecteurGraphe2_lblProjet";
    public final static String budgetEtatSecteurGraphe2_lblTitre = "budgetEtatSecteurGraphe2_lblTitre";
    public final static String budgetEtatSecteurGraphe2_lblAnnee = "budgetEtatSecteurGraphe2_lblAnnee";
    public final static String budgetEtatSecteurGraphe2_lblSecteur = "budgetEtatSecteurGraphe2_lblSecteur";
    //public final static String budgetEtatSecteurGraphe2_lblGrapheTitre = "budgetEtatSecteurGraphe2_lblGrapheTitre";
    public final static String budgetEtatSecteurGraphe2_lblBudget = "budgetEtatSecteurGraphe2_lblBudget";
    public final static String budgetEtatSecteurGraphe2_PARAM_Titre = "budgetEtatSecteurGraphe2_PARAM_Titre";
//
    public final static String budgetParMinistereEtRegionTitre = "budgetParMinistereEtRegionTitre";
    public final static String budgetParMinistereEtRegionFINEX = "budgetParMinistereEtRegionFINEX";
    public final static String budgetParMinistereEtRegionHFINEX = "budgetParMinistereEtRegionHFINEX";
    public final static String budgetParMinistereEtRegion_lbLibelle = "budgetParMinistereEtRegion_lbLibelle";
    public final static String budgetParMinistereEtRegion_lblBF = "budgetParMinistereEtRegion_lblBF";
    public final static String budgetParMinistereEtRegion_lblBIP = "budgetParMinistereEtRegion_lblBIP";
    public final static String budgetParMinistereEtRegion_lblSC = "budgetParMinistereEtRegion_lblSC";
    public final static String budgetParMinistereEtRegion_lblSE = "budgetParMinistereEtRegion_lblSE";
    public final static String budgetParMinistereEtRegion_lblSCE = "budgetParMinistereEtRegion_lblSCE";
    public final static String budgetParMinistereEtRegion_lblPresentationPar = "budgetParMinistereEtRegion_lblPresentationPar";
    public final static String budgetParMinistereEtRegion_lblTaux = "budgetParMinistereEtRegion_lblTaux";
//
    public final static String chargeBudgetaire_PARAM_PREPA_BUD = "chargeBudgetaire_PARAM_PREPA_BUD";
    public final static String chargeBudgetaire_PARAM_Titre = "chargeBudgetaire_PARAM_Titre";
    public final static String chargeBudgetaire_PARAM_LibelleMinistre = "chargeBudgetaire_PARAM_LibelleMinistre";
    public final static String chargeBudgetaire_PARAM_LocalisationPC = "chargeBudgetaire_PARAM_LocalisationPC";
    public final static String chargeBudgetaire_PARAM_Imputation = "chargeBudgetaire_PARAM_Imputation";
    public final static String chargeBudgetaire_PARAM_Libelle = "chargeBudgetaire_PARAM_Libelle";
    public final static String chargeBudgetaire_PARAM_LibelleCB = "chargeBudgetaire_PARAM_LibelleCB";
    public final static String chargeBudgetaire_PARAM_EVALUATION_BES_CRED = "chargeBudgetaire_PARAM_EVALUATION_BES_CRED";
    public final static String chargeBudgetaire_PARAM_DOTBASE = "chargeBudgetaire_PARAM_DOTBASE";
    public final static String chargeBudgetaire_PARAM_AJUST = "chargeBudgetaire_PARAM_AJUST";
    public final static String chargeBudgetaire_PARAM_TOTAL_CP = "chargeBudgetaire_PARAM_TOTAL_CP";
    public final static String chargeBudgetaire_PARAM_Chapitre = "chargeBudgetaire_PARAM_Chapitre";
    public final static String chargeBudgetaire_PARAM_MAJ_PROJBUD = "chargeBudgetaire_PARAM_MAJ_PROJBUD";
    public final static String chargeBudgetaire_PARAM_PRESENTATION_FCT = "chargeBudgetaire_PARAM_PRESENTATION_FCT";
//
    public final static String chargeBudgetairePGAC_PARAM_Titre = "chargeBudgetairePGAC_PARAM_Titre";
    public final static String chargeBudgetairePGAC_lblLocalisationPC = "chargeBudgetairePGAC_lblLocalisationPC";
    public final static String chargeBudgetairePGAC_lblImputation = "chargeBudgetairePGAC_lblImputation";
    public final static String chargeBudgetairePGAC_lblLibelle = "chargeBudgetairePGAC_lblLibelle";
    public final static String chargeBudgetairePGAC_lblEVALUATION_BES_CRED = "chargeBudgetairePGAC_lblEVALUATION_BES_CRED";
    public final static String chargeBudgetairePGAC_lblChapitre = "chargeBudgetairePGAC_lblChapitre";
    public final static String chargeBudgetairePGAC_lblPRESENTATION = "chargeBudgetairePGAC_lblPRESENTATION";
    public final static String chargeBudgetairePGAC_lblPartie = "chargeBudgetairePGAC_lblPartie";
    public final static String chargeBudgetairePGAC_lblTotalGl = "chargeBudgetairePGAC_lblTotalGl";
    public final static String chargeBudgetairePGAC_lblParagraphe = "chargeBudgetairePGAC_lblParagraphe";
    public final static String chargeBudgetairePGAC_lblArticle = "chargeBudgetairePGAC_lblArticle";
    public final static String chargeBudgetairePGAC_lblSecteur = "chargeBudgetairePGAC_lblSecteur";
    public final static String chargeBudgetairePGAC_lblFonction = "chargeBudgetairePGAC_lblFonction";
    public final static String chargeBudgetairePGAC_lblProgramme = "chargeBudgetairePGAC_lblProgramme";
    public final static String chargeBudgetairePGAC_lblAction = "chargeBudgetairePGAC_lblAction";
//
    public final static String DepenseFpPgAcObIn_lblFPProgramme = "DepenseFpPgAcObIn_lblFPProgramme";
    public final static String DepenseFpPgAcObIn_PARAM_Titre = "DepenseFpPgAcObIn_PARAM_Titre";
    public final static String DepenseFpPgAcObIn_lblObjectif = "DepenseFpPgAcObIn_lblObjectif";
    public final static String DepenseFpPgAcObIn_lblIndicateur = "DepenseFpPgAcObIn_lblIndicateur";
    public final static String DepenseFpPgAcObIn_lblFP = "DepenseFpPgAcObIn_lblFP";
    public final static String DepenseFpPgAcObIn_lblProgramme = "DepenseFpPgAcObIn_lblProgramme";
    public final static String DepenseFpPgAcObIn_lblTotal = "DepenseFpPgAcObIn_lblTotal";
//
    public final static String DepenseFpPgAcObInPaysage_lblFPProgramme = "DepenseFpPgAcObInPaysage_lblFPProgramme";
    public final static String DepenseFpPgAcObInPaysage_lblChapitre = "DepenseFpPgAcObInPaysage_lblChapitre";
    public final static String DepenseFpPgAcObInPaysage_PARAM_Titre = "DepenseFpPgAcObInPaysage_PARAM_Titre";
    public final static String DepenseFpPgAcObInPaysage_PARAM_Titre_Comite = "DepenseFpPgAcObInPaysage_PARAM_Titre_Comite";
    public final static String DepenseFpPgAcObInPaysage_lblObjectif = "DepenseFpPgAcObInPaysage_lblObjectif";
    public final static String DepenseFpPgAcObInPaysage_lblIndicateur = "DepenseFpPgAcObInPaysage_lblIndicateur";
    public final static String DepenseFpPgAcObInPaysage_lblProgramme = "DepenseFpPgAcObInPaysage_lblProgramme";
    public final static String DepenseFpPgAcObInPaysage_lblFP = "DepenseFpPgAcObInPaysage_lblFP";
    public final static String DepenseFpPgAcObInPaysage_lblAction = "DepenseFpPgAcObInPaysage_lblAction";
    public final static String DepenseFpPgAcObInPaysage_lblTotal = "DepenseFpPgAcObInPaysage_lblTotal";
//
    public final static String DepensePgAcObIn_PARAM_Titre_Comite = "DepensePgAcObIn_PARAM_Titre_Comite";
    //public final static String DepensesParFctPgAr_lblProjet = "DepensesParFctPgAr_lblProjet";
    public final static String DepensesParFctPgAr_lblTitre = "DepensesParFctPgAr_lblTitre";
    public final static String DepensesParFctPgAr_lblAnnee = "DepensesParFctPgAr_lblAnnee";
    public final static String DepensesParFctPgAr_lblChapitre = "DepensesParFctPgAr_lblChapitre";
    public final static String DepensesParFctPgAr_PARAM_Titre = "DepensesParFctPgAr_PARAM_Titre";
    public final static String DepensesParFctPgAr_PARAM_BudgetEtat = "DepensesParFctPgAr_PARAM_BudgetEtat";
    public final static String DepensesParFctPgAr_lblProgramme = "DepensesParFctPgAr_lblProgramme";
    public final static String DepensesParFctPgAr_lblArticle = "DepensesParFctPgAr_lblArticle";
    public final static String DepensesParFctPgAr_lblFP = "DepensesParFctPgAr_lblFP";
    public final static String DepensesParFctPgAr_lblCumul = "DepensesParFctPgAr_lblCumul";
    public final static String DepensesParFctPgAr_lblDI = "DepensesParFctPgAr_lblDI";
    public final static String DepensesParFctPgAr_lblDC = "DepensesParFctPgAr_lblDC";
    public final static String DepensesParFctPgAr_lblTotal = "DepensesParFctPgAr_lblTotal";
//
    public final static String EvolutionMasseSalariale_lblChapitre = "EvolutionMasseSalariale_lblChapitre";
    public final static String EvolutionMasseSalariale_PARAM_Titre = "EvolutionMasseSalariale_PARAM_Titre";
    public final static String EvolutionMasseSalariale_PARAM_Fonctionnaires = "EvolutionMasseSalariale_PARAM_Fonctionnaires";
    public final static String EvolutionMasseSalariale_PARAM_PersonnelCodeTravail = "EvolutionMasseSalariale_PARAM_PersonnelCodeTravail";
    public final static String EvolutionMasseSalariale_lblCategories = "EvolutionMasseSalariale_lblCategories";
    public final static String EvolutionMasseSalariale_lblEffectifs = "EvolutionMasseSalariale_lblEffectifs";
    public final static String EvolutionMasseSalariale_lblMS = "EvolutionMasseSalariale_lblMS";
    public final static String EvolutionMasseSalariale_lblEvolution = "EvolutionMasseSalariale_lblEvolution";
    public final static String EvolutionMasseSalariale_lblSousTotal = "EvolutionMasseSalariale_lblSousTotal";
    public final static String EvolutionMasseSalariale_lblPersSoldeGlobale = "EvolutionMasseSalariale_lblPersSoldeGlobale";
    public final static String EvolutionMasseSalariale_lblTotalGl = "EvolutionMasseSalariale_lblTotalGl";
    public final static String EvolutionMasseSalariale_lblDescMS = "EvolutionMasseSalariale_lblDescMS";
    public final static String EvolutionMasseSalariale_lblTypeFiche = "EvolutionMasseSalariale_lblTypeFiche";
//
    public final static String ficheDeCollecte_PARAM_Titre = "ficheDeCollecte_PARAM_Titre";
    public final static String ficheDeCollecte_lblChapitre = "ficheDeCollecte_lblChapitre";
    public final static String ficheDeCollecte_lblProgramme = "ficheDeCollecte_lblProgramme";
    public final static String ficheDeCollecte_lblintituleAction = "ficheDeCollecte_lblintituleAction";
    public final static String ficheDeCollecte_lblIntituleActivite = "ficheDeCollecte_lblIntituleActivite";
    public final static String ficheDeCollecte_lblIntituleTache = "ficheDeCollecte_lblIntituleTache";
    public final static String ficheDeCollecte_lblSection = "ficheDeCollecte_lblSection";
    public final static String ficheDeCollecte_lbluniteAdministrative = "ficheDeCollecte_lbluniteAdministrative";
    public final static String ficheDeCollecte_lblCode = "ficheDeCollecte_lblCode";
    public final static String ficheDeCollecte_lblListeNE = "ficheDeCollecte_lblListeNE";
    public final static String ficheDeCollecte_lblLibelle = "ficheDeCollecte_lblLibelle";
    public final static String ficheDeCollecte_lblCout = "ficheDeCollecte_lblCout";
    public final static String ficheDeCollecte_lblCoutTache = "ficheDeCollecte_lblCoutTache";
    public final static String ficheDeCollecte_lblCoutActivite = "ficheDeCollecte_lblCoutActivite";
    public final static String ficheDeCollecte_lblCoutAction = "ficheDeCollecte_lblCoutAction";
    public final static String ficheDeCollecte_lblCoutProgramme = "ficheDeCollecte_lblCoutProgramme";
    public final static String ficheDeCollecte_lblCoutChapitre = "ficheDeCollecte_lblCoutChapitre";
//
    public final static String fonctionParChapitre_PARAM_Titre = "fonctionParChapitre_PARAM_Titre";
    public final static String fonctionParChapitre_lblFP = "fonctionParChapitre_lblFP";
//
    public final static String jpi_PARAM_Description = "jpi_PARAM_Description";
    public final static String jpi_PARAM_Titre = "jpi_PARAM_Titre";
    public final static String jpi_PARAM_LibelleMinistre = "jpi_PARAM_LibelleMinistre";
    public final static String jpi_PARAM_LibelleSection = "jpi_PARAM_LibelleSection";
    public final static String jpi_PARAM_LibelleUnite = "jpi_PARAM_LibelleUnite";
    public final static String jpi_PARAM_PROGRAMME = "jpi_PARAM_PROGRAMME";
    public final static String jpi_PARAM_CHAPITRE = "jpi_PARAM_CHAPITRE";
    public final static String jpi_PARAM_TOTAL = "jpi_PARAM_TOTAL";
    public final static String jpi_PARAM_Projet = "jpi_PARAM_Projet";
    public final static String jpi_PARAM_LibelleRecap = "jpi_PARAM_LibelleRecap";
//
    public final static String jpi_PTA_lbl_Operation = "jpi_PTA_lbl_Operation";
    public final static String jpi_PTA_lbl_Titre = "jpi_PTA_lbl_Titre";
    public final static String jpi_PTA_lbl_Projet = "jpi_PTA_lbl_Projet";
    public final static String jpi_PTA_lbl_Total = "jpi_PTA_lbl_Total";
    public final static String jpi_PTA_lbl_Cout = "jpi_PTA_lbl_Cout";
    public final static String jpi_PTA_lbl_Region = "jpi_PTA_lbl_Region";
    public final static String jpi_PTA_lbl_Departement = "jpi_PTA_lbl_Departement";
    public final static String jpi_PTA_lbl_Arrondissement = "jpi_PTA_lbl_Arrondissement";
    public final static String jpi_PTA_lbl_PosteComptable = "jpi_PTA_lbl_PosteComptable";
    public final static String jpi_PTA_lbl_Localite = "jpi_PTA_lbl_Localite";
    public final static String jpi_PTA_lbl_MG = "jpi_PTA_lbl_MG";
    public final static String jpi_PTA_lbl_MMarche = "jpi_PTA_lbl_MMarche";
    public final static String jpi_PTA_lbl_Gestionnaire = "jpi_PTA_lbl_Gestionnaire";
    public final static String jpi_PTA_lbl_CodeBudgetaire = "jpi_PTA_lbl_CodeBudgetaire";
    public final static String jpi_PTA_lbl_Chapitre = "jpi_PTA_lbl_Chapitre";
    public final static String jpi_PTA_lbl_Action = "jpi_PTA_lbl_Action";
    public final static String jpi_PTA_lbl_Programme = "jpi_PTA_lbl_Programme";
    public final static String jpi_PTA_PARAM_CoutTotal = "jpi_PTA_PARAM_CoutTotal";
    public final static String jpi_PTA_PARAM_Index = "jpi_PTA_PARAM_Index";
//
    public final static String jpi_recap_PARAM_Description = "jpi_recap_PARAM_Description";
    public final static String jpi_recap_PARAM_Titre = "jpi_recap_PARAM_Titre";
    public final static String jpi_recap_PARAM_LibelleMinistre = "jpi_recap_PARAM_LibelleMinistre";
    public final static String jpi_recap_PARAM_LibelleSection = "jpi_recap_PARAM_LibelleSection";
    public final static String jpi_recap_PARAM_LibelleUnite = "jpi_recap_PARAM_LibelleUnite";
    public final static String jpi_recap_PARAM_PROGRAMME = "jpi_recap_PARAM_PROGRAMME";
    public final static String jpi_recap_PARAM_CHAPITRE = "jpi_recap_PARAM_CHAPITRE";
    public final static String jpi_recap_PARAM_TOTAL = "jpi_recap_PARAM_TOTAL";
    public final static String jpi_recap_PARAM_Recap = "jpi_recap_PARAM_Recap";
    public final static String jpi_recap_PARAM_Projet = "jpi_recap_PARAM_Projet";
    public final static String jpi_recap_PARAM_LibelleRecap = "jpi_recap_PARAM_LibelleRecap";
//
    public final static String listeProgramme_lblFPProgramme = "listeProgramme_lblFPProgramme";
    public final static String listeProgramme_PARAM_Titre = "listeProgramme_PARAM_Titre";
    public final static String listeProgramme_lblObjectif = "listeProgramme_lblObjectif";
    public final static String listeProgramme_lblIndicateur = "listeProgramme_lblIndicateur";
    public final static String listeProgramme_lblProgramme = "listeProgramme_lblProgramme";
    public final static String listeProgramme_lblFP = "listeProgramme_lblFP";
    public final static String listeProgramme_lblAction = "listeProgramme_lblAction";
//
    public final static String ppa_PARAM_Titre = "ppa_PARAM_Titre";
    public final static String ppa_PARAM_LibelleMinistre = "ppa_PARAM_LibelleMinistre";
    public final static String ppa_PARAM_NoteExplicative = "ppa_PARAM_NoteExplicative";
    public final static String ppa_PARAM_ResponsableProgramme = "ppa_PARAM_ResponsableProgramme";
    public final static String ppa_PARAM_LibelleProgramme = "ppa_PARAM_LibelleProgramme";
    public final static String ppa_PARAM_Sommaire = "ppa_PARAM_Sommaire";
    public final static String ppa_PARAM_Sommaire_1 = "ppa_PARAM_Sommaire_1";
    public final static String ppa_PARAM_Sommaire_2 = "ppa_PARAM_Sommaire_2";
    public final static String ppa_PARAM_Sommaire_3 = "ppa_PARAM_Sommaire_3";
    public final static String ppa_PARAM_Sommaire_4 = "ppa_PARAM_Sommaire_4";
    public final static String ppa_PARAM_Sommaire_5 = "ppa_PARAM_Sommaire_5";
    public final static String ppa_PARAM_Sommaire_6 = "ppa_PARAM_Sommaire_6";
    public final static String ppa_PARAM_CoordonnateurProgramme = "ppa_PARAM_CoordonnateurProgramme";
//
    public final static String ppa_lblANNEXE = "ppa_lblANNEXE";
    public final static String ppa_lblTABLEAUBUDGETISATION = "ppa_lblTABLEAUBUDGETISATION";
    public final static String ppa_PLF_Abrev = "ppa_PLF_Abrev";
    public final static String ppa_PREMIERE_PARTIE = "ppa_PREMIERE_PARTIE";
    public final static String ppa_SYNTHESE_STRATEGIQUE = "ppa_SYNTHESE_STRATEGIQUE";
    public final static String ppa_PRESENTATION_PRIORITES_NATIONALES = "ppa_PRESENTATION_PRIORITES_NATIONALES";
    public final static String ppa_PRESENTATION_DOMAINE = "ppa_PRESENTATION_DOMAINE";
    public final static String ppa_PERFORMANCES_ANTERIEURES = "ppa_PERFORMANCES_ANTERIEURES";
    public final static String ppa_BILAN_TECHNIQUE = "ppa_BILAN_TECHNIQUE";
    public final static String ppa_BILAN_FINANCIER = "ppa_BILAN_FINANCIER";
    public final static String ppa_PERSPECTIVES = "ppa_PERSPECTIVES";
    public final static String ppa_PRESENTATION_OBJECTIF_STRATEGIQUE = "ppa_PRESENTATION_OBJECTIF_STRATEGIQUE";
    public final static String ppa_DESCRIPTION = "ppa_DESCRIPTION";
    public final static String ppa_STRATEGIE_INTERVENTION = "ppa_STRATEGIE_INTERVENTION";
    public final static String ppa_CADRE_INSTITUTIONNEL = "ppa_CADRE_INSTITUTIONNEL";
    public final static String ppa_Presentation_Cadre_Strategique = "ppa_Presentation_Cadre_Strategique";
    public final static String ppa_DEUXIEME_PARTIE = "ppa_DEUXIEME_PARTIE";
    public final static String ppa_CONTENU_PROGRAMMES = "ppa_CONTENU_PROGRAMMES";
//
    public final static String ppa_CadreLogique_lblTitre_CL = "ppa_CadreLogique_lblTitre_CL";
    public final static String ppa_CadreLogique_lblProgramme = "ppa_CadreLogique_lblProgramme";
    public final static String ppa_CadreLogique_lbl_Objectif = "ppa_CadreLogique_lbl_Objectif";
    public final static String ppa_CadreLogique_lblListeAction = "ppa_CadreLogique_lblListeAction";
    public final static String ppa_CadreLogique_lblLibelle = "ppa_CadreLogique_lblLibelle";
    public final static String ppa_CadreLogique_lblIndicateurs = "ppa_CadreLogique_lblIndicateurs";
    public final static String ppa_CadreLogique_lblNiveauRef = "ppa_CadreLogique_lblNiveauRef";
    public final static String ppa_CadreLogique_lblNiveauCible = "ppa_CadreLogique_lblNiveauCible";
    public final static String ppa_CadreLogique_lblSourceVerif = "ppa_CadreLogique_lblSourceVerif";
//
    public final static String ppa_PresentationActions_PARAM_Titre_Actions = "ppa_PresentationActions_PARAM_Titre_Actions";
    public final static String ppa_PresentationActions_PARAM_LibelleProgramme = "ppa_PresentationActions_PARAM_LibelleProgramme";
    public final static String ppa_PresentationActions_PARAM_LibellePresentationProgramme = "ppa_PresentationActions_PARAM_LibellePresentationProgramme";
    public final static String ppa_PresentationActions_PARAM_LibellePresentationAction = "ppa_PresentationActions_PARAM_LibellePresentationAction";
    public final static String ppa_PresentationActions_PARAM_Libelle_StrategieProgramme = "ppa_PresentationActions_PARAM_Libelle_StrategieProgramme";
    public final static String ppa_PresentationActions_PARAM_LibelleRecap = "ppa_PresentationActions_PARAM_LibelleRecap";
    public final static String ppa_PresentationActions_PARAM_TitreObjectifs = "ppa_PresentationActions_PARAM_TitreObjectifs";
    public final static String ppa_PresentationActions_lbl_Objectif = "ppa_PresentationActions_lbl_Objectif";
    public final static String ppa_PresentationActions_lbl_Indicateur = "ppa_PresentationActions_lbl_Indicateur";
    public final static String ppa_PresentationActions_lbl_Valeur = "ppa_PresentationActions_lbl_Valeur";
    public final static String ppa_PresentationActions_lbl_Date = "ppa_PresentationActions_lbl_Date";
    public final static String ppa_PresentationActions_lbl_UniteMesure = "ppa_PresentationActions_lbl_UniteMesure";
    public final static String ppa_PresentationActions_lbl_Cible = "ppa_PresentationActions_lbl_Cible";
    public final static String ppa_PresentationActions_lbl_Reference = "ppa_PresentationActions_lbl_Reference";
    public final static String ppa_PresentationActions_lbl_Action = "ppa_PresentationActions_lbl_Action";
//
    public final static String ppa_PresentationCredit_PARAM_Titre_Credit = "ppa_PresentationCredit_PARAM_Titre_Credit";
    public final static String ppa_PresentationCredit_PARAM_LibelleProgramme = "ppa_PresentationCredit_PARAM_LibelleProgramme";
    public final static String ppa_PresentationCredit_PARAM_CL_Action = "ppa_PresentationCredit_PARAM_CL_Action";
    public final static String ppa_PresentationCredit_PARAM_CL_DepenseCourante = "ppa_PresentationCredit_PARAM_CL_DepenseCourante";
    public final static String ppa_PresentationCredit_PARAM_CL_DepenseInvestissement = "ppa_PresentationCredit_PARAM_CL_DepenseInvestissement";
    public final static String ppa_PresentationCredit_PARAM_CL_DepenseOpFin = "ppa_PresentationCredit_PARAM_CL_DepenseOpFin";
    public final static String ppa_PresentationCredit_PARAM_CL_Total = "ppa_PresentationCredit_PARAM_CL_Total";
    public final static String ppa_PresentationCredit_PARAM_CL_AE = "ppa_PresentationCredit_PARAM_CL_AE";
    public final static String ppa_PresentationCredit_PARAM_CL_CP = "ppa_PresentationCredit_PARAM_CL_CP";
//
    public final static String ppa_PresentationCreditRecap_PARAM_Titre_Credit = "ppa_PresentationCreditRecap_PARAM_Titre_Credit";
    public final static String ppa_PresentationCreditRecap_PARAM_LibelleProgramme = "ppa_PresentationCreditRecap_PARAM_LibelleProgramme";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_Programme = "ppa_PresentationCreditRecap_PARAM_CL_Programme";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_DepenseCourante = "ppa_PresentationCreditRecap_PARAM_CL_DepenseCourante";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_DepenseInvestissement = "ppa_PresentationCreditRecap_PARAM_CL_DepenseInvestissement";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_DepenseOpFin = "ppa_PresentationCreditRecap_PARAM_CL_DepenseOpFin";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_Total = "ppa_PresentationCreditRecap_PARAM_CL_Total";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_CP = "ppa_PresentationCreditRecap_PARAM_CL_CP";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_AE = "ppa_PresentationCreditRecap_PARAM_CL_AE";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_CP_FULL = "ppa_PresentationCreditRecap_PARAM_CL_CP_FULL";
    public final static String ppa_PresentationCreditRecap_PARAM_CL_AE_FULL = "ppa_PresentationCreditRecap_PARAM_CL_AE_FULL";
//
    public final static String ppa_PresentationProgramme_PARAM_Titre_Actions = "ppa_PresentationProgramme_PARAM_Titre_Actions";
    public final static String ppa_PresentationProgramme_PARAM_LibelleProgramme = "ppa_PresentationProgramme_PARAM_LibelleProgramme";
    public final static String ppa_PresentationProgramme_PARAM_LibellePresentationProgramme = "ppa_PresentationProgramme_PARAM_LibellePresentationProgramme";
    public final static String ppa_PresentationProgramme_PARAM_LibellePresentationAction = "ppa_PresentationProgramme_PARAM_LibellePresentationAction";
    public final static String ppa_PresentationProgramme_PARAM_Libelle_StrategieProgramme = "ppa_PresentationProgramme_PARAM_Libelle_StrategieProgramme";
    public final static String ppa_PresentationProgramme_PARAM_LibelleRecap = "ppa_PresentationProgramme_PARAM_LibelleRecap";
    public final static String ppa_PresentationProgramme_PARAM_TitreObjectifs = "ppa_PresentationProgramme_PARAM_TitreObjectifs";
    public final static String ppa_PresentationProgramme_lbl_Objectif = "ppa_PresentationProgramme_lbl_Objectif";
    public final static String ppa_PresentationProgramme_lbl_Indicateur = "ppa_PresentationProgramme_lbl_Indicateur";
    public final static String ppa_PresentationProgramme_lbl_Valeur = "ppa_PresentationProgramme_lbl_Valeur";
    public final static String ppa_PresentationProgramme_lbl_Date = "ppa_PresentationProgramme_lbl_Date";
    public final static String ppa_PresentationProgramme_lbl_UniteMesure = "ppa_PresentationProgramme_lbl_UniteMesure";
    public final static String ppa_PresentationProgramme_lbl_Cible = "ppa_PresentationProgramme_lbl_Cible";
    public final static String ppa_PresentationProgramme_lbl_Reference = "ppa_PresentationProgramme_lbl_Reference";
    public final static String ppa_PresentationProgramme_lbl_Action = "ppa_PresentationProgramme_lbl_Action";
//
    public final static String ppa_PresentationProgrammeActionsRecap_lbl_Action = "ppa_PresentationProgrammeActionsRecap_lbl_Action";
//
    public final static String ppa_PresentationProgrammeEtActions_PARAM_Titre_Actions = "ppa_PresentationProgrammeEtActions_PARAM_Titre_Actions";
    public final static String ppa_PresentationProgrammeEtActions_PARAM_LibelleProgramme = "ppa_PresentationProgrammeEtActions_PARAM_LibelleProgramme";
    public final static String ppa_PresentationProgrammeEtActions_PARAM_LibellePresentationProgramme = "ppa_PresentationProgrammeEtActions_PARAM_LibellePresentationProgramme";
    public final static String ppa_PresentationProgrammeEtActions_PARAM_LibellePresentationAction = "ppa_PresentationProgrammeEtActions_PARAM_LibellePresentationAction";
    public final static String ppa_PresentationProgrammeEtActions_PARAM_Libelle_StrategieProgramme = "ppa_PresentationProgrammeEtActions_PARAM_Libelle_StrategieProgramme";
    public final static String ppa_PresentationProgrammeEtActions_PARAM_LibelleRecap = "ppa_PresentationProgrammeEtActions_PARAM_LibelleRecap";
    public final static String ppa_PresentationProgrammeEtActions_PARAM_TitreObjectifs = "ppa_PresentationProgrammeEtActions_PARAM_TitreObjectifs";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Objectif = "ppa_PresentationProgrammeEtActions_lbl_Objectif";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Indicateur = "ppa_PresentationProgrammeEtActions_lbl_Indicateur";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Valeur = "ppa_PresentationProgrammeEtActions_lbl_Valeur";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Date = "ppa_PresentationProgrammeEtActions_lbl_Date";
    public final static String ppa_PresentationProgrammeEtActions_lbl_UniteMesure = "ppa_PresentationProgrammeEtActions_lbl_UniteMesure";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Cible = "ppa_PresentationProgrammeEtActions_lbl_Cible";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Reference = "ppa_PresentationProgrammeEtActions_lbl_Reference";
    public final static String ppa_PresentationProgrammeEtActions_lbl_Action = "ppa_PresentationProgrammeEtActions_lbl_Action";
//
    public final static String ppa_PresentationProgrammeStrategie_PARAM_Titre_Actions = "ppa_PresentationProgrammeStrategie_PARAM_Titre_Actions";
    public final static String ppa_PresentationProgrammeStrategie_PARAM_LibelleProgramme = "ppa_PresentationProgrammeStrategie_PARAM_LibelleProgramme";
    public final static String ppa_PresentationProgrammeStrategie_PARAM_LibellePresentationProgramme = "ppa_PresentationProgrammeStrategie_PARAM_LibellePresentationProgramme";
    public final static String ppa_PresentationProgrammeStrategie_PARAM_LibellePresentationAction = "ppa_PresentationProgrammeStrategie_PARAM_LibellePresentationAction";
    public final static String ppa_PresentationProgrammeStrategie_PARAM_Libelle_StrategieProgramme = "ppa_PresentationProgrammeStrategie_PARAM_Libelle_StrategieProgramme";
    public final static String ppa_PresentationProgrammeStrategie_PARAM_LibelleRecap = "ppa_PresentationProgrammeStrategie_PARAM_LibelleRecap";
    public final static String ppa_PresentationProgrammeStrategie_PARAM_TitreObjectifs = "ppa_PresentationProgrammeStrategie_PARAM_TitreObjectifs";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Objectif = "ppa_PresentationProgrammeStrategie_lbl_Objectif";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Indicateur = "ppa_PresentationProgrammeStrategie_lbl_Indicateur";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Valeur = "ppa_PresentationProgrammeStrategie_lbl_Valeur";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Date = "ppa_PresentationProgrammeStrategie_lbl_Date";
    public final static String ppa_PresentationProgrammeStrategie_lbl_UniteMesure = "ppa_PresentationProgrammeStrategie_lbl_UniteMesure";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Cible = "ppa_PresentationProgrammeStrategie_lbl_Cible";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Reference = "ppa_PresentationProgrammeStrategie_lbl_Reference";
    public final static String ppa_PresentationProgrammeStrategie_lbl_Action = "ppa_PresentationProgrammeStrategie_lbl_Action";
//
    public final static String ppa_ProgrammeObjectif_PARAM_Titre_Actions = "ppa_ProgrammeObjectif_PARAM_Titre_Actions";
    public final static String ppa_ProgrammeObjectif_PARAM_LibelleProgramme = "ppa_ProgrammeObjectif_PARAM_LibelleProgramme";
    public final static String ppa_ProgrammeObjectif_PARAM_LibellePresentationProgramme = "ppa_ProgrammeObjectif_PARAM_LibellePresentationProgramme";
    public final static String ppa_ProgrammeObjectif_PARAM_LibellePresentationAction = "ppa_ProgrammeObjectif_PARAM_LibellePresentationAction";
    public final static String ppa_ProgrammeObjectif_PARAM_Libelle_StrategieProgramme = "ppa_ProgrammeObjectif_PARAM_Libelle_StrategieProgramme";
    public final static String ppa_ProgrammeObjectif_PARAM_LibelleRecap = "ppa_ProgrammeObjectif_PARAM_LibelleRecap";
    public final static String ppa_ProgrammeObjectif_PARAM_TitreObjectifs = "ppa_ProgrammeObjectif_PARAM_TitreObjectifs";
    public final static String ppa_ProgrammeObjectif_lbl_Objectif = "ppa_ProgrammeObjectif_lbl_Objectif";
    public final static String ppa_ProgrammeObjectif_lbl_Indicateur = "ppa_ProgrammeObjectif_lbl_Indicateur";
    public final static String ppa_ProgrammeObjectif_lbl_Valeur = "ppa_ProgrammeObjectif_lbl_Valeur";
    public final static String ppa_ProgrammeObjectif_lbl_Date = "ppa_ProgrammeObjectif_lbl_Date";
    public final static String ppa_ProgrammeObjectif_lbl_UniteMesure = "ppa_ProgrammeObjectif_lbl_UniteMesure";
    public final static String ppa_ProgrammeObjectif_lbl_Cible = "ppa_ProgrammeObjectif_lbl_Cible";
    public final static String ppa_ProgrammeObjectif_lbl_Reference = "ppa_ProgrammeObjectif_lbl_Reference";
    public final static String ppa_ProgrammeObjectif_lbl_Action = "ppa_ProgrammeObjectif_lbl_Action";
//
    public final static String ppa_PARAM_MainLibelleProgramme = "ppa_PARAM_MainLibelleProgramme";
    public final static String ppa_PARAM_MainSommaire_1 = "ppa_PARAM_MainSommaire_1";
    public final static String ppa_PARAM_MainSommaire_11 = "ppa_PARAM_MainSommaire_11";
    public final static String ppa_PARAM_MainSommaire_12 = "ppa_PARAM_MainSommaire_12";
    public final static String ppa_PARAM_MainSommaire_13 = "ppa_PARAM_MainSommaire_13";
    public final static String ppa_PARAM_MainSommaire_131 = "ppa_PARAM_MainSommaire_131";
    public final static String ppa_PARAM_MainSommaire_132 = "ppa_PARAM_MainSommaire_132";
    public final static String ppa_PARAM_MainSommaire_14 = "ppa_PARAM_MainSommaire_14";
    public final static String ppa_PARAM_MainSommaire_15 = "ppa_PARAM_MainSommaire_15";
    public final static String ppa_PARAM_MainSommaire_16 = "ppa_PARAM_MainSommaire_16";
    public final static String ppa_PARAM_MainSommaire_2 = "ppa_PARAM_MainSommaire_2";
    public final static String ppa_PARAM_MainSommaire_Annexe = "ppa_PARAM_MainSommaire_Annexe";
    public final static String ppa_PARAM_MainSommaire_Annexe_1 = "ppa_PARAM_MainSommaire_Annexe_1";
//
    public final static String ppa_Projet_PG_PARAM_ResponsableProgramme = "ppa_Projet_PG_PARAM_ResponsableProgramme";
    public final static String ppa_Projet_PG_PARAM_LibelleProgramme = "ppa_Projet_PG_PARAM_LibelleProgramme";
    public final static String ppa_Projet_PG_PARAM_CoordonnateurProgramme = "ppa_Projet_PG_PARAM_CoordonnateurProgramme";
//
//    public final static String ppa_Projet_RTF_PARAM_Titre = "ppa_Projet_RTF_PARAM_Titre";
//    public final static String ppa_Projet_RTF_PARAM_SousTitre = "ppa_Projet_RTF_PARAM_SousTitre";
//    public final static String ppa_Projet_RTF_PARAM_Description = "ppa_Projet_RTF_PARAM_Description";
//    public final static String ppa_Projet_RTF_PARAM_NumSousTitre = "ppa_Projet_RTF_PARAM_NumSousTitre";
//    public final static String ppa_Projet_RTF_PARAM_NumTitre = "ppa_Projet_RTF_PARAM_NumTitre";
//    public final static String ppa_Projet_RTF_PARAM_NumSousTitre_1 = "ppa_Projet_RTF_PARAM_NumSousTitre_1";
//    public final static String ppa_Projet_RTF_PARAM_Description_1 = "ppa_Projet_RTF_PARAM_Description_1";
//    public final static String ppa_Projet_RTF_PARAM_SousTitre_1 = "ppa_Projet_RTF_PARAM_SousTitre_1";
//    public final static String ppa_Projet_RTF_PARAM_NumSousTitre_2 = "ppa_Projet_RTF_PARAM_NumSousTitre_2";
//    public final static String ppa_Projet_RTF_PARAM_Description_2 = "ppa_Projet_RTF_PARAM_Description_2";
//    public final static String ppa_Projet_RTF_PARAM_SousTitre_2 = "ppa_Projet_RTF_PARAM_SousTitre_2";
//    public final static String ppa_Projet_RTF_PARAM_NumSousTitre_3 = "ppa_Projet_RTF_PARAM_NumSousTitre_3";
//    public final static String ppa_Projet_RTF_PARAM_Description_3 = "ppa_Projet_RTF_PARAM_Description_3";
//    public final static String ppa_Projet_RTF_PARAM_SousTitre_3 = "ppa_Projet_RTF_PARAM_SousTitre_3";
//    public final static String ppa_Projet_RTF_PARAM_NumSousTitre_4 = "ppa_Projet_RTF_PARAM_NumSousTitre_4";
//    public final static String ppa_Projet_RTF_PARAM_Description_4 = "ppa_Projet_RTF_PARAM_Description_4";
//    public final static String ppa_Projet_RTF_PARAM_SousTitre_4 = "ppa_Projet_RTF_PARAM_SousTitre_4";
//    public final static String ppa_Projet_RTF_PARAM_DescriptionMenu = "ppa_Projet_RTF_PARAM_DescriptionMenu";
////
//    public final static String ppa_Projet_RTFDesc_PARAM_Titre = "ppa_Projet_RTFDesc_PARAM_Titre";
//    public final static String ppa_Projet_RTFDesc_PARAM_Description = "ppa_Projet_RTFDesc_PARAM_Description";
//    public final static String ppa_Projet_RTFDesc_PARAM_NumTitre = "ppa_Projet_RTFDesc_PARAM_NumTitre";
////
//    public final static String ppa_Projet_RTF_Image_PARAM_Titre = "ppa_Projet_RTF_Image_PARAM_Titre";
//    public final static String ppa_Projet_RTF_Image_PARAM_SousTitre = "ppa_Projet_RTF_Image_PARAM_SousTitre";
//    public final static String ppa_Projet_RTF_Image_PARAM_Description = "ppa_Projet_RTF_Image_PARAM_Description";
//    public final static String ppa_Projet_RTF_Image_PARAM_NumSousTitre = "ppa_Projet_RTF_Image_PARAM_NumSousTitre";
//    public final static String ppa_Projet_RTF_Image_PARAM_NumTitre = "ppa_Projet_RTF_Image_PARAM_NumTitre";
//    public final static String ppa_Projet_RTF_Image_PARAM_NumSousTitre_1 = "ppa_Projet_RTF_Image_PARAM_NumSousTitre_1";
//    public final static String ppa_Projet_RTF_Image_PARAM_Description_1 = "ppa_Projet_RTF_Image_PARAM_Description_1";
//    public final static String ppa_Projet_RTF_Image_PARAM_SousTitre_1 = "ppa_Projet_RTF_Image_PARAM_SousTitre_1";
//    public final static String ppa_Projet_RTF_Image_PARAM_NumSousTitre_2 = "ppa_Projet_RTF_Image_PARAM_NumSousTitre_2";
//    public final static String ppa_Projet_RTF_Image_PARAM_Description_2 = "ppa_Projet_RTF_Image_PARAM_Description_2";
//    public final static String ppa_Projet_RTF_Image_PARAM_SousTitre_2 = "ppa_Projet_RTF_Image_PARAM_SousTitre_2";
//    public final static String ppa_Projet_RTF_Image_PARAM_NumSousTitre_3 = "ppa_Projet_RTF_Image_PARAM_NumSousTitre_3";
//    public final static String ppa_Projet_RTF_Image_PARAM_Description_3 = "ppa_Projet_RTF_Image_PARAM_Description_3";
//    public final static String ppa_Projet_RTF_Image_PARAM_SousTitre_3 = "ppa_Projet_RTF_Image_PARAM_SousTitre_3";
//    public final static String ppa_Projet_RTF_Image_PARAM_NumSousTitre_4 = "ppa_Projet_RTF_Image_PARAM_NumSousTitre_4";
//    public final static String ppa_Projet_RTF_Image_PARAM_Description_4 = "ppa_Projet_RTF_Image_PARAM_Description_4";
//    public final static String ppa_Projet_RTF_Image_PARAM_SousTitre_4 = "ppa_Projet_RTF_Image_PARAM_SousTitre_4";
//
    public final static String projetBIP_lbl_Titre = "projetBIP_lbl_Titre";
    public final static String projetBIP_lbl_Projet = "projetBIP_lbl_Projet";
    public final static String projetBIP_lbl_Total = "projetBIP_lbl_Total";
    public final static String projetBIP_lbl_Chapitre = "projetBIP_lbl_Chapitre";
    public final static String projetBIP_lbl_Interne = "projetBIP_lbl_Interne";
    public final static String projetBIP_lbl_Externe = "projetBIP_lbl_Externe";
    public final static String projetBIP_PARAM_CoutTotal = "projetBIP_PARAM_CoutTotal";
    public final static String projetBIP_PARAM_Index = "projetBIP_PARAM_Index";
    public final static String projetBIP_lbl_AE = "projetBIP_lbl_AE";
    public final static String projetBIP_lbl_CP = "projetBIP_lbl_CP";
    public final static String projetBIP_lbl_Investissement = "projetBIP_lbl_Investissement";
//
    public final static String projetBIP_detail_lbl_Titre = "projetBIP_detail_lbl_Titre";
    public final static String projetBIP_detail_lbl_Projet = "projetBIP_detail_lbl_Projet";
    public final static String projetBIP_detail_lbl_Total = "projetBIP_detail_lbl_Total";
    public final static String projetBIP_detail_lbl_Chapitre = "projetBIP_detail_lbl_Chapitre";
    public final static String projetBIP_detail_lbl_Interne = "projetBIP_detail_lbl_Interne";
    public final static String projetBIP_detail_lbl_Externe = "projetBIP_detail_lbl_Externe";
    public final static String projetBIP_detail_PARAM_CoutTotal = "projetBIP_detail_PARAM_CoutTotal";
    public final static String projetBIP_detail_PARAM_Index = "projetBIP_detail_PARAM_Index";
    public final static String projetBIP_detail_lbl_AE = "projetBIP_detail_lbl_AE";
    public final static String projetBIP_detail_lbl_CP = "projetBIP_detail_lbl_CP";
    public final static String projetBIP_detail_lbl_Investissement = "projetBIP_detail_lbl_Investissement";
//
    public final static String projetMINEPAT_lbl_Operation = "projetMINEPAT_lbl_Operation";
    public final static String projetMINEPAT_lbl_Titre = "projetMINEPAT_lbl_Titre";
    public final static String projetMINEPAT_lbl_Projet = "projetMINEPAT_lbl_Projet";
    public final static String projetMINEPAT_lbl_Total = "projetMINEPAT_lbl_Total";
    public final static String projetMINEPAT_lbl_Cout = "projetMINEPAT_lbl_Cout";
    public final static String projetMINEPAT_lbl_Region = "projetMINEPAT_lbl_Region";
    public final static String projetMINEPAT_lbl_Departement = "projetMINEPAT_lbl_Departement";
    public final static String projetMINEPAT_lbl_Arrondissement = "projetMINEPAT_lbl_Arrondissement";
    public final static String projetMINEPAT_lbl_PosteComptable = "projetMINEPAT_lbl_PosteComptable";
    public final static String projetMINEPAT_lbl_Localite = "projetMINEPAT_lbl_Localite";
    public final static String projetMINEPAT_lbl_MG = "projetMINEPAT_lbl_MG";
    public final static String projetMINEPAT_lbl_MMarche = "projetMINEPAT_lbl_MMarche";
    public final static String projetMINEPAT_lbl_Gestionnaire = "projetMINEPAT_lbl_Gestionnaire";
    public final static String projetMINEPAT_lbl_CodeBudgetaire = "projetMINEPAT_lbl_CodeBudgetaire";
    public final static String projetMINEPAT_lbl_Chapitre = "projetMINEPAT_lbl_Chapitre";
    public final static String projetMINEPAT_lbl_Action = "projetMINEPAT_lbl_Action";
    public final static String projetMINEPAT_lbl_Programme = "projetMINEPAT_lbl_Programme";
    public final static String projetMINEPAT_PARAM_CoutTotal = "projetMINEPAT_PARAM_CoutTotal";
    public final static String projetMINEPAT_PARAM_Index = "projetMINEPAT_PARAM_Index";
    //
    public final static String feuilleDeTravail_PARAM_Titre = "feuilleDeTravail_PARAM_Titre";
    //
    public final static String titreBIP = "titreBIP";
    //
    public final static String appEtape = "appEtape";
    public final static String appDe = "appDe";
    public final static String uniteUnit = "uniteUnit";
    public final static String uniteKilo = "uniteKilo";
    public final static String uniteMega = "uniteMega";
    public final static String uniteGiga = "uniteGiga";
    //
    public final static String Minepat_Pointage = "Minepat_Pointage";
    public final static String Minepat_PointageRegion = "Minepat_PointageRegion";
    public final static String Minepat_JournalProjetChRgPortrait2013 = "JournalProjetChRgPortrait2013";
    public final static String Minepat_JournalProjetRgDeChPortrait2013 = "JournalProjetRgDeChPortrait2013";
    //
    public final static String Minepat_Budget_CH_PG_Mode_Fin = "Budget_CH_PG_Mode_Fin";
    public final static String Minepat_Budget_CH_AV_Mode_Fin = "Budget_CH_AV_Mode_Fin";
    public final static String Minepat_Budgetisation_PG = "Budgetisation_PG";
    public final static String Minepat_Tableau_Budgetisation = "Tableau_Budgetisation";
    public final static String Minepat_Detail_OP_CH_PG_AC = "Detail_OP_CH_PG_AC";
    public final static String Minepat_Detail_OP_CH_PG_AC_PJ = "Detail_OP_CH_PG_AC_PJ";
    public final static String Minepat_Detail_OP_CH_PG_AC_RG = "Detail_OP_CH_PG_AC_RG";
    public final static String Minepat_Detail_OP_CH_PG_AC_DE = "Detail_OP_CH_PG_AC_DE";
    public final static String Minepat_Detail_OP_CH_PG_AC_AO = "Detail_OP_CH_PG_AC_AO";
    public final static String Minepat_Detail_OP_CH_IM = "Detail_OP_CH_IM";
    public final static String Minepat_Depenses_Detaillees_AR_PA = "Depenses_Detaillees_AR_PA";
    public final static String Minepat_Identifiaction_AC_PG = "Identifiaction_AC_PG";
    public final static String Minepat_Elements_Contenu_AC = "Elements_Contenu_AC";
    public final static String Minepat_Tableau_Programmation = "Tableau_Programmation";
    public final static String Minepat_Journal_PJ_CH_PG_AC = "Journal_PJ_CH_PG_AC";
    public final static String Minepat_Journal_PJ_CH_PG_AC_PJ = "Journal_PJ_CH_PG_AC_PJ";
    public final static String Minepat_Journal_PJ_CH_IM = "Journal_PJ_CH_IM";
    public final static String Minepat_Synthese_Budget_CH_PG = "Synthese_Budget_CH_PG";
    public final static String Minepat_Synthese_Budget_CH_PG_AC = "Synthese_Budget_CH_PG_AC";
    public final static String Minepat_Syntheses_Couts_PG = "Syntheses_Couts_PG";
    public final static String Minepat_Detail_TA_CH_PG_AC_PJ = "Detail_TA_CH_PG_AC_PJ";
    public final static String Minepat_Journal_PJ_OP_RG_CH = "Detail_PJ_OP_RG_CH";
    public final static String Minepat_BIP = "Minepat_BIP";
    public final static String Minepat_Journal_PJ = "Minepat_Journal_PJ";
    //
    public static final int Minepat_Int_Budget_CH_PG_Mode_Fin = 1;
    public static final int Minepat_Int_Budget_CH_AV_Mode_Fin = 2;
    public static final int Minepat_Int_Budgetisation_PG = 3;
    public static final int Minepat_Int_Tableau_Budgetisation = 4;
    public static final int Minepat_Int_Detail_OP_CH_PG_AC = 5;
    public static final int Minepat_Int_Detail_OP_CH_PG_AC_PJ = 6;
    public static final int Minepat_Int_Detail_OP_CH_PG_AC_RG = 7;
    public static final int Minepat_Int_Detail_OP_CH_PG_AC_DE = 8;
    public static final int Minepat_Int_Detail_OP_CH_PG_AC_AO = 9;
    public static final int Minepat_Int_Detail_OP_CH_IM = 10;
    public static final int Minepat_Int_Depenses_Detaillees_AR_PA = 11;
    public static final int Minepat_Int_Identifiaction_AC_PG = 12;
    public static final int Minepat_Int_Elements_Contenu_AC = 13;
    public static final int Minepat_Int_Tableau_Programmation = 14;
    public static final int Minepat_Int_Journal_PJ_CH_PG_AC = 15;
    public static final int Minepat_Int_Journal_PJ_CH_PG_AC_PJ = 16;
    public static final int Minepat_Int_Journal_PJ_CH_IM = 17;
    public static final int Minepat_Int_Synthese_Budget_CH_PG = 18;
    public static final int Minepat_Int_Synthese_Budget_CH_PG_AC = 19;
    public static final int Minepat_Int_Syntheses_Couts_PG = 20;
    public static final int Minepat_Int_Detail_TA_CH_PG_AC_PJ = 21;
    public final static int Minepat_Int_Journal_PJ_OP_RG_CH = 22;
    public final static int Minepat_Int_BIP = 23;
    public final static int Minepat_Int_Journal_PJ = 24;
    public final static int Minepat_Int_Pointage = 25;
    public final static int Minepat_Int_JournalProjetChRgPortrait2013 = 26;
    public final static int Minepat_Int_JournalProjetRgDeChPortrait2013 = 27;
    public final static int Minepat_Int_PointageRegion = 28;

    public static String getMinepatIntToCode(int code) {
        switch (code) {
            case Minepat_Int_JournalProjetChRgPortrait2013:
                return Minepat_JournalProjetChRgPortrait2013;

            case Minepat_Int_JournalProjetRgDeChPortrait2013:
                return Minepat_JournalProjetRgDeChPortrait2013;

            case Minepat_Int_Pointage:
                return Minepat_Pointage;

            case Minepat_Int_PointageRegion:
                return Minepat_PointageRegion;

            case Minepat_Int_Budget_CH_PG_Mode_Fin:
                return Minepat_Budget_CH_PG_Mode_Fin;

            case Minepat_Int_Budget_CH_AV_Mode_Fin:
                return Minepat_Budget_CH_AV_Mode_Fin;

            case Minepat_Int_Budgetisation_PG:
                return Minepat_Budgetisation_PG;

            case Minepat_Int_Tableau_Budgetisation:
                return Minepat_Tableau_Budgetisation;

            case Minepat_Int_Detail_OP_CH_PG_AC:
                return Minepat_Detail_OP_CH_PG_AC;

            case Minepat_Int_Detail_OP_CH_PG_AC_PJ:
                return Minepat_Detail_OP_CH_PG_AC_PJ;

            case Minepat_Int_Detail_OP_CH_PG_AC_RG:
                return Minepat_Detail_OP_CH_PG_AC_RG;

            case Minepat_Int_Detail_OP_CH_PG_AC_DE:
                return Minepat_Detail_OP_CH_PG_AC_DE;

            case Minepat_Int_Detail_OP_CH_PG_AC_AO:
                return Minepat_Detail_OP_CH_PG_AC_AO;

            case Minepat_Int_Detail_OP_CH_IM:
                return Minepat_Detail_OP_CH_IM;

            case Minepat_Int_Depenses_Detaillees_AR_PA:
                return Minepat_Depenses_Detaillees_AR_PA;

            case Minepat_Int_Identifiaction_AC_PG:
                return Minepat_Identifiaction_AC_PG;

            case Minepat_Int_Elements_Contenu_AC:
                return Minepat_Elements_Contenu_AC;

            case Minepat_Int_Tableau_Programmation:
                return Minepat_Tableau_Programmation;

            case Minepat_Int_Journal_PJ_CH_PG_AC:
                return Minepat_Journal_PJ_CH_PG_AC;

            case Minepat_Int_Journal_PJ_CH_PG_AC_PJ:
                return Minepat_Journal_PJ_CH_PG_AC_PJ;

            case Minepat_Int_Journal_PJ_CH_IM:
                return Minepat_Journal_PJ_CH_IM;

            case Minepat_Int_Synthese_Budget_CH_PG:
                return Minepat_Synthese_Budget_CH_PG;

            case Minepat_Int_Synthese_Budget_CH_PG_AC:
                return Minepat_Synthese_Budget_CH_PG_AC;

            case Minepat_Int_Syntheses_Couts_PG:
                return Minepat_Syntheses_Couts_PG;

            case Minepat_Int_Detail_TA_CH_PG_AC_PJ:
                return Minepat_Detail_TA_CH_PG_AC_PJ;

            case Minepat_Int_Journal_PJ_OP_RG_CH:
                return Minepat_Journal_PJ_OP_RG_CH;

            case Minepat_Int_BIP:
                return Minepat_BIP;

            case Minepat_Int_Journal_PJ:
                return Minepat_Journal_PJ;
        }
        return "";

    }

    public static int getMinepatCodeToInt(String strCode) {
        switch (strCode) {
            case Minepat_JournalProjetChRgPortrait2013:
                return Minepat_Int_JournalProjetChRgPortrait2013;
            case Minepat_JournalProjetRgDeChPortrait2013:
                return Minepat_Int_JournalProjetRgDeChPortrait2013;
            case Minepat_Pointage:
                return Minepat_Int_Pointage;
            case Minepat_PointageRegion:
                return Minepat_Int_PointageRegion;
            case Minepat_Budget_CH_PG_Mode_Fin:
                return Minepat_Int_Budget_CH_PG_Mode_Fin;
            case Minepat_Budget_CH_AV_Mode_Fin:
                return Minepat_Int_Budget_CH_AV_Mode_Fin;
            case Minepat_Budgetisation_PG:
                return Minepat_Int_Budgetisation_PG;
            case Minepat_Tableau_Budgetisation:
                return Minepat_Int_Tableau_Budgetisation;
            case Minepat_Detail_OP_CH_PG_AC:
                return Minepat_Int_Detail_OP_CH_PG_AC;
            case Minepat_Detail_OP_CH_PG_AC_PJ:
                return Minepat_Int_Detail_OP_CH_PG_AC_PJ;
            case Minepat_Detail_OP_CH_PG_AC_RG:
                return Minepat_Int_Detail_OP_CH_PG_AC_RG;
            case Minepat_Detail_OP_CH_PG_AC_DE:
                return Minepat_Int_Detail_OP_CH_PG_AC_DE;
            case Minepat_Detail_OP_CH_PG_AC_AO:
                return Minepat_Int_Detail_OP_CH_PG_AC_AO;
            case Minepat_Detail_OP_CH_IM:
                return Minepat_Int_Detail_OP_CH_IM;
            case Minepat_Depenses_Detaillees_AR_PA:
                return Minepat_Int_Depenses_Detaillees_AR_PA;
            case Minepat_Identifiaction_AC_PG:
                return Minepat_Int_Identifiaction_AC_PG;
            case Minepat_Elements_Contenu_AC:
                return Minepat_Int_Elements_Contenu_AC;
            case Minepat_Tableau_Programmation:
                return Minepat_Int_Tableau_Programmation;
            case Minepat_Journal_PJ_CH_PG_AC:
                return Minepat_Int_Journal_PJ_CH_PG_AC;
            case Minepat_Journal_PJ_CH_PG_AC_PJ:
                return Minepat_Int_Journal_PJ_CH_PG_AC_PJ;
            case Minepat_Journal_PJ_CH_IM:
                return Minepat_Int_Journal_PJ_CH_IM;
            case Minepat_Synthese_Budget_CH_PG:
                return Minepat_Int_Synthese_Budget_CH_PG;
            case Minepat_Synthese_Budget_CH_PG_AC:
                return Minepat_Int_Synthese_Budget_CH_PG_AC;
            case Minepat_Syntheses_Couts_PG:
                return Minepat_Int_Syntheses_Couts_PG;
            case Minepat_Detail_TA_CH_PG_AC_PJ:
                return Minepat_Int_Detail_TA_CH_PG_AC_PJ;
            case Minepat_Journal_PJ_OP_RG_CH:
                return Minepat_Int_Journal_PJ_OP_RG_CH;
            case Minepat_BIP:
                return Minepat_Int_BIP;
            case Minepat_Journal_PJ:
                return Minepat_Int_Journal_PJ;
            default:
                return 0;
        }
    }

    public static boolean isMinepatLandScape(String strCode) {
        switch (strCode) {
            case Minepat_Pointage:
                return true;
            case Minepat_Journal_PJ_CH_PG_AC:
                return true;
            case Minepat_Journal_PJ_CH_PG_AC_PJ:
                return true;
            case Minepat_Journal_PJ_CH_IM:
                return true;
            case Minepat_Synthese_Budget_CH_PG:
                return true;
            case Minepat_Synthese_Budget_CH_PG_AC:
                return true;
            case Minepat_Journal_PJ_OP_RG_CH:
                return true;
            case Minepat_Journal_PJ:
                return true;
            default:
                return false;
        }
    }

    public String getLblVersion() {
        return getLabel(lblVersion);
    }

    public String getLblCHAPITRE() {
        return getLabel(lblCHAPITRE);
    }

    public String getDevise() {
        return getLabel(param_Devise);
    }

    public String getPays() {
        return getLabel(param_Pays);
    }

    public String getLibelleResteDep() {
        return getLabel(bd_LibelleResteDep);
    }

    public String getlibelleAutreChapSE() {
        return getLabel(bd_libelleAutreChapSE);
    }

    public String getLibelleDC() {
        return getLabel(bd_libelleDC);
    }

    public String getLibelleDI() {
        return getLabel(bd_libelleDI);
    }

    public String getLibelleSC() {
        return getLabel(bd_libelleSC);
    }

    public String getLibelleSETR() {
        return getLabel(bd_libelleSETR);
    }

    public String getLibelleSEXT() {
        return getLabel(bd_libelleSEXT);
    }

    public String getPlf(boolean isDraft) {
        return getLabel(isDraft ? lblPLFDraft : lblPLFDefinitif);
    }

    public String getPrExercice(int annee) {
        if (annee <= 1966) {
            return getLabel(lblPrExercice).replace("{0}", " ");
        }
        return getLabel(lblPrExercice).replace("{0}", " ".concat(Integer.toString(annee)).concat(" "));
    }

    public String getAnnee() {
        return getLabel(lblAnnee);
    }

    public String getBudgetEtatCamDCGrapheTitre() {
        return getLabel(budgetEtatCamDCGrapheTitre);
    }

    public String getBudgetEtatCamDIGrapheTitre() {
        return getLabel(budgetEtatCamDIGrapheTitre);
    }

    public String getBudgetEtatCamGrapheTitre() {
        return getLabel(budgetEtatCamGrapheTitre);
    }

    public String getBudgetEtatHistoGrapheTitre() {
        return getLabel(budgetEtatHistoGrapheTitre);
    }

    public String getBudgetSecteurGraphe1() {
        return getLabel(budgetSecteurGraphe1);
    }

    public String getBudgetSecteurGraphe2() {
        return getLabel(budgetSecteurGraphe2);
    }

    public String getBudgetSecteurGraphe3() {
        return getLabel(budgetSecteurGraphe3);
    }

    public String getBudgetSecteurGraphe4() {
        return getLabel(budgetSecteurGraphe4);
    }

    public String getAppEtape() {
        return getLabel(appEtape);
    }

    public String getAppDe() {
        return getLabel(appDe);
    }

    public String titreDecentralisation() {
        return getLabel(decentralisationTitre);
    }

    public String titreBudgetEtat() {
        return getLabel(budgetEtatTitre);
    }

    public String titreDeveloppementDepenses() {
        return getLabel(developpementDepensesTitre);
    }

    public String titreDepensesParFonctionEtNatureEco() {
        return getLabel(depensesParFonctionEtNatureEcoTitre);
    }

    public String titreDepensesParSecteurEtNatureEco() {
        return getLabel(depensesParSecteurEtNatureEcoTitre);
    }

    public String titreDepenseFpPgAcObIn() {
        return getLabel(DepenseFpPgAcObIn_PARAM_Titre);
    }

    public String titreDepenseFpPgAcObInComite() {
        return getLabel(DepenseFpPgAcObInPaysage_PARAM_Titre_Comite);
    }

    public String titreDepensePgAcObInComite() {
        return getLabel(DepensePgAcObIn_PARAM_Titre_Comite);
    }

    public String titrePPA() {
        return getLabel(ppa_PARAM_Titre);
    }

    public String titreDepensesParFctPgAr() {
        return getLabel(DepensesParFctPgAr_PARAM_Titre);
    }

    public String titreListeProgramme() {
        return getLabel(listeProgramme_PARAM_Titre);
    }
//
//    public String titreFicheDeCollecte() {
//        return getLabel(ficheDeCollecte_PARAM_Titre);
//    }

    public String titreFeuilleDeTravail() {
        return getLabel(feuilleDeTravail_PARAM_Titre);
    }

    public String titreBudgetEtatChapitre() {
        return getLabel(budgetEtatChapitre_PARAM_Titre);
    }

    public String titreBudgetEtatCategorieChapitreEtRegion() {
        return getLabel(budgetEtatCategorieChapitreEtRegionTitre);
    }

    public String titreBudgetEtatCategorieRegionEtChapitre() {
        return getLabel(budgetEtatCategorieRegionEtChapitreTitre);
    }

    public String titrebudgetParMinistereEtRegion() {
        return getLabel(budgetParMinistereEtRegionTitre);
    }

    public String getlibelleAutreChapCA() {
        return getLabel(bd_libelleAutreChapCA);
    }

    public String getLibelleTousChapitres() {
        return getLabel(bd_libelleTousChapitres);
    }

    public String titreBIP() {
        return getLabel(titreBIP);
    }

    public String getLabel(String label, Locale locale) {
        if (locale.equals(Locale.ENGLISH)) {
            return getLabelUS(label);
        } else {
            return getLabelFR(label);
        }
    }
}
