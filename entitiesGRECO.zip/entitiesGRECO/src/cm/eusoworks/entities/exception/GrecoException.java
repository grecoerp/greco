/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.exception;

/**
 *
 * @author macbookair
 */
public class GrecoException extends Exception {

    String messageUs;
    private boolean typeDirect = false;
    public GrecoException() {
    }

    public GrecoException(String message) {
        this(message,"",false);
    }
    
    public GrecoException(String message, String messageUs, boolean direct) {
        super(message);
        this.messageUs = messageUs;
        this.typeDirect = direct;
    }

    public GrecoException(String message, Throwable cause) {
        super(message, cause);
    }

    public GrecoException(Throwable cause) {
        super(cause);
    }

    public GrecoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }

    public String getMessageUs() {
        return messageUs;
    }

    public void setMessageUs(String messageUs) {
        this.messageUs = messageUs;
    }

    public boolean isTypeDirect() {
        return typeDirect;
    }


}
