/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;

/**
 *
 * @author jeanemmanuel
 */

public class VueFournisseurRIB implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String fournisseurID;
    private String numContribuable;
    private String raisonSociale;
    private String rib;
    private String codeBanque;
    private String sigle;
    private String designationBanque;
    private String codeAgence;
    private String designationAgence;
    
    private String compte;
    

    public VueFournisseurRIB() {
    }

    public String getFournisseurID() {
        return fournisseurID;
    }

    public void setFournisseurID(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public String getNumContribuable() {
        return numContribuable;
    }

    public void setNumContribuable(String numContribuable) {
        this.numContribuable = numContribuable;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public void setRaisonSociale(String raisonSociale) {
        this.raisonSociale = raisonSociale;
    }

    public String getCodeBanque() {
        return codeBanque;
    }

    public void setCodeBanque(String codeBanque) {
        this.codeBanque = codeBanque;
    }

    public String getSigle() {
        return sigle;
    }

    public void setSigle(String sigle) {
        this.sigle = sigle;
    }

    public String getDesignationBanque() {
        return designationBanque;
    }

    public void setDesignationBanque(String designationBanque) {
        this.designationBanque = designationBanque;
    }

    public String getCodeAgence() {
        return codeAgence;
    }

    public void setCodeAgence(String codeAgence) {
        this.codeAgence = codeAgence;
    }

    public String getDesignationAgence() {
        return designationAgence;
    }

    public void setDesignationAgence(String designationAgence) {
        this.designationAgence = designationAgence;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public String getCompte() {
        return ribFormat(rib) + " ["+designationBanque+"/"+designationAgence+"]";
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    private String ribFormat(String r){
        String f = "";
        try {
            f = r.substring(0, 5)+"  "+r.substring(6, 11)+" "+r.substring(12, 23)+" "+r.substring(24, 26);
        } catch (Exception e) {
            f = "";
        }
        return f;
    }
    
    
    @Override
    public String toString() {
        return rib+" "+sigle+" "+designationAgence;
    }
    
}
