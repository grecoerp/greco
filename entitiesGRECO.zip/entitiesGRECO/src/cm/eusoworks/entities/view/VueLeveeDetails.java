/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author ouethy
 */

public class VueLeveeDetails implements Serializable {

    private static final long serialVersionUID = 1L;


    private String id;
    private String leveeId;
    private String identifiant;
    private String beneficiaire;
    private String blocage;
    private String motifLevee;
    private String userDemande;
    private Date dateDemande;
    private boolean statut;

    public VueLeveeDetails() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
    
    

    public String getIdentifiant() {
        return identifiant;
    }

    public void setIdentifiant(String identifiant) {
        this.identifiant = identifiant;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public String getBlocage() {
        return blocage;
    }

    public void setBlocage(String blocage) {
        this.blocage = blocage;
    }

    public String getMotifLevee() {
        return motifLevee;
    }

    public void setMotifLevee(String motifLevee) {
        this.motifLevee = motifLevee;
    }

    public String getUserDemande() {
        return userDemande;
    }

    public void setUserDemande(String userDemande) {
        this.userDemande = userDemande;
    }

    public Date getDateDemande() {
        return dateDemande;
    }

    public void setDateDemande(Date dateDemande) {
        this.dateDemande = dateDemande;
    }

    public boolean isStatut() {
        return statut;
    }

    public void setStatut(boolean statut) {
        this.statut = statut;
    }

    public String getLeveeId() {
        return leveeId;
    }

    public void setLeveeId(String leveeId) {
        this.leveeId = leveeId;
    }

    
    
}
