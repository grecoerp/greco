/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author ouethy
 */
public class VueEngagementJournal  implements Serializable {
    
    private static final long serialVersionUID = 1L;
    
    private String engagementID;
    private String libelleFr;
    private String libelleUs;
    private String motif;
    private Date dateOperation;
    private String login;
    private String user;

    public String getEngagementID() {
        return engagementID;
    }

    public void setEngagementID(String engagementID) {
        this.engagementID = engagementID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
        if(this.motif == null) this.motif = "";
    }

    public Date getDateOperation() {
        return dateOperation;
    }

    public void setDateOperation(Date dateOperation) {
        this.dateOperation = dateOperation;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
    
   public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }
    
    public String getLibelle(Locale locale) {
        if(locale.equals(Locale.FRENCH)){
            return libelleFr;
        }else {
            return libelleUs;
        }
    } 
    
    public String getOperation() {
        return getLibelle(Locale.getDefault())+ ((motif ==null || motif.isEmpty())?"":"["+motif+"]");
    }
}
