/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class VuePTATache implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String pgCode;
    private String pgLibelle;
    private String acCode;
    private String acLibelle;
    private String taCode;
    private String taLibelle;
    private BigDecimal aeBF;
    private BigDecimal cpBF;
    private BigDecimal aeBIP;
    private BigDecimal cpBIP;
    private String exLibelle;
    private String orgLibelleFr;
    private String orgLibelleUs;

    public VuePTATache() {
    }

    public String getPgCode() {
        return pgCode;
    }

    public void setPgCode(String pgCode) {
        this.pgCode = pgCode;
    }

    public String getPgLibelle() {
        return pgLibelle;
    }

    public void setPgLibelle(String pgLibelle) {
        this.pgLibelle = pgLibelle;
    }

    public String getAcCode() {
        return acCode;
    }

    public void setAcCode(String acCode) {
        this.acCode = acCode;
    }

    public String getAcLibelle() {
        return acLibelle;
    }

    public void setAcLibelle(String acLibelle) {
        this.acLibelle = acLibelle;
    }

    public String getTaCode() {
        return taCode;
    }

    public void setTaCode(String taCode) {
        this.taCode = taCode;
    }

    public String getTaLibelle() {
        return taLibelle;
    }

    public void setTaLibelle(String taLibelle) {
        this.taLibelle = taLibelle;
    }

    public BigDecimal getAeBF() {
        return aeBF;
    }

    public void setAeBF(BigDecimal aeBF) {
        this.aeBF = aeBF;
    }

    public BigDecimal getCpBF() {
        return cpBF;
    }

    public void setCpBF(BigDecimal cpBF) {
        this.cpBF = cpBF;
    }

    public BigDecimal getAeBIP() {
        return aeBIP;
    }

    public void setAeBIP(BigDecimal aeBIP) {
        this.aeBIP = aeBIP;
    }

    public BigDecimal getCpBIP() {
        return cpBIP;
    }

    public void setCpBIP(BigDecimal cpBIP) {
        this.cpBIP = cpBIP;
    }

    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getOrgLibelleFr() {
        return orgLibelleFr;
    }

    public void setOrgLibelleFr(String orgLibelleFr) {
        this.orgLibelleFr = orgLibelleFr;
    }

    public String getOrgLibelleUs() {
        return orgLibelleUs;
    }

    public void setOrgLibelleUs(String orgLibelleUs) {
        this.orgLibelleUs = orgLibelleUs;
    }
    
    
}
