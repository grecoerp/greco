/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import cm.eusoworks.entities.security.Crypto;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author ouethy
 */

public class VueTrack implements Serializable {

    private static final long serialVersionUID = 1L;

        
    private String zZ33; 
    private String nM; 
    private String pM; 
    private String mAT7; 
    private String m2M; 
    private String tR78; 
    private String r36; 
    private String yU9;
    private Date lUJ2; 
    private String SYS; //OS
    private String AHT9; //32 ou 64 bits
    private String FCT8; //Fonction d'appel
    private String MDL6; //module appele

    public VueTrack() {
    }

    public String getzZ33() {
        return Crypto.decrypt(zZ33);
    }

    public void setzZ33(String zZ33) {
        this.zZ33 = zZ33;
    }

    public String getnM() {
        return Crypto.decrypt(nM);
    }

    public void setnM(String nM) {
        this.nM = nM;
    }

    public String getpM() {
        return Crypto.decrypt(pM);
    }

    public void setpM(String pM) {
        this.pM = pM;
    }

    public String getmAT7() {
        return Crypto.decrypt(mAT7);
    }

    public void setmAT7(String mAT7) {
        this.mAT7 = mAT7;
    }

    public String getM2M() {
        return Crypto.decrypt(m2M);
    }

    public void setM2M(String m2M) {
        this.m2M = m2M;
    }

    public String gettR78() {
        return Crypto.decrypt(tR78);
    }

    public void settR78(String tR78) {
        this.tR78 = tR78;
    }

    public String getR36() {
        return Crypto.decrypt(r36);
    }

    public void setR36(String r36) {
        this.r36 = r36;
    }

    public String getyU9() {
        return Crypto.decrypt(yU9);
    }

    public void setyU9(String yU9) {
        this.yU9 = yU9;
    }

    public Date getlUJ2() {
        return lUJ2;
    }

    public void setlUJ2(Date lUJ2) {
        this.lUJ2 = lUJ2;
    }

    public String getSYS() {
        return SYS;
    }

    public void setSYS(String SYS) {
        this.SYS = SYS;
    }

    public String getAHT9() {
        return AHT9;
    }

    public void setAHT9(String AHT9) {
        this.AHT9 = AHT9;
    }

    public String getFCT8() {
        return FCT8;
    }

    public void setFCT8(String FCT8) {
        this.FCT8 = FCT8;
    }

    public String getMDL6() {
        return MDL6;
    }

    public void setMDL6(String MDL6) {
        this.MDL6 = MDL6;
    }
    
    
}
