/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.io.Serializable;

/**
 *
 * @author ouethy
 */

public class VueStructureBCA implements Serializable {

    private static final long serialVersionUID = 1L;
    private String structureID;
    private String code;
    private String abbreviationFr;
    private String abbreviationUs;
    private String libelleFr;
    private String libelleUs;
    private Integer nbBCA;
    private int etat;

    public VueStructureBCA() {
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAbbreviationFr() {
        return abbreviationFr;
    }

    public void setAbbreviationFr(String abbreviationFr) {
        this.abbreviationFr = abbreviationFr;
    }

    public String getAbbreviationUs() {
        return abbreviationUs;
    }

    public void setAbbreviationUs(String abbreviationUs) {
        this.abbreviationUs = abbreviationUs;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Integer getNbBCA() {
        return nbBCA;
    }

    public void setNbBCA(Integer nbBCA) {
        this.nbBCA = nbBCA;
    }

    @Override
    public String toString() {
        String nb = "00"+nbBCA; 
        return "("+nb.substring(nb.length()-3, nb.length())+") "+abbreviationFr+"    ["+getEtatString()+"]";
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public String getEtatString() {
        return EtatDossier.getString( etat).toUpperCase();
    }
    
}
