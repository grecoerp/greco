/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author cwam
 */
public class VuePrepaMarche implements Serializable {

    private static final long serialVersionUID = 1L;
    private String prLibelleFrancais;
    private String prLibelleAnglais;
    private String deLibelleFrancais;
    private String deLibelleAnglais;
    private String aoLibelleFrancais;
    private String aoLibelleAnglais;
    private String exMillesime;
    private String chCodeChapitre;
    private String paLibelleFrancais;
    private String paLibelleAnglais;
    private String imputation;
    private String paId;
    private Boolean uniteExistante;
    private String intitule;
    private String nom;
    private String posteOccupe;
    private String adresse;
    private String email;
    private String telephone;
    private Integer annee1;
    private String intitule1;
    private BigDecimal cout1;
    private Integer annee2;
    private String intitule2;
    private BigDecimal cout2;
    private Integer annee3;
    private String intitule3;
    private BigDecimal cout3;
    private Integer annee4;
    private String intitule4;
    private BigDecimal cout4;
    private Integer annee5;
    private String intitule5;
    private BigDecimal cout5;
    private String typeAOId;
    private String codeTypeAO;
    private String libelleTypeAO;
    private String naturePrestationId;
    private String codePrestation;
    private String abbreviationPrestation;
    private String libelleFrPrestation;
    private String libelleUsPrestation;
    private String financementId;
    private String abbreviationFinancement;
    private String libelleFrFinancement;
    private String libelleUsFinancement;
    private String contractantId;
    private String libelleFrContractant;
    private String libelleUsContractant;
    private String paIdMarche;
    private Integer numOrdre;
    private String maitreOuvrage;
    private Boolean annualite;
    private String motifGreAGre;
    private Date dateDebut;
    private Date dateFin;
    private Date dateLancement;
    private Date dateAttribution;
    private Date dateSignature;
    private Date dateDemarrage;
    private Date dateReception;
    private Date dateLancementCP;
    private Date dateAttributionCP;
    private Date dateSignatureCP;
    private Date dateDemarrageCP;
    private Date dateReceptionCP;
    private BigDecimal paCP;
    private String paLocalite;
    private String nomSGP1;
    private String nomSGP2;
    private String adresseSGP1;
    private String adresseSGP2;
    private String telSGP1;
    private String telSGP2;
    private String exLibelleFrancais;
    private String abbreviationAO;
    private String arCode;

    public String getArCode() {
        return arCode;
    }

    public void setArCode(String arCode) {
        this.arCode = arCode;
    }

    public String getAbbreviationAO() {
        return abbreviationAO;
    }

    public void setAbbreviationAO(String abbreviationAO) {
        this.abbreviationAO = abbreviationAO;
    }

    public String getAbbreviationFinancement() {
        return abbreviationFinancement;
    }

    public void setAbbreviationFinancement(String abbreviationFinancement) {
        this.abbreviationFinancement = abbreviationFinancement;
    }

    public String getAbbreviationPrestation() {
        return abbreviationPrestation;
    }

    public void setAbbreviationPrestation(String abbreviationPrestation) {
        this.abbreviationPrestation = abbreviationPrestation;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getAdresseSGP1() {
        return adresseSGP1;
    }

    public void setAdresseSGP1(String adresseSGP1) {
        this.adresseSGP1 = adresseSGP1;
    }

    public String getAdresseSGP2() {
        return adresseSGP2;
    }

    public void setAdresseSGP2(String adresseSGP2) {
        this.adresseSGP2 = adresseSGP2;
    }

    public Integer getAnnee1() {
        return annee1;
    }

    public void setAnnee1(Integer annee1) {
        this.annee1 = annee1;
    }

    public Integer getAnnee2() {
        return annee2;
    }

    public void setAnnee2(Integer annee2) {
        this.annee2 = annee2;
    }

    public Integer getAnnee3() {
        return annee3;
    }

    public void setAnnee3(Integer annee3) {
        this.annee3 = annee3;
    }

    public Integer getAnnee4() {
        return annee4;
    }

    public void setAnnee4(Integer annee4) {
        this.annee4 = annee4;
    }

    public Integer getAnnee5() {
        return annee5;
    }

    public void setAnnee5(Integer annee5) {
        this.annee5 = annee5;
    }

    public Boolean getAnnualite() {
        return annualite;
    }

    public void setAnnualite(Boolean annualite) {
        this.annualite = annualite;
    }

    public String getAoLibelleAnglais() {
        return aoLibelleAnglais;
    }

    public void setAoLibelleAnglais(String aoLibelleAnglais) {
        this.aoLibelleAnglais = aoLibelleAnglais;
    }

    public String getAoLibelleFrancais() {
        return aoLibelleFrancais;
    }

    public void setAoLibelleFrancais(String aoLibelleFrancais) {
        this.aoLibelleFrancais = aoLibelleFrancais;
    }

    public String getChCodeChapitre() {
        return chCodeChapitre;
    }

    public void setChCodeChapitre(String chCodeChapitre) {
        this.chCodeChapitre = chCodeChapitre;
    }

    public String getCodePrestation() {
        return codePrestation;
    }

    public void setCodePrestation(String codePrestation) {
        this.codePrestation = codePrestation;
    }

    public String getCodeTypeAO() {
        return codeTypeAO;
    }

    public void setCodeTypeAO(String codeTypeAO) {
        this.codeTypeAO = codeTypeAO;
    }

    public String getContractantId() {
        return contractantId;
    }

    public void setContractantId(String contractantId) {
        this.contractantId = contractantId;
    }

    public BigDecimal getCout1() {
        return cout1;
    }

    public void setCout1(BigDecimal cout1) {
        this.cout1 = cout1;
    }

    public BigDecimal getCout2() {
        return cout2;
    }

    public void setCout2(BigDecimal cout2) {
        this.cout2 = cout2;
    }

    public BigDecimal getCout3() {
        return cout3;
    }

    public void setCout3(BigDecimal cout3) {
        this.cout3 = cout3;
    }

    public BigDecimal getCout4() {
        return cout4;
    }

    public void setCout4(BigDecimal cout4) {
        this.cout4 = cout4;
    }

    public BigDecimal getCout5() {
        return cout5;
    }

    public void setCout5(BigDecimal cout5) {
        this.cout5 = cout5;
    }

    public Date getDateAttribution() {
        return dateAttribution;
    }

    public void setDateAttribution(Date dateAttribution) {
        this.dateAttribution = dateAttribution;
    }

    public Date getDateAttributionCP() {
        return dateAttributionCP;
    }

    public void setDateAttributionCP(Date dateAttributionCP) {
        this.dateAttributionCP = dateAttributionCP;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateDemarrage() {
        return dateDemarrage;
    }

    public void setDateDemarrage(Date dateDemarrage) {
        this.dateDemarrage = dateDemarrage;
    }

    public Date getDateDemarrageCP() {
        return dateDemarrageCP;
    }

    public void setDateDemarrageCP(Date dateDemarrageCP) {
        this.dateDemarrageCP = dateDemarrageCP;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public Date getDateLancement() {
        return dateLancement;
    }

    public void setDateLancement(Date dateLancement) {
        this.dateLancement = dateLancement;
    }

    public Date getDateLancementCP() {
        return dateLancementCP;
    }

    public void setDateLancementCP(Date dateLancementCP) {
        this.dateLancementCP = dateLancementCP;
    }

    public Date getDateReception() {
        return dateReception;
    }

    public void setDateReception(Date dateReception) {
        this.dateReception = dateReception;
    }

    public Date getDateReceptionCP() {
        return dateReceptionCP;
    }

    public void setDateReceptionCP(Date dateReceptionCP) {
        this.dateReceptionCP = dateReceptionCP;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public Date getDateSignatureCP() {
        return dateSignatureCP;
    }

    public void setDateSignatureCP(Date dateSignatureCP) {
        this.dateSignatureCP = dateSignatureCP;
    }

    public String getDeLibelleAnglais() {
        return deLibelleAnglais;
    }

    public void setDeLibelleAnglais(String deLibelleAnglais) {
        this.deLibelleAnglais = deLibelleAnglais;
    }

    public String getDeLibelleFrancais() {
        return deLibelleFrancais;
    }

    public void setDeLibelleFrancais(String deLibelleFrancais) {
        this.deLibelleFrancais = deLibelleFrancais;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getExLibelleFrancais() {
        return exLibelleFrancais;
    }

    public void setExLibelleFrancais(String exLibelleFrancais) {
        this.exLibelleFrancais = exLibelleFrancais;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getFinancementId() {
        return financementId;
    }

    public void setFinancementId(String financementId) {
        this.financementId = financementId;
    }

    public String getImputation() {
        return imputation;
    }

    public void setImputation(String imputation) {
        this.imputation = imputation;
    }

    public String getIntitule() {
        return intitule;
    }

    public void setIntitule(String intitule) {
        this.intitule = intitule;
    }

    public String getIntitule1() {
        return intitule1;
    }

    public void setIntitule1(String intitule1) {
        this.intitule1 = intitule1;
    }

    public String getIntitule2() {
        return intitule2;
    }

    public void setIntitule2(String intitule2) {
        this.intitule2 = intitule2;
    }

    public String getIntitule3() {
        return intitule3;
    }

    public void setIntitule3(String intitule3) {
        this.intitule3 = intitule3;
    }

    public String getIntitule4() {
        return intitule4;
    }

    public void setIntitule4(String intitule4) {
        this.intitule4 = intitule4;
    }

    public String getIntitule5() {
        return intitule5;
    }

    public void setIntitule5(String intitule5) {
        this.intitule5 = intitule5;
    }

    public String getLibelleFrContractant() {
        return libelleFrContractant;
    }

    public void setLibelleFrContractant(String libelleFrContractant) {
        this.libelleFrContractant = libelleFrContractant;
    }

    public String getLibelleFrFinancement() {
        return libelleFrFinancement;
    }

    public void setLibelleFrFinancement(String libelleFrFinancement) {
        this.libelleFrFinancement = libelleFrFinancement;
    }

    public String getLibelleFrPrestation() {
        return libelleFrPrestation;
    }

    public void setLibelleFrPrestation(String libelleFrPrestation) {
        this.libelleFrPrestation = libelleFrPrestation;
    }

    public String getLibelleTypeAO() {
        return libelleTypeAO;
    }

    public void setLibelleTypeAO(String libelleTypeAO) {
        this.libelleTypeAO = libelleTypeAO;
    }

    public String getLibelleUsContractant() {
        return libelleUsContractant;
    }

    public void setLibelleUsContractant(String libelleUsContractant) {
        this.libelleUsContractant = libelleUsContractant;
    }

    public String getLibelleUsFinancement() {
        return libelleUsFinancement;
    }

    public void setLibelleUsFinancement(String libelleUsFinancement) {
        this.libelleUsFinancement = libelleUsFinancement;
    }

    public String getLibelleUsPrestation() {
        return libelleUsPrestation;
    }

    public void setLibelleUsPrestation(String libelleUsPrestation) {
        this.libelleUsPrestation = libelleUsPrestation;
    }

    public String getMaitreOuvrage() {
        return maitreOuvrage;
    }

    public void setMaitreOuvrage(String maitreOuvrage) {
        this.maitreOuvrage = maitreOuvrage;
    }

    public String getMotifGreAGre() {
        return motifGreAGre;
    }

    public void setMotifGreAGre(String motifGreAGre) {
        this.motifGreAGre = motifGreAGre;
    }

    public String getNaturePrestationId() {
        return naturePrestationId;
    }

    public void setNaturePrestationId(String naturePrestationId) {
        this.naturePrestationId = naturePrestationId;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNomSGP1() {
        return nomSGP1;
    }

    public void setNomSGP1(String nomSGP1) {
        this.nomSGP1 = nomSGP1;
    }

    public String getNomSGP2() {
        return nomSGP2;
    }

    public void setNomSGP2(String nomSGP2) {
        this.nomSGP2 = nomSGP2;
    }

    public Integer getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(Integer numOrdre) {
        this.numOrdre = numOrdre;
    }

    public BigDecimal getPaCP() {
        return paCP;
    }

    public void setPaCP(BigDecimal paCP) {
        this.paCP = paCP;
    }

    public String getPaId() {
        return paId;
    }

    public void setPaId(String paId) {
        this.paId = paId;
    }

    public String getPaIdMarche() {
        return paIdMarche;
    }

    public void setPaIdMarche(String paIdMarche) {
        this.paIdMarche = paIdMarche;
    }

    public String getPaLibelleAnglais() {
        return paLibelleAnglais;
    }

    public void setPaLibelleAnglais(String paLibelleAnglais) {
        this.paLibelleAnglais = paLibelleAnglais;
    }

    public String getPaLibelleFrancais() {
        return paLibelleFrancais;
    }

    public void setPaLibelleFrancais(String paLibelleFrancais) {
        this.paLibelleFrancais = paLibelleFrancais;
    }

    public String getPaLocalite() {
        return paLocalite;
    }

    public void setPaLocalite(String paLocalite) {
        this.paLocalite = paLocalite;
    }

    public String getPosteOccupe() {
        return posteOccupe;
    }

    public void setPosteOccupe(String posteOccupe) {
        this.posteOccupe = posteOccupe;
    }

    public String getPrLibelleAnglais() {
        return prLibelleAnglais;
    }

    public void setPrLibelleAnglais(String prLibelleAnglais) {
        this.prLibelleAnglais = prLibelleAnglais;
    }

    public String getPrLibelleFrancais() {
        return prLibelleFrancais;
    }

    public void setPrLibelleFrancais(String prLibelleFrancais) {
        this.prLibelleFrancais = prLibelleFrancais;
    }

    public String getTelSGP1() {
        return telSGP1;
    }

    public void setTelSGP1(String telSGP1) {
        this.telSGP1 = telSGP1;
    }

    public String getTelSGP2() {
        return telSGP2;
    }

    public void setTelSGP2(String telSGP2) {
        this.telSGP2 = telSGP2;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getTypeAOId() {
        return typeAOId;
    }

    public void setTypeAOId(String typeAOId) {
        this.typeAOId = typeAOId;
    }

    public Boolean getUniteExistante() {
        return uniteExistante;
    }

    public void setUniteExistante(Boolean uniteExistante) {
        this.uniteExistante = uniteExistante;
    }
}
