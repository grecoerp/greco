/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author cwam
 */
public class VuePrepaMarcheJournal implements Serializable {

    private static final long serialVersionUID = 1L;
    private Integer numOrdre;
    private String maitreOuvrage;
    private Date dateLancement;
    private Date dateAttribution;
    private Date dateSignature;
    private Date dateDemarrage;
    private Date dateReception;
    private String libelleFr;
    private String abbreviation;
    private String abbreviationAO;
    private String chLibelleReduitFr;
    private String chCode;
    private String exMillesime;
    private String exLibelleFrancais;
    private String paLibelleFrancais;
    private BigDecimal paCP;
    private String paLocalite;
    private String aoLibelleFrancais;
    private String aoLibelleAnglais;
    private String deLibelleFrancais;
    private String deLibelleAnglais;
    private String prLibelleFrancais;
    private String prLibelleAnglais;

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getAbbreviationAO() {
        return abbreviationAO;
    }

    public void setAbbreviationAO(String abbreviationAO) {
        this.abbreviationAO = abbreviationAO;
    }

    public String getAoLibelleAnglais() {
        return aoLibelleAnglais;
    }

    public void setAoLibelleAnglais(String aoLibelleAnglais) {
        this.aoLibelleAnglais = aoLibelleAnglais;
    }

    public String getAoLibelleFrancais() {
        return aoLibelleFrancais;
    }

    public void setAoLibelleFrancais(String aoLibelleFrancais) {
        this.aoLibelleFrancais = aoLibelleFrancais;
    }

    public String getChCode() {
        return chCode;
    }

    public void setChCode(String chCode) {
        this.chCode = chCode;
    }

    public String getChLibelleReduitFr() {
        return chLibelleReduitFr;
    }

    public void setChLibelleReduitFr(String chLibelleReduitFr) {
        this.chLibelleReduitFr = chLibelleReduitFr;
    }

    public Date getDateAttribution() {
        return dateAttribution;
    }

    public void setDateAttribution(Date dateAttribution) {
        this.dateAttribution = dateAttribution;
    }

    public Date getDateDemarrage() {
        return dateDemarrage;
    }

    public void setDateDemarrage(Date dateDemarrage) {
        this.dateDemarrage = dateDemarrage;
    }

    public Date getDateLancement() {
        return dateLancement;
    }

    public void setDateLancement(Date dateLancement) {
        this.dateLancement = dateLancement;
    }

    public Date getDateReception() {
        return dateReception;
    }

    public void setDateReception(Date dateReception) {
        this.dateReception = dateReception;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public String getDeLibelleAnglais() {
        return deLibelleAnglais;
    }

    public void setDeLibelleAnglais(String deLibelleAnglais) {
        this.deLibelleAnglais = deLibelleAnglais;
    }

    public String getDeLibelleFrancais() {
        return deLibelleFrancais;
    }

    public void setDeLibelleFrancais(String deLibelleFrancais) {
        this.deLibelleFrancais = deLibelleFrancais;
    }

    public String getExLibelleFrancais() {
        return exLibelleFrancais;
    }

    public void setExLibelleFrancais(String exLibelleFrancais) {
        this.exLibelleFrancais = exLibelleFrancais;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getMaitreOuvrage() {
        return maitreOuvrage;
    }

    public void setMaitreOuvrage(String maitreOuvrage) {
        this.maitreOuvrage = maitreOuvrage;
    }

    public Integer getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(Integer numOrdre) {
        this.numOrdre = numOrdre;
    }

    public BigDecimal getPaCP() {
        return paCP;
    }

    public void setPaCP(BigDecimal paCP) {
        this.paCP = paCP;
    }

    public String getPaLibelleFrancais() {
        return paLibelleFrancais;
    }

    public void setPaLibelleFrancais(String paLibelleFrancais) {
        this.paLibelleFrancais = paLibelleFrancais;
    }

    public String getPaLocalite() {
        return paLocalite;
    }

    public void setPaLocalite(String paLocalite) {
        this.paLocalite = paLocalite;
    }

    public String getPrLibelleAnglais() {
        return prLibelleAnglais;
    }

    public void setPrLibelleAnglais(String prLibelleAnglais) {
        this.prLibelleAnglais = prLibelleAnglais;
    }

    public String getPrLibelleFrancais() {
        return prLibelleFrancais;
    }

    public void setPrLibelleFrancais(String prLibelleFrancais) {
        this.prLibelleFrancais = prLibelleFrancais;
    }
}
