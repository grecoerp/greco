/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author ouethy
 */

public class VueEngagementState implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Boolean stateEngage;
    private Boolean stateLiquide;
    private Boolean stateMandate;
    private Boolean stateRegle;
    private Date dateEngage;
    private Date dateLiquide;
    private Date dateMandate;
    private Date dateRegle;
    
    public VueEngagementState() {
    }

    public Boolean isStateEngage() {
        return stateEngage;
    }

    public void setStateEngage(Boolean stateEngage) {
        this.stateEngage = stateEngage;
    }

    public Boolean isStateLiquide() {
        return stateLiquide;
    }

    public void setStateLiquide(Boolean stateLiquide) {
        this.stateLiquide = stateLiquide;
    }

    public Boolean isStateMandate() {
        return stateMandate;
    }

    public void setStateMandate(Boolean stateMandate) {
        this.stateMandate = stateMandate;
    }

    public Boolean isStateRegle() {
        return stateRegle;
    }

    public void setStateRegle(Boolean stateRegle) {
        this.stateRegle = stateRegle;
    }

    public Date getDateEngage() {
        return dateEngage;
    }

    public void setDateEngage(Date dateEngage) {
        this.dateEngage = dateEngage;
    }

    public Date getDateLiquide() {
        return dateLiquide;
    }

    public void setDateLiquide(Date dateLiquide) {
        this.dateLiquide = dateLiquide;
    }

    public Date getDateMandate() {
        return dateMandate;
    }

    public void setDateMandate(Date dateMandate) {
        this.dateMandate = dateMandate;
    }

    public Date getDateRegle() {
        return dateRegle;
    }

    public void setDateRegle(Date dateRegle) {
        this.dateRegle = dateRegle;
    }

}
