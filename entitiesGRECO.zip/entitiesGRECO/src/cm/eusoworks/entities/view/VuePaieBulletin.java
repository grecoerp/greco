/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VuePaieBulletin implements Serializable {

    private static final long serialVersionUID = 1L;
    Date periodDebut;
    Date periodeFin;
    String adresseOrg;
    String boitePostaleOrg;
    String numContribuableOrg;
    String numSSOrg;
    String matriculeEmp;
    String numSSEmp;
    String emploiEmp;
    String qualificationEmp;
    float coeffEmp;
    String nomEmp;
    String prenomEmp;
    String adresseEmp;
    String boitePostaleEmp;
    BigDecimal totalBrut;
    BigDecimal totalRetenues;
    BigDecimal netAPayer;
    BigDecimal totalRetenuePatronnales;

    public VuePaieBulletin() {
    }

    public Date getPeriodDebut() {
        return periodDebut;
    }

    public void setPeriodDebut(Date periodDebut) {
        this.periodDebut = periodDebut;
    }

    public Date getPeriodeFin() {
        return periodeFin;
    }

    public void setPeriodeFin(Date periodeFin) {
        this.periodeFin = periodeFin;
    }

    public String getAdresseOrg() {
        return adresseOrg;
    }

    public void setAdresseOrg(String adresseOrg) {
        this.adresseOrg = adresseOrg;
    }

    public String getBoitePostaleOrg() {
        return boitePostaleOrg;
    }

    public void setBoitePostaleOrg(String boitePostaleOrg) {
        this.boitePostaleOrg = boitePostaleOrg;
    }

    public String getNumContribuableOrg() {
        return numContribuableOrg;
    }

    public void setNumContribuableOrg(String numContribuableOrg) {
        this.numContribuableOrg = numContribuableOrg;
    }

    public String getNumSSOrg() {
        return numSSOrg;
    }

    public void setNumSSOrg(String numSSOrg) {
        this.numSSOrg = numSSOrg;
    }

    public String getMatriculeEmp() {
        return matriculeEmp;
    }

    public void setMatriculeEmp(String matriculeEmp) {
        this.matriculeEmp = matriculeEmp;
    }

    public String getNumSSEmp() {
        return numSSEmp;
    }

    public void setNumSSEmp(String numSSEmp) {
        this.numSSEmp = numSSEmp;
    }

    public String getEmploiEmp() {
        return emploiEmp;
    }

    public void setEmploiEmp(String emploiEmp) {
        this.emploiEmp = emploiEmp;
    }

    public String getQualificationEmp() {
        return qualificationEmp;
    }

    public void setQualificationEmp(String qualificationEmp) {
        this.qualificationEmp = qualificationEmp;
    }

    public float getCoeffEmp() {
        return coeffEmp;
    }

    public void setCoeffEmp(float coeffEmp) {
        this.coeffEmp = coeffEmp;
    }

    public String getNomEmp() {
        return nomEmp;
    }

    public void setNomEmp(String nomEmp) {
        this.nomEmp = nomEmp;
    }

    public String getPrenomEmp() {
        return prenomEmp;
    }

    public void setPrenomEmp(String prenomEmp) {
        this.prenomEmp = prenomEmp;
    }

    public String getAdresseEmp() {
        return adresseEmp;
    }

    public void setAdresseEmp(String adresseEmp) {
        this.adresseEmp = adresseEmp;
    }

    public String getBoitePostaleEmp() {
        return boitePostaleEmp;
    }

    public void setBoitePostaleEmp(String boitePostaleEmp) {
        this.boitePostaleEmp = boitePostaleEmp;
    }

    public BigDecimal getTotalBrut() {
        return totalBrut;
    }

    public void setTotalBrut(BigDecimal totalBrut) {
        this.totalBrut = totalBrut;
    }

    public BigDecimal getTotalRetenues() {
        return totalRetenues;
    }

    public void setTotalRetenues(BigDecimal totalRetenues) {
        this.totalRetenues = totalRetenues;
    }

    public BigDecimal getNetAPayer() {
        return netAPayer;
    }

    public void setNetAPayer(BigDecimal netAPayer) {
        this.netAPayer = netAPayer;
    }

    public BigDecimal getTotalRetenuePatronnales() {
        return totalRetenuePatronnales;
    }

    public void setTotalRetenuePatronnales(BigDecimal totalRetenuePatronnales) {
        this.totalRetenuePatronnales = totalRetenuePatronnales;
    }
    
    

}
