/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VueBCAReport implements Serializable {

    private static final long serialVersionUID = 1L;

    private String bcaId;
    private String objet;
    private String reference;
    private Date delaiDeLivraison;
    private Date dateDeSignature;
    private String lieuDeSignature;
    private String entete1;
    private String entete2;
    private String entete3;
    private String entete4;
    private String entete5;
    private BigDecimal montantTTC;
    private BigDecimal montantHT;
    private BigDecimal montantTVA;
    private BigDecimal montantIR;
    private Float tauxTVA;
    private Float tauxIR;
    private BigDecimal NAP;
    private String contribuableId;
    private String matriculeOrdonnateur;
    private String paExecutionId;
    private String exMillesime;
    private String numImputation;
    private String bcaLigneId;
    private BigDecimal prixUnitaireLigne;
    private Integer quantiteLigne;
    private BigDecimal montantHTLigne;
    private Long tauxTVALigne;
    private Long tauxIRLigne;
    private String numOrdre;
    private String exLibelleFrancais;
    private String exLibelleAnglais;
    private String chCode;
    private String chAbreviation;
    private String chLibelleFrancais;
    private String chLibelleAnglais;
    private String agNom;
    private String agPrenom;
    private String agNomJeuneFille;
    private String numContribuable;
    private String raisonSociale;
    private String adresse;
    private String boitePostale;
    private String telephone;
    private String amId;
    private String refArticle;
    private String designation;
    private String sfCodeSrcFin;
    private String registreCommerce;
    private String pgCode;
    private String pgLibelle;
    private String acCode;
    private String acLibelle;
    private String projetCode;
    private String projetLibelle;
    

    public String getBcaId() {
        return bcaId;
    }

    public void setBcaId(String bcaId) {
        this.bcaId = bcaId;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Date getDelaiDeLivraison() {
        return delaiDeLivraison;
    }

    public void setDelaiDeLivraison(Date delaiDeLivraison) {
        this.delaiDeLivraison = delaiDeLivraison;
    }

    public Date getDateDeSignature() {
        return dateDeSignature;
    }

    public void setDateDeSignature(Date dateDeSignature) {
        this.dateDeSignature = dateDeSignature;
    }

    public String getLieuDeSignature() {
        return lieuDeSignature;
    }

    public void setLieuDeSignature(String lieuDeSignature) {
        this.lieuDeSignature = lieuDeSignature;
    }

    public String getEntete1() {
        return entete1;
    }

    public void setEntete1(String entete1) {
        this.entete1 = entete1;
    }

    public String getEntete2() {
        return entete2;
    }

    public void setEntete2(String entete2) {
        this.entete2 = entete2;
    }

    public String getEntete3() {
        return entete3;
    }

    public void setEntete3(String entete3) {
        this.entete3 = entete3;
    }

    public String getEntete4() {
        return entete4;
    }

    public void setEntete4(String entete4) {
        this.entete4 = entete4;
    }

    public String getEntete5() {
        return entete5;
    }

    public void setEntete5(String entete5) {
        this.entete5 = entete5;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public BigDecimal getMontantHT() {
        return montantHT;
    }

    public void setMontantHT(BigDecimal montantHT) {
        this.montantHT = montantHT;
    }

    public BigDecimal getMontantTVA() {
        return montantTVA;
    }

    public void setMontantTVA(BigDecimal montantTVA) {
        this.montantTVA = montantTVA;
    }

    public BigDecimal getMontantIR() {
        return montantIR;
    }

    public void setMontantIR(BigDecimal montantIR) {
        this.montantIR = montantIR;
    }

    public Float getTauxTVA() {
        return tauxTVA;
    }

    public void setTauxTVA(Float tauxTVA) {
        this.tauxTVA = tauxTVA;
    }

    public Float getTauxIR() {
        return tauxIR;
    }

    public void setTauxIR(Float tauxIR) {
        this.tauxIR = tauxIR;
    }

    public BigDecimal getNAP() {
        return NAP;
    }

    public void setNAP(BigDecimal NAP) {
        this.NAP = NAP;
    }

    public String getContribuableId() {
        return contribuableId;
    }

    public void setContribuableId(String contribuableId) {
        this.contribuableId = contribuableId;
    }

    public String getMatriculeOrdonnateur() {
        return matriculeOrdonnateur;
    }

    public void setMatriculeOrdonnateur(String matriculeOrdonnateur) {
        this.matriculeOrdonnateur = matriculeOrdonnateur;
    }

    public String getPaExecutionId() {
        return paExecutionId;
    }

    public void setPaExecutionId(String paExecutionId) {
        this.paExecutionId = paExecutionId;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getNumImputation() {
        return numImputation;
    }

    public void setNumImputation(String numImputation) {
        this.numImputation = numImputation;
    }

    public String getBcaLigneId() {
        return bcaLigneId;
    }

    public void setBcaLigneId(String bcaLigneId) {
        this.bcaLigneId = bcaLigneId;
    }

    public BigDecimal getPrixUnitaireLigne() {
        return prixUnitaireLigne;
    }

    public void setPrixUnitaireLigne(BigDecimal prixUnitaireLigne) {
        this.prixUnitaireLigne = prixUnitaireLigne;
    }

    public Integer getQuantiteLigne() {
        return quantiteLigne;
    }

    public void setQuantiteLigne(Integer quantiteLigne) {
        this.quantiteLigne = quantiteLigne;
    }

    public BigDecimal getMontantHTLigne() {
        return montantHTLigne;
    }

    public void setMontantHTLigne(BigDecimal montantHTLigne) {
        this.montantHTLigne = montantHTLigne;
    }

    public Long getTauxTVALigne() {
        return tauxTVALigne;
    }

    public void setTauxTVALigne(Long tauxTVALigne) {
        this.tauxTVALigne = tauxTVALigne;
    }

    public Long getTauxIRLigne() {
        return tauxIRLigne;
    }

    public void setTauxIRLigne(Long tauxIRLigne) {
        this.tauxIRLigne = tauxIRLigne;
    }

    public String getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(String numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getExLibelleFrancais() {
        return exLibelleFrancais;
    }

    public void setExLibelleFrancais(String exLibelleFrancais) {
        this.exLibelleFrancais = exLibelleFrancais;
    }

    public String getExLibelleAnglais() {
        return exLibelleAnglais;
    }

    public void setExLibelleAnglais(String exLibelleAnglais) {
        this.exLibelleAnglais = exLibelleAnglais;
    }

    public String getChCode() {
        return chCode;
    }

    public void setChCode(String chCode) {
        this.chCode = chCode;
    }

    public String getChAbreviation() {
        return chAbreviation;
    }

    public void setChAbreviation(String chAbreviation) {
        this.chAbreviation = chAbreviation;
    }

    public String getChLibelleFrancais() {
        return chLibelleFrancais;
    }

    public void setChLibelleFrancais(String chLibelleFrancais) {
        this.chLibelleFrancais = chLibelleFrancais;
    }

    public String getChLibelleAnglais() {
        return chLibelleAnglais;
    }

    public void setChLibelleAnglais(String chLibelleAnglais) {
        this.chLibelleAnglais = chLibelleAnglais;
    }

    public String getAgNom() {
        return agNom;
    }

    public void setAgNom(String agNom) {
        this.agNom = agNom;
    }

    public String getAgPrenom() {
        return agPrenom;
    }

    public void setAgPrenom(String agPrenom) {
        this.agPrenom = agPrenom;
    }

    public String getAgNomJeuneFille() {
        return agNomJeuneFille;
    }

    public void setAgNomJeuneFille(String agNomJeuneFille) {
        this.agNomJeuneFille = agNomJeuneFille;
    }

    public String getNumContribuable() {
        return numContribuable;
    }

    public void setNumContribuable(String numContribuable) {
        this.numContribuable = numContribuable;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public void setRaisonSociale(String raisonSociale) {
        this.raisonSociale = raisonSociale;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getBoitePostale() {
        return boitePostale;
    }

    public void setBoitePostale(String boitePostale) {
        this.boitePostale = boitePostale;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    public String getAmId() {
        return amId;
    }

    public void setAmId(String amId) {
        this.amId = amId;
    }

    public String getRefArticle() {
        return refArticle;
    }

    public void setRefArticle(String refArticle) {
        this.refArticle = refArticle;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getSfCodeSrcFin() {
        return sfCodeSrcFin;
    }

    public void setSfCodeSrcFin(String sfCodeSrcFin) {
        this.sfCodeSrcFin = sfCodeSrcFin;
    }

    public String getRegistreCommerce() {
        return registreCommerce;
    }

    public void setRegistreCommerce(String registreCommerce) {
        this.registreCommerce = registreCommerce;
    }

    public String getPgCode() {
        return pgCode;
    }

    public void setPgCode(String pgCode) {
        this.pgCode = pgCode;
    }

    public String getPgLibelle() {
        return pgLibelle;
    }

    public void setPgLibelle(String pgLibelle) {
        this.pgLibelle = pgLibelle;
    }

    public String getAcCode() {
        return acCode;
    }

    public void setAcCode(String acCode) {
        this.acCode = acCode;
    }

    public String getAcLibelle() {
        return acLibelle;
    }

    public void setAcLibelle(String acLibelle) {
        this.acLibelle = acLibelle;
    }

    public String getProjetCode() {
        return projetCode;
    }

    public void setProjetCode(String projetCode) {
        this.projetCode = projetCode;
    }

    public String getProjetLibelle() {
        return projetLibelle;
    }

    public void setProjetLibelle(String projetLibelle) {
        this.projetLibelle = projetLibelle;
    }  
}
