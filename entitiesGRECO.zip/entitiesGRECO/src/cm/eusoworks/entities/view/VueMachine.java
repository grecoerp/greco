/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import cm.eusoworks.entities.security.Crypto;
import java.io.Serializable;

/**
 *
 * @author ouethy
 */
public class VueMachine implements Serializable {

    private static final long serialVersionUID = 1L;

    private String tR78;
    private String r36;
    private String yU9;
    private String host;

    public VueMachine() {
    }

    public String gettR78() {
        return Crypto.decrypt(tR78);
    }

    public void settR78(String tR78) {
        this.tR78 = tR78;
    }

    public String getR36() {
        return Crypto.decrypt(r36);
    }

    public void setR36(String r36) {
        this.r36 = r36;
    }

    public String getyU9() {
        return Crypto.decrypt(yU9);
    }
    
    public String getMACCrypte() {
        return yU9;
    }

    public void setyU9(String yU9) {
        this.yU9 = yU9;
    }

    public String getNomMachine() {
        return tR78;
    }

    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }



    @Override
    public String toString() {
        return getyU9() + " " + gettR78() + " [" + getR36() + "]";
    }

}
