/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;

/**
 *
 * @author ouethy
 */
public class VueUsersFonctionnalite implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String idParent;
    private String libelleFr;
    private String libelleUs;
    private String code;
    private String ocag;
    private int moduleID;
    private boolean actif;

    public VueUsersFonctionnalite() {
    }

    public VueUsersFonctionnalite(String id, String idParent, String libelleFr, String libelleUs, String code, int moduleID, String ocag, boolean actif) {
        this.id = id;
        this.idParent = idParent;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
        this.code = code;
        this.ocag = ocag;
        this.moduleID = moduleID;
        this.actif = actif;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdParent() {
        return idParent;
    }

    public void setIdParent(String idParent) {
        this.idParent = idParent;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getOcag() {
        return ocag;
    }

    public void setOcag(String ocag) {
        this.ocag = ocag;
    }

    public int getModuleID() {
        return moduleID;
    }

    public void setModuleID(int moduleID) {
        this.moduleID = moduleID;
    }

    public boolean isActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    
    @Override
    public String toString() {
        return getLibelleFr();
    }

}
