/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;

/**
 *
 * @author ouethy
 */

public class VueAgentOM implements Serializable {

    private static final long serialVersionUID = 1L;
    private String matricule;
    private String nom;
    private String prenom;
    private int nbOM;
    
    private int nbJours = 0;

    public VueAgentOM() {
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public int getNbOM() {
        return nbOM;
    }

    public void setNbOM(int nbOM) {
        this.nbOM = nbOM;
    }

    public int getNbJours() {
        return nbJours;
    }

    public void setNbJours(int nbJours) {
        this.nbJours = nbJours;
    }
    
    private String getNbJoursFormat(){
        String f = "000"+nbJours;
        return f.substring(f.length()-3, f.length());
    }
    
    private String getNbMissionsFormat(){
        String f = "00"+nbOM;
        return f.substring(f.length()-2, f.length());
    }

    
    @Override
    public String toString() {
        return "("+getNbMissionsFormat()+"/"+getNbJoursFormat()+") "+" ["+matricule+"]  "+nom+" - "+prenom;
    }
    
}
