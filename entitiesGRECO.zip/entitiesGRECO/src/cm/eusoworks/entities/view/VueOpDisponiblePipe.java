/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class VueOpDisponiblePipe implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private String tacheID;
    private BigDecimal ae;
    private BigDecimal engage;
    private BigDecimal pipe;
    private BigDecimal reste;

    public VueOpDisponiblePipe() {
        ae = BigDecimal.ZERO;
        engage = BigDecimal.ZERO;
        pipe = BigDecimal.ZERO;
        reste = BigDecimal.ZERO;
        tacheID = null;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getEngage() {
        return engage;
    }

    public void setEngage(BigDecimal engage) {
        this.engage = engage;
    }

    public BigDecimal getPipe() {
        return pipe;
    }

    public void setPipe(BigDecimal pipe) {
        this.pipe = pipe;
    }

    public BigDecimal getReste() {
        return reste;
    }

    public void setReste(BigDecimal reste) {
        this.reste = reste;
    }

}
