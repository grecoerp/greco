/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;

/**
 *
 * @author ouethy
 */

public class VueStructureCodification implements Serializable {

    private static final long serialVersionUID = 1L;
    private String abbreviationFr;
    private String libelleFr;
    private String libelleGroupe;
    private int niveauOrganiqueID;

    public VueStructureCodification() {
    }

    public String getAbbreviationFr() {
        return abbreviationFr;
    }

    public void setAbbreviationFr(String abbreviationFr) {
        this.abbreviationFr = abbreviationFr;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleGroupe() {
        return libelleGroupe;
    }

    public void setLibelleGroupe(String libelleGroupe) {
        this.libelleGroupe = libelleGroupe;
    }

    public int getNiveauOrganiqueID() {
        return niveauOrganiqueID;
    }

    public void setNiveauOrganiqueID(int niveauOrganiqueID) {
        this.niveauOrganiqueID = niveauOrganiqueID;
    }

    
    
    
    @Override
    public String toString() {
        return abbreviationFr+" - "+libelleFr;
    }
    
}
