/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;

/**
 *
 * @author ouethy
 */

public class VueEngagementStat implements Serializable {

    private static final long serialVersionUID = 1L;
    private int save;
    private int reserve;
    private int rejet;
    private int controle;
    private int annulControl;

    public VueEngagementStat() {
    }

    public int getSave() {
        return save;
    }

    public void setSave(int save) {
        this.save = save;
    }

    public int getReserve() {
        return reserve;
    }

    public void setReserve(int reserve) {
        this.reserve = reserve;
    }

    public int getRejet() {
        return rejet;
    }

    public void setRejet(int rejet) {
        this.rejet = rejet;
    }

    public int getControle() {
        return controle;
    }

    public void setControle(int controle) {
        this.controle = controle;
    }

    public int getAnnulControl() {
        return annulControl;
    }

    public void setAnnulControl(int annulControl) {
        this.annulControl = annulControl;
    }

    
    
}
