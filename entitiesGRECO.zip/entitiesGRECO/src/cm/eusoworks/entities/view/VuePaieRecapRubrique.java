/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VuePaieRecapRubrique implements Serializable {

    private static final long serialVersionUID = 1L;
    Date periodDebut;
    Date periodeFin;
    String libelle;
    BigDecimal montant;

    public VuePaieRecapRubrique() {
    }

    public Date getPeriodDebut() {
        return periodDebut;
    }

    public void setPeriodDebut(Date periodDebut) {
        this.periodDebut = periodDebut;
    }

    public Date getPeriodeFin() {
        return periodeFin;
    }

    public void setPeriodeFin(Date periodeFin) {
        this.periodeFin = periodeFin;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    
    

}
