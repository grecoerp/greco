/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class VuePTAOperation implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String pgCode;
    private String pgLibelle;
    private String acCode;
    private String acLibelle;
    private String taCode;
    private String taLibelle;
    private String opLibelle;
    private String indicateurFr;
    private String sourceVerificationFr;
    private String structure;
    private String compteCode;
    private String compteLibelle;
    private String financement;
    private BigDecimal ae;
    private BigDecimal cp;
    private String jan;
    private String feb;
    private String mar;
    private String apr;
    private String may;
    private String jun;
    private String jul;
    private String aug;
    private String sep;
    private String oct;
    private String nov;
    private String deb;
    private String exLibelle;
    private String orgLibelleFr;
    private String orgLibelleUs;

    public VuePTAOperation() {
    }

    public String getPgCode() {
        return pgCode;
    }

    public void setPgCode(String pgCode) {
        this.pgCode = pgCode;
    }

    public String getPgLibelle() {
        return pgLibelle;
    }

    public void setPgLibelle(String pgLibelle) {
        this.pgLibelle = pgLibelle;
    }

    public String getAcCode() {
        return acCode;
    }

    public void setAcCode(String acCode) {
        this.acCode = acCode;
    }

    public String getAcLibelle() {
        return acLibelle;
    }

    public void setAcLibelle(String acLibelle) {
        this.acLibelle = acLibelle;
    }

    public String getTaCode() {
        return taCode;
    }

    public void setTaCode(String taCode) {
        this.taCode = taCode;
    }

    public String getTaLibelle() {
        return taLibelle;
    }

    public void setTaLibelle(String taLibelle) {
        this.taLibelle = taLibelle;
    }

    public String getOpLibelle() {
        return opLibelle;
    }

    public void setOpLibelle(String opLibelle) {
        this.opLibelle = opLibelle;
    }

    public String getIndicateurFr() {
        return indicateurFr;
    }

    public void setIndicateurFr(String indicateurFr) {
        this.indicateurFr = indicateurFr;
    }

    public String getSourceVerificationFr() {
        return sourceVerificationFr;
    }

    public void setSourceVerificationFr(String sourceVerificationFr) {
        this.sourceVerificationFr = sourceVerificationFr;
    }

    public String getStructure() {
        return structure;
    }

    public void setStructure(String structure) {
        this.structure = structure;
    }

    public String getCompteCode() {
        return compteCode;
    }

    public void setCompteCode(String CompteCode) {
        this.compteCode = CompteCode;
    }

    public String getCompteLibelle() {
        return compteLibelle;
    }

    public void setCompteLibelle(String compteLibelle) {
        this.compteLibelle = compteLibelle;
    }

    public String getFinancement() {
        return financement;
    }

    public void setFinancement(String financement) {
        this.financement = financement;
    }

    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getCp() {
        return cp;
    }

    public void setCp(BigDecimal cp) {
        this.cp = cp;
    }

    public String getJan() {
        return jan;
    }

    public void setJan(String jan) {
        this.jan = jan;
    }

    public String getFeb() {
        return feb;
    }

    public void setFeb(String feb) {
        this.feb = feb;
    }

    
    public String getMar() {
        return mar;
    }

    public void setMar(String mar) {
        this.mar = mar;
    }

    public String getApr() {
        return apr;
    }

    public void setApr(String apr) {
        this.apr = apr;
    }

    public String getMay() {
        return may;
    }

    public void setMay(String may) {
        this.may = may;
    }

    

    public String getJun() {
        return jun;
    }

    public void setJun(String jun) {
        this.jun = jun;
    }

    public String getJul() {
        return jul;
    }

    public void setJul(String jul) {
        this.jul = jul;
    }

    public String getAug() {
        return aug;
    }

    public void setAug(String aug) {
        this.aug = aug;
    }

    public String getSep() {
        return sep;
    }

    public void setSep(String sep) {
        this.sep = sep;
    }

    public String getOct() {
        return oct;
    }

    public void setOct(String oct) {
        this.oct = oct;
    }

    public String getNov() {
        return nov;
    }

    public void setNov(String nov) {
        this.nov = nov;
    }

    
    public void setDeb(String Deb) {
        this.deb = Deb;
    }

    public String getDeb() {
        return deb;
    }

    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getOrgLibelleFr() {
        return orgLibelleFr;
    }

    public void setOrgLibelleFr(String orgLibelleFr) {
        this.orgLibelleFr = orgLibelleFr;
    }

    public String getOrgLibelleUs() {
        return orgLibelleUs;
    }

    public void setOrgLibelleUs(String orgLibelleUs) {
        this.orgLibelleUs = orgLibelleUs;
    }
    
    
}
