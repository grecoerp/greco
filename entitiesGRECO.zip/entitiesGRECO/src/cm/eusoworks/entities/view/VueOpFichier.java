/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.math.BigDecimal;

/**
 *
 * @author jeanemmanuel
 */
public class VueOpFichier {

    
    private String compte;
    private String libelleFr;
    private String libelleUs;
    private String indicateur;
    private String sourceVerification;
    private String jan;
    private String fev;
    private String mar;
    private String avr;
    private String mai;
    private String jun;
    private String jul;
    private String aou;
    private String sep;
    private String oct;
    private String nov;
    private String dec;
    
    private BigDecimal ae;
    private BigDecimal cp;
    
    public VueOpFichier() {
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getCp() {
        return cp;
    }

    public void setCp(BigDecimal cp) {
        this.cp = cp;
    }

    public String getIndicateur() {
        return indicateur;
    }

    public void setIndicateur(String indicateur) {
        this.indicateur = indicateur;
    }

    public String getSourceVerification() {
        return sourceVerification;
    }

    public void setSourceVerification(String sourceVerification) {
        this.sourceVerification = sourceVerification;
    }

    public String getJan() {
        return jan;
    }

    public void setJan(String jan) {
        this.jan = jan;
    }

    public String getFev() {
        return fev;
    }

    public void setFev(String fev) {
        this.fev = fev;
    }

    public String getMar() {
        return mar;
    }

    public void setMar(String mar) {
        this.mar = mar;
    }

    public String getAvr() {
        return avr;
    }

    public void setAvr(String avr) {
        this.avr = avr;
    }

    public String getMai() {
        return mai;
    }

    public void setMai(String mai) {
        this.mai = mai;
    }

    public String getJun() {
        return jun;
    }

    public void setJun(String jun) {
        this.jun = jun;
    }

    public String getJul() {
        return jul;
    }

    public void setJul(String jul) {
        this.jul = jul;
    }

    public String getAou() {
        return aou;
    }

    public void setAou(String aou) {
        this.aou = aou;
    }

    public String getSep() {
        return sep;
    }

    public void setSep(String sep) {
        this.sep = sep;
    }

    public String getOct() {
        return oct;
    }

    public void setOct(String oct) {
        this.oct = oct;
    }

    public String getNov() {
        return nov;
    }

    public void setNov(String nov) {
        this.nov = nov;
    }

    public String getDec() {
        return dec;
    }

    public void setDec(String dec) {
        this.dec = dec;
    }
    
    public String getCalendrier() {
        StringBuilder s = new StringBuilder(12);
        s.append(jan.equalsIgnoreCase("x") ? "1" : "0");
        s.append(fev.equalsIgnoreCase("x") ? "1" : "0");
        s.append(mar.equalsIgnoreCase("x") ? "1" : "0");
        s.append(avr.equalsIgnoreCase("x") ? "1" : "0");
        s.append(mai.equalsIgnoreCase("x") ? "1" : "0");
        s.append(jun.equalsIgnoreCase("x") ? "1" : "0");
        s.append(jul.equalsIgnoreCase("x") ? "1" : "0");
        s.append(aou.equalsIgnoreCase("x") ? "1" : "0");
        s.append(sep.equalsIgnoreCase("x") ? "1" : "0");
        s.append(oct.equalsIgnoreCase("x") ? "1" : "0");
        s.append(nov.equalsIgnoreCase("x") ? "1" : "0");
        s.append(dec.equalsIgnoreCase("x") ? "1" : "0");
        return s.toString();
    }
}
