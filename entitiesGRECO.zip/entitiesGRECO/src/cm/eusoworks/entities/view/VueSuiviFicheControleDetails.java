/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;

import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.enumeration.EtatDossier;
import java.awt.Color;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VueSuiviFicheControleDetails  implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private String pgCode;
    private String pgLibelle;
    private String acCode;
    private String acLibelle;
    private String numDossier;
    private Date dateValidation;
    private String objet;
    private String beneficiaire;
    private BigDecimal montantTTC;
    private String typeProcedure;
    private int etat;
    private String statut;
    private String activiteID;
    private String typeBudget;
    private String exMillesime;
    private String exLibelle;
    private String orgCode;
    private String orgLibelleFr;
    private String orgLibelleUs;
    private String taCode;
    private String taLibelle;
    private BigDecimal ae;
    private BigDecimal cp;
    private BigDecimal aerevisee;
    private BigDecimal engagements;
    private BigDecimal disponible;
    private double taux;
    private String compteCode;
    private String compteLibelle;
    private String tacheID;
    private String budgetExploite;
    private BigDecimal file;
    private String numOrdre;
    private Date dateEntree;

    public String getPgCode() {
        return pgCode;
    }

    public void setPgCode(String pgCode) {
        this.pgCode = pgCode;
    }

    public String getPgLibelle() {
        return pgLibelle;
    }

    public void setPgLibelle(String pgLibelle) {
        this.pgLibelle = pgLibelle;
    }

    public String getAcCode() {
        return acCode;
    }

    public void setAcCode(String acCode) {
        this.acCode = acCode;
    }

    public String getAcLibelle() {
        return acLibelle;
    }

    public void setAcLibelle(String acLibelle) {
        this.acLibelle = acLibelle;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public Date getDateValidation() {
        return dateValidation;
    }

    public void setDateValidation(Date dateValidation) {
        this.dateValidation = dateValidation;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public String getTypeProcedure() {
        return typeProcedure;
    }

    public void setTypeProcedure(String typeProcedure) {
        this.typeProcedure = typeProcedure;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public String getStatut() {
        return EtatDossier.getString(etat);
    }

    public void setStatut(String statut) {
        this.statut = statut;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getTypeBudget() {
        return typeBudget;
    }

    public void setTypeBudget(String typeBudget) {
        this.typeBudget = typeBudget;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrgLibelleFr() {
        return orgLibelleFr;
    }

    public void setOrgLibelleFr(String orgLibelleFr) {
        this.orgLibelleFr = orgLibelleFr;
    }

    public String getOrgLibelleUs() {
        return orgLibelleUs;
    }

    public void setOrgLibelleUs(String orgLibelleUs) {
        this.orgLibelleUs = orgLibelleUs;
    }

    public String getTaCode() {
        return taCode;
    }

    public void setTaCode(String taCode) {
        this.taCode = taCode;
    }

    public String getTaLibelle() {
        return taLibelle;
    }

    public void setTaLibelle(String taLibelle) {
        this.taLibelle = taLibelle;
    }

    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getCp() {
        return cp;
    }

    public void setCp(BigDecimal cp) {
        this.cp = cp;
    }

    public BigDecimal getAerevisee() {
        return aerevisee;
    }

    public void setAerevisee(BigDecimal aerevisee) {
        this.aerevisee = aerevisee;
    }

    public BigDecimal getEngagements() {
        return engagements;
    }

    public void setEngagements(BigDecimal engagements) {
        this.engagements = engagements;
    }

    public BigDecimal getDisponible() {
        return disponible;
    }

    public void setDisponible(BigDecimal disponible) {
        this.disponible = disponible;
    }

    public double getTaux() {
        return taux;
    }

    public void setTaux(double taux) {
        this.taux = taux;
    }

    public String getCompteCode() {
        return compteCode;
    }

    public void setCompteCode(String compteCode) {
        this.compteCode = compteCode;
    }

    public String getCompteLibelle() {
        return compteLibelle;
    }

    public void setCompteLibelle(String compteLibelle) {
        this.compteLibelle = compteLibelle;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getBudgetExploite() {
        String be = "";
        if (budgetExploite.equals(BudgetType.ETAT_REPORT)) {
                be = "(R)  ";
            } else if (budgetExploite.equals(BudgetType.ETAT_INITIAL)) {
                be = "       ";
            } else if (budgetExploite.equals(BudgetType.ETAT_ADDITIF)) {
                be = "(A)  ";
            }
        return be;
    }

    public void setBudgetExploite(String budgetExploite) {
        this.budgetExploite = budgetExploite;
    }

    public BigDecimal getFile() {
        return file;
    }

    public void setFile(BigDecimal file) {
        this.file = file;
    }

    public String getNumOrdre() {
        return numDossier;
    }

    public void setNumOrdre(String numOrdre) {
        this.numDossier = numOrdre;
    }

    public Date getDateEntree() {
        return dateValidation;
    }

    public void setDateEntree(Date dateEntree) {
        this.dateValidation = dateEntree;
    }

    
    
}
