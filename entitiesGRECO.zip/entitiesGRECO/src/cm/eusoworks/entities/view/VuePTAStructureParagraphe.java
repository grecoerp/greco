/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author cwam
 */
public class VuePTAStructureParagraphe implements Serializable {

    private static final long serialVersionUID = 1L;
    private String exMillesime;
    private String exLibelle;
    private Integer annee;
    private String chCodeChapitre;
    private String chAbreviation;
    private String chLibelle;
    private String fsCode;
    private String fsAbreviation;
    private String fsLibelle;
    private String caCode;
    private String caAbreviation;
    private String caLibelle;
    private String arCodeArticle;
    private String reCode;
    private String arNumOrdre;
    private String arAbreviation;
    private String arLibelle;
    private String typeDepense;
    private String libelleDepense;
    private String neCodeNatureEco;
    private String neLibelle;
    private String geCode;
    private String geLibelle;
    private String coCode;
    private String coLibelle;
    private BigDecimal AE;
    private BigDecimal CP;
    private String imputation;
    private BigDecimal dotationBase;
    private Integer anneePrec;

    public BigDecimal getAE() {
        return AE;
    }

    public void setAE(BigDecimal AE) {
        this.AE = AE;
    }

    public BigDecimal getCP() {
        return CP;
    }

    public void setCP(BigDecimal CP) {
        this.CP = CP;
    }

    public Integer getAnnee() {
        return annee;
    }

    public void setAnnee(Integer annee) {
        this.annee = annee;
    }

    public Integer getAnneePrec() {
        return anneePrec;
    }

    public void setAnneePrec(Integer anneePrec) {
        this.anneePrec = anneePrec;
    }

    public String getArAbreviation() {
        return arAbreviation;
    }

    public void setArAbreviation(String arAbreviation) {
        this.arAbreviation = arAbreviation;
    }

    public String getArCodeArticle() {
        return arCodeArticle;
    }

    public void setArCodeArticle(String arCodeArticle) {
        this.arCodeArticle = arCodeArticle;
    }

    public String getArLibelle() {
        return arLibelle;
    }

    public void setArLibelle(String arLibelle) {
        this.arLibelle = arLibelle;
    }

    public String getArNumOrdre() {
        return arNumOrdre;
    }

    public void setArNumOrdre(String arNumOrdre) {
        this.arNumOrdre = arNumOrdre;
    }

    public String getCaAbreviation() {
        return caAbreviation;
    }

    public void setCaAbreviation(String caAbreviation) {
        this.caAbreviation = caAbreviation;
    }

    public String getCaCode() {
        return caCode;
    }

    public void setCaCode(String caCode) {
        this.caCode = caCode;
    }

    public String getCaLibelle() {
        return caLibelle;
    }

    public void setCaLibelle(String caLibelle) {
        this.caLibelle = caLibelle;
    }

    public String getChAbreviation() {
        return chAbreviation;
    }

    public void setChAbreviation(String chAbreviation) {
        this.chAbreviation = chAbreviation;
    }

    public String getChCodeChapitre() {
        return chCodeChapitre;
    }

    public void setChCodeChapitre(String chCodeChapitre) {
        this.chCodeChapitre = chCodeChapitre;
    }

    public String getChLibelle() {
        return chLibelle;
    }

    public void setChLibelle(String chLibelle) {
        this.chLibelle = chLibelle;
    }

    public String getCoCode() {
        return coCode;
    }

    public void setCoCode(String coCode) {
        this.coCode = coCode;
    }

    public String getCoLibelle() {
        return coLibelle;
    }

    public void setCoLibelle(String coLibelle) {
        this.coLibelle = coLibelle;
    }

    public BigDecimal getDotationBase() {
        return dotationBase;
    }

    public void setDotationBase(BigDecimal dotationBase) {
        this.dotationBase = dotationBase;
    }

    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getFsAbreviation() {
        return fsAbreviation;
    }

    public void setFsAbreviation(String fsAbreviation) {
        this.fsAbreviation = fsAbreviation;
    }

    public String getFsCode() {
        return fsCode;
    }

    public void setFsCode(String fsCode) {
        this.fsCode = fsCode;
    }

    public String getFsLibelle() {
        return fsLibelle;
    }

    public void setFsLibelle(String fsLibelle) {
        this.fsLibelle = fsLibelle;
    }

    public String getGeCode() {
        return geCode;
    }

    public void setGeCode(String geCode) {
        this.geCode = geCode;
    }

    public String getGeLibelle() {
        return geLibelle;
    }

    public void setGeLibelle(String geLibelle) {
        this.geLibelle = geLibelle;
    }

    public String getImputation() {
        return imputation;
    }

    public void setImputation(String imputation) {
        this.imputation = imputation;
    }

    public String getLibelleDepense() {
        return libelleDepense;
    }

    public void setLibelleDepense(String libelleDepense) {
        this.libelleDepense = libelleDepense;
    }

    public String getNeCodeNatureEco() {
        return neCodeNatureEco;
    }

    public void setNeCodeNatureEco(String neCodeNatureEco) {
        this.neCodeNatureEco = neCodeNatureEco;
    }

    public String getNeLibelle() {
        return neLibelle;
    }

    public void setNeLibelle(String neLibelle) {
        this.neLibelle = neLibelle;
    }

    public String getReCode() {
        return reCode;
    }

    public void setReCode(String reCode) {
        this.reCode = reCode;
    }

    public String getTypeDepense() {
        return typeDepense;
    }

    public void setTypeDepense(String typeDepense) {
        this.typeDepense = typeDepense;
    }

}
