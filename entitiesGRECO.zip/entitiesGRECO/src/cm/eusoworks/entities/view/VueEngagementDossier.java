/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VueEngagementDossier implements Serializable {

    private static final long serialVersionUID = 1L;

    private int type;
    private String engagementID;
    private String numDossier;
    private String objet;
    private String beneficiaire;
    private String compte;
    private BigDecimal montant;
    private int etatID;
    private boolean check;
    private String motifAnnulationOrdo;
    private String motifAnnulationCF;
    private Date dateAnnulation;
    private BigDecimal montantTVA;
    private BigDecimal montantNAP;
    private BigDecimal montantHT;
    private double tauxTVA;
    private double tauxIR;
    private String bcaID;
    private String omID;
    private String decisionID;
    private String lettreCommandeID;
    private String marcheID;
    private String millesime;
    private String organisationID;
    private String numeroOP;
    private BigDecimal montantRAL;
    
    /*********************************************/
    private String structureID;
    private String tacheID;
    private String activiteID;
    private String fournisseurID;
    private String matricule;
    private String tacheLibelle;
    private String activiteLibelle;
    private String structureLibelle;
    // proprietes file d'attente
    private String numeroOPNet;
    private String numeroOPTaxe;
    private BigDecimal montantNet;
    private BigDecimal montantTaxe;
    private String codeTache;
    private String reference;
    
    private String updateUser;
    private Date updateLastDate;

    public VueEngagementDossier() {
    }

    public String getEngagementID() {
        return engagementID;
    }

    public void setEngagementID(String engagementID) {
        this.engagementID = engagementID;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    public int getType() {
        return type;
    }

    public boolean isCheck() {
        return check;
    }

    public void setCheck(boolean check) {
        this.check = check;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getEtatDossier() {
        return EtatDossier.getString(etatID).toUpperCase();
    }

    public int getEtatID() {
        return etatID;
    }

    public void setEtatID(int etatID) {
        this.etatID = etatID;
    }

    public String getMotifAnnulationOrdo() {
        return motifAnnulationOrdo;
    }

    public void setMotifAnnulationOrdo(String motifAnnulationOrdo) {
        this.motifAnnulationOrdo = motifAnnulationOrdo;
    }

    public String getMotifAnnulationCF() {
        return motifAnnulationCF;
    }

    public void setMotifAnnulationCF(String motifAnnulationCF) {
        this.motifAnnulationCF = motifAnnulationCF;
    }

    public Date getDateAnnulation() {
        return dateAnnulation;
    }

    public void setDateAnnulation(Date dateAnnulation) {
        this.dateAnnulation = dateAnnulation;
    }

    public BigDecimal getMontantTVA() {
        return montantTVA;
    }

    public void setMontantTVA(BigDecimal montantTVA) {
        this.montantTVA = montantTVA;
    }

    public BigDecimal getMontantNAP() {
        return montantNAP;
    }

    public void setMontantNAP(BigDecimal montantNAP) {
        this.montantNAP = montantNAP;
    }

    public BigDecimal getMontantHT() {
        return montantHT;
    }

    public void setMontantHT(BigDecimal montantHT) {
        this.montantHT = montantHT;
    }

    public double getTauxTVA() {
        return tauxTVA;
    }

    public void setTauxTVA(double tauxTVA) {
        this.tauxTVA = tauxTVA;
    }

    public double getTauxIR() {
        return tauxIR;
    }

    public void setTauxIR(double tauxIR) {
        this.tauxIR = tauxIR;
    }

    public String getBcaID() {
        return bcaID;
    }

    public void setBcaID(String bcaID) {
        this.bcaID = bcaID;
    }

    public String getOmID() {
        return omID;
    }

    public void setOmID(String omID) {
        this.omID = omID;
    }

    public String getDecisionID() {
        return decisionID;
    }

    public void setDecisionID(String decisionID) {
        this.decisionID = decisionID;
    }

    public String getLettreCommandeID() {
        return lettreCommandeID;
    }

    public void setLettreCommandeID(String lettreCommandeID) {
        this.lettreCommandeID = lettreCommandeID;
    }

    public String getMarcheID() {
        return marcheID;
    }

    public void setMarcheID(String marcheID) {
        this.marcheID = marcheID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getNumeroOP() {
        return numeroOP;
    }

    public void setNumeroOP(String numeroOP) {
        this.numeroOP = numeroOP;
    }

    public BigDecimal getMontantRAL() {
        return montantRAL;
    }

    public void setMontantRAL(BigDecimal montantRAL) {
        this.montantRAL = montantRAL;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getFournisseurID() {
        return fournisseurID;
    }

    public void setFournisseurID(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getTacheLibelle() {
        return tacheLibelle;
    }

    public void setTacheLibelle(String tacheLibelle) {
        this.tacheLibelle = tacheLibelle;
    }

    public String getActiviteLibelle() {
        return activiteLibelle;
    }

    public void setActiviteLibelle(String activiteLibelle) {
        this.activiteLibelle = activiteLibelle;
    }

    public String getStructureLibelle() {
        return structureLibelle;
    }

    public void setStructureLibelle(String structureLibelle) {
        this.structureLibelle = structureLibelle;
    }

    public String getNumeroOPNet() {
        return numeroOPNet;
    }

    public void setNumeroOPNet(String numeroOPNet) {
        this.numeroOPNet = numeroOPNet;
    }

    public String getNumeroOPTaxe() {
        return numeroOPTaxe;
    }

    public void setNumeroOPTaxe(String numeroOPTaxe) {
        this.numeroOPTaxe = numeroOPTaxe;
    }

    public BigDecimal getMontantNet() {
        return montantNet;
    }

    public void setMontantNet(BigDecimal montantNet) {
        this.montantNet = montantNet;
    }

    public BigDecimal getMontantTaxe() {
        return montantTaxe;
    }

    public void setMontantTaxe(BigDecimal montantTaxe) {
        this.montantTaxe = montantTaxe;
    }

    public String getCodeTache() {
        return codeTache;
    }

    public void setCodeTache(String codeTache) {
        this.codeTache = codeTache;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getUpdateUser() {
        return updateUser;
    }

    public void setUpdateUser(String updateUser) {
        this.updateUser = updateUser;
    }

    public Date getUpdateLastDate() {
        return updateLastDate;
    }

    public void setUpdateLastDate(Date updateLastDate) {
        this.updateLastDate = updateLastDate;
    }

    
}
