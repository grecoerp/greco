/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */

public class VueLiquidationReport implements Serializable{

    private static final long serialVersionUID = 1L;
    private String organisationFR;
    private String organisationUS;
    private String exerciceLibelleFr;
    private String chapitre;
    private BigDecimal dotationBudgetaire;
    private BigDecimal totalEngag;
    private BigDecimal disponible;
    private BigDecimal depenseCourante;
    private BigDecimal solde;
    private String sourceFinancement;

    private String matriculeOrdo;
    private String nomOrdo;
    private String moisEmission;
    private String exerciceOrigine;
    private String numBordereauEmission;
    private String numMandat;
    private String objet;
    private String beneficiare;
    private BigDecimal montantOrdonnance;
    private BigDecimal precompte;
    private BigDecimal netApayer;
    private String piecesJustificatives;
    private String banque;
    private String agence;
    private String numCompte;

    public String getOrganisationFR() {
        return organisationFR;
    }

    public BigDecimal getMontantOrdonnance() {
        return montantOrdonnance;
    }

    public void setMontantOrdonnance(BigDecimal montantOrdonnance) {
        this.montantOrdonnance = montantOrdonnance;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public void setOrganisationFR(String organisationFR) {
        this.organisationFR = organisationFR;
    }

    public String getOrganisationUS() {
        return organisationUS;
    }

    public void setOrganisationUS(String organisationUS) {
        this.organisationUS = organisationUS;
    }

    public String getExerciceLibelleFr() {
        return exerciceLibelleFr;
    }

    public void setExerciceLibelleFr(String exerciceLibelleFr) {
        this.exerciceLibelleFr = exerciceLibelleFr;
    }

    public String getChapitre() {
        return chapitre;
    }

    public void setChapitre(String chapitre) {
        this.chapitre = chapitre;
    }

    public BigDecimal getDotationBudgetaire() {
        return dotationBudgetaire;
    }

    public void setDotationBudgetaire(BigDecimal dotationBudgetaire) {
        this.dotationBudgetaire = dotationBudgetaire;
    }

    public BigDecimal getTotalEngag() {
        return totalEngag;
    }

    public void setTotalEngag(BigDecimal totalEngag) {
        this.totalEngag = totalEngag;
    }

    public BigDecimal getDisponible() {
        return disponible;
    }

    public void setDisponible(BigDecimal disponible) {
        this.disponible = disponible;
    }

    public BigDecimal getDepenseCourante() {
        return depenseCourante;
    }

    public void setDepenseCourante(BigDecimal depenseCourante) {
        this.depenseCourante = depenseCourante;
    }

    public BigDecimal getSolde() {
        return solde;
    }

    public void setSolde(BigDecimal solde) {
        this.solde = solde;
    }

    public String getSourceFinancement() {
        return sourceFinancement;
    }

    public void setSourceFinancement(String sourceFinancement) {
        this.sourceFinancement = sourceFinancement;
    }

    public String getMatriculeOrdo() {
        return matriculeOrdo;
    }

    public void setMatriculeOrdo(String matriculeOrdo) {
        this.matriculeOrdo = matriculeOrdo;
    }

    public String getNomOrdo() {
        return nomOrdo;
    }

    public void setNomOrdo(String nomOrdo) {
        this.nomOrdo = nomOrdo;
    }

    public String getMoisEmission() {
        return moisEmission;
    }

    public void setMoisEmission(String moisEmission) {
        this.moisEmission = moisEmission;
    }

    public String getExerciceOrigine() {
        return exerciceOrigine;
    }

    public void setExerciceOrigine(String exerciceOrigine) {
        this.exerciceOrigine = exerciceOrigine;
    }

    public String getNumBordereauEmission() {
        return numBordereauEmission;
    }

    public void setNumBordereauEmission(String numBordereauEmission) {
        this.numBordereauEmission = numBordereauEmission;
    }

    public String getNumMandat() {
        return numMandat;
    }

    public void setNumMandat(String numMandat) {
        this.numMandat = numMandat;
    }

    public String getBeneficiare() {
        return beneficiare;
    }

    public void setBeneficiare(String beneficiare) {
        this.beneficiare = beneficiare;
    }

    public BigDecimal getPrecompte() {
        return precompte;
    }

    public void setPrecompte(BigDecimal precompte) {
        this.precompte = precompte;
    }

    public BigDecimal getNetApayer() {
        return netApayer;
    }

    public void setNetApayer(BigDecimal netApayer) {
        this.netApayer = netApayer;
    }

    public String getPiecesJustificatives() {
        return piecesJustificatives;
    }

    public void setPiecesJustificatives(String piecesJustificatives) {
        this.piecesJustificatives = piecesJustificatives;
    }

    public String getBanque() {
        return banque;
    }

    public void setBanque(String banque) {
        this.banque = banque;
    }

    public String getAgence() {
        return agence;
    }

    public void setAgence(String agence) {
        this.agence = agence;
    }

    public String getNumCompte() {
        return numCompte;
    }

    public void setNumCompte(String numCompte) {
        this.numCompte = numCompte;
    }
    
    

}
