/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.util.Locale;

/**
 *
 * @author ouethy
 */
public class VueEntiteReduit implements Serializable {

    private static final long serialVersionUID = 1L;

    private String id;
    private String code;
    private String libelleFr;
    private String libelleUs;
    private String ocag;
    private boolean checked;
    private boolean ordonnateur;
    private boolean controleur;
    private boolean comptable;
    private boolean gestion;
    private int intValue;

    public VueEntiteReduit() {
    }


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getOcag() {
        return (ordonnateur?"1":"0")+(controleur?"1":"0")+(comptable?"1":"0")+(gestion?"1":"0");
    }

    public void setOcag(String ocag) {
        this.ocag = ocag;
        if(ocag.substring(0, 1).equalsIgnoreCase("1")) setOrdonnateur(true);
        if(ocag.substring(1, 2).equalsIgnoreCase("1")) setControleur(true);
        if(ocag.substring(2, 3).equalsIgnoreCase("1")) setComptable(true);
        if(ocag.substring(3, 4).equalsIgnoreCase("1")) setGestion(true);
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public boolean isOrdonnateur() {
        return ordonnateur;
    }

    public void setOrdonnateur(boolean ordonnateur) {
        this.ordonnateur = ordonnateur;
    }

    public boolean isControleur() {
        return controleur;
    }

    public void setControleur(boolean controleur) {
        this.controleur = controleur;
    }

    public boolean isComptable() {
        return comptable;
    }

    public void setComptable(boolean comptable) {
        this.comptable = comptable;
    }

    public boolean isGestion() {
        return gestion;
    }

    public void setGestion(boolean gestion) {
        this.gestion = gestion;
    }
    
    public String getLibelle(){
        if(Locale.getDefault() == Locale.FRENCH) return (code==null?""+getLibelleFr():code+ " - "+getLibelleFr()) ;
        else return (code==null?""+getLibelleUs():code+ " - "+getLibelleUs()) ;
    }

    public int getIntValue() {
        return intValue;
    }

    public void setIntValue(int intValue) {
        this.intValue = intValue;
    }

    @Override
    public String toString() {
        return getLibelle();
    }

}
