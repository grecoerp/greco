/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VueMissionFiche implements Serializable {

    private static final long serialVersionUID = 1L;

    private String orgCode;
    private String orgLibelle;
    private String exMillesime;
    private String exLibelle;
    private String matricule;
    private String beneficiaire;
    private String budget;
    private String code;
    private String libelleFr;
    private String destination;
    private String compteCode;
    private String imputation;
    private String numDossier;
    private String status;
    private int etat;
    private int nbJours;
    private int typeMission;
    private BigDecimal montantGlobal;
    private Date dateDepart;
    private Date dateRetour;
    
    public VueMissionFiche() {
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrgLibelle() {
        return orgLibelle;
    }

    public void setOrgLibelle(String orgLibelle) {
        this.orgLibelle = orgLibelle;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public String getBudget() {
        return budget;
    }

    public void setBudget(String budget) {
        this.budget = budget;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getCompteCode() {
        return compteCode;
    }

    public void setCompteCode(String compteCode) {
        this.compteCode = compteCode;
    }

    

    public String getImputation() {
        return imputation;
    }

    public void setImputation(String imputation) {
        this.imputation = imputation;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public String getStatus() {
        return EtatDossier.getString(etat);
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public int getNbJours() {
        return nbJours;
    }

    public void setNbJours(int nbJours) {
        this.nbJours = nbJours;
    }

    public int getTypeMission() {
        return typeMission;
    }

    public void setTypeMission(int typeMission) {
        this.typeMission = typeMission;
    }

    public BigDecimal getMontantGlobal() {
        return montantGlobal;
    }

    public void setMontantGlobal(BigDecimal montantGlobal) {
        this.montantGlobal = montantGlobal;
    }

    public Date getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(Date dateDepart) {
        this.dateDepart = dateDepart;
    }

    public Date getDateRetour() {
        return dateRetour;
    }

    public void setDateRetour(Date dateRetour) {
        this.dateRetour = dateRetour;
    }

    
}
