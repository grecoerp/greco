/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class VuePTAParagraphe implements Serializable {
    
    private static final long serialVersionUID = 1L;
    private String artCode;
    private String artLibelle;
    private String sfAbbreviation;
    private String sfLibelle;
    private String compteCode;
    private String compteLibelle;
    private String chapCode;
    private String chapLibelle;
    private BigDecimal ae;
    private BigDecimal cp;
    private String exLibelle;
    private String orgLibelleFr;
    private String orgLibelleUs;

    public VuePTAParagraphe() {
    }

    public String getArtCode() {
        return artCode;
    }

    public void setArtCode(String artCode) {
        this.artCode = artCode;
    }

    public String getArtLibelle() {
        return artLibelle;
    }

    public void setArtLibelle(String artLibelle) {
        this.artLibelle = artLibelle;
    }

    public String getSfAbbreviation() {
        return sfAbbreviation;
    }

    public void setSfAbbreviation(String sfAbbreviation) {
        this.sfAbbreviation = sfAbbreviation;
    }

    public String getSfLibelle() {
        return sfLibelle;
    }

    public void setSfLibelle(String sfLibelle) {
        this.sfLibelle = sfLibelle;
    }

    
    public String getCompteCode() {
        return compteCode;
    }

    public void setCompteCode(String CompteCode) {
        this.compteCode = CompteCode;
    }

    public String getCompteLibelle() {
        return compteLibelle;
    }

    public void setCompteLibelle(String compteLibelle) {
        this.compteLibelle = compteLibelle;
    }

   
    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getCp() {
        return cp;
    }

    public void setCp(BigDecimal cp) {
        this.cp = cp;
    }

    public String getChapCode() {
        return chapCode;
    }

    public void setChapCode(String chapCode) {
        this.chapCode = chapCode;
    }

    public String getChapLibelle() {
        return chapLibelle;
    }

    public void setChapLibelle(String chapLibelle) {
        this.chapLibelle = chapLibelle;
    }

    
    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getOrgLibelleFr() {
        return orgLibelleFr;
    }

    public void setOrgLibelleFr(String orgLibelleFr) {
        this.orgLibelleFr = orgLibelleFr;
    }

    public String getOrgLibelleUs() {
        return orgLibelleUs;
    }

    public void setOrgLibelleUs(String orgLibelleUs) {
        this.orgLibelleUs = orgLibelleUs;
    }
    
    
}
