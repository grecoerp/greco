/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class VueSuiviFicheControle  implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private String activiteID;
    private String typeBudget;
    private String exMillesime;
    private String exLibelle;
    private String orgCode;
    private String orgLibelle;
    private String atCode;
    private String atLibelle;
    private BigDecimal ae;
    private BigDecimal aerevisee;
    private BigDecimal engagements;
    private BigDecimal disponible;
    private double taux;
    private String compte;
    private String compteLibelle;

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getTypeBudget() {
        return typeBudget;
    }

    public void setTypeBudget(String typeBudget) {
        this.typeBudget = typeBudget;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getExLibelle() {
        return exLibelle;
    }

    public void setExLibelle(String exLibelle) {
        this.exLibelle = exLibelle;
    }

    public String getOrgCode() {
        return orgCode;
    }

    public void setOrgCode(String orgCode) {
        this.orgCode = orgCode;
    }

    public String getOrgLibelle() {
        return orgLibelle;
    }

    public void setOrgLibelle(String orgLibelle) {
        this.orgLibelle = orgLibelle;
    }

    public String getAtCode() {
        return atCode;
    }

    public void setAtCode(String atCode) {
        this.atCode = atCode;
    }

    public String getAtLibelle() {
        return atLibelle;
    }

    public void setAtLibelle(String atLibelle) {
        this.atLibelle = atLibelle;
    }

    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getAerevisee() {
        return aerevisee;
    }

    public void setAerevisee(BigDecimal aerevisee) {
        this.aerevisee = aerevisee;
    }

    public BigDecimal getEngagements() {
        return engagements;
    }

    public void setEngagements(BigDecimal engagements) {
        this.engagements = engagements;
    }

    public BigDecimal getDisponible() {
        return disponible;
    }

    public void setDisponible(BigDecimal disponible) {
        this.disponible = disponible;
    }

    public double getTaux() {
        return taux;
    }

    public void setTaux(double taux) {
        this.taux = taux;
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public String getCompteLibelle() {
        return compteLibelle;
    }

    public void setCompteLibelle(String compteLibelle) {
        this.compteLibelle = compteLibelle;
    }
    
    
}
