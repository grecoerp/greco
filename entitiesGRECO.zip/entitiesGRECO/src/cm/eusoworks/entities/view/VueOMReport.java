/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author ouethy
 */
public class VueOMReport implements Serializable {

    private static final long serialVersionUID = 1L;
    private String ordreDeMission;
    private String matriculeAgent;
    private String situationMatAgent;
    private String destinationMission;
    private String passantParMission;
    private String motifEtReferenceMission;
    private String moyenDeTransportMission;
    private String accompagnantMission;
    private Date dateDepartMission;
    private Date dateRetourMission;
    private String exMillesime;
    private String exLibelleFrancais;
    private String chLibelleAnglais;
    private String chLibelleFrancais;
    private String nomAgent;
    private String prenomAgent;
    private String nomJeuneFilleAgent;

    public VueOMReport() {
    }

    public String getOrdreDeMission() {
        return ordreDeMission;
    }

    public void setOrdreDeMission(String ordreDeMission) {
        this.ordreDeMission = ordreDeMission;
    }

    public String getMatriculeAgent() {
        return matriculeAgent;
    }

    public void setMatriculeAgent(String matriculeAgent) {
        this.matriculeAgent = matriculeAgent;
    }

    public String getSituationMatAgent() {
        return situationMatAgent;
    }

    public void setSituationMatAgent(String situationMatAgent) {
        this.situationMatAgent = situationMatAgent;
    }

    public String getDestinationMission() {
        return destinationMission;
    }

    public void setDestinationMission(String destinationMission) {
        this.destinationMission = destinationMission;
    }

    public String getPassantParMission() {
        return passantParMission;
    }

    public void setPassantParMission(String passantParMission) {
        this.passantParMission = passantParMission;
    }

    public String getMotifEtReferenceMission() {
        return motifEtReferenceMission;
    }

    public void setMotifEtReferenceMission(String motifEtReferenceMission) {
        this.motifEtReferenceMission = motifEtReferenceMission;
    }

    public String getMoyenDeTransportMission() {
        return moyenDeTransportMission;
    }

    public void setMoyenDeTransportMission(String moyenDeTransportMission) {
        this.moyenDeTransportMission = moyenDeTransportMission;
    }

    public String getAccompagnantMission() {
        return accompagnantMission;
    }

    public void setAccompagnantMission(String accompagnantMission) {
        this.accompagnantMission = accompagnantMission;
    }

    public Date getDateDepartMission() {
        return dateDepartMission;
    }

    public void setDateDepartMission(Date dateDepartMission) {
        this.dateDepartMission = dateDepartMission;
    }

    public Date getDateRetourMission() {
        return dateRetourMission;
    }

    public void setDateRetourMission(Date dateRetourMission) {
        this.dateRetourMission = dateRetourMission;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    public String getExLibelleFrancais() {
        return exLibelleFrancais;
    }

    public void setExLibelleFrancais(String exLibelleFrancais) {
        this.exLibelleFrancais = exLibelleFrancais;
    }

    public String getChLibelleAnglais() {
        return chLibelleAnglais;
    }

    public void setChLibelleAnglais(String chLibelleAnglais) {
        this.chLibelleAnglais = chLibelleAnglais;
    }

    public String getChLibelleFrancais() {
        return chLibelleFrancais;
    }

    public void setChLibelleFrancais(String chLibelleFrancais) {
        this.chLibelleFrancais = chLibelleFrancais;
    }

    public String getNomAgent() {
        return nomAgent;
    }

    public void setNomAgent(String nomAgent) {
        this.nomAgent = nomAgent;
    }

    public String getPrenomAgent() {
        return prenomAgent;
    }

    public void setPrenomAgent(String prenomAgent) {
        this.prenomAgent = prenomAgent;
    }

    public String getNomJeuneFilleAgent() {
        return nomJeuneFilleAgent;
    }

    public void setNomJeuneFilleAgent(String nomJeuneFilleAgent) {
        this.nomJeuneFilleAgent = nomJeuneFilleAgent;
    }
    
    
    
}
