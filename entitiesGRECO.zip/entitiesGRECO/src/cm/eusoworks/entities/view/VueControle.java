/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;

/**
 *
 * @author ouethy
 */
public class VueControle implements Serializable {

    private static final long serialVersionUID = 1L;

    public static final int SUCCESS = 1;
    public static final int ECHEC = 2;
    public static final int WARNING = 3;
    
    
    private String observations;
    private String libelle;
    private int result;
    private boolean checked;
    private String motifLevee;
    private int numeroControle = -1;

    public VueControle(String libelle, String observations, int result) {
        this.libelle = libelle;
        this.observations = observations;
        this.result = result;
    }
    public VueControle() {
        this("","",2);
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public int getResult() {
        return result;
    }

    public void setResult(int result) {
        this.result = result;
    }

    public boolean isSuccess(){
        return this.result == SUCCESS;
    }
    
    public boolean isEchec(){
        return this.result == ECHEC;
    }
    
    public boolean isWarning(){
        return this.result == WARNING;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public String getMotifLevee() {
        return motifLevee;
    }

    public void setMotifLevee(String motifLevee) {
        this.motifLevee = motifLevee;
    }

    public int getNumeroControle() {
        return numeroControle;
    }

    public void setNumeroControle(int numeroControle) {
        this.numeroControle = numeroControle;
    }


}
