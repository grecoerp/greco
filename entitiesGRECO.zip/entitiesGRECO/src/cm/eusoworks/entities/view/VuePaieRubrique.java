/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.view;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author ouethy
 */
public class VuePaieRubrique implements Serializable {

    private static final long serialVersionUID = 1L;

    String rubrique;
    double base;
    float taux;
    BigDecimal adeduire;
    BigDecimal apayer;
    float tauxPatronal;
    BigDecimal chargePatronale;

    public VuePaieRubrique() {
    }

    public String getRubrique() {
        return rubrique;
    }

    public void setRubrique(String rubrique) {
        this.rubrique = rubrique;
    }

    public double getBase() {
        return base;
    }

    public void setBase(double base) {
        this.base = base;
    }

    public float getTaux() {
        return taux;
    }

    public void setTaux(float taux) {
        this.taux = taux;
    }

    public BigDecimal getAdeduire() {
        return adeduire;
    }

    public void setAdeduire(BigDecimal adeduire) {
        this.adeduire = adeduire;
    }

    public BigDecimal getApayer() {
        return apayer;
    }

    public void setApayer(BigDecimal apayer) {
        this.apayer = apayer;
    }

    public float getTauxPatronal() {
        return tauxPatronal;
    }

    public void setTauxPatronal(float tauxPatronal) {
        this.tauxPatronal = tauxPatronal;
    }

    public BigDecimal getChargePatronale() {
        return chargePatronale;
    }

    public void setChargePatronale(BigDecimal chargePatronale) {
        this.chargePatronale = chargePatronale;
    }

    
}
