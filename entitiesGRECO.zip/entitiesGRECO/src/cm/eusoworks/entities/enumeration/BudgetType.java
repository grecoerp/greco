/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.enumeration;

/**
 *
 * @author ouethy
 */
public class BudgetType {

    public static final int INITIAL = 1;
    public static final int REPORT = 0;
    public static final int ADDITIF = 2; //retour a modifie
    public static final int COLLECTIF = 3; //retour a modifie
    
    public static String ETAT_REPORT = "10000";
    public static String ETAT_INITIAL = "01000";
    public static String ETAT_ADDITIF = "00100";
    public static String ETAT_INITIAL_ADDITIF = "00010";
    public static String ETAT_ALL_BUDGET = "00001";
    
}
