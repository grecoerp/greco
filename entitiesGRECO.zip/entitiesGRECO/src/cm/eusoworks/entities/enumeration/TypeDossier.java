/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.enumeration;

/**
 *
 * @author ouethy
 */
public class TypeDossier {

    public static String BON_COMMANDE = "1";
    public static String LETTRE_COMMANDE = "2";
    public static String MARCHE = "3";
    public static String MISSION = "4";
    public static String MISE_A_DISPOSITION = "5";
    
    public static String getLibelleType(String typeID){
        if(typeID.equals("1")) return "BON COMMANDE";
        else if(typeID.equals("2")) return "LETTRE COMMANDE";
        else if(typeID.equals("3")) return "MARCHE";
        else if(typeID.equals("4")) return "ORDRE DE MISSION";
        else if(typeID.equals("5")) return "DECISION";
        else return "DEPENSES";
    }
    
}
