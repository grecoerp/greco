/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.enumeration;

/**
 *
 * @author ouethy
 */
public class EtatDossier {

    public static final int enregistre = 10;
    public static final int modifie = 20;
    public static final int reservation_annule = 30; //retour a modifie
    public static final int reserve = 40;
    public static final int rejeteCF_Visa = 50;
    public static final int transmiCF_annule = 60; // retour a reserver
    public static final int transmiCF = 70;
    
    public static final int receptionneCF = 80;
    public static final int valide = 90;
    public static final int transmiPourLiquidation_annule = 100; // retour a controle de conformite
    public static final int transmiPourLiquidation = 110;
    
    public static final int receptionneLiquidation = 120;
    public static final int liquide_enregistre = 130;
    public static final int liquide_partielle = 140;
    public static final int liquide_validation = 150;
    public static final int mandate = 160;
    public static final int rejetCF_regularite = 170;
    public static final int transmiPourRegularite_annule = 180; // retour a mandate
    public static final int transmiPourRegularite = 190;
    
    public static final int receptionneRegularite = 200;
    public static final int valideRegularite = 210;
    public static final int rejetAC_PriseEnCharge = 220;
    public static final int transmiAuComptable_annule = 230; // retour au controle de regularite
    public static final int transmiAuComptable = 240;
    
    public static final int receptionneComptable = 250;
    public static final int prisEnCharge = 260;
    public static final int regle = 270;
    
    //hors circuit
    public static final int valide_annule = 89;

    public static String str_enregistre = "enregistré";
    public static String str_modifie = "modifié";
    public static String str_reservation_annule = "reservation annulée";
    public static String str_reserve = "reservé";
    public static String str_rejeteCF_Visa = "rejeté par le CF";
    public static String str_transmiCF = "transmis au CF pour visas";
    
    public static String str_transmiCF_annule = "transmission au CF annulée";
    public static String str_transmiCF_reception = "réceptionné par le CF pour visa";
    public static String str_valide = "validé par le CF";
    public static String str_transmiPourLiquidation = "transmis pour Liquidation";
    public static String str_transmiPourLiquidation_annule = "Annulation de la transmission pour Liquidation";
    public static String str_transmiPourLiquidation_reception = "Réception des dossiers par l'ordonnateur pour liquidation";
    
    public static String str_receptionneLiquidation = "réceptionné par l'ordonnateur pour liquidation";
    public static String str_liquide_constatation = "Liquidation enregistree";
    public static String str_liquide_certification = "Liquidation partielle";
    public static String str_liquide_validation = "liquidation validée";
    public static String str_mandate = "mandaté";
    public static String str_rejetCF_regularite = "rejeté par le CF";
    public static String str_transmiPourRegularite_annule = "annulation de la transmission pour Contrôle de régularité";
    public static String str_transmiPourRegularite = "transmis au CF pour Contrôle de régularité";
    
    public static String str_receptionneRegularite = "réceptionné pour régularité";
    public static String str_valideRegularite = "régularité validé";
    public static String str_rejetAC_PriseEnCharge = "prise en charge rejetée";
    public static String str_transmiAuComptable_annule = "transmission à l'AC annulée";
    public static String str_transmiAuComptable = "transmis à l'AC";
    
    public static String str_receptionneComptable = "réceptionné par l'AC";
    public static String str_prisEnCharge = "créance pris en charge";
    public static String str_regle = "créance reglé";

    public static String getString(int etat) {
        String s = "***";
        switch (etat) {
            case enregistre:
                s = str_enregistre;
                break;
            case modifie:
                s = str_modifie;
                break;
            case reservation_annule:
                s = str_reservation_annule;
                break;
            case reserve:
                s = str_reserve;
                break;
            case rejeteCF_Visa:
                s = str_rejeteCF_Visa;
                break;
            case transmiCF_annule:
                s = str_transmiCF_annule;
                break;
            case transmiCF:
                s = str_transmiCF;
                break;
// ------------------------------controle de vonformite
            case receptionneCF:
                s = str_transmiCF_reception;
                break;
            case valide:
                s = str_valide;
                break;
            case transmiPourLiquidation_annule:
                s = str_transmiPourLiquidation_annule;
                break;
            case transmiPourLiquidation:
                s = str_transmiPourLiquidation;
                break;
// ---------------------------- liquidation             
            case receptionneLiquidation:
                s = str_receptionneLiquidation;
                break;
            case liquide_enregistre:
                s = str_liquide_constatation;
                break;
            case liquide_partielle:
                s = str_liquide_certification;
                break;
            case liquide_validation:
                s = str_liquide_validation;
                break;
            case mandate:
                s = str_mandate;
                break;
            case rejetCF_regularite:
                s = str_rejetCF_regularite;
                break;
            case transmiPourRegularite_annule:
                s = str_transmiPourRegularite_annule;
                break;
            case transmiPourRegularite:
                s = str_transmiPourRegularite;
                break;

// ----------------------------- controle de regularité           
            case receptionneRegularite:
                s = str_receptionneRegularite;
                break;
            case valideRegularite:
                s = str_valideRegularite;
                break;
            case rejetAC_PriseEnCharge:
                s = str_rejetAC_PriseEnCharge;
                break;
            case transmiAuComptable_annule:
                s = str_transmiAuComptable_annule;
                break;
            case transmiAuComptable:
                s = str_transmiAuComptable;
                break;
                
// ------------- comptable       
            case receptionneComptable:
                s = str_receptionneComptable;
                break;
            case prisEnCharge:
                s = str_prisEnCharge;
                break;
            case regle:
                s = str_regle;
                break;
            default:
                s = "";
                break;
        }
        return s;
    }
    
   public static String getListeEtat(int openMode) {
        String s = "";
        StringBuilder l = new StringBuilder();
        if(openMode == DialogOpenMode.annulation_dossier){
            l.append("").append(EtatDossier.transmiCF).append(",");
            l.append("").append(EtatDossier.receptionneCF).append(",");
            l.append("").append(EtatDossier.valide).append(",");
            l.append("").append(EtatDossier.valide_annule).append(",");
            l.append("").append(EtatDossier.transmiPourLiquidation).append(",");
            l.append("").append(EtatDossier.transmiPourLiquidation_annule).append(",");
        }else if(openMode == DialogOpenMode.enregistre){
            l.append("").append(EtatDossier.enregistre).append(",");
            l.append("").append(EtatDossier.modifie).append(",");
        }
        else if(openMode == DialogOpenMode.modifie){
            l.append("").append(EtatDossier.enregistre).append(",");
            l.append("").append(EtatDossier.modifie).append(",");
        }
        else if(openMode == DialogOpenMode.reserve){
            l.append("").append(EtatDossier.enregistre).append(",");
            l.append("").append(EtatDossier.modifie).append(",");
            l.append("").append(EtatDossier.reservation_annule).append(",");
        }
        else if(openMode == DialogOpenMode.reservation_annule){
            l.append("").append(EtatDossier.reserve).append(",");
            l.append("").append(EtatDossier.rejeteCF_Visa).append(",");
        }
        else if(openMode == DialogOpenMode.transmiCF){
            l.append("").append(EtatDossier.reserve).append(",");
            l.append("").append(EtatDossier.rejeteCF_Visa).append(",");
        }
        else if(openMode == DialogOpenMode.receptionneCF){
            l.append("").append(EtatDossier.transmiCF).append(",");
        }
        else if(openMode == DialogOpenMode.valide){
            l.append("").append(EtatDossier.receptionneCF).append(",");
        }
        else if(openMode == DialogOpenMode.valide_annule){
            l.append("").append(EtatDossier.valide).append(",");
        }
        else if(openMode == DialogOpenMode.rejeteCF_Visa){
            l.append("").append(EtatDossier.valide).append(",");
        }else if(openMode == DialogOpenMode.rejeteCF_Bordereau){
            l.append("").append(EtatDossier.rejeteCF_Visa).append(",");
        }
        else if(openMode == DialogOpenMode.transmiPourLiquidation){
            l.append("").append(EtatDossier.valide).append(",");
        }
        else if(openMode == DialogOpenMode.transmiPourLiquidation_annule){
            l.append("").append(EtatDossier.transmiPourLiquidation).append(",");
        }
        else if(openMode == DialogOpenMode.liquidation){
            l.append("").append(EtatDossier.receptionneLiquidation).append(",");
            l.append("").append(EtatDossier.liquide_enregistre).append(",");
            l.append("").append(EtatDossier.liquide_partielle).append(",");
        }
        else if(openMode == DialogOpenMode.liquide_constatation){
            l.append("").append(EtatDossier.liquide_enregistre).append(",");
            l.append("").append(EtatDossier.liquide_partielle).append(",");
        }
        else if(openMode == DialogOpenMode.liquide_certification){
            l.append("").append(EtatDossier.liquide_validation).append(",");
            l.append("").append(EtatDossier.liquide_partielle).append(",");
        }
        else if(openMode == DialogOpenMode.liquide_validation){
            l.append("").append(EtatDossier.liquide_validation).append(",");
        }
        else if(openMode == DialogOpenMode.transmiPourRegularite){
            l.append("").append(EtatDossier.mandate).append(",");
        }
        else if(openMode == DialogOpenMode.transmiPourRegularite_annule){
            l.append("").append(EtatDossier.transmiPourRegularite).append(",");
        }
        else if(openMode == DialogOpenMode.transmiAuComptable){
            l.append("").append(EtatDossier.valideRegularite).append(",");
        }
        else if(openMode == DialogOpenMode.transmiAuComptable_annule){
            l.append("").append(EtatDossier.transmiAuComptable).append(",");
        }
        else if(openMode == DialogOpenMode.valideRegularite){
            l.append("").append(EtatDossier.receptionneRegularite).append(",");
        }
        else if(openMode == DialogOpenMode.receptionneLiquidation){
            l.append("").append(EtatDossier.transmiPourLiquidation).append(",");
        }
        else if(openMode == DialogOpenMode.receptionneRegularite){
            l.append("").append(EtatDossier.transmiPourRegularite).append(",");
        }
        else if(openMode == DialogOpenMode.receptionneComptable){
            l.append("").append(EtatDossier.transmiAuComptable).append(",");
        }
        else if(openMode == DialogOpenMode.prisEnCharge){
            l.append("").append(EtatDossier.receptionneComptable).append(",");
        }
        else if(openMode == DialogOpenMode.regle){
            l.append("").append(EtatDossier.prisEnCharge).append(",");
        }
        
        
        s = l.toString();
        if (s.length() > 2) {
            s = s.substring(0, s.length() - 1);
        }
        s = "(" + s + ")";
        return s;
    }
   
   public static String getNextStep(int etat) {
        String s = "***";
        switch (etat) {
            case enregistre:
                s = "ordonnateur : FAIRE LA RESERVATON DES CREDITS";
                break;
            case modifie:
                s = "ordonnateur : FAIRE LES CORRECTIONS NESSECAIRES PUIS LA RESERVATON DES CREDITS";
                break;
            case reservation_annule:
                s = "ordonnateur : MODIFIER ET FAIRE LA RESERVATON DES CREDITS";
                break;
            case reserve:
                s = "ordonnateur : FAIRE LA TRANSMISSION AU CONTROLE FINANCIER POUR VISAS";
                break;
            case rejeteCF_Visa:
                s = "ordonnateur : ANNULER LA RESERVATION DES CREDITS ET FAIRE LES CORRECTIONS NECESSAIRES";
                break;
            case transmiCF_annule:
                s = "ordonnateur : ANNULER LA RESERVATION DE CREDITS OU RETRANSMETTRE A NOUVEAU";
                break;
            case transmiCF:
                s = "LE CONTROLEUR FINANCIER DOIT RECEPTIONNER LE DOSSIER AVANT DE FAIRE LE CONTROLE";
                break;
// ------------------------------controle de vonformite
            case receptionneCF:
                s = "cf : FAIRE LE CONTROLE DE CONFORMITE DE CONFORMITE POUR VISAS PAR LE CF";
                break;
            case valide:
                s = "cf : ENGAGEMENT VALIDE. FAIRE LA TRANSMISSION A L'ORDONNATEUR POUR LA LIQUIDATION";
                break;
            case transmiPourLiquidation_annule:
                s = "cf : LE CONTROLEUR FINANCIER DOIT EFFECTUER A NOUVEAU LE CONTROLE DE CONFORMITE OU REJETER LE DOSSIER";
                break;
            case transmiPourLiquidation:
                s = "L'ORDONNATEUR DOIT RECEPTIONNER LE DOSSIER AVANT DE LIQUIDER";
                break;
// ---------------------------- liquidation             
            case receptionneLiquidation:
                s = "ordonnateur : COMMENCER LA LIQUIDATION ";
                break;
            case liquide_enregistre:
                s = "ordonnateur : CONTINUER LA LIQUIDATION EN FAISANT LA CERTIFICATION";
                break;
            case liquide_partielle:
                s = "ordonnateur : LA LIQUIDATION DOIT ETRE VALIDEE AVANT DE FAIRE L'ORDONNANCEMENT";
                break;
            case liquide_validation:
                s = "ordonnateur : FAIRE L'ORDONNANCEMENT ET TRANSMETTRE AU CONTROLEUR";
                break;
            case mandate:
                s = "ordonnateur : FAIRE LA TRANSMISSION AU CONTROLEUR POUR CONTROLE DE LA REGULARITE";
                break;
            case rejetCF_regularite:
                s = "ordonnateur : REFAIRE L'ORDONNANCEMENT";
                break;
            case transmiPourRegularite_annule:
                s = "ordonnateur : FAIRE LES CORRECTIONS NECESSAIRES";
                break;
            case transmiPourRegularite:
                s = "LE CONTROLEUR FINANCIER DOIT RECEPTIONNER LES DOSSIERS AVANT D'EFFECTUER LE CONTROLE DE REGULARITE ";
                break;

// ----------------------------- controle de regularité           
            case receptionneRegularite:
                s = "cf : EFFECTUER LE CONTROLE DE REGULARITE";
                break;
            case valideRegularite:
                s = "LE CONTROLEUR DOIT FAIRE LA TRANSMISSION AU COMPTABLE POUR PAIEMENT ";
                break;
            case rejetAC_PriseEnCharge:
                s = "cf : FAIRE LES CORRECTIONS NECESSAIRES ET RENVOYER LE DOSSIER A L'AGENT COMPTABLE";
                break;
            case transmiAuComptable_annule:
                s = "cf : FAIRE LES CORRECTIONS NECESSAIRES ET RENVOYER LE DOSSIER A L'AGENT COMPTABLE";
                break;
            case transmiAuComptable:
                s = "L'AGENT COMPTABLE DOIT RECEPTIONNER LE DOSSIER";
                break;
                
// ------------- comptable       
            case receptionneComptable:
                s = "ac : FAIRE LA PRISE EN CHARGE ET EFFECTUER LES DIFFERENTS PRECOMPTES";
                break;
            case prisEnCharge:
                s = "ac : PROCEDER A LA MISE EN PAIEMENT";
                break;
            case regle:
                s = "DOSSIER REGLE AUPRES DE L'AGENT COMPTABLE. FIN DE PROCEDURE";
                break;
            default:
                s = "";
                break;
        }
        return s;
    }
}
