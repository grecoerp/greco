/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.enumeration;

/**
 *
 * @author ouethy
 */
public class DialogOpenMode {
    public static final int enregistre = 10;
    public static final int modifie = 20;
    public static final int reservation_annule = 30; //retour a modifie
    public static final int reserve = 40;
    public static final int rejeteCF_Visa = 50;
    public static final int rejeteCF_Bordereau = -10;
    public static final int transmiCF_annule = 60; // retour a reserver
    public static final int transmiCF = 70;
    
    public static final int receptionneCF = 80;
    public static final int valide = 90;
    public static final int transmiPourLiquidation_annule = 100; // retour a controle de conformite
    public static final int transmiPourLiquidation = 110;
    
    public static final int receptionneLiquidation = 120;
    public static final int liquide_constatation = 130;
    public static final int liquide_certification = 140;
    public static final int liquide_validation = 150;
    public static final int mandate = 160;
    public static final int rejetCF_regularite = 170;
    public static final int transmiPourRegularite_annule = 180; // retour a mandate
    public static final int transmiPourRegularite = 190;
    
    public static final int receptionneRegularite = 200;
    public static final int valideRegularite = 210;
    public static final int rejetAC_PriseEnCharge = 220;
    public static final int transmiAuComptable_annule = 230; // retour au controle de regularite
    public static final int transmiAuComptable = 240;
    
    public static final int receptionneComptable = 250;
    public static final int prisEnCharge = 260;
    public static final int regle = 270;
    
    //hors circuit
    public static final int valide_annule = 89;
    public static final int liquidation = 119;
    public static final int annulation_dossier = 9;
}
