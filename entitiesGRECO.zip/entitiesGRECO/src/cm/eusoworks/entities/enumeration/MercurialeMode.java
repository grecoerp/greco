/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.enumeration;

/**
 *
 * @author jeanemmanuel
 */
public class MercurialeMode {
    
    public static final int MODE_FACTURE = 1;
    public static final int MODE_SAISIEARTICLES = 2;
}
