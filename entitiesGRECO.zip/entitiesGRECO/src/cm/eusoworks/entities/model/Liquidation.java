/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "LIQUIDATION")
public class Liquidation implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Column(name = "machine")
    private String machine;
    @Id
    @Basic(optional = false)
    @Column(name = "liquidationID")
    private String liquidationID;
    private String engagementID;
    @Basic(optional = false)
    @Column(name = "numOrdre")
    private int numOrdre;
    @Basic(optional = false)
    @Column(name = "etat")
    private int etat;
    @Column(name = "dateLiquidation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateLiquidation;
    @Basic(optional = false)
    @Column(name = "objet")
    private String objet;
    @Basic(optional = false)
    @Column(name = "montantTTC")
    private BigDecimal montantTTC;
    @Column(name = "montantTVA")
    private BigDecimal montantTVA;
    @Column(name = "montantIR")
    private BigDecimal montantIR;
    @Basic(optional = false)
    @Column(name = "montantNAP")
    private BigDecimal montantNAP;
    @Column(name = "montantRG")
    private BigDecimal montantRG;
    @Basic(optional = false)
    @Column(name = "beneficiaire")
    private String beneficiaire;
    @Column(name = "pieces")
    private String pieces;
    @Column(name = "livrables")
    private String livrables;
    @Column(name = "dateValidation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateValidation;
    @Column(name = "userValidation")
    private String userValidation;
    @Column(name = "obsValidation")
    private String obsValidation;
    @Column(name = "dateRejet")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateRejet;
    @Column(name = "userRejet")
    private String userRejet;
    @Column(name = "motifRejet")
    private String motifRejet;
    
    private String numDossier;

    public Liquidation() {
    }

    public Liquidation(String liquidationID) {
        this.liquidationID = liquidationID;
    }

    public Liquidation(String liquidationID, Date lastUpdate, String userUpdate, int numOrdre, int etat, String objet, BigDecimal montantTTC, BigDecimal montantNAP, String beneficiaire) {
        this.liquidationID = liquidationID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.numOrdre = numOrdre;
        this.etat = etat;
        this.objet = objet;
        this.montantTTC = montantTTC;
        this.montantNAP = montantNAP;
        this.beneficiaire = beneficiaire;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public String getLiquidationID() {
        return liquidationID;
    }

    public void setLiquidationID(String liquidationID) {
        this.liquidationID = liquidationID;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public Date getDateLiquidation() {
        return dateLiquidation;
    }

    public void setDateLiquidation(Date dateLiquidation) {
        this.dateLiquidation = dateLiquidation;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public Date getDateValidation() {
        return dateValidation;
    }

    public void setDateValidation(Date dateValidation) {
        this.dateValidation = dateValidation;
    }

    public String getUserValidation() {
        return userValidation;
    }

    public void setUserValidation(String userValidation) {
        this.userValidation = userValidation;
    }

    public String getObsValidation() {
        return obsValidation;
    }

    public void setObsValidation(String obsValidation) {
        this.obsValidation = obsValidation;
    }

    public Date getDateRejet() {
        return dateRejet;
    }

    public void setDateRejet(Date dateRejet) {
        this.dateRejet = dateRejet;
    }

    public String getUserRejet() {
        return userRejet;
    }

    public void setUserRejet(String userRejet) {
        this.userRejet = userRejet;
    }

    public String getMotifRejet() {
        return motifRejet;
    }

    public void setMotifRejet(String motifRejet) {
        this.motifRejet = motifRejet;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liquidationID != null ? liquidationID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Liquidation)) {
            return false;
        }
        Liquidation other = (Liquidation) object;
        if ((this.liquidationID == null && other.liquidationID != null) || (this.liquidationID != null && !this.liquidationID.equals(other.liquidationID))) {
            return false;
        }
        return true;
    }

    public String getEngagementID() {
        return engagementID;
    }

    public void setEngagementID(String engagementID) {
        this.engagementID = engagementID;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public BigDecimal getMontantTVA() {
        return montantTVA;
    }

    public void setMontantTVA(BigDecimal montantTVA) {
        this.montantTVA = montantTVA;
    }

    public BigDecimal getMontantIR() {
        return montantIR;
    }

    public void setMontantIR(BigDecimal montantIR) {
        this.montantIR = montantIR;
    }

    public BigDecimal getMontantNAP() {
        return montantNAP;
    }

    public void setMontantNAP(BigDecimal montantNAP) {
        this.montantNAP = montantNAP;
    }

    public BigDecimal getMontantRG() {
        return montantRG;
    }

    public void setMontantRG(BigDecimal montantRG) {
        this.montantRG = montantRG;
    }

    public String getPieces() {
        return pieces;
    }

    public void setPieces(String pieces) {
        this.pieces = pieces;
    }

    public String getLivrables() {
        return livrables;
    }

    public void setLivrables(String livrables) {
        this.livrables = livrables;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }


    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.Liquidation[ liquidationID=" + liquidationID + " ]";
    }
    
}
