/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "ordremission")
public class OrdreMission implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "omID")
    private String omID;
    @Basic(optional = false)
    @Column(name = "motif")
    private String motif;
    @Column(name = "grade")
    private String grade;
    @Column(name = "affectation")
    private String affectation;
    @Column(name = "situation")
    private String situation;
    @Basic(optional = false)
    @Column(name = "destination")
    private String destination;
    @Column(name = "passantPar")
    private String passantPar;
    @Column(name = "motifReference")
    private String motifReference;
    @Column(name = "transport")
    private String transport;
    @Column(name = "accompagnant")
    private String accompagnant;
    @Basic(optional = false)
    @Column(name = "dateDepart")
    @Temporal(TemporalType.DATE)
    private Date dateDepart;
    @Basic(optional = false)
    @Column(name = "dateRetour")
    @Temporal(TemporalType.DATE)
    private Date dateRetour;
    @Basic(optional = false)
    @Column(name = "typeMission")
    private int typeMission;
    @Column(name = "matricule")
    private String matricule;
    @Column(name = "tacheID")
    private String tacheID;
    @Column(name = "organisationID")
    private String organisationID;
    @Column(name = "millesime")
    private String millesime;
    @Column(name = "activiteID")
    private String activiteID;
    @Column(name = "structureID")
    private String structureID;

    private String nomAgent;
    private String prenomAgent;
    private int nbJours;

    private String ordonnateur;
    private String numeroOP;
    private BigDecimal montantGlobal;
    private BigDecimal montantOP;
    private int etat;
    private String beneficiaire;
    private String numDossier;
    
    private String strEtat;

    public OrdreMission() {
    }

    public OrdreMission(String omID) {
        this.omID = omID;
    }

    public OrdreMission(String omID, Date lastUpdate, String userUpdate, String motif, String destination, Date dateDepart, Date dateRetour, int typeMission) {
        this.omID = omID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.motif = motif;
        this.destination = destination;
        this.dateDepart = dateDepart;
        this.dateRetour = dateRetour;
        this.typeMission = typeMission;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getOmID() {
        return omID;
    }

    public void setOmID(String omID) {
        this.omID = omID;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    public String getAffectation() {
        return affectation;
    }

    public void setAffectation(String affectation) {
        this.affectation = affectation;
    }

    public String getSituation() {
        return situation;
    }

    public void setSituation(String situation) {
        this.situation = situation;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getPassantPar() {
        return passantPar;
    }

    public void setPassantPar(String passantPar) {
        this.passantPar = passantPar;
    }

    public String getMotifReference() {
        return motifReference;
    }

    public void setMotifReference(String motifReference) {
        this.motifReference = motifReference;
    }

    public String getTransport() {
        return transport;
    }

    public void setTransport(String transport) {
        this.transport = transport;
    }

    public String getAccompagnant() {
        return accompagnant;
    }

    public void setAccompagnant(String accompagnant) {
        this.accompagnant = accompagnant;
    }

    public Date getDateDepart() {
        return dateDepart;
    }

    public void setDateDepart(Date dateDepart) {
        this.dateDepart = dateDepart;
    }

    public Date getDateRetour() {
        return dateRetour;
    }

    public void setDateRetour(Date dateRetour) {
        this.dateRetour = dateRetour;
    }

    public int getTypeMission() {
        return typeMission;
    }

    public void setTypeMission(int typeMission) {
        this.typeMission = typeMission;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getNomAgent() {
        return nomAgent;
    }

    public void setNomAgent(String nomAgent) {
        this.nomAgent = nomAgent;
    }

    public String getPrenomAgent() {
        return prenomAgent;
    }

    public void setPrenomAgent(String prenomAgent) {
        this.prenomAgent = prenomAgent;
    }

    public int getNbJours() {
        return nbJours;
    }

    public void setNbJours(int nbJours) {
        this.nbJours = nbJours;
    }

    public String getNomCompletWithMatricule() {
        return "[" + this.matricule + "] " + this.nomAgent + " " + this.prenomAgent == null ? "" : this.prenomAgent;
    }

    public String getNomComplet() {
        return this.nomAgent + " " + this.prenomAgent == null ? "" : this.prenomAgent;
    }

    public String getOrdonnateur() {
        return ordonnateur;
    }

    public void setOrdonnateur(String ordonnateur) {
        this.ordonnateur = ordonnateur;
    }

    public String getNumeroOP() {
        return numeroOP;
    }

    public void setNumeroOP(String numeroOP) {
        this.numeroOP = numeroOP;
    }

    public BigDecimal getMontantGlobal() {
        return montantGlobal;
    }

    public void setMontantGlobal(BigDecimal montantGlobal) {
        this.montantGlobal = montantGlobal;
    }

    public BigDecimal getMontantOP() {
        return montantOP;
    }

    public void setMontantOP(BigDecimal montantOP) {
        this.montantOP = montantOP;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (omID != null ? omID.hashCode() : 0);
        return hash;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public String getStrEtat() {
        return EtatDossier.getString(etat);
    }

    public void setStrEtat(String strEtat) {
        this.strEtat = strEtat;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrdreMission)) {
            return false;
        }
        OrdreMission other = (OrdreMission) object;
        if ((this.omID == null && other.omID != null) || (this.omID != null && !this.omID.equals(other.omID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return motifReference + "- " + getNomComplet();
    }

}
