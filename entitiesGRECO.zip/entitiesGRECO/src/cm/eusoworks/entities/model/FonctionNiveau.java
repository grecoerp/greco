/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "FONCTIONNIVEAU")

public class FonctionNiveau implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "niveauFonctionID")
    private Integer niveauFonctionID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelleUs")
    private String libelleUs;
    @Column(name = "r")
    private Integer r;
    @Column(name = "g")
    private Integer g;
    @Column(name = "b")
    private Integer b;
    @Basic(optional = false)
    @Column(name = "mask")
    private String mask;

    public FonctionNiveau() {
    }

    public FonctionNiveau(Integer niveauFonctionID) {
        this.niveauFonctionID = niveauFonctionID;
    }

    public FonctionNiveau(Integer niveauFonctionID, Date lastUpdate, String userUpdate, String libelleFr, String libelleUs) {
        this.niveauFonctionID = niveauFonctionID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public Integer getNiveauFonctionID() {
        return niveauFonctionID;
    }

    public void setNiveauFonctionID(Integer niveauFonctionID) {
        this.niveauFonctionID = niveauFonctionID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Integer getR() {
        return r;
    }

    public void setR(Integer r) {
        this.r = r;
    }

    public Integer getG() {
        return g;
    }

    public void setG(Integer g) {
        this.g = g;
    }

    public Integer getB() {
        return b;
    }

    public void setB(Integer b) {
        this.b = b;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (niveauFonctionID != null ? niveauFonctionID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FonctionNiveau)) {
            return false;
        }
        FonctionNiveau other = (FonctionNiveau) object;
        if ((this.niveauFonctionID == null && other.niveauFonctionID != null) || (this.niveauFonctionID != null && !this.niveauFonctionID.equals(other.niveauFonctionID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return niveauFonctionID.toString()+" - "+getLibelle(Locale.getDefault());
    }
    public String getLibelle(Locale locale) {
        return locale==Locale.FRENCH?getLibelleFr():getLibelleUs();
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }
}
