/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "exercice")
public class Exercice implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "dateDebut")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDebut;
    @Basic(optional = false)
    @Column(name = "dateFin")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFin;
    @Column(name = "enProgrammation")
    private Boolean enProgrammation;
    @Column(name = "enBudgetisation")
    private Boolean enBudgetisation;
    @Column(name = "enExecution")
    private Boolean enExecution;
    @Column(name = "enCloture")
    private Boolean enCloture;

    public Exercice() {
    }

    public Exercice(String millesime) {
        this.millesime = millesime;
    }

    public Exercice(String millesime, Date lastUpdate, String userUpdate, String libelleFr, String libelleUs, Date dateDebut, Date dateFin) {
        this.millesime = millesime;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public Boolean getEnProgrammation() {
        return enProgrammation;
    }

    public void setEnProgrammation(Boolean enProgrammation) {
        this.enProgrammation = enProgrammation;
    }

    public Boolean getEnBudgetisation() {
        return enBudgetisation;
    }

    public void setEnBudgetisation(Boolean enBudgetisation) {
        this.enBudgetisation = enBudgetisation;
    }

    public Boolean getEnExecution() {
        return enExecution;
    }

    public void setEnExecution(Boolean enExecution) {
        this.enExecution = enExecution;
    }

    public Boolean getEnCloture() {
        return enCloture;
    }

    public void setEnCloture(Boolean enCloture) {
        this.enCloture = enCloture;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (millesime != null ? millesime.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Exercice)) {
            return false;
        }
        Exercice other = (Exercice) object;
        if ((this.millesime == null && other.millesime != null) || (this.millesime != null && !this.millesime.equals(other.millesime))) {
            return false;
        }
        return true;
    }

    public String getLibelle(Locale locale){
        return locale == Locale.FRENCH?getLibelleFr():getLibelleUs();
    }
    
    public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }
    
    @Override
    public String toString() {
        return millesime + " - " + getLibelle();
    }
    
}
