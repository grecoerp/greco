/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbook
 */

public class Ecritures implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "ecritureID")
    private String ecritureID;
    @Basic(optional = false)
    @Column(name = "dateOperation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateOperation;
    @Basic(optional = false)
    @Column(name = "libelle")
    private String libelle;
    @Basic(optional = false)
    @Column(name = "debit")
    private BigDecimal debit;
    @Basic(optional = false)
    @Column(name = "credit")
    private BigDecimal credit;
    @Column(name = "lettrage")
    private String lettrage;
    @Column(name = "rapprochement")
    private String rapprochement;
    @Basic(optional = false)
    @Lob
    @Column(name = "numOrdreValidation")
    private Long numOrdreValidation;
    @Column(name = "valide")
    private Boolean valide;
    
    private String millesime;
    private String axeID;
    private String journalID;
    private String compte;
    
    private String mandatementID;
    private String pieces;
    
    private String engagementID;
    private String droitID;
    private int typeEcriture;
    

    public Ecritures() {
    }
    
    public Ecritures(String journalID) {
        this.journalID = journalID;
    }
    
    public Ecritures(String journalID, Date dateOper, String libelle) {
        this.journalID = journalID;
        this.dateOperation = dateOper;
        this.libelle = libelle;
    }


    public Ecritures(String ecritureID, Date lastUpdate, String userUpdate, Date dateOperation, String libelle, BigDecimal debit, BigDecimal credit, Long numOrdreValidation) {
        this.ecritureID = ecritureID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.dateOperation = dateOperation;
        this.libelle = libelle;
        this.debit = debit;
        this.credit = credit;
        this.numOrdreValidation = numOrdreValidation;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getEcritureID() {
        return ecritureID;
    }

    public void setEcritureID(String ecritureID) {
        this.ecritureID = ecritureID;
    }

    public Date getDateOperation() {
        return dateOperation;
    }

    public void setDateOperation(Date dateOperation) {
        this.dateOperation = dateOperation;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

    public BigDecimal getDebit() {
        return debit;
    }

    public void setDebit(BigDecimal debit) {
        this.debit = debit;
    }

    public BigDecimal getCredit() {
        return credit;
    }

    public void setCredit(BigDecimal credit) {
        this.credit = credit;
    }

   

    public String getLettrage() {
        return lettrage;
    }

    public void setLettrage(String lettrage) {
        this.lettrage = lettrage;
    }

    public String getRapprochement() {
        return rapprochement;
    }

    public void setRapprochement(String rapprochement) {
        this.rapprochement = rapprochement;
    }


    public Boolean getValide() {
        return valide;
    }

    public void setValide(Boolean valide) {
        this.valide = valide;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ecritureID != null ? ecritureID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Ecritures)) {
            return false;
        }
        Ecritures other = (Ecritures) object;
        if ((this.ecritureID == null && other.ecritureID != null) || (this.ecritureID != null && !this.ecritureID.equals(other.ecritureID))) {
            return false;
        }
        return true;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getAxeID() {
        return axeID;
    }

    public void setAxeID(String axeID) {
        this.axeID = axeID;
    }

    public String getJournalID() {
        return journalID;
    }

    public void setJournalID(String journalID) {
        this.journalID = journalID;
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public String getMandatementID() {
        return mandatementID;
    }

    public void setMandatementID(String mandatementID) {
        this.mandatementID = mandatementID;
    }

    public String getPieces() {
        return pieces;
    }

    public void setPieces(String pieces) {
        this.pieces = pieces;
    }

    @Override
    public String toString() {
        return compte +" ["+libelle+"]";
    }

    public String getEngagementID() {
        return engagementID;
    }

    public void setEngagementID(String engagementID) {
        this.engagementID = engagementID;
    }

    public Long getNumOrdreValidation() {
        return numOrdreValidation;
    }

    public void setNumOrdreValidation(Long numOrdreValidation) {
        this.numOrdreValidation = numOrdreValidation;
    }

    public String getDroitID() {
        return droitID;
    }

    public void setDroitID(String droitID) {
        this.droitID = droitID;
    }

    public int getTypeEcriture() {
        return typeEcriture;
    }

    public void setTypeEcriture(int typeEcriture) {
        this.typeEcriture = typeEcriture;
    }
    
}
