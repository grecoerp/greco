/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "fournisseur")
public class Fournisseur implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "fournisseurID")
    private String fournisseurID;
    @Basic(optional = false)
    @Column(name = "numContribuable")
    private String numContribuable;
    @Basic(optional = false)
    @Column(name = "raisonSociale")
    private String raisonSociale;
    @Column(name = "adresse")
    private String adresse;
    @Basic(optional = false)
    @Column(name = "rib")
    private String rib;
    @Basic(optional = false)
    @Column(name = "banque")
    private String banque;
    @Basic(optional = false)
    @Column(name = "agence")
    private String agence;
    @Basic(optional = false)
    @Column(name = "fourBudgetaire")
    private Boolean fourBudgetaire;
    
    private String registreCommerce;
    private String telephone; 

    public Fournisseur() {
    }

    public Fournisseur(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public Fournisseur(String fournisseurID, Date lastUpdate, String userUpdate, String numContribuable, String raisonSociale, String rib, String banque, String agence) {
        this.fournisseurID = fournisseurID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.numContribuable = numContribuable;
        this.raisonSociale = raisonSociale;
        this.rib = rib;
        this.banque = banque;
        this.agence = agence;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getFournisseurID() {
        return fournisseurID;
    }

    public void setFournisseurID(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public String getNumContribuable() {
        return numContribuable;
    }

    public void setNumContribuable(String numContribuable) {
        this.numContribuable = numContribuable;
    }

    public String getRaisonSociale() {
        return raisonSociale;
    }

    public void setRaisonSociale(String raisonSociale) {
        this.raisonSociale = raisonSociale;
    }

    public String getAdresse() {
        return adresse;
    }

    public void setAdresse(String adresse) {
        this.adresse = adresse;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public String getBanque() {
        return banque;
    }

    public void setBanque(String banque) {
        this.banque = banque;
    }

    public String getAgence() {
        return agence;
    }

    public void setAgence(String agence) {
        this.agence = agence;
    }

    public Boolean isFourBudgetaire() {
        return fourBudgetaire;
    }

    public void setFourBudgetaire(Boolean fourBudgetaire) {
        this.fourBudgetaire = fourBudgetaire;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (fournisseurID != null ? fournisseurID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Fournisseur)) {
            return false;
        }
        Fournisseur other = (Fournisseur) object;
        if ((this.fournisseurID == null && other.fournisseurID != null) || (this.fournisseurID != null && !this.fournisseurID.equals(other.fournisseurID))) {
            return false;
        }
        return true;
    }

    public String getRegistreCommerce() {
        return registreCommerce;
    }

    public void setRegistreCommerce(String registreCommerce) {
        this.registreCommerce = registreCommerce;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }

    @Override
    public String toString() {
        return numContribuable+" - "+raisonSociale;
    }
    
}
