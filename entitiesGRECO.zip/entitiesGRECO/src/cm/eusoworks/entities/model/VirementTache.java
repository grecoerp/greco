/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author DISI
 */

public class VirementTache implements Serializable {

    private static final long serialVersionUID = 1L;
    
    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String virementTacheID;
    private String virementID;
    private String tacheID;
    private BigDecimal debit;
    private BigDecimal credit;
    private String millesime;
    private String chapitre;
    private String tacheCode;
    private String paragraphe;
    private String programme;
    private String action;
    private String libelleFr;
    private String libelleUs;
    private BigDecimal disponibleAvant;
    private BigDecimal montant;

    public VirementTache() {
    }

    public VirementTache(String virementTacheID) {
        this.virementTacheID = virementTacheID;
    }

    public VirementTache(String virementTacheID, Date lastUpdate, String virementID, String tacheID, BigDecimal debit, BigDecimal credit, String millesime, String chapitre, String tacheCode, 
            String paragraphe, String programme, String action, String libelleFr, String libelleUs, BigDecimal disponibleAvant) {
        this.virementTacheID = virementTacheID;
        this.lastUpdate = lastUpdate;
        this.virementID = virementID;
        this.tacheID = tacheID;
        this.debit = debit;
        this.credit = credit;
        this.millesime = millesime;
        this.chapitre = chapitre;
        this.tacheCode = tacheCode;
        this.paragraphe = paragraphe;
        this.programme = programme;
        this.action = action;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
        this.disponibleAvant = disponibleAvant;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getVirementTacheID() {
        return virementTacheID;
    }

    public void setVirementTacheID(String virementTacheID) {
        this.virementTacheID = virementTacheID;
    }

    public String getVirementID() {
        return virementID;
    }

    public void setVirementID(String virementID) {
        this.virementID = virementID;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public BigDecimal getDebit() {
        return debit;
    }

    public void setDebit(BigDecimal debit) {
        this.debit = debit;
    }

    public BigDecimal getCredit() {
        return credit;
    }

    public void setCredit(BigDecimal credit) {
        this.credit = credit;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getChapitre() {
        return chapitre;
    }

    public void setChapitre(String chapitre) {
        this.chapitre = chapitre;
    }

    public String getTacheCode() {
        return tacheCode;
    }

    public void setTacheCode(String tacheCode) {
        this.tacheCode = tacheCode;
    }

    public String getParagraphe() {
        return paragraphe;
    }

    public void setParagraphe(String paragraphe) {
        this.paragraphe = paragraphe;
    }

    public String getProgramme() {
        return programme;
    }

    public void setProgramme(String programme) {
        this.programme = programme;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public BigDecimal getDisponibleAvant() {
        return disponibleAvant;
    }

    public void setDisponibleAvant(BigDecimal disponibleAvant) {
        this.disponibleAvant = disponibleAvant;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getImputation(){
        if(millesime == null) return "";
        else return millesime+" " + chapitre+" "+tacheCode+" "+paragraphe;
        //return "51 33 020801 602022";
    }
    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (virementTacheID != null ? virementTacheID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof VirementTache)) {
            return false;
        }
        VirementTache other = (VirementTache) object;
        if ((this.virementTacheID == null && other.virementTacheID != null) || (this.virementTacheID != null && !this.virementTacheID.equals(other.virementTacheID))) {
            return false;
        }
        return true;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    
    @Override
    public String toString() {
        return millesime+" "+chapitre+" "+tacheCode+" "+paragraphe+ " ["+libelleFr+"]";
    }
    
}
