/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbook
 */

public class CompteLiquidite implements Serializable {

    private static final long serialVersionUID = 1L;
    
    public static int ALL = 0;
    public static int BANQUE = 1;
    public static int CAISSE = 2;
    
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "liquiditeID")
    private String liquiditeID;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "isBanque")
    private boolean isBanque;
    @Basic(optional = false)
    @Column(name = "compte")
    private String compte;
    @Basic(optional = false)
    @Column(name = "journalID")
    private String journalID;
    @Column(name = "banqueID")
    private String banqueID;

    public CompteLiquidite() {
    }

    public CompteLiquidite(String liquiditeID) {
        this.liquiditeID = liquiditeID;
    }

    public CompteLiquidite(String liquiditeID, Date lastUpdate, String userUpdate, String code, String libelleFr, boolean isBanque, String compte, String journalID) {
        this.liquiditeID = liquiditeID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.code = code;
        this.libelleFr = libelleFr;
        this.isBanque = isBanque;
        this.compte = compte;
        this.journalID = journalID;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getLiquiditeID() {
        return liquiditeID;
    }

    public void setLiquiditeID(String liquiditeID) {
        this.liquiditeID = liquiditeID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public boolean getIsBanque() {
        return isBanque;
    }

    public void setIsBanque(boolean isBanque) {
        this.isBanque = isBanque;
    }

    public String getCompte() {
        return compte;
    }

    public void setCompte(String compte) {
        this.compte = compte;
    }

    public String getJournalID() {
        return journalID;
    }

    public void setJournalID(String journalID) {
        this.journalID = journalID;
    }

    public String getBanqueID() {
        return banqueID;
    }

    public void setBanqueID(String banqueID) {
        this.banqueID = banqueID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liquiditeID != null ? liquiditeID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CompteLiquidite)) {
            return false;
        }
        CompteLiquidite other = (CompteLiquidite) object;
        if ((this.liquiditeID == null && other.liquiditeID != null) || (this.liquiditeID != null && !this.liquiditeID.equals(other.liquiditeID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return libelleFr;
    }
    
}
