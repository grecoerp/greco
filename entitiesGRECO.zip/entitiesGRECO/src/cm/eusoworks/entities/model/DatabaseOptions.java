/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author DISI
 */

public class DatabaseOptions implements Serializable {

    private static final long serialVersionUID = 1L;

    private Date lastUpdate;

    private String userUpdate;
    private String ipUpdate;
    private String organisationID;
    private String qs89;
    private String yu78;
    private String rt34;
    private String o980;
    private String ssr4;
    private String akl;

    public DatabaseOptions() {
    }

    public DatabaseOptions(String organisationID) {
        this.organisationID = organisationID;
    }

    public DatabaseOptions(String organisationID, Date lastUpdate, String userUpdate, String qs89, String yu78, String rt34, String o980, String ssr4) {
        this.organisationID = organisationID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.qs89 = qs89;
        this.yu78 = yu78;
        this.rt34 = rt34;
        this.o980 = o980;
        this.ssr4 = ssr4;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getQs89() {
        return qs89;
    }

    public void setQs89(String qs89) {
        this.qs89 = qs89;
    }

    public String getYu78() {
        return yu78;
    }

    public void setYu78(String yu78) {
        this.yu78 = yu78;
    }

    public String getRt34() {
        return rt34;
    }

    public void setRt34(String rt34) {
        this.rt34 = rt34;
    }

    public String getO980() {
        return o980;
    }

    public void setO980(String o980) {
        this.o980 = o980;
    }

    public String getSsr4() {
        return ssr4;
    }

    public void setSsr4(String ssr4) {
        this.ssr4 = ssr4;
    }

    public String getAkl() {
        return akl;
    }

    public void setAkl(String akl) {
        this.akl = akl;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (organisationID != null ? organisationID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DatabaseOptions)) {
            return false;
        }
        DatabaseOptions other = (DatabaseOptions) object;
        if ((this.organisationID == null && other.organisationID != null) || (this.organisationID != null && !this.organisationID.equals(other.organisationID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return ssr4+" ON "+qs89;
    }
    
}
