/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "REGLEMENTMODE")
@NamedQueries({
    @NamedQuery(name = "ReglementMode.findAll", query = "SELECT r FROM ReglementMode r")})
public class ReglementMode implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "reglementID")
    private String reglementID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "isEspece")
    private boolean isEspece;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "reglementMode")
    private List<CaisseTicket> caisseTicketList;

    public ReglementMode() {
    }

    public ReglementMode(String reglementID) {
        this.reglementID = reglementID;
    }

    public ReglementMode(String reglementID, Date lastUpdate, String userUpdate, String libelleFr, boolean isEspece) {
        this.reglementID = reglementID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.isEspece = isEspece;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getReglementID() {
        return reglementID;
    }

    public void setReglementID(String reglementID) {
        this.reglementID = reglementID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public boolean getIsEspece() {
        return isEspece;
    }

    public void setIsEspece(boolean isEspece) {
        this.isEspece = isEspece;
    }

    public List<CaisseTicket> getCaisseTicketList() {
        return caisseTicketList;
    }

    public void setCaisseTicketList(List<CaisseTicket> caisseTicketList) {
        this.caisseTicketList = caisseTicketList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (reglementID != null ? reglementID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReglementMode)) {
            return false;
        }
        ReglementMode other = (ReglementMode) object;
        if ((this.reglementID == null && other.reglementID != null) || (this.reglementID != null && !this.reglementID.equals(other.reglementID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.ReglementMode[ reglementID=" + reglementID + " ]";
    }
    
}
