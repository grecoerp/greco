/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "PRMTR_NIVEAUMAX")
public class OptionNiveauMax implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "parametreID")
    private Integer parametreID;
    @Column(name = "FU")
    private Integer fu;
    @Column(name = "CA")
    private Integer ca;
    @Column(name = "LO")
    private Integer lo;
    @Column(name = "PC")
    private Integer pc;
    @Column(name = "AT")
    private Integer at;

    public OptionNiveauMax() {
    }

    public OptionNiveauMax(Integer parametreID) {
        this.parametreID = parametreID;
    }

    public OptionNiveauMax(Integer parametreID, Date lastUpdate, String userUpdate) {
        this.parametreID = parametreID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public Integer getParametreID() {
        return parametreID;
    }

    public void setParametreID(Integer parametreID) {
        this.parametreID = parametreID;
    }

    public Integer getFu() {
        return fu;
    }

    public void setFu(Integer fu) {
        this.fu = fu;
    }

    public Integer getCa() {
        return ca;
    }

    public void setCa(Integer ca) {
        this.ca = ca;
    }

    public Integer getLo() {
        return lo;
    }

    public void setLo(Integer lo) {
        this.lo = lo;
    }

    public Integer getPc() {
        return pc;
    }

    public void setPc(Integer pc) {
        this.pc = pc;
    }

    public Integer getAt() {
        return at;
    }

    public void setAt(Integer at) {
        this.at = at;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (parametreID != null ? parametreID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OptionNiveauMax)) {
            return false;
        }
        OptionNiveauMax other = (OptionNiveauMax) object;
        if ((this.parametreID == null && other.parametreID != null) || (this.parametreID != null && !this.parametreID.equals(other.parametreID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "OptionNiveauMax[ parametreID=" + parametreID + " ]";
    }
    
}
