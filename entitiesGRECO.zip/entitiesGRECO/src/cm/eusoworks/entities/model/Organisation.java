/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author macbookair
 */

public class Organisation implements Serializable {
    private static final long serialVersionUID = 1L;
    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String organisationID;
    private String code;
    private String abbreviationFr;
    private String abbreviationUs;
    private String libelleFr;
    private String libelleUs;
    private Date dateCreation;
    private Date dateCessation;
    private boolean actif;

    public Organisation() {
    }

    public Organisation(String organisationID) {
        this.organisationID = organisationID;
    }

    public Organisation(String organisationID, Date lastUpdate, String userUpdate, String code, String abbreviationFr, String abbreviationUs, String libelleFr, String libelleUs, Date dateCreation, boolean actif) {
        this.organisationID = organisationID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.code = code;
        this.abbreviationFr = abbreviationFr;
        this.abbreviationUs = abbreviationUs;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
        this.dateCreation = dateCreation;
        this.actif = actif;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAbbreviationFr() {
        return abbreviationFr;
    }

    public void setAbbreviationFr(String abbreviationFr) {
        this.abbreviationFr = abbreviationFr;
    }

    public String getAbbreviationUs() {
        return abbreviationUs;
    }

    public void setAbbreviationUs(String abbreviationUs) {
        this.abbreviationUs = abbreviationUs;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }
    
    public String getLibelle(Locale locale) {
        if(locale.equals(Locale.FRENCH)){
            return libelleFr;
        }else {
            return libelleUs;
        }
    }
    
    
    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Date getDateCessation() {
        return dateCessation;
    }

    public void setDateCessation(Date dateCessation) {
        this.dateCessation = dateCessation;
    }

    public boolean getActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (organisationID != null ? organisationID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Organisation)) {
            return false;
        }
        Organisation other = (Organisation) object;
        if ((this.organisationID == null && other.organisationID != null) || (this.organisationID != null && !this.organisationID.equals(other.organisationID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return code==null?"":code + " - "+ getLibelle();
    }
    
}
