/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author ouethy
 */

public class PrepaOperationBudgetaire implements Serializable {
    private static final long serialVersionUID = 1L;
    
    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String tacheID;
    private String libelleFr;
    private String libelleUs;
    private Date dateDebut;
    private Date dateFin;
    private String resultatFr;
    private String resultatUs;
    private String indicateurFr;
    private String indicateurUs;
    private String sourceVerificationFr;
    private String sourceVerificationUs;
    private BigDecimal ae;
    private BigDecimal cp;
    private String CompteCode;
    private String financementID;
    private String structureID;
    private String activiteBudgetiseID;
    private String posteComptableID;
    private int ordreDansActivite;

    private String compteLibelle; 
    private String structureAbbreviation; 
    private String financementAbbreviation; 
    private String posteComptableLibelle; 
    
    private String budgetID;
    private String budgetExploite = "";
    private String calendrier;
    
    boolean checked;
    
    private BigDecimal AECollectif;
    private BigDecimal CPCollectif;
    
    
    public PrepaOperationBudgetaire() {
    }

    public PrepaOperationBudgetaire(String tacheID) {
        this.tacheID = tacheID;
    }

    public PrepaOperationBudgetaire(String tacheID, Date lastUpdate, String userUpdate, String libelleFr, Date dateDebut, Date dateFin, String resultatFr, String indicateurFr, String sourceVerificationFr, BigDecimal ae, BigDecimal cp, int ordreDansActivite) {
        this.tacheID = tacheID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.dateDebut = dateDebut;
        this.dateFin = dateFin;
        this.resultatFr = resultatFr;
        this.indicateurFr = indicateurFr;
        this.sourceVerificationFr = sourceVerificationFr;
        this.ae = ae;
        this.cp = cp;
        this.ordreDansActivite = ordreDansActivite;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public String getResultatFr() {
        return resultatFr;
    }

    public void setResultatFr(String resultatFr) {
        this.resultatFr = resultatFr;
    }

    public String getResultatUs() {
        return resultatUs;
    }

    public void setResultatUs(String resultatUs) {
        this.resultatUs = resultatUs;
    }

    public String getIndicateurFr() {
        return indicateurFr;
    }

    public void setIndicateurFr(String indicateurFr) {
        this.indicateurFr = indicateurFr;
    }

    public String getIndicateurUs() {
        return indicateurUs;
    }

    public void setIndicateurUs(String indicateurUs) {
        this.indicateurUs = indicateurUs;
    }

    public String getSourceVerificationFr() {
        return sourceVerificationFr;
    }

    public void setSourceVerificationFr(String sourceVerificationFr) {
        this.sourceVerificationFr = sourceVerificationFr;
    }

    public String getSourceVerificationUs() {
        return sourceVerificationUs;
    }

    public void setSourceVerificationUs(String sourceVerificationUs) {
        this.sourceVerificationUs = sourceVerificationUs;
    }

    public BigDecimal getAe() {
        return ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getCp() {
        return cp;
    }

    public void setCp(BigDecimal cp) {
        this.cp = cp;
    }



    public int getOrdreDansActivite() {
        return ordreDansActivite;
    }

    public void setOrdreDansActivite(int ordreDansActivite) {
        this.ordreDansActivite = ordreDansActivite;
    }

    public String getCompteCode() {
        return CompteCode;
    }

    public void setCompteCode(String CompteCode) {
        this.CompteCode = CompteCode;
    }

    public String getFinancementID() {
        return financementID;
    }

    public void setFinancementID(String financementID) {
        this.financementID = financementID;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getActiviteBudgetiseID() {
        return activiteBudgetiseID;
    }

    public void setActiviteBudgetiseID(String activiteBudgetiseID) {
        this.activiteBudgetiseID = activiteBudgetiseID;
    }

    public String getPosteComptableID() {
        return posteComptableID;
    }

    public void setPosteComptableID(String posteComptableID) {
        this.posteComptableID = posteComptableID;
    }

    public String getCompteLibelle() {
        return compteLibelle;
    }

    public void setCompteLibelle(String compteLibelle) {
        this.compteLibelle = compteLibelle;
    }

    public String getStructureAbbreviation() {
        return structureAbbreviation;
    }

    public void setStructureAbbreviation(String structureAbbreviation) {
        this.structureAbbreviation = structureAbbreviation;
    }

    public String getFinancementAbbreviation() {
        return financementAbbreviation;
    }

    public void setFinancementAbbreviation(String financementAbbreviation) {
        this.financementAbbreviation = financementAbbreviation;
    }

    public String getPosteComptableLibelle() {
        return posteComptableLibelle;
    }

    public void setPosteComptableLibelle(String posteComptableLibelle) {
        this.posteComptableLibelle = posteComptableLibelle;
    }

    public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }
    
    public String getLibelle(Locale locale){
        return locale == Locale.FRENCH?getLibelleFr():getLibelleUs();
    }

    public String getBudgetID() {
        return budgetID;
    }

    public void setBudgetID(String budgetID) {
        this.budgetID = budgetID;
    }

    public String getBudgetExploite() {
        return budgetExploite;
    }

    public void setBudgetExploite(String budgetExploite) {
        this.budgetExploite = budgetExploite;
    }

    public String getCalendrier() {
        return calendrier;
    }

    public void setCalendrier(String calendrier) {
        this.calendrier = calendrier;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (tacheID != null ? tacheID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaOperationBudgetaire)) {
            return false;
        }
        PrepaOperationBudgetaire other = (PrepaOperationBudgetaire) object;
        if ((this.tacheID == null && other.tacheID != null) || (this.tacheID != null && !this.tacheID.equals(other.tacheID))) {
            return false;
        }
        return true;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public BigDecimal getAECollectif() {
        return AECollectif;
    }

    public void setAECollectif(BigDecimal AECollectif) {
        this.AECollectif = AECollectif;
    }

    public BigDecimal getCPCollectif() {
        return CPCollectif;
    }

    public void setCPCollectif(BigDecimal CPCollectif) {
        this.CPCollectif = CPCollectif;
    }

    
    
    @Override
    public String toString() {
        return CompteCode+" - "+ getLibelle();
    }
    
}
