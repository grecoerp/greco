/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "rubrique")
public class Rubrique implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "ruId")
    private String ruId;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "numRubrique")
    private String numRubrique;
    @Basic(optional = false)
    @Column(name = "dateDebutValid")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDebutValid;
    @Basic(optional = false)
    @Column(name = "dateFinValid")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFinValid;
    @Basic(optional = false)
    @Column(name = "designation")
    private String designation;
    @Column(name = "definition")
    private String definition;

    public Rubrique() {
    }

    public Rubrique(String ruId) {
        this.ruId = ruId;
    }

    public Rubrique(String ruId, String millesime, String numRubrique, Date dateDebutValid, Date dateFinValid, String designation) {
        this.ruId = ruId;
        this.millesime = millesime;
        this.numRubrique = numRubrique;
        this.dateDebutValid = dateDebutValid;
        this.dateFinValid = dateFinValid;
        this.designation = designation;
    }

    public String getRuId() {
        return ruId;
    }

    public void setRuId(String ruId) {
        this.ruId = ruId;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getNumRubrique() {
        return numRubrique;
    }

    public void setNumRubrique(String numRubrique) {
        this.numRubrique = numRubrique;
    }

    public Date getDateDebutValid() {
        return dateDebutValid;
    }

    public void setDateDebutValid(Date dateDebutValid) {
        this.dateDebutValid = dateDebutValid;
    }

    public Date getDateFinValid() {
        return dateFinValid;
    }

    public void setDateFinValid(Date dateFinValid) {
        this.dateFinValid = dateFinValid;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ruId != null ? ruId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Rubrique)) {
            return false;
        }
        Rubrique other = (Rubrique) object;
        if ((this.ruId == null && other.ruId != null) || (this.ruId != null && !this.ruId.equals(other.ruId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return numRubrique+" - "+designation;
    }
    
}
