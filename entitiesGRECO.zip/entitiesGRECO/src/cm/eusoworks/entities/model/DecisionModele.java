/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "decisionmodele")
public class DecisionModele implements Serializable {
    @Column(name = "entete1Fr")
    private String entete1Fr;
    @Column(name = "entete1Us")
    private String entete1Us;
    @Column(name = "entete2Fr")
    private String entete2Fr;
    @Column(name = "entete2Us")
    private String entete2Us;
    @Column(name = "entete3Fr")
    private String entete3Fr;
    @Column(name = "entete3Us")
    private String entete3Us;
    @Column(name = "entete4Fr")
    private String entete4Fr;
    @Column(name = "entete4Us")
    private String entete4Us;
    @Column(name = "entete5Fr")
    private String entete5Fr;
    @Column(name = "entete5Us")
    private String entete5Us;
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "modeleID")
    private String modeleID;
    @Basic(optional = false)
    @Column(name = "description")
    private String description;
    @Lob
    @Column(name = "contenu")
    private String contenu;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;

    public DecisionModele() {
    }

    public DecisionModele(String modeleID) {
        this.modeleID = modeleID;
    }

    public DecisionModele(String modeleID, Date lastUpdate, String userUpdate, String description) {
        this.modeleID = modeleID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.description = description;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getModeleID() {
        return modeleID;
    }

    public void setModeleID(String modeleID) {
        this.modeleID = modeleID;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (modeleID != null ? modeleID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof DecisionModele)) {
            return false;
        }
        DecisionModele other = (DecisionModele) object;
        if ((this.modeleID == null && other.modeleID != null) || (this.modeleID != null && !this.modeleID.equals(other.modeleID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return description;
    }

    public String getEntete1Fr() {
        return entete1Fr;
    }

    public void setEntete1Fr(String entete1Fr) {
        this.entete1Fr = entete1Fr;
    }

    public String getEntete1Us() {
        return entete1Us;
    }

    public void setEntete1Us(String entete1Us) {
        this.entete1Us = entete1Us;
    }

    public String getEntete2Fr() {
        return entete2Fr;
    }

    public void setEntete2Fr(String entete2Fr) {
        this.entete2Fr = entete2Fr;
    }

    public String getEntete2Us() {
        return entete2Us;
    }

    public void setEntete2Us(String entete2Us) {
        this.entete2Us = entete2Us;
    }

    public String getEntete3Fr() {
        return entete3Fr;
    }

    public void setEntete3Fr(String entete3Fr) {
        this.entete3Fr = entete3Fr;
    }

    public String getEntete3Us() {
        return entete3Us;
    }

    public void setEntete3Us(String entete3Us) {
        this.entete3Us = entete3Us;
    }

    public String getEntete4Fr() {
        return entete4Fr;
    }

    public void setEntete4Fr(String entete4Fr) {
        this.entete4Fr = entete4Fr;
    }

    public String getEntete4Us() {
        return entete4Us;
    }

    public void setEntete4Us(String entete4Us) {
        this.entete4Us = entete4Us;
    }

    public String getEntete5Fr() {
        return entete5Fr;
    }

    public void setEntete5Fr(String entete5Fr) {
        this.entete5Fr = entete5Fr;
    }

    public String getEntete5Us() {
        return entete5Us;
    }

    public void setEntete5Us(String entete5Us) {
        this.entete5Us = entete5Us;
    }
    
}
