/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "agent")
public class Agent implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "matricule")
    private String matricule;
    @Column(name = "nom")
    private String nom;
    @Column(name = "nomJeuneFille")
    private String nomJeuneFille;
    @Column(name = "prenom")
    private String prenom;
    @Column(name = "dateNaissance")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateNaissance;
    @Column(name = "numCNI")
    private String numCNI;
    @Column(name = "millesime")
    private String millesime;
    @Column(name = "organisationID")
    private String organisationID;
    @Basic(optional = false)
    @Column(name = "matriculeBudgetaire")
    private boolean matriculeBudgetaire;
    @Basic(optional = false)
    @Column(name = "actif")
    private boolean actif;
    @Column(name = "import")
    private Boolean imported;

    public Agent() {
    }

    public Agent(String matricule) {
        this.matricule = matricule;
    }

    public Agent(String matricule, Date lastUpdate, String userUpdate, boolean matriculeBudgetaire, boolean actif) {
        this.matricule = matricule;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.matriculeBudgetaire = matriculeBudgetaire;
        this.actif = actif;
    }
    
    public Agent(String matricule, String nom, String nomJeuneFille, String prenom, Date dateNaissance, String numCNI, String userUpdate, 
                                    String ipUpdate) {
        this.matricule = matricule;
        this.nom = nom;
        this.nomJeuneFille = nomJeuneFille;
        this.prenom = prenom;
        this.dateNaissance = dateNaissance;
        this.numCNI = numCNI;
        this.userUpdate = userUpdate;
        this.ipUpdate = ipUpdate;
        this.matriculeBudgetaire = false;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getNomJeuneFille() {
        return nomJeuneFille;
    }

    public void setNomJeuneFille(String nomJeuneFille) {
        this.nomJeuneFille = nomJeuneFille;
    }

    public String getPrenom() {
        return prenom;
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getNomComplet(){
        String nomComplet = "";
        nomComplet = nom + (prenom==null?"":" "+prenom)+(nomJeuneFille==null || nomJeuneFille.isEmpty()?"":" "+nomJeuneFille);
        return nomComplet;
    }
    
    public Date getDateNaissance() {
        return dateNaissance;
    }

    public void setDateNaissance(Date dateNaissance) {
        this.dateNaissance = dateNaissance;
    }

    public String getNumCNI() {
        return numCNI;
    }

    public void setNumCNI(String numCNI) {
        this.numCNI = numCNI;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public boolean getMatriculeBudgetaire() {
        return matriculeBudgetaire;
    }

    public void setMatriculeBudgetaire(boolean matriculeBudgetaire) {
        this.matriculeBudgetaire = matriculeBudgetaire;
    }

    public boolean getActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    public Boolean isImported() {
        return imported;
    }

    public void setImported(Boolean imported) {
        this.imported = imported;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (matricule != null ? matricule.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Agent)) {
            return false;
        }
        Agent other = (Agent) object;
        if ((this.matricule == null && other.matricule != null) || (this.matricule != null && !this.matricule.equals(other.matricule))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return matricule + " - " + getNomComplet();
    }
    
}
