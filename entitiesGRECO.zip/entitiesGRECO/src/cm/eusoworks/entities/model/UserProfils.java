/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jeanemmanuel
 */

public class UserProfils implements Serializable {

    private static final long serialVersionUID = 1L;

    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String profilID;

    public UserProfils() {
    }

    public UserProfils(String profilID) {
        this.profilID = profilID;
    }

    public UserProfils(String profilID, Date lastUpdate, String userUpdate) {
        this.profilID = profilID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getProfilID() {
        return profilID;
    }

    public void setProfilID(String profilID) {
        this.profilID = profilID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (profilID != null ? profilID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserProfils)) {
            return false;
        }
        UserProfils other = (UserProfils) object;
        if ((this.profilID == null && other.profilID != null) || (this.profilID != null && !this.profilID.equals(other.profilID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "[ profilID=" + profilID + " ]";
    }
    
}
