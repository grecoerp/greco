/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author jeanemmanuel
 */
@Embeddable
public class CommerciauxClientPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "commercialID")
    private String commercialID;
    @Basic(optional = false)
    @Column(name = "clientID")
    private String clientID;

    public CommerciauxClientPK() {
    }

    public CommerciauxClientPK(String commercialID, String clientID) {
        this.commercialID = commercialID;
        this.clientID = clientID;
    }

    public String getCommercialID() {
        return commercialID;
    }

    public void setCommercialID(String commercialID) {
        this.commercialID = commercialID;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (commercialID != null ? commercialID.hashCode() : 0);
        hash += (clientID != null ? clientID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CommerciauxClientPK)) {
            return false;
        }
        CommerciauxClientPK other = (CommerciauxClientPK) object;
        if ((this.commercialID == null && other.commercialID != null) || (this.commercialID != null && !this.commercialID.equals(other.commercialID))) {
            return false;
        }
        if ((this.clientID == null && other.clientID != null) || (this.clientID != null && !this.clientID.equals(other.clientID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.CommerciauxClientPK[ commercialID=" + commercialID + ", clientID=" + clientID + " ]";
    }
    
}
