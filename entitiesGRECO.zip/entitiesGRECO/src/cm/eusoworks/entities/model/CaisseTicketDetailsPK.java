/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author jeanemmanuel
 */
@Embeddable
public class CaisseTicketDetailsPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "ticketDetailsID")
    private String ticketDetailsID;
    @Basic(optional = false)
    @Column(name = "ticketID")
    private String ticketID;
    @Basic(optional = false)
    @Column(name = "amId")
    private String amId;

    public CaisseTicketDetailsPK() {
    }

    public CaisseTicketDetailsPK(String ticketDetailsID, String ticketID, String amId) {
        this.ticketDetailsID = ticketDetailsID;
        this.ticketID = ticketID;
        this.amId = amId;
    }

    public String getTicketDetailsID() {
        return ticketDetailsID;
    }

    public void setTicketDetailsID(String ticketDetailsID) {
        this.ticketDetailsID = ticketDetailsID;
    }

    public String getTicketID() {
        return ticketID;
    }

    public void setTicketID(String ticketID) {
        this.ticketID = ticketID;
    }

    public String getAmId() {
        return amId;
    }

    public void setAmId(String amId) {
        this.amId = amId;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ticketDetailsID != null ? ticketDetailsID.hashCode() : 0);
        hash += (ticketID != null ? ticketID.hashCode() : 0);
        hash += (amId != null ? amId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseTicketDetailsPK)) {
            return false;
        }
        CaisseTicketDetailsPK other = (CaisseTicketDetailsPK) object;
        if ((this.ticketDetailsID == null && other.ticketDetailsID != null) || (this.ticketDetailsID != null && !this.ticketDetailsID.equals(other.ticketDetailsID))) {
            return false;
        }
        if ((this.ticketID == null && other.ticketID != null) || (this.ticketID != null && !this.ticketID.equals(other.ticketID))) {
            return false;
        }
        if ((this.amId == null && other.amId != null) || (this.amId != null && !this.amId.equals(other.amId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.CaisseTicketDetailsPK[ ticketDetailsID=" + ticketDetailsID + ", ticketID=" + ticketID + ", amId=" + amId + " ]";
    }
    
}
