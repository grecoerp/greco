/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "structure")
public class Structure implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "structureID")
    private String structureID;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Column(name = "abbreviationFr")
    private String abbreviationFr;
    @Column(name = "abbreviationUs")
    private String abbreviationUs;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "dateCreation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreation;
    @Column(name = "dateCessation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCessation;
    @Basic(optional = false)
    @Column(name = "actif")
    private boolean actif;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;
    @Basic(optional = false)
    @Column(name = "CategorieCode")
    private String categorieCode;
    @Basic(optional = false)
    @Column(name = "FonctionCode")
    private String fonctionCode;
    @Basic(optional = false)
    @Column(name = "LocaliteCode")
    private String localiteCode;
    @Basic(optional = false)
    @Column(name = "posteComptableID")
    private String posteComptableID;
    @Column(name = "structureParentID")
    private String structureParentID;
    @Basic(optional = false)
    @Column(name = "uniteOrganiqueID")
    private String uniteOrganiqueID;
    
    private int childs;
    private boolean checked;

    public Structure() {
    }

    public Structure(String structureID) {
        this.structureID = structureID;
    }
    
    public Structure(String structureID, String libelle) {
        this.structureID = structureID;
        this.libelleFr = libelle;
    }

    public Structure(String structureID, Date lastUpdate, String userUpdate, String code, String libelleFr, Date dateCreation, boolean actif) {
        this.structureID = structureID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.code = code;
        this.libelleFr = libelleFr;
        this.dateCreation = dateCreation;
        this.actif = actif;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAbbreviationFr() {
        return abbreviationFr;
    }

    public void setAbbreviationFr(String abbreviationFr) {
        this.abbreviationFr = abbreviationFr;
    }

    public String getAbbreviationUs() {
        return abbreviationUs;
    }

    public void setAbbreviationUs(String abbreviationUs) {
        this.abbreviationUs = abbreviationUs;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Date getDateCessation() {
        return dateCessation;
    }

    public void setDateCessation(Date dateCessation) {
        this.dateCessation = dateCessation;
    }

    public boolean getActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getCategorieCode() {
        return categorieCode;
    }

    public void setCategorieCode(String categorieCode) {
        this.categorieCode = categorieCode;
    }

    public String getFonctionCode() {
        return fonctionCode;
    }

    public void setFonctionCode(String fonctionCode) {
        this.fonctionCode = fonctionCode;
    }

    public String getLocaliteCode() {
        return localiteCode;
    }

    public void setLocaliteCode(String localiteCode) {
        this.localiteCode = localiteCode;
    }

    public String getPosteComptableID() {
        return posteComptableID;
    }

    public void setPosteComptableID(String posteComptableID) {
        this.posteComptableID = posteComptableID;
    }

    public String getUniteOrganiqueID() {
        return uniteOrganiqueID;
    }

    public void setUniteOrganiqueID(String uniteOrganiqueID) {
        this.uniteOrganiqueID = uniteOrganiqueID;
    }

    public String getStructureParentID() {
        return structureParentID;
    }

    public void setStructureParentID(String structureParentID) {
        this.structureParentID = structureParentID;
    }
    
    public String getLibelle(Locale locale) {
        if(locale == Locale.FRENCH) return libelleFr;
        else return libelleUs;
    }
    
    public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }

    public int getChilds() {
        return childs;
    }

    public void setChilds(int childs) {
        this.childs = childs;
    }
    
    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (structureID != null ? structureID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Structure)) {
            return false;
        }
        Structure other = (Structure) object;
        if ((this.structureID == null && other.structureID != null) || (this.structureID != null && !this.structureID.equals(other.structureID))) {
            return false;
        }
        return true;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        String ab = "";
        if(abbreviationFr != null){
            ab = abbreviationFr;
        }
        String s = ab.concat("      ");
        return s.substring(0, 6)+" " + getLibelle();
    }
    
}
