/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;

/**
 *
 * @author macbook
 */

public class ComptaLibelle implements Serializable {

    private static final long serialVersionUID = 1L;

    private String organisationID;
    private String code;
    private String libelle;

    public ComptaLibelle() {
        code = "";
    }

    public ComptaLibelle(String code) {
        this.code = code;
    }

    public ComptaLibelle(String code, String libelle) {
        this.code = code;
        this.libelle = libelle;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelle() {
        return libelle;
    }

    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }

  
    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ComptaLibelle)) {
            return false;
        }
        ComptaLibelle other = (ComptaLibelle) object;
        if ((this.code == null && other.code != null) || (this.code != null && !this.code.equals(other.code))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return libelle;
    }
    
}
