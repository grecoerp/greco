/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author DGLS
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class PrepaMarchePhasage implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "paId")
    protected String paId;
    @Column(name = "annee1")
    protected Integer annee1;
    @Lob
    @Column(name = "intitule1")
    protected String intitule1;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "cout1")
    protected BigDecimal cout1;
    @Column(name = "annee2")
    protected Integer annee2;
    @Lob
    @Column(name = "intitule2")
    protected String intitule2;
    @Column(name = "cout2")
    protected BigDecimal cout2;
    @Column(name = "annee3")
    protected Integer annee3;
    @Lob
    @Column(name = "intitule3")
    protected String intitule3;
    @Column(name = "cout3")
    protected BigDecimal cout3;
    @Column(name = "annee4")
    protected Integer annee4;
    @Lob
    @Column(name = "intitule4")
    protected String intitule4;
    @Column(name = "cout4")
    protected BigDecimal cout4;
    @Column(name = "annee5")
    protected Integer annee5;
    @Lob
    @Column(name = "intitule5")
    protected String intitule5;
    @Column(name = "cout5")
    protected BigDecimal cout5;
    @Column(name = "userMaj")
    protected String userMaj;
    @Column(name = "dateMaj")
    @Temporal(TemporalType.TIMESTAMP)
    protected Date dateMaj;

    public PrepaMarchePhasage() {
    }

    public PrepaMarchePhasage(String paId) {
        this.paId = paId;
    }

    public String getPaId() {
        return paId;
    }

    public void setPaId(String paId) {
        this.paId = paId;
    }

    public Integer getAnnee1() {
        return annee1;
    }

    public void setAnnee1(Integer annee1) {
        this.annee1 = annee1;
    }

    public String getIntitule1() {
        return intitule1;
    }

    public void setIntitule1(String intitule1) {
        this.intitule1 = intitule1;
    }

    public BigDecimal getCout1() {
        return cout1;
    }

    public void setCout1(BigDecimal cout1) {
        this.cout1 = cout1;
    }

    public Integer getAnnee2() {
        return annee2;
    }

    public void setAnnee2(Integer annee2) {
        this.annee2 = annee2;
    }

    public String getIntitule2() {
        return intitule2;
    }

    public void setIntitule2(String intitule2) {
        this.intitule2 = intitule2;
    }

    public BigDecimal getCout2() {
        return cout2;
    }

    public void setCout2(BigDecimal cout2) {
        this.cout2 = cout2;
    }

    public Integer getAnnee3() {
        return annee3;
    }

    public void setAnnee3(Integer annee3) {
        this.annee3 = annee3;
    }

    public String getIntitule3() {
        return intitule3;
    }

    public void setIntitule3(String intitule3) {
        this.intitule3 = intitule3;
    }

    public BigDecimal getCout3() {
        return cout3;
    }

    public void setCout3(BigDecimal cout3) {
        this.cout3 = cout3;
    }

    public Integer getAnnee4() {
        return annee4;
    }

    public void setAnnee4(Integer annee4) {
        this.annee4 = annee4;
    }

    public String getIntitule4() {
        return intitule4;
    }

    public void setIntitule4(String intitule4) {
        this.intitule4 = intitule4;
    }

    public BigDecimal getCout4() {
        return cout4;
    }

    public void setCout4(BigDecimal cout4) {
        this.cout4 = cout4;
    }

    public Integer getAnnee5() {
        return annee5;
    }

    public void setAnnee5(Integer annee5) {
        this.annee5 = annee5;
    }

    public String getIntitule5() {
        return intitule5;
    }

    public void setIntitule5(String intitule5) {
        this.intitule5 = intitule5;
    }

    public BigDecimal getCout5() {
        return cout5;
    }

    public void setCout5(BigDecimal cout5) {
        this.cout5 = cout5;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (paId != null ? paId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaMarchePhasage)) {
            return false;
        }
        PrepaMarchePhasage other = (PrepaMarchePhasage) object;
        if ((this.paId == null && other.paId != null) || (this.paId != null && !this.paId.equals(other.paId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.siic.dgls.marche.generated.GenMarchePhasage[ paId=" + paId + " ]";
    }
    
}
