/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "DEVISE")
public class Devise implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "deviseID")
    private String deviseID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Column(name = "symbole")
    private String symbole;
    @Basic(optional = false)
    @Column(name = "isCourante")
    private boolean isCourante;
    @Basic(optional = false)
    @Column(name = "changeAchat")
    private BigDecimal changeAchat;
    @Basic(optional = false)
    @Column(name = "changeVente")
    private BigDecimal changeVente;
    

    public Devise() {
    }

    public Devise(String deviseID) {
        this.deviseID = deviseID;
    }

    public Devise(String deviseID, Date lastUpdate, String userUpdate, String libelleFr, boolean isCourante, long change) {
        this.deviseID = deviseID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.isCourante = isCourante;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getDeviseID() {
        return deviseID;
    }

    public void setDeviseID(String deviseID) {
        this.deviseID = deviseID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getSymbole() {
        return symbole;
    }

    public void setSymbole(String symbole) {
        this.symbole = symbole;
    }

    public boolean getIsCourante() {
        return isCourante;
    }

    public void setIsCourante(boolean isCourante) {
        this.isCourante = isCourante;
    }

    public BigDecimal getChangeAchat() {
        return changeAchat;
    }

    public void setChangeAchat(BigDecimal changeAchat) {
        this.changeAchat = changeAchat;
    }

    public BigDecimal getChangeVente() {
        return changeVente;
    }

    public void setChangeVente(BigDecimal changeVente) {
        this.changeVente = changeVente;
    }

    

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (deviseID != null ? deviseID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Devise)) {
            return false;
        }
        Devise other = (Devise) object;
        if ((this.deviseID == null && other.deviseID != null) || (this.deviseID != null && !this.deviseID.equals(other.deviseID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.Devise[ deviseID=" + deviseID + " ]";
    }
    
}
