/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "sousrubrique")
public class SousRubrique implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "srId")
    private String srId;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "numRubrique")
    private String numRubrique;
    @Basic(optional = false)
    @Column(name = "numSousRubrique")
    private String numSousRubrique;
    @Basic(optional = false)
    @Column(name = "dateDebutValid")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDebutValid;
    @Basic(optional = false)
    @Column(name = "dateFinValid")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFinValid;
    @Basic(optional = false)
    @Column(name = "designation")
    private String designation;
    @Column(name = "definition")
    private String definition;
    @Column(name = "ruId")
    private String ruId;


    public SousRubrique() {
    }

    public SousRubrique(String srId) {
        this.srId = srId;
    }

    public SousRubrique(String srId, String millesime, String numRubrique, String numSousRubrique, Date dateDebutValid, Date dateFinValid, String designation) {
        this.srId = srId;
        this.millesime = millesime;
        this.numRubrique = numRubrique;
        this.numSousRubrique = numSousRubrique;
        this.dateDebutValid = dateDebutValid;
        this.dateFinValid = dateFinValid;
        this.designation = designation;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getNumRubrique() {
        return numRubrique;
    }

    public void setNumRubrique(String numRubrique) {
        this.numRubrique = numRubrique;
    }

    public String getNumSousRubrique() {
        return numSousRubrique;
    }

    public void setNumSousRubrique(String numSousRubrique) {
        this.numSousRubrique = numSousRubrique;
    }

    public Date getDateDebutValid() {
        return dateDebutValid;
    }

    public void setDateDebutValid(Date dateDebutValid) {
        this.dateDebutValid = dateDebutValid;
    }

    public Date getDateFinValid() {
        return dateFinValid;
    }

    public void setDateFinValid(Date dateFinValid) {
        this.dateFinValid = dateFinValid;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getDefinition() {
        return definition;
    }

    public void setDefinition(String definition) {
        this.definition = definition;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (srId != null ? srId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SousRubrique)) {
            return false;
        }
        SousRubrique other = (SousRubrique) object;
        if ((this.srId == null && other.srId != null) || (this.srId != null && !this.srId.equals(other.srId))) {
            return false;
        }
        return true;
    }

    public String getRuId() {
        return ruId;
    }

    public void setRuId(String ruId) {
        this.ruId = ruId;
    }

    @Override
    public String toString() {
        return numSousRubrique+" - "+designation;
    }
    
}
