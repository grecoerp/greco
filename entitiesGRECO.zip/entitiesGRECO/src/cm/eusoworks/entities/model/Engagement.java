/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "engagement")

public class Engagement implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "engagementID")
    private String engagementID;
    @Basic(optional = false)
    @Column(name = "numDossier")
    private String numDossier;
    @Basic(optional = false)
    @Column(name = "etat")
    private int etat;
    @Column(name = "dateValidation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateValidation;
    @Basic(optional = false)
    @Column(name = "reference")
    private String reference;
    @Basic(optional = false)
    @Column(name = "objet")
    private String objet;
    @Column(name = "dateSignature")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateSignature;
    @Column(name = "signataire")
    private String signataire;
    @Basic(optional = false)
    @Column(name = "montantTTC")
    private BigDecimal montantTTC;
    @Column(name = "montantTAXE")
    private BigDecimal montantTAXE;
    @Column(name = "montantNAP")
    private BigDecimal montantNAP;
    @Column(name = "montantRG")
    private BigDecimal montantRG;
    @Basic(optional = false)
    @Column(name = "beneficiaire")
    private String beneficiaire;
    @Column(name = "fournisseurID")
    private String fournisseurID;
    @Column(name = "matricule")
    private String matricule;
    @Column(name = "structureBenefID")
    private String structureBenefID;
    @Basic(optional = false)
    @Column(name = "tacheID")
    private String tacheID;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "activiteID")
    private String activiteID;
    @Basic(optional = false)
    @Column(name = "structureID")
    private String structureID;
    @Basic(optional = false)
    @Column(name = "typeID")
    private String typeID;
    @Basic(optional = false)
    @Column(name = "gestionnaire")
    private String gestionnaire;
    @Column(name = "decisionID")
    private String decisionID;
    @Column(name = "bcaID")
    private String bcaID;
    @Column(name = "omID")
    private String omID;
    @Column(name = "captcha")
    private String captcha;
    
    private String rib;
    private boolean depassement;
   
    // proprietes file d'attente
    private String numeroOPNet;
    private String numeroOPTaxe;
    private BigDecimal montantNet;
    private BigDecimal montantTaxe;
    private String codeTache;

    public Engagement() {
    }

    public Engagement(String engagementID) {
        this.engagementID = engagementID;
    }

    public Engagement(String engagementID, Date lastUpdate, String userUpdate, String numDossier, int etat, String reference, BigDecimal montantTTC, String beneficiaire) {
        this.engagementID = engagementID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.numDossier = numDossier;
        this.etat = etat;
        this.reference = reference;
        this.montantTTC = montantTTC;
        this.beneficiaire = beneficiaire;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getEngagementID() {
        return engagementID;
    }

    public void setEngagementID(String engagementID) {
        this.engagementID = engagementID;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public Date getDateValidation() {
        return dateValidation;
    }

    public void setDateValidation(Date dateValidation) {
        this.dateValidation = dateValidation;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public String getSignataire() {
        return signataire;
    }

    public void setSignataire(String signataire) {
        this.signataire = signataire;
    }


    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public String getFournisseurID() {
        return fournisseurID;
    }

    public void setFournisseurID(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getStructureBenefID() {
        return structureBenefID;
    }

    public void setStructureBenefID(String structureBenefID) {
        this.structureBenefID = structureBenefID;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getTypeID() {
        return typeID;
    }

    public void setTypeID(String typeID) {
        this.typeID = typeID;
    }

    public String getGestionnaire() {
        return gestionnaire;
    }

    public void setGestionnaire(String gestionnaire) {
        this.gestionnaire = gestionnaire;
    }

    public String getDecisionID() {
        return decisionID;
    }

    public void setDecisionID(String decisionID) {
        this.decisionID = decisionID;
    }

    public String getBcaID() {
        return bcaID;
    }

    public void setBcaID(String bcaID) {
        this.bcaID = bcaID;
    }

    public String getOmID() {
        return omID;
    }

    public void setOmID(String omID) {
        this.omID = omID;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public BigDecimal getMontantTAXE() {
        return montantTAXE;
    }

    public void setMontantTAXE(BigDecimal montantTAXE) {
        this.montantTAXE = montantTAXE;
    }

    public BigDecimal getMontantNAP() {
        return montantNAP;
    }

    public void setMontantNAP(BigDecimal montantNAP) {
        this.montantNAP = montantNAP;
    }

    public BigDecimal getMontantRG() {
        return montantRG;
    }

    public void setMontantRG(BigDecimal montantRG) {
        this.montantRG = montantRG;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (engagementID != null ? engagementID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Engagement)) {
            return false;
        }
        Engagement other = (Engagement) object;
        if ((this.engagementID == null && other.engagementID != null) || (this.engagementID != null && !this.engagementID.equals(other.engagementID))) {
            return false;
        }
        return true;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public boolean isDepassement() {
        return depassement;
    }

    public void setDepassement(boolean depassement) {
        this.depassement = depassement;
    }

    
    @Override
    public String toString() {
        return "["+numDossier+"] "+ beneficiaire + " - "+objet;
    }

    public String getNumeroOPNet() {
        return numeroOPNet;
    }

    public void setNumeroOPNet(String numeroOPNet) {
        this.numeroOPNet = numeroOPNet;
    }

    public String getNumeroOPTaxe() {
        return numeroOPTaxe;
    }

    public void setNumeroOPTaxe(String numeroOPTaxe) {
        this.numeroOPTaxe = numeroOPTaxe;
    }

    public BigDecimal getMontantNet() {
        return montantNet;
    }

    public void setMontantNet(BigDecimal montantNet) {
        this.montantNet = montantNet;
    }

    public BigDecimal getMontantTaxe() {
        return montantTaxe;
    }

    public void setMontantTaxe(BigDecimal montantTaxe) {
        this.montantTaxe = montantTaxe;
    }

    public String getCodeTache() {
        return codeTache;
    }

    public void setCodeTache(String codeTache) {
        this.codeTache = codeTache;
    }
    
}
