/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "CLIENTGROUPE")
public class ClientGroupe implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "groupeClientID")
    private String groupeClientID;
    @Column(name = "libelleFr")
    private String libelleFr;


    public ClientGroupe() {
    }

    public ClientGroupe(String groupeClientID) {
        this.groupeClientID = groupeClientID;
    }

    public ClientGroupe(String groupeClientID, Date lastUpdate, String userUpdate) {
        this.groupeClientID = groupeClientID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getGroupeClientID() {
        return groupeClientID;
    }

    public void setGroupeClientID(String groupeClientID) {
        this.groupeClientID = groupeClientID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (groupeClientID != null ? groupeClientID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ClientGroupe)) {
            return false;
        }
        ClientGroupe other = (ClientGroupe) object;
        if ((this.groupeClientID == null && other.groupeClientID != null) || (this.groupeClientID != null && !this.groupeClientID.equals(other.groupeClientID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.ClientGroupe[ groupeClientID=" + groupeClientID + " ]";
    }
    
}
