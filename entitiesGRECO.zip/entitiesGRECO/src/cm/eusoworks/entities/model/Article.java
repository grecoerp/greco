/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "article")
public class Article implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "amId")
    private String amId;
    @Column(name = "millesime")
    private String millesime;
    @Column(name = "numRubrique")
    private String numRubrique;
    @Column(name = "numSousRubrique")
    private String numSousRubrique;
    @Column(name = "refArticle")
    private String refArticle;
    @Column(name = "dateDebutValid")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDebutValid;
    @Column(name = "dateFinValid")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFinValid;
    @Column(name = "designation")
    private String designation;
    @Column(name = "conditionnement")
    private String conditionnement;
    @Column(name = "prixDeReference")
    private BigDecimal prixDeReference;
    @Column(name = "srId")
    private String srId;

    private float quantite = 1f;
    private BigDecimal prixUnitaire;
    private BigDecimal prixTotal;
    private BigDecimal prixMax;
    private boolean prixValide = true;
    private int numOrdre;
    private BigDecimal remise = BigDecimal.ZERO;

    public Article() {
    }

    public Article(String amId) {
        this.amId = amId;
    }

    public String getAmId() {
        return amId;
    }

    public void setAmId(String amId) {
        this.amId = amId;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getNumRubrique() {
        return numRubrique;
    }

    public void setNumRubrique(String numRubrique) {
        this.numRubrique = numRubrique;
    }

    public String getNumSousRubrique() {
        return numSousRubrique;
    }

    public void setNumSousRubrique(String numSousRubrique) {
        this.numSousRubrique = numSousRubrique;
    }

    public String getRefArticle() {
        return refArticle;
    }

    public void setRefArticle(String refArticle) {
        this.refArticle = refArticle;
    }

    public Date getDateDebutValid() {
        return dateDebutValid;
    }

    public void setDateDebutValid(Date dateDebutValid) {
        this.dateDebutValid = dateDebutValid;
    }

    public Date getDateFinValid() {
        return dateFinValid;
    }

    public void setDateFinValid(Date dateFinValid) {
        this.dateFinValid = dateFinValid;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public String getConditionnement() {
        return conditionnement;
    }

    public void setConditionnement(String conditionnement) {
        this.conditionnement = conditionnement;
    }

    public BigDecimal getPrixDeReference() {
        return prixDeReference;
    }

    public void setPrixDeReference(BigDecimal prixDeReference) {
        this.prixDeReference = prixDeReference;
    }

    public String getSrId() {
        return srId;
    }

    public void setSrId(String srId) {
        this.srId = srId;
    }

    public float getQuantite() {
        return quantite;
    }

    public void setQuantite(float qte) {
        this.quantite = qte;
    }

    public BigDecimal getPrixUnitaire() {
        return prixUnitaire;
    }

    public BigDecimal getRemise() {
        return remise;
    }

    public void setRemise(BigDecimal remise) {
        this.remise = remise;
    }
    
    public void setPrixUnitaire(BigDecimal prixUnitaire) {
        this.prixUnitaire = prixUnitaire;
        Number prix = prixUnitaire;
        Number prixMax = this.prixMax == null ? BigDecimal.ZERO : this.prixMax ;
        if(prix.longValue() > prixMax.longValue()){
            prixValide = false;
        }else {
            prixValide = true;
        }
    }

    public BigDecimal getPrixTotal() {
        return prixTotal == null ? BigDecimal.ZERO:prixTotal;
    }

    public void setPrixTotal(BigDecimal prixTotal) {
        this.prixTotal = prixTotal;
    }

    public boolean isPrixValide() {
        return prixValide;
    }

    public void setPrixValide(boolean prixValide) {
        this.prixValide = prixValide;
    }

    public BigDecimal getPrixMax() {
        return prixMax;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }
    
    public void setPrixMax(BigDecimal prixMax) {
        this.prixMax = prixMax;
        
        Number prix = prixUnitaire;
        if(prix.longValue() > prixMax.longValue()){
            prixValide = false;
        }else {
            prixValide = true;
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (amId != null ? amId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Article)) {
            return false;
        }
        Article other = (Article) object;
        if ((this.amId == null && other.amId != null) || (this.amId != null && !this.amId.equals(other.amId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return refArticle + " - " + designation;
    }

}
