/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "bca")
public class Bca implements Serializable {
    
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "bcaID")
    private String bcaID;
    @Basic(optional = false)
    @Column(name = "objet")
    private String objet;
    @Column(name = "reference")
    private String reference;
    @Column(name = "delaiLivraison")
    @Temporal(TemporalType.TIMESTAMP)
    private Date delaiLivraison;
    @Column(name = "dateSignature")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateSignature;
    @Column(name = "lieuSignature")
    private String lieuSignature;
    @Column(name = "entete1")
    private String entete1;
    @Column(name = "entete2")
    private String entete2;
    @Column(name = "entete3")
    private String entete3;
    @Column(name = "entete4")
    private String entete4;
    @Column(name = "entete5")
    private String entete5;
    @Column(name = "montantTTC")
    private BigDecimal montantTTC;
    @Column(name = "montantHT")
    private BigDecimal montantHT;
    @Column(name = "nap")
    private BigDecimal nap;
    @Column(name = "tauxTVA")
    private Float tauxTVA;
    @Column(name = "tauxIR")
    private Float tauxIR;
    @Column(name = "fournisseurID")
    private String fournisseurID;
    @Column(name = "matriculeOrdo")
    private String matriculeOrdo;
    @Column(name = "tacheID")
    private String tacheID;
    @Column(name = "organisationID")
    private String organisationID;
    @Column(name = "millesime")
    private String millesime;
    @Column(name = "activiteID")
    private String activiteID;
    @Column(name = "structureID")
    private String structureID;
    
    private String fournisseur;
    private String budgetExploite;
    private String rib;
    private int etat;
    
    private BigDecimal montantRG;
    private String typeID;

    public Bca() {
    }

    public Bca(String bcaID) {
        this.bcaID = bcaID;
    }

    public Bca(String bcaID, Date lastUpdate, String userUpdate, String objet) {
        this.bcaID = bcaID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.objet = objet;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getBcaID() {
        return bcaID;
    }

    public void setBcaID(String bcaID) {
        this.bcaID = bcaID;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Date getDelaiLivraison() {
        return delaiLivraison;
    }

    public void setDelaiLivraison(Date delaiLivraison) {
        this.delaiLivraison = delaiLivraison;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public String getLieuSignature() {
        return lieuSignature;
    }

    public void setLieuSignature(String lieuSignature) {
        this.lieuSignature = lieuSignature;
    }

    public String getEntete1() {
        return entete1;
    }

    public void setEntete1(String entete1) {
        this.entete1 = entete1;
    }

    public String getEntete2() {
        return entete2;
    }

    public void setEntete2(String entete2) {
        this.entete2 = entete2;
    }

    public String getEntete3() {
        return entete3;
    }

    public void setEntete3(String entete3) {
        this.entete3 = entete3;
    }

    public String getEntete4() {
        return entete4;
    }

    public void setEntete4(String entete4) {
        this.entete4 = entete4;
    }

    public String getEntete5() {
        return entete5;
    }

    public void setEntete5(String entete5) {
        this.entete5 = entete5;
    }

    public Float getTauxTVA() {
        return tauxTVA;
    }

    public void setTauxTVA(Float tauxTVA) {
        this.tauxTVA = tauxTVA;
    }

    public Float getTauxIR() {
        return tauxIR;
    }

    public void setTauxIR(Float tauxIR) {
        this.tauxIR = tauxIR;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public BigDecimal getMontantHT() {
        return montantHT;
    }

    public void setMontantHT(BigDecimal montantHT) {
        this.montantHT = montantHT;
    }

    public BigDecimal getNap() {
        return nap;
    }

    public void setNap(BigDecimal nap) {
        this.nap = nap;
    }

    public String getFournisseurID() {
        return fournisseurID;
    }

    public void setFournisseurID(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public String getMatriculeOrdo() {
        return matriculeOrdo;
    }

    public void setMatriculeOrdo(String matriculeOrdo) {
        this.matriculeOrdo = matriculeOrdo;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getFournisseur() {
        return fournisseur;
    }

    public void setFournisseur(String fournisseur) {
        this.fournisseur = fournisseur;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bcaID != null ? bcaID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bca)) {
            return false;
        }
        Bca other = (Bca) object;
        if ((this.bcaID == null && other.bcaID != null) || (this.bcaID != null && !this.bcaID.equals(other.bcaID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return reference+" ["+fournisseur+"]"+" "+objet;
    }

    public String getBudgetExploite() {
        return budgetExploite;
    }

    public void setBudgetExploite(String budgetExploite) {
        this.budgetExploite = budgetExploite;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public BigDecimal getMontantRG() {
        return montantRG;
    }

    public void setMontantRG(BigDecimal montantRG) {
        this.montantRG = montantRG;
    }

    public String getTypeID() {
        return typeID;
    }

    public void setTypeID(String typeID) {
        this.typeID = typeID;
    }
    
}
