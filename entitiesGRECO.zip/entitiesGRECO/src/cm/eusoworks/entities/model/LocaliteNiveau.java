/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "LOCALITENIVEAU")
@NamedQueries({
    @NamedQuery(name = "LocaliteNiveau.findAll", query = "SELECT l FROM LocaliteNiveau l")})
public class LocaliteNiveau implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "niveauLocaliteID")
    private Integer niveauLocaliteID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Basic(optional = false)
    @Column(name = "libelleUs")
    private String libelleUs;
    @Column(name = "r")
    private Integer r;
    @Column(name = "g")
    private Integer g;
    @Column(name = "b")
    private Integer b;
    @Basic(optional = false)
    @Column(name = "mask")
    private String mask;

    public LocaliteNiveau() {
    }

    public LocaliteNiveau(Integer niveauLocaliteID) {
        this.niveauLocaliteID = niveauLocaliteID;
    }

    public LocaliteNiveau(Integer niveauLocaliteID, Date lastUpdate, String userUpdate, String libelleFr, String libelleUs) {
        this.niveauLocaliteID = niveauLocaliteID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public Integer getNiveauLocaliteID() {
        return niveauLocaliteID;
    }

    public void setNiveauLocaliteID(Integer niveauLocaliteID) {
        this.niveauLocaliteID = niveauLocaliteID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Integer getR() {
        return r;
    }

    public void setR(Integer r) {
        this.r = r;
    }

    public Integer getG() {
        return g;
    }

    public void setG(Integer g) {
        this.g = g;
    }

    public Integer getB() {
        return b;
    }

    public void setB(Integer b) {
        this.b = b;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (niveauLocaliteID != null ? niveauLocaliteID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof LocaliteNiveau)) {
            return false;
        }
        LocaliteNiveau other = (LocaliteNiveau) object;
        if ((this.niveauLocaliteID == null && other.niveauLocaliteID != null) || (this.niveauLocaliteID != null && !this.niveauLocaliteID.equals(other.niveauLocaliteID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return niveauLocaliteID.toString()+" - "+getLibelle(Locale.getDefault());
    }
    public String getLibelle(Locale locale) {
        return locale==Locale.FRENCH?getLibelleFr():getLibelleUs();
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }
}
