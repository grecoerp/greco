/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "UNITEORGANIQUE")
public class UniteOrganique implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "uniteOrganiqueID")
    private String uniteOrganiqueID;
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "ordre")
    private int ordre;
    @Column(name = "r")
    private Integer r;
    @Column(name = "g")
    private Integer g;
    @Column(name = "b")
    private Integer b;
    @Basic(optional = false)
    @Column(name = "uniteOrganiqueParentID")
    private String uniteOrganiqueParentID;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;

    private String missionsFr;
    private String missionsUs;
    
    
    public UniteOrganique() {
    }

    public UniteOrganique(String uniteOrganiqueID) {
        this.uniteOrganiqueID = uniteOrganiqueID;
    }

    public UniteOrganique(String uniteOrganiqueID, Date lastUpdate, String userUpdate, int ordre) {
        this.uniteOrganiqueID = uniteOrganiqueID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.ordre = ordre;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getUniteOrganiqueID() {
        return uniteOrganiqueID;
    }

    public void setUniteOrganiqueID(String uniteOrganiqueID) {
        this.uniteOrganiqueID = uniteOrganiqueID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getLibelle(Locale locale) {
        return locale==Locale.FRENCH?getLibelleFr():getLibelleUs();
    }
    
    public int getOrdre() {
        return ordre;
    }

    public void setOrdre(int ordre) {
        this.ordre = ordre;
    }

    public Integer getR() {
        return r;
    }

    public void setR(Integer r) {
        this.r = r;
    }

    public Integer getG() {
        return g;
    }

    public void setG(Integer g) {
        this.g = g;
    }

    public Integer getB() {
        return b;
    }

    public void setB(Integer b) {
        this.b = b;
    }

    public String getUniteOrganiqueParentID() {
        return uniteOrganiqueParentID;
    }

    public void setUniteOrganiqueParentID(String uniteOrganiqueParentID) {
        this.uniteOrganiqueParentID = uniteOrganiqueParentID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMissionsFr() {
        return missionsFr;
    }

    public void setMissionsFr(String missionsFr) {
        this.missionsFr = missionsFr;
    }

    public String getMissionsUs() {
        return missionsUs;
    }

    public void setMissionsUs(String missionsUs) {
        this.missionsUs = missionsUs;
    }
    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uniteOrganiqueID != null ? uniteOrganiqueID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UniteOrganique)) {
            return false;
        }
        UniteOrganique other = (UniteOrganique) object;
        if ((this.uniteOrganiqueID == null && other.uniteOrganiqueID != null) || (this.uniteOrganiqueID != null && !this.uniteOrganiqueID.equals(other.uniteOrganiqueID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getLibelle(Locale.getDefault());
    }
    
}
