/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "SYSTEME")
public class Systeme implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "systemeID")
    private String systemeID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "numOrdre")
    private int numOrdre;
    
    private boolean habilite = false;

    public static final String STRATEGIE = "1";
    public static final String PREVISION = "2";
    public static final String EXECUTION = "3";
    public static final String COMPTABILITE = "4";
    public static final String ADMINISTRATION = "5";
    
    
    public Systeme() {
    }

    public Systeme(String systemeID) {
        this.systemeID = systemeID;
    }

    public Systeme(String systemeID, Date lastUpdate, String userUpdate, String libelleFr, int numOrdre) {
        this.systemeID = systemeID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.numOrdre = numOrdre;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getSystemeID() {
        return systemeID;
    }

    public void setSystemeID(String systemeID) {
        this.systemeID = systemeID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (systemeID != null ? systemeID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Systeme)) {
            return false;
        }
        Systeme other = (Systeme) object;
        return (this.systemeID != null || other.systemeID == null) && (this.systemeID == null || this.systemeID.equals(other.systemeID));
    }

    @Override
    public String toString() {
        return  getLibelle(Locale.getDefault());
    }

    public boolean isHabilite() {
        return habilite;
    }

    public void setHabilite(boolean habilite) {
        this.habilite = habilite;
    } 

    public String getLibelle(Locale locale){
        if(locale == Locale.FRENCH) return getLibelleFr();
        else return getLibelleUs();
    }
    
    public String getLibelle(){
        return getLibelle(Locale.getDefault());
    }
}
