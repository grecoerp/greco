/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "NOTES")
public class Notes implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "noteID")
    private String noteID;
    @Basic(optional = false)
    @Column(name = "objet")
    private String objet;
    @Lob
    @Column(name = "contenu")
    private String contenu;
    @Basic(optional = false)
    @Column(name = "dateAffichage")
    @Temporal(TemporalType.DATE)
    private Date dateAffichage;
    @Basic(optional = false)
    @Column(name = "statut")
    private int statut;
    @Column(name = "organisationIDs")
    private String organisationIDs;
    @Column(name = "moduleIDs")
    private String moduleIDs;
    @Column(name = "userLogins")
    private String userLogins;

    public Notes() {
    }

    public Notes(String noteID) {
        this.noteID = noteID;
    }

    public Notes(String noteID, Date lastUpdate, String userUpdate, String objet, Date dateAffichage, int statut) {
        this.noteID = noteID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.objet = objet;
        this.dateAffichage = dateAffichage;
        this.statut = statut;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getNoteID() {
        return noteID;
    }

    public void setNoteID(String noteID) {
        this.noteID = noteID;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    public Date getDateAffichage() {
        return dateAffichage;
    }

    public void setDateAffichage(Date dateAffichage) {
        this.dateAffichage = dateAffichage;
    }

    public int getStatut() {
        return statut;
    }

    public void setStatut(int statut) {
        this.statut = statut;
    }

    public String getOrganisationIDs() {
        return organisationIDs;
    }

    public void setOrganisationIDs(String organisationIDs) {
        this.organisationIDs = organisationIDs;
    }

    public String getModuleIDs() {
        return moduleIDs;
    }

    public void setModuleIDs(String moduleIDs) {
        this.moduleIDs = moduleIDs;
    }

    public String getUserLogins() {
        return userLogins;
    }

    public void setUserLogins(String userLogins) {
        this.userLogins = userLogins;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (noteID != null ? noteID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Notes)) {
            return false;
        }
        Notes other = (Notes) object;
        if ((this.noteID == null && other.noteID != null) || (this.noteID != null && !this.noteID.equals(other.noteID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.Notes[ noteID=" + noteID + " ]";
    }
    
}
