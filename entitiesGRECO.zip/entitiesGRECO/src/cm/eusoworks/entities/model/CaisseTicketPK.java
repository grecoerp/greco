/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;

/**
 *
 * @author jeanemmanuel
 */
@Embeddable
public class CaisseTicketPK implements Serializable {

    @Basic(optional = false)
    @Column(name = "ticketID")
    private String ticketID;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "deviseID")
    private String deviseID;
    @Basic(optional = false)
    @Column(name = "reglementID")
    private String reglementID;
    @Basic(optional = false)
    @Column(name = "loginCaissier")
    private String loginCaissier;
    @Basic(optional = false)
    @Column(name = "clientID")
    private String clientID;

    public CaisseTicketPK() {
    }

    public CaisseTicketPK(String ticketID, String organisationID, String millesime, String deviseID, String reglementID, String loginCaissier, String clientID) {
        this.ticketID = ticketID;
        this.organisationID = organisationID;
        this.millesime = millesime;
        this.deviseID = deviseID;
        this.reglementID = reglementID;
        this.loginCaissier = loginCaissier;
        this.clientID = clientID;
    }

    public String getTicketID() {
        return ticketID;
    }

    public void setTicketID(String ticketID) {
        this.ticketID = ticketID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getDeviseID() {
        return deviseID;
    }

    public void setDeviseID(String deviseID) {
        this.deviseID = deviseID;
    }

    public String getReglementID() {
        return reglementID;
    }

    public void setReglementID(String reglementID) {
        this.reglementID = reglementID;
    }

    public String getLoginCaissier() {
        return loginCaissier;
    }

    public void setLoginCaissier(String loginCaissier) {
        this.loginCaissier = loginCaissier;
    }

    public String getClientID() {
        return clientID;
    }

    public void setClientID(String clientID) {
        this.clientID = clientID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (ticketID != null ? ticketID.hashCode() : 0);
        hash += (organisationID != null ? organisationID.hashCode() : 0);
        hash += (millesime != null ? millesime.hashCode() : 0);
        hash += (deviseID != null ? deviseID.hashCode() : 0);
        hash += (reglementID != null ? reglementID.hashCode() : 0);
        hash += (loginCaissier != null ? loginCaissier.hashCode() : 0);
        hash += (clientID != null ? clientID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseTicketPK)) {
            return false;
        }
        CaisseTicketPK other = (CaisseTicketPK) object;
        if ((this.ticketID == null && other.ticketID != null) || (this.ticketID != null && !this.ticketID.equals(other.ticketID))) {
            return false;
        }
        if ((this.organisationID == null && other.organisationID != null) || (this.organisationID != null && !this.organisationID.equals(other.organisationID))) {
            return false;
        }
        if ((this.millesime == null && other.millesime != null) || (this.millesime != null && !this.millesime.equals(other.millesime))) {
            return false;
        }
        if ((this.deviseID == null && other.deviseID != null) || (this.deviseID != null && !this.deviseID.equals(other.deviseID))) {
            return false;
        }
        if ((this.reglementID == null && other.reglementID != null) || (this.reglementID != null && !this.reglementID.equals(other.reglementID))) {
            return false;
        }
        if ((this.loginCaissier == null && other.loginCaissier != null) || (this.loginCaissier != null && !this.loginCaissier.equals(other.loginCaissier))) {
            return false;
        }
        if ((this.clientID == null && other.clientID != null) || (this.clientID != null && !this.clientID.equals(other.clientID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.CaisseTicketPK[ ticketID=" + ticketID + ", organisationID=" + organisationID + ", millesime=" + millesime + ", deviseID=" + deviseID + ", reglementID=" + reglementID + ", loginCaissier=" + loginCaissier + ", clientID=" + clientID + " ]";
    }
    
}
