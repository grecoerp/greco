/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "CAISSETICKET")
@NamedQueries({
    @NamedQuery(name = "CaisseTicket.findAll", query = "SELECT c FROM CaisseTicket c")})
public class CaisseTicket implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CaisseTicketPK caisseTicketPK;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Column(name = "dateHeure")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateHeure;
    @Column(name = "total")
    private Long total;
    @Column(name = "remise")
    private Long remise;
    @Column(name = "nap")
    private Long nap;
    @Column(name = "encaisse")
    private Long encaisse;
    @Column(name = "rendu")
    private Long rendu;
    @Column(name = "reference")
    private Long reference;
    @Basic(optional = false)
    @Column(name = "change")
    private float change;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "caisseTicket")
    private List<CaisseTicketDetails> caisseTicketDetailsList;
    @JoinColumn(name = "clientID", referencedColumnName = "clientID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Client client;
    @JoinColumn(name = "deviseID", referencedColumnName = "deviseID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Devise devise;
    @JoinColumn(name = "reglementID", referencedColumnName = "reglementID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private ReglementMode reglementMode;

    public CaisseTicket() {
    }

    public CaisseTicket(CaisseTicketPK caisseTicketPK) {
        this.caisseTicketPK = caisseTicketPK;
    }

    public CaisseTicket(CaisseTicketPK caisseTicketPK, Date lastUpdate, String userUpdate, float change) {
        this.caisseTicketPK = caisseTicketPK;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.change = change;
    }

    public CaisseTicket(String ticketID, String organisationID, String millesime, String deviseID, String reglementID, String loginCaissier, String clientID) {
        this.caisseTicketPK = new CaisseTicketPK(ticketID, organisationID, millesime, deviseID, reglementID, loginCaissier, clientID);
    }

    public CaisseTicketPK getCaisseTicketPK() {
        return caisseTicketPK;
    }

    public void setCaisseTicketPK(CaisseTicketPK caisseTicketPK) {
        this.caisseTicketPK = caisseTicketPK;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public Date getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(Date dateHeure) {
        this.dateHeure = dateHeure;
    }

    public Long getTotal() {
        return total;
    }

    public void setTotal(Long total) {
        this.total = total;
    }

    public Long getRemise() {
        return remise;
    }

    public void setRemise(Long remise) {
        this.remise = remise;
    }

    public Long getNap() {
        return nap;
    }

    public void setNap(Long nap) {
        this.nap = nap;
    }

    public Long getEncaisse() {
        return encaisse;
    }

    public void setEncaisse(Long encaisse) {
        this.encaisse = encaisse;
    }

    public Long getRendu() {
        return rendu;
    }

    public void setRendu(Long rendu) {
        this.rendu = rendu;
    }

    public Long getReference() {
        return reference;
    }

    public void setReference(Long reference) {
        this.reference = reference;
    }

    public float getChange() {
        return change;
    }

    public void setChange(float change) {
        this.change = change;
    }

    public List<CaisseTicketDetails> getCaisseTicketDetailsList() {
        return caisseTicketDetailsList;
    }

    public void setCaisseTicketDetailsList(List<CaisseTicketDetails> caisseTicketDetailsList) {
        this.caisseTicketDetailsList = caisseTicketDetailsList;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Devise getDevise() {
        return devise;
    }

    public void setDevise(Devise devise) {
        this.devise = devise;
    }

    public ReglementMode getReglementMode() {
        return reglementMode;
    }

    public void setReglementMode(ReglementMode reglementMode) {
        this.reglementMode = reglementMode;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (caisseTicketPK != null ? caisseTicketPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseTicket)) {
            return false;
        }
        CaisseTicket other = (CaisseTicket) object;
        if ((this.caisseTicketPK == null && other.caisseTicketPK != null) || (this.caisseTicketPK != null && !this.caisseTicketPK.equals(other.caisseTicketPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.CaisseTicket[ caisseTicketPK=" + caisseTicketPK + " ]";
    }
    
}
