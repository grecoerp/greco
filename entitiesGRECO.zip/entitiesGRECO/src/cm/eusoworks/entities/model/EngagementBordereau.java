/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "engagementbordereau")

public class EngagementBordereau implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "bordereauID")
    private String bordereauID;
    @Basic(optional = false)
    @Column(name = "numBordereau")
    private String numBordereau;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "numDossier")
    private String numDossier;
    @Basic(optional = false)
    @Column(name = "objet")
    private String objet;
    @Basic(optional = false)
    @Column(name = "beneficiaire")
    private String beneficiaire;
    @Basic(optional = false)
    @Column(name = "montant")
    private long montant;

    public EngagementBordereau() {
    }

    public EngagementBordereau(String bordereauID) {
        this.bordereauID = bordereauID;
    }

    public EngagementBordereau(String bordereauID, String numBordereau, String organisationID, String millesime, String numDossier, String objet, String beneficiaire, long montant) {
        this.bordereauID = bordereauID;
        this.numBordereau = numBordereau;
        this.organisationID = organisationID;
        this.millesime = millesime;
        this.numDossier = numDossier;
        this.objet = objet;
        this.beneficiaire = beneficiaire;
        this.montant = montant;
    }

    public String getBordereauID() {
        return bordereauID;
    }

    public void setBordereauID(String bordereauID) {
        this.bordereauID = bordereauID;
    }

    public String getNumBordereau() {
        return numBordereau;
    }

    public void setNumBordereau(String numBordereau) {
        this.numBordereau = numBordereau;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public long getMontant() {
        return montant;
    }

    public void setMontant(long montant) {
        this.montant = montant;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (bordereauID != null ? bordereauID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EngagementBordereau)) {
            return false;
        }
        EngagementBordereau other = (EngagementBordereau) object;
        if ((this.bordereauID == null && other.bordereauID != null) || (this.bordereauID != null && !this.bordereauID.equals(other.bordereauID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.EngagementBordereau[ bordereauID=" + bordereauID + " ]";
    }
    
}
