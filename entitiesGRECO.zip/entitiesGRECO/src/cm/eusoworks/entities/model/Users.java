/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import cm.eusoworks.entities.security.Crypto;
import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "USERS")
public class Users implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "login")
    private String login;
    @Basic(optional = false)
    @Column(name = "password")
    private String password;
    @Basic(optional = false)
    @Column(name = "nom")
    private String nom;
    @Column(name = "prenom")
    private String prenom;
    @Column(name = "immatriculation")
    private String immatriculation;
    @Column(name = "fonction")
    private String fonction;
    @Column(name = "email")
    private String email;
    @Basic(optional = false)
    @Column(name = "actif")
    private boolean actif;
    @Column(name = "service")
    private String service;
    
    private String organisationID;
    private Date dateCreation;
    private String structure;
    private String structureID;
    private boolean checked = false;
    
    private String facebook;
    private String whatsapp;
    private String twitter;
    private String googleplus;
    private String linkedln;
    private String telephone;

    public Users() {
    }

    public Users(String login) {
        this.login = login;
    }

    public Users(String login, Date lastUpdate, String userUpdate, String password, String nom, boolean actif) {
        this.login = login;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.password = password;
        this.nom = nom;
        this.actif = actif;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getLogin() {
        return login;
    }
    
    public String getLoginDecrypt() {
        return Crypto.decrypt(login);
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNom() {
        return nom;
    }
    
    public String getNomDecrypt() {
        return Crypto.decrypt( nom);
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPrenom() {
        return prenom;
    }
    
    public String getPrenomDecrypt() {
        return Crypto.decrypt( prenom);
    }

    public void setPrenom(String prenom) {
        this.prenom = prenom;
    }

    public String getImmatriculation() {
        return immatriculation;
    }
    
    public String getImmatriculationDecrypt() {
        return Crypto.decrypt( immatriculation);
    }

    public void setImmatriculation(String immatriculation) {
        this.immatriculation = immatriculation;
    }

    public String getFonction() {
        return fonction;
    }
    
    public String getFonctionDecrypt() {
        return Crypto.decrypt(fonction);
    }

    public void setFonction(String fonction) {
        this.fonction = fonction;
    }

    public String getEmail() {
        return email;
    }
    
    public String getEmailDecrypt() {
        return Crypto.decrypt(email);
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public boolean getActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public String getStructure() {
        return structure;
    }

    public void setStructure(String structure) {
        this.structure = structure;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (login != null ? login.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Users)) {
            return false;
        }
        Users other = (Users) object;
        if ((this.login == null && other.login != null) || (this.login != null && !this.login.equals(other.login))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return (new StringBuilder().append(nom==null?"":Crypto.decrypt(nom)).append(" ").append(prenom==null?"":Crypto.decrypt(prenom)).append(" [").append(Crypto.decrypt(login)).append(" ]")).toString();
    }
    
    public String getNomComplet(){
        return nom==null?"":nom+" "+prenom==null?"":prenom;
    }
    
    public String getNomCompletDecrypt(){
        return (new StringBuilder().append(nom==null?"":Crypto.decrypt(nom)).append(" ").append(prenom==null?"":Crypto.decrypt(prenom))).toString();
       
    }

    public String getService() {
        return service;
    }
    
    public String getServiceDecrypt() {
        return Crypto.decrypt(service);
    }

    public void setService(String service) {
        this.service = service;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    public String getFacebook() {
        return facebook;
    }

    public void setFacebook(String facebook) {
        this.facebook = facebook;
    }

    public String getWhatsapp() {
        return whatsapp;
    }

    public void setWhatsapp(String whatsapp) {
        this.whatsapp = whatsapp;
    }

    public String getTwitter() {
        return twitter;
    }

    public void setTwitter(String twitter) {
        this.twitter = twitter;
    }

    public String getGoogleplus() {
        return googleplus;
    }

    public void setGoogleplus(String googleplus) {
        this.googleplus = googleplus;
    }

    public String getLinkedln() {
        return linkedln;
    }

    public void setLinkedln(String linkedln) {
        this.linkedln = linkedln;
    }

    public String getTelephone() {
        return telephone;
    }

    public void setTelephone(String telephone) {
        this.telephone = telephone;
    }
    
    
    
}
