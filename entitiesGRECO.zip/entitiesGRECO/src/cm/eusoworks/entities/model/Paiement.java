/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


public class Paiement implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "paiementID")
    private String paiementID;
    @Column(name = "mandatementID")
    private String mandatementID;
    @Column(name = "liquiditeID")
    private String liquiditeID;
    @Basic(optional = false)
    @Column(name = "numOrdre")
    private int numOrdre;
    @Basic(optional = false)
    @Column(name = "montant")
    private BigDecimal montant;
    @Basic(optional = false)
    @Column(name = "datePaiement")
    @Temporal(TemporalType.TIMESTAMP)
    private Date datePaiement;
    @Column(name = "reference")
    private String reference;
    
    private String droitID;

    public Paiement() {
    }

    public Paiement(String paiementID) {
        this.paiementID = paiementID;
    }

    public Paiement(String paiementID, Date lastUpdate, String userUpdate, int numOrdre, BigDecimal montant, Date datePaiement) {
        this.paiementID = paiementID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.numOrdre = numOrdre;
        this.montant = montant;
        this.datePaiement = datePaiement;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getPaiementID() {
        return paiementID;
    }

    public void setPaiementID(String paiementID) {
        this.paiementID = paiementID;
    }

    public String getMandatementID() {
        return mandatementID;
    }

    public void setMandatementID(String mandatementID) {
        this.mandatementID = mandatementID;
    }

    public String getLiquiditeID() {
        return liquiditeID;
    }

    public void setLiquiditeID(String liquiditeID) {
        this.liquiditeID = liquiditeID;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }


    public Date getDatePaiement() {
        return datePaiement;
    }

    public void setDatePaiement(Date datePaiement) {
        this.datePaiement = datePaiement;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getDroitID() {
        return droitID;
    }

    public void setDroitID(String droitID) {
        this.droitID = droitID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (paiementID != null ? paiementID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Paiement)) {
            return false;
        }
        Paiement other = (Paiement) object;
        if ((this.paiementID == null && other.paiementID != null) || (this.paiementID != null && !this.paiementID.equals(other.paiementID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.Paiement[ paiementID=" + paiementID + " ]";
    }
    
}
