/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author DGLS
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class PrepaMarcheFinancement implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "financementId")
    protected String financementId;
    @Column(name = "abbreviation")
    protected String abbreviation;
    @Column(name = "libelleFr")
    protected String libelleFr;
    @Column(name = "libelleUs")
    protected String libelleUs;
    @Column(name = "userMaj")
    protected String userMaj;
    @Column(name = "dateMaj")
    @Temporal(TemporalType.TIMESTAMP)
    protected Date dateMaj;

    public PrepaMarcheFinancement() {
    }

    public PrepaMarcheFinancement(String financementId) {
        this.financementId = financementId;
    }

    public String getFinancementId() {
        return financementId;
    }

    public void setFinancementId(String financementId) {
        this.financementId = financementId;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (financementId != null ? financementId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaMarcheFinancement)) {
            return false;
        }
        PrepaMarcheFinancement other = (PrepaMarcheFinancement) object;
        if ((this.financementId == null && other.financementId != null) || (this.financementId != null && !this.financementId.equals(other.financementId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.siic.dgls.marche.generated.GenMarcheFinancement[ financementId=" + financementId + " ]";
    }
    
}
