/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author DISI
 */
public class PrepaBudget implements Serializable {

    private static final long serialVersionUID = 1L;
    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String libelleFr;
    private String libelleUs;
    private String millesime;
    private String organisationID;
    private String budgetID;
    private int type;
    private String etat;
    private String reference;
    private Integer numOrdre;

    private BigDecimal volumeAE;
    private BigDecimal volumeCP;

    private boolean saisie;
    private boolean valideMinistere;
    private boolean validePM;
    
    private boolean enLigne;
    private String notePresentationFr;
    private String notePresentationUs;
    
    private String budgetCollectifInitial;

    public PrepaBudget() {
    }

    public PrepaBudget(String budgetID) {
        this.budgetID = budgetID;
    }

    public PrepaBudget(String budgetID, Date lastUpdate, String userUpdate, String libelleFr, int type, String etat) {
        this.budgetID = budgetID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.type = type;
        this.etat = etat;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getBudgetID() {
        return budgetID;
    }

    public void setBudgetID(String budgetID) {
        this.budgetID = budgetID;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getEtat() {
        return etat;
    }

    public void setEtat(String etat) {
        this.etat = etat;
        saisie = etat.substring(0, 1).equals("1");
        valideMinistere = etat.substring(1, 2).equals("1");
        validePM = etat.substring(2).equals("1");
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Integer getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(Integer numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (budgetID != null ? budgetID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaBudget)) {
            return false;
        }
        PrepaBudget other = (PrepaBudget) object;
        if ((this.budgetID == null && other.budgetID != null) || (this.budgetID != null && !this.budgetID.equals(other.budgetID))) {
            return false;
        }
        return true;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public BigDecimal getVolumeAE() {
        return volumeAE;
    }

    public void setVolumeAE(BigDecimal volumeAE) {
        this.volumeAE = volumeAE;
    }

    public BigDecimal getVolumeCP() {
        return volumeCP;
    }

    public void setVolumeCP(BigDecimal volumeCP) {
        this.volumeCP = volumeCP;
    }

    public boolean isSaisie() {
        return saisie;
    }

    public void setSaisie(boolean saisie) {
        this.saisie = saisie;
    }

    public boolean isValideMinistere() {
        return valideMinistere;
    }

    public void setValideMinistere(boolean valideMinistere) {
        this.valideMinistere = valideMinistere;
    }

    public boolean isValidePM() {
        return validePM;
    }

    public void setValidePM(boolean validePM) {
        this.validePM = validePM;
    }

    public boolean isEnLigne() {
        return enLigne;
    }

    public void setEnLigne(boolean enLigne) {
        this.enLigne = enLigne;
    }

    @Override
    public String toString() {
        return libelleFr;
    }

    public String getNotePresentationFr() {
        return notePresentationFr;
    }

    public void setNotePresentationFr(String notePresentationFr) {
        this.notePresentationFr = notePresentationFr;
    }

    public String getNotePresentationUs() {
        return notePresentationUs;
    }

    public void setNotePresentationUs(String notePresentationUs) {
        this.notePresentationUs = notePresentationUs;
    }

    public String getBudgetCollectifInitial() {
        return budgetCollectifInitial;
    }

    public void setBudgetCollectifInitial(String budgetCollectifInitial) {
        this.budgetCollectifInitial = budgetCollectifInitial;
    }

}
