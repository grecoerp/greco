/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 *
 * @author jeanemmanuel
 */
public class Mandatement implements Serializable {

    private static final long serialVersionUID = 1L;

    private String mandatementID;
    private String liquidationID;
    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private int numOrdre;
    private int etat;
    private String ordonnateur;
    private BigDecimal montantMandate;
    private Date dateMandatement;
    private String observations;
    private BigDecimal montantTTC;
    private BigDecimal montantTVA;
    private BigDecimal montantIR;
    private BigDecimal montantNAP;
    private BigDecimal montantRG;
    private String beneficiaire;
    private String pieces;
    private String rib;
    private Date dateControleRegularite;
    private String userControleReg;
    private String obsControleReg;

    private String numDossier;
    private String machine;
    private String objet;
    private String numeroOP;

    private String details;

    private String rubrique;
    private BigDecimal rubriqueMontant;
    private String rubriqueID;
    private String compteCredit;
    private String compteDebit;
    private String journalID;

    private boolean priseEnCharge;
    private boolean regle;
    private BigDecimal reglementEnCours;
    private BigDecimal reglementRestant;

    private List<MandatementDroits> droits;

    public Mandatement() {
    }

    public String getMandatementID() {
        return mandatementID;
    }

    public void setMandatementID(String mandatementID) {
        this.mandatementID = mandatementID;
    }

    public String getLiquidationID() {
        return liquidationID;
    }

    public void setLiquidationID(String liquidationID) {
        this.liquidationID = liquidationID;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public String getOrdonnateur() {
        return ordonnateur;
    }

    public void setOrdonnateur(String ordonnateur) {
        this.ordonnateur = ordonnateur;
    }

    public Date getDateMandatement() {
        return dateMandatement;
    }

    public void setDateMandatement(Date dateMandatement) {
        this.dateMandatement = dateMandatement;
    }

    public String getObservations() {
        return observations;
    }

    public void setObservations(String observations) {
        this.observations = observations;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    public Date getDateControleRegularite() {
        return dateControleRegularite;
    }

    public void setDateControleRegularite(Date dateControleRegularite) {
        this.dateControleRegularite = dateControleRegularite;
    }

    public String getUserControleReg() {
        return userControleReg;
    }

    public void setUserControleReg(String userControleReg) {
        this.userControleReg = userControleReg;
    }

    public String getObsControleReg() {
        return obsControleReg;
    }

    public void setObsControleReg(String obsControleReg) {
        this.obsControleReg = obsControleReg;
    }

    public BigDecimal getMontantMandate() {
        return montantMandate;
    }

    public void setMontantMandate(BigDecimal montantMandate) {
        this.montantMandate = montantMandate;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public BigDecimal getMontantTVA() {
        return montantTVA;
    }

    public void setMontantTVA(BigDecimal montantTVA) {
        this.montantTVA = montantTVA;
    }

    public BigDecimal getMontantIR() {
        return montantIR;
    }

    public void setMontantIR(BigDecimal montantIR) {
        this.montantIR = montantIR;
    }

    public BigDecimal getMontantNAP() {
        return montantNAP;
    }

    public void setMontantNAP(BigDecimal montantNAP) {
        this.montantNAP = montantNAP;
    }

    public BigDecimal getMontantRG() {
        return montantRG;
    }

    public void setMontantRG(BigDecimal montantRG) {
        this.montantRG = montantRG;
    }

    public String getPieces() {
        return pieces;
    }

    public void setPieces(String pieces) {
        this.pieces = pieces;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    @Override
    public int hashCode() {
        int hash = 0;

        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Mandatement)) {
            return false;
        }

        return true;
    }

    public List<MandatementDroits> getDroits() {
        return droits;
    }

    public void setDroits(List<MandatementDroits> droits) {
        this.droits = droits;
    }

    public String getNumeroOP() {
        return numeroOP;
    }

    public void setNumeroOP(String numeroOP) {
        this.numeroOP = numeroOP;
    }

    public String getDetails() {
        StringBuilder s = new StringBuilder();
        s.append("");
        if (droits != null) {
            if (!droits.isEmpty()) {
                for (MandatementDroits droit : droits) {
                    s.append(droit.getSigleFr());
                    s.append(";");
                }
            }
        }

        return s.toString();
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getRubrique() {
        return rubrique;
    }

    public void setRubrique(String rubrique) {
        this.rubrique = rubrique;
    }

    public BigDecimal getRubriqueMontant() {
        return rubriqueMontant;
    }

    public void setRubriqueMontant(BigDecimal rubriqueMontant) {
        this.rubriqueMontant = rubriqueMontant;
    }

    public String getRubriqueID() {
        return rubriqueID;
    }

    public void setRubriqueID(String rubriqueID) {
        this.rubriqueID = rubriqueID;
    }

    public String getCompteCredit() {
        return compteCredit;
    }

    public void setCompteCredit(String compteCredit) {
        this.compteCredit = compteCredit;
    }

    public String getCompteDebit() {
        return compteDebit;
    }

    public void setCompteDebit(String compteDebit) {
        this.compteDebit = compteDebit;
    }

    public String getJournalID() {
        return journalID;
    }

    public void setJournalID(String journalID) {
        this.journalID = journalID;
    }

    public boolean isPriseEnCharge() {
        return etat >= EtatDossier.prisEnCharge;
    }

    public void setPriseEnCharge(boolean priseEnCharge) {
        this.priseEnCharge = priseEnCharge;
    }

    public boolean isRegle() {
        if(reglementRestant == null) return false;
        else return reglementRestant.compareTo(BigDecimal.ZERO) == 0;
    }

    public void setRegle(boolean regle) {
        this.regle = regle;
    }

    public BigDecimal getReglementEnCours() {
        return reglementEnCours;
    }

    public void setReglementEnCours(BigDecimal reglementEnCours) {
        this.reglementEnCours = reglementEnCours;
    }

    public BigDecimal getReglementRestant() {
        return reglementRestant;
    }

    public void setReglementRestant(BigDecimal reglementRestant) {
        this.reglementRestant = reglementRestant;
    }

}
