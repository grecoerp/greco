/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity

public class NiveauOrganique implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "niveauOrganiqueID")
    private Integer niveauOrganiqueID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Column(name = "r")
    private Integer r;
    @Column(name = "g")
    private Integer g;
    @Column(name = "b")
    private Integer b;
    private String organisationID;

    public NiveauOrganique() {
    }

    public NiveauOrganique(Integer niveauOrganiqueID) {
        this.niveauOrganiqueID = niveauOrganiqueID;
    }

    public NiveauOrganique(Integer niveauOrganiqueID, Date lastUpdate, String userUpdate, String libelleFr) {
        this.niveauOrganiqueID = niveauOrganiqueID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public Integer getNiveauOrganiqueID() {
        return niveauOrganiqueID;
    }

    public void setNiveauOrganiqueID(Integer niveauOrganiqueID) {
        this.niveauOrganiqueID = niveauOrganiqueID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }
    
    public String getLibelle() {
        if(Locale.getDefault().equals(Locale.FRENCH)){
            return libelleFr;
        }else {
            return libelleUs;
        }
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Integer getR() {
        return r;
    }

    public void setR(Integer r) {
        this.r = r;
    }

    public Integer getG() {
        return g;
    }

    public void setG(Integer g) {
        this.g = g;
    }

    public Integer getB() {
        return b;
    }

    public void setB(Integer b) {
        this.b = b;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (niveauOrganiqueID != null ? niveauOrganiqueID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof NiveauOrganique)) {
            return false;
        }
        NiveauOrganique other = (NiveauOrganique) object;
        if ((this.niveauOrganiqueID == null && other.niveauOrganiqueID != null) || (this.niveauOrganiqueID != null && !this.niveauOrganiqueID.equals(other.niveauOrganiqueID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "" + niveauOrganiqueID + " - "+getLibelle();
    }
    
}
