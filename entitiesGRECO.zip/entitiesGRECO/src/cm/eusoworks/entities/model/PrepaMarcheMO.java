/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author DGLS
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class PrepaMarcheMO implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "maitreId")
    protected String maitreId;
    @Column(name = "code")
    protected String code;
    @Column(name = "libelleFR")
    protected String libelleFR;
    @Column(name = "libelleUS")
    protected String libelleUS;
    @Column(name = "arCode")
    protected String arCode;
    @Column(name = "chCode")
    protected String chCode;
    @Column(name = "userMaj")
    protected String userMaj;
    @Column(name = "dateMaj")
    @Temporal(TemporalType.TIMESTAMP)
    protected Date dateMaj;
    @Column(name = "exMillesime")
    protected String exMillesime;

    public PrepaMarcheMO() {
    }

    public PrepaMarcheMO(String maitreId) {
        this.maitreId = maitreId;
    }

    public String getMaitreId() {
        return maitreId;
    }

    public void setMaitreId(String maitreId) {
        this.maitreId = maitreId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getLibelleFR() {
        return libelleFR;
    }

    public void setLibelleFR(String libelleFR) {
        this.libelleFR = libelleFR;
    }

    public String getLibelleUS() {
        return libelleUS;
    }

    public void setLibelleUS(String libelleUS) {
        this.libelleUS = libelleUS;
    }

    public String getArCode() {
        return arCode;
    }

    public void setArCode(String arCode) {
        this.arCode = arCode;
    }

    public String getChCode() {
        return chCode;
    }

    public void setChCode(String chCode) {
        this.chCode = chCode;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    public String getExMillesime() {
        return exMillesime;
    }

    public void setExMillesime(String exMillesime) {
        this.exMillesime = exMillesime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (maitreId != null ? maitreId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaMarcheMO)) {
            return false;
        }
        PrepaMarcheMO other = (PrepaMarcheMO) object;
        if ((this.maitreId == null && other.maitreId != null) || (this.maitreId != null && !this.maitreId.equals(other.maitreId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.siic.dgls.marche.generated.GenPrepaMarcheMO[ maitreId=" + maitreId + " ]";
    }
}
