/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author DISI
 */

public class Virement implements Serializable {

    private static final long serialVersionUID = 1L;

    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String virementID;
    private int etat;
    private Date dateValidation;
    private String reference;
    private String objet;
    private Date dateSignature;
    private String signataire;
    private BigDecimal debit;
    private BigDecimal credit;
    private String gestionnaire;
    private Date dateEnregistrement;
    private String captcha;
    private String numVirement;
    private int numOrdre;
    private String budgetID;
    private String organisationID;
    private String millesime;
    private String titre;
    private String contenu;
    
    private boolean reserve;
    private boolean transmiCF;
    private boolean receptionCF;
    private boolean visaBudgetaire;
    private boolean signe;

    private String libelleFr;
    private String libelleUs;
    
    
    public Virement() {
    }

    public Virement(String virementID) {
        this.virementID = virementID;
    }

    public Virement(String virementID, Date lastUpdate, int etat, String reference, String objet, BigDecimal debit, BigDecimal credit, String numVirement, int numOrdre) {
        this.virementID = virementID;
        this.lastUpdate = lastUpdate;
        this.etat = etat;
        this.reference = reference;
        this.objet = objet;
        this.debit = debit;
        this.credit = credit;
        this.numVirement = numVirement;
        this.numOrdre = numOrdre;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getVirementID() {
        return virementID;
    }

    public void setVirementID(String virementID) {
        this.virementID = virementID;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public Date getDateValidation() {
        return dateValidation;
    }

    public void setDateValidation(Date dateValidation) {
        this.dateValidation = dateValidation;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public String getSignataire() {
        return signataire;
    }

    public void setSignataire(String signataire) {
        this.signataire = signataire;
    }

    public BigDecimal getDebit() {
        return debit;
    }

    public void setDebit(BigDecimal debit) {
        this.debit = debit;
    }

    public BigDecimal getCredit() {
        return credit;
    }

    public void setCredit(BigDecimal credit) {
        this.credit = credit;
    }

    public String getGestionnaire() {
        return gestionnaire;
    }

    public void setGestionnaire(String gestionnaire) {
        this.gestionnaire = gestionnaire;
    }

    public Date getDateEnregistrement() {
        return dateEnregistrement;
    }

    public void setDateEnregistrement(Date dateEnregistrement) {
        this.dateEnregistrement = dateEnregistrement;
    }

    public String getCaptcha() {
        return captcha;
    }

    public void setCaptcha(String captcha) {
        this.captcha = captcha;
    }

    public String getNumVirement() {
        return numVirement;
    }

    public void setNumVirement(String numVirement) {
        this.numVirement = numVirement;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getBudgetID() {
        return budgetID;
    }

    public void setBudgetID(String budgetID) {
        this.budgetID = budgetID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (virementID != null ? virementID.hashCode() : 0);
        return hash;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getTitre() {
        return titre;
    }

    public void setTitre(String titre) {
        this.titre = titre;
    }

    public String getContenu() {
        return contenu;
    }

    public void setContenu(String contenu) {
        this.contenu = contenu;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Virement)) {
            return false;
        }
        Virement other = (Virement) object;
        if ((this.virementID == null && other.virementID != null) || (this.virementID != null && !this.virementID.equals(other.virementID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return numVirement+": "+objet;
    }

    public boolean isReserve() {
        return etat >= EtatDossier.reserve;
    }

    public void setReserve(boolean reserve) {
        this.reserve = reserve;
    }

    public boolean isTransmiCF() {
        return etat >= EtatDossier.transmiCF;
    }

    public void setTransmiCF(boolean transmiCF) {
        this.transmiCF = transmiCF;
    }

    public boolean isReceptionCF() {
        return etat >= EtatDossier.receptionneCF;
    }

    public void setReceptionCF(boolean receptionCF) {
        this.receptionCF = receptionCF;
    }

    public boolean isVisaBudgetaire() {
        return etat >= EtatDossier.valide;
    }

    public void setVisaBudgetaire(boolean visaBudgetaire) {
        this.visaBudgetaire = visaBudgetaire;
    }

    public boolean isSigne() {
        return etat >= EtatDossier.transmiPourLiquidation;
    }

    public void setSigne(boolean signe) {
        this.signe = signe;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }
    
}
