/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "POSTECOMPTABLENATURE")
public class PosteComptableNature implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "naturePC")
    private String naturePC;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    private int posteComptableCount;

    public PosteComptableNature() {
    }

    public PosteComptableNature(String naturePC) {
        this.naturePC = naturePC;
    }

    public PosteComptableNature(String naturePC, Date lastUpdate, String userUpdate, String libelleFr) {
        this.naturePC = naturePC;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getNaturePC() {
        return naturePC;
    }

    public void setNaturePC(String naturePC) {
        this.naturePC = naturePC;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }
    
    public String getLibelle(Locale locale) {
        if(locale == Locale.FRENCH) return getLibelleFr();
        else return getLibelleUs();
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (naturePC != null ? naturePC.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PosteComptableNature)) {
            return false;
        }
        PosteComptableNature other = (PosteComptableNature) object;
        if ((this.naturePC == null && other.naturePC != null) || (this.naturePC != null && !this.naturePC.equals(other.naturePC))) {
            return false;
        }
        return true;
    }

    public int getPosteComptableCount() {
        return posteComptableCount;
    }

    public void setPosteComptableCount(int posteComptableCount) {
        this.posteComptableCount = posteComptableCount;
    }

    
    @Override
    public String toString() {
        return "("+posteComptableCount+") "+getLibelle(Locale.getDefault());
    }
    
}
