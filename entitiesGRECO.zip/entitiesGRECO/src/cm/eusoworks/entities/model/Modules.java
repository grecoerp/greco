/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "MODULES")
public class Modules implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "moduleID")
    private String moduleID;
    @Basic(optional = false)
    @Column(name = "systemeID")
    private String systemeID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "numOrdre")
    private int numOrdre;
    @Basic(optional = false)
    @Column(name = "icon")
    private String icon;
    @Basic(optional = false)
    @Column(name = "iconRoll")
    private String iconRoll;

    private boolean habilite = false;
    
    public static final String ANALYSE_STRATEGIQUE = "1";
    public static final String PLAN_DACTION_PRIORITAIRE = "2";
    public static final String PROGRAMMATION_PLURIANNUELLE = "3";
    public static final String BUDGETISATION_ANNUELLE = "4";
    public static final String DEPENSES = "5";
    public static final String RECETTES = "6";
    public static final String PAIE = "7";
    public static final String STOCKS = "8";
    public static final String IMMOBILISATIONS = "9";
    public static final String RESSOURCES_HUMAINES = "10";
    public static final String COMPTA_BUDGETAIRE = "11";
    public static final String COMPTA_GENERALE = "12";
    public static final String COMPTA_ANALYTIQUE = "13";
    public static final String CONFIGURATION = "14";
    public static final String PREFERENCES = "15";
    public static final String UTILISATEURS = "16";
    public static final String PROFILS_UTILISATEUR = "17";
    public static final String BUSINESSS_INTELLIGENCE = "18";
    public static final String PROFILEUR = "19";
    public static final String SAUVEGARDE_BD = "20";
//    public static final String MARCHE_PLAN_PASSATION = "21";
    public static final String COMPTA_CAISSE = "21";
    public static final String COMPTA_TRESORERIE = "22";
    
    public Modules() {
    }

    public Modules(String moduleID) {
        this.moduleID = moduleID;
    }

    public Modules(String moduleID, Date lastUpdate, String userUpdate, String libelleFr, int numOrdre, String icon, String iconRoll) {
        this.moduleID = moduleID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.numOrdre = numOrdre;
        this.icon = icon;
        this.iconRoll = iconRoll;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getModuleID() {
        return moduleID;
    }

    public void setModuleID(String moduleID) {
        this.moduleID = moduleID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getLibelle(Locale locale){
        if(locale == Locale.FRENCH) return getLibelleFr();
        else return getLibelleUs();
    }
    
    public String getLibelle(){
        return getLibelle(Locale.getDefault());
    }
    
    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public String getIconRoll() {
        return iconRoll;
    }

    public void setIconRoll(String iconRoll) {
        this.iconRoll = iconRoll;
    }

    public String getSystemeID() {
        return systemeID;
    }

    public void setSystemeID(String systemeID) {
        this.systemeID = systemeID;
    }

    public boolean isHabilite() {
        return habilite;
    }

    public void setHabilite(boolean habilite) {
        this.habilite = habilite;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (moduleID != null ? moduleID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Modules)) {
            return false;
        }
        Modules other = (Modules) object;
        if ((this.moduleID == null && other.moduleID != null) || (this.moduleID != null && !this.moduleID.equals(other.moduleID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return getLibelle(Locale.getDefault());
    }
    
}
