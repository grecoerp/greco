/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;

/**
 *
 * @author DISI
 */

public class PrepaBudgetLexique implements Serializable {

    private static final long serialVersionUID = 1L;
    private String organisationID;
    private String millesime;
    private String lexiqueFr;
    private String lexiqueUs;

    public PrepaBudgetLexique() {
    }


    public String getLexiqueFr() {
        return lexiqueFr;
    }

    public void setLexiqueFr(String lexiqueFr) {
        this.lexiqueFr = lexiqueFr;
    }

    public String getLexiqueUs() {
        return lexiqueUs;
    }

    public void setLexiqueUs(String lexiqueUs) {
        this.lexiqueUs = lexiqueUs;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }


    
}
