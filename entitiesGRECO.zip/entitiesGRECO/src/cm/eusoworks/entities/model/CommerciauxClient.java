/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "COMMERCIAUXCLIENT")
@NamedQueries({
    @NamedQuery(name = "CommerciauxClient.findAll", query = "SELECT c FROM CommerciauxClient c")})
public class CommerciauxClient implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CommerciauxClientPK commerciauxClientPK;
    @Basic(optional = false)
    @Column(name = "principal")
    private boolean principal;
    @JoinColumn(name = "clientID", referencedColumnName = "clientID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Client client;
    @JoinColumn(name = "commercialID", referencedColumnName = "commercialID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Commerciaux commerciaux;

    public CommerciauxClient() {
    }

    public CommerciauxClient(CommerciauxClientPK commerciauxClientPK) {
        this.commerciauxClientPK = commerciauxClientPK;
    }

    public CommerciauxClient(CommerciauxClientPK commerciauxClientPK, boolean principal) {
        this.commerciauxClientPK = commerciauxClientPK;
        this.principal = principal;
    }

    public CommerciauxClient(String commercialID, String clientID) {
        this.commerciauxClientPK = new CommerciauxClientPK(commercialID, clientID);
    }

    public CommerciauxClientPK getCommerciauxClientPK() {
        return commerciauxClientPK;
    }

    public void setCommerciauxClientPK(CommerciauxClientPK commerciauxClientPK) {
        this.commerciauxClientPK = commerciauxClientPK;
    }

    public boolean getPrincipal() {
        return principal;
    }

    public void setPrincipal(boolean principal) {
        this.principal = principal;
    }

    public Client getClient() {
        return client;
    }

    public void setClient(Client client) {
        this.client = client;
    }

    public Commerciaux getCommerciaux() {
        return commerciaux;
    }

    public void setCommerciaux(Commerciaux commerciaux) {
        this.commerciaux = commerciaux;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (commerciauxClientPK != null ? commerciauxClientPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CommerciauxClient)) {
            return false;
        }
        CommerciauxClient other = (CommerciauxClient) object;
        if ((this.commerciauxClientPK == null && other.commerciauxClientPK != null) || (this.commerciauxClientPK != null && !this.commerciauxClientPK.equals(other.commerciauxClientPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.CommerciauxClient[ commerciauxClientPK=" + commerciauxClientPK + " ]";
    }
    
}
