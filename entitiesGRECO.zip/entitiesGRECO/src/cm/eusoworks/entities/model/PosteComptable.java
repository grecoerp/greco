/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "POSTECOMPTABLE")

public class PosteComptable implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "posteComptableID")
    private String posteComptableID;
    @Basic(optional = false)
    @Column(name = "code")
    private String code;
    @Column(name = "abbreviationFr")
    private String abbreviationFr;
    @Column(name = "abbreviationUs")
    private String abbreviationUs;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "dateCreation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreation;
    @Column(name = "dateCessation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCessation;
    @Basic(optional = false)
    @Column(name = "actif")
    private boolean actif;
    @Basic(optional = false)
    @Column(name = "codeLocalite")
    private String codeLocalite;
    @Basic(optional = false)
    @Column(name = "naturePC")
    private String naturePC;
    

    public PosteComptable() {
    }

    public PosteComptable(String posteComptableID) {
        this.posteComptableID = posteComptableID;
    }

    public PosteComptable(String posteComptableID, Date lastUpdate, String userUpdate, String code, String libelleFr, Date dateCreation, boolean actif) {
        this.posteComptableID = posteComptableID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.code = code;
        this.libelleFr = libelleFr;
        this.dateCreation = dateCreation;
        this.actif = actif;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getPosteComptableID() {
        return posteComptableID;
    }

    public void setPosteComptableID(String posteComptableID) {
        this.posteComptableID = posteComptableID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAbbreviationFr() {
        return abbreviationFr;
    }

    public void setAbbreviationFr(String abbreviationFr) {
        this.abbreviationFr = abbreviationFr;
    }

    public String getAbbreviationUs() {
        return abbreviationUs;
    }

    public void setAbbreviationUs(String abbreviationUs) {
        this.abbreviationUs = abbreviationUs;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    public Date getDateCessation() {
        return dateCessation;
    }

    public void setDateCessation(Date dateCessation) {
        this.dateCessation = dateCessation;
    }

    public boolean getActif() {
        return actif;
    }

    public void setActif(boolean actif) {
        this.actif = actif;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (posteComptableID != null ? posteComptableID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PosteComptable)) {
            return false;
        }
        PosteComptable other = (PosteComptable) object;
        if ((this.posteComptableID == null && other.posteComptableID != null) || (this.posteComptableID != null && !this.posteComptableID.equals(other.posteComptableID))) {
            return false;
        }
        return true;
    }

    public String getLibelle(Locale locale) {
        if(locale.equals(Locale.FRENCH)){
            return libelleFr;
        }else {
            return libelleUs;
        }
    }
    public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }
    @Override
    public String toString() {
        return (posteComptableID == null)?"":code+" - "+getLibelle();
    }

    public String getCodeLocalite() {
        return codeLocalite;
    }

    public void setCodeLocalite(String codeLocalite) {
        this.codeLocalite = codeLocalite;
    }

    public String getNaturePC() {
        return naturePC;
    }

    public void setNaturePC(String naturePC) {
        this.naturePC = naturePC;
    }
    
}
