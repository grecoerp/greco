/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author DISI
 */

public class Liasse implements Serializable {

    private static final long serialVersionUID = 1L;
    private Date lastUpdate;
    private String userUpdate;
    private String ipUpdate;
    private String liasseID;
    private String libelleFr;
    private String libelleUs;
    private String typeID;
    
    private boolean checked;

    public Liasse() {
    }

    public Liasse(String liasseID) {
        this.liasseID = liasseID;
    }

    public Liasse(String liasseID, Date lastUpdate, String userUpdate, String libelleFr, String typeID) {
        this.liasseID = liasseID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.typeID = typeID;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getLiasseID() {
        return liasseID;
    }

    public void setLiasseID(String liasseID) {
        this.liasseID = liasseID;
    }

    public String getLibelle(Locale locale) {
        if(locale == Locale.FRENCH) return libelleFr;
        else return libelleUs;
    }
    
    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getTypeID() {
        return typeID;
    }

    public void setTypeID(String typeID) {
        this.typeID = typeID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (liasseID != null ? liasseID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Liasse)) {
            return false;
        }
        Liasse other = (Liasse) object;
        if ((this.liasseID == null && other.liasseID != null) || (this.liasseID != null && !this.liasseID.equals(other.liasseID))) {
            return false;
        }
        return true;
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean checked) {
        this.checked = checked;
    }

    @Override
    public String toString() {
        return libelleFr;
    }
    
}
