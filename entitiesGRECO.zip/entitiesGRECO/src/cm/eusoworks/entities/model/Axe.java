/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbook
 */

public class Axe implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "axeID")
    private String axeID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Basic(optional = false)
    @Column(name = "abbreviationFr")
    private String abbreviationFr;
    @Column(name = "abbreviationUs")
    private String abbreviationUs;
    @Basic(optional = false)
    @Column(name = "dateCreation")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateCreation;

    public Axe() {
    }

    public Axe(String axeID) {
        this.axeID = axeID;
    }

    public Axe(String axeID, Date lastUpdate, String userUpdate, String libelleFr, String abbreviationFr, Date dateCreation) {
        this.axeID = axeID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.abbreviationFr = abbreviationFr;
        this.dateCreation = dateCreation;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getAxeID() {
        return axeID;
    }

    public void setAxeID(String axeID) {
        this.axeID = axeID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getAbbreviationFr() {
        return abbreviationFr;
    }

    public void setAbbreviationFr(String abbreviationFr) {
        this.abbreviationFr = abbreviationFr;
    }

    public String getAbbreviationUs() {
        return abbreviationUs;
    }

    public void setAbbreviationUs(String abbreviationUs) {
        this.abbreviationUs = abbreviationUs;
    }

    public Date getDateCreation() {
        return dateCreation;
    }

    public void setDateCreation(Date dateCreation) {
        this.dateCreation = dateCreation;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (axeID != null ? axeID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Axe)) {
            return false;
        }
        Axe other = (Axe) object;
        if ((this.axeID == null && other.axeID != null) || (this.axeID != null && !this.axeID.equals(other.axeID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return axeID + " - "+libelleFr;
    }
    
}
