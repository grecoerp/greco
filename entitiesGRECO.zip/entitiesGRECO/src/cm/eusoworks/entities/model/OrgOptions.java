/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "ORGOPTIONS")
public class OrgOptions implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;
    @Column(name = "zoneEco")
    private String zoneEco;
    @Column(name = "paysFr")
    private String paysFr;
    @Column(name = "paysUs")
    private String paysUs;
    @Column(name = "deviseFr")
    private String deviseFr;
    @Column(name = "deviseUs")
    private String deviseUs;
    @Column(name = "orgSigleFr")
    private String orgSigleFr;
    @Column(name = "orgSigleUs")
    private String orgSigleUs;
    @Column(name = "orgLibelleFr")
    private String orgLibelleFr;
    @Column(name = "orgLibelleUs")
    private String orgLibelleUs;
    @Column(name = "orgContact")
    private String orgContact;
    @Column(name = "appAbreviationFr")
    private String appAbreviationFr;
    @Column(name = "appAbreviationUs")
    private String appAbreviationUs;
    @Column(name = "appTitleFr")
    private String appTitleFr;
    @Column(name = "appTitleUs")
    private String appTitleUs;
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Column(name = "machine")
    private String machine;
    @Column(name = "motif")
    private String motif;
    private String tutelleFr;
    private String tutelleUs;

    public OrgOptions() {
    }

    public OrgOptions(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getZoneEco() {
        return zoneEco;
    }

    public void setZoneEco(String zoneEco) {
        this.zoneEco = zoneEco;
    }

    public String getPaysFr() {
        return paysFr;
    }

    public void setPaysFr(String paysFr) {
        this.paysFr = paysFr;
    }

    public String getPaysUs() {
        return paysUs;
    }

    public void setPaysUs(String paysUs) {
        this.paysUs = paysUs;
    }

    public String getDeviseFr() {
        return deviseFr;
    }

    public void setDeviseFr(String deviseFr) {
        this.deviseFr = deviseFr;
    }

    public String getDeviseUs() {
        return deviseUs;
    }

    public void setDeviseUs(String deviseUs) {
        this.deviseUs = deviseUs;
    }

    public String getOrgSigleFr() {
        return orgSigleFr;
    }

    public void setOrgSigleFr(String orgSigleFr) {
        this.orgSigleFr = orgSigleFr;
    }

    public String getOrgSigleUs() {
        return orgSigleUs;
    }

    public void setOrgSigleUs(String orgSigleUs) {
        this.orgSigleUs = orgSigleUs;
    }

    public String getOrgLibelleFr() {
        return orgLibelleFr;
    }

    public void setOrgLibelleFr(String orgLibelleFr) {
        this.orgLibelleFr = orgLibelleFr;
    }

    public String getOrgLibelleUs() {
        return orgLibelleUs;
    }

    public void setOrgLibelleUs(String orgLibelleUs) {
        this.orgLibelleUs = orgLibelleUs;
    }

    public String getOrgContact() {
        return orgContact;
    }

    public void setOrgContact(String orgContact) {
        this.orgContact = orgContact;
    }

    public String getAppAbreviationFr() {
        return appAbreviationFr;
    }

    public void setAppAbreviationFr(String appAbreviationFr) {
        this.appAbreviationFr = appAbreviationFr;
    }

    public String getAppAbreviationUs() {
        return appAbreviationUs;
    }

    public void setAppAbreviationUs(String appAbreviationUs) {
        this.appAbreviationUs = appAbreviationUs;
    }

    public String getAppTitleFr() {
        return appTitleFr;
    }

    public void setAppTitleFr(String appTitleFr) {
        this.appTitleFr = appTitleFr;
    }

    public String getAppTitleUs() {
        return appTitleUs;
    }

    public void setAppTitleUs(String appTitleUs) {
        this.appTitleUs = appTitleUs;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (organisationID != null ? organisationID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof OrgOptions)) {
            return false;
        }
        OrgOptions other = (OrgOptions) object;
        if ((this.organisationID == null && other.organisationID != null) || (this.organisationID != null && !this.organisationID.equals(other.organisationID))) {
            return false;
        }
        return true;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getMachine() {
        return machine;
    }

    public void setMachine(String machine) {
        this.machine = machine;
    }

    public String getMotif() {
        return motif;
    }

    public void setMotif(String motif) {
        this.motif = motif;
    }

    public String getTutelleFr() {
        return tutelleFr;
    }

    public void setTutelleFr(String tutelleFr) {
        this.tutelleFr = tutelleFr;
    }

    public String getTutelleUs() {
        return tutelleUs;
    }

    public void setTutelleUs(String tutelleUs) {
        this.tutelleUs = tutelleUs;
    }

    
    
    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.OrgOptions[ organisationID=" + organisationID + " ]";
    }
    
}
