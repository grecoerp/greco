/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import com.siicore.util.StringUtil;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "decision")
public class Decision implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "decisionID")
    private String decisionID;
    @Column(name = "reference")
    private String reference;
    @Column(name = "dateSignature")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateSignature;
    @Column(name = "montant")
    private BigDecimal montant;
    @Column(name = "beneficiaire")
    private String beneficiaire;
    @Column(name = "fournisseurID")
    private String fournisseurID;
    @Column(name = "matricule")
    private String matricule;
    @Column(name = "structureBenefID")
    private String structureBenefID;
    @Basic(optional = false)
    @Column(name = "tacheID")
    private String tacheID;
    @Basic(optional = false)
    @Column(name = "organisationID")
    private String organisationID;
    @Basic(optional = false)
    @Column(name = "millesime")
    private String millesime;
    @Basic(optional = false)
    @Column(name = "activiteID")
    private String activiteID;
    @Basic(optional = false)
    @Column(name = "structureID")
    private String structureID;
    @Basic(optional = false)
    @Column(name = "modeleID")
    private String modeleID;
    @Basic(optional = false)
    @Column(name = "objet")
    private String objet;
    @Column(name = "signataire")
    private String signataire;
    
    private String budget;
    private String organisationLibelle;
    private String montantLettre;
    private String imputation;
    
    private String ordonnateur;
    private BigDecimal montantTVA;
    private BigDecimal montantIR;
    private BigDecimal montantHT;
    private BigDecimal montantTTC;
    private BigDecimal montantNAP;
    private int etat;
    private String numeroOPNap;
    private String numeroOPTaxe;
    private String numDossier;
    private String rib;

    public Decision() {
    }

    public Decision(String decisionID) {
        this.decisionID = decisionID;
    }

    public Decision(String decisionID, Date lastUpdate, String userUpdate) {
        this.decisionID = decisionID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getDecisionID() {
        return decisionID;
    }

    public void setDecisionID(String decisionID) {
        this.decisionID = decisionID;
    }

    public String getReference() {
        return reference;
    }

    public void setReference(String reference) {
        this.reference = reference;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    public String getBeneficiaire() {
        return beneficiaire;
    }

    public void setBeneficiaire(String beneficiaire) {
        this.beneficiaire = beneficiaire;
    }

    public String getFournisseurID() {
        return fournisseurID;
    }

    public void setFournisseurID(String fournisseurID) {
        this.fournisseurID = fournisseurID;
    }

    public String getMatricule() {
        return matricule;
    }

    public void setMatricule(String matricule) {
        this.matricule = matricule;
    }

    public String getStructureBenefID() {
        return structureBenefID;
    }

    public void setStructureBenefID(String structureBenefID) {
        this.structureBenefID = structureBenefID;
    }

    public String getTacheID() {
        return tacheID;
    }

    public void setTacheID(String tacheID) {
        this.tacheID = tacheID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getStructureID() {
        return structureID;
    }

    public void setStructureID(String structureID) {
        this.structureID = structureID;
    }

    public String getBudget() {
        return budget;
    }

    public void setBudget(String budget) {
        this.budget = budget;
    }

    public String getOrganisationLibelle() {
        return organisationLibelle;
    }

    public void setOrganisationLibelle(String organisationLibelle) {
        this.organisationLibelle = organisationLibelle;
    }

    public String getMontantLettre() {
        return StringUtil.getMontantEnLettre(Locale.FRENCH, this.montant) + "  francs CFA";
    }

    public void setMontantLettre(String montantLettre) {
        this.montantLettre = montantLettre;
    }

    public String getImputation() {
        return imputation;
    }

    public void setImputation(String imputation) {
        this.imputation = imputation;
    }

    public String getModeleID() {
        return modeleID;
    }

    public void setModeleID(String modeleID) {
        this.modeleID = modeleID;
    }

    public String getObjet() {
        return objet;
    }

    public void setObjet(String objet) {
        this.objet = objet;
    }

    public String getSignataire() {
        return signataire;
    }

    public void setSignataire(String signataire) {
        this.signataire = signataire;
    }

    
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (decisionID != null ? decisionID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Decision)) {
            return false;
        }
        Decision other = (Decision) object;
        if ((this.decisionID == null && other.decisionID != null) || (this.decisionID != null && !this.decisionID.equals(other.decisionID))) {
            return false;
        }
        return true;
    }

    public String getOrdonnateur() {
        return ordonnateur;
    }

    public void setOrdonnateur(String ordonnateur) {
        this.ordonnateur = ordonnateur;
    }

    public BigDecimal getMontantTVA() {
        return montantTVA;
    }

    public void setMontantTVA(BigDecimal montantTVA) {
        this.montantTVA = montantTVA;
    }

    public BigDecimal getMontantIR() {
        return montantIR;
    }

    public void setMontantIR(BigDecimal montantIR) {
        this.montantIR = montantIR;
    }

    public BigDecimal getMontantHT() {
        return montantHT;
    }

    public void setMontantHT(BigDecimal montantHT) {
        this.montantHT = montantHT;
    }

    public BigDecimal getMontantTTC() {
        return montantTTC;
    }

    public void setMontantTTC(BigDecimal montantTTC) {
        this.montantTTC = montantTTC;
    }

    public int getEtat() {
        return etat;
    }

    public void setEtat(int etat) {
        this.etat = etat;
    }

    public BigDecimal getMontantNAP() {
        return montantNAP;
    }

    public void setMontantNAP(BigDecimal montantNAP) {
        this.montantNAP = montantNAP;
    }

    public String getNumeroOPNap() {
        return numeroOPNap;
    }

    public void setNumeroOPNap(String numeroOPNap) {
        this.numeroOPNap = numeroOPNap;
    }

    public String getNumeroOPTaxe() {
        return numeroOPTaxe;
    }

    public void setNumeroOPTaxe(String numeroOPTaxe) {
        this.numeroOPTaxe = numeroOPTaxe;
    }

    public String getNumDossier() {
        return numDossier;
    }

    public void setNumDossier(String numDossier) {
        this.numDossier = numDossier;
    }

    public String getRib() {
        return rib;
    }

    public void setRib(String rib) {
        this.rib = rib;
    }

    
    
    @Override
    public String toString() {
        return  reference+" / "+this.beneficiaire;
    }
    
}
