/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author DGLS
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class PrepaMarcheContractant implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "contractantId")
    protected String contractantId;
    @Column(name = "libelleFr")
    protected String libelleFr;
    @Column(name = "libelleUs")
    protected String libelleUs;
    @Column(name = "userMaj")
    protected String userMaj;
    @Column(name = "dateMaj")
    @Temporal(TemporalType.TIMESTAMP)
    protected Date dateMaj;

    public PrepaMarcheContractant() {
    }

    public PrepaMarcheContractant(String contractantId) {
        this.contractantId = contractantId;
    }

    public String getContractantId() {
        return contractantId;
    }

    public void setContractantId(String contractantId) {
        this.contractantId = contractantId;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (contractantId != null ? contractantId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaMarcheContractant)) {
            return false;
        }
        PrepaMarcheContractant other = (PrepaMarcheContractant) object;
        if ((this.contractantId == null && other.contractantId != null) || (this.contractantId != null && !this.contractantId.equals(other.contractantId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.siic.dgls.marche.generated.GenMarcheContractant[ contractantId=" + contractantId + " ]";
    }
    
}
