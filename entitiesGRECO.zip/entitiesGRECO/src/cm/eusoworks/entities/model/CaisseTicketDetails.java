/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author jeanemmanuel
 */
@Entity
@Table(name = "CAISSETICKETDETAILS")
@NamedQueries({
    @NamedQuery(name = "CaisseTicketDetails.findAll", query = "SELECT c FROM CaisseTicketDetails c")})
public class CaisseTicketDetails implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CaisseTicketDetailsPK caisseTicketDetailsPK;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Column(name = "dateHeure")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateHeure;
    @Basic(optional = false)
    @Column(name = "quantite")
    private double quantite;
    @Column(name = "prixReference")
    private Long prixReference;
    @Basic(optional = false)
    @Column(name = "prixUnitaire")
    private long prixUnitaire;
    @Column(name = "prixTotal")
    private Long prixTotal;
    @Column(name = "remise")
    private Long remise;
    @JoinColumn(name = "ticketID", referencedColumnName = "ticketID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private CaisseTicket caisseTicket;

    public CaisseTicketDetails() {
    }

    public CaisseTicketDetails(CaisseTicketDetailsPK caisseTicketDetailsPK) {
        this.caisseTicketDetailsPK = caisseTicketDetailsPK;
    }

    public CaisseTicketDetails(CaisseTicketDetailsPK caisseTicketDetailsPK, Date lastUpdate, String userUpdate, double quantite, long prixUnitaire) {
        this.caisseTicketDetailsPK = caisseTicketDetailsPK;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.quantite = quantite;
        this.prixUnitaire = prixUnitaire;
    }

    public CaisseTicketDetails(String ticketDetailsID, String ticketID, String amId) {
        this.caisseTicketDetailsPK = new CaisseTicketDetailsPK(ticketDetailsID, ticketID, amId);
    }

    public CaisseTicketDetailsPK getCaisseTicketDetailsPK() {
        return caisseTicketDetailsPK;
    }

    public void setCaisseTicketDetailsPK(CaisseTicketDetailsPK caisseTicketDetailsPK) {
        this.caisseTicketDetailsPK = caisseTicketDetailsPK;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public Date getDateHeure() {
        return dateHeure;
    }

    public void setDateHeure(Date dateHeure) {
        this.dateHeure = dateHeure;
    }

    public double getQuantite() {
        return quantite;
    }

    public void setQuantite(double quantite) {
        this.quantite = quantite;
    }

    public Long getPrixReference() {
        return prixReference;
    }

    public void setPrixReference(Long prixReference) {
        this.prixReference = prixReference;
    }

    public long getPrixUnitaire() {
        return prixUnitaire;
    }

    public void setPrixUnitaire(long prixUnitaire) {
        this.prixUnitaire = prixUnitaire;
    }

    public Long getPrixTotal() {
        return prixTotal;
    }

    public void setPrixTotal(Long prixTotal) {
        this.prixTotal = prixTotal;
    }

    public Long getRemise() {
        return remise;
    }

    public void setRemise(Long remise) {
        this.remise = remise;
    }

    public CaisseTicket getCaisseTicket() {
        return caisseTicket;
    }

    public void setCaisseTicket(CaisseTicket caisseTicket) {
        this.caisseTicket = caisseTicket;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (caisseTicketDetailsPK != null ? caisseTicketDetailsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof CaisseTicketDetails)) {
            return false;
        }
        CaisseTicketDetails other = (CaisseTicketDetails) object;
        if ((this.caisseTicketDetailsPK == null && other.caisseTicketDetailsPK != null) || (this.caisseTicketDetailsPK != null && !this.caisseTicketDetailsPK.equals(other.caisseTicketDetailsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.CaisseTicketDetails[ caisseTicketDetailsPK=" + caisseTicketDetailsPK + " ]";
    }
    
}
