/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author ouethy
 */

public class Activite implements Serializable {
    private static final long serialVersionUID = 1L;

    protected Date lastUpdate;
    protected String userUpdate;
    protected String ipUpdate;
    protected String activiteID;
    protected String libelleFr;
    protected String libelleUs;
    protected String presentationFr;
    protected String presentationUs;
    protected String millesime;
    protected String activiteParentID;
    protected Integer niveauActiviteID;
    protected String organisationID;
    protected String code;
    

    protected int childs;
    protected BigDecimal ae;
    protected BigDecimal cp;
    
    
    public Activite() {
    }

    public Activite(String activiteID) {
        this.activiteID = activiteID;
    }

    public Activite(String activiteID, Date lastUpdate, String userUpdate, String libelleFr) {
        this.activiteID = activiteID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getActiviteID() {
        return activiteID;
    }

    public void setActiviteID(String activiteID) {
        this.activiteID = activiteID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public String getActiviteParentID() {
        return activiteParentID;
    }

    public void setActiviteParentID(String activiteParentID) {
        this.activiteParentID = activiteParentID;
    }

    public Integer getNiveauActiviteID() {
        return niveauActiviteID;
    }

    public void setNiveauActiviteID(Integer niveauActiviteID) {
        this.niveauActiviteID = niveauActiviteID;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public int getChilds() {
        return childs;
    }

    public void setChilds(int childs) {
        this.childs = childs;
    }
    public boolean haschilds(){
        return (this.childs > 0);
    }

    public BigDecimal getAe() {
        return ae==null?BigDecimal.ZERO:ae;
    }

    public void setAe(BigDecimal ae) {
        this.ae = ae;
    }

    public BigDecimal getCp() {
        return cp==null?BigDecimal.ZERO:cp;
    }

    public void setCp(BigDecimal cp) {
        this.cp = cp;
    }
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (activiteID != null ? activiteID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Activite)) {
            return false;
        }
        Activite other = (Activite) object;
        if ((this.activiteID == null && other.activiteID != null) || (this.activiteID != null && !this.activiteID.equals(other.activiteID))) {
            return false;
        }
        return true;
    }

    public String getLibelle(Locale locale){
        return locale == Locale.FRENCH?getLibelleFr():getLibelleUs();
    }
    
    public String getLibelle(){
        return getLibelle(Locale.getDefault());
    }
    
    @Override
    public String toString() {
        return code==null?"":code+" - "+getLibelle();
    }

    public String getPresentationFr() {
        return presentationFr;
    }

    public void setPresentationFr(String presentationFr) {
        this.presentationFr = presentationFr;
    }

    public String getPresentationUs() {
        return presentationUs;
    }

    public void setPresentationUs(String presentationUs) {
        this.presentationUs = presentationUs;
    }
    
    
}
