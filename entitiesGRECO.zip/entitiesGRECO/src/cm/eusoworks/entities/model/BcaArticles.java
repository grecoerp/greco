/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "bcaarticles")
public class BcaArticles implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "amId")
    private String amId;
    @Basic(optional = false)
    @Column(name = "prixUnitaire")
    private BigDecimal prixUnitaire;
    @Basic(optional = false)
    @Column(name = "quantite")
    private float quantite;
    @Basic(optional = false)
    private String bcaID;
    @Basic(optional = false)
    private int numOrdre;

    private String refArticle="";
    private String designation="";
    private BigDecimal prixDeReference;
    
    private String liquidationID;
    
    public BcaArticles() {
    }

    public BcaArticles(String amId) {
        this.amId = amId;
    }

    public BcaArticles(String amId, Date lastUpdate, String userUpdate, BigDecimal prixUnitaire, int quantite) {
        this.amId = amId;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.prixUnitaire = prixUnitaire;
        this.quantite = quantite;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getAmId() {
        return amId;
    }

    public void setAmId(String amId) {
        this.amId = amId;
    }

    public BigDecimal getPrixUnitaire() {
        return prixUnitaire;
    }

    public void setPrixUnitaire(BigDecimal prixUnitaire) {
        this.prixUnitaire = prixUnitaire;
    }

   

    public float getQuantite() {
        return quantite;
    }

    public void setQuantite(float quantite) {
        this.quantite = quantite;
    }

    public String getBcaID() {
        return bcaID;
    }

    public void setBcaID(String bcaID) {
        this.bcaID = bcaID;
    }

    public BigDecimal getPrixDeReference() {
        return prixDeReference;
    }

    public void setPrixDeReference(BigDecimal prixDeReference) {
        this.prixDeReference = prixDeReference;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (amId != null ? amId.hashCode() : 0);
        return hash;
    }

    public String getRefArticle() {
        return refArticle;
    }

    public void setRefArticle(String refArticle) {
        this.refArticle = refArticle;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getLiquidationID() {
        return liquidationID;
    }

    public void setLiquidationID(String liquidationID) {
        this.liquidationID = liquidationID;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof BcaArticles)) {
            return false;
        }
        BcaArticles other = (BcaArticles) object;
        if ((this.amId == null && other.amId != null) || (this.amId != null && !this.amId.equals(other.amId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return refArticle+" : [Qté:"+quantite+"] -"+designation;
    }
    
}
