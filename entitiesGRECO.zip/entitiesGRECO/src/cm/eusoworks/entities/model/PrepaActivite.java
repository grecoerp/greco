/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author ouethy
 */

public class PrepaActivite extends Activite implements Serializable {
    private static final long serialVersionUID = 1L;


    protected BigDecimal AECollectif;
    protected BigDecimal CPCollectif;

    public PrepaActivite() {
    }

    public PrepaActivite(String activiteID) {
        this.activiteID = activiteID;
    }

    public PrepaActivite(String activiteID, Date lastUpdate, String userUpdate, String libelleFr) {
        this.activiteID = activiteID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
    }

    

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaActivite)) {
            return false;
        }
        PrepaActivite other = (PrepaActivite) object;
        if ((this.activiteID == null && other.activiteID != null) || (this.activiteID != null && !this.activiteID.equals(other.activiteID))) {
            return false;
        }
        return true;
    }

    public String getLibelle(Locale locale){
        return locale == Locale.FRENCH?getLibelleFr():getLibelleUs();
    }
    
    public String getLibelle(){
        return getLibelle(Locale.getDefault());
    }

    public BigDecimal getAECollectif() {
        return AECollectif;
    }

    public void setAECollectif(BigDecimal AECollectif) {
        this.AECollectif = AECollectif;
    }

    public BigDecimal getCPCollectif() {
        return CPCollectif;
    }

    public void setCPCollectif(BigDecimal CPCollectif) {
        this.CPCollectif = CPCollectif;
    }
    

    
}
