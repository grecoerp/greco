/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author ouethy
 */

public class MandatementDroits implements Serializable {
    
    private static final long serialVersionUID = 1L;

    private String droitID;
    private String mandatementID;
    private double taux;
    private BigDecimal montant;
    private String libelleFr;
    private String libelleUs;
    private String sigleFr;
    private String sigleUs;
    private Date last_update;
    private String user_update;
    private String ip_update;
    private String id;
    
    private boolean NAP;
    private boolean TVA;
    private boolean IR;
    private boolean RG;
    private boolean Caution;
    private boolean Penalite;
    private boolean DepotDivers;
    private boolean Precompte;

    public MandatementDroits() {
    }

    public MandatementDroits(String id) {
        this.id = id;
    }

    public double getTaux() {
        return taux;
    }

    public void setTaux(double taux) {
        this.taux = taux;
    }

    public BigDecimal getMontant() {
        return montant;
    }

    public void setMontant(BigDecimal montant) {
        this.montant = montant;
    }

    public String getDroitID() {
        return droitID;
    }

    public void setDroitID(String droitID) {
        this.droitID = droitID;
    }

    public String getMandatementID() {
        return mandatementID;
    }

    public void setMandatementID(String mandatementID) {
        this.mandatementID = mandatementID;
    }

    public String getSigleFr() {
        return sigleFr;
    }

    public void setSigleFr(String sigleFr) {
        this.sigleFr = sigleFr;
    }

    public String getSigleUs() {
        return sigleUs;
    }

    public void setSigleUs(String sigleUs) {
        this.sigleUs = sigleUs;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getLibelle(Locale locale) {
        if(locale == Locale.FRENCH) return libelleFr;
        else return libelleUs;
    }
    
    public String getLibelle() {
        return getLibelle(Locale.getDefault());
    }
    
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getLast_update() {
        return last_update;
    }

    public void setLast_update(Date last_update) {
        this.last_update = last_update;
    }

    public String getUser_update() {
        return user_update;
    }

    public void setUser_update(String user_update) {
        this.user_update = user_update;
    }

    public String getIp_update() {
        return ip_update;
    }

    public void setIp_update(String ip_update) {
        this.ip_update = ip_update;
    }

    @Override
    public String toString() {
        return getLibelle();
    }

    public boolean isNAP() {
        return NAP;
    }

    public void setNAP(boolean NAP) {
        this.NAP = NAP;
    }

    public boolean isTVA() {
        return TVA;
    }

    public void setTVA(boolean TVA) {
        this.TVA = TVA;
    }

    public boolean isIR() {
        return IR;
    }

    public void setIR(boolean IR) {
        this.IR = IR;
    }

    public boolean isRG() {
        return RG;
    }

    public void setRG(boolean RG) {
        this.RG = RG;
    }

    public boolean isCaution() {
        return Caution;
    }

    public void setCaution(boolean Caution) {
        this.Caution = Caution;
    }

    public boolean isPenalite() {
        return Penalite;
    }

    public void setPenalite(boolean Penalite) {
        this.Penalite = Penalite;
    }

    public boolean isDepotDivers() {
        return DepotDivers;
    }

    public void setDepotDivers(boolean DepotDivers) {
        this.DepotDivers = DepotDivers;
    }

    public boolean isPrecompte() {
        return Precompte;
    }

    public void setPrecompte(boolean Precompte) {
        this.Precompte = Precompte;
    }

    public LiquidationDroits getLiquidationDroit(){
        LiquidationDroits m = new LiquidationDroits();
        m.setCaution(Caution);
        m.setDepotDivers(DepotDivers);
        m.setDroitID(droitID);
        m.setIR(IR);
        m.setLibelleFr(libelleFr);
        m.setLibelleUs(libelleUs);
        m.setMontant(montant);
        m.setSigleFr(sigleFr);
        m.setSigleUs(sigleUs);
        m.setNAP(NAP);
        m.setPenalite(Penalite);
        m.setPrecompte(Precompte);
        m.setRG(RG);
        m.setTVA(TVA);
        m.setTaux(taux);
        
        return m;
    }

}
