/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author macbookair
 */
@Entity
@Table(name = "USERPREFERENCES")

public class Userpreferences implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Column(name = "langue")
    private String langue;
    @Id
    @Basic(optional = false)
    @Column(name = "login")
    private String login;
    @Column(name = "soundSuccess")
    private Boolean soundSuccess;
    @Column(name = "soundFail")
    private Boolean soundFail;
    @Column(name = "sound")
    private Boolean sound;
    @Column(name = "animation")
    private Boolean animation;
    @Column(name = "background")
    private String background;

    public Userpreferences() {
    }

    public Userpreferences(String login) {
        this.login = login;
    }

    public Userpreferences(String login, Date lastUpdate, String userUpdate) {
        this.login = login;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getBackground() {
        return background;
    }

    public void setBackground(String background) {
        this.background = background;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getLangue() {
        return langue;
    }

    public void setLangue(String langue) {
        this.langue = langue;
    }

    public String getLogin() {
        return login;
    }

    public void setLogin(String login) {
        this.login = login;
    }

    public Boolean getSoundSuccess() {
        return soundSuccess;
    }

    public void setSoundSuccess(Boolean soundSuccess) {
        this.soundSuccess = soundSuccess;
    }

    public Boolean getSoundFail() {
        return soundFail;
    }

    public void setSoundFail(Boolean soundFail) {
        this.soundFail = soundFail;
    }

    public Boolean getSound() {
        return sound;
    }

    public void setSound(Boolean sound) {
        this.sound = sound;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (login != null ? login.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Userpreferences)) {
            return false;
        }
        Userpreferences other = (Userpreferences) object;
        if ((this.login == null && other.login != null) || (this.login != null && !this.login.equals(other.login))) {
            return false;
        }
        return true;
    }

    public Boolean isAnimation() {
        return animation;
    }

    public void setAnimation(Boolean animation) {
        this.animation = animation;
    }

    
    
    @Override
    public String toString() {
        return "cm.eusoworks.entities.model.Userpreferences[ login=" + login + " ]";
    }
    
}
