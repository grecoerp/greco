/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Locale;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "droits")
public class Droits implements Serializable {
    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @Column(name = "last_update")
    @Temporal(TemporalType.TIMESTAMP)
    private Date lastUpdate;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Column(name = "ip_update")
    private String ipUpdate;
    @Id
    @Basic(optional = false)
    @Column(name = "droitID")
    private String droitID;
    @Basic(optional = false)
    @Column(name = "libelleFr")
    private String libelleFr;
    @Column(name = "libelleUs")
    private String libelleUs;
    @Column(name = "sigleFr")
    private String sigleFr;
    @Column(name = "sigleUs")
    private String sigleUs;
    @Basic(optional = false)
    @Column(name = "isNAP")
    private boolean NAP;
    @Column(name = "isTVA")
    private boolean TVA;
    @Column(name = "isIR")
    private boolean IR;
    @Column(name = "isRG")
    private boolean RG;
    @Column(name = "isCaution")
    private boolean Caution;
    @Column(name = "isPenalite")
    private boolean Penalite;
    @Column(name = "isDepotDivers")
    private boolean DepotDivers;
    @Column(name = "isPrecompte")
    private boolean Precompte;
    
    
    private String compteCredit;
    private String compteDebit;
    private String journalID;

    public Droits() {
    }

    public Droits(String droitID) {
        this.droitID = droitID;
    }

    public Droits(String droitID, Date lastUpdate, String userUpdate, String libelleFr, String sigleFr, boolean isNAP, boolean isTVA, boolean isIR, boolean isRG, boolean isCaution, boolean isPenalite, boolean isDepotDivers, boolean isPrecompte) {
        this.droitID = droitID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.sigleFr = sigleFr;
        this.NAP = isNAP;
        this.TVA = isTVA;
        this.IR = isIR;
        this.RG = isRG;
        this.Caution = isCaution;
        this.Penalite = isPenalite;
        this.DepotDivers = isDepotDivers;
        this.Precompte = isPrecompte;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getDroitID() {
        return droitID;
    }

    public void setDroitID(String droitID) {
        this.droitID = droitID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getSigleFr() {
        return sigleFr;
    }

    public void setSigleFr(String sigleFr) {
        this.sigleFr = sigleFr;
    }

    public String getSigleUs() {
        return sigleUs;
    }

    public void setSigleUs(String sigleUs) {
        this.sigleUs = sigleUs;
    }

    public boolean isNAP() {
        return NAP;
    }

    public void setNAP(boolean NAP) {
        this.NAP = NAP;
    }

    public boolean isTVA() {
        return TVA;
    }

    public void setTVA(boolean TVA) {
        this.TVA = TVA;
    }

    public boolean isIR() {
        return IR;
    }

    public void setIR(boolean IR) {
        this.IR = IR;
    }

    public boolean isRG() {
        return RG;
    }

    public void setRG(boolean RG) {
        this.RG = RG;
    }

    public boolean isCaution() {
        return Caution;
    }

    public void setCaution(boolean Caution) {
        this.Caution = Caution;
    }

    public boolean isPenalite() {
        return Penalite;
    }

    public void setPenalite(boolean Penalite) {
        this.Penalite = Penalite;
    }

    public boolean isDepotDivers() {
        return DepotDivers;
    }

    public void setDepotDivers(boolean DepotDivers) {
        this.DepotDivers = DepotDivers;
    }

    public boolean isPrecompte() {
        return Precompte;
    }

    public void setPrecompte(boolean Precompte) {
        this.Precompte = Precompte;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (droitID != null ? droitID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Droits)) {
            return false;
        }
        Droits other = (Droits) object;
        if ((this.droitID == null && other.droitID != null) || (this.droitID != null && !this.droitID.equals(other.droitID))) {
            return false;
        }
        return true;
    }

    public String getLibelle(Locale locale){
        return locale == Locale.FRENCH?getLibelleFr():getLibelleUs();
    }
    
    @Override
    public String toString() {
        return  getLibelle(Locale.getDefault()) ;
    }

    public String getCompteCredit() {
        return compteCredit;
    }

    public void setCompteCredit(String compteCredit) {
        this.compteCredit = compteCredit;
    }

    public String getCompteDebit() {
        return compteDebit;
    }

    public void setCompteDebit(String compteDebit) {
        this.compteDebit = compteDebit;
    }

    public String getJournalID() {
        return journalID;
    }

    public void setJournalID(String journalID) {
        this.journalID = journalID;
    }
    
    
    
}
