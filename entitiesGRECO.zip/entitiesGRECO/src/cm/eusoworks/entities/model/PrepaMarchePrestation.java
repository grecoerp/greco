/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author DGLS
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class PrepaMarchePrestation implements Serializable {
    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "naturePrestationId")
    protected String naturePrestationId;
    @Column(name = "code")
    protected String code;
    @Column(name = "abbreviation")
    protected String abbreviation;
    @Column(name = "libelleFr")
    protected String libelleFr;
    @Column(name = "libelleUs")
    protected String libelleUs;
    @Column(name = "userMaj")
    protected String userMaj;
    @Column(name = "dateMaj")
    @Temporal(TemporalType.TIMESTAMP)
    protected Date dateMaj;

    public PrepaMarchePrestation() {
    }

    public PrepaMarchePrestation(String naturePrestationId) {
        this.naturePrestationId = naturePrestationId;
    }

    public String getNaturePrestationId() {
        return naturePrestationId;
    }

    public void setNaturePrestationId(String naturePrestationId) {
        this.naturePrestationId = naturePrestationId;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getAbbreviation() {
        return abbreviation;
    }

    public void setAbbreviation(String abbreviation) {
        this.abbreviation = abbreviation;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (naturePrestationId != null ? naturePrestationId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaMarchePrestation)) {
            return false;
        }
        PrepaMarchePrestation other = (PrepaMarchePrestation) object;
        if ((this.naturePrestationId == null && other.naturePrestationId != null) || (this.naturePrestationId != null && !this.naturePrestationId.equals(other.naturePrestationId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.siic.dgls.marche.generated.GenMarchePrestation[ naturePrestationId=" + naturePrestationId + " ]";
    }
    
}
