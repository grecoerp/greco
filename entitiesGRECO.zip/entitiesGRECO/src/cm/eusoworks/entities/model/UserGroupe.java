/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author jeanemmanuel
 */

public class UserGroupe implements Serializable {

    private static final long serialVersionUID = 1L;

    private Date lastUpdate;

    private String userUpdate;

    private String ipUpdate;

    private String groupeID;

    private String libelleFr;

    private String description;

    private int numOrdre;

    private String proprietaire;

    private String profils;

    public UserGroupe() {
    }

    public UserGroupe(String groupeID) {
        this.groupeID = groupeID;
    }

    public UserGroupe(String groupeID, Date lastUpdate, String userUpdate, String libelleFr, int numOrdre, String proprietaire) {
        this.groupeID = groupeID;
        this.lastUpdate = lastUpdate;
        this.userUpdate = userUpdate;
        this.libelleFr = libelleFr;
        this.numOrdre = numOrdre;
        this.proprietaire = proprietaire;
    }

    public Date getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(Date lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getIpUpdate() {
        return ipUpdate;
    }

    public void setIpUpdate(String ipUpdate) {
        this.ipUpdate = ipUpdate;
    }

    public String getGroupeID() {
        return groupeID;
    }

    public void setGroupeID(String groupeID) {
        this.groupeID = groupeID;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(int numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getProprietaire() {
        return proprietaire;
    }

    public void setProprietaire(String proprietaire) {
        this.proprietaire = proprietaire;
    }

    public String getProfils() {
        return profils;
    }

    public void setProfils(String profils) {
        this.profils = profils;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (groupeID != null ? groupeID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof UserGroupe)) {
            return false;
        }
        UserGroupe other = (UserGroupe) object;
        if ((this.groupeID == null && other.groupeID != null) || (this.groupeID != null && !this.groupeID.equals(other.groupeID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return libelleFr;
    }
    
}
