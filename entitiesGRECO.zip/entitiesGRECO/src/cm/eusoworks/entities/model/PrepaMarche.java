/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Lob;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author DGLS
 */
@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class PrepaMarche implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "paId")
    private String paId;
    @Column(name = "naturePrestationId")
    private String naturePrestationId;
    @Column(name = "contractantId")
    private String contractantId;
    @Column(name = "typeAOId")
    private String typeAOId;
    @Column(name = "financementId")
    private String financementId;
    @Column(name = "numOrdre")
    private Integer numOrdre;
    @Column(name = "maitreOuvrage")
    private String maitreOuvrage;
    @Column(name = "annualite")
    private Boolean annualite;
    @Lob
    @Column(name = "motifGreAGre")
    private String motifGreAGre;
    @Column(name = "dateDebut")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDebut;
    @Column(name = "dateFin")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateFin;
    @Column(name = "dateLancement")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateLancement;
    @Column(name = "dateAttribution")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateAttribution;
    @Column(name = "dateSignature")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateSignature;
    @Column(name = "dateDemarrage")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDemarrage;
    @Column(name = "dateReception")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateReception;
    @Column(name = "dateLancementCP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateLancementCP;
    @Column(name = "dateAttributionCP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateAttributionCP;
    @Column(name = "dateSignatureCP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateSignatureCP;
    @Column(name = "dateDemarrageCP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateDemarrageCP;
    @Column(name = "dateReceptionCP")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateReceptionCP;
    @Column(name = "userMaj")
    private String userMaj;
    @Column(name = "dateMaj")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateMaj;

    public PrepaMarche() {
    }

    public PrepaMarche(String paId) {
        this.paId = paId;
    }

    public String getPaId() {
        return paId;
    }

    public void setPaId(String paId) {
        this.paId = paId;
    }

    public String getNaturePrestationId() {
        return naturePrestationId;
    }

    public void setNaturePrestationId(String naturePrestationId) {
        this.naturePrestationId = naturePrestationId;
    }

    public String getContractantId() {
        return contractantId;
    }

    public void setContractantId(String contractantId) {
        this.contractantId = contractantId;
    }

    public String getTypeAOId() {
        return typeAOId;
    }

    public void setTypeAOId(String typeAOId) {
        this.typeAOId = typeAOId;
    }

    public String getFinancementId() {
        return financementId;
    }

    public void setFinancementId(String financementId) {
        this.financementId = financementId;
    }

    public Integer getNumOrdre() {
        return numOrdre;
    }

    public void setNumOrdre(Integer numOrdre) {
        this.numOrdre = numOrdre;
    }

    public String getMaitreOuvrage() {
        return maitreOuvrage;
    }

    public void setMaitreOuvrage(String maitreOuvrage) {
        this.maitreOuvrage = maitreOuvrage;
    }

    public Boolean getAnnualite() {
        return annualite;
    }

    public void setAnnualite(Boolean annualite) {
        this.annualite = annualite;
    }

    public String getMotifGreAGre() {
        return motifGreAGre;
    }

    public void setMotifGreAGre(String motifGreAGre) {
        this.motifGreAGre = motifGreAGre;
    }

    public Date getDateDebut() {
        return dateDebut;
    }

    public void setDateDebut(Date dateDebut) {
        this.dateDebut = dateDebut;
    }

    public Date getDateFin() {
        return dateFin;
    }

    public void setDateFin(Date dateFin) {
        this.dateFin = dateFin;
    }

    public Date getDateLancement() {
        return dateLancement;
    }

    public void setDateLancement(Date dateLancement) {
        this.dateLancement = dateLancement;
    }

    public Date getDateAttribution() {
        return dateAttribution;
    }

    public void setDateAttribution(Date dateAttribution) {
        this.dateAttribution = dateAttribution;
    }

    public Date getDateSignature() {
        return dateSignature;
    }

    public void setDateSignature(Date dateSignature) {
        this.dateSignature = dateSignature;
    }

    public Date getDateDemarrage() {
        return dateDemarrage;
    }

    public void setDateDemarrage(Date dateDemarrage) {
        this.dateDemarrage = dateDemarrage;
    }

    public Date getDateReception() {
        return dateReception;
    }

    public void setDateReception(Date dateReception) {
        this.dateReception = dateReception;
    }

    public Date getDateLancementCP() {
        return dateLancementCP;
    }

    public void setDateLancementCP(Date dateLancementCP) {
        this.dateLancementCP = dateLancementCP;
    }

    public Date getDateAttributionCP() {
        return dateAttributionCP;
    }

    public void setDateAttributionCP(Date dateAttributionCP) {
        this.dateAttributionCP = dateAttributionCP;
    }

    public Date getDateSignatureCP() {
        return dateSignatureCP;
    }

    public void setDateSignatureCP(Date dateSignatureCP) {
        this.dateSignatureCP = dateSignatureCP;
    }

    public Date getDateDemarrageCP() {
        return dateDemarrageCP;
    }

    public void setDateDemarrageCP(Date dateDemarrageCP) {
        this.dateDemarrageCP = dateDemarrageCP;
    }

    public Date getDateReceptionCP() {
        return dateReceptionCP;
    }

    public void setDateReceptionCP(Date dateReceptionCP) {
        this.dateReceptionCP = dateReceptionCP;
    }

    public String getUserMaj() {
        return userMaj;
    }

    public void setUserMaj(String userMaj) {
        this.userMaj = userMaj;
    }

    public Date getDateMaj() {
        return dateMaj;
    }

    public void setDateMaj(Date dateMaj) {
        this.dateMaj = dateMaj;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (paId != null ? paId.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PrepaMarche)) {
            return false;
        }
        PrepaMarche other = (PrepaMarche) object;
        if ((this.paId == null && other.paId != null) || (this.paId != null && !this.paId.equals(other.paId))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "chargement.entites.GenMarche[ paId=" + paId + " ]";
    }
}
