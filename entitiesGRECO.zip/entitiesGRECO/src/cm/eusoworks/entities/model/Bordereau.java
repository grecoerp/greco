/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.model;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 *
 * @author ouethy
 */
@Entity
@Table(name = "bordereau")

public class Bordereau implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "numBordereau")
    private String numBordereau;
    @Basic(optional = false)
    @Column(name = "type")
    private int type;
    @Basic(optional = false)
    @Column(name = "numordre")
    private String numordre;
    @Basic(optional = false)
    @Column(name = "dateGeneration")
    @Temporal(TemporalType.TIMESTAMP)
    private Date dateGeneration;
    @Basic(optional = false)
    @Column(name = "user_update")
    private String userUpdate;
    @Basic(optional = false)
    @Column(name = "source")
    private String source;
    @Basic(optional = false)
    @Column(name = "destination")
    private String destination;
    @Basic(optional = false)
    @Column(name = "agent")
    private String agent;
    private String organisationID;
    private String millesime;

    public Bordereau() {
    }

    public Bordereau(String numBordereau) {
        this.numBordereau = numBordereau;
    }

    public Bordereau(String numBordereau, int type, String numordre, Date dateGeneration, String userUpdate, String source, String destination, String agent) {
        this.numBordereau = numBordereau;
        this.type = type;
        this.numordre = numordre;
        this.dateGeneration = dateGeneration;
        this.userUpdate = userUpdate;
        this.source = source;
        this.destination = destination;
        this.agent = agent;
    }

    public String getNumBordereau() {
        return numBordereau;
    }

    public void setNumBordereau(String numBordereau) {
        this.numBordereau = numBordereau;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getNumordre() {
        return numordre;
    }

    public void setNumordre(String numordre) {
        this.numordre = numordre;
    }

    public Date getDateGeneration() {
        return dateGeneration;
    }

    public void setDateGeneration(Date dateGeneration) {
        this.dateGeneration = dateGeneration;
    }

    public String getUserUpdate() {
        return userUpdate;
    }

    public void setUserUpdate(String userUpdate) {
        this.userUpdate = userUpdate;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getAgent() {
        return agent;
    }

    public void setAgent(String agent) {
        this.agent = agent;
    }

    public String getOrganisationID() {
        return organisationID;
    }

    public void setOrganisationID(String organisationID) {
        this.organisationID = organisationID;
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (numBordereau != null ? numBordereau.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Bordereau)) {
            return false;
        }
        Bordereau other = (Bordereau) object;
        if ((this.numBordereau == null && other.numBordereau != null) || (this.numBordereau != null && !this.numBordereau.equals(other.numBordereau))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        SimpleDateFormat s = new SimpleDateFormat("yyyyMMdd");
        return numBordereau +" du "+s.format(dateGeneration)+ "      DE {" + source + "] VERS [" + destination + "]";
    }

}
