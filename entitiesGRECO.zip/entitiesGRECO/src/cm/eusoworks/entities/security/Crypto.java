/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.entities.security;

import java.security.MessageDigest;

/**
 *
 * @author macbookair
 */
public class Crypto {

    public static String getMD5(String chaine) {
        byte[] uniqueKey = chaine.getBytes();
        byte[] hash = null;
        try {
            hash = MessageDigest.getInstance("MD5").digest(uniqueKey);
        } catch (Exception e) {
            throw new Error("no MD5 support in this VM");
        }
        StringBuilder hashString = new StringBuilder();
        for (int i = 0; i < hash.length; ++i) {
            String hex = Integer.toHexString(hash[i]);
            if (hex.length() == 1) {
                hashString.append('0');
                hashString.append(hex.charAt(hex.length() - 1));
            } else {
                hashString.append(hex.substring(hex.length() - 2));
            }
        }
        return hashString.toString();
    }

    public static String crypterPassword(String login, String password) {
        return getMD5("&&" + login) + getMD5(password) + getMD5("@#" + login);
    }

//    Crypter
    public static String encrypt(String chaine) {
        String crypte = "";
        for (int i = 0; i < chaine.length(); i++) {
            int c = chaine.charAt(i) ^ 48;
            crypte = crypte + (char) c;
        }
        return crypte;
    }
    
//    Décrypter
    public static String decrypt(String chaine) {
        String aCrypter = "";
        for (int i = 0; i < chaine.length(); i++) {
            int c = chaine.charAt(i) ^ 48;
            aCrypter = aCrypter + (char) c;
        }
        return aCrypter;
    }

    public static void main(String[] args) {
        String mot = "admin";
        String cle = "greco123";
        Crypto c = new Crypto();
        String crypte = c.crypterPassword("admin","ff");
        System.out.println(crypte);

        System.out.println(c.decrypt(crypte));
    }
}
