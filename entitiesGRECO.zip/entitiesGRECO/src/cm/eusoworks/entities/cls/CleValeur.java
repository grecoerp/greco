/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.entities.cls;

import java.io.Serializable;
import java.util.Locale;

/**
 *
 * @author ouethy
 */
public class CleValeur  implements Serializable {

    private static final long serialVersionUID = 1L;

    private Object code;
    private String libelleFr;
    private String libelleUs;
    private int numero;

    public Object getCode() {
        return code;
    }

    public void setCode(Object code) {
        this.code = code;
    }

    public String getLibelleFr() {
        return libelleFr;
    }

    public void setLibelleFr(String libelleFr) {
        this.libelleFr = libelleFr;
    }

    public String getLibelleUs() {
        return libelleUs;
    }

    public void setLibelleUs(String libelleUs) {
        this.libelleUs = libelleUs;
    }

    @Override
    public String toString() {
        return Locale.getDefault().equals(Locale.ENGLISH) ? libelleUs : libelleFr;
    }

    public CleValeur() {
    }

    public CleValeur(Object code, String libelleFr, String libelleUs) {
        this.code = code;
        this.libelleFr = libelleFr;
        this.libelleUs = libelleUs;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }
    
    
}
