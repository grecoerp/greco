/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.caisse.component;

import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.entities.model.Article;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author jeanemmanuel
 */
public class CaisseTableModel extends AbstractTableModel {

    CaisseComponent frame;
    String millesime;
    private int mode = 1;
    private double tauxRemise = 0;

    private List<Article> dataList = new ArrayList<>();
    private final String[] columNames = {"REFERENCE", "DESIGNATION", "QTE", "PRIX UNIT.", "PRIX TOTAL", "REMISE"};
    boolean[] canEdit = new boolean[]{true, false, true, false, false, true};
    BigDecimal somme = BigDecimal.ZERO;
    BigDecimal remise = BigDecimal.ZERO;

    public CaisseTableModel(CaisseComponent frame, String millesime, int mode) {
        this.frame = frame;
        this.millesime = millesime;

    }

    public CaisseTableModel(CaisseComponent frame, String millesime) {
        this(frame, millesime, 1);
    }

    public double getTauxRemise() {
        return tauxRemise;
    }

    public void setTauxRemise(double tauxRemise) {
        this.tauxRemise = tauxRemise;

        for (Article a : dataList) {
            if (a != null) {
                Number pt = a.getPrixTotal();
                double rm = pt.doubleValue() * tauxRemise;
                a.setRemise(BigDecimal.valueOf(rm));
            }
        }
        calculerSomme();
    }

    public void setMode(int m) {
        this.mode = m;
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return canEdit[columnIndex];
    }

    @Override
    public int getRowCount() {
        return dataList == null ? 0 : dataList.size();
    }

    @Override
    public int getColumnCount() {
        return columNames.length;
    }

    @Override
    public String getColumnName(int col) {
        return columNames[col];
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Article a = dataList.get(rowIndex);
        Object ob = null;
        switch (columnIndex) {
            case 0:
                ob = a.getRefArticle();
                break;
            case 1:
                ob = a.getDesignation();
                break;
            case 2:
                ob = a.getQuantite();
                break;
            case 3:
                ob = a.getPrixUnitaire();
                break;
            case 4:
                ob = a.getPrixTotal();
                break;
            case 5:
                ob = a.getRemise();
                break;
        }
        return ob;
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        if (columnIndex == 0) {
            return String.class;
        } else if (columnIndex == 2) {
            return Float.class;
        } else if (columnIndex == 3) {
            return BigDecimal.class;
        } else if (columnIndex == 4) {
            return BigDecimal.class;
        } else if (columnIndex == 5) {
            return BigDecimal.class;
        } else {
            return null;
        }
    }

    @Override
    public void setValueAt(Object value, int row, int col) {
        Article a = dataList.get(row);
        String ref = value == null ? null : value.toString();
        switch (col) {
            case 0:
                //rechercher l'artiche ici et charger la designation et le prix unitaire
                Article tmp = null;
                tmp = GrecoServiceFactory.getMercurialeService().getStockArticle(millesime, ref);
                if (tmp != null) {
                    a.setRefArticle(ref);
                    a.setAmId(ref);
                    a.setPrixUnitaire(tmp.getPrixDeReference());
                    a.setPrixMax(tmp.getPrixDeReference());
                    setValueAt(tmp.getDesignation(), row, 1);
                    setValueAt(tmp.getPrixDeReference(), row, 3);

                    Number n2 = a.getPrixUnitaire();
                    Float f2 = a.getQuantite();
                    long l2 = n2.longValue() * f2.longValue();
                    setValueAt(BigDecimal.valueOf(l2), row, 4);

                    Number nr = tmp.getPrixDeReference();
                    double lr = nr.doubleValue() * tauxRemise * f2;
                    setValueAt(BigDecimal.valueOf(lr), row, 5);

                    //si c'est la derniere ligne, ajouter une ligne dans le tableau
                    if (row == dataList.size() - 1) {
                        Article art = new Article(null);
                        addArticle(art);
                    }
                }

                break;
            case 1:
                a.setDesignation(value == null ? "" : value.toString());
                break;
            case 2:
                a.setQuantite(value == null ? 0 : (float) value);
                Number n1 = (getValueAt(row, 3) == null ? BigDecimal.ZERO : (BigDecimal) getValueAt(row, 3));
                double l1 = n1.doubleValue() * (value == null ? 0 : (float) value);
                setValueAt(BigDecimal.valueOf(l1), row, 4);
                calculerSomme();
                break;
            case 3:
                a.setPrixUnitaire(value == null ? BigDecimal.ZERO : (BigDecimal) value);
                Number n3 = a.getPrixUnitaire();
                Float f3 = a.getQuantite();
                double l3 = n3.doubleValue() * f3.doubleValue();
                setValueAt(BigDecimal.valueOf(l3), row, 4);
                calculerSomme();
                break;
            case 4:
                a.setPrixTotal(value == null ? BigDecimal.ZERO : (BigDecimal) value);
                break;
            case 5:
                a.setRemise(value == null ? BigDecimal.ZERO : (BigDecimal) value);
                calculerSomme();
                break;
        }
        fireTableCellUpdated(row, col);

    }

    public void addArticle(Article article) {
        // supprimer la derniere ligne si elle est vide
        int lastIndex = dataList.size() - 1;
        if (lastIndex >= 0) {
            Article a = dataList.get(dataList.size() - 1);
            if (a.getRefArticle() == null || a.getRefArticle().isEmpty()) {
                dataList.remove(lastIndex);
                fireTableRowsDeleted(lastIndex, lastIndex);
            }
        }

        // ajouter la nouvelle ligne
        dataList.add(article);
        fireTableRowsInserted(dataList.size() - 1, dataList.size() - 1);
        calculerSomme();
        
    }

    public void removeArticle(int rowIndex) {
        dataList.remove(rowIndex);
        fireTableRowsDeleted(rowIndex, rowIndex);
        calculerSomme();
    }

    public Article getArticleAt(int index) {
        return dataList.get(index);
    }

    private void calculerSomme() {
        somme = BigDecimal.ZERO;
        remise = BigDecimal.ZERO;
        for (Article a : dataList) {
            if (a != null) {
                somme = somme.add(a.getPrixTotal());
                remise = remise.add(a.getRemise());
            }
        }
        //mise a jour des totaux
        frame.calculTotaux(somme, remise);
    }

    public String getMillesime() {
        return millesime;
    }

    public void setMillesime(String millesime) {
        this.millesime = millesime;
    }

    public List<Article> getDataList() {
        return dataList;
    }

    public void setDataList(List<Article> data) {
        if (dataList != null) {
            for (int i = 0; i < dataList.size(); i++) {
                removeArticle(i);
            }
        }
        dataList.clear();
        for (int i = 0; i < data.size(); i++) {
            addArticle(data.get(i));
        }
    }

}
