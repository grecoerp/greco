package cm.eusoworks.context;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.Properties;
import javax.naming.Context;
import javax.naming.InitialContext;

/**
 *
 * @author macbookair
 */
public class GrecoAppConfig {

    private static Context _ctx = null;
    private static final String SERVER_APPLICATION_NAME = "grecoServeur";
    private static final String SERVER_MODULE_NAME = "greco-module";
    private static String HOSTNAME = "";
    private static final int SOCKET_TIMEOUT = 10000;
    private static final int SOCKET_PORT = 4848;

    //parametrage application
    private static String paysFr = "ORG_SIGLE";
    private static String paysUS = "ORG_SIGLE";
    private static String orgSigleFr = "MINFOF-FSDF"; //"MINPOSTEL-FST";
    private static String orgSigleUs = "ORG_SIGLE";
    private static String orgLibelleFr = "ORG_SIGLE";
    private static String orgLibelleUS = "ORG_SIGLE";
    private static String orgContact = "ORG_SIGLE_CONTACT";
    private static String deviseFr = "ORG_SIGLE";
    private static String deviseUS = "ORG_SIGLE";
    private static String appAbbreviationFr = "GRECO";
    private static String appAbbreviationUs = "GRECO";
    private static String appTitleFr = "Gestion des REssources et Charges des Organisations";
    private static String appTitleUs = "Gestion des REssources et Charges des Organisations";
    private static String tutelleFr = "MINISTERE";
    private static String tutelleUs = "MINISTRY";
    

    //URL des services
    public static final String USER_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "UserService";
    public static final String SYSTEME_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "SystemeService";
    public static final String ORGANISATION_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "OrganisationService";
    public static final String UNITEORGANIQUE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "UniteOrganiqueService";
    public static final String NIVEAU_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "NiveauService";
    public static final String NOMENCLATURE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "NomenclatureService";
    public static final String POSTECOMPTABLE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "PosteComptableService";
    public static final String SOURCEFINANCEMENT_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "SourceFinancementService";
    public static final String EXERCICE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "ExerciceService";
    public static final String ACTIVITE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "ActiviteService";
    public static final String OPERATIONBUDGETAIRE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "OperationService";
    public static final String REPORT_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "ReportService";
    public static final String MERCURIALE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "MercurialeService";
    public static final String FOURNISSEUR_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "FournisseurService";
    public static final String AGENT_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "AgentService";
    public static final String BONCOMMANDE_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "BonCommandeService";
    public static final String ORDREMISSION_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "OrdreMissionService";
    public static final String DECISION_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "DecisionService";
    public static final String ENGAGEMENT_URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "EngagementService";
    public static final String MARCHE_PREPA__URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "PrepaMarcheService";
    public static final String DROITS__URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "DroitsService";
    public static final String BANQUE__URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "BanqueService";
    public static final String COMPTA__URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "ComptaService";
    public static final String CLIENT__URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "ClientService";
    public static final String VIREMENT__URL = "java:global/" + SERVER_APPLICATION_NAME + "/" + SERVER_MODULE_NAME + "/" + "VirementService";

    static Properties properties;

    static Context ctx() {
        try {
            if (_ctx == null) {
                InputStream is = null;
                properties = new Properties();
                if (HOSTNAME.isEmpty()) {
                    try {
                        is = new FileInputStream("appServeur.properties");
                        properties.load(is);
                    } catch (Exception e) {
                        searchServer();
                    }

                } else {
                    properties.put("org.omg.CORBA.ORBInitialHost", HOSTNAME);
                }
                properties.put(Context.INITIAL_CONTEXT_FACTORY, "com.sun.enterprise.naming.SerialInitContextFactory");
                _ctx = new InitialContext(properties);
            }
            return _ctx;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        }

    }

    public static void searchServer() {
        String adresseIP = "127.0.0.1";
        if (pingHost(adresseIP, SOCKET_PORT, SOCKET_TIMEOUT)) {
            properties.put("org.omg.CORBA.ORBInitialHost", adresseIP);
            return;
        }
    }

    public static boolean pingHost(String host, int port, int timeout) {
        try (Socket socket = new Socket()) {
            socket.connect(new InetSocketAddress(host, port), timeout);
            return true;
        } catch (IOException e) {
            return false;
        }
    }

    public static String getHOSTNAME() {
        return HOSTNAME;
    }

    public static void setHOSTNAME(String HOSTNAME) {
        GrecoAppConfig.HOSTNAME = HOSTNAME;
    }

    public static void setCtx(Context _ctx) {
        GrecoAppConfig._ctx = _ctx;
    }

    public static final int GRECO = -1;
    public static final int FSPF_MINFOF = 1;
    public static final int CNRPH = 2;
    public static final int ENAM = 3;
    public static final int CSPH = 4;
    public static final int CCAA = 5;
    public static final int FST = 6;
    public static final int FSDF = 7;

    public static void initOrganisation(int i) {
        switch (i) {
            case GrecoAppConfig.FSPF_MINFOF:
                orgSigleFr = "FSPF";
                appAbbreviationFr = "WFBS";
                appTitleFr = " WILDLIFE FUND BUDGETING SYSTEM";
                break;
            case GrecoAppConfig.FSDF:
                orgSigleFr = "FSDF";
                appAbbreviationFr = "WFBS";
                appTitleFr = " WILDLIFE FUND BUDGETING SYSTEM";
                break;
            case GrecoAppConfig.CNRPH:
                orgSigleFr = "CNRPH";
                appAbbreviationFr = "TRAFIC2";
                appTitleFr = "TRAITEMENT INFORMATIQUE DES DONNEES FINANCIERES ET COMPTABLES";
                break;
            case GrecoAppConfig.ENAM:
                orgSigleFr = "ENAM";
                appAbbreviationFr = "SIGBUC";
                appTitleFr = " SYSTEME INTEGRE DE GESTION BUDGETAIRE ET COMPTABLE DE L'ENAM";
                break;
            case GrecoAppConfig.CSPH:
                orgSigleFr = "CSPH";
                appAbbreviationFr = "GRECO";
                appTitleFr = "PROGICIEL DE GESTION BUDGETAIRE ET COMPTABLE";
                break;
            case GrecoAppConfig.CCAA:
                orgSigleFr = "CCAA";
                appAbbreviationFr = "KEAMA ERP";
                appTitleFr = "PROGICIEL DE GESTION INTEGRE";
                break;
            case GrecoAppConfig.FST:
                orgSigleFr = "MINPOSTEL-FST";
                appAbbreviationFr = "FSTMANAGER";
                appTitleFr = "DISPOSITIF TECHNIQUE POUR LA GESTION DU FST";
                break;
            case GrecoAppConfig.GRECO:
                orgSigleFr = "ORGANISATION";
                appAbbreviationFr = "GRECO";
                appTitleFr = "SOLUTION DE GESTION BUDGETAIRE ET COMPTABLE";
                break;
        }

    }

    public static String getOrgSigleFr() {
        return orgSigleFr;
    }

    public static void setOrgSigleFr(String orgSigleFr) {
        GrecoAppConfig.orgSigleFr = orgSigleFr;
    }

    public static String getOrgSigleUs() {
        return orgSigleUs;
    }

    public static void setOrgSigleUs(String orgSigleUs) {
        GrecoAppConfig.orgSigleUs = orgSigleUs;
    }

    public static String getAppAbbreviation() {
        return appAbbreviationFr;
    }

    public static void setAppAbbreviation(String appAbbreviation) {
        GrecoAppConfig.appAbbreviationFr = appAbbreviation;
    }

    public static String getAppAbbreviationUs() {
        return appAbbreviationUs;
    }

    public static void setAppAbbreviationUs(String appAbbreviationUs) {
        GrecoAppConfig.appAbbreviationUs = appAbbreviationUs;
    }

    public static String getPaysFr() {
        return paysFr;
    }

    public static void setPaysFr(String paysFr) {
        GrecoAppConfig.paysFr = paysFr;
    }

    public static String getPaysUS() {
        return paysUS;
    }

    public static void setPaysUS(String paysUS) {
        GrecoAppConfig.paysUS = paysUS;
    }

    public static String getOrgLibelleFr() {
        return orgLibelleFr;
    }

    public static void setOrgLibelleFr(String orgLibelleFr) {
        GrecoAppConfig.orgLibelleFr = orgLibelleFr;
    }

    public static String getOrgLibelleUS() {
        return orgLibelleUS;
    }

    public static void setOrgLibelleUS(String orgLibelleUS) {
        GrecoAppConfig.orgLibelleUS = orgLibelleUS;
    }

    public static String getDeviseFr() {
        return deviseFr;
    }

    public static void setDeviseFr(String deviseFr) {
        GrecoAppConfig.deviseFr = deviseFr;
    }

    public static String getDeviseUS() {
        return deviseUS;
    }

    public static void setDeviseUS(String deviseUS) {
        GrecoAppConfig.deviseUS = deviseUS;
    }

    public static String getAppTitleFr() {
        return appTitleFr;
    }

    public static void setAppTitleFr(String appTitleFr) {
        GrecoAppConfig.appTitleFr = appTitleFr;
    }

    public static String getAppTitleUs() {
        return appTitleUs;
    }

    public static void setAppTitleUs(String appTitleUs) {
        GrecoAppConfig.appTitleUs = appTitleUs;
    }

    public static String getOrgContact() {
        return orgContact;
    }

    public static void setOrgContact(String orgContact) {
        GrecoAppConfig.orgContact = orgContact;
    }

    public static String getAppAbbreviationFr() {
        return appAbbreviationFr;
    }

    public static void setAppAbbreviationFr(String appAbbreviationFr) {
        GrecoAppConfig.appAbbreviationFr = appAbbreviationFr;
    }

    public static String getTutelleFr() {
        return tutelleFr;
    }

    public static void setTutelleFr(String tutelleFr) {
        GrecoAppConfig.tutelleFr = tutelleFr;
    }

    public static String getTutelleUs() {
        return tutelleUs;
    }

    public static void setTutelleUs(String tutelleUs) {
        GrecoAppConfig.tutelleUs = tutelleUs;
    }

}
