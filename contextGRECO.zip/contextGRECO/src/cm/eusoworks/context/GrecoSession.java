package cm.eusoworks.context;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */



import cm.eusoworks.entities.model.ComptaLibelle;
import cm.eusoworks.entities.model.OptionNiveauMax;
import cm.eusoworks.entities.model.Userpreferences;
import cm.eusoworks.entities.model.Users;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

/**
 *
 * @author macbookair
 */
public class GrecoSession {
    
    public static Users USER_CONNECTED; 
    public static Locale USER_LANGUAGE = Locale.FRENCH; 
    public static String USER_ADRESSE_IP; 
    public static String USER_ADRESSE_MAC; 
    public static String USER_HOST_NAME; 
    public static boolean USER_SOUND_ON = true;
    public static boolean USER_SOUND_ON_FAIL = true;
    public static boolean USER_SOUND_ON_SUCCESS = true;
    public static MySound notifications = new MySound();
    public static OptionNiveauMax optionNiveau = null;
    public static String connectionTime;
    public static double MERCURIALE_MARGE = 0.04d;
    public static String USER_BACKGROUND; 
    public static String USER_OS; 
    public static String USER_ARCHITECTURE;
    public static String USER_NAME; 
    
    private static HashMap comptaLibelleMap = new HashMap();
    
    public static void initUserPreferences(){
        //preferences utilisateur
        Userpreferences preferences = GrecoServiceFactory.getUserService().getUserPreferences(USER_CONNECTED.getLogin());
        if(preferences != null){
            USER_LANGUAGE = preferences.getLangue().trim().equalsIgnoreCase("fr")?Locale.FRENCH:Locale.ENGLISH;
            Locale.setDefault(USER_LANGUAGE);
            USER_SOUND_ON = preferences.getSound();
            USER_SOUND_ON_FAIL = preferences.getSoundFail();
            USER_SOUND_ON_SUCCESS = preferences.getSoundSuccess();
            USER_BACKGROUND = preferences.getBackground();
        }
        notifications.setIsSoundOn(USER_SOUND_ON);
        notifications.setIsSoundFail(USER_SOUND_ON_FAIL);
        notifications.setIsSoundSuccess(USER_SOUND_ON_SUCCESS);
        
        //optionNiveau
        try {
            optionNiveau = GrecoServiceFactory.getNiveauService().getOptionNiveauxMax();
        } catch (Exception e) {
            optionNiveau = null;
        }
        
    }
    
    public static void setComptaLibelleMap(List<ComptaLibelle> list){
        comptaLibelleMap.clear();;
        for (ComptaLibelle lib : list) {
            comptaLibelleMap.put(lib.getCode(), lib.getLibelle());
        }
    }
    
    public static String getComptaLibelle(String key){
        return (String) comptaLibelleMap.get(key);
    }
}
