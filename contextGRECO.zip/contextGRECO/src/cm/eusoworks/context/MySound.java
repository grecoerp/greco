/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.context;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.SwingUtilities;

/**
 *
 * @author macbookair
 */
public class MySound {

    private AudioFormat format;
    private byte[] samples;
    private AudioInputStream stream;
    DataLine.Info info;
    Clip clip;
    String filename;
    private boolean isSoundOn = true;
    private boolean isSoundFail = true;
    private boolean isSoundSuccess = true;

    public MySound() {
    }

    public void sound(final InputStream iStream) {
        if (!isSoundOn) {
            return;
        }
        //filename = fileNamePath;
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
//                    File f = new File(getClass().getResource(filename).getPath());
//                    URL resources = url; //f.toURI().toURL();

                    try {
                        InputStream bufferedIn = new BufferedInputStream(iStream);
                        stream = AudioSystem.getAudioInputStream(bufferedIn);
                        format = stream.getFormat();
                        info = new DataLine.Info(Clip.class, format);
                        try {
                            clip = (Clip) AudioSystem.getLine(info);
                            try {
                                clip.open(stream);
                                clip.start();
                            } catch (LineUnavailableException ex) {
                                System.out.println("LineUnavailableException");
                                ex.printStackTrace();
                                Logger.getLogger(MySound.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        } catch (LineUnavailableException ex) {
                            System.out.println("LineUnavailableException");
                            ex.printStackTrace();
                            Logger.getLogger(MySound.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    } catch (UnsupportedAudioFileException ex) {
                        System.out.println("UnsupportedAudioFileException");
                        ex.printStackTrace();
                        Logger.getLogger(MySound.class.getName()).log(Level.SEVERE, null, ex);
                    }

                } catch (IOException e) {
                    System.out.println("IOEXCEPTION");
                    e.printStackTrace();
                }
            }
        });
    }

    public void connect() {
        sound(getClass().getResourceAsStream("/cm/eusoworks/resources/wav/connect.wav"));
    }

    public void success() {
        if (isSoundSuccess) {
            sound(getClass().getResourceAsStream("/cm/eusoworks/resources/wav/success.wav"));
        }
    }

    public void echec() {
        if (isSoundFail) {
            sound(getClass().getResourceAsStream("/cm/eusoworks/resources/wav/echec.wav"));
        }
    }

    public void exit() {
        sound(getClass().getResourceAsStream("/cm/eusoworks/resources/wav/exit.wav"));
    }

    public void waiting() {
        sound(getClass().getResourceAsStream("/cm/eusoworks/resources/wav/waiting.wav"));
    }

    public void doubleBeep() {
        sound(getClass().getResourceAsStream("/cm/eusoworks/resources/wav/beep.wav"));
    }

    public void setIsSoundOn(boolean isSoundOn) {
        this.isSoundOn = isSoundOn;
    }

    public void setIsSoundFail(boolean isSoundFail) {
        this.isSoundFail = isSoundFail;
    }

    public void setIsSoundSuccess(boolean isSoundSuccess) {
        this.isSoundSuccess = isSoundSuccess;
    }

}
