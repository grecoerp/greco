package cm.eusoworks.context;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import cm.eusoworks.services.IActiviteService;
import cm.eusoworks.services.IAgentService;
import cm.eusoworks.services.IBanqueService;
import cm.eusoworks.services.IBonCommandeService;
import cm.eusoworks.services.IClientService;
import cm.eusoworks.services.IComptaService;
import cm.eusoworks.services.IDecisionService;
import cm.eusoworks.services.IDroitsService;
import cm.eusoworks.services.IEngagementService;
import cm.eusoworks.services.IExerciceService;
import cm.eusoworks.services.IFournisseurService;
import cm.eusoworks.services.IMercurialeService;
import cm.eusoworks.services.INiveauService;
import cm.eusoworks.services.INomenclatureService;
import cm.eusoworks.services.IOperationService;
import cm.eusoworks.services.IOrdreMissionService;
import cm.eusoworks.services.IOrganisationService;
import cm.eusoworks.services.IPosteComptableService;
import cm.eusoworks.services.IPrepaMarcheService;
import cm.eusoworks.services.IReportService;
import cm.eusoworks.services.ISourceFinancementService;
import cm.eusoworks.services.ISystemeService;
import cm.eusoworks.services.IUniteOrganiqueService;
import cm.eusoworks.services.IUserService;
import cm.eusoworks.services.IVirementService;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.naming.NamingException;
import javax.swing.JOptionPane;

/**
 *
 * @author macbookair
 */
public class GrecoServiceFactory {

    private static IUserService userService;
    private static ISystemeService systemeService;
    private static IOrganisationService organisationService;
    private static IUniteOrganiqueService uniteOrganiqueService;
    private static INiveauService niveauService;
    private static INomenclatureService nomenclatureService;
    private static IPosteComptableService posteComptableService;
    private static ISourceFinancementService sourceFinancementService;
    private static IExerciceService exerciceService;
    private static IActiviteService activiteService;
    private static IOperationService operationService;
    private static IReportService reportService;
    private static IMercurialeService mercurialeService;
    private static IFournisseurService fournisseurService;
    private static IAgentService agentService;
    private static IBonCommandeService bonCommandeService;
    private static IOrdreMissionService ordreMissionService;
    private static IDecisionService decisionService;
    private static IEngagementService engagementService;
    private static IPrepaMarcheService prepaMarcheService;
    private static IDroitsService droitService;
    private static IBanqueService banqueService;
    private static IComptaService comptaService;
    private static IClientService clientService;
    private static IVirementService virementService;
    
    
    private static final String NAMIMG_ERROR = "Le module serveur n'est pas déployé. Vérifier la disponibilité du serveur ";

    

    public static void initService() {
        getUserService();
        getSystemeService();
        getOrganisationService();
    }
    
    public static void closeService() {
        userService = null;
        systemeService = null;
        organisationService = null;
    }
 
    public static IUserService getUserService() {
        if (userService == null) {
            try {
                userService = (IUserService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.USER_URL);
            } catch (NamingException ex) {
                userService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / UserService");
                return userService;
            }
        }
        return userService;
    }

    public static ISystemeService getSystemeService() {
        if (systemeService == null) {
            try {
                systemeService = (ISystemeService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.SYSTEME_URL);
            } catch (NamingException ex) {
                systemeService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / SystemeService");
                return systemeService;
            }
        }
        return systemeService;
    }
    
    public static IOrganisationService getOrganisationService() {
        if (organisationService == null) {
            try {
                organisationService = (IOrganisationService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.ORGANISATION_URL);
            } catch (NamingException ex) {
                organisationService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / OrganisationService");
                return organisationService;
            }
        }
        return organisationService;
    }
    
    public static IUniteOrganiqueService getUniteOrganiqueService() {
        if (uniteOrganiqueService == null) {
            try {
                uniteOrganiqueService = (IUniteOrganiqueService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.UNITEORGANIQUE_URL);
            } catch (NamingException ex) {
                uniteOrganiqueService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / UniteOrganiqueService");
                return uniteOrganiqueService;
            }
        }
        return uniteOrganiqueService;
    }
    
    public static INiveauService getNiveauService() {
        if (niveauService == null) {
            try {
                niveauService = (INiveauService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.NIVEAU_URL);
            } catch (NamingException ex) {
                niveauService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / NiveauService");
                return niveauService;
            }
        }
        return niveauService;
    }
    
    public static INomenclatureService getNomenclatureService() {
        if (nomenclatureService == null) {
            try {
                nomenclatureService = (INomenclatureService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.NOMENCLATURE_URL);
            } catch (NamingException ex) {
                nomenclatureService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / NomenclatureService");
                return nomenclatureService;
            }
        }
        return nomenclatureService;
    }
    
    public static IPosteComptableService getPosteComptableService() {
        if (posteComptableService == null) {
            try {
                posteComptableService = (IPosteComptableService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.POSTECOMPTABLE_URL);
            } catch (NamingException ex) {
                posteComptableService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / PosteComptableService");
                return posteComptableService;
            }
        }
        return posteComptableService;
    }
    
    public static ISourceFinancementService getSourceFinancementService() {
        if (sourceFinancementService == null) {
            try {
                sourceFinancementService = (ISourceFinancementService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.SOURCEFINANCEMENT_URL);
            } catch (NamingException ex) {
                sourceFinancementService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / SourceFinancementService");
                return sourceFinancementService;
            }
        }
        return sourceFinancementService;
    }
    
    public static IExerciceService getExerciceService() {
        if (exerciceService == null) {
            try {
                exerciceService = (IExerciceService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.EXERCICE_URL);
            } catch (NamingException ex) {
                exerciceService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / ExerciceService");
                return exerciceService;
            }
        }
        return exerciceService;
    }
    
    public static IActiviteService getActiviteService() {
        if (activiteService == null) {
            try {
                activiteService = (IActiviteService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.ACTIVITE_URL);
            } catch (NamingException ex) {
                activiteService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / ActiviteService");
                return activiteService;
            }
        }
        return activiteService;
    }
    
    public static IOperationService getOperationService() {
        if (operationService == null) {
            try {
                operationService = (IOperationService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.OPERATIONBUDGETAIRE_URL);
            } catch (NamingException ex) {
                operationService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / OperationService");
                return operationService;
            }
        }
        return operationService;
    }
    
    public static IReportService getReportService() {
        if (reportService == null) {
            try {
                reportService = (IReportService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.REPORT_URL);
            } catch (NamingException ex) {
                reportService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / ReportService");
                return reportService;
            }
        }
        return reportService;
    }
    
    public static IMercurialeService getMercurialeService() {
        if (mercurialeService == null) {
            try {
                mercurialeService = (IMercurialeService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.MERCURIALE_URL);
            } catch (NamingException ex) {
                mercurialeService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / MercurialeService");
                return mercurialeService;
            }
        }
        return mercurialeService;
    }
    
    public static IFournisseurService getFournisseurService() {
        if (fournisseurService == null) {
            try {
                fournisseurService = (IFournisseurService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.FOURNISSEUR_URL);
            } catch (NamingException ex) {
                fournisseurService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / FournisseurService");
                return fournisseurService;
            }
        }
        return fournisseurService;
    }
    
    public static IAgentService getAgentService() {
        if (agentService == null) {
            try {
                agentService = (IAgentService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.AGENT_URL);
            } catch (NamingException ex) {
                agentService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / AgentService");
                return agentService;
            }
        }
        return agentService;
    }
    
    public static IBonCommandeService getBonCommandeService() {
        if (bonCommandeService == null) {
            try {
                bonCommandeService = (IBonCommandeService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.BONCOMMANDE_URL);
            } catch (NamingException ex) {
                bonCommandeService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / BonCommandeService");
                return bonCommandeService;
            }
        }
        return bonCommandeService;
    }
    
    public static IOrdreMissionService getOrdreMissionService() {
        if (ordreMissionService == null) {
            try {
                ordreMissionService = (IOrdreMissionService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.ORDREMISSION_URL);
            } catch (NamingException ex) {
                ordreMissionService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / OrdreMissionService");
                return ordreMissionService;
            }
        }
        return ordreMissionService;
    }
    
    public static IDecisionService getDecisionService() {
        if (decisionService == null) {
            try {
                decisionService = (IDecisionService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.DECISION_URL);
            } catch (NamingException ex) {
                decisionService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / DecisionService");
                return decisionService;
            }
        }
        return decisionService;
    }
    
    public static IEngagementService getEngagementService() {
        if (engagementService == null) {
            try {
                engagementService = (IEngagementService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.ENGAGEMENT_URL);
            } catch (NamingException ex) {
                engagementService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / EngagementService");
                return engagementService;
            }
        }
        return engagementService;
    }
    
    public static IPrepaMarcheService getPrepaMarcheService() {
        if (prepaMarcheService == null) {
            try {
                prepaMarcheService = (IPrepaMarcheService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.MARCHE_PREPA__URL);
            } catch (NamingException ex) {
                prepaMarcheService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / PrepaMarcheService");
                return prepaMarcheService;
            }
        }
        return prepaMarcheService;
    }

    public static IDroitsService getDroitsService() {
        if (droitService == null) {
            try {
                droitService = (IDroitsService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.DROITS__URL);
            } catch (NamingException ex) {
                droitService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / DroitsService");
                return droitService;
            }
        }
        return droitService;
    }
    
    public static IBanqueService getBanqueService() {
        if (banqueService == null) {
            try {
                banqueService = (IBanqueService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.BANQUE__URL);
            } catch (NamingException ex) {
                banqueService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / BanqueService");
                return banqueService;
            }
        }
        return banqueService;
    }
    
    public static IComptaService getComptaService() {
        if (comptaService == null) {
            try {
                comptaService = (IComptaService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.COMPTA__URL);
            } catch (NamingException ex) {
                comptaService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / ComptaService");
                return comptaService;
            }
        }
        return comptaService;
    }
    
    public static IClientService getClientService() {
        if (clientService == null) {
            try {
                clientService = (IClientService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.CLIENT__URL);
            } catch (NamingException ex) {
                clientService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / ClientService");
                return clientService;
            }
        }
        return clientService;
    }
    
    public static IVirementService getVirementService() {
        if (virementService == null) {
            try {
                virementService = (IVirementService) GrecoAppConfig.ctx().lookup(GrecoAppConfig.VIREMENT__URL);
            } catch (NamingException ex) {
                clientService = null;
                Logger.getLogger(GrecoServiceFactory.class.getName()).log(Level.SEVERE, null, ex);
                JOptionPane.showMessageDialog(null, NAMIMG_ERROR+" / VirementService");
                return virementService;
            }
        }
        return virementService;
    }
    
    
}
