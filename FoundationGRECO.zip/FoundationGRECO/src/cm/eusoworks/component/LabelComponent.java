/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.component;

import java.awt.Color;
import java.awt.Cursor;
import org.jdesktop.swingx.JXLabel;

/**
 *
 * @author ouethy
 */
public class LabelComponent extends JXLabel {

    private String texte;
    Color initialColor = new Color(240,240,240);
    
    public LabelComponent() {
        super();
        this.setHorizontalAlignment(javax.swing.SwingConstants.LEFT);
        this.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        this.setLineWrap(true);
        this.setMaxLineSpan(160);
        this.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                jXLabel1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                jXLabel1MouseExited(evt);
            }
        });
    }

    public LabelComponent(String text) {
        super(text);
    }
    
    private void jXLabel1MouseEntered(java.awt.event.MouseEvent evt) {                                      
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.HAND_CURSOR));
        initialColor = getForeground();
        setForeground(new Color(102,102,255));
    }                                     

    private void jXLabel1MouseExited(java.awt.event.MouseEvent evt) {                                     
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        setForeground(initialColor);
    }                                     

    public String getTexte() {
        return texte;
    }

    public void setTexte(String texte) {
        this.texte = texte;
        setText(texte);
    }
    
}
