/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.renderer;

import cm.eusoworks.entities.enumeration.EtatDossier;
import java.awt.Component;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author DISI
 */
public class BooleanTableRenderer   extends DefaultTableCellRenderer{
    
   
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        JLabel l = new JLabel();
        try {
            l.setHorizontalAlignment(CENTER);
            l.setIcon(getIcond((boolean)value));
            
        } catch (Exception e) {
        }
        return l; 
    }
    
    public ImageIcon getIcond(boolean value){
        if(value) return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_success_mini.png"));
        else  return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_erreur_mini.png"));
    }
}
