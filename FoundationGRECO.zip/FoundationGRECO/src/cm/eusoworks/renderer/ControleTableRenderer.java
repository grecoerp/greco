/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.renderer;

import cm.eusoworks.entities.view.VueControle;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author DISI
 */
public class ControleTableRenderer extends DefaultTableCellRenderer {

    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        this.setBackground(Color.WHITE);
        this.setOpaque(true);
        if (value instanceof Integer) {
            try {
                this.setHorizontalAlignment(CENTER);
                this.setIcon(getIcond((int) value));
            } catch (Exception e) {
            }
        } else if (value instanceof String) {
            try {
                //couleur du texte
                Object valueAt = table.getValueAt(row, 0);
                if (valueAt instanceof Integer) {
                    int s = (int) valueAt;
                    if (s == VueControle.ECHEC) {
                        this.setForeground(Color.red);
                    } else if (s == VueControle.WARNING) {
                        this.setForeground(new Color(214, 124, 0));
                    } else {
                        this.setForeground(Color.black);
                    }
                }
                this.setHorizontalAlignment(LEFT);
                this.setFont(new Font("arial", Font.PLAIN, 15));
                this.setText((String) value);
            } catch (Exception e) {
            }
        }
        if (isSelected) {
            setBackground(new Color(208, 217, 230));
            setForeground(new Color(105, 128, 151));
        }

        return this;
    }

    public ImageIcon getIcond(int value) {
        if (value == VueControle.SUCCESS) {
            return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_success_mini.png"));
        } else if (value == VueControle.ECHEC) {
            return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_erreur_mini.png"));
        } else if (value == VueControle.WARNING) {
            return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_warning_mini.png"));
        } else {
            return new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_erreur_mini.png"));
        }

    }
}
