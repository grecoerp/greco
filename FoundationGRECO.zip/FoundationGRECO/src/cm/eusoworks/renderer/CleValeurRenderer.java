/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.renderer;

import cm.eusoworks.entities.cls.CleValeur;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author macbook
 */
public class CleValeurRenderer  extends JLabel implements ListCellRenderer<CleValeur> {
    @Override
    public Component getListCellRendererComponent(JList<? extends CleValeur> list, CleValeur value, int index, boolean isSelected, boolean cellHasFocus) {

        setOpaque(true);
        setFont(new Font("Arial", Font.PLAIN, 14));
        setBackground(Color.white);
        if (value != null) {
            setFont(new Font("Arial", Font.ITALIC, 18));
            setForeground(Color.black);
            setText("("+ value.getCode().toString()+")   "+value.getLibelleFr()); 
        }

        if (isSelected) {
            setBackground(new Color(208, 217, 230));
            setForeground(new Color(105, 128, 151));
        }
        
        return this;
    }
}
