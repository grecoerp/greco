/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.renderer;

import cm.eusoworks.entities.enumeration.EtatDossier;
import cm.eusoworks.entities.view.VueStructureBCA;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author DISI
 */
public class ListVueStructureBCARenderer extends JLabel implements ListCellRenderer<VueStructureBCA> {

    @Override
    public Component getListCellRendererComponent(JList<? extends VueStructureBCA> list, VueStructureBCA value, int index, boolean isSelected, boolean cellHasFocus) {

        setOpaque(true);
        setFont(new Font("Arial", Font.PLAIN, 15));
        setBackground(Color.white);
        if (value != null) {
            if (value.getEtat() == EtatDossier.enregistre) {
                setForeground(new Color(110, 110, 110));
            } else if (value.getEtat() == EtatDossier.reserve) {
                setForeground(Color.black);
            } else if (value.getEtat() == EtatDossier.valide) {
                setForeground(Color.green);
            }else if (value.getEtat() == EtatDossier.rejeteCF_Visa) {
                setForeground(Color.red);
            }else {
                setForeground(Color.black);
            }
            setText(value.toString()); 
        }

        if (isSelected) {
            setBackground(new Color(208, 217, 230));
            setForeground(new Color(105, 128, 151));
        }
        
        return this;
    }

}
