/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.renderer;

import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.model.OperationBudgetaire;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;

/**
 *
 * @author DISI
 */
public class ComboOperationBudgetaireRenderer extends JLabel implements ListCellRenderer<OperationBudgetaire> {

    String indicator = "";

    @Override
    public Component getListCellRendererComponent(JList<? extends OperationBudgetaire> list, OperationBudgetaire value, int index, boolean isSelected, boolean cellHasFocus) {

        setOpaque(true);
        setFont(new Font("Arial", Font.PLAIN, 15));
        setBackground(Color.white);
        if (isSelected) {
            setBackground(new Color(208, 217, 230));
            setForeground(new Color(105, 128, 151));
        }
        if (value != null) {
            if (value.getBudgetExploite().equals(BudgetType.ETAT_REPORT)) {
                setForeground(new Color(125, 161, 237));
                indicator = "(R)  ";
            } else if (value.getBudgetExploite().equals(BudgetType.ETAT_INITIAL)) {
                setForeground(Color.black);
                indicator = "       ";
            } else if (value.getBudgetExploite().equals(BudgetType.ETAT_ADDITIF)) {
                setForeground(Color.ORANGE);
                indicator = "(A)  ";
            }
            setText(indicator + value.getCompteCode() + "  " + value.getCompteLibelle());
        }else {
            indicator = "       ";
            setForeground(Color.red);
            setText(indicator + "aucun paragraphe budgétaire");
        }

        
        
        return this;
    }

}
