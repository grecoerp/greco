/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.NiveauOrganique;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IUniteOrganiqueDao {

    public int ajouter(UniteOrganique org, int codeErreur)  throws GrecoException;

    public int modifier(UniteOrganique org, int codeErreur)  throws GrecoException;

    public void supprimer(String uniteOrganiqueID)  throws GrecoException;

    public UniteOrganique rechercherById(String uniteOrganiqueID);

    public UniteOrganique rechercherByOrder(int numOrdre);

    public List<UniteOrganique> listeUniteOrganique(String organisationID);
    
    public List<UniteOrganique> listeUniteOrganiqueFilles(String uniteOrganiqueID);
    
    public List<UniteOrganique> getUniteOrganiqueForStructure(String structureID);
    
    public List<UniteOrganique> getUniteOrganiqueFillesForStructure(String structureID);
    
    public int ajouterNiveau(NiveauOrganique org, int codeErreur)  throws GrecoException;

    public int modifierNiveau(NiveauOrganique org, int codeErreur)  throws GrecoException;

    public void supprimerNiveau(int niveauOrganiqueID)  throws GrecoException;
    
    public NiveauOrganique rechercherNiveauById(String niveauOrganiqueID);
    
    public List<NiveauOrganique> listeNiveauOrganique(String organisationID);
    
    public List<UniteOrganique> listeUniteOrganiqueByNiveau(String organisationID, int niveauOrganiqueID);
    
}
