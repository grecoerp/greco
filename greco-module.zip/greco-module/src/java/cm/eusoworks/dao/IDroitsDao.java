/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.MandatementDroits;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IDroitsDao {

    public int ajouter(Droits org, int codeErreur) throws GrecoException;

    public int modifier(Droits org, int codeErreur) throws GrecoException;

    public void supprimer(String droitID) throws GrecoException;

    public Droits rechercherById(String droitID);

    public List<Droits> listeDroits();

    public List<Droits> listeDroitsNAP();

    public List<Droits> listeDroitsRetenues();

    public int ajouterLiquidationDroit(List<LiquidationDroits> droits);

    public void supprimerLiquidationDroit(String liquidationID);

    public List<LiquidationDroits> listeLiquidationDroits(String liquidationID);

    public List<LiquidationDroits> listeLiquidationDroitsNAP(String liquidationID);

    public List<LiquidationDroits> listeLiquidationDroitsRetenues(String liquidationID);
    
    public int ajouterMandatementDroit(List<MandatementDroits> droits);

    public void supprimerMandatementDroit(String mandatementID);

    public List<MandatementDroits> listeMandatementDroits(String mandatementID);
}
