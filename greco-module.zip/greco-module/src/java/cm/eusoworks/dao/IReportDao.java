/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueEngagementBordereau;
import cm.eusoworks.entities.view.VueLiquidationReport;
import cm.eusoworks.entities.view.VueMandatementReport;
import cm.eusoworks.entities.view.VueMissionFiche;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.entities.view.VuePTAOperation;
import cm.eusoworks.entities.view.VuePTAParagraphe;
import cm.eusoworks.entities.view.VuePTAStructureParagraphe;
import cm.eusoworks.entities.view.VuePTATache;
import cm.eusoworks.entities.view.VuePTATacheParagraphe;
import cm.eusoworks.entities.view.VuePaieBulletin;
import cm.eusoworks.entities.view.VuePaieRecapRubrique;
import cm.eusoworks.entities.view.VuePaieRubrique;
import cm.eusoworks.entities.view.VueStructureCodification;
import cm.eusoworks.entities.view.VueSuiviFicheControle;
import cm.eusoworks.entities.view.VueSuiviFicheControleDetails;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IReportDao {

    public List<VuePTAOperation> getPTAOperation(String organisationID, String millesime);

    public List<VuePTATache> getPTATache(String organisationID, String millesime);

    public List<VuePTATacheParagraphe> getPTATacheParagraphe(String organisationID, String millesime);

    public List<VuePTAParagraphe> getPTAParagraphe(String organisationID, String millesime);

    public List<VueBCAReport> getBcaLignesReport(String bcaID);

    public VueOMReport getOM(String omID);

    public List<VueLiquidationReport> getLiquidation(String liquidationID);

    public List<VuePTAStructureParagraphe> getPTAStructureParagraphe(String millesime, String organisationID,
            String articleID, String compteCode);

    public List<VueEngagementBordereau> getBordereauTransmission(String numBordereau);

    public List<VueStructureCodification> getStructureCodification(String organisationID);

    public List<VueMandatementReport> getMandatementReport(String mandatementID) throws SQLException;

    public VuePaieBulletin getPaieBulletin(String employeID, String millesime, Date datedebut, Date dateFin);

    public List<VuePaieRubrique> getPaieRubriquesBase(String employeID, String millesime, Date datedebut, Date dateFin);

    public List<VuePaieRubrique> getPaieRubriquesRetenues(String employeID, String millesime, Date datedebut, Date dateFin);

    public List<VuePaieRubrique> getPaieRubriquesNet(String employeID, String millesime, Date datedebut, Date dateFin);
    
    public List<VuePaieRecapRubrique> getPaieRecapCotisations(Date dateDebut, Date dateFin);
    
    public List<VueSuiviFicheControle> getSuiviFicheControleAE(String millesime, String organisationID, String activiteID, String tacheID, int base);
    
    public List<VueSuiviFicheControleDetails> getSuiviFicheControleAEDetails(String tacheID, int base);
    
    public List<VueSuiviFicheControleDetails> getSuiviFicheConsolideeAEDetails(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base);
    
    public List<VueSuiviFicheControleDetails> getSuiviBudgetConsolideAE(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base);
    
    public List<VueMissionFiche> getMissionFiche(String organisationID, String millesime, String matricule);
    
    public List<VueSuiviFicheControleDetails> getFileFicheConsolideeDetails(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base);
    
    public List<VueSuiviFicheControleDetails> getFileBudgetConsolide(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base);
}
