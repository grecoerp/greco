/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.PrepaMarche;
import cm.eusoworks.entities.model.PrepaMarcheContractant;
import cm.eusoworks.entities.model.PrepaMarcheFinancement;
import cm.eusoworks.entities.model.PrepaMarchePrestation;
import cm.eusoworks.entities.model.PrepaMarcheTypeAO;
import cm.eusoworks.entities.view.VuePrepaMarche;
import cm.eusoworks.entities.view.VuePrepaMarcheArticle;
import cm.eusoworks.entities.view.VuePrepaMarcheJournal;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IPrepaMarcheDao {

    int deleteMarche(String paId);

    int saveMarche(String paId, String naturePrestationId, String contractantId, String typeAOId, String financementId, Integer numOrdre, String maitreOuvrage, Boolean annualite, String motifGreAGre, Date dateDebut, Date dateFin, Date dateLancement, Date dateAttribution, Date dateSignature, Date dateDemarrage, Date dateReception, Date dateLancementCP, Date dateAttributionCP, Date dateSignatureCP, Date dateDemarrageCP, Date dateReceptionCP, Integer annee1, String intitule1, BigDecimal cout1, Integer annee2, String intitule2, BigDecimal cout2, Integer annee3, String intitule3, BigDecimal cout3, Integer annee4, String intitule4, BigDecimal cout4, Integer annee5, String intitule5, BigDecimal cout5, Boolean uniteExistante, String intitule, String nom, String posteOccupe, String adresse, String email, String telephone, String userMaj, Date dateMaj);

    int deleteMarcheContractant(String contractantId);

    int saveMarcheContractant(String contractantId, String libelleFr, String libelleUs, String userMaj, Date dateMaj);

    int deleteMarcheFinancement(String financementId);

    int saveMarcheFinancement(String financementId, String abbreviation, String libelleFr, String libelleUs, String userMaj, Date dateMaj);

    int deleteMarchePrestation(String naturePrestationId);

    int saveMarchePrestation(String naturePrestationId, String code, String abbreviation, String libelleFr, String libelleUs, String userMaj, Date dateMaj);

    int deleteMarcheTypeAO(String typeAOId);

    int saveMarcheTypeAO(String typeAOId, String code, String libelle, String userMaj, Date dateMaj);

    List<PrepaMarche> getMarches(String exMillesime, String chCode, String paId, String naturePrestationId, String contractantId, String typeAOId, String financementId);

    List<PrepaMarcheContractant> getMarcheContractants(String contractantId);

    List<PrepaMarcheFinancement> getMarcheFinancements(String financementId);

    List<PrepaMarchePrestation> getMarchePrestations(String naturePrestationId);

    List<PrepaMarcheTypeAO> getMarcheTypeAOs(String typeAOId);

    List<OperationBudgetaire> getParagrapheParChapitreEtNature(String exMillesime, String chCode, String neLike);

    List<VuePrepaMarche> getMarcheByPaId(String paId);

    List<VuePrepaMarcheJournal> getMarcheJournal(String exMillesime, String chCode, String maitreOuvrage);

    List<VuePrepaMarcheJournal> getMarcheListeMO(String exMillesime, String chCode);
    
    List<VuePrepaMarche> getListeMarcheByExerciceChapitre(String exMillesime, String chCode);
    
    List<VuePrepaMarcheJournal> getListeMarcheAttribueByChapitre(String exMillesime, String chCode); 
    
    List<VuePrepaMarcheJournal> getListeMarcheAttribueByRegionAndChapitre(String exMillesime, String chCode, String prProvinceID);
    
    List<VuePrepaMarcheJournal> getMarcheAbbreviationUnique(String abbreviationSF,String abbreviationPr,String abbreviationAO); 
    
    List<VuePrepaMarche> getListeMarcheRecovery(String exMillesime, String chCode);
    
    List<VuePrepaMarcheArticle> getListeMarcheArticle(String arCode, String user);
}
