/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Virement;
import cm.eusoworks.entities.model.VirementTache;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IVirementDao {

    
    public String ajouterVirement(Virement act) throws GrecoException;
    
    public void modifierVirement(Virement act) throws GrecoException;
    
    public void ajouterTache(VirementTache v) throws GrecoException;

    public void supprimer(String virementID, String userUpdate) throws GrecoException;
    
    public void supprimerTaches(String virementID) throws GrecoException;

    public Virement getVirement(String virementID);

    public List<VirementTache> getListTache(String virementID);

    public List<Virement> getListVirement(String organisationID, String millesime, String budgetID, int mode);
    
    public List<VirementTache> getDisponibleTache(String organisationID, String millesime, String budgetID, String chapitre, String tacheCode, String paragraphe);
    
    public void reserver(String virementID, String userUpdate) throws GrecoException;
    
    public void reservation_annuler(String virementID, String userUpdate) throws GrecoException;
    
    public void visaBudgetaire(String virementID, String userUpdate) throws GrecoException;
    
    public void visaBudgetaire_annuler(String virementID, String userUpdate) throws GrecoException;
    
    public void valider(String virementID, String userUpdate, String arrete, Date dateSignature) throws GrecoException;
    
    public void valider_annuler(String virementID, String userUpdate) throws GrecoException;
    
}
