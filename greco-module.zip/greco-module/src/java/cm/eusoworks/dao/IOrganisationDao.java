/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.DatabaseOptions;
import cm.eusoworks.entities.model.Notes;
import cm.eusoworks.entities.model.OrgOptions;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IOrganisationDao {

    public int ajouter(Organisation org, int codeErreur) throws GrecoException;

    public int modifier(Organisation org, int codeErreur) throws GrecoException;

    public void supprimer(String organisationID) throws GrecoException;

    public Organisation rechercherById(String organisationID);

    public List<Organisation> rechercherByCode(String code);

    public List<Organisation> listeOrganisation(boolean active);
    
    public List<Organisation> listeOrganisationUsersByRole(String login, String role);

    public void ajouterStructure(Structure org) throws GrecoException;

    public void modifierStructure(Structure org) throws GrecoException;

    public void supprimerStructure(String structureID) throws GrecoException;

    public List<Structure> listeStructuresOrganisation(String organisationID);
    
    public List<Structure> listeStructuresUserByOrganisation(String organisationID, String login);

    public void saveParametres(String organisationID, String zoneEco, String paysFr, String paysUs, String deviseFr, String deviseUs, String orgSigleFr,
            String orgSigleUs, String orgLibelleFr, String orgLibelleUs, String orgContact, String appAbreviationFr, String appAbreviationUs, String appTitleFr, String appTitleUs,
            String user, String adresseIP, String machine, String motif, String tutelleFr, String tutelleUs);

    public void saveParametres(OrgOptions op);
    
    public void saveBackupDBParameters(String user_update, String ip_update, String organisationID, String adresseIP, String port, String username, String password, String database, String dumpPath) throws GrecoException;

    public DatabaseOptions databaseGetParameters(String organisationID);
    
    public OrgOptions getOptionOrganisation(String organisationID);

    public List<Structure> listeStructuresFilles(String organisationID, String structureID);

    public List<Structure> listeStructuresByUniteOrganique(String organisationID, String uniteOrganiqueID);

    public int structureMaxOrdre(String caCode, String loCode);

    public void noteModification(String user_update, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins);

    public void noteAjout(String userupdate, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins);

    public List<Notes> noteRechercher(String organisationID, String noteID, String moduleID, String userLogins, Date dateAffichageDebut, Date dateAffichageFin, String userupdate, Integer statut);

    public void noteSuppression(String noteID);

}
