/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao;

import cm.eusoworks.entities.model.ActiviteNiveau;
import cm.eusoworks.entities.model.CategorieNiveau;
import cm.eusoworks.entities.model.CompteNiveau;
import cm.eusoworks.entities.model.FonctionNiveau;
import cm.eusoworks.entities.model.LocaliteNiveau;
import cm.eusoworks.entities.model.OptionNiveauMax;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface INiveauDao {
    
    
    public void ajouterNiveauActivite(ActiviteNiveau act) throws GrecoException;
    public void modifierNiveauActivite(ActiviteNiveau act) throws GrecoException;
    public void supprimerNiveauActivite(int activiteNiveauID) throws GrecoException;
    public List<ActiviteNiveau> listeNiveauActivite();
    public ActiviteNiveau getNiveauActivite(int ID);
    
    public void ajouterNiveauCategorie(CategorieNiveau act) throws GrecoException;
    public void modifierNiveauCategorie(CategorieNiveau act) throws GrecoException;
    public void supprimerNiveauCategorie(int categorieNiveauID) throws GrecoException;
    public List<CategorieNiveau> listeNiveauCategorie();
    public CategorieNiveau getNiveauCategorie(int ID);
    
    public void ajouterNiveauCompte(CompteNiveau act) throws GrecoException;
    public void modifierNiveauCompte(CompteNiveau act) throws GrecoException;
    public void supprimerNiveauCompte(int compteNiveauID) throws GrecoException;
    public List<CompteNiveau> listeNiveauCompte();
    public CompteNiveau getNiveauCompte(int ID);
    
    public void ajouterNiveauFonction(FonctionNiveau act) throws GrecoException;
    public void modifierNiveauFonction(FonctionNiveau act) throws GrecoException;
    public void supprimerNiveauFonction(int fonctionNiveauID) throws GrecoException;
    public List<FonctionNiveau> listeNiveauFonction();
    public FonctionNiveau getNiveauFonction(int ID);
    
    public void ajouterNiveauLocalite(LocaliteNiveau act) throws GrecoException;
    public void modifierNiveauLocalite(LocaliteNiveau act) throws GrecoException;
    public void supprimerNiveauLocalite(int localiteNiveauID) throws GrecoException;
    public List<LocaliteNiveau> listeNiveauLocalite();
    public LocaliteNiveau getNiveauLocalite(int ID);
    
    public void saveParametreNiveau(int fu, int ca, int lo, int pc, int at, String userUpdate, String ipUpdate) throws GrecoException;
    public OptionNiveauMax getOptionNiveauxMax();
}
