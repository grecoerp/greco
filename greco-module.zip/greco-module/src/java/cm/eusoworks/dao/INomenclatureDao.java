/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface INomenclatureDao {
    
    public void ajouterCategorie(Categorie act) throws GrecoException;
    public void modifierCategorie(Categorie act) throws GrecoException;
    public void supprimerCategorie(String codeCategorie) throws GrecoException;
    public Categorie getCategorie(String codeCategorie);
    public List<Categorie> getListCategorieAll();
    public List<Categorie> getListCategorieByNiveau(int niveauID);
    public List<Categorie> getListCategorieRacines();
    public List<Categorie> getListCategorieChilds(String codeCategorie);
    
    public void ajouterFonction(Fonction act) throws GrecoException;
    public void modifierFonction(Fonction act) throws GrecoException;
    public void supprimerFonction(String codeFonction) throws GrecoException;
    public Fonction getFonction(String codeFonction);
    public List<Fonction> getListFonctionAll();
    public List<Fonction> getListFonctionByNiveau(int niveauID);
    public List<Fonction> getListFonctionRacines();
    public List<Fonction> getListFonctionChilds(String codeFonction);
    
    public void ajouterLocalite(Localite act) throws GrecoException;
    public void modifierLocalite(Localite act) throws GrecoException;
    public void supprimerLocalite(String codeLocalite) throws GrecoException;
    public Localite getLocalite(String codeLocalite);
    public List<Localite> getListLocaliteAll();
    public List<Localite> getListLocaliteByNiveau(int niveauID);
    public List<Localite> getListLocaliteRacines();
    public List<Localite> getListLocaliteChilds(String codeLocalite);
    
    public void ajouterCompte(Compte act, boolean creerIfNotExists) throws GrecoException;
    public void modifierCompte(Compte act) throws GrecoException;
    public void supprimerCompte(String codeCompte) throws GrecoException;
    public Compte getCompte(String codeCompte);
    public List<Compte> getListCompteAll();
    public List<Compte> getListCompteByNiveau(int niveauID);
    public List<Compte> getListCompteRacines();
    public List<Compte> getListCompteChilds(String codeCompte);
    public List<Compte> getListCompteUtilisables();
}
