/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.view.VueOpDisponiblePipe;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IOperationDao {

    //prepa
    public void prepaAjouter(PrepaOperationBudgetaire act) throws GrecoException;

    public void prepaModifier(PrepaOperationBudgetaire act) throws GrecoException;

    public void prepaSupprimer(String tacheID, String user) throws GrecoException;

    public PrepaOperationBudgetaire prepaGetOperation(String tacheID);

    public List<PrepaOperationBudgetaire> prepaGetListOperationByActivite(String activiteID, String budgetID);

    public List<PrepaOperationBudgetaire> prepaGetListOperationByActiviteWithCollectif(String activiteID, String budgetID, String budgetCollectifID);
    
    
    // execution
    public void ajouter(OperationBudgetaire act) throws GrecoException;

    public void modifier(OperationBudgetaire act) throws GrecoException;

    public void supprimer(String tacheID) throws GrecoException;

    public OperationBudgetaire getOperation(String tacheID);

    public List<OperationBudgetaire> getListOperationByActivite(String activiteID);
    
    public List<OperationBudgetaire> getListOperationByActiviteAndStructure(String activiteID, String structureID);

    public BigDecimal getDisponible(OperationBudgetaire op);
    
    public VueOpDisponiblePipe getDisponiblePipe(String tacheID);
    
    /*
    getListOperationByActiviteExec :
    Liste des operations budgetaires avec la dotation initiale et le disponible affichés en cours d'exécution 
    */
    public List<OperationBudgetaire> getListOperationByActiviteExecution(String activiteID, String budgetID);
    
    public void prepaCollectifInsert(String budgetID, String budgetCollectifID, PrepaOperationBudgetaire act) throws GrecoException;
    
    public int prepaCollectifEnExecution (String budgetInitialID, String budgetCollectifID,String user_update);
}
