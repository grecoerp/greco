/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.entities.model.Userpreferences;
import cm.eusoworks.entities.model.Users;
import cm.eusoworks.entities.view.VueTrack;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.UserGroupe;
import cm.eusoworks.entities.model.UserProfils;
import cm.eusoworks.entities.view.VueMachine;
import cm.eusoworks.entities.view.VueEntiteReduit;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IUserDao {

    public Users rechercher(String login)  throws GrecoException ;

    public boolean authentifier(String login, String password);

    public void saveConnection(String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName)  throws GrecoException ;
    
    public void journalisation(String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName, 
                                String os, String arhitecture, String function, String module, int categorie, String id);
    
    public List<Systeme> getSystemeListByUser(String login);
    

    public Userpreferences getUserPreferences(String login);

    public void savePreferences(String locale, boolean sound, boolean soundFail, boolean soundSuccess, boolean soundWait, String ipAdress, String userUpdate, String imageFond);

    public List<Modules> getModuleListByUser(String login);

    public void updatePassword(String login, String newPassword) throws GrecoException;

    public void deleteUser(String login) throws GrecoException;

    public List<Users> getListUsersByOrganisation(String organisationID);

    public void enregistrer(String user_update, String ip_update, String login, String password, String nom, String prenom,
            String immatriculation, String fonction, String email, boolean actif, String service, String organisationID, String structureID,
                String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String telephone)  throws GrecoException ;

    public void modifier(String user_update, String ip_update, String login, String password, String nom, String prenom,
            String immatriculation, String fonction, String email, boolean actif, String service, String organisationID, String structureID, 
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String telephone);
    
    public void modifierReseauSociaux(String user_update, String ip_update, String login,
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String email, String telephone)  throws GrecoException;
    
    public List<VueTrack> getTracking(String login, Date dateDebut, Date dateFin);
    
    public List<VueTrack> getTrackingMachine(String machineName, Date dateDebut, Date dateFin);
    
    public List<VueTrack> getTrackingDossier(String dossier);
    
    public List<VueMachine> getListMachine();
    
    public void profilInsert(String user_update, String ip_update, String profilID, String login, String groupeID);
    
    public void profilUpdate(String user_update, String ip_update, String profilID, String login, String groupeID);
    
    public void profilDeleteByLoginAndGroupe(String user_update, String ip_update, String login, String groupeID);
    
    public void profilDeleteByLogin(String user_update, String ip_update, String login);
    
    public void profilDeleteByGroupe(String user_update, String ip_update, String groupeID);
    
    public UserProfils profilGetByID(String profilID);
    
    public List<UserProfils> profilGetByLogin(String login);
    
    public List<UserProfils> profilGetByLoginAndModule(String login, String moduleID);
    
    public void groupeDeleteByGroup (String user_update, String ip_update, String groupeID);

    public void groupeInsert(String user_update, String ip_update, String groupeID, String libelleFr, String description, 
                                        String proprietaire, String profils);
    
    public void groupeUpdate(String user_update, String ip_update, String groupeID, String libelleFr, String description, 
                                        String proprietaire, String profils);
    
    public UserGroupe groupeGetByID(String groupeID);
    
    public List<UserGroupe> groupeGetByLogin(String login);
    
    public List<UserGroupe> groupeGetByModule(String moduleID);
    
    public List<UserGroupe> groupeGetByLoginAndModule(String login, String moduleID);
    
    public List<UserGroupe> groupeGetSousGroupe(String groupeID);
    
    public List<UserGroupe> groupeGetSousGroupeByProprietaire(String groupeID, String login);
    
    public List<VueEntiteReduit> userOrganisationList(String loginHierarchie, String login);
    
    public void userOrganisationDelete(String login);
    
    public void userOrganisationSave(String login, VueEntiteReduit org);
    
    public List<VueEntiteReduit> userStructureList(String loginHierarchie, String login) throws GrecoException ;;
    
    public void userStructureDelete(String login) throws GrecoException ;;
    
    public void userStructureSave(String login, VueEntiteReduit structure) throws GrecoException ;
    
    //source financement
    public List<VueEntiteReduit> userSourceFinancementList(String loginHierarchie, String login) throws GrecoException ;;
    
    public void userSourceFinancementDelete(String login) throws GrecoException ;;
    
    public void userSourceFinancementSave(String login, VueEntiteReduit structure) throws GrecoException ;
    
    public List<VueEntiteReduit> userProgrammeList(String loginHierarchie, String login, String millesime) throws GrecoException ;
        
    public List<VueEntiteReduit> userProgrammeActionList(String loginHierarchie, String login, String activiteParentID, String millesime) throws GrecoException ;
        
    public void userProgrammeDelete(String login, String millesime, int type) throws GrecoException ;
    
    public void userProgrammeSave(String login, String activiteParentID, String millesime, int type,  VueEntiteReduit activite) throws GrecoException;
}
