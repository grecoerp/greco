/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IDecisionDao {

    public String ajouterModele(DecisionModele d) throws GrecoException;

    public void modifierModele(DecisionModele d) throws GrecoException;

    public void supprimerModele(String modeleID, String user, String ipAdresse) throws GrecoException;

    public DecisionModele getModele(String modeleID);

    public List<DecisionModele> getModeleByOrganisation(String millesime, String organisationID);
    
    public String ajouterDecision(Decision d) throws GrecoException;

    public void modifierDecision(Decision d) throws GrecoException;

    public void supprimerDecision(String decisionID, String user, String ipAdresse) throws GrecoException;

    public Decision getDecision(String modeleID);

    public List<Decision> getDecisionByOrganisation(String millesime, String organisationID);
    
    public List<Decision> getDecisionByOrganisationAndDate(String millesime, String organisationID, Date date);
    
    public List<Date> getDateDecisionByOrganisation(String millesime, String organisationID);
    
    public void dupliquerModele(String modeleID, String name, String newModeleID);
    
    public void reservationDecision(String decisionID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException;
    
    public void reservationDecisionAnnuler(String decisionID, boolean annuler, String motif, String login, String adresseIP) throws GrecoException;
}
