/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.BcaArticles;
import cm.eusoworks.entities.view.VueStructureBCA;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.view.VueControle;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IBonCommandeDao {

    public String ajouter(Bca bca) throws GrecoException;

    public void modifier(Bca bca) throws GrecoException;
    
    public void modifierRIB(String bcaID, String rib) throws GrecoException;

    public void supprimer(String bcaID, String user, String ipAdresse) throws GrecoException;

    public Bca getBCA(String bcaID);

    public List<Bca> getBCAByOrganisation(String millesime, String organisationID);
    
    public List<Bca> getBCAByOrganisationNotUsed(String millesime, String organisationID);

    public List<Bca> getBCAByFournisseur(String millesime, String organisationID, String fournisseurID);

    public List<Bca> getBCAByOrdonnateur(String millesime, String organisationID, String matriculeOrdo);

    public List<Bca> getBCAByTache(String millesime, String organisationID, String tacheID);

    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID);
    
     public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID, int etat);
     
     public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID, int etat, String typeID);
     
     public List<VueControle> getControleResult(String bcaID, String typeID);
     
     public void reservationBCA(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException;

    /**
     * *********-----------lignes du bca ********************---
     */
    public void ajouterLigne(BcaArticles article) throws GrecoException;
    
    public void ajouterLigneDefinitive(BcaArticles article) throws GrecoException;

    public void modifierLigne(BcaArticles bcaArticle) throws GrecoException;

    public void supprimerLigne(String bcaId, String amId, String user, String ip) throws GrecoException;

    public List<BcaArticles> getBCALignes(String bcaID);
    
    public List<Article> getArticleLignes(String bcaID);
    
    public List<BcaArticles> getBCALignesDefinitive(String liquidationID);

    public BcaArticles getBCAArticle(String bcaID, String amId);
    
    public List<VueStructureBCA> getBCANumberByStructure(String millesime, String organisationID);
    
    public List<VueStructureBCA> getBCANumberByStructure(String millesime, String organisationID, String typeID);
    
    public void supprimerTousArticles(String bcaID,String user, String ip);
    
    public void supprimerTousArticlesDefinitive(String liquidationID,String user, String ip);
    
    public void reservationBCAAnnuler(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException ;
}
