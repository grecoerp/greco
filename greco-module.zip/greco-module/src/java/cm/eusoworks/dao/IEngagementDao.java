/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.cls.CleValeur;
import cm.eusoworks.entities.model.Bordereau;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.entities.view.VueEngagementJournal;
import cm.eusoworks.entities.view.VueEngagementLivre;
import cm.eusoworks.entities.view.VueEngagementStat;
import cm.eusoworks.entities.view.VueEngagementState;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Liasse;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.Mandatement;
import cm.eusoworks.entities.model.Paiement;
import cm.eusoworks.entities.view.VueControle;
import cm.eusoworks.entities.view.VueLeveeDetails;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IEngagementDao {

    public EngagementType getEngagementType(String typeID);

    public List<EngagementType> getEngagementType();
    
    public void engagementTypeJournaux(String organisationID, String jrn1, String jrn2, String jrn3, String jrn4, String jrn5);

    public String ajouter(Engagement e) throws GrecoException;

    public void modifier(Engagement act) throws GrecoException;

    public void supprimer(String engagementID, String user, String ipAdresse) throws GrecoException;

    public Engagement getEngagement(String engagementID);

    public Engagement getEngagementByDossier(String dossier);

    public List<Engagement> getEngagementByOrganisation(String millesime, String organisationID, String listeEtat);

    public List<Engagement> getEngagementByFournisseur(String millesime, String organisationID, String fournisseurID, String listeEtat);

    public List<Engagement> getEngagementByOrdonnateur(String millesime, String organisationID, String matriculeOrdo, String listeEtat);

    public List<Engagement> getEngagementByAgent(String millesime, String organisationID, String matriculeAgent, String listeEtat);

    public List<Engagement> getEngagementByTache(String millesime, String organisationID, String tacheID, String listeEtat);

    public List<Engagement> getEngagementByStructure(String millesime, String organisationID, String structureID, String listeEtat);

    public List<Engagement> getEngagementByType(String millesime, String organisationID, String typeID, String listeEtat);

    public List<Engagement> getEngagementByBCA(String millesime, String organisationID, String bcaID, String listeEtat);

    public List<Engagement> getEngagementByDecision(String millesime, String organisationID, String decisionID, String listeEtat);

    public List<Engagement> getEngagementByOM(String millesime, String organisationID, String omID, String listeEtat);

    public VueEngagementStat getEngagementStat(String exMillesime);

    public List<VueEngagementDossier> getDossiers(String organisationID, String millesime, String numdossier, String etat,
            String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin,
            Date dateValidDebut, Date dateValidFin, String beneficiare);
    
    public List<VueEngagementDossier> getDossiersResteALiquider(String organisationID, String millesime, String numdossier, String etat,
            String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin,
            Date dateValidDebut, Date dateValidFin, String beneficiare);

    public List<VueEngagementDossier> getMandatements(String organisationID, String millesime, String numdossier, String etat,
            String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin,
            Date dateValidDebut, Date dateValidFin, String beneficiare);
    
    public List<VueEngagementJournal> getJournal(String engagementID);

    public void reservation(String engagementID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException;

    ;
    
    public void annulerReservation(String engagementID, boolean annule, String motif, String login, String adresseIP) throws GrecoException;

    public List<VueEngagementLivre> getLivreJournal(String organisationID, String millesime, String numdossier, String etat,
            String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin,
            Date dateValidDebut, Date dateValidFin, String beneficiare);

    public String genererBordereau(String organisationID, String millesime, int type,
            String source, String destination, String agent, String userUpdate);

    public void transmissionEngagement(String organisationID, String millesime, String bordereau, VueEngagementDossier dossier, int etatDossier, String userUpdate);

    public VueEngagementLivre getFicheDossier(String numDossier);

    public List<Bordereau> getBordereauTransmission(String organisationID, String millesime, String numBordereau, String numdossier, Date dateEnregDebut, Date dateEnregFin, int typeTransmission);

    public List<VueEngagementDossier> getDossiersByNumBordereau(String numBordereau);

    public List<Bordereau> getBordereauTransmissionEnCours(String organisationID, String millesime, int typeTransmission);

    public List<VueEngagementDossier> getDossiersAtTypeTransmission(String organisationID, String millesime, String numBordereau, String numdossier, Date dateEnregDebut, Date dateEnregFin, int typeTransmission);

    public void transmissionAnnulationEngagement(String organisationID, String millesime, String bordereau, VueEngagementDossier dossier, int etatDossier, String userUpdate);

    public String valider(String engagementID, boolean valider, String motif, String user);
    
    public String validerRegularite(String engagementID, boolean valider, String motif, String user);
    
    public void validerRegulariteOP(Mandatement mandat);

    public void valider_annuler(String engagementID, String motif, String user);

    public VueEngagementState getEtatengagement(String numDossier);

    public void demandeLevee(String id, int type, VueControle vue, String userDemande);

    public void leveeDemande(String id, int type, int numeroControle, String userLevee);

    public void deleteDemandeLevee(String id, int type);

    public void liquidationEnregistrement(String userUpdate, String ipAdresse, String machine, String liquidationID, String engagementID, String objet,
            BigDecimal montantTVA, BigDecimal montantIR, BigDecimal montantNAP, BigDecimal montantRG, String beneficiaire, String pieces, String livrables) throws GrecoException;

    public void liquidationModifier(String userUpdate, String ipAdresse, String machine, String liquidationID, String engagementID, String objet,
            BigDecimal montantTVA, BigDecimal montantIR, BigDecimal montantNAP, BigDecimal montantRG, String beneficiaire, String pieces, String livrables) throws GrecoException;

    public void liquidationSupprimer(String userUpdate, String ipAdresse, String machine, String liquidationID) throws GrecoException;

    public void liquidationValider(String userUpdate, String ipAdresse, String machine, String liquidationID, String observations, boolean isValidation, String engagementID) throws GrecoException;

    public void liquidationValiderAnnuler(String userUpdate, String ipAdresse, String machine, String liquidationID, String observations, String engagementID) throws GrecoException;

    public Liquidation liquidationFind(String liquidationID);

    public List<Liquidation> liquidationByEngagement(String engagementID);

    public List<Liquidation> liquidationByEtat(String engagementID, int etat);

    public List<Liquidation> liquidationByEtatOnly(String organisationID, String millesime, String numdossier, String etat);

    public void MandatementEnregistrement(String userUpdate, String ipAdresse, String machine, String mandatementID, String liquidationID, String ordonnateur,
            BigDecimal montantMandate, String rib, String numeroOP, String objet) throws GrecoException;

    public void MandatementModifier(String userUpdate, String ipAdresse, String machine, String mandatementID, String ordonnateur, String rib, String numeroOP, String objet) throws GrecoException;

    public void MandatementSupprimer(String userUpdate, String ipAdresse, String machine, String mandatementID) throws GrecoException;

    public Mandatement MandatementFind(String mandatementID);

    public List<Mandatement> MandatementFindByLiquidation(String liquidationID);

    public List<Mandatement> MandatementEnCours();

    public List<Mandatement> MandatementByEtat(String organisationID, String millesime, String numdossier, String etat);

    public List<Mandatement> MandatementByEtatRubriques(String organisationID, String millesime, String numdossier, String etat);
    
    public List<Mandatement> MandatementByEtatRubriquesPaiement(String organisationID, String millesime, String numdossier, String etat);
    
    public void MandatementValider(String userUpdate, String ipAdresse, String machine, String mandatementID, String pieces) throws GrecoException;

    public void MandatementValiderAnnuler(String userUpdate, String ipAdresse, String machine, String mandatementID, String motif) throws GrecoException;

    public int MandatementLiasseAjouter(String mandatementID, List<String> liasse, String userUpdate, String ipUpdate) throws GrecoException;;

    public void MandatementLiasseSupprimer(String mandatementID);

    public List<Liasse> MandatementLiasseListe(String mandatementID);

    public List<Liasse> MandatementLiasseListeComplete(String mandatementID);

    public VueControle controle(String id, String libelle, int typeProcedure, int controleID);

    public void ajouterLiasse(Liasse l) throws GrecoException;

    public void modifierLiasse(Liasse pc) throws GrecoException;

    public void supprimerLiasse(String liasseID) throws GrecoException;

    public List<Liasse> getLiasse();

    public List<Liasse> getLiasse(String mandatementID);

    public List<Liasse> getLiasseByEngagement(String engagementID);
    
    public String ajouterPipe(Engagement e) throws GrecoException;

    public void modifierPipe(Engagement act) throws GrecoException;
    
    public boolean modifierPipeOP(VueEngagementDossier dossier) throws GrecoException;

    public void supprimerPipe(String engagementPipeID, String user, String ipAdresse) throws GrecoException;
    
    public List<VueEngagementDossier> getEngagementPipe(String millesime, String organisationID, String programmeID, String operationID, String typeID, String beneficiaire, int nbJours, boolean isPipe);
    
    public Engagement getEngagementPipe(String engagementPipeID);
    
    public void validationComptable(String mandatementID, boolean validerCreance, boolean ValiderPaiement) throws GrecoException;
    
    public void validationComptableAnnuler(String mandatementID, String numDossier, boolean validerCreance, boolean ValiderPaiement) throws GrecoException;
    
    public void validationComptablePaiement(Paiement mandatementID, boolean validerCreance) throws GrecoException;
    
    public List<CleValeur> leveeListByType(String organisationID, String millesime, String typeID);
    
    public List<VueLeveeDetails> leveeListByTypeDetails(String organisationID, String millesime, int typeID, int numeroControle);
    
    public void leveeUpdateBlocage(String leveeID, int statut, String userAutorise);
}
