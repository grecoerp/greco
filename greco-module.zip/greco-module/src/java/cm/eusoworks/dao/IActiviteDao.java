/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaActivite;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IActiviteDao {

    public void ajouter(Activite act) throws GrecoException;

    public void modifier(Activite act) throws GrecoException;

    public void supprimer(String activiteID) throws GrecoException;

    public Activite getActivite(String activiteID);

    public List<Activite> getListActivite(String organisationID, String millesime);

    public List<Activite> getListActiviteRoots(String organisationID, String millesime);

    public List<Activite> getListActiviteChilds(String activiteID);

    public List<Activite> getListActiviteChildsAndOperationCount(String activiteID);

    public int copierOperation(String TacheSourceID, String tacheDestinationID, String structureDestinationID);

    public List<Activite> getListActiviteNiveau(String organisationID, int niveauID, String millesime);

    public List<Activite> getListTacheBudgetiseByStructure(String millesime, String organisationID, String structureID);

    //prepa activite
    public void prepaAjouter(PrepaActivite act) throws GrecoException;

    public void prepaModifier(PrepaActivite act) throws GrecoException;

    public void prepaSupprimer(String activiteID) throws GrecoException;

    public PrepaActivite prepaGetActivite(String activiteID);

    public List<PrepaActivite> prepaGetListActivite(String organisationID, String millesime);

    public List<PrepaActivite> prepaGetListActiviteRoots(String organisationID, String millesime);
    
    public List<PrepaActivite> prepaGetListActiviteRootsByBudget(String organisationID, String millesime, String budgetID);

    public List<PrepaActivite> prepaGetListActiviteChilds(String activiteID);
    
    public List<PrepaActivite> prepaGetListActiviteChildsByBudget(String activiteID, String budgetID);

    public List<PrepaActivite> prepaGetListActiviteChildsAndOperationCount(String activiteID);
    
    public List<PrepaActivite> prepaGetListActiviteChildsAndOperationCountByBudget(String activiteID, String budgetID);

    public int prepaCopierOperation(String TacheSourceID, String tacheDestinationID, String structureDestinationID);

    public List<PrepaActivite> prepaGetListActiviteNiveau(String organisationID, int niveauID, String millesime);
    
    public List<PrepaActivite> prepaGetListTacheBudgetiseByStructure(String millesime, String organisationID, String structureID);
}
