/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao;

import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface ISystemeDao {
    
    public List<Systeme> getListSysteme();
    
    public List<Systeme> getSystemeListWithHabilitation(String login);
    
    public List<Modules> getModuleListWithHabilitation(String login);
    
    public List<Modules> getModuleListWithHabilitation(String login, String systemeID);
    
    public List<Systeme> getSystemeListByLogin(String login);
}
