/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Axe;
import cm.eusoworks.entities.model.ComptaLibelle;
import cm.eusoworks.entities.model.CompteLiquidite;
import cm.eusoworks.entities.model.Devise;
import cm.eusoworks.entities.model.Ecritures;
import cm.eusoworks.entities.model.Journaux;
import cm.eusoworks.entities.model.ReglementMode;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IComptaDao {

    // <editor-fold defaultstate="collapsed" desc="ReglementMode">
    public void reglementModeAjouter(ReglementMode rg);

    public void reglementModeModifier(ReglementMode rg);

    public void reglementModeSupprimer(String ReglementModeID);

    public ReglementMode reglementModeRechercher(String reglementModeID);

    public List<ReglementMode> reglementModeListe();
    // </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="Devises">
    public void deviseAjouter(Devise dv);

    public void deviseModifier(Devise dv);

    public void deviseSupprimer(String deviseID);

    public Devise deviseRechercher(String deviseID);

    public List<Devise> deviseRechercherLabel(String label);

    public List<Devise> deviseList();

    // </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="Axe">
    public void axeAjouter(Axe dv);

    public void axeModifier(Axe dv);

    public void axeSupprimer(String axeID);

    public List<Axe> axeList();

    // </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="Journaux comptables">
    public void journauxAjouter(Journaux dv);

    public void journauxModifier(Journaux dv);

    public void journauxSupprimer(String axeID);

    public List<Journaux> journauxList();

    // </editor-fold> 
    
     // <editor-fold defaultstate="collapsed" desc="Compta libelle automatique">
    public List<ComptaLibelle> comptaLibelleList(String organisationID );

    public void comptaLibelleDeleteAll(String organisationID);

    public void comptaLibelleInsert(String organisationID, String code, String Libelle) throws GrecoException;


    // </editor-fold> 
    
     // <editor-fold defaultstate="collapsed" desc="Compte de liquidite banque et caisse">
    
    public void liquiditeAjouter(CompteLiquidite org) throws GrecoException;

    public void liquiditeModifier(CompteLiquidite org) throws GrecoException;

    public void liquiditeSupprimer(String liquiditeID) throws GrecoException;

    public CompteLiquidite liquiditeRechercherById(String liquiditeID);

    public List<CompteLiquidite> liquiditeListe(int type);
    
    
    // </editor-fold> 
    
    // <editor-fold defaultstate="collapsed" desc="ecriture">
    public void ecritureComptable( Ecritures ecriture) throws GrecoException;
    
    public int ecritureNumOrdreValidation();
    // </editor-fold> 
}
