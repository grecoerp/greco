/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.view.VueAgentOM;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IOrdreMissionDao {

    public String ajouter(OrdreMission om) throws GrecoException;

    public void modifier(OrdreMission om) throws GrecoException;

    public void supprimer(String omID, String user, String ipAdresse) throws GrecoException;

    public OrdreMission getOrdreMission(String omID);

    public List<OrdreMission> getOMByOrganisation(String millesime, String organisationID);

    public List<OrdreMission> getOMByAgent(String millesime, String organisationID, String matricule);

    public List<OrdreMission> getOMByTache(String millesime, String organisationID, String tacheID);

    public List<OrdreMission> getOMByStructure(String millesime, String organisationID, String structureID);

    public List<VueAgentOM> getOMNumberByAgent(String millesime, String organisationID);
    
    public void reservationOM(String omID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException;
    
    public void reservationOMAnnuler(String decisionID, boolean annuler, String motif, String login, String adresseIP) throws GrecoException;
}
