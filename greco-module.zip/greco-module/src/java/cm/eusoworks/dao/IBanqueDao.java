/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao;

import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Agence;
import cm.eusoworks.entities.model.Banque;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface IBanqueDao {

    public void banqueAjout(Banque b) throws GrecoException;

    public void banqueModifier(Banque b) throws GrecoException;

    public void banqueSupprimer(String codeBanque, boolean withAgences) throws GrecoException;

    public Banque banqueRechercher(String codeBanque);
    
    public List<Banque> banqueListe();
    
    
    public void agenceAjout(Agence a) throws GrecoException;

    public void agenceModifier(Agence a) throws GrecoException;

    public void agenceSupprimer(String codeBanque, String codeAgence) throws GrecoException;

    public Agence agenceRechercher(String codeAgence, String codeBanque);
    
    public List<Agence> agenceListe(String codeBanque);
    
    
    public List<VueFournisseurRIB> ribByFournisseur(String fournisseurID);
    
    public void ribSupprimer(String user, String adresseIP, String rib) throws GrecoException;
    
    public void ribAjout(String user_update, String ip_update, String fournisseurBanqueID, String fournisseurID, String codeBanque, String rib) throws GrecoException;
    
    
}
