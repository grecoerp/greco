/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao;

import cm.eusoworks.entities.model.SourceFinancement;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Local
public interface ISourceFinancementDao {
    
   public void ajouter(SourceFinancement sf)  throws GrecoException;

    public void modifier(SourceFinancement sf)  throws GrecoException;

    public void supprimer(String sourceFinancementID)  throws GrecoException;

    public SourceFinancement rechercherById(String sourceFinancementID);
    
    public List<SourceFinancement> listeSourceFinancement();

    public List<SourceFinancement> listeSourceFinancement(String login);
}
