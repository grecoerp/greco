/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.ISourceFinancementDao;
import cm.eusoworks.entities.model.SourceFinancement;
import cm.eusoworks.entities.exception.GrecoException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class SourceFinancementDao implements ISourceFinancementDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;
    
    
    @Override
    public void ajouter(SourceFinancement pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSourceFin_Insert(?, ?, ?, ?, ?, ?, ? )");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getFinancementID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getFinancementID());
            }
            if (pc.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getAbbreviationFr());
            }
            if (pc.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getAbbreviationUs());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, pc.getLibelleUs());
            }
            
            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(SourceFinancement pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSourceFin_Update(?, ?, ?, ?, ?, ?, ? )");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getFinancementID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getFinancementID());
            }
            if (pc.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getAbbreviationFr());
            }
            if (pc.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getAbbreviationUs());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, pc.getLibelleUs());
            }
            
            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String financementID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSourceFin_Delete(?)");
            stmt.setString(1, financementID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public SourceFinancement rechercherById(String financementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSourceFin_Find(?)");
            stmt.setString(1, financementID);
            
            SourceFinancement o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new SourceFinancement();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setFinancementID(rs.getString("financementID"));
                if (rs.wasNull()) {
                    o.setFinancementID(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<SourceFinancement> listeSourceFinancement(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSourceFin_ListByUser( ? )");
            stmt.setString(1, login);
            
            List<SourceFinancement> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                SourceFinancement o = new SourceFinancement();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setFinancementID(rs.getString("financementID"));
                if (rs.wasNull()) {
                    o.setFinancementID(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<SourceFinancement> listeSourceFinancement() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSourceFin_List()");
            
            List<SourceFinancement> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                SourceFinancement o = new SourceFinancement();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setFinancementID(rs.getString("financementID"));
                if (rs.wasNull()) {
                    o.setFinancementID(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}


