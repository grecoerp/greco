/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IExerciceDao;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.PrepaBudgetLexique;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ExerciceDao implements IExerciceDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public void ajouter(Exercice act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getMillesime());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getDateDebut() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(act.getDateDebut().getTime()));
            }
            if (act.getDateFin() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(act.getDateFin().getTime()));
            }

            stmt.setBoolean(8, act.getEnProgrammation());
            stmt.setBoolean(9, act.getEnBudgetisation());
            stmt.setBoolean(10, act.getEnExecution());
            stmt.setBoolean(11, act.getEnCloture());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(Exercice act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getMillesime());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getDateDebut() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(act.getDateDebut().getTime()));
            }
            if (act.getDateFin() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(act.getDateFin().getTime()));
            }

            stmt.setBoolean(8, act.getEnProgrammation());
            stmt.setBoolean(9, act.getEnBudgetisation());
            stmt.setBoolean(10, act.getEnExecution());
            stmt.setBoolean(11, act.getEnCloture());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String millesime) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Delete(?)");
            stmt.setString(1, millesime);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Exercice getExercice(String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Find(?)");

            stmt.setString(1, millesime);

            Exercice o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Exercice();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    o.setDateDebut(null);
                }
                o.setDateFin(rs.getDate("datefin"));
                if (rs.wasNull()) {
                    o.setDateFin(null);
                }
                o.setEnProgrammation(rs.getBoolean("enProgrammation"));
                o.setEnBudgetisation(rs.getBoolean("enBudgetisation"));
                o.setEnExecution(rs.getBoolean("enExecution"));
                o.setEnCloture(rs.getBoolean("enCloture"));
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Exercice> getListExercice() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_SL()");

            List<Exercice> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Exercice o = new Exercice();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    o.setDateDebut(null);
                }
                o.setDateFin(rs.getDate("datefin"));
                if (rs.wasNull()) {
                    o.setDateFin(null);
                }
                o.setEnProgrammation(rs.getBoolean("enProgrammation"));
                o.setEnBudgetisation(rs.getBoolean("enBudgetisation"));
                o.setEnExecution(rs.getBoolean("enExecution"));
                o.setEnCloture(rs.getBoolean("enCloture"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Exercice> getListExerciceElaboration() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Prog()");

            List<Exercice> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Exercice o = new Exercice();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    o.setDateDebut(null);
                }
                o.setDateFin(rs.getDate("datefin"));
                if (rs.wasNull()) {
                    o.setDateFin(null);
                }
                o.setEnProgrammation(rs.getBoolean("enProgrammation"));
                o.setEnBudgetisation(rs.getBoolean("enBudgetisation"));
                o.setEnExecution(rs.getBoolean("enExecution"));
                o.setEnCloture(rs.getBoolean("enCloture"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Exercice> getListExerciceBudgetisation() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Bud()");

            List<Exercice> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Exercice o = new Exercice();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    o.setDateDebut(null);
                }
                o.setDateFin(rs.getDate("datefin"));
                if (rs.wasNull()) {
                    o.setDateFin(null);
                }
                o.setEnProgrammation(rs.getBoolean("enProgrammation"));
                o.setEnBudgetisation(rs.getBoolean("enBudgetisation"));
                o.setEnExecution(rs.getBoolean("enExecution"));
                o.setEnCloture(rs.getBoolean("enCloture"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Exercice> getListExerciceExecution() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Exec()");

            List<Exercice> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Exercice o = new Exercice();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    o.setDateDebut(null);
                }
                o.setDateFin(rs.getDate("datefin"));
                if (rs.wasNull()) {
                    o.setDateFin(null);
                }
                o.setEnProgrammation(rs.getBoolean("enProgrammation"));
                o.setEnBudgetisation(rs.getBoolean("enBudgetisation"));
                o.setEnExecution(rs.getBoolean("enExecution"));
                o.setEnCloture(rs.getBoolean("enCloture"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Exercice> getListExerciceCloture() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psExercice_Clot()");

            List<Exercice> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Exercice o = new Exercice();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    o.setDateDebut(null);
                }
                o.setDateFin(rs.getDate("datefin"));
                if (rs.wasNull()) {
                    o.setDateFin(null);
                }
                o.setEnProgrammation(rs.getBoolean("enProgrammation"));
                o.setEnBudgetisation(rs.getBoolean("enBudgetisation"));
                o.setEnExecution(rs.getBoolean("enExecution"));
                o.setEnCloture(rs.getBoolean("enCloture"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void budgetAjouter(PrepaBudget act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getMillesime());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getBudgetID() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getBudgetID());
            }

            stmt.setInt(7, act.getType());
            
            if (act.getEtat() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getEtat());
            }
            if (act.getReference()== null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getReference()); 
            }

            if (act.getOrganisationID()== null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getOrganisationID()); 
            }
            if (act.getNotePresentationFr()== null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getNotePresentationFr()); 
            }
            if (act.getNotePresentationUs()== null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getNotePresentationUs()); 
            }
            if (act.getBudgetCollectifInitial()== null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, act.getBudgetCollectifInitial()); 
            }

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void budgetModifier(PrepaBudget act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }

            if (act.getLibelleFr() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleUs());
            }
            if (act.getBudgetID() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getBudgetID());
            }
            if (act.getEtat() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getEtat());
            }
            if (act.getReference()== null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getReference()); 
            }
            if (act.getNotePresentationFr()== null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getNotePresentationFr()); 
            }
            if (act.getNotePresentationUs()== null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getNotePresentationUs()); 
            }
            if (act.getBudgetCollectifInitial()== null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getBudgetCollectifInitial()); 
            }

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void budgetSupprimer(String userDelete, String ipDelete, String budgetID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_Delete(?, ?, ?)");
            if (userDelete == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, userDelete);
            }
            if (ipDelete == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ipDelete);
            }
            if (budgetID == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, budgetID);
            }
            
            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public PrepaBudget budgetGetByID(String budgetID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_S(?)");

            stmt.setString(1, budgetID);

            PrepaBudget o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new PrepaBudget();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setBudgetID(rs.getString("budgetID"));
                if (rs.wasNull()) {
                    o.setBudgetID(null);
                }
                o.setEtat(rs.getString("etat"));
                if (rs.wasNull()) {
                    o.setEtat(null);
                }
                o.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    o.setReference(null);
                }
                o.setType(rs.getInt("type"));
                
                o.setNumOrdre(rs.getInt("numOrdre"));
                
                o.setVolumeAE(rs.getBigDecimal("ae"));
                
                o.setVolumeCP(rs.getBigDecimal("cp"));
                 
                o.setOrganisationID(rs.getString("organisationID"));
                
                o.setEnLigne(rs.getBoolean("enLigne"));
                
                o.setNotePresentationFr(rs.getString("noteFr"));
                
                o.setNotePresentationUs(rs.getString("noteUs"));
                
                try {
                    o.setBudgetCollectifInitial(rs.getString("collectifInitialID"));
                } catch (Exception e) {
                }
                
                
            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaBudget> budgetGetByMillesime(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_SL(?, ?)");

            stmt.setString(1, organisationID);
            stmt.setString(2, millesime);

            List<PrepaBudget> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PrepaBudget o = new PrepaBudget();
                o = new PrepaBudget();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setBudgetID(rs.getString("budgetID"));
                if (rs.wasNull()) {
                    o.setBudgetID(null);
                }
                o.setEtat(rs.getString("etat"));
                if (rs.wasNull()) {
                    o.setEtat(null);
                }
                o.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    o.setReference(null);
                }
                o.setType(rs.getInt("type"));
                
                o.setNumOrdre(rs.getInt("numOrdre"));
                
                o.setVolumeAE(rs.getBigDecimal("ae"));
                
                o.setVolumeCP(rs.getBigDecimal("cp"));
                 
                o.setOrganisationID(rs.getString("organisationID"));
                
                o.setEnLigne(rs.getBoolean("enLigne"));
                
                o.setNotePresentationFr(rs.getString("noteFr"));
                
                o.setNotePresentationUs(rs.getString("noteUs"));
                
                try {
                    o.setBudgetCollectifInitial(rs.getString("collectifInitialID"));
                } catch (Exception e) {
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaBudget> budgetGetByMillesime(String organisationID, String millesime, int typeBudget) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudgetType_SL(?, ?, ?)");

            stmt.setString(1, organisationID);
            stmt.setString(2, millesime);
            stmt.setInt(3, typeBudget);

            List<PrepaBudget> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PrepaBudget o = new PrepaBudget();
                o = new PrepaBudget();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setBudgetID(rs.getString("budgetID"));
                if (rs.wasNull()) {
                    o.setBudgetID(null);
                }
                o.setEtat(rs.getString("etat"));
                if (rs.wasNull()) {
                    o.setEtat(null);
                }
                o.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    o.setReference(null);
                }
                o.setType(rs.getInt("type"));
                
                o.setNumOrdre(rs.getInt("numOrdre"));
                
                o.setVolumeAE(rs.getBigDecimal("ae"));
                
                o.setVolumeCP(rs.getBigDecimal("cp"));
                
                o.setOrganisationID(rs.getString("organisationID"));
                
                o.setEnLigne(rs.getBoolean("enLigne"));
                
                o.setNotePresentationFr(rs.getString("noteFr"));
                
                o.setNotePresentationUs(rs.getString("noteUs"));
                
                try {
                    o.setBudgetCollectifInitial(rs.getString("collectifInitialID"));
                } catch (Exception e) {
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaBudget> budgetGetByMillesimeOnLine(String organisationID, String millesime, boolean online) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_OnLine(?, ?, ?)");

            stmt.setString(1, organisationID);
            stmt.setString(2, millesime);
            if(online) stmt.setBoolean(3, true);
            else stmt.setBoolean(3, false);
            

            List<PrepaBudget> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PrepaBudget o = new PrepaBudget();
                o = new PrepaBudget();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setBudgetID(rs.getString("budgetID"));
                if (rs.wasNull()) {
                    o.setBudgetID(null);
                }
                o.setEtat(rs.getString("etat"));
                if (rs.wasNull()) {
                    o.setEtat(null);
                }
                o.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    o.setReference(null);
                }
                o.setType(rs.getInt("type"));
                
                o.setNumOrdre(rs.getInt("numOrdre"));
                
                o.setVolumeAE(rs.getBigDecimal("ae"));
                
                o.setVolumeCP(rs.getBigDecimal("cp"));
                 
                o.setOrganisationID(rs.getString("organisationID"));
                
                o.setEnLigne(rs.getBoolean("enLigne"));
                
                try {
                    o.setBudgetCollectifInitial(rs.getString("collectifInitialID"));
                } catch (Exception e) {
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void budgetLexique(String organisationID, String millesime, String lexiqueFr, String lexiqueUs) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudgetLexique(?, ?, ?, ?)");

            stmt.setString(1, organisationID);
            stmt.setString(2, millesime);
            stmt.setString(3, lexiqueFr);
            stmt.setString(4, lexiqueUs);

            stmt.executeQuery();
            
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public PrepaBudgetLexique budgetLexiqueFind(String organisationID, String millesime) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudgetLexique_Find(?, ?)");

            stmt.setString(1, organisationID);
            stmt.setString(2, millesime);
            

            PrepaBudgetLexique p = null; //
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                p = new PrepaBudgetLexique();
                
                p.setOrganisationID(rs.getString("organisationID"));
                p.setMillesime(rs.getString("millesime"));
                p.setLexiqueFr(rs.getString("lexiqueFr"));
                p.setLexiqueUs(rs.getString("lexiqueUs"));
            }
            return p;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void budgetTransfererEnExecution(String millesime, String budgetID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaBudget_Transferer( ?, ? )");

            stmt.setString(1, millesime);
            stmt.setString(2, budgetID);
            
            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
