/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IVirementDao;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Virement;
import cm.eusoworks.entities.model.VirementTache;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class VirementDao implements IVirementDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public String ajouterVirement(Virement e) throws GrecoException {
        Connection con = null;
        String numVirement = null;
        con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psVirement_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getLastUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(1, new java.sql.Date(e.getLastUpdate().getTime()));
            }
            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getIpUpdate());
            }
            if (e.getVirementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getVirementID());
            }

            stmtpsEngagementInsert.setInt(5, e.getEtat());

            if (e.getDateValidation() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(6, new java.sql.Date(e.getDateValidation().getTime()));
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(7, e.getReference());
            }
            if (e.getObjet() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getObjet());
            }
            if (e.getDateSignature() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(9, new java.sql.Date(e.getDateSignature().getTime()));
            }
            if (e.getSignataire() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(10, e.getSignataire());
            }

            if (e.getDebit() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(11, e.getDebit());
            }
            if (e.getCredit() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(12, e.getCredit());
            }

            if (e.getOrganisationID() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(13, e.getOrganisationID());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(14, e.getMillesime());
            }

            if (e.getGestionnaire() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(15, e.getGestionnaire());
            }

            if (e.getNumVirement() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(16, e.getNumVirement());
            }

            if (e.getBudgetID() == null) {
                stmtpsEngagementInsert.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(17, e.getBudgetID());
            }
            if (e.getTitre() == null) {
                stmtpsEngagementInsert.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(18, e.getTitre());
            }
            if (e.getContenu() == null) {
                stmtpsEngagementInsert.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(19, e.getContenu());
            }

            stmtpsEngagementInsert.registerOutParameter(16, java.sql.Types.VARCHAR);

            stmtpsEngagementInsert.executeUpdate();

            numVirement = stmtpsEngagementInsert.getString(16);

            return numVirement;

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierVirement(Virement e) throws GrecoException {
        Connection con = null;
        String numVirement = null;
        con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psVirement_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getLastUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(1, new java.sql.Date(e.getLastUpdate().getTime()));
            }
            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getIpUpdate());
            }
            if (e.getVirementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getVirementID());
            }

            stmtpsEngagementInsert.setInt(5, e.getEtat());

            if (e.getDateValidation() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(6, new java.sql.Date(e.getDateValidation().getTime()));
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(7, e.getReference());
            }
            if (e.getObjet() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getObjet());
            }
            if (e.getDateSignature() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(9, new java.sql.Date(e.getDateSignature().getTime()));
            }
            if (e.getSignataire() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(10, e.getSignataire());
            }

            if (e.getDebit() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(11, e.getDebit());
            }
            if (e.getCredit() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(12, e.getCredit());
            }

            if (e.getOrganisationID() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(13, e.getOrganisationID());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(14, e.getMillesime());
            }

            if (e.getGestionnaire() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(15, e.getGestionnaire());
            }

            if (e.getNumVirement() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(16, e.getNumVirement());
            }

            if (e.getBudgetID() == null) {
                stmtpsEngagementInsert.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(17, e.getBudgetID());
            }
            if (e.getTitre() == null) {
                stmtpsEngagementInsert.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(18, e.getTitre());
            }
            if (e.getContenu() == null) {
                stmtpsEngagementInsert.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(19, e.getContenu());
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            System.out.println("psVirement_Update");
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ajouterTache(VirementTache e) throws GrecoException {
        Connection con = null;
        CallableStatement stmtpsEngagementInsert = null;

        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psVirementTache_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getIpUpdate());
            }
            if (e.getVirementTacheID() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getVirementTacheID());
            }
            if (e.getVirementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getVirementID());
            }
            if (e.getTacheID() == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, e.getTacheID());
            }
            if (e.getDebit() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(6, e.getDebit());
            }
            if (e.getCredit() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(7, e.getCredit());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getMillesime());
            }
            if (e.getChapitre() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, e.getChapitre());
            }
            if (e.getTacheCode() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(10, e.getTacheCode());
            }
            if (e.getParagraphe() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, e.getParagraphe());
            }
            if (e.getProgramme() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(12, e.getProgramme());
            }
            if (e.getAction() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(13, e.getAction());
            }
            if (e.getLibelleFr() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(14, e.getLibelleFr());
            }
            if (e.getLibelleUs() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(15, e.getLibelleUs());
            }
            if (e.getDisponibleAvant() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(16, e.getDisponibleAvant());
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            System.out.println("psVirementTache_Insert");
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerTaches(String virementID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirementTaches_Delete( ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String virementID, String userUpdate) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_Delete( ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Virement getVirement(String virementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psVirement_Find( ?)");

            if (virementID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, virementID);
            }
            Virement e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new Virement();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                e.setVirementID(rs.getString("virementID"));
                e.setEtat(rs.getInt("etat"));
                e.setDateValidation(rs.getDate("dateValidation"));
                e.setReference(rs.getString("reference"));
                e.setObjet(rs.getString("objet"));
                e.setDateSignature(rs.getDate("dateSignature"));
                e.setSignataire(rs.getString("signataire"));
                e.setDebit(rs.getBigDecimal("debit"));
                e.setCredit(rs.getBigDecimal("credit"));
                e.setGestionnaire(rs.getString("gestionnaire"));
                e.setDateEnregistrement(rs.getDate("dateEnregistrement"));
                e.setNumVirement(rs.getString("numVirement"));
                e.setBudgetID(rs.getString("budgetID"));
                e.setNumOrdre(rs.getInt("numOrdre"));
                e.setOrganisationID(rs.getString("organisationID"));
                e.setMillesime(rs.getString("millesime"));
                e.setContenu(rs.getString("contenu"));
                e.setTitre(rs.getString("titre"));
                try {
                    e.setLibelleFr(rs.getString("libelleFr"));
                } catch (Exception eb) {
                }
                try {
                    e.setLibelleUs(rs.getString("libelleUs"));
                } catch (Exception eb) {
                }
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VirementTache> getListTache(String virementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psVirementTaches_List( ?)");

            if (virementID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, virementID);
            }
            List<VirementTache> list = new ArrayList();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VirementTache e = new VirementTache();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                e.setVirementTacheID(rs.getString("virementTacheID"));
                e.setVirementID(rs.getString("virementID"));
                e.setTacheID(rs.getString("tacheID"));
                e.setDebit(rs.getBigDecimal("debit"));
                e.setCredit(rs.getBigDecimal("credit"));
                e.setMillesime(rs.getString("millesime"));
                e.setChapitre(rs.getString("chapitre"));
                e.setTacheCode(rs.getString("tacheCode"));
                e.setParagraphe(rs.getString("paragraphe"));
                e.setProgramme(rs.getString("programme"));
                e.setAction(rs.getString("action"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                e.setDisponibleAvant(rs.getBigDecimal("disponibleAvant"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Virement> getListVirement(String organisationID, String millesime, String budgetID, int mode) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psVirement_List( ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }

            stmtpsactiviteS.setInt(4, mode);

            List<Virement> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Virement e = new Virement();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                e.setVirementID(rs.getString("virementID"));
                e.setEtat(rs.getInt("etat"));
                e.setDateValidation(rs.getDate("dateValidation"));
                e.setReference(rs.getString("reference"));
                e.setObjet(rs.getString("objet"));
                e.setDateSignature(rs.getDate("dateSignature"));
                e.setSignataire(rs.getString("signataire"));
                e.setDebit(rs.getBigDecimal("debit"));
                e.setCredit(rs.getBigDecimal("credit"));
                e.setGestionnaire(rs.getString("gestionnaire"));
                e.setDateEnregistrement(rs.getDate("dateEnregistrement"));
                e.setNumVirement(rs.getString("numVirement"));
                e.setBudgetID(rs.getString("budgetID"));
                e.setNumOrdre(rs.getInt("numOrdre"));
                e.setOrganisationID(rs.getString("organisationID"));
                e.setMillesime(rs.getString("millesime"));
                e.setContenu(rs.getString("contenu"));
                e.setTitre(rs.getString("titre"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VirementTache> getDisponibleTache(String organisationID, String millesime, String budgetID, String chapitre, String tacheCode, String paragraphe) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psVirement_DisponibleTache( ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }
            if (chapitre == null) {
                stmtpsactiviteS.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(4, chapitre);
            }
            if (tacheCode == null) {
                stmtpsactiviteS.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(5, tacheCode);
            }
            if (paragraphe == null) {
                stmtpsactiviteS.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(6, paragraphe);
            }
            List<VirementTache> list = new ArrayList();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VirementTache e = new VirementTache();

//                e.setLastUpdate(rs.getDate("last_update"));
//                e.setIpUpdate(rs.getString("ip_update"));
//                e.setVirementTacheID(rs.getString("virementTacheID"));
//                e.setVirementID(rs.getString("virementID"));
                e.setTacheID(rs.getString("tacheID"));
//                e.setDebit(rs.getBigDecimal("debit"));
//                e.setCredit(rs.getBigDecimal("credit"));
                e.setMillesime(rs.getString("millesime"));
                e.setChapitre(rs.getString("chapitre"));
                e.setTacheCode(rs.getString("tacheCode"));
                e.setParagraphe(rs.getString("paragraphe"));
                e.setProgramme(rs.getString("programme"));
                e.setAction(rs.getString("action"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                e.setDisponibleAvant(rs.getBigDecimal("disponibleAvant"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void reserver(String virementID, String userUpdate) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_Reserver( ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void reservation_annuler(String virementID, String userUpdate) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_ReserverAnnuler( ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void visaBudgetaire(String virementID, String userUpdate) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_Visa( ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void visaBudgetaire_annuler(String virementID, String userUpdate) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_VisaAnnuler( ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void valider(String virementID, String userUpdate, String arrete, Date dateSignature) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_Valider( ?, ?, ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }
            if (arrete == null) {
                stmtpsEngagementDelete.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(3, arrete);
            }
            if (dateSignature == null) {
                stmtpsEngagementDelete.setNull(4, java.sql.Types.DATE);
            } else {
                stmtpsEngagementDelete.setDate(4, new java.sql.Date(dateSignature.getTime()));
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void valider_annuler(String virementID, String userUpdate) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psVirement_ValiderAnnuler( ?, ?)");

            if (virementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, virementID);
            }
            if (userUpdate == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, userUpdate);
            }

            stmtpsEngagementDelete.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
