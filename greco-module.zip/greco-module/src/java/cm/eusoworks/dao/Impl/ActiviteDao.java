/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IActiviteDao;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaActivite;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ParameterMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ActiviteDao implements IActiviteDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public void ajouter(Activite act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psActivite_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getActiviteID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getActiviteID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getMillesime());
            }
            if (act.getNiveauActiviteID() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setInt(7, act.getNiveauActiviteID());
            }
            if (act.getActiviteParentID() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getActiviteParentID());
            }
            if (act.getCode() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getCode());
            }
            if (act.getOrganisationID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getOrganisationID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(Activite act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psActivite_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getActiviteID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getActiviteID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getMillesime());
            }
            if (act.getNiveauActiviteID() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setInt(7, act.getNiveauActiviteID());
            }
            if (act.getActiviteParentID() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getActiviteParentID());
            }
            if (act.getCode() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getCode());
            }
            if (act.getOrganisationID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getOrganisationID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String activiteID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psActivite_Delete(?)");
            stmt.setString(1, activiteID);
            stmt.executeQuery();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Activite getActivite(String activiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_Find( ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            Activite e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Activite> getListActivite(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_List( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<Activite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Activite e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Activite> getListActiviteRoots(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_Roots( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<Activite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Activite e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Activite> getListActiviteChilds(String activiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_Childs( ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            List<Activite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Activite e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Activite> getListActiviteChildsAndOperationCount(String activiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_ChildsOperation( ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            List<Activite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Activite e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int copierOperation(String TacheSourceID, String tacheDestinationID, String structureDestinationID) {
        Connection con = null;
        int rowsAffected = -1;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psActivite_CopieOperation(?, ?, ?, ?)");

            stmt.setString(1, TacheSourceID);
            stmt.setString(2, tacheDestinationID);
            stmt.setString(3, structureDestinationID);
            stmt.registerOutParameter(4, java.sql.Types.INTEGER);
            stmt.setInt(4, rowsAffected);

            stmt.executeQuery();

            rowsAffected = stmt.getInt(4);
            return rowsAffected;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Activite> getListActiviteNiveau(String organisationID, int niveauID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_Niveau( ?, ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }

            stmtpsactiviteS.setInt(2, niveauID);

            if (millesime == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, millesime);
            }

            List<Activite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Activite e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Activite> getListTacheBudgetiseByStructure(String millesime, String organisationID, String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psActivite_TacheStructure( ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, structureID);
            }
            List<Activite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Activite e = new Activite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // PREPAACTIVITE 
    @Override
    public void prepaAjouter(PrepaActivite act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaActivite_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getActiviteID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getActiviteID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getMillesime());
            }
            if (act.getNiveauActiviteID() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setInt(7, act.getNiveauActiviteID());
            }
            if (act.getActiviteParentID() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getActiviteParentID());
            }
            if (act.getCode() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getCode());
            }
            if (act.getOrganisationID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getOrganisationID());
            }

            if (act.getPresentationFr() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getPresentationFr() == null ? "" : act.getPresentationFr());
            }
            if (act.getPresentationUs() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getPresentationUs() == null ? "" : act.getPresentationUs());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void prepaModifier(PrepaActivite act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaActivite_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getActiviteID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getActiviteID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getMillesime() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getMillesime());
            }
            if (act.getNiveauActiviteID() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setInt(7, act.getNiveauActiviteID());
            }
            if (act.getActiviteParentID() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getActiviteParentID());
            }
            if (act.getCode() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getCode());
            }
            if (act.getOrganisationID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getOrganisationID());
            }

            if (act.getPresentationFr() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getPresentationFr() == null ? "" : act.getPresentationFr());
            }
            if (act.getPresentationUs() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getPresentationUs() == null ? "" : act.getPresentationUs());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void prepaSupprimer(String activiteID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaActivite_Delete(?)");
            stmt.setString(1, activiteID);
            stmt.executeQuery();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public PrepaActivite prepaGetActivite(String activiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_Find( ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            PrepaActivite e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActivite(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_List( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteRoots(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_Roots( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChilds(String activiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_Childs( ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChildsAndOperationCount(String activiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_ChildsOperation( ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                e.setPresentationFr(rs.getString("presentationFr") == null ? "" : rs.getString("presentationFr"));
                e.setPresentationUs(rs.getString("presentationUs") == null ? "" : rs.getString("presentationUs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int prepaCopierOperation(String TacheSourceID, String tacheDestinationID, String structureDestinationID) {
        Connection con = null;
        int rowsAffected = -1;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaActivite_CopieOperation(?, ?, ?, ?)");

            stmt.setString(1, TacheSourceID);
            stmt.setString(2, tacheDestinationID);
            stmt.setString(3, structureDestinationID);
            stmt.registerOutParameter(4, java.sql.Types.INTEGER);
            stmt.setInt(4, rowsAffected);

            stmt.executeQuery();

            rowsAffected = stmt.getInt(4);
            return rowsAffected;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteNiveau(String organisationID, int niveauID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_Niveau( ?, ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }

            stmtpsactiviteS.setInt(2, niveauID);

            if (millesime == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, millesime);
            }

            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListTacheBudgetiseByStructure(String millesime, String organisationID, String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_TacheStructure( ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, structureID);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteRootsByBudget(String organisationID, String millesime, String budgetID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_RootsByBudget( ?, ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChildsByBudget(String activiteID, String budgetID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_ChildsByBudget( ?, ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, budgetID);
            }

            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChildsAndOperationCountByBudget(String activiteID, String budgetID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaActivite_ChildsOperationByBudget( ?, ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, budgetID);
            }
            List<PrepaActivite> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaActivite e = new PrepaActivite();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setActiviteID(rs.getString("activiteID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setMillesime(rs.getString("millesime"));

                e.setNiveauActiviteID(rs.getInt("niveauActiviteID"));

                e.setActiviteParentID(rs.getString("activiteParentID"));
                if (rs.wasNull()) {
                    e.setActiviteParentID(null);
                }
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setOrganisationID(rs.getString("organisationID"));
                e.setChilds(rs.getInt("childs"));

                e.setPresentationFr(rs.getString("presentationFr") == null ? "" : rs.getString("presentationFr"));
                e.setPresentationUs(rs.getString("presentationUs") == null ? "" : rs.getString("presentationUs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
