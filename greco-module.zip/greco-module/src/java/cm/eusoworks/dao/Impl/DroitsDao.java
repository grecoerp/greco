/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IDroitsDao;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.MandatementDroits;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class DroitsDao implements IDroitsDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public int ajouter(Droits droit, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (droit.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, droit.getUserUpdate());
            }
            if (droit.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, droit.getIpUpdate());
            }
            if (droit.getDroitID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, droit.getDroitID());
            }
            if (droit.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, droit.getLibelleFr());
            }
            if (droit.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, droit.getLibelleUs());
            }
            if (droit.getSigleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, droit.getSigleFr());
            }
            if (droit.getSigleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, droit.getSigleFr());
            }
            stmt.setBoolean(8, droit.isNAP());
            stmt.setBoolean(9, droit.isTVA());
            stmt.setBoolean(10, droit.isIR());
            stmt.setBoolean(11, droit.isRG());
            stmt.setBoolean(12, droit.isCaution());
            stmt.setBoolean(13, droit.isPenalite());
            stmt.setBoolean(14, droit.isDepotDivers());
            stmt.setBoolean(15, droit.isPrecompte());

            stmt.registerOutParameter(16, java.sql.Types.INTEGER);
            stmt.setInt(16, codeErreur);

            if (droit.getCompteCredit()== null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, droit.getCompteCredit());
            }
            
            if (droit.getCompteDebit()== null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, droit.getCompteDebit());
            }
            
            if (droit.getJournalID()== null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, droit.getJournalID());
            }
            
            
            stmt.executeQuery();

            codeErreur = stmt.getInt(16);
            return codeErreur;
        } catch (Exception ex) {
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int modifier(Droits droit, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (droit.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, droit.getUserUpdate());
            }
            if (droit.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, droit.getIpUpdate());
            }
            if (droit.getDroitID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, droit.getDroitID());
            }
            if (droit.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, droit.getLibelleFr());
            }
            if (droit.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, droit.getLibelleUs());
            }
            if (droit.getSigleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, droit.getSigleFr());
            }
            if (droit.getSigleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, droit.getSigleFr());
            }
            stmt.setBoolean(8, droit.isNAP());
            stmt.setBoolean(9, droit.isTVA());
            stmt.setBoolean(10, droit.isIR());
            stmt.setBoolean(11, droit.isRG());
            stmt.setBoolean(12, droit.isCaution());
            stmt.setBoolean(13, droit.isPenalite());
            stmt.setBoolean(14, droit.isDepotDivers());
            stmt.setBoolean(15, droit.isPrecompte());

            stmt.registerOutParameter(16, java.sql.Types.INTEGER);
            stmt.setInt(16, codeErreur);

            
            if (droit.getCompteCredit()== null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, droit.getCompteCredit());
            }
            
            if (droit.getCompteDebit()== null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, droit.getCompteDebit());
            }
            
            if (droit.getJournalID()== null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, droit.getJournalID());
            }
            
            stmt.executeUpdate();

            codeErreur = stmt.getInt(16);
            return codeErreur;
        } catch (Exception ex) {
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String droitID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_Delete(?)");
            stmt.setString(1, droitID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public Droits rechercherById(String droitID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_Find(?)");
            stmt.setString(1, droitID);

            Droits o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Droits();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }
                o.setNAP(rs.getBoolean("isNAP"));
                o.setTVA(rs.getBoolean("isTVA"));
                o.setIR(rs.getBoolean("isIR"));
                o.setRG(rs.getBoolean("isRG"));
                o.setCaution(rs.getBoolean("isCaution"));
                o.setPenalite(rs.getBoolean("isPenalite"));
                o.setDepotDivers(rs.getBoolean("isDepotDivers"));
                o.setPrecompte(rs.getBoolean("isPrecompte"));
                
                try {
                    o.setCompteCredit(rs.getString("compteCredit"));
                } catch (Exception e) {
                }
                try {
                    o.setCompteDebit(rs.getString("compteDebit"));
                } catch (Exception e) {
                }
                try {
                    o.setJournalID(rs.getString("journalID"));
                } catch (Exception e) {
                }
                

            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Droits> listeDroits() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_List()");

            ResultSet rs = stmt.executeQuery();
            List<Droits> droits = new ArrayList<>();
            while (rs.next()) {
                Droits o = new Droits();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }
                o.setNAP(rs.getBoolean("isNAP"));
                o.setTVA(rs.getBoolean("isTVA"));
                o.setIR(rs.getBoolean("iSIR"));
                o.setRG(rs.getBoolean("isRG"));
                o.setCaution(rs.getBoolean("isCaution"));
                o.setPenalite(rs.getBoolean("isPenalite"));
                o.setDepotDivers(rs.getBoolean("isDepotDivers"));
                o.setPrecompte(rs.getBoolean("isPrecompte")); 
                
                
                
                try {
                    o.setCompteCredit(rs.getString("compteCredit"));
                } catch (Exception e) {
                }
                try {
                    o.setCompteDebit(rs.getString("compteDebit"));
                } catch (Exception e) {
                }
                try {
                    o.setJournalID(rs.getString("journalID"));
                } catch (Exception e) {
                }
                

                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Droits> listeDroitsNAP() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_List_NAP()");

            ResultSet rs = stmt.executeQuery();
            List<Droits> droits = new ArrayList<>();
            while (rs.next()) {
                Droits o = new Droits();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }
                o.setNAP(rs.getBoolean("isNAP"));
                o.setTVA(rs.getBoolean("isTVA"));
                o.setIR(rs.getBoolean("iSIR"));
                o.setRG(rs.getBoolean("isRG"));
                o.setCaution(rs.getBoolean("isCaution"));
                o.setPenalite(rs.getBoolean("isPenalite"));
                o.setDepotDivers(rs.getBoolean("isDepotDivers"));
                o.setPrecompte(rs.getBoolean("isPrecompte"));

                try {
                    o.setCompteCredit(rs.getString("compteCredit"));
                } catch (Exception e) {
                }
                try {
                    o.setCompteDebit(rs.getString("compteDebit"));
                } catch (Exception e) {
                }
                try {
                    o.setJournalID(rs.getString("journalID"));
                } catch (Exception e) {
                }
                
                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Droits> listeDroitsRetenues() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDroits_List_Retenues()");

            ResultSet rs = stmt.executeQuery();
            List<Droits> droits = new ArrayList<>();
            while (rs.next()) {
                Droits o = new Droits();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }
                o.setNAP(rs.getBoolean("isNAP"));
                o.setTVA(rs.getBoolean("isTVA"));
                o.setIR(rs.getBoolean("iSIR"));
                o.setRG(rs.getBoolean("isRG"));
                o.setCaution(rs.getBoolean("isCaution"));
                o.setPenalite(rs.getBoolean("isPenalite"));
                o.setDepotDivers(rs.getBoolean("isDepotDivers"));
                o.setPrecompte(rs.getBoolean("isPrecompte"));

                try {
                    o.setCompteCredit(rs.getString("compteCredit"));
                } catch (Exception e) {
                }
                try {
                    o.setCompteDebit(rs.getString("compteDebit"));
                } catch (Exception e) {
                }
                try {
                    o.setJournalID(rs.getString("journalID"));
                } catch (Exception e) {
                }
                
                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int ajouterLiquidationDroit(List<LiquidationDroits> droits) {
        Connection con = null;
        int nbInserted = 0;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiquidationDroits_Insert(?, ?, ?, ?, ?, ?)");
            for (LiquidationDroits droit : droits) {
                if (droit.getUser_update() == null) {
                    stmt.setNull(1, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(1, droit.getUser_update());
                }
                if (droit.getIp_update() == null) {
                    stmt.setNull(2, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(2, droit.getIp_update());
                }
                if (droit.getDroitID() == null) {
                    stmt.setNull(3, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(3, droit.getDroitID());
                }
                if (droit.getLiquidationID() == null) {
                    stmt.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(4, droit.getLiquidationID());
                }

                stmt.setDouble(5, droit.getTaux());

                if (droit.getMontant() == null) {
                    stmt.setNull(6, java.sql.Types.DECIMAL);
                } else {
                    stmt.setBigDecimal(6, droit.getMontant());
                }
                try {
                    stmt.executeQuery();
                    nbInserted++;
                } catch (Exception e) {
                }
            }
        } catch (Exception ex) {
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return nbInserted;
    }

    @Override
    public void supprimerLiquidationDroit(String liquidationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiquidationDroits_Delete(?)");
            stmt.setString(1, liquidationID);
            stmt.executeQuery();
        } catch (SQLException ex) {
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<LiquidationDroits> listeLiquidationDroits(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiquidationDroits_List(?)");
            stmt.setString(1, engagementID);
            stmt.executeQuery();

            ResultSet rs = stmt.executeQuery();
            List<LiquidationDroits> droits = new ArrayList<>();
            while (rs.next()) {
                LiquidationDroits o = new LiquidationDroits();
                o.setIp_update(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIp_update(null);
                }
                o.setLast_update(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLast_update(null);
                }
                o.setUser_update(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUser_update(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    o.setLiquidationID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }

                o.setTaux(rs.getDouble("taux"));
                o.setMontant(rs.getBigDecimal("montant"));

                try {
                    o.setNAP(rs.getBoolean("isNAP"));
                    o.setIR(rs.getBoolean("isIR"));
                    o.setTVA(rs.getBoolean("isTVA"));
                    o.setRG(rs.getBoolean("isRG"));
                    o.setCaution(rs.getBoolean("isCaution"));
                    o.setPenalite(rs.getBoolean("isPenalite"));
                    o.setDepotDivers(rs.getBoolean("isDepotDivers"));
                    o.setPrecompte(rs.getBoolean("isPrecompte"));
                } catch (Exception e) {
                }

                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<LiquidationDroits> listeLiquidationDroitsNAP(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiquidationDroits_List_NAP(?)");
            stmt.setString(1, engagementID);
            stmt.executeQuery();

            ResultSet rs = stmt.executeQuery();
            List<LiquidationDroits> droits = new ArrayList<>();
            while (rs.next()) {
                LiquidationDroits o = new LiquidationDroits();
                o.setIp_update(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIp_update(null);
                }
                o.setLast_update(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLast_update(null);
                }
                o.setUser_update(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUser_update(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    o.setLiquidationID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }

                o.setTaux(rs.getDouble("taux"));

                o.setMontant(rs.getBigDecimal("montant"));

                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<LiquidationDroits> listeLiquidationDroitsRetenues(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiquidationDroits_List_Retenues(?)");
            stmt.setString(1, engagementID);
            stmt.executeQuery();

            ResultSet rs = stmt.executeQuery();
            List<LiquidationDroits> droits = new ArrayList<>();
            while (rs.next()) {
                LiquidationDroits o = new LiquidationDroits();
                o.setIp_update(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIp_update(null);
                }
                o.setLast_update(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLast_update(null);
                }
                o.setUser_update(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUser_update(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    o.setLiquidationID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }

                o.setTaux(rs.getDouble("taux"));

                o.setMontant(rs.getBigDecimal("montant"));

                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    @Override
    public int ajouterMandatementDroit(List<MandatementDroits> droits) {
        Connection con = null;
        int nbInserted = 0;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psMandatementDroits_Insert(?, ?, ?, ?, ?, ?)");
            for (MandatementDroits droit : droits) {
                if (droit.getUser_update() == null) {
                    stmt.setNull(1, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(1, droit.getUser_update());
                }
                if (droit.getIp_update() == null) {
                    stmt.setNull(2, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(2, droit.getIp_update());
                }
                if (droit.getDroitID() == null) {
                    stmt.setNull(3, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(3, droit.getDroitID());
                }
                if (droit.getMandatementID() == null) {
                    stmt.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(4, droit.getMandatementID());
                }

                stmt.setDouble(5, droit.getTaux());

                if (droit.getMontant() == null) {
                    stmt.setNull(6, java.sql.Types.DECIMAL);
                } else {
                    stmt.setBigDecimal(6, droit.getMontant());
                }
                try {
                    stmt.executeQuery();
                    nbInserted++;
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("***** droit mandatement ajouter error on save ");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return nbInserted;
    }

    @Override
    public void supprimerMandatementDroit(String mandatementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psMandatementDroits_Delete(?)");
            stmt.setString(1, mandatementID);
            stmt.executeQuery();
        } catch (SQLException ex) {
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<MandatementDroits> listeMandatementDroits(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psMandatementDroits_List(?)");
            stmt.setString(1, engagementID);
            stmt.executeQuery();

            ResultSet rs = stmt.executeQuery();
            List<MandatementDroits> droits = new ArrayList<>();
            while (rs.next()) {
                MandatementDroits o = new MandatementDroits();
                o.setIp_update(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIp_update(null);
                }
                o.setLast_update(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLast_update(null);
                }
                o.setUser_update(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUser_update(null);
                }
                o.setDroitID(rs.getString("droitID"));
                if (rs.wasNull()) {
                    o.setDroitID(null);
                }
                o.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    o.setMandatementID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setSigleFr(rs.getString("sigleFr"));
                if (rs.wasNull()) {
                    o.setSigleFr(null);
                }
                o.setSigleUs(rs.getString("sigleUs"));
                if (rs.wasNull()) {
                    o.setSigleUs(null);
                }

                o.setTaux(rs.getDouble("taux"));
                o.setMontant(rs.getBigDecimal("montant"));

                try {
                    o.setNAP(rs.getBoolean("isNAP"));
                    o.setIR(rs.getBoolean("isIR"));
                    o.setTVA(rs.getBoolean("isTVA"));
                    o.setRG(rs.getBoolean("isRG"));
                    o.setCaution(rs.getBoolean("isCaution"));
                    o.setPenalite(rs.getBoolean("isPenalite"));
                    o.setDepotDivers(rs.getBoolean("isDepotDivers"));
                    o.setPrecompte(rs.getBoolean("isPrecompte"));
                } catch (Exception e) {
                }

                droits.add(o);
            }
            return droits;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

   
}
