/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IComptaDao;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Axe;
import cm.eusoworks.entities.model.ComptaLibelle;
import cm.eusoworks.entities.model.CompteLiquidite;
import cm.eusoworks.entities.model.Devise;
import cm.eusoworks.entities.model.Ecritures;
import cm.eusoworks.entities.model.Journaux;
import cm.eusoworks.entities.model.ReglementMode;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ComptaDao implements IComptaDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    // <editor-fold defaultstate="collapsed" desc="ReglementMode">
    @Override
    public void reglementModeAjouter(ReglementMode rg) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psReglementMode_Insert( ?, ?, ?, ?, ?, ?, ?)");

            if (rg.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(rg.getLastUpdate().getTime()));
            }
            if (rg.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, rg.getUserUpdate());
            }
            if (rg.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, rg.getIpUpdate());
            }
            if (rg.getReglementID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, rg.getReglementID());
            }
            if (rg.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, rg.getLibelleFr());
            }
            if (rg.getLibelleUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, rg.getLibelleUs());
            }

            stmt.setBoolean(7, rg.getIsEspece());

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void reglementModeModifier(ReglementMode rg) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psReglementMode_Update( ?, ?, ?, ?, ?, ?, ?)");

            if (rg.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(rg.getLastUpdate().getTime()));
            }
            if (rg.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, rg.getUserUpdate());
            }
            if (rg.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, rg.getIpUpdate());
            }
            if (rg.getReglementID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, rg.getReglementID());
            }
            if (rg.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, rg.getLibelleFr());
            }
            if (rg.getLibelleUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, rg.getLibelleUs());
            }

            stmt.setBoolean(7, rg.getIsEspece());

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void reglementModeSupprimer(String reglementModeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psReglementMode_Delete( ?)");

            if (reglementModeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, reglementModeID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public ReglementMode reglementModeRechercher(String reglementModeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psReglementMode_Find( ? )");

            if (reglementModeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, reglementModeID);
            }

            ReglementMode e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new ReglementMode();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setReglementID(rs.getString("reglementID"));
                if (rs.wasNull()) {
                    e.setReglementID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setIsEspece(rs.getBoolean("isEspece"));
                if (rs.wasNull()) {
                    e.setIsEspece(false);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ComptaDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<ReglementMode> reglementModeListe() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psReglementMode_List()");

            List<ReglementMode> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ReglementMode e = new ReglementMode();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setReglementID(rs.getString("reglementID"));
                if (rs.wasNull()) {
                    e.setReglementID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setIsEspece(rs.getBoolean("isEspece"));
                if (rs.wasNull()) {
                    e.setIsEspece(false);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ComptaDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    // </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="Devise"> 
    @Override
    public void deviseAjouter(Devise dv) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDevise_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (dv.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(dv.getLastUpdate().getTime()));
            }
            if (dv.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, dv.getUserUpdate());
            }
            if (dv.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, dv.getIpUpdate());
            }
            if (dv.getDeviseID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, dv.getDeviseID());
            }
            if (dv.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, dv.getLibelleFr());
            }
            if (dv.getLibelleUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, dv.getLibelleUs());
            }
            if (dv.getSymbole() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, dv.getSymbole());
            }

            stmt.setBoolean(8, dv.getIsCourante());

            if (dv.getChangeAchat() == null) {
                stmt.setNull(9, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(9, dv.getChangeAchat());
            }
            if (dv.getChangeVente() == null) {
                stmt.setNull(10, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(10, dv.getChangeVente());
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void deviseModifier(Devise dv) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDevise_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (dv.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(dv.getLastUpdate().getTime()));
            }
            if (dv.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, dv.getUserUpdate());
            }
            if (dv.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, dv.getIpUpdate());
            }
            if (dv.getDeviseID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, dv.getDeviseID());
            }
            if (dv.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, dv.getLibelleFr());
            }
            if (dv.getLibelleUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, dv.getLibelleUs());
            }
            if (dv.getSymbole() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, dv.getSymbole());
            }

            stmt.setBoolean(8, dv.getIsCourante());

            if (dv.getChangeAchat() == null) {
                stmt.setNull(9, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(9, dv.getChangeAchat());
            }
            if (dv.getChangeVente() == null) {
                stmt.setNull(10, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(10, dv.getChangeVente());
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void deviseSupprimer(String deviseID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psDevise_Delete( ?)");

            if (deviseID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, deviseID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public Devise deviseRechercher(String deviseID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psDevise_List( )");

            Devise e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new Devise();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setDeviseID(rs.getString("deviseID"));
                if (rs.wasNull()) {
                    e.setDeviseID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setSymbole(rs.getString("symbole"));
                if (rs.wasNull()) {
                    e.setSymbole(null);
                }
                e.setIsCourante(rs.getBoolean("isCourante"));
                if (rs.wasNull()) {
                    e.setIsCourante(false);
                }
                e.setChangeAchat(rs.getBigDecimal("changeAchat"));
                if (rs.wasNull()) {
                    e.setChangeAchat(null);
                }
                e.setChangeVente(rs.getBigDecimal("changeVente"));
                if (rs.wasNull()) {
                    e.setChangeVente(null);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ComptaDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Devise> deviseRechercherLabel(String label) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psDevise_FindByLabel( ? )");

            if (label == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, label);
            }

            List<Devise> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Devise e = new Devise();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setDeviseID(rs.getString("deviseID"));
                if (rs.wasNull()) {
                    e.setDeviseID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setSymbole(rs.getString("symbole"));
                if (rs.wasNull()) {
                    e.setSymbole(null);
                }
                e.setIsCourante(rs.getBoolean("isCourante"));
                if (rs.wasNull()) {
                    e.setIsCourante(false);
                }
                e.setChangeAchat(rs.getBigDecimal("changeAchat"));
                if (rs.wasNull()) {
                    e.setChangeAchat(null);
                }
                e.setChangeVente(rs.getBigDecimal("changeVente"));
                if (rs.wasNull()) {
                    e.setChangeVente(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ComptaDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Devise> deviseList() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psDevise_List( )");

            List<Devise> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Devise e = new Devise();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setDeviseID(rs.getString("deviseID"));
                if (rs.wasNull()) {
                    e.setDeviseID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setSymbole(rs.getString("symbole"));
                if (rs.wasNull()) {
                    e.setSymbole(null);
                }
                e.setIsCourante(rs.getBoolean("isCourante"));
                if (rs.wasNull()) {
                    e.setIsCourante(false);
                }
                e.setChangeAchat(rs.getBigDecimal("changeAchat"));
                if (rs.wasNull()) {
                    e.setChangeAchat(null);
                }
                e.setChangeVente(rs.getBigDecimal("changeVente"));
                if (rs.wasNull()) {
                    e.setChangeVente(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ComptaDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Axes"> 
    @Override
    public void axeAjouter(Axe org) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAxe_Insert(?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getAxeID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getAxeID());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(8, java.sql.Types.DATE);
            } else {
                stmt.setDate(8, new java.sql.Date(org.getDateCreation().getTime()));
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void axeModifier(Axe org) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAxe_Update(?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getAxeID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getAxeID());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(8, java.sql.Types.DATE);
            } else {
                stmt.setDate(8, new java.sql.Date(org.getDateCreation().getTime()));
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void axeSupprimer(String axeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAxe_Delete(?)");
            stmt.setString(1, axeID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Axe> axeList() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAxe_List()");

            List<Axe> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Axe o = new Axe();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setAxeID(rs.getString("axeID"));
                if (rs.wasNull()) {
                    o.setAxeID(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Journaux comptables"> 
    @Override
    public void journauxAjouter(Journaux org) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psJournaux_Insert(?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getJournalID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getJournalID());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(8, java.sql.Types.DATE);
            } else {
                stmt.setDate(8, new java.sql.Date(org.getDateCreation().getTime()));
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void journauxModifier(Journaux org) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psJournaux_Update(?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getJournalID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getJournalID());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(8, java.sql.Types.DATE);
            } else {
                stmt.setDate(8, new java.sql.Date(org.getDateCreation().getTime()));
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void journauxSupprimer(String axeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psJournaux_Delete(?)");
            stmt.setString(1, axeID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Journaux> journauxList() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psJournaux_List()");

            List<Journaux> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Journaux o = new Journaux();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setJournalID(rs.getString("journalID"));
                if (rs.wasNull()) {
                    o.setJournalID(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Compta Libelle"> 
    @Override
    public List<ComptaLibelle> comptaLibelleList(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psComptaLibelle_List(?)");

            stmt.setString(1, organisationID);

            List<ComptaLibelle> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ComptaLibelle o = new ComptaLibelle();

                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }

                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setLibelle(rs.getString("libelle"));
                if (rs.wasNull()) {
                    o.setLibelle(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void comptaLibelleDeleteAll(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psComptaLibelle_DeleteAll(?)");
            stmt.setString(1, organisationID);

            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void comptaLibelleInsert(String organisationID, String code, String Libelle) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psComptaLibelle_Insert(?, ?, ?)");
            stmt.setString(1, organisationID);
            stmt.setString(2, code);
            stmt.setString(3, Libelle);

            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Compte de Liquidite "> 
    @Override
    public void liquiditeAjouter(CompteLiquidite cliq) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompteLiquidite_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (cliq.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, cliq.getUserUpdate());
            }
            if (cliq.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, cliq.getIpUpdate());
            }
            if (cliq.getLiquiditeID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, cliq.getLiquiditeID());
            }
            if (cliq.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, cliq.getLibelleFr());
            }
            if (cliq.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, cliq.getLibelleUs());
            }
            if (cliq.getCode() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, cliq.getCode());
            }

            if (cliq.getCompte() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, cliq.getCompte());
            }

            if (cliq.getJournalID() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, cliq.getJournalID());
            }

            stmt.setBoolean(9, cliq.getIsBanque());

            if (cliq.getBanqueID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, cliq.getBanqueID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void liquiditeModifier(CompteLiquidite cliq) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompteLiquidite_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (cliq.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, cliq.getUserUpdate());
            }
            if (cliq.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, cliq.getIpUpdate());
            }
            if (cliq.getLiquiditeID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, cliq.getLiquiditeID());
            }
            if (cliq.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, cliq.getLibelleFr());
            }
            if (cliq.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, cliq.getLibelleUs());
            }
            if (cliq.getCode() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, cliq.getCode());
            }

            if (cliq.getCompte() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, cliq.getCompte());
            }

            if (cliq.getJournalID() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, cliq.getJournalID());
            }

            stmt.setBoolean(9, cliq.getIsBanque());

            if (cliq.getBanqueID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, cliq.getBanqueID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void liquiditeSupprimer(String liquiditeID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompteLiquidite_Delete(?)");
            stmt.setString(1, liquiditeID);

            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public CompteLiquidite liquiditeRechercherById(String liquiditeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompteLiquidite_Find( ? )");

            stmt.setString(1, liquiditeID);

            CompteLiquidite o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {

                o = new CompteLiquidite();

                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setLiquiditeID(rs.getString("liquiditeID"));
                if (rs.wasNull()) {
                    o.setLiquiditeID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }

                o.setIsBanque(rs.getBoolean("isBanque"));

                try {
                    o.setCompte(rs.getString("compte"));
                } catch (Exception e) {
                }
                try {
                    o.setJournalID(rs.getString("journalID"));
                } catch (Exception e) {
                }
                try {
                    o.setBanqueID(rs.getString("banqueID"));
                } catch (Exception e) {
                }

            }
            return o;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<CompteLiquidite> liquiditeListe(int type) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompteLiquidite_List( ? )");

            stmt.setInt(1, type);

            List<CompteLiquidite> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {

                CompteLiquidite o = new CompteLiquidite();

                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setLiquiditeID(rs.getString("liquiditeID"));
                if (rs.wasNull()) {
                    o.setLiquiditeID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }

                o.setIsBanque(rs.getBoolean("isBanque"));

                try {
                    o.setCompte(rs.getString("compte"));
                } catch (Exception e) {
                }
                try {
                    o.setJournalID(rs.getString("journalID"));
                } catch (Exception e) {
                }
                try {
                    o.setBanqueID(rs.getString("banqueID"));
                } catch (Exception e) {
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // </editor-fold>
    
    // <editor-fold defaultstate="collapsed" desc="Ecritures comptables "> 
    
   
    
    @Override
    public void ecritureComptable(Ecritures ecriture) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psEcritures_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? )");
            
            
            if(ecriture.getEcritureID() == null){
                ecriture.setEcritureID("CG"+StringUtil.generatedID());
            }
            
            if (ecriture.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, ecriture.getUserUpdate());
            }
            if (ecriture.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ecriture.getIpUpdate());
            }
            if (ecriture.getEcritureID()== null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, ecriture.getEcritureID());
            }
            if (ecriture.getDateOperation()== null) {
                stmt.setNull(4, java.sql.Types.DATE);
            } else {
                stmt.setDate(4,  new Date(  ecriture.getDateOperation().getTime()));
            }
           if (ecriture.getLibelle()== null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, ecriture.getLibelle());
            }
            if (ecriture.getDebit()== null) {
                stmt.setNull(6, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(6, ecriture.getDebit());
            }
            if (ecriture.getCredit() == null) {
                stmt.setNull(7, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(7, ecriture.getCredit());
            }
            if (ecriture.getLettrage()== null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, ecriture.getLettrage());
            }

            if (ecriture.getMillesime()== null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, ecriture.getMillesime());
            }
            if (ecriture.getJournalID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, ecriture.getJournalID());
            }
            if (ecriture.getAxeID()== null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, ecriture.getAxeID());
            }
            stmt.setLong(12, ecriture.getNumOrdreValidation());

            if (ecriture.getCompte()== null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, ecriture.getCompte());
            }
            if (ecriture.getEngagementID()== null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(14, ecriture.getEngagementID());
            }
            if (ecriture.getMandatementID()== null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(15, ecriture.getMandatementID());
            }
            if (ecriture.getDroitID()== null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, ecriture.getDroitID());
            }
            stmt.setInt(17, ecriture.getTypeEcriture());
            
            stmt.executeQuery();


        } catch (Exception ex) {
            Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    @Override
    public int ecritureNumOrdreValidation(){
        Connection con = null;
        int ordre = -1;
        con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psComptaOrdreValidation_Get( ?)");

            stmtpsEngagementInsert.setInt(1, ordre);
            stmtpsEngagementInsert.registerOutParameter(1, java.sql.Types.INTEGER);

            stmtpsEngagementInsert.executeUpdate();

            ordre = stmtpsEngagementInsert.getInt(1);

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return ordre;
    }
    // </editor-fold>
}


