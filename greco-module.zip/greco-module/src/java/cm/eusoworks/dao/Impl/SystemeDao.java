/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.ISystemeDao;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.entities.model.Userpreferences;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class SystemeDao implements ISystemeDao{

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public List<Systeme> getListSysteme() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSysteme_List()");
            
            List<Systeme> list = new ArrayList();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Systeme sys = new Systeme();
                sys.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    sys.setIpUpdate(null);
                }
                sys.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    sys.setLastUpdate(null);
                }
                sys.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    sys.setUserUpdate(null);
                }
                sys.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    sys.setLibelleFr(null);
                }
                sys.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    sys.setLibelleUs(null);
                }
                sys.setSystemeID(rs.getString("systemeID"));
                if (rs.wasNull()) {
                    sys.setSystemeID(null);
                }
                sys.setNumOrdre(rs.getInt("systemeID"));
                if (rs.wasNull()) {
                    sys.setNumOrdre(0);
                }
                list.add(sys);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public List<Systeme> getSystemeListWithHabilitation(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSysteme_SelectWithHabilitation(?)");
            stmt.setString(1, login);
            
            List<Systeme> sysUsers = new ArrayList();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Systeme sys = new Systeme();
                sys.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    sys.setIpUpdate(null);
                }
                sys.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    sys.setLastUpdate(null);
                }
                sys.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    sys.setUserUpdate(null);
                }
                sys.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    sys.setLibelleFr(null);
                }
                sys.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    sys.setLibelleUs(null);
                }
                sys.setSystemeID(rs.getString("systemeID"));
                if (rs.wasNull()) {
                    sys.setSystemeID(null);
                }
                sys.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    sys.setNumOrdre(0);
                }
                try {
                    sys.setHabilite(rs.getBoolean("habilitation"));
                } catch (Exception e) {
                    sys.setHabilite(false);
                }
                
                
                sysUsers.add(sys);
            }
            return sysUsers;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public List<Modules> getModuleListWithHabilitation(String login) {
        return getModuleListWithHabilitation(login, null);
    }

    
    @Override
    public List<Modules> getModuleListWithHabilitation(String login, String systemeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psModules_SelectWithHabilitation(?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, systemeID);
            
            List<Modules> modUsers = new ArrayList();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Modules m = new Modules();
                m.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    m.setIpUpdate(null);
                }
                m.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    m.setLastUpdate(null);
                }
                m.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    m.setUserUpdate(null);
                }
                m.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    m.setLibelleFr(null);
                }
                m.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    m.setLibelleUs(null);
                }
                m.setModuleID(rs.getString("moduleID"));
                if (rs.wasNull()) {
                    m.setModuleID(null);
                }
                m.setSystemeID(rs.getString("systemeID"));
                if (rs.wasNull()) {
                    m.setSystemeID(null);
                }
                m.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    m.setNumOrdre(0);
                }
                m.setIcon(rs.getString("icon"));
                if (rs.wasNull()) {
                    m.setIcon(null);
                }
                m.setIconRoll(rs.getString("iconRoll"));
                if (rs.wasNull()) {
                    m.setIconRoll(null);
                }
                try {
                    m.setHabilite(rs.getBoolean("habilitation"));
                } catch (Exception e) {
                }
                modUsers.add(m);
            }
            return modUsers;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public List<Systeme> getSystemeListByLogin(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSysteme_SelectByLogin(?)");
            stmt.setString(1, login);
            
            List<Systeme> sysUsers = new ArrayList();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Systeme sys = new Systeme();
                sys.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    sys.setIpUpdate(null);
                }
                sys.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    sys.setLastUpdate(null);
                }
                sys.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    sys.setUserUpdate(null);
                }
                sys.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    sys.setLibelleFr(null);
                }
                sys.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    sys.setLibelleUs(null);
                }
                sys.setSystemeID(rs.getString("systemeID"));
                if (rs.wasNull()) {
                    sys.setSystemeID(null);
                }
                sys.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    sys.setNumOrdre(0);
                }
                try {
                    sys.setHabilite(rs.getBoolean("habilitation"));
                } catch (Exception e) {
                    sys.setHabilite(false);
                }
                
                
                sysUsers.add(sys);
            }
            return sysUsers;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
