/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IPrepaMarcheDao;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.PrepaMarche;
import cm.eusoworks.entities.model.PrepaMarcheContractant;
import cm.eusoworks.entities.model.PrepaMarcheFinancement;
import cm.eusoworks.entities.model.PrepaMarcheGestion;
import cm.eusoworks.entities.model.PrepaMarchePhasage;
import cm.eusoworks.entities.model.PrepaMarchePrestation;
import cm.eusoworks.entities.model.PrepaMarcheTypeAO;
import cm.eusoworks.entities.view.VuePrepaMarche;
import cm.eusoworks.entities.view.VuePrepaMarcheArticle;
import cm.eusoworks.entities.view.VuePrepaMarcheJournal;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class PrepaMarcheDao implements IPrepaMarcheDao{

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    //<editor-fold defaultstate="collapsed" desc="Marche">
    //
    //
        /*
    ps_Prepa_Marche_D
    @paId varchar(50)
     */
    @Override
    public int deleteMarche(String paId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtdeleteMarche = con.prepareCall("CALL ps_Prepa_Marche_D( ?)");

            if (paId == null) {
                stmtdeleteMarche.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtdeleteMarche.setString(1, paId);
            }

            return stmtdeleteMarche.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    @Override
    public int saveMarche(String paId, String naturePrestationId, String contractantId, String typeAOId, 
    String financementId, Integer numOrdre, String maitreOuvrage, Boolean annualite, String motifGreAGre, 
    Date dateDebut, Date dateFin, Date dateLancement, Date dateAttribution, Date dateSignature, Date dateDemarrage, 
    Date dateReception, Date dateLancementCP, Date dateAttributionCP, Date dateSignatureCP, Date dateDemarrageCP, 
    Date dateReceptionCP, Integer annee1, String intitule1, BigDecimal cout1, Integer annee2, String intitule2, 
    BigDecimal cout2, Integer annee3, String intitule3, BigDecimal cout3, Integer annee4, String intitule4, BigDecimal cout4, Integer annee5, String intitule5, BigDecimal cout5, Boolean uniteExistante, String intitule, String nom, String posteOccupe, String adresse, String email, String telephone, String userMaj, Date dateMaj) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaMarcheIU = con.prepareCall("CALL ps_Prepa_Marche_IU( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (paId == null) {
                stmtpsPrepaMarcheIU.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(1, paId);
            }
            if (naturePrestationId == null) {
                stmtpsPrepaMarcheIU.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(2, naturePrestationId);
            }
            if (contractantId == null) {
                stmtpsPrepaMarcheIU.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(3, contractantId);
            }
            if (typeAOId == null) {
                stmtpsPrepaMarcheIU.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(4, typeAOId);
            }
            if (financementId == null) {
                stmtpsPrepaMarcheIU.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(5, financementId);
            }
            if (numOrdre == null) {
                stmtpsPrepaMarcheIU.setNull(6, java.sql.Types.INTEGER);
            } else {
                stmtpsPrepaMarcheIU.setInt(6, numOrdre);
            }
            if (maitreOuvrage == null) {
                stmtpsPrepaMarcheIU.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(7, maitreOuvrage);
            }
            if (annualite == null) {
                stmtpsPrepaMarcheIU.setNull(8, java.sql.Types.BOOLEAN);
            } else {
                stmtpsPrepaMarcheIU.setBoolean(8, annualite);
            }
            if (motifGreAGre == null) {
                stmtpsPrepaMarcheIU.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(9, motifGreAGre);
            }
            if (dateDebut == null) {
                stmtpsPrepaMarcheIU.setNull(10, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(10, new java.sql.Date(dateDebut.getTime()));
            }
            if (dateFin == null) {
                stmtpsPrepaMarcheIU.setNull(11, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(11, new java.sql.Date(dateFin.getTime()));
            }
            if (dateLancement == null) {
                stmtpsPrepaMarcheIU.setNull(12, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(12, new java.sql.Date(dateLancement.getTime()));
            }
            if (dateAttribution == null) {
                stmtpsPrepaMarcheIU.setNull(13, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(13, new java.sql.Date(dateAttribution.getTime()));
            }
            if (dateSignature == null) {
                stmtpsPrepaMarcheIU.setNull(14, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(14, new java.sql.Date(dateSignature.getTime()));
            }
            if (dateDemarrage == null) {
                stmtpsPrepaMarcheIU.setNull(15, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(15, new java.sql.Date(dateDemarrage.getTime()));
            }
            if (dateReception == null) {
                stmtpsPrepaMarcheIU.setNull(16, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(16, new java.sql.Date(dateReception.getTime()));
            }
            if (dateLancementCP == null) {
                stmtpsPrepaMarcheIU.setNull(17, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(17, new java.sql.Date(dateLancementCP.getTime()));
            }
            if (dateAttributionCP == null) {
                stmtpsPrepaMarcheIU.setNull(18, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(18, new java.sql.Date(dateAttributionCP.getTime()));
            }
            if (dateSignatureCP == null) {
                stmtpsPrepaMarcheIU.setNull(19, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(19, new java.sql.Date(dateSignatureCP.getTime()));
            }
            if (dateDemarrageCP == null) {
                stmtpsPrepaMarcheIU.setNull(20, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(20, new java.sql.Date(dateDemarrageCP.getTime()));
            }
            if (dateReceptionCP == null) {
                stmtpsPrepaMarcheIU.setNull(21, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(21, new java.sql.Date(dateReceptionCP.getTime()));
            }
            if (annee1 == null) {
                stmtpsPrepaMarcheIU.setNull(22, java.sql.Types.INTEGER);
            } else {
                stmtpsPrepaMarcheIU.setInt(22, annee1);
            }
            if (intitule1 == null) {
                stmtpsPrepaMarcheIU.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(23, intitule1);
            }
            if (cout1 == null) {
                stmtpsPrepaMarcheIU.setNull(24, java.sql.Types.NUMERIC);
            } else {
                stmtpsPrepaMarcheIU.setBigDecimal(24, cout1);
            }
            if (annee2 == null) {
                stmtpsPrepaMarcheIU.setNull(25, java.sql.Types.INTEGER);
            } else {
                stmtpsPrepaMarcheIU.setInt(25, annee2);
            }
            if (intitule2 == null) {
                stmtpsPrepaMarcheIU.setNull(26, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(26, intitule2);
            }
            if (cout2 == null) {
                stmtpsPrepaMarcheIU.setNull(27, java.sql.Types.NUMERIC);
            } else {
                stmtpsPrepaMarcheIU.setBigDecimal(27, cout2);
            }
            if (annee3 == null) {
                stmtpsPrepaMarcheIU.setNull(28, java.sql.Types.INTEGER);
            } else {
                stmtpsPrepaMarcheIU.setInt(28, annee3);
            }
            if (intitule3 == null) {
                stmtpsPrepaMarcheIU.setNull(29, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(29, intitule3);
            }
            if (cout3 == null) {
                stmtpsPrepaMarcheIU.setNull(30, java.sql.Types.NUMERIC);
            } else {
                stmtpsPrepaMarcheIU.setBigDecimal(30, cout3);
            }
            if (annee4 == null) {
                stmtpsPrepaMarcheIU.setNull(31, java.sql.Types.INTEGER);
            } else {
                stmtpsPrepaMarcheIU.setInt(31, annee4);
            }
            if (intitule4 == null) {
                stmtpsPrepaMarcheIU.setNull(32, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(32, intitule4);
            }
            if (cout4 == null) {
                stmtpsPrepaMarcheIU.setNull(33, java.sql.Types.NUMERIC);
            } else {
                stmtpsPrepaMarcheIU.setBigDecimal(33, cout4);
            }
            if (annee5 == null) {
                stmtpsPrepaMarcheIU.setNull(34, java.sql.Types.INTEGER);
            } else {
                stmtpsPrepaMarcheIU.setInt(34, annee5);
            }
            if (intitule5 == null) {
                stmtpsPrepaMarcheIU.setNull(35, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(35, intitule5);
            }
            if (cout5 == null) {
                stmtpsPrepaMarcheIU.setNull(36, java.sql.Types.NUMERIC);
            } else {
                stmtpsPrepaMarcheIU.setBigDecimal(36, cout5);
            }
            if (uniteExistante == null) {
                stmtpsPrepaMarcheIU.setNull(37, java.sql.Types.BOOLEAN);
            } else {
                stmtpsPrepaMarcheIU.setBoolean(37, uniteExistante);
            }
            if (intitule == null) {
                stmtpsPrepaMarcheIU.setNull(38, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(38, intitule);
            }
            if (nom == null) {
                stmtpsPrepaMarcheIU.setNull(39, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(39, nom);
            }
            if (posteOccupe == null) {
                stmtpsPrepaMarcheIU.setNull(40, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(40, posteOccupe);
            }
            if (adresse == null) {
                stmtpsPrepaMarcheIU.setNull(41, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(41, adresse);
            }
            if (email == null) {
                stmtpsPrepaMarcheIU.setNull(42, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(42, email);
            }
            if (telephone == null) {
                stmtpsPrepaMarcheIU.setNull(43, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(43, telephone);
            }
            if (userMaj == null) {
                stmtpsPrepaMarcheIU.setNull(44, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheIU.setString(44, userMaj);
            }
            if (dateMaj == null) {
                stmtpsPrepaMarcheIU.setNull(45, java.sql.Types.DATE);
            } else {
                stmtpsPrepaMarcheIU.setDate(45, new java.sql.Date(dateMaj.getTime()));
            }

            return stmtpsPrepaMarcheIU.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }    //
    //
        /*
    ps_Prepa_MarcheContractant_D
    @contractantId varchar(50)
     */

    @Override
    public int deleteMarcheContractant(String contractantId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtdeleteMarcheContractant = con.prepareCall("CALL ps_Prepa_MarcheContractant_D( ?)");

            if (contractantId == null) {
                stmtdeleteMarcheContractant.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtdeleteMarcheContractant.setString(1, contractantId);
            }

            return stmtdeleteMarcheContractant.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarcheContractant_IU
    @contractantId varchar(50),
    @libelleFr varchar(1000),
    @libelleUs varchar(1000),
    @userMaj varchar(50),
    @dateMaj datetime(8)
     */

    @Override
    public int saveMarcheContractant(String contractantId, String libelleFr, String libelleUs, String userMaj, Date dateMaj) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtsaveMarcheContractant = con.prepareCall("CALL ps_Prepa_MarcheContractant_IU( ?, ?, ?, ?, ?)");

            if (contractantId == null) {
                stmtsaveMarcheContractant.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheContractant.setString(1, contractantId);
            }
            if (libelleFr == null) {
                stmtsaveMarcheContractant.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheContractant.setString(2, libelleFr);
            }
            if (libelleUs == null) {
                stmtsaveMarcheContractant.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheContractant.setString(3, libelleUs);
            }
            if (userMaj == null) {
                stmtsaveMarcheContractant.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheContractant.setString(4, userMaj);
            }
            if (dateMaj == null) {
                stmtsaveMarcheContractant.setNull(5, java.sql.Types.DATE);
            } else {
                stmtsaveMarcheContractant.setDate(5, new java.sql.Date(dateMaj.getTime()));
            }

            return stmtsaveMarcheContractant.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarcheFinancement_D
    @financementId varchar(50)
     */

    @Override
    public int deleteMarcheFinancement(String financementId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtdeleteMarcheFinancement = con.prepareCall("CALL ps_Prepa_MarcheFinancement_D( ?)");

            if (financementId == null) {
                stmtdeleteMarcheFinancement.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtdeleteMarcheFinancement.setString(1, financementId);
            }

            return stmtdeleteMarcheFinancement.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarcheFinancement_IU
    @financementId varchar(50),
    @abbreviation varchar(50),
    @libelleFr varchar(1000),
    @libelleUs varchar(1000),
    @userMaj varchar(50),
    @dateMaj datetime(8)
     */

    @Override
    public int saveMarcheFinancement(String financementId, String abbreviation, String libelleFr, String libelleUs, String userMaj, Date dateMaj) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtsaveMarcheFinancement = con.prepareCall("CALL ps_Prepa_MarcheFinancement_IU( ?, ?, ?, ?, ?, ?)");

            if (financementId == null) {
                stmtsaveMarcheFinancement.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheFinancement.setString(1, financementId);
            }
            if (abbreviation == null) {
                stmtsaveMarcheFinancement.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheFinancement.setString(2, abbreviation);
            }
            if (libelleFr == null) {
                stmtsaveMarcheFinancement.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheFinancement.setString(3, libelleFr);
            }
            if (libelleUs == null) {
                stmtsaveMarcheFinancement.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheFinancement.setString(4, libelleUs);
            }
            if (userMaj == null) {
                stmtsaveMarcheFinancement.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheFinancement.setString(5, userMaj);
            }
            if (dateMaj == null) {
                stmtsaveMarcheFinancement.setNull(6, java.sql.Types.DATE);
            } else {
                stmtsaveMarcheFinancement.setDate(6, new java.sql.Date(dateMaj.getTime()));
            }

            return stmtsaveMarcheFinancement.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarchePrestation_D
    @naturePrestationId varchar(50)
     */

    @Override
    public int deleteMarchePrestation(String naturePrestationId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtdeleteMarchePrestation = con.prepareCall("CALL ps_Prepa_MarchePrestation_D( ?)");

            if (naturePrestationId == null) {
                stmtdeleteMarchePrestation.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtdeleteMarchePrestation.setString(1, naturePrestationId);
            }

            return stmtdeleteMarchePrestation.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarchePrestation_IU
    @naturePrestationId varchar(50),
    @code varchar(50),
    @abbreviation varchar(50),
    @libelleFr varchar(1000),
    @libelleUs varchar(1000),
    @userMaj varchar(50),
    @dateMaj datetime(8)
     */

    @Override
    public int saveMarchePrestation(String naturePrestationId, String code, String abbreviation, String libelleFr, String libelleUs, String userMaj, Date dateMaj) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtsaveMarchePrestation = con.prepareCall("CALL ps_Prepa_MarchePrestation_IU( ?, ?, ?, ?, ?, ?, ?)");

            if (naturePrestationId == null) {
                stmtsaveMarchePrestation.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarchePrestation.setString(1, naturePrestationId);
            }
            if (code == null) {
                stmtsaveMarchePrestation.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarchePrestation.setString(2, code);
            }
            if (abbreviation == null) {
                stmtsaveMarchePrestation.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarchePrestation.setString(3, abbreviation);
            }
            if (libelleFr == null) {
                stmtsaveMarchePrestation.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarchePrestation.setString(4, libelleFr);
            }
            if (libelleUs == null) {
                stmtsaveMarchePrestation.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarchePrestation.setString(5, libelleUs);
            }
            if (userMaj == null) {
                stmtsaveMarchePrestation.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarchePrestation.setString(6, userMaj);
            }
            if (dateMaj == null) {
                stmtsaveMarchePrestation.setNull(7, java.sql.Types.DATE);
            } else {
                stmtsaveMarchePrestation.setDate(7, new java.sql.Date(dateMaj.getTime()));
            }

            return stmtsaveMarchePrestation.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarcheTypeAO_D
    @typeAOId varchar(50)
     */

    @Override
    public int deleteMarcheTypeAO(String typeAOId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtdeleteMarcheTypeAO = con.prepareCall("CALL ps_Prepa_MarcheTypeAO_D( ?)");

            if (typeAOId == null) {
                stmtdeleteMarcheTypeAO.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtdeleteMarcheTypeAO.setString(1, typeAOId);
            }

            return stmtdeleteMarcheTypeAO.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //
    //
        /*
    ps_Prepa_MarcheTypeAO_IU
    @typeAOId varchar(50),
    @code varchar(50),
    @libelle varchar(1000),
    @userMaj varchar(50),
    @dateMaj datetime(8)
     */

    @Override
    public int saveMarcheTypeAO(String typeAOId, String code, String libelle, String userMaj, Date dateMaj) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtsaveMarcheTypeAO = con.prepareCall("CALL ps_Prepa_MarcheTypeAO_IU( ?, ?, ?, ?, ?)");

            if (typeAOId == null) {
                stmtsaveMarcheTypeAO.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheTypeAO.setString(1, typeAOId);
            }
            if (code == null) {
                stmtsaveMarcheTypeAO.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheTypeAO.setString(2, code);
            }
            if (libelle == null) {
                stmtsaveMarcheTypeAO.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheTypeAO.setString(3, libelle);
            }
            if (userMaj == null) {
                stmtsaveMarcheTypeAO.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtsaveMarcheTypeAO.setString(4, userMaj);
            }
            if (dateMaj == null) {
                stmtsaveMarcheTypeAO.setNull(5, java.sql.Types.DATE);
            } else {
                stmtsaveMarcheTypeAO.setDate(5, new java.sql.Date(dateMaj.getTime()));
            }

            return stmtsaveMarcheTypeAO.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_Marche_SL
    @exMillesime char(2),
    @chCode char(2),
    @paId varchar(50),
    @naturePrestationId varchar(50),
    @contractantId varchar(50),
    @typeAOId varchar(50),
    @financementId varchar(50)
     */
    @Override
    public List<PrepaMarche> getMarches(String exMillesime, String chCode, String paId, String naturePrestationId, String contractantId, String typeAOId, String financementId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMarches = con.prepareCall("CALL ps_Prepa_Marche_SL( ?, ?, ?, ?, ?, ?, ?)");

            if (exMillesime == null) {
                stmtMarches.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMarches.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmtMarches.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtMarches.setString(2, chCode);
            }
            if (paId == null) {
                stmtMarches.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtMarches.setString(3, paId);
            }
            if (naturePrestationId == null) {
                stmtMarches.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtMarches.setString(4, naturePrestationId);
            }
            if (contractantId == null) {
                stmtMarches.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtMarches.setString(5, contractantId);
            }
            if (typeAOId == null) {
                stmtMarches.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtMarches.setString(6, typeAOId);
            }
            if (financementId == null) {
                stmtMarches.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtMarches.setString(7, financementId);
            }

            List<PrepaMarche> list = new ArrayList<>();
            ResultSet rs = stmtMarches.executeQuery();
            while (rs.next()) {
                PrepaMarche e = new PrepaMarche();

                e.setPaId(rs.getString("paIdMarche"));

                e.setNaturePrestationId(rs.getString("naturePrestationId"));
                if (rs.wasNull()) {
                    e.setNaturePrestationId(null);
                }
                e.setContractantId(rs.getString("contractantId"));
                if (rs.wasNull()) {
                    e.setContractantId(null);
                }
                e.setTypeAOId(rs.getString("typeAOId"));
                if (rs.wasNull()) {
                    e.setTypeAOId(null);
                }
                e.setFinancementId(rs.getString("financementId"));
                if (rs.wasNull()) {
                    e.setFinancementId(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setAnnualite(rs.getBoolean("annualite"));
                if (rs.wasNull()) {
                    e.setAnnualite(null);
                }
                e.setMotifGreAGre(rs.getString("motifGreAGre"));
                if (rs.wasNull()) {
                    e.setMotifGreAGre(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    e.setDateDebut(null);
                }
                e.setDateFin(rs.getDate("dateFin"));
                if (rs.wasNull()) {
                    e.setDateFin(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setDateLancementCP(rs.getDate("dateLancementCP"));
                if (rs.wasNull()) {
                    e.setDateLancementCP(null);
                }
                e.setDateAttributionCP(rs.getDate("dateAttributionCP"));
                if (rs.wasNull()) {
                    e.setDateAttributionCP(null);
                }
                e.setDateSignatureCP(rs.getDate("dateSignatureCP"));
                if (rs.wasNull()) {
                    e.setDateSignatureCP(null);
                }
                e.setDateDemarrageCP(rs.getDate("dateDemarrageCP"));
                if (rs.wasNull()) {
                    e.setDateDemarrageCP(null);
                }
                e.setDateReceptionCP(rs.getDate("dateReceptionCP"));
                if (rs.wasNull()) {
                    e.setDateReceptionCP(null);
                }
                e.setUserMaj(rs.getString("userMaj"));
                if (rs.wasNull()) {
                    e.setUserMaj(null);
                }
                e.setDateMaj(rs.getDate("dateMaj"));
                if (rs.wasNull()) {
                    e.setDateMaj(null);
                }
                PrepaMarchePhasage pha = new PrepaMarchePhasage();
                pha.setAnnee1(rs.getInt("annee1"));
                if (rs.wasNull()) {
                    pha.setAnnee1(null);
                }
                pha.setIntitule1(rs.getString("intitule1"));
                if (rs.wasNull()) {
                    pha.setIntitule1(null);
                }
                pha.setCout1(rs.getBigDecimal("cout1"));
                if (rs.wasNull()) {
                    pha.setCout1(null);
                }
                pha.setAnnee2(rs.getInt("annee2"));
                if (rs.wasNull()) {
                    pha.setAnnee2(null);
                }
                pha.setIntitule2(rs.getString("intitule2"));
                if (rs.wasNull()) {
                    pha.setIntitule2(null);
                }
                pha.setCout2(rs.getBigDecimal("cout2"));
                if (rs.wasNull()) {
                    pha.setCout2(null);
                }
                pha.setAnnee3(rs.getInt("annee3"));
                if (rs.wasNull()) {
                    pha.setAnnee3(null);
                }
                pha.setIntitule3(rs.getString("intitule3"));
                if (rs.wasNull()) {
                    pha.setIntitule3(null);
                }
                pha.setCout3(rs.getBigDecimal("cout3"));
                if (rs.wasNull()) {
                    pha.setCout3(null);
                }
                pha.setAnnee4(rs.getInt("annee4"));
                if (rs.wasNull()) {
                    pha.setAnnee4(null);
                }
                pha.setIntitule4(rs.getString("intitule4"));
                if (rs.wasNull()) {
                    pha.setIntitule4(null);
                }
                pha.setCout4(rs.getBigDecimal("cout4"));
                if (rs.wasNull()) {
                    pha.setCout4(null);
                }
                pha.setAnnee5(rs.getInt("annee5"));
                if (rs.wasNull()) {
                    pha.setAnnee5(null);
                }
                pha.setIntitule5(rs.getString("intitule5"));
                if (rs.wasNull()) {
                    pha.setIntitule5(null);
                }
                pha.setCout5(rs.getBigDecimal("cout5"));
                if (rs.wasNull()) {
                    pha.setCout5(null);
                }
////                e.setPhasage(pha);
                PrepaMarcheGestion ges = new PrepaMarcheGestion();
                ges.setUniteExistante(rs.getBoolean("uniteExistante"));
                if (rs.wasNull()) {
                    ges.setUniteExistante(null);
                }
                ges.setIntitule(rs.getString("intitule"));
                if (rs.wasNull()) {
                    ges.setIntitule(null);
                }
                ges.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    ges.setNom(null);
                }
                ges.setPosteOccupe(rs.getString("posteOccupe"));
                if (rs.wasNull()) {
                    ges.setPosteOccupe(null);
                }
                ges.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    ges.setAdresse(null);
                }
                ges.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    ges.setEmail(null);
                }
                ges.setTelephone(rs.getString("telephone"));
                if (rs.wasNull()) {
                    ges.setTelephone(null);
                }
////                e.setGestion(ges);
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_MarcheContractant_SL
    @contractantId varchar(50)
     */
    @Override
    public List<PrepaMarcheContractant> getMarcheContractants(String contractantId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMarcheContractants = con.prepareCall("CALL ps_Prepa_MarcheContractant_SL( ?)");

            if (contractantId == null) {
                stmtMarcheContractants.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtMarcheContractants.setString(1, contractantId);
            }

            List<PrepaMarcheContractant> list = new ArrayList<>();
            ResultSet rs = stmtMarcheContractants.executeQuery();
            while (rs.next()) {
                PrepaMarcheContractant e = new PrepaMarcheContractant();

                e.setContractantId(rs.getString("contractantId"));

                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setUserMaj(rs.getString("userMaj"));
                if (rs.wasNull()) {
                    e.setUserMaj(null);
                }
                e.setDateMaj(rs.getDate("dateMaj"));
                if (rs.wasNull()) {
                    e.setDateMaj(null);
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_MarcheFinancement_SL
    @financementId varchar(50)
     */
    @Override
    public List<PrepaMarcheFinancement> getMarcheFinancements(String financementId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMarcheFinancements = con.prepareCall("CALL ps_Prepa_MarcheFinancement_SL( ?)");

            if (financementId == null) {
                stmtMarcheFinancements.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtMarcheFinancements.setString(1, financementId);
            }

            List<PrepaMarcheFinancement> list = new ArrayList<>();
            ResultSet rs = stmtMarcheFinancements.executeQuery();
            while (rs.next()) {
                PrepaMarcheFinancement e = new PrepaMarcheFinancement();

                e.setFinancementId(rs.getString("financementId"));

                e.setAbbreviation(rs.getString("abbreviation"));
                if (rs.wasNull()) {
                    e.setAbbreviation(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setUserMaj(rs.getString("userMaj"));
                if (rs.wasNull()) {
                    e.setUserMaj(null);
                }
                e.setDateMaj(rs.getDate("dateMaj"));
                if (rs.wasNull()) {
                    e.setDateMaj(null);
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_MarchePrestation_SL
    @naturePrestationId varchar(50)
     */
    @Override
    public List<PrepaMarchePrestation> getMarchePrestations(String naturePrestationId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMarchePrestations = con.prepareCall("CALL ps_Prepa_MarchePrestation_SL( ?)");

            if (naturePrestationId == null) {
                stmtMarchePrestations.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtMarchePrestations.setString(1, naturePrestationId);
            }

            List<PrepaMarchePrestation> list = new ArrayList<>();
            ResultSet rs = stmtMarchePrestations.executeQuery();
            while (rs.next()) {
                PrepaMarchePrestation e = new PrepaMarchePrestation();

                e.setNaturePrestationId(rs.getString("naturePrestationId"));

                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setAbbreviation(rs.getString("abbreviation"));
                if (rs.wasNull()) {
                    e.setAbbreviation(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setUserMaj(rs.getString("userMaj"));
                if (rs.wasNull()) {
                    e.setUserMaj(null);
                }
                e.setDateMaj(rs.getDate("dateMaj"));
                if (rs.wasNull()) {
                    e.setDateMaj(null);
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_MarcheTypeAO_SL
    @typeAOId varchar(50)
     */
    @Override
    public List<PrepaMarcheTypeAO> getMarcheTypeAOs(String typeAOId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMarcheTypeAOs = con.prepareCall("CALL ps_Prepa_MarcheTypeAO_SL( ?)");

            if (typeAOId == null) {
                stmtMarcheTypeAOs.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtMarcheTypeAOs.setString(1, typeAOId);
            }

            List<PrepaMarcheTypeAO> list = new ArrayList<>();
            ResultSet rs = stmtMarcheTypeAOs.executeQuery();
            while (rs.next()) {
                PrepaMarcheTypeAO e = new PrepaMarcheTypeAO();

                e.setTypeAOId(rs.getString("typeAOId"));

                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setLibelle(rs.getString("libelle"));
                if (rs.wasNull()) {
                    e.setLibelle(null);
                }
                e.setUserMaj(rs.getString("userMaj"));
                if (rs.wasNull()) {
                    e.setUserMaj(null);
                }
                e.setDateMaj(rs.getDate("dateMaj"));
                if (rs.wasNull()) {
                    e.setDateMaj(null);
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_GetMarcheByPaId
    @paId varchar(50)
     */
    @Override
    public List<VuePrepaMarche> getMarcheByPaId(String paId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaGetMarcheByPaId = con.prepareCall("CALL ps_Prepa_GetMarcheByPaId( ?)");

            if (paId == null) {
                stmtpsPrepaGetMarcheByPaId.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaGetMarcheByPaId.setString(1, paId);
            }

            List<VuePrepaMarche> list = new ArrayList<>();
            ResultSet rs = stmtpsPrepaGetMarcheByPaId.executeQuery();
            while (rs.next()) {
                VuePrepaMarche e = new VuePrepaMarche();

                e.setPrLibelleFrancais(rs.getString("prLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPrLibelleFrancais(null);
                }
                e.setPrLibelleAnglais(rs.getString("prLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setPrLibelleAnglais(null);
                }
                e.setDeLibelleFrancais(rs.getString("deLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setDeLibelleFrancais(null);
                }
                e.setDeLibelleAnglais(rs.getString("deLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setDeLibelleAnglais(null);
                }
                e.setAoLibelleFrancais(rs.getString("aoLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setAoLibelleFrancais(null);
                }
                e.setAoLibelleAnglais(rs.getString("aoLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setAoLibelleAnglais(null);
                }
                e.setExMillesime(rs.getString("exMillesime"));

                e.setChCodeChapitre(rs.getString("chCodeChapitre"));

                e.setPaLibelleFrancais(rs.getString("paLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPaLibelleFrancais(null);
                }
                e.setPaLibelleAnglais(rs.getString("paLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setPaLibelleAnglais(null);
                }
                e.setImputation(rs.getString("imputation"));
                if (rs.wasNull()) {
                    e.setImputation(null);
                }
                e.setPaId(rs.getString("paId"));

                e.setUniteExistante(rs.getBoolean("uniteExistante"));
                if (rs.wasNull()) {
                    e.setUniteExistante(null);
                }
                e.setIntitule(rs.getString("intitule"));
                if (rs.wasNull()) {
                    e.setIntitule(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setPosteOccupe(rs.getString("posteOccupe"));
                if (rs.wasNull()) {
                    e.setPosteOccupe(null);
                }
                e.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    e.setAdresse(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setTelephone(rs.getString("telephone"));
                if (rs.wasNull()) {
                    e.setTelephone(null);
                }
                e.setAnnee1(rs.getInt("annee1"));
                if (rs.wasNull()) {
                    e.setAnnee1(null);
                }
                e.setIntitule1(rs.getString("intitule1"));
                if (rs.wasNull()) {
                    e.setIntitule1(null);
                }
                e.setCout1(rs.getBigDecimal("cout1"));
                if (rs.wasNull()) {
                    e.setCout1(null);
                }
                e.setAnnee2(rs.getInt("annee2"));
                if (rs.wasNull()) {
                    e.setAnnee2(null);
                }
                e.setIntitule2(rs.getString("intitule2"));
                if (rs.wasNull()) {
                    e.setIntitule2(null);
                }
                e.setCout2(rs.getBigDecimal("cout2"));
                if (rs.wasNull()) {
                    e.setCout2(null);
                }
                e.setAnnee3(rs.getInt("annee3"));
                if (rs.wasNull()) {
                    e.setAnnee3(null);
                }
                e.setIntitule3(rs.getString("intitule3"));
                if (rs.wasNull()) {
                    e.setIntitule3(null);
                }
                e.setCout3(rs.getBigDecimal("cout3"));
                if (rs.wasNull()) {
                    e.setCout3(null);
                }
                e.setAnnee4(rs.getInt("annee4"));
                if (rs.wasNull()) {
                    e.setAnnee4(null);
                }
                e.setIntitule4(rs.getString("intitule4"));
                if (rs.wasNull()) {
                    e.setIntitule4(null);
                }
                e.setCout4(rs.getBigDecimal("cout4"));
                if (rs.wasNull()) {
                    e.setCout4(null);
                }
                e.setAnnee5(rs.getInt("annee5"));
                if (rs.wasNull()) {
                    e.setAnnee5(null);
                }
                e.setIntitule5(rs.getString("intitule5"));
                if (rs.wasNull()) {
                    e.setIntitule5(null);
                }
                e.setCout5(rs.getBigDecimal("cout5"));
                if (rs.wasNull()) {
                    e.setCout5(null);
                }
                e.setTypeAOId(rs.getString("typeAOId"));
                if (rs.wasNull()) {
                    e.setTypeAOId(null);
                }
                e.setCodeTypeAO(rs.getString("codeTypeAO"));
                if (rs.wasNull()) {
                    e.setCodeTypeAO(null);
                }
                e.setLibelleTypeAO(rs.getString("libelleTypeAO"));
                if (rs.wasNull()) {
                    e.setLibelleTypeAO(null);
                }
                e.setNaturePrestationId(rs.getString("naturePrestationId"));
                if (rs.wasNull()) {
                    e.setNaturePrestationId(null);
                }
                e.setCodePrestation(rs.getString("codePrestation"));
                if (rs.wasNull()) {
                    e.setCodePrestation(null);
                }
                e.setAbbreviationPrestation(rs.getString("abbreviationPrestation"));
                if (rs.wasNull()) {
                    e.setAbbreviationPrestation(null);
                }
                e.setLibelleFrPrestation(rs.getString("libelleFrPrestation"));
                if (rs.wasNull()) {
                    e.setLibelleFrPrestation(null);
                }
                e.setLibelleUsPrestation(rs.getString("libelleUsPrestation"));
                if (rs.wasNull()) {
                    e.setLibelleUsPrestation(null);
                }
                e.setFinancementId(rs.getString("financementId"));
                if (rs.wasNull()) {
                    e.setFinancementId(null);
                }
                e.setAbbreviationFinancement(rs.getString("abbreviationFinancement"));
                if (rs.wasNull()) {
                    e.setAbbreviationFinancement(null);
                }
                e.setLibelleFrFinancement(rs.getString("libelleFrFinancement"));
                if (rs.wasNull()) {
                    e.setLibelleFrFinancement(null);
                }
                e.setLibelleUsFinancement(rs.getString("libelleUsFinancement"));
                if (rs.wasNull()) {
                    e.setLibelleUsFinancement(null);
                }
                e.setContractantId(rs.getString("contractantId"));
                if (rs.wasNull()) {
                    e.setContractantId(null);
                }
                e.setLibelleFrContractant(rs.getString("libelleFrContractant"));
                if (rs.wasNull()) {
                    e.setLibelleFrContractant(null);
                }
                e.setLibelleUsContractant(rs.getString("libelleUsContractant"));
                if (rs.wasNull()) {
                    e.setLibelleUsContractant(null);
                }
                e.setPaIdMarche(rs.getString("paIdMarche"));
                if (rs.wasNull()) {
                    e.setPaIdMarche(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setAnnualite(rs.getBoolean("annualite"));
                if (rs.wasNull()) {
                    e.setAnnualite(null);
                }
                e.setMotifGreAGre(rs.getString("motifGreAGre"));
                if (rs.wasNull()) {
                    e.setMotifGreAGre(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    e.setDateDebut(null);
                }
                e.setDateFin(rs.getDate("dateFin"));
                if (rs.wasNull()) {
                    e.setDateFin(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setDateLancementCP(rs.getDate("dateLancementCP"));
                if (rs.wasNull()) {
                    e.setDateLancementCP(null);
                }
                e.setDateAttributionCP(rs.getDate("dateAttributionCP"));
                if (rs.wasNull()) {
                    e.setDateAttributionCP(null);
                }
                e.setDateSignatureCP(rs.getDate("dateSignatureCP"));
                if (rs.wasNull()) {
                    e.setDateSignatureCP(null);
                }
                e.setDateDemarrageCP(rs.getDate("dateDemarrageCP"));
                if (rs.wasNull()) {
                    e.setDateDemarrageCP(null);
                }
                e.setDateReceptionCP(rs.getDate("dateReceptionCP"));
                if (rs.wasNull()) {
                    e.setDateReceptionCP(null);
                }
                e.setPaCP(rs.getBigDecimal("paCP"));
                if (rs.wasNull()) {
                    e.setPaCP(null);
                }
                e.setPaLocalite(rs.getString("paLocalite"));
                if (rs.wasNull()) {
                    e.setPaLocalite(null);
                }
                e.setArCode(rs.getString("arCode"));
                if (rs.wasNull()) {
                    e.setArCode(null);
                }
                e.setNomSGP1(rs.getString("nomSGP1"));
                if (rs.wasNull()) {
                    e.setNomSGP1(null);
                }
                e.setNomSGP2(rs.getString("nomSGP2"));
                if (rs.wasNull()) {
                    e.setNomSGP2(null);
                }
                e.setAdresseSGP1(rs.getString("adresseSGP1"));
                if (rs.wasNull()) {
                    e.setAdresseSGP1(null);
                }
                e.setAdresseSGP2(rs.getString("adresseSGP2"));
                if (rs.wasNull()) {
                    e.setAdresseSGP2(null);
                }
                e.setTelSGP1(rs.getString("telSGP1"));
                if (rs.wasNull()) {
                    e.setTelSGP1(null);
                }
                e.setTelSGP2(rs.getString("telSGP2"));
                if (rs.wasNull()) {
                    e.setTelSGP2(null);
                }
                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setAbbreviationAO(rs.getString("abbreviationAO"));
                if (rs.wasNull()) {
                    e.setAbbreviationAO(null);
                }


                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_MarcheJournal
    @exMillesime char(2),
    @chCode char(2),
    @maitreOuvrage varchar(1000)
     */
    @Override
    public List<VuePrepaMarcheJournal> getMarcheJournal(String exMillesime, String chCode, String maitreOuvrage) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaMarcheJournal = con.prepareCall("CALL ps_Prepa_MarcheJournal( ?, ?, ?)");

            if (exMillesime == null) {
                stmtpsPrepaMarcheJournal.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmtpsPrepaMarcheJournal.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(2, chCode);
            }
            if (maitreOuvrage == null) {
                stmtpsPrepaMarcheJournal.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(3, maitreOuvrage);
            }

            List<VuePrepaMarcheJournal> list = new ArrayList<>();
            ResultSet rs = stmtpsPrepaMarcheJournal.executeQuery();
            while (rs.next()) {
                VuePrepaMarcheJournal e = new VuePrepaMarcheJournal();

                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setAbbreviation(rs.getString("abbreviation"));
                if (rs.wasNull()) {
                    e.setAbbreviation(null);
                }
                e.setAbbreviationAO(rs.getString("abbreviationAO"));
                if (rs.wasNull()) {
                    e.setAbbreviationAO(null);
                }
                e.setChLibelleReduitFr(rs.getString("chLibelleReduitFr"));

                e.setChCode(rs.getString("chCode"));

                e.setExMillesime(rs.getString("exMillesime"));

                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setPaLibelleFrancais(rs.getString("paLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPaLibelleFrancais(null);
                }
                e.setPaCP(rs.getBigDecimal("paCP"));
                if (rs.wasNull()) {
                    e.setPaCP(null);
                }
                e.setPaLocalite(rs.getString("paLocalite"));
                if (rs.wasNull()) {
                    e.setPaLocalite(null);
                }
                e.setAoLibelleFrancais(rs.getString("aoLibelleFrancais"));

                e.setAoLibelleAnglais(rs.getString("aoLibelleAnglais"));

                e.setDeLibelleFrancais(rs.getString("deLibelleFrancais"));

                e.setDeLibelleAnglais(rs.getString("deLibelleAnglais"));

                e.setPrLibelleFrancais(rs.getString("prLibelleFrancais"));

                e.setPrLibelleAnglais(rs.getString("prLibelleAnglais"));


                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    //
    //
        /*
    ps_Prepa_MarcheListe_MO
    @exMillesime char(2),
    @chCode char(2)
     */
    @Override
    public List<VuePrepaMarcheJournal> getMarcheListeMO(String exMillesime, String chCode) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaMarcheListeMO = con.prepareCall("CALL ps_Prepa_MarcheListe_MO( ?, ?)");

            if (exMillesime == null) {
                stmtpsPrepaMarcheListeMO.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheListeMO.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmtpsPrepaMarcheListeMO.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheListeMO.setString(2, chCode);
            }

            List<VuePrepaMarcheJournal> list = new ArrayList<>();
            ResultSet rs = stmtpsPrepaMarcheListeMO.executeQuery();
            while (rs.next()) {
                VuePrepaMarcheJournal e = new VuePrepaMarcheJournal();

                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setExMillesime(rs.getString("exMillesime"));

                e.setChCode(rs.getString("chCodeChapitre"));


                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePrepaMarche> getListeMarcheByExerciceChapitre(String exMillesime, String chCode) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL ps_Prepa_ListeMarcheByExoChapitre( ?,?)");

            if (exMillesime == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, chCode);
            }

            List<VuePrepaMarche> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePrepaMarche e = new VuePrepaMarche();
                System.out.print("entrée dans la vue");
                e.setPrLibelleFrancais(rs.getString("prLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPrLibelleFrancais(null);
                }
                e.setPrLibelleAnglais(rs.getString("prLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setPrLibelleAnglais(null);
                }
                e.setDeLibelleFrancais(rs.getString("deLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setDeLibelleFrancais(null);
                }
                e.setDeLibelleAnglais(rs.getString("deLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setDeLibelleAnglais(null);
                }
                e.setAoLibelleFrancais(rs.getString("aoLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setAoLibelleFrancais(null);
                }
                e.setAoLibelleAnglais(rs.getString("aoLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setAoLibelleAnglais(null);
                }
                e.setExMillesime(rs.getString("exMillesime"));

                e.setChCodeChapitre(rs.getString("chCodeChapitre"));

                e.setPaLibelleFrancais(rs.getString("paLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPaLibelleFrancais(null);
                }
                e.setPaLibelleAnglais(rs.getString("paLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setPaLibelleAnglais(null);
                }
                e.setImputation(rs.getString("imputation"));
                if (rs.wasNull()) {
                    e.setImputation(null);
                }
                e.setPaId(rs.getString("paId"));

                e.setUniteExistante(rs.getBoolean("uniteExistante"));
                if (rs.wasNull()) {
                    e.setUniteExistante(null);
                }
                e.setIntitule(rs.getString("intitule"));
                if (rs.wasNull()) {
                    e.setIntitule(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setPosteOccupe(rs.getString("posteOccupe"));
                if (rs.wasNull()) {
                    e.setPosteOccupe(null);
                }
                e.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    e.setAdresse(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setTelephone(rs.getString("telephone"));
                if (rs.wasNull()) {
                    e.setTelephone(null);
                }
                e.setAnnee1(rs.getInt("annee1"));
                if (rs.wasNull()) {
                    e.setAnnee1(null);
                }
                e.setIntitule1(rs.getString("intitule1"));
                if (rs.wasNull()) {
                    e.setIntitule1(null);
                }
                e.setCout1(rs.getBigDecimal("cout1"));
                if (rs.wasNull()) {
                    e.setCout1(null);
                }
                e.setAnnee2(rs.getInt("annee2"));
                if (rs.wasNull()) {
                    e.setAnnee2(null);
                }
                e.setIntitule2(rs.getString("intitule2"));
                if (rs.wasNull()) {
                    e.setIntitule2(null);
                }
                e.setCout2(rs.getBigDecimal("cout2"));
                if (rs.wasNull()) {
                    e.setCout2(null);
                }
                e.setAnnee3(rs.getInt("annee3"));
                if (rs.wasNull()) {
                    e.setAnnee3(null);
                }
                e.setIntitule3(rs.getString("intitule3"));
                if (rs.wasNull()) {
                    e.setIntitule3(null);
                }
                e.setCout3(rs.getBigDecimal("cout3"));
                if (rs.wasNull()) {
                    e.setCout3(null);
                }
                e.setAnnee4(rs.getInt("annee4"));
                if (rs.wasNull()) {
                    e.setAnnee4(null);
                }
                e.setIntitule4(rs.getString("intitule4"));
                if (rs.wasNull()) {
                    e.setIntitule4(null);
                }
                e.setCout4(rs.getBigDecimal("cout4"));
                if (rs.wasNull()) {
                    e.setCout4(null);
                }
                e.setAnnee5(rs.getInt("annee5"));
                if (rs.wasNull()) {
                    e.setAnnee5(null);
                }
                e.setIntitule5(rs.getString("intitule5"));
                if (rs.wasNull()) {
                    e.setIntitule5(null);
                }
                e.setCout5(rs.getBigDecimal("cout5"));
                if (rs.wasNull()) {
                    e.setCout5(null);
                }
                e.setTypeAOId(rs.getString("typeAOId"));
                if (rs.wasNull()) {
                    e.setTypeAOId(null);
                }
                e.setCodeTypeAO(rs.getString("codeTypeAO"));
                if (rs.wasNull()) {
                    e.setCodeTypeAO(null);
                }
                e.setLibelleTypeAO(rs.getString("libelleTypeAO"));
                if (rs.wasNull()) {
                    e.setLibelleTypeAO(null);
                }
                e.setNaturePrestationId(rs.getString("naturePrestationId"));
                if (rs.wasNull()) {
                    e.setNaturePrestationId(null);
                }
                e.setCodePrestation(rs.getString("codePrestation"));
                if (rs.wasNull()) {
                    e.setCodePrestation(null);
                }
                e.setAbbreviationPrestation(rs.getString("abbreviationPrestation"));
                if (rs.wasNull()) {
                    e.setAbbreviationPrestation(null);
                }
                e.setLibelleFrPrestation(rs.getString("libelleFrPrestation"));
                if (rs.wasNull()) {
                    e.setLibelleFrPrestation(null);
                }
                e.setLibelleUsPrestation(rs.getString("libelleUsPrestation"));
                if (rs.wasNull()) {
                    e.setLibelleUsPrestation(null);
                }
                e.setFinancementId(rs.getString("financementId"));
                if (rs.wasNull()) {
                    e.setFinancementId(null);
                }
                e.setAbbreviationFinancement(rs.getString("abbreviationFinancement"));
                if (rs.wasNull()) {
                    e.setAbbreviationFinancement(null);
                }
                e.setLibelleFrFinancement(rs.getString("libelleFrFinancement"));
                if (rs.wasNull()) {
                    e.setLibelleFrFinancement(null);
                }
                e.setLibelleUsFinancement(rs.getString("libelleUsFinancement"));
                if (rs.wasNull()) {
                    e.setLibelleUsFinancement(null);
                }
                e.setContractantId(rs.getString("contractantId"));
                if (rs.wasNull()) {
                    e.setContractantId(null);
                }
                e.setLibelleFrContractant(rs.getString("libelleFrContractant"));
                if (rs.wasNull()) {
                    e.setLibelleFrContractant(null);
                }
                e.setLibelleUsContractant(rs.getString("libelleUsContractant"));
                if (rs.wasNull()) {
                    e.setLibelleUsContractant(null);
                }
                e.setPaIdMarche(rs.getString("paIdMarche"));
                if (rs.wasNull()) {
                    e.setPaIdMarche(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setAnnualite(rs.getBoolean("annualite"));
                if (rs.wasNull()) {
                    e.setAnnualite(null);
                }
                e.setMotifGreAGre(rs.getString("motifGreAGre"));
                if (rs.wasNull()) {
                    e.setMotifGreAGre(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    e.setDateDebut(null);
                }
                e.setDateFin(rs.getDate("dateFin"));
                if (rs.wasNull()) {
                    e.setDateFin(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setDateLancementCP(rs.getDate("dateLancementCP"));
                if (rs.wasNull()) {
                    e.setDateLancementCP(null);
                }
                e.setDateAttributionCP(rs.getDate("dateAttributionCP"));
                if (rs.wasNull()) {
                    e.setDateAttributionCP(null);
                }
                e.setDateSignatureCP(rs.getDate("dateSignatureCP"));
                if (rs.wasNull()) {
                    e.setDateSignatureCP(null);
                }
                e.setDateDemarrageCP(rs.getDate("dateDemarrageCP"));
                if (rs.wasNull()) {
                    e.setDateDemarrageCP(null);
                }
                e.setDateReceptionCP(rs.getDate("dateReceptionCP"));
                if (rs.wasNull()) {
                    e.setDateReceptionCP(null);
                }
                e.setPaCP(rs.getBigDecimal("paCP"));
                if (rs.wasNull()) {
                    e.setPaCP(null);
                }
                e.setPaLocalite(rs.getString("paLocalite"));
                if (rs.wasNull()) {
                    e.setPaLocalite(null);
                }
                e.setNomSGP1(rs.getString("nomSGP1"));
                if (rs.wasNull()) {
                    e.setNomSGP1(null);
                }
                e.setNomSGP2(rs.getString("nomSGP2"));
                if (rs.wasNull()) {
                    e.setNomSGP2(null);
                }
                e.setAdresseSGP1(rs.getString("adresseSGP1"));
                if (rs.wasNull()) {
                    e.setAdresseSGP1(null);
                }
                e.setAdresseSGP2(rs.getString("adresseSGP2"));
                if (rs.wasNull()) {
                    e.setAdresseSGP2(null);
                }
                e.setTelSGP1(rs.getString("telSGP1"));
                if (rs.wasNull()) {
                    e.setTelSGP1(null);
                }
                e.setTelSGP2(rs.getString("telSGP2"));
                if (rs.wasNull()) {
                    e.setTelSGP2(null);
                }
                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setAbbreviationAO(rs.getString("abbreviationAO"));
                if (rs.wasNull()) {
                    e.setAbbreviationAO(null);
                }
                System.out.print("lecture de l'article");
                e.setArCode(rs.getString("arCode"));
                if (rs.wasNull()) {
                    e.setArCode(null);
                } 
                
                System.out.print("fin de la liste");
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePrepaMarcheJournal> getListeMarcheAttribueByChapitre(String exMillesime, String chCode) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaMarcheJournal = con.prepareCall("CALL ps_Prepa_ListeMarcheAttribueByChapitre( ?, ?)");

            if (exMillesime == null) {
                stmtpsPrepaMarcheJournal.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmtpsPrepaMarcheJournal.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(2, chCode);
            }
            List<VuePrepaMarcheJournal> list = new ArrayList<>();
            ResultSet rs = stmtpsPrepaMarcheJournal.executeQuery();
            while (rs.next()) {
                VuePrepaMarcheJournal e = new VuePrepaMarcheJournal();

                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setAbbreviation(rs.getString("abbreviation"));
                if (rs.wasNull()) {
                    e.setAbbreviation(null);
                }
                e.setAbbreviationAO(rs.getString("abbreviationAO"));
                if (rs.wasNull()) {
                    e.setAbbreviationAO(null);
                }
                e.setChLibelleReduitFr(rs.getString("chLibelleReduitFr"));

                e.setChCode(rs.getString("chCode"));

                e.setExMillesime(rs.getString("exMillesime"));

                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setPaLibelleFrancais(rs.getString("paLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPaLibelleFrancais(null);
                }
                e.setPaCP(rs.getBigDecimal("paCP"));
                if (rs.wasNull()) {
                    e.setPaCP(null);
                }
                e.setPaLocalite(rs.getString("paLocalite"));
                if (rs.wasNull()) {
                    e.setPaLocalite(null);
                }
                e.setAoLibelleFrancais(rs.getString("aoLibelleFrancais"));

                e.setAoLibelleAnglais(rs.getString("aoLibelleAnglais"));

                e.setDeLibelleFrancais(rs.getString("deLibelleFrancais"));

                e.setDeLibelleAnglais(rs.getString("deLibelleAnglais"));

                e.setPrLibelleFrancais(rs.getString("prLibelleFrancais"));

                e.setPrLibelleAnglais(rs.getString("prLibelleAnglais"));


                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePrepaMarcheJournal> getListeMarcheAttribueByRegionAndChapitre(String exMillesime, String chCode, String prProvinceID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaMarcheJournal = con.prepareCall("CALL ps_Prepa_ListeMarcheAttribueByRegionAndChapitre(?, ?, ?)");

            if (exMillesime == null) {
                stmtpsPrepaMarcheJournal.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmtpsPrepaMarcheJournal.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(2, chCode);
            }
            if (prProvinceID == null) {
                stmtpsPrepaMarcheJournal.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(3, prProvinceID);
            }
            List<VuePrepaMarcheJournal> list = new ArrayList<>();
            ResultSet rs = stmtpsPrepaMarcheJournal.executeQuery();
            while (rs.next()) {
                VuePrepaMarcheJournal e = new VuePrepaMarcheJournal();

                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                e.setAbbreviation(rs.getString("abbreviation"));
                if (rs.wasNull()) {
                    e.setAbbreviation(null);
                }
                e.setAbbreviationAO(rs.getString("abbreviationAO"));
                if (rs.wasNull()) {
                    e.setAbbreviationAO(null);
                }
                e.setChLibelleReduitFr(rs.getString("chLibelleReduitFr"));

                e.setChCode(rs.getString("chCode"));

                e.setExMillesime(rs.getString("exMillesime"));

                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setPaLibelleFrancais(rs.getString("paLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPaLibelleFrancais(null);
                }
                e.setPaCP(rs.getBigDecimal("paCP"));
                if (rs.wasNull()) {
                    e.setPaCP(null);
                }
                e.setPaLocalite(rs.getString("paLocalite"));
                if (rs.wasNull()) {
                    e.setPaLocalite(null);
                }
                e.setAoLibelleFrancais(rs.getString("aoLibelleFrancais"));

                e.setAoLibelleAnglais(rs.getString("aoLibelleAnglais"));

                e.setDeLibelleFrancais(rs.getString("deLibelleFrancais"));

                e.setDeLibelleAnglais(rs.getString("deLibelleAnglais"));

                e.setPrLibelleFrancais(rs.getString("prLibelleFrancais"));

                e.setPrLibelleAnglais(rs.getString("prLibelleAnglais"));


                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(PrepaMarcheDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    //</editor-fold>

    @Override
    public List<VuePrepaMarcheJournal> getMarcheAbbreviationUnique(String abbreviationSF, String abbreviationPr, String abbreviationAO) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsPrepaMarcheJournal = con.prepareCall("CALL ps_Prepa_Marche_AbbreviationUnique(?, ?, ?)");

            if (abbreviationSF == null) {
                stmtpsPrepaMarcheJournal.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(1, abbreviationSF);
            }
            if (abbreviationPr == null) {
                stmtpsPrepaMarcheJournal.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(2, abbreviationPr);
            }
            if (abbreviationAO == null) {
                stmtpsPrepaMarcheJournal.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsPrepaMarcheJournal.setString(3, abbreviationAO);
            }
            List<VuePrepaMarcheJournal> list = new ArrayList<>();
            ResultSet rs = stmtpsPrepaMarcheJournal.executeQuery();
            while (rs.next()) {
                VuePrepaMarcheJournal e = new VuePrepaMarcheJournal();

                e.setAbbreviation(rs.getString("abbreviation"));
                if (rs.wasNull()) {
                    e.setAbbreviation(null);
                }


                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePrepaMarche> getListeMarcheRecovery(String exMillesime, String chCode) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL [ps_Prepa_Marche_Recovery](?,?)");

            if (exMillesime == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, exMillesime);
            }
            if (chCode == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, chCode);
            }

            List<VuePrepaMarche> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePrepaMarche e = new VuePrepaMarche();
 
                e.setPrLibelleFrancais(rs.getString("prLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPrLibelleFrancais(null);
                }
                e.setPrLibelleAnglais(rs.getString("prLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setPrLibelleAnglais(null);
                }
                e.setDeLibelleFrancais(rs.getString("deLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setDeLibelleFrancais(null);
                }
                e.setDeLibelleAnglais(rs.getString("deLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setDeLibelleAnglais(null);
                }
                e.setAoLibelleFrancais(rs.getString("aoLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setAoLibelleFrancais(null);
                }
                e.setAoLibelleAnglais(rs.getString("aoLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setAoLibelleAnglais(null);
                }
                e.setExMillesime(rs.getString("exMillesime"));

                e.setChCodeChapitre(rs.getString("chCodeChapitre"));

                e.setPaLibelleFrancais(rs.getString("paLibelleFrancais"));
                if (rs.wasNull()) {
                    e.setPaLibelleFrancais(null);
                }
                e.setPaLibelleAnglais(rs.getString("paLibelleAnglais"));
                if (rs.wasNull()) {
                    e.setPaLibelleAnglais(null);
                }
                e.setImputation(rs.getString("imputation"));
                if (rs.wasNull()) {
                    e.setImputation(null);
                }
                e.setPaId(rs.getString("paId"));

                e.setUniteExistante(rs.getBoolean("uniteExistante"));
                if (rs.wasNull()) {
                    e.setUniteExistante(null);
                }
                e.setIntitule(rs.getString("intitule"));
                if (rs.wasNull()) {
                    e.setIntitule(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setPosteOccupe(rs.getString("posteOccupe"));
                if (rs.wasNull()) {
                    e.setPosteOccupe(null);
                }
                e.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    e.setAdresse(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setTelephone(rs.getString("telephone"));
                if (rs.wasNull()) {
                    e.setTelephone(null);
                }
                e.setAnnee1(rs.getInt("annee1"));
                if (rs.wasNull()) {
                    e.setAnnee1(null);
                }
                e.setIntitule1(rs.getString("intitule1"));
                if (rs.wasNull()) {
                    e.setIntitule1(null);
                }
                e.setCout1(rs.getBigDecimal("cout1"));
                if (rs.wasNull()) {
                    e.setCout1(null);
                }
                e.setAnnee2(rs.getInt("annee2"));
                if (rs.wasNull()) {
                    e.setAnnee2(null);
                }
                e.setIntitule2(rs.getString("intitule2"));
                if (rs.wasNull()) {
                    e.setIntitule2(null);
                }
                e.setCout2(rs.getBigDecimal("cout2"));
                if (rs.wasNull()) {
                    e.setCout2(null);
                }
                e.setAnnee3(rs.getInt("annee3"));
                if (rs.wasNull()) {
                    e.setAnnee3(null);
                }
                e.setIntitule3(rs.getString("intitule3"));
                if (rs.wasNull()) {
                    e.setIntitule3(null);
                }
                e.setCout3(rs.getBigDecimal("cout3"));
                if (rs.wasNull()) {
                    e.setCout3(null);
                }
                e.setAnnee4(rs.getInt("annee4"));
                if (rs.wasNull()) {
                    e.setAnnee4(null);
                }
                e.setIntitule4(rs.getString("intitule4"));
                if (rs.wasNull()) {
                    e.setIntitule4(null);
                }
                e.setCout4(rs.getBigDecimal("cout4"));
                if (rs.wasNull()) {
                    e.setCout4(null);
                }
                e.setAnnee5(rs.getInt("annee5"));
                if (rs.wasNull()) {
                    e.setAnnee5(null);
                }
                e.setIntitule5(rs.getString("intitule5"));
                if (rs.wasNull()) {
                    e.setIntitule5(null);
                }
                e.setCout5(rs.getBigDecimal("cout5"));
                if (rs.wasNull()) {
                    e.setCout5(null);
                }
                e.setTypeAOId(rs.getString("typeAOId"));
                if (rs.wasNull()) {
                    e.setTypeAOId(null);
                }
                e.setCodeTypeAO(rs.getString("codeTypeAO"));
                if (rs.wasNull()) {
                    e.setCodeTypeAO(null);
                }
                e.setLibelleTypeAO(rs.getString("libelleTypeAO"));
                if (rs.wasNull()) {
                    e.setLibelleTypeAO(null);
                }
                e.setNaturePrestationId(rs.getString("naturePrestationId"));
                if (rs.wasNull()) {
                    e.setNaturePrestationId(null);
                }
                e.setCodePrestation(rs.getString("codePrestation"));
                if (rs.wasNull()) {
                    e.setCodePrestation(null);
                }
                e.setAbbreviationPrestation(rs.getString("abbreviationPrestation"));
                if (rs.wasNull()) {
                    e.setAbbreviationPrestation(null);
                }
                e.setLibelleFrPrestation(rs.getString("libelleFrPrestation"));
                if (rs.wasNull()) {
                    e.setLibelleFrPrestation(null);
                }
                e.setLibelleUsPrestation(rs.getString("libelleUsPrestation"));
                if (rs.wasNull()) {
                    e.setLibelleUsPrestation(null);
                }
                e.setFinancementId(rs.getString("financementId"));
                if (rs.wasNull()) {
                    e.setFinancementId(null);
                }
                e.setAbbreviationFinancement(rs.getString("abbreviationFinancement"));
                if (rs.wasNull()) {
                    e.setAbbreviationFinancement(null);
                }
                e.setLibelleFrFinancement(rs.getString("libelleFrFinancement"));
                if (rs.wasNull()) {
                    e.setLibelleFrFinancement(null);
                }
                e.setLibelleUsFinancement(rs.getString("libelleUsFinancement"));
                if (rs.wasNull()) {
                    e.setLibelleUsFinancement(null);
                }
                e.setContractantId(rs.getString("contractantId"));
                if (rs.wasNull()) {
                    e.setContractantId(null);
                }
                e.setLibelleFrContractant(rs.getString("libelleFrContractant"));
                if (rs.wasNull()) {
                    e.setLibelleFrContractant(null);
                }
                e.setLibelleUsContractant(rs.getString("libelleUsContractant"));
                if (rs.wasNull()) {
                    e.setLibelleUsContractant(null);
                }
                e.setPaIdMarche(rs.getString("paIdMarche"));
                if (rs.wasNull()) {
                    e.setPaIdMarche(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    e.setNumOrdre(null);
                }
                e.setMaitreOuvrage(rs.getString("maitreOuvrage"));
                if (rs.wasNull()) {
                    e.setMaitreOuvrage(null);
                }
                e.setAnnualite(rs.getBoolean("annualite"));
                if (rs.wasNull()) {
                    e.setAnnualite(null);
                }
                e.setMotifGreAGre(rs.getString("motifGreAGre"));
                if (rs.wasNull()) {
                    e.setMotifGreAGre(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                if (rs.wasNull()) {
                    e.setDateDebut(null);
                }
                e.setDateFin(rs.getDate("dateFin"));
                if (rs.wasNull()) {
                    e.setDateFin(null);
                }
                e.setDateLancement(rs.getDate("dateLancement"));
                if (rs.wasNull()) {
                    e.setDateLancement(null);
                }
                e.setDateAttribution(rs.getDate("dateAttribution"));
                if (rs.wasNull()) {
                    e.setDateAttribution(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setDateDemarrage(rs.getDate("dateDemarrage"));
                if (rs.wasNull()) {
                    e.setDateDemarrage(null);
                }
                e.setDateReception(rs.getDate("dateReception"));
                if (rs.wasNull()) {
                    e.setDateReception(null);
                }
                e.setDateLancementCP(rs.getDate("dateLancementCP"));
                if (rs.wasNull()) {
                    e.setDateLancementCP(null);
                }
                e.setDateAttributionCP(rs.getDate("dateAttributionCP"));
                if (rs.wasNull()) {
                    e.setDateAttributionCP(null);
                }
                e.setDateSignatureCP(rs.getDate("dateSignatureCP"));
                if (rs.wasNull()) {
                    e.setDateSignatureCP(null);
                }
                e.setDateDemarrageCP(rs.getDate("dateDemarrageCP"));
                if (rs.wasNull()) {
                    e.setDateDemarrageCP(null);
                }
                e.setDateReceptionCP(rs.getDate("dateReceptionCP"));
                if (rs.wasNull()) {
                    e.setDateReceptionCP(null);
                }
                e.setPaCP(rs.getBigDecimal("paCP"));
                if (rs.wasNull()) {
                    e.setPaCP(null);
                }
                e.setPaLocalite(rs.getString("paLocalite"));
                if (rs.wasNull()) {
                    e.setPaLocalite(null);
                }
                e.setNomSGP1(rs.getString("nomSGP1"));
                if (rs.wasNull()) {
                    e.setNomSGP1(null);
                }
                e.setNomSGP2(rs.getString("nomSGP2"));
                if (rs.wasNull()) {
                    e.setNomSGP2(null);
                }
                e.setAdresseSGP1(rs.getString("adresseSGP1"));
                if (rs.wasNull()) {
                    e.setAdresseSGP1(null);
                }
                e.setAdresseSGP2(rs.getString("adresseSGP2"));
                if (rs.wasNull()) {
                    e.setAdresseSGP2(null);
                }
                e.setTelSGP1(rs.getString("telSGP1"));
                if (rs.wasNull()) {
                    e.setTelSGP1(null);
                }
                e.setTelSGP2(rs.getString("telSGP2"));
                if (rs.wasNull()) {
                    e.setTelSGP2(null);
                }
                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setAbbreviationAO(rs.getString("abbreviationAO"));
                if (rs.wasNull()) {
                    e.setAbbreviationAO(null);
                } 
                e.setArCode(rs.getString("arCode"));
                if (rs.wasNull()) {
                    e.setArCode(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {  
            return null;
        } finally {
            try {  
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePrepaMarcheArticle> getListeMarcheArticle(String arCode, String user) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL ps_Prepa_Marche_ListeARParent(?,?)");

            if (arCode == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, arCode);
            }
            if (user == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, user);
            }

            List<VuePrepaMarcheArticle> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePrepaMarcheArticle e = new VuePrepaMarcheArticle();
 
                e.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    e.setCode(null);
                }
                e.setLibelleEN(rs.getString("libelleEN"));
                if (rs.wasNull()) {
                    e.setLibelleEN(null);
                }
                e.setLibelleFR(rs.getString("libelleFR"));
                if (rs.wasNull()) {
                    e.setLibelleFR(null);
                }
                e.setType(rs.getString("Type"));
                if (rs.wasNull()) {
                    e.setType(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {  
            return null;
        } finally {
            try {  
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<OperationBudgetaire> getParagrapheParChapitreEtNature(String exMillesime, String chCode, String neLike) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
