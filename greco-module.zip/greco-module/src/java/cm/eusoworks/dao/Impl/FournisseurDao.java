/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IFournisseurDao;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.exception.GrecoException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class FournisseurDao implements IFournisseurDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public void ajouter(Fournisseur four) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseur_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (four.getUserUpdate() == null) {
                stmtFour.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(1, four.getUserUpdate());
            }
            if (four.getIpUpdate() == null) {
                stmtFour.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(2, four.getIpUpdate());
            }
            if (four.getFournisseurID() == null) {
                stmtFour.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(3, four.getFournisseurID());
            }
            if (four.getNumContribuable() == null) {
                stmtFour.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(4, four.getNumContribuable());
            }
            if (four.getRaisonSociale() == null) {
                stmtFour.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(5, four.getRaisonSociale());
            }
            if (four.getAdresse() == null) {
                stmtFour.setNull(6, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(6, four.getAdresse());
            }
            if (four.getRib() == null) {
                stmtFour.setNull(7, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(7, four.getRib());
            }
            if (four.getBanque() == null) {
                stmtFour.setNull(8, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(8, four.getBanque());
            }
            if (four.getAgence() == null) {
                stmtFour.setNull(9, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(9, four.getAgence());
            }
            if (four.getRegistreCommerce() == null) {
                stmtFour.setNull(10, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(10, four.getRegistreCommerce());
            }
            if (four.getTelephone() == null) {
                stmtFour.setNull(11, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(11, four.getTelephone());
            }

            stmtFour.executeUpdate();

        } catch (Exception exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public String ajouterFournisseurBudgetaire(Fournisseur four, String exMillesime) throws GrecoException {
        Connection con = null;
        String numContribuable;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseurBudgetaire_Insert( ?, ?, ?, ?, ?, ?, ?, ?)");
            if (four.getUserUpdate() == null) {
                stmtFour.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(1, four.getUserUpdate());
            }
            if (four.getIpUpdate() == null) {
                stmtFour.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(2, four.getIpUpdate());
            }
            if (four.getFournisseurID() == null) {
                stmtFour.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(3, four.getFournisseurID());
            }
            if (four.getNumContribuable() == null) {
                stmtFour.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(4, four.getNumContribuable());
            }
            if (four.getRaisonSociale() == null) {
                stmtFour.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(5, four.getRaisonSociale());
            }
            if (four.getAdresse() == null) {
                stmtFour.setNull(6, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(6, four.getAdresse());
            }
            if (four.getRib() == null) {
                stmtFour.setNull(7, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(7, four.getRib());
            }
            if (exMillesime == null) {
                stmtFour.setNull(8, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(8, exMillesime);
            }

            stmtFour.registerOutParameter(4, java.sql.Types.CHAR);

            stmtFour.executeUpdate();

            numContribuable = stmtFour.getString(4);
            return numContribuable;
        } catch (SQLException exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
            }
        }
    }

    @Override
    public void modifier(Fournisseur four) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseur_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (four.getUserUpdate() == null) {
                stmtFour.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(1, four.getUserUpdate());
            }
            if (four.getIpUpdate() == null) {
                stmtFour.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(2, four.getIpUpdate());
            }
            if (four.getFournisseurID() == null) {
                stmtFour.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(3, four.getFournisseurID());
            }
            if (four.getNumContribuable() == null) {
                stmtFour.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtFour.setString(4, four.getNumContribuable());
            }
            if (four.getRaisonSociale() == null) {
                stmtFour.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(5, four.getRaisonSociale());
            }
            if (four.getAdresse() == null) {
                stmtFour.setNull(6, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(6, four.getAdresse());
            }
            if (four.getRib() == null) {
                stmtFour.setNull(7, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(7, four.getRib());
            }
            if (four.getBanque() == null) {
                stmtFour.setNull(8, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(8, four.getBanque());
            }
            if (four.getAgence() == null) {
                stmtFour.setNull(9, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(9, four.getAgence());
            }
            if (four.getRegistreCommerce() == null) {
                stmtFour.setNull(10, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(10, four.getRegistreCommerce());
            }
            if (four.getTelephone() == null) {
                stmtFour.setNull(11, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(11, four.getTelephone());
            }

            stmtFour.executeUpdate();

        } catch (Exception exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void supprimer(String fournisseurID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseur_Delete( ?)");

            stmtFour.setString(1, fournisseurID);
            stmtFour.executeUpdate();

        } catch (Exception exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Fournisseur getFournisseur(String fournisseurID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseur_Find( ?)");
            if (fournisseurID == null) {
                stmtFour.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(1, fournisseurID);
            }

            Fournisseur e = null;
            ResultSet rs = stmtFour.executeQuery();

            while (rs.next()) {
                e = new Fournisseur();

                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setRaisonSociale(rs.getString("raisonSociale"));
                if (rs.wasNull()) {
                    e.setRaisonSociale(null);
                }
                e.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    e.setAdresse(null);
                }
                e.setNumContribuable(rs.getString("numContribuable"));
                if (rs.wasNull()) {
                    e.setNumContribuable(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setBanque(rs.getString("banque"));
                if (rs.wasNull()) {
                    e.setBanque(null);
                }
                e.setAgence(rs.getString("agence"));
                if (rs.wasNull()) {
                    e.setAgence(null);
                }

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setFourBudgetaire(rs.getBoolean("fourBudgetaire"));
                if (rs.wasNull()) {
                    e.setFourBudgetaire(false);
                }
            }
            return e;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Fournisseur> getListFournisseur() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseur_List()");
            List<Fournisseur> listFournisseur = new ArrayList<>();

            ResultSet rs = stmtFour.executeQuery();
            while (rs.next()) {
                Fournisseur e = new Fournisseur();

                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setRaisonSociale(rs.getString("raisonSociale"));
                if (rs.wasNull()) {
                    e.setRaisonSociale(null);
                }
                e.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    e.setAdresse(null);
                }
                e.setNumContribuable(rs.getString("numContribuable"));
                if (rs.wasNull()) {
                    e.setNumContribuable(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setBanque(rs.getString("banque"));
                if (rs.wasNull()) {
                    e.setBanque(null);
                }
                e.setAgence(rs.getString("agence"));
                if (rs.wasNull()) {
                    e.setAgence(null);
                }
                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setFourBudgetaire(rs.getBoolean("fourBudgetaire"));
                if (rs.wasNull()) {
                    e.setFourBudgetaire(false);
                }

                listFournisseur.add(e);
            }
            return listFournisseur;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Fournisseur> getListFournisseurByNumContribuable(String numContribuable) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtFour = con.prepareCall("CALL psFournisseur_ByContribuable( ?)");
            if (numContribuable == null) {
                stmtFour.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtFour.setString(1, numContribuable);
            }
            List<Fournisseur> listFournisseur = new ArrayList<>();

            ResultSet rs = stmtFour.executeQuery();
            while (rs.next()) {
                Fournisseur e = new Fournisseur();

                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setRaisonSociale(rs.getString("raisonSociale"));
                if (rs.wasNull()) {
                    e.setRaisonSociale(null);
                }
                e.setAdresse(rs.getString("adresse"));
                if (rs.wasNull()) {
                    e.setAdresse(null);
                }
                e.setNumContribuable(rs.getString("numContribuable"));
                if (rs.wasNull()) {
                    e.setNumContribuable(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setBanque(rs.getString("banque"));
                if (rs.wasNull()) {
                    e.setBanque(null);
                }
                e.setAgence(rs.getString("agence"));
                if (rs.wasNull()) {
                    e.setAgence(null);
                }
                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setFourBudgetaire(rs.getBoolean("fourBudgetaire"));
                if (rs.wasNull()) {
                    e.setFourBudgetaire(false);
                }

                listFournisseur.add(e);
            }
            return listFournisseur;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}
