/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IMercurialeDao;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Rubrique;
import cm.eusoworks.entities.model.SousRubrique;
import cm.eusoworks.entities.exception.GrecoException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class MercurialeDao implements IMercurialeDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public String ajouterArticle(Article act) throws GrecoException {
        Connection con = null;
        String refArticle = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeArticleI = con.prepareCall("CALL psArticle_Insert( ?, ?, ?, ?, ?)");
            if (act.getMillesime() == null) {
                stmtMercurialeArticleI.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeArticleI.setString(1, act.getMillesime());
            }
            if (act.getDesignation() == null) {
                stmtMercurialeArticleI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeArticleI.setString(2, act.getDesignation());
            }
            if (act.getConditionnement() == null) {
                stmtMercurialeArticleI.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtMercurialeArticleI.setString(3, act.getConditionnement());
            }
            if (act.getPrixDeReference() == null) {
                stmtMercurialeArticleI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeArticleI.setBigDecimal(4, act.getPrixDeReference());
            }
            if (refArticle == null) {
                stmtMercurialeArticleI.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtMercurialeArticleI.setString(5, refArticle);
            }

            stmtMercurialeArticleI.registerOutParameter(5, java.sql.Types.CHAR);

            stmtMercurialeArticleI.executeUpdate();

            refArticle = stmtMercurialeArticleI.getString(5);
            return refArticle;
        } catch (Exception exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void modifierArticle(Article act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeArticleI = con.prepareCall("CALL psArticle_Update( ?, ?, ?, ?, ?)");
            if (act.getMillesime() == null) {
                stmtMercurialeArticleI.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeArticleI.setString(1, act.getMillesime());
            }
            if (act.getDesignation() == null) {
                stmtMercurialeArticleI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeArticleI.setString(2, act.getDesignation());
            }
            if (act.getConditionnement() == null) {
                stmtMercurialeArticleI.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtMercurialeArticleI.setString(3, act.getConditionnement());
            }
            if (act.getPrixDeReference() == null) {
                stmtMercurialeArticleI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeArticleI.setBigDecimal(4, act.getPrixDeReference());
            }
            if (act.getRefArticle() == null) {
                stmtMercurialeArticleI.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtMercurialeArticleI.setString(5, act.getRefArticle());
            }

            stmtMercurialeArticleI.executeUpdate();
        } catch (Exception exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void supprimerArticle(String amId) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeArticleI = con.prepareCall("CALL psArticle_Delete( ?)");

            stmtMercurialeArticleI.setString(1, amId);

            stmtMercurialeArticleI.executeUpdate();

        } catch (Exception exception) {
            throw new GrecoException(exception);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Article getArticle(String millesime, String refArticle) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticle_Find( ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (refArticle == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, refArticle);
            }

            Article e = null;
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }
                e.setQuantite(1);
                e.setPrixTotal(rs.getBigDecimal("prixDeReference"));
                e.setPrixUnitaire(rs.getBigDecimal("prixDeReference"));
                e.setRemise(BigDecimal.ZERO);
            }
            return e;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Article> rchercherArticle(String millesime, String chaineRecherchee) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticle_Search( ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (chaineRecherchee == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, chaineRecherchee);
            }

            List<Article> list = new ArrayList<Article>();
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                Article e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }

                list.add(e);
            }
            return list;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Rubrique> getListRubriques(String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psRubrique_List( ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }

            List<Rubrique> list = new ArrayList<Rubrique>();
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                Rubrique e = new Rubrique();

                e.setRuId(rs.getString("ruId"));
                if (rs.wasNull()) {
                    e.setRuId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }

                list.add(e);
            }
            return list;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<SousRubrique> getListSousRubriques(String millesime, String numRubrique) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psSousRubrique_List( ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (numRubrique == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, numRubrique);
            }

            List<SousRubrique> list = new ArrayList<SousRubrique>();
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                SousRubrique e = new SousRubrique();

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setRuId(rs.getString("ruId"));
                if (rs.wasNull()) {
                    e.setRuId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }

                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }

                list.add(e);
            }
            return list;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Article> getListArticleBySousRubrique(String millesime, String numSousRubrique) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticle_List( ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (numSousRubrique == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, numSousRubrique);
            }

            List<Article> list = new ArrayList<Article>();
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                Article e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }

                list.add(e);
            }
            return list;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Article getArticle(String amId) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticle_S( ?)");
            if (amId == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, amId);
            }

            Article e = null;
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }
                e.setQuantite(1);
                e.setPrixTotal(rs.getBigDecimal("prixDeReference"));
                e.setPrixUnitaire(rs.getBigDecimal("prixDeReference"));
                e.setRemise(BigDecimal.ZERO);
            }
            return e;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Article getArticle(String millesime, String refArticle, Date dateEmission) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticle_FindPrix( ?, ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (refArticle == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, refArticle);
            }
            if (dateEmission == null) {
                stmtMercurialeF.setNull(3, java.sql.Types.DATE);
            } else {
                stmtMercurialeF.setDate(3, new java.sql.Date(dateEmission.getTime()));
            }

            Article e = null;
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }
                try {
                    e.setPrixMax(rs.getBigDecimal("prixMax"));
                    if (rs.wasNull()) {
                        e.setPrixMax(null);
                    }
                } catch (Exception ee) {
                }
                e.setQuantite(1);
                e.setPrixTotal(rs.getBigDecimal("prixDeReference"));
                e.setPrixUnitaire(rs.getBigDecimal("prixDeReference"));
                e.setRemise(BigDecimal.ZERO);
            }
            return e;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Article> getStockArticles(String millesime, String refArticle, boolean isRefOrDesignation) {
        Connection con = null;
        List<Article> listeArt = new ArrayList<>();
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticleStock_Search( ?, ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (refArticle == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, refArticle);
            }
            stmtMercurialeF.setBoolean(3, isRefOrDesignation);

            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                Article e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }
                e.setQuantite(1);
                e.setPrixTotal(rs.getBigDecimal("prixDeReference"));
                e.setPrixUnitaire(rs.getBigDecimal("prixDeReference"));
                e.setRemise(BigDecimal.ZERO);
                
                listeArt.add(e);
            }
            return listeArt;
        } catch (Exception exception) {
            exception.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public Article getStockArticle(String millesime, String refArticle) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtMercurialeF = con.prepareCall("CALL psArticleStock_Find( ?, ?)");
            if (millesime == null) {
                stmtMercurialeF.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtMercurialeF.setString(1, millesime);
            }
            if (refArticle == null) {
                stmtMercurialeF.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtMercurialeF.setString(2, refArticle);
            }

            Article e = null;
            ResultSet rs = stmtMercurialeF.executeQuery();

            while (rs.next()) {
                e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }
                e.setQuantite(1);
                e.setPrixTotal(rs.getBigDecimal("prixDeReference"));
                e.setPrixUnitaire(rs.getBigDecimal("prixDeReference"));
                e.setRemise(BigDecimal.ZERO);
            }
            return e;
        } catch (Exception exception) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }

}
