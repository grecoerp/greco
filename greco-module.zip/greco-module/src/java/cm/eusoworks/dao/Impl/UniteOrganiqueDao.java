/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IUniteOrganiqueDao;
import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.NiveauOrganique;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class UniteOrganiqueDao implements IUniteOrganiqueDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public int ajouter(UniteOrganique org, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getUniteOrganiqueID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getUniteOrganiqueID());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getLibelleUs());
            }

            stmt.setInt(6, org.getOrdre());
            stmt.setInt(7, org.getR());
            stmt.setInt(8, org.getG());
            stmt.setInt(9, org.getB());
            
            if (org.getUniteOrganiqueParentID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, org.getUniteOrganiqueParentID());
            }
            if (org.getMissionsFr()== null) {
                stmt.setNull(11, java.sql.Types.BLOB);
            } else {
                stmt.setString(11, org.getMissionsFr());
            }
            if (org.getMissionsUs()== null) {
                stmt.setNull(12, java.sql.Types.BLOB);
            } else {
                stmt.setString(12, org.getMissionsUs());
            }
            if (org.getOrganisationID()== null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, org.getOrganisationID());
            }

            stmt.registerOutParameter(14, java.sql.Types.INTEGER);
            stmt.setInt(14, codeErreur);
            
            stmt.executeQuery();

            codeErreur = stmt.getInt(14);
            return codeErreur;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int modifier(UniteOrganique org, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getUniteOrganiqueID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getUniteOrganiqueID());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getLibelleUs());
            }

            stmt.setInt(6, org.getOrdre());
            stmt.setInt(7, org.getR());
            stmt.setInt(8, org.getG());
            stmt.setInt(9, org.getB());

            if (org.getUniteOrganiqueParentID() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, org.getUniteOrganiqueParentID());
            }
            if (org.getMissionsFr()== null) {
                stmt.setNull(11, java.sql.Types.BLOB);
            } else {
                stmt.setString(11, org.getMissionsFr());
            }
            if (org.getMissionsUs()== null) {
                stmt.setNull(12, java.sql.Types.BLOB);
            } else {
                stmt.setString(12, org.getMissionsUs());
            }
            if (org.getOrganisationID()== null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, org.getOrganisationID());
            }
            
            stmt.registerOutParameter(14, java.sql.Types.INTEGER);
            stmt.setInt(14, codeErreur);
            
            stmt.executeQuery();

            codeErreur = stmt.getInt(14);
            return codeErreur;
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String uniteOrganiqueID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_Delete(?)");
            stmt.setString(1, uniteOrganiqueID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public UniteOrganique rechercherById(String uniteOrganiqueID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_SearchID(?)");
            stmt.setString(1, uniteOrganiqueID);

            UniteOrganique o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");
                

            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public UniteOrganique rechercherByOrder(int numOrde) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_SearchOrder(?)");
            stmt.setInt(1, numOrde);

            UniteOrganique o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<UniteOrganique> listeUniteOrganique(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_List(?)");
            stmt.setString(1, organisationID);
            
            List<UniteOrganique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UniteOrganique o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<UniteOrganique> listeUniteOrganiqueFilles(String uniteOrganiqueID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_Filles(?)");
            stmt.setString(1, uniteOrganiqueID);

            List<UniteOrganique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UniteOrganique o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public List<UniteOrganique> getUniteOrganiqueForStructure(String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_Structure(?)");
            stmt.setString(1, structureID);

            List<UniteOrganique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UniteOrganique o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<UniteOrganique> getUniteOrganiqueFillesForStructure(String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_StructureFilles(?)");
            stmt.setString(1, structureID);

            List<UniteOrganique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UniteOrganique o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int ajouterNiveau(NiveauOrganique org, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psNiveauOrganique_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ? )");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getNiveauOrganiqueID() == null) {
                stmt.setNull(3, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(3, org.getNiveauOrganiqueID());
            }
            if (org.getOrganisationID()== null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getOrganisationID());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getLibelleUs());
            }

            stmt.setInt(7, org.getR());
            stmt.setInt(8, org.getG());
            stmt.setInt(9, org.getB());

            stmt.registerOutParameter(10, java.sql.Types.INTEGER);
            stmt.setInt(10, codeErreur);
            
            stmt.executeQuery();

            codeErreur = stmt.getInt(10);
            return codeErreur;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int modifierNiveau(NiveauOrganique org, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psNiveauOrganique_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ? )");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getNiveauOrganiqueID() == null) {
                stmt.setNull(3, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(3, org.getNiveauOrganiqueID());
            }
            if (org.getOrganisationID()== null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getOrganisationID());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getLibelleUs());
            }

            stmt.setInt(7, org.getR());
            stmt.setInt(8, org.getG());
            stmt.setInt(9, org.getB());

            stmt.registerOutParameter(10, java.sql.Types.INTEGER);
            stmt.setInt(10, codeErreur);
            
            stmt.executeQuery();

            codeErreur = stmt.getInt(10);
            return codeErreur;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerNiveau(int niveauOrganiqueID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psNiveauOrganique_Delete(?)");
            stmt.setInt(1, niveauOrganiqueID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public NiveauOrganique rechercherNiveauById(String niveauOrganiqueID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psNiveauOrganique_SearchID(?)");
            stmt.setString(1, niveauOrganiqueID);

            NiveauOrganique o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new NiveauOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setNiveauOrganiqueID(rs.getInt("niveauOrganiqueID"));
                if (rs.wasNull()) {
                    o.setNiveauOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));

                o.setOrganisationID("organisationID");
                

            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<NiveauOrganique> listeNiveauOrganique(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psNiveauOrganique_List(?)");
            stmt.setString(1, organisationID);

            List<NiveauOrganique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                NiveauOrganique o = new NiveauOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setNiveauOrganiqueID(rs.getInt("niveauOrganiqueID"));
                if (rs.wasNull()) {
                    o.setNiveauOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));

                o.setOrganisationID("organisationID");
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<UniteOrganique> listeUniteOrganiqueByNiveau(String organisationID, int niveauOrganiqueID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUniteOrganique_ListByNiveau(?, ?)");
            stmt.setString(1, organisationID);
            stmt.setInt(2, niveauOrganiqueID);
            
            List<UniteOrganique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                UniteOrganique o = new UniteOrganique();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setOrdre(rs.getInt("ordre"));
                o.setR(rs.getInt("r"));
                o.setG(rs.getInt("g"));
                o.setB(rs.getInt("b"));
                
                o.setUniteOrganiqueParentID(rs.getString("uniteOrganiqueParentID"));
                o.setMissionsFr(rs.getString("missionsFr"));
                o.setMissionsUs(rs.getString("missionsUs"));
                o.setOrganisationID("organisationID");

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            ex.printStackTrace();
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
