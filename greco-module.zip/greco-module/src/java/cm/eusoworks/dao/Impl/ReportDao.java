/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IReportDao;
import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueEngagementBordereau;
import cm.eusoworks.entities.view.VueLiquidationReport;
import cm.eusoworks.entities.view.VueMandatementReport;
import cm.eusoworks.entities.view.VueMissionFiche;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.entities.view.VuePTAOperation;
import cm.eusoworks.entities.view.VuePTAParagraphe;
import cm.eusoworks.entities.view.VuePTAStructureParagraphe;
import cm.eusoworks.entities.view.VuePTATache;
import cm.eusoworks.entities.view.VuePTATacheParagraphe;
import cm.eusoworks.entities.view.VuePaieBulletin;
import cm.eusoworks.entities.view.VuePaieRecapRubrique;
import cm.eusoworks.entities.view.VuePaieRubrique;
import cm.eusoworks.entities.view.VueStructureCodification;
import cm.eusoworks.entities.view.VueSuiviFicheControle;
import cm.eusoworks.entities.view.VueSuiviFicheControleDetails;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ReportDao implements IReportDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public List<VuePTAOperation> getPTAOperation(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_PTA( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<VuePTAOperation> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VuePTAOperation o = new VuePTAOperation();
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));
                o.setOpLibelle(rs.getString("opLibelle"));
                o.setIndicateurFr(rs.getString("indicateurFr"));
                o.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                o.setStructure(rs.getString("structure"));
                o.setFinancement(rs.getString("financement"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCp(rs.getBigDecimal("cp"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));
                o.setJan(rs.getString("jan"));
                o.setFeb(rs.getString("feb"));
                o.setMar(rs.getString("mar"));
                o.setApr(rs.getString("apr"));
                o.setMay(rs.getString("may"));
                o.setJun(rs.getString("jun"));
                o.setJul(rs.getString("jul"));
                o.setAug(rs.getString("aug"));
                o.setSep(rs.getString("sep"));
                o.setOct(rs.getString("oct"));
                o.setNov(rs.getString("nov"));
                o.setDeb(rs.getString("deb"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePTATache> getPTATache(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_PTATache( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<VuePTATache> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VuePTATache o = new VuePTATache();
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));

                o.setAeBF(rs.getBigDecimal("aeBF"));
                o.setCpBF(rs.getBigDecimal("cpBF"));
                o.setAeBIP(rs.getBigDecimal("aeBIP"));
                o.setCpBIP(rs.getBigDecimal("cpBIP"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePTATacheParagraphe> getPTATacheParagraphe(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_PTATacheParagraphe( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<VuePTATacheParagraphe> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VuePTATacheParagraphe o = new VuePTATacheParagraphe();
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setChapCode(rs.getString("chapCode"));
                o.setChapLibelle(rs.getString("chapLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCp(rs.getBigDecimal("cp"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePTAParagraphe> getPTAParagraphe(String organisationID, String millesime) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_PTAParagraphe( ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            List<VuePTAParagraphe> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VuePTAParagraphe o = new VuePTAParagraphe();
                o.setSfAbbreviation(rs.getString("sfAbbreviation"));
                o.setSfLibelle(rs.getString("sfLibelle"));
                o.setArtCode(rs.getString("artCode"));
                o.setArtLibelle(rs.getString("artLibelle"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setChapCode(rs.getString("chapCode"));
                o.setChapLibelle(rs.getString("chapLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCp(rs.getBigDecimal("cp"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueBCAReport> getBcaLignesReport(String bcaID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAReport = con.prepareCall("CALL psReport_BCA( ?)");

            if (bcaID == null) {
                stmtpsBCAReport.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAReport.setString(1, bcaID);
            }

            List<VueBCAReport> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAReport.executeQuery();
            while (rs.next()) {
                VueBCAReport e = new VueBCAReport();

                e.setBcaId(rs.getString("bcaId"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));

                e.setDelaiDeLivraison(rs.getDate("delaiDeLivraison"));

                e.setDateDeSignature(rs.getDate("dateDeSignature"));

                e.setLieuDeSignature(rs.getString("lieuDeSignature"));

                e.setEntete1(rs.getString("entete1"));

                e.setEntete2(rs.getString("entete2"));

                e.setEntete3(rs.getString("entete3"));

                e.setEntete4(rs.getString("entete4"));

                e.setEntete5(rs.getString("entete5"));

                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantHT(rs.getBigDecimal("montantHT"));

                e.setMontantTVA(rs.getBigDecimal("montantTVA"));

                e.setMontantIR(rs.getBigDecimal("montantIR"));

                e.setTauxTVA(rs.getFloat("tauxTVA"));

                e.setTauxIR(rs.getFloat("tauxIR"));

                e.setNAP(rs.getBigDecimal("NAP"));

                e.setContribuableId(rs.getString("contribuableId"));

                e.setMatriculeOrdonnateur(rs.getString("matriculeOrdonnateur"));

                e.setPaExecutionId(rs.getString("paExecutionId"));

                e.setExMillesime(rs.getString("exMillesime"));

                e.setNumImputation(rs.getString("numImputation"));

                e.setBcaLigneId(rs.getString("bcaLigneId"));

                e.setPrixUnitaireLigne(rs.getBigDecimal("prixUnitaireLigne"));

                e.setQuantiteLigne(rs.getInt("quantiteLigne"));

                e.setMontantHTLigne(rs.getBigDecimal("montantHTLigne"));

                e.setTauxTVALigne(rs.getLong("tauxTVALigne"));

                e.setTauxIRLigne(rs.getLong("tauxIRLigne"));

                e.setNumOrdre(rs.getString("numOrdre"));

                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setExLibelleAnglais(rs.getString("exLibelleAnglais"));

                e.setChCode(rs.getString("chCode"));

                e.setChAbreviation(rs.getString("chAbreviation"));

                e.setChLibelleFrancais(rs.getString("chLibelleFrancais"));

                e.setChLibelleAnglais(rs.getString("chLibelleAnglais"));

                e.setAgNom(rs.getString("agNom"));

                e.setAgPrenom(rs.getString("agPrenom"));

                e.setAgNomJeuneFille(rs.getString("agNomJeuneFille"));

                e.setNumContribuable(rs.getString("numContribuable"));

                e.setRaisonSociale(rs.getString("raisonSociale"));

                e.setAdresse(rs.getString("adresse"));

                e.setBoitePostale(rs.getString("boitePostale"));

                e.setTelephone(rs.getString("telephone"));

                e.setAmId(rs.getString("amId"));

                e.setRefArticle(rs.getString("refArticle"));

                e.setDesignation(rs.getString("designation"));

                e.setSfCodeSrcFin(rs.getString("sfCodeSrcFin"));

                e.setRegistreCommerce(rs.getString("registreCommerce"));

                e.setPgCode(rs.getString("pgCode"));
                e.setPgLibelle(rs.getString("pgLibelle"));
                e.setAcCode(rs.getString("acCode"));
                e.setAcLibelle(rs.getString("acLibelle"));

                try {
                    e.setProjetCode(rs.getString("projetCode"));
                } catch (Exception ec) {
                    ec.printStackTrace();
                }
                try {
                    e.setProjetLibelle(rs.getString("projetLibelle"));
                } catch (Exception ev) {
                    ev.printStackTrace();
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public VueOMReport getOM(String omID) {
        Connection con = null;
        VueOMReport e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionSL = con.prepareCall("CALL psReport_OM( ?)");
            if (omID == null) {
                stmtpsordremissionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionSL.setString(1, omID);
            }

            ResultSet rs = stmtpsordremissionSL.executeQuery();
            while (rs.next()) {
                e = new VueOMReport();

                e.setOrdreDeMission(rs.getString("ordreDeMission"));

                e.setMatriculeAgent(rs.getString("matriculeAgent"));

                e.setSituationMatAgent(rs.getString("situationMatAgent"));
                if (rs.wasNull()) {
                    e.setSituationMatAgent(null);
                }
                e.setDestinationMission(rs.getString("destinationMission"));

                e.setPassantParMission(rs.getString("passantParMission"));
                if (rs.wasNull()) {
                    e.setPassantParMission(null);
                }
                e.setMotifEtReferenceMission(rs.getString("motifEtReferenceMission"));
                if (rs.wasNull()) {
                    e.setMotifEtReferenceMission(null);
                }
                e.setMoyenDeTransportMission(rs.getString("moyenDeTransportMission"));
                if (rs.wasNull()) {
                    e.setMoyenDeTransportMission(null);
                }
                e.setAccompagnantMission(rs.getString("accompagnantMission"));
                if (rs.wasNull()) {
                    e.setAccompagnantMission(null);
                }
                e.setDateDepartMission(rs.getDate("dateDepartMission"));

                e.setDateRetourMission(rs.getDate("dateRetourMission"));

                e.setExMillesime(rs.getString("exMillesime"));

                e.setExLibelleFrancais(rs.getString("exLibelleFrancais"));

                e.setChLibelleAnglais(rs.getString("chLibelleAnglais"));

                e.setChLibelleFrancais(rs.getString("chLibelleFrancais"));

                e.setNomAgent(rs.getString("nomAgent"));

                e.setPrenomAgent(rs.getString("prenomAgent"));

                e.setNomJeuneFilleAgent(rs.getString("nomJeuneFilleAgent"));

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueLiquidationReport> getLiquidation(String liquidationID) {
        Connection con = null;
        VueLiquidationReport e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionSL = con.prepareCall("CALL psReport_Liquidation( ?)");
            if (liquidationID == null) {
                stmtpsordremissionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionSL.setString(1, liquidationID);
            }
            List<VueLiquidationReport> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionSL.executeQuery();
            while (rs.next()) {
                e = new VueLiquidationReport();

                e.setOrganisationFR(rs.getString("organisationFR"));

                e.setOrganisationUS(rs.getString("organisationUS"));

                e.setExerciceLibelleFr(rs.getString("exerciceLibelleFr"));

                e.setChapitre(rs.getString("chapitre"));

                e.setDotationBudgetaire(rs.getBigDecimal("dotationBudgetaire"));
                if (rs.wasNull()) {
                    e.setDotationBudgetaire(null);
                }
                e.setTotalEngag(rs.getBigDecimal("totalEngag"));
                if (rs.wasNull()) {
                    e.setTotalEngag(null);
                }
                e.setDisponible(rs.getBigDecimal("disponible"));
                if (rs.wasNull()) {
                    e.setDisponible(null);
                }
                e.setDepenseCourante(rs.getBigDecimal("depenseCourante"));
                if (rs.wasNull()) {
                    e.setDepenseCourante(null);
                }
                e.setSolde(rs.getBigDecimal("solde"));

                e.setSourceFinancement(rs.getString("sourceFinancement"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setNomOrdo(rs.getString("nomOrdo"));

                e.setMoisEmission(rs.getString("moisEmission"));

                e.setExerciceOrigine(rs.getString("exerciceOrigine"));

                e.setNumBordereauEmission(rs.getString("numBordereauEmission"));

                e.setNumMandat(rs.getString("numMandat"));

                e.setObjet(rs.getString("objet"));

                e.setBeneficiare(rs.getString("beneficiare"));

                e.setPrecompte(rs.getBigDecimal("montantOrdonnance"));

                e.setPrecompte(rs.getBigDecimal("precompte"));

                e.setNetApayer(rs.getBigDecimal("netApayer"));

                e.setPiecesJustificatives(rs.getString("piecesJustificatives"));
                e.setBanque(rs.getString("banque"));

                e.setAgence(rs.getString("agence"));

                e.setNumCompte(rs.getString("numCompte"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePTAStructureParagraphe> getPTAStructureParagraphe(String millesime, String organisationID, String articleID, String compteCode) {
        List<VuePTAStructureParagraphe> list = new ArrayList<>();
        try (Connection con = dataSource.getConnection()) {
            CallableStatement stmt = con.prepareCall("CALL psReport_PTAMoyen(?, ?, ?, ?)");
            stmt.setString(1, millesime);
            stmt.setString(2, organisationID);
            stmt.setString(3, articleID);
            stmt.setString(4, compteCode);

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePTAStructureParagraphe e = new VuePTAStructureParagraphe();
                e.setExMillesime(rs.getString("exMillesime"));
                e.setExLibelle(rs.getString("exLibelle"));
                e.setAnnee(rs.getInt("annee"));
                if (rs.wasNull()) {
                    e.setAnnee(null);
                }
                e.setChCodeChapitre(rs.getString("chCodeChapitre"));
                e.setChAbreviation(rs.getString("chAbreviation"));
                e.setChLibelle(rs.getString("chLibelle"));
                e.setFsCode(rs.getString("fsCode"));
                if (rs.wasNull()) {
                    e.setFsCode(null);
                }
                e.setFsAbreviation(rs.getString("fsAbreviation"));
                if (rs.wasNull()) {
                    e.setFsAbreviation(null);
                }
                e.setFsLibelle(rs.getString("fsLibelle"));
                if (rs.wasNull()) {
                    e.setFsLibelle(null);
                }
                e.setCaCode(rs.getString("caCode"));
                if (rs.wasNull()) {
                    e.setCaCode(null);
                }
                e.setCaAbreviation(rs.getString("caAbreviation"));
                if (rs.wasNull()) {
                    e.setCaAbreviation(null);
                }
                e.setCaLibelle(rs.getString("caLibelle"));
                if (rs.wasNull()) {
                    e.setCaLibelle(null);
                }
                e.setArCodeArticle(rs.getString("arCodeArticle"));
                if (rs.wasNull()) {
                    e.setArCodeArticle(null);
                }
                e.setReCode(rs.getString("reCode"));
                if (rs.wasNull()) {
                    e.setReCode(null);
                }
                e.setArNumOrdre(rs.getString("arNumOrdre"));
                if (rs.wasNull()) {
                    e.setArNumOrdre(null);
                }
                e.setArAbreviation(rs.getString("arAbreviation"));
                if (rs.wasNull()) {
                    e.setArAbreviation(null);
                }
                e.setArLibelle(rs.getString("arLibelle"));
                if (rs.wasNull()) {
                    e.setArLibelle(null);
                }
                e.setTypeDepense(rs.getString("typeDepense"));

                e.setLibelleDepense(rs.getString("libelleDepense"));

                e.setNeCodeNatureEco(rs.getString("neCodeNatureEco"));
                if (rs.wasNull()) {
                    e.setNeCodeNatureEco(null);
                }
                e.setNeLibelle(rs.getString("neLibelle"));
                if (rs.wasNull()) {
                    e.setNeLibelle(null);
                }
                e.setGeCode(rs.getString("geCode"));
                if (rs.wasNull()) {
                    e.setGeCode(null);
                }
                e.setGeLibelle(rs.getString("geLibelle"));
                if (rs.wasNull()) {
                    e.setGeLibelle(null);
                }
                e.setCoCode(rs.getString("coCode"));
                if (rs.wasNull()) {
                    e.setCoCode(null);
                }
                e.setCoLibelle(rs.getString("coLibelle"));
                if (rs.wasNull()) {
                    e.setCoLibelle(null);
                }
                e.setAE(rs.getBigDecimal("AE"));
                if (rs.wasNull()) {
                    e.setAE(null);
                }
                e.setCP(rs.getBigDecimal("CP"));
                if (rs.wasNull()) {
                    e.setCP(null);
                }
                e.setImputation(rs.getString("imputation"));
                if (rs.wasNull()) {
                    e.setImputation(null);
                }
                e.setDotationBase(rs.getBigDecimal("dotationBase"));
                if (rs.wasNull()) {
                    e.setDotationBase(null);
                }

                list.add(e);
            }
            return list;
        } catch (Exception e) {
            System.out.println(e);
            return null;
        }
    }

    @Override
    public List<VueEngagementBordereau> getBordereauTransmission(String numBordereau) {
        Connection con = null;
        VueEngagementBordereau e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionSL = con.prepareCall("CALL psBordereau_Contents( ?)");
            if (numBordereau == null) {
                stmtpsordremissionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionSL.setString(1, numBordereau);
            }
            List<VueEngagementBordereau> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionSL.executeQuery();
            while (rs.next()) {
                e = new VueEngagementBordereau();
                e.setAgent(rs.getString("agent"));
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setDestination(rs.getString("destination"));
                e.setExercice(rs.getString("exercice"));
                e.setMillesime(rs.getString("millesime"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setNumBordereau(rs.getString("numBordereau"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                e.setSource(rs.getString("source"));
                try {
                    e.setNumeroOP(rs.getString("numeroOP"));
                } catch (Exception ec) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueStructureCodification> getStructureCodification(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_StructureCodification( ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }

            List<VueStructureCodification> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueStructureCodification o = new VueStructureCodification();
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                o.setLibelleFr(rs.getString("libelleFr"));
                o.setLibelleGroupe(rs.getString("libelleGroupe"));
                o.setNiveauOrganiqueID(rs.getInt("niveauOrganiqueID"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueMandatementReport> getMandatementReport(String mandatementID) throws SQLException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatementReport( ?)");

            if (mandatementID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, mandatementID);
            }

            List<VueMandatementReport> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueMandatementReport e = new VueMandatementReport();

                e.setOrganisationFR(rs.getString("organisationFR"));
                if (rs.wasNull()) {
                    e.setOrganisationFR(null);
                }
                e.setOrganisationUS(rs.getString("organisationUS"));
                if (rs.wasNull()) {
                    e.setOrganisationUS(null);
                }
                e.setExerciceLibelleFr(rs.getString("exerciceLibelleFr"));
                if (rs.wasNull()) {
                    e.setExerciceLibelleFr(null);
                }
                e.setChapitre(rs.getString("chapitre"));
                if (rs.wasNull()) {
                    e.setChapitre(null);
                }
                e.setDotationBudgetaire(rs.getInt("dotationBudgetaire"));
                if (rs.wasNull()) {
                    e.setDotationBudgetaire(null);
                }
                e.setTotalEngag(rs.getInt("totalEngag"));
                if (rs.wasNull()) {
                    e.setTotalEngag(null);
                }
                e.setDisponible(rs.getInt("disponible"));
                if (rs.wasNull()) {
                    e.setDisponible(null);
                }
                e.setDepenseCourante(rs.getInt("depenseCourante"));
                if (rs.wasNull()) {
                    e.setDepenseCourante(null);
                }
                e.setSolde(rs.getInt("solde"));
                if (rs.wasNull()) {
                    e.setSolde(null);
                }
                e.setSourceFinancement(rs.getString("sourceFinancement"));
                if (rs.wasNull()) {
                    e.setSourceFinancement(null);
                }
                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));
                if (rs.wasNull()) {
                    e.setMatriculeOrdo(null);
                }
                e.setNomOrdo(rs.getString("nomOrdo"));
                if (rs.wasNull()) {
                    e.setNomOrdo(null);
                }
                e.setMoisEmission(rs.getString("moisEmission"));
                if (rs.wasNull()) {
                    e.setMoisEmission(null);
                }
                e.setExerciceOrigine(rs.getString("exerciceOrigine"));
                if (rs.wasNull()) {
                    e.setExerciceOrigine(null);
                }
                e.setNumBordereauEmission(rs.getString("numBordereauEmission"));
                if (rs.wasNull()) {
                    e.setNumBordereauEmission(null);
                }
                e.setNumMandat(rs.getString("numMandat"));
                if (rs.wasNull()) {
                    e.setNumMandat(null);
                }
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setBeneficiare(rs.getString("beneficiare"));
                if (rs.wasNull()) {
                    e.setBeneficiare(null);
                }
                e.setMontantOrdonnance(rs.getInt("montantOrdonnance"));
                if (rs.wasNull()) {
                    e.setMontantOrdonnance(null);
                }
                e.setPrecompte(rs.getInt("precompte"));
                if (rs.wasNull()) {
                    e.setPrecompte(null);
                }
                e.setNetApayer(rs.getInt("netApayer"));
                if (rs.wasNull()) {
                    e.setNetApayer(null);
                }
                e.setPiecesJustificatives(rs.getString("piecesJustificatives"));
                if (rs.wasNull()) {
                    e.setPiecesJustificatives(null);
                }
                e.setBanque(rs.getString("banque"));
                if (rs.wasNull()) {
                    e.setBanque(null);
                }
                e.setAgence(rs.getString("agence"));
                if (rs.wasNull()) {
                    e.setAgence(null);
                }
                e.setNumCompte(rs.getString("numCompte"));
                if (rs.wasNull()) {
                    e.setNumCompte(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public VuePaieBulletin getPaieBulletin(String employeID, String millesime, Date datedebut, Date dateFin) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psPaie_Bulletin(  ?, ?, ?, ?)");

            if (employeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, employeID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (datedebut == null) {
                stmt.setNull(3, java.sql.Types.DATE);
            } else {
                stmt.setDate(3, new java.sql.Date(datedebut.getTime()));
            }
            if (dateFin == null) {
                stmt.setNull(4, java.sql.Types.DATE);
            } else {
                stmt.setDate(4, new java.sql.Date(dateFin.getTime()));
            }

            VuePaieBulletin e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new VuePaieBulletin();

                e.setAdresseEmp(rs.getString("adresseEmp"));
                e.setAdresseOrg(rs.getString("adresseOrg"));
                e.setBoitePostaleEmp(rs.getString("boitePostaleEmp"));
                e.setBoitePostaleOrg(rs.getString("boitePostaleOrg"));
                e.setCoeffEmp(rs.getFloat("coeffEmp"));
                e.setEmploiEmp(rs.getString("emploiEmp"));
                e.setMatriculeEmp(rs.getString("matriculeEmp"));
                e.setNetAPayer(rs.getBigDecimal("netAPayer"));
                e.setNomEmp(rs.getString("nomEmp"));
                e.setNumContribuableOrg(rs.getString("numContribuableOrg"));
                e.setNumSSEmp(rs.getString("numSSEmp"));
                e.setNumSSOrg(rs.getString("numSSOrg"));
                e.setPeriodDebut(rs.getDate("periodDebut"));
                e.setPeriodeFin(rs.getDate("periodeFin"));
                e.setPrenomEmp(rs.getString("prenomEmp"));
                e.setQualificationEmp(rs.getString("qualificationEmp"));
                e.setTotalBrut(rs.getBigDecimal("totalBrut"));
                e.setTotalRetenuePatronnales(rs.getBigDecimal("totalRetenuePatronnales"));
                e.setTotalRetenues(rs.getBigDecimal("totalRetenues"));

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePaieRubrique> getPaieRubriquesBase(String employeID, String millesime, Date datedebut, Date dateFin) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psPaie_Base(  ?, ?, ?, ?)");

            if (employeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, employeID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (datedebut == null) {
                stmt.setNull(3, java.sql.Types.DATE);
            } else {
                stmt.setDate(3, new java.sql.Date(datedebut.getTime()));
            }
            if (dateFin == null) {
                stmt.setNull(4, java.sql.Types.DATE);
            } else {
                stmt.setDate(4, new java.sql.Date(dateFin.getTime()));
            }

            List<VuePaieRubrique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePaieRubrique e = new VuePaieRubrique();

                e.setRubrique(rs.getString("rubrique"));
                e.setBase(rs.getDouble("base"));
                e.setTaux(rs.getFloat("taux"));
                e.setAdeduire(rs.getBigDecimal("adeduire"));
                e.setApayer(rs.getBigDecimal("apayer"));
                e.setTauxPatronal(rs.getFloat("tauxpatronal"));
                e.setChargePatronale(rs.getBigDecimal("chargePatronale"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePaieRubrique> getPaieRubriquesRetenues(String employeID, String millesime, Date datedebut, Date dateFin) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psPaie_Retenue( ?, ?, ?, ?)");

            if (employeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, employeID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (datedebut == null) {
                stmt.setNull(3, java.sql.Types.DATE);
            } else {
                stmt.setDate(3, new java.sql.Date(datedebut.getTime()));
            }
            if (dateFin == null) {
                stmt.setNull(4, java.sql.Types.DATE);
            } else {
                stmt.setDate(4, new java.sql.Date(dateFin.getTime()));
            }

            List<VuePaieRubrique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePaieRubrique e = new VuePaieRubrique();

                e.setRubrique(rs.getString("rubrique"));
                e.setBase(rs.getDouble("base"));
                e.setTaux(rs.getFloat("taux"));
                e.setAdeduire(rs.getBigDecimal("adeduire"));
                e.setApayer(rs.getBigDecimal("apayer"));
                e.setTauxPatronal(rs.getFloat("tauxpatronal"));
                e.setChargePatronale(rs.getBigDecimal("chargePatronale"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePaieRubrique> getPaieRubriquesNet(String employeID, String millesime, Date datedebut, Date dateFin) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psPaie_Net( ?, ?, ?, ?)");

            if (employeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, employeID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (datedebut == null) {
                stmt.setNull(3, java.sql.Types.DATE);
            } else {
                stmt.setDate(3, new java.sql.Date(datedebut.getTime()));
            }
            if (dateFin == null) {
                stmt.setNull(4, java.sql.Types.DATE);
            } else {
                stmt.setDate(4, new java.sql.Date(dateFin.getTime()));
            }

            List<VuePaieRubrique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePaieRubrique e = new VuePaieRubrique();

                e.setRubrique(rs.getString("rubrique"));
                e.setBase(rs.getDouble("base"));
                e.setTaux(rs.getFloat("taux"));
                e.setAdeduire(rs.getBigDecimal("adeduire"));
                e.setApayer(rs.getBigDecimal("apayer"));
                e.setTauxPatronal(rs.getFloat("tauxpatronal"));
                e.setChargePatronale(rs.getBigDecimal("chargePatronale"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VuePaieRecapRubrique> getPaieRecapCotisations(Date dateDebut, Date dateFin) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psPaie_RecapCotisation( ?, ?)");

            if (dateDebut == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(dateDebut.getTime()));
            }
            if (dateFin == null) {
                stmt.setNull(2, java.sql.Types.DATE);
            } else {
                stmt.setDate(2, new java.sql.Date(dateFin.getTime()));
            }

            List<VuePaieRecapRubrique> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VuePaieRecapRubrique e = new VuePaieRecapRubrique();

                e.setLibelle(rs.getString("libelle"));
                e.setMontant(rs.getBigDecimal("montant"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueSuiviFicheControle> getSuiviFicheControleAE(String millesime, String organisationID, String activiteID, String tacheID, int base) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_BudgetFicheControleAE( ?, ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (activiteID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, activiteID);
            }
            if (tacheID == null) {
                stmtpsactiviteS.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(4, tacheID);
            }
            stmtpsactiviteS.setInt(5, base);

            List<VueSuiviFicheControle> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueSuiviFicheControle o = new VueSuiviFicheControle();

                o.setActiviteID(rs.getString("activiteID"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setAerevisee(rs.getBigDecimal("aerevisee"));
                o.setAtCode(rs.getString("atCode"));
                o.setAtLibelle(rs.getString("atLibelle"));
                o.setCompte(rs.getString("compte"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setDisponible(rs.getBigDecimal("disponible"));
                o.setEngagements(rs.getBigDecimal("engagements"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setExMillesime(rs.getString("exMillesime"));
                o.setOrgCode(rs.getString("orgCode"));
                o.setOrgLibelle(rs.getString("orgLibelle"));
                o.setTaux(rs.getDouble("taux"));
                o.setTypeBudget(rs.getString("typeBudget"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueSuiviFicheControleDetails> getSuiviFicheControleAEDetails(String tacheID, int base) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_BudgetFicheControleAEDetails( ?, ?)");

            if (tacheID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, tacheID);
            }

            stmtpsactiviteS.setInt(2, base);

            List<VueSuiviFicheControleDetails> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueSuiviFicheControleDetails o = new VueSuiviFicheControleDetails();

                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setBeneficiaire(rs.getString("beneficiaire"));
                o.setDateValidation(rs.getDate("dateValidation"));
                o.setEtat(rs.getInt("etat"));
                o.setMontantTTC(rs.getBigDecimal("montantTTC"));
                o.setNumDossier(rs.getString("numDossier"));
                o.setObjet(rs.getString("objet"));
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setStatut(rs.getString("statut"));
                o.setTypeProcedure(rs.getString("typeProcedure"));
                try {
                    o.setExMillesime(rs.getString("exMillesime"));
                } catch (Exception e) {
                }

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueSuiviFicheControleDetails> getSuiviFicheConsolideeAEDetails(String millesime, String organisationID, String budgetID, String structureID, String programmeID,
            String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_BudgetFicheControleAE_Activite( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(4, structureID);
            }
            if (programmeID == null) {
                stmtpsactiviteS.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(5, programmeID);
            }
            if (actionID == null) {
                stmtpsactiviteS.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(6, actionID);
            }
            if (activiteID == null) {
                stmtpsactiviteS.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(7, activiteID);
            }
            if (tacheID == null) {
                stmtpsactiviteS.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(8, tacheID);
            }
            if (beneficiaire == null) {
                stmtpsactiviteS.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(9, beneficiaire);
            }

            stmtpsactiviteS.setInt(10, base);

            List<VueSuiviFicheControleDetails> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueSuiviFicheControleDetails o = new VueSuiviFicheControleDetails();

                o.setActiviteID(rs.getString("activiteID"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setAe(rs.getBigDecimal("cp"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));
                o.setBudgetExploite(rs.getString("budgetExploite"));
                o.setTacheID(rs.getString("tacheID"));
                o.setBeneficiaire(rs.getString("beneficiaire"));
                o.setDateValidation(rs.getDate("dateValidation"));
                o.setEtat(rs.getInt("etat"));
                o.setMontantTTC(rs.getBigDecimal("montantTTC"));
                o.setNumDossier(rs.getString("numDossier"));
                o.setObjet(rs.getString("objet"));
                o.setStatut(rs.getString("statut"));
                o.setTypeProcedure(rs.getString("typeProcedure"));
                o.setExMillesime(rs.getString("exMillesime"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueSuiviFicheControleDetails> getSuiviBudgetConsolideAE(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        // 

        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_BudgetConsolideAE_Activite( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(4, structureID);
            }
            if (programmeID == null) {
                stmtpsactiviteS.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(5, programmeID);
            }
            if (actionID == null) {
                stmtpsactiviteS.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(6, actionID);
            }
            if (activiteID == null) {
                stmtpsactiviteS.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(7, activiteID);
            }
            if (tacheID == null) {
                stmtpsactiviteS.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(8, tacheID);
            }
            if (beneficiaire == null) {
                stmtpsactiviteS.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(9, beneficiaire);
            }

            stmtpsactiviteS.setInt(10, base);

            List<VueSuiviFicheControleDetails> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueSuiviFicheControleDetails o = new VueSuiviFicheControleDetails();

                o.setActiviteID(rs.getString("activiteID"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setAe(rs.getBigDecimal("cp"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));
                o.setBudgetExploite(rs.getString("budgetExploite"));
                o.setTacheID(rs.getString("tacheID"));
                // o.setBeneficiaire(rs.getString("beneficiaire"));
                // o.setDateValidation(rs.getDate("dateValidation"));
                // o.setEtat(rs.getInt("etat"));
                // o.setMontantTTC(rs.getBigDecimal("montantTTC"));
                // o.setNumDossier(rs.getString("numDossier"));
                // o.setObjet(rs.getString("objet"));
                // o.setStatut(rs.getString("statut"));
                //  o.setTypeProcedure(rs.getString("typeProcedure"));
                o.setExMillesime(rs.getString("exMillesime"));
                o.setDisponible(rs.getBigDecimal("disponible"));
                o.setEngagements(rs.getBigDecimal("engagements"));
                o.setTaux(rs.getDouble("taux"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueMissionFiche> getMissionFiche(String organisationID, String millesime, String matricule) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_MissionFiche( ?, ?, ?)");

            if (organisationID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, millesime);
            }
            if (matricule == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, matricule);
            }

            List<VueMissionFiche> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueMissionFiche o = new VueMissionFiche();
                o.setCode(rs.getString("code"));
                o.setLibelleFr(rs.getString("libelleFr"));
                o.setMatricule(rs.getString("matricule"));
                o.setBeneficiaire(rs.getString("beneficiaire"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setImputation(rs.getString("imputation"));
                o.setDestination(rs.getString("destination"));
                o.setNumDossier(rs.getString("numDossier"));
                o.setStatus(rs.getString("status"));
                o.setOrgLibelle(rs.getString("orgLibelle"));
                o.setOrgCode(rs.getString("orgCode"));
                o.setExMillesime(rs.getString("exMillesime"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setBudget(rs.getString("budget"));
                o.setDateDepart(rs.getDate("dateDepart"));
                o.setDateRetour(rs.getDate("dateRetour"));
                o.setTypeMission(rs.getInt("typeMission"));
                o.setEtat(rs.getInt("etat"));
                o.setNbJours(rs.getInt("nbJours"));
                o.setMontantGlobal(rs.getBigDecimal("montantGlobal"));

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueSuiviFicheControleDetails> getFileFicheConsolideeDetails(String millesime, String organisationID, String budgetID, String structureID, String programmeID,
            String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_FileFicheControle_Activite( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(4, structureID);
            }
            if (programmeID == null) {
                stmtpsactiviteS.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(5, programmeID);
            }
            if (actionID == null) {
                stmtpsactiviteS.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(6, actionID);
            }
            if (activiteID == null) {
                stmtpsactiviteS.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(7, activiteID);
            }
            if (tacheID == null) {
                stmtpsactiviteS.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(8, tacheID);
            }
            if (beneficiaire == null) {
                stmtpsactiviteS.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(9, beneficiaire);
            }

            stmtpsactiviteS.setInt(10, base);

            List<VueSuiviFicheControleDetails> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueSuiviFicheControleDetails o = new VueSuiviFicheControleDetails();

                o.setActiviteID(rs.getString("activiteID"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setAe(rs.getBigDecimal("cp"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));
                o.setBudgetExploite(rs.getString("budgetExploite"));
                o.setTacheID(rs.getString("tacheID"));
                o.setBeneficiaire(rs.getString("beneficiaire"));
                o.setDateValidation(rs.getDate("dateEntree"));
                o.setEtat(rs.getInt("etat"));
                o.setMontantTTC(rs.getBigDecimal("montantTTC"));
                o.setNumDossier(rs.getString("numOrdre"));
                o.setObjet(rs.getString("objet"));
                o.setStatut(rs.getString("statut"));
                o.setTypeProcedure(rs.getString("typeProcedure"));
                o.setExMillesime(rs.getString("exMillesime"));
                try {
                    o.setFile(rs.getBigDecimal("file"));
                } catch (Exception e) {
                }
                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueSuiviFicheControleDetails> getFileBudgetConsolide(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        // 

        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psReport_FileConsolide_Activite( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, organisationID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(4, structureID);
            }
            if (programmeID == null) {
                stmtpsactiviteS.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(5, programmeID);
            }
            if (actionID == null) {
                stmtpsactiviteS.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(6, actionID);
            }
            if (activiteID == null) {
                stmtpsactiviteS.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(7, activiteID);
            }
            if (tacheID == null) {
                stmtpsactiviteS.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(8, tacheID);
            }
            if (beneficiaire == null) {
                stmtpsactiviteS.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(9, beneficiaire);
            }

            stmtpsactiviteS.setInt(10, base);

            List<VueSuiviFicheControleDetails> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueSuiviFicheControleDetails o = new VueSuiviFicheControleDetails();

                o.setActiviteID(rs.getString("activiteID"));
                o.setExLibelle(rs.getString("exLibelle"));
                o.setAe(rs.getBigDecimal("ae"));
                o.setCompteLibelle(rs.getString("compteLibelle"));
                o.setPgCode(rs.getString("pgCode"));
                o.setPgLibelle(rs.getString("pgLibelle"));
                o.setAcCode(rs.getString("acCode"));
                o.setAcLibelle(rs.getString("acLibelle"));
                o.setTaCode(rs.getString("taCode"));
                o.setTaLibelle(rs.getString("taLibelle"));
                o.setCompteCode(rs.getString("compteCode"));
                o.setAe(rs.getBigDecimal("cp"));
                o.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                o.setOrgLibelleUs(rs.getString("orgLibelleUs"));
                o.setBudgetExploite(rs.getString("budgetExploite"));
                o.setTacheID(rs.getString("tacheID"));
                // o.setBeneficiaire(rs.getString("beneficiaire"));
                // o.setDateValidation(rs.getDate("dateValidation"));
                // o.setEtat(rs.getInt("etat"));
                // o.setMontantTTC(rs.getBigDecimal("montantTTC"));
                // o.setNumDossier(rs.getString("numDossier"));
                // o.setObjet(rs.getString("objet"));
                // o.setStatut(rs.getString("statut"));
                //  o.setTypeProcedure(rs.getString("typeProcedure"));
                o.setExMillesime(rs.getString("exMillesime"));
                o.setDisponible(rs.getBigDecimal("disponible"));
                o.setEngagements(rs.getBigDecimal("engagements"));
                o.setTaux(rs.getDouble("taux"));
                try {
                    o.setFile(rs.getBigDecimal("file"));
                } catch (Exception e) {
                }

                list.add(o);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
