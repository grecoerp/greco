/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IAgentDao;
import cm.eusoworks.entities.cls.CleValeur;
import cm.eusoworks.entities.model.Agent;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class AgentDao implements IAgentDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public Agent getAgent(String agMatricule) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAgent_Find(?)");
            
            stmt.setString(1, agMatricule);

            Agent o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Agent();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    o.setMatricule(null);
                }
                o.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    o.setNom(null);
                }
                o.setNomJeuneFille(rs.getString("nomJeuneFille"));
                if (rs.wasNull()) {
                    o.setNomJeuneFille(null);
                }
                o.setPrenom(rs.getString("prenom"));
                if (rs.wasNull()) {
                    o.setPrenom(null);
                }
                o.setDateNaissance(rs.getDate("dateNaissance"));
                if (rs.wasNull()) {
                    o.setDateNaissance(null);
                }
                o.setNumCNI(rs.getString("numCNI"));
                if (rs.wasNull()) {
                    o.setNumCNI(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setMatriculeBudgetaire(rs.getBoolean("matriculeBudgetaire"));
                o.setActif(rs.getBoolean("actif"));
                
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Agent> getAgents(String prefix) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAgent_Search(?)");
            
            stmt.setString(1, prefix);

            List<Agent> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Agent o = new Agent();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    o.setMatricule(null);
                }
                o.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    o.setNom(null);
                }
                o.setNomJeuneFille(rs.getString("nomJeuneFille"));
                if (rs.wasNull()) {
                    o.setNomJeuneFille(null);
                }
                o.setPrenom(rs.getString("prenom"));
                if (rs.wasNull()) {
                    o.setPrenom(null);
                }
                o.setDateNaissance(rs.getDate("dateNaissance"));
                if (rs.wasNull()) {
                    o.setDateNaissance(null);
                }
                o.setNumCNI(rs.getString("numCNI"));
                if (rs.wasNull()) {
                    o.setNumCNI(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setMatriculeBudgetaire(rs.getBoolean("matriculeBudgetaire"));
                o.setActif(rs.getBoolean("actif"));
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String ajouterAgentBudgetaire( Agent ag) {
        String matBud = "";
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmttblAgentU = con.prepareCall("CALL psAgent_InsertBud( ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            stmttblAgentU.setNull(1, java.sql.Types.VARCHAR);

            if (ag.getMillesime() == null) {
                stmttblAgentU.setNull(2, java.sql.Types.CHAR);
            } else {
                stmttblAgentU.setString(2, ag.getMillesime());
            }
            if (ag.getOrganisationID() == null) {
                stmttblAgentU.setNull(3, java.sql.Types.CHAR);
            } else {
                stmttblAgentU.setString(3, ag.getOrganisationID());
            }
            if (ag.getNom() == null) {
                stmttblAgentU.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(4, ag.getNom());
            }
            if (ag.getPrenom() == null) {
                stmttblAgentU.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(5, ag.getPrenom());
            }

            if (ag.getDateNaissance() == null) {
                stmttblAgentU.setNull(6, java.sql.Types.DATE);
            } else {
                stmttblAgentU.setDate(6, new java.sql.Date(ag.getDateNaissance().getTime()));
            }

            if (ag.getNumCNI() == null) {
                stmttblAgentU.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(7, ag.getNumCNI());
            }

            if (ag.getUserUpdate() == null) {
                stmttblAgentU.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(8, ag.getUserUpdate());
            }

            if (ag.getIpUpdate() == null) {
                stmttblAgentU.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(9, ag.getIpUpdate());
            }

            stmttblAgentU.registerOutParameter(1, java.sql.Types.VARCHAR);
            stmttblAgentU.executeUpdate();

            matBud = stmttblAgentU.getString(1);

            return matBud;
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AgentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public void modifierAgentBudgetaire(Agent ag) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmttblAgentU = con.prepareCall("CALL psAgent_UpdateBud( ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (ag.getMatricule() == null) {
                stmttblAgentU.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(1, ag.getMatricule());
            }
            if (ag.getMillesime() == null) {
                stmttblAgentU.setNull(2, java.sql.Types.CHAR);
            } else {
                stmttblAgentU.setString(2, ag.getMillesime());
            }
            if (ag.getOrganisationID() == null) {
                stmttblAgentU.setNull(3, java.sql.Types.CHAR);
            } else {
                stmttblAgentU.setString(3, ag.getOrganisationID());
            }
            if (ag.getNom() == null) {
                stmttblAgentU.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(4, ag.getNom());
            }
            if (ag.getPrenom() == null) {
                stmttblAgentU.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(5, ag.getPrenom());
            }

            if (ag.getDateNaissance() == null) {
                stmttblAgentU.setNull(6, java.sql.Types.DATE);
            } else {
                stmttblAgentU.setDate(6, new java.sql.Date(ag.getDateNaissance().getTime()));
            }

            if (ag.getNumCNI() == null) {
                stmttblAgentU.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(7, ag.getNumCNI());
            }

            if (ag.getUserUpdate() == null) {
                stmttblAgentU.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(8, ag.getUserUpdate());
            }

            if (ag.getIpUpdate() == null) {
                stmttblAgentU.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentU.setString(9, ag.getIpUpdate());
            }

            stmttblAgentU.executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AgentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public List<CleValeur> importAgent(List<Agent> listAgent) {
        List<CleValeur> list = new ArrayList<>();

        int index = 0;
        for (Agent v : listAgent) {
            index++;
            try {
                importAgent(v.getMillesime(), v.getMatricule(), v.getNom(), v.getPrenom(), v.getNomJeuneFille(),
                        v.getDateNaissance(), v.getNumCNI(), v.getUserUpdate(), v.getIpUpdate(), v.getActif());
            } catch (Exception e) {
                list.add(new CleValeur(index, e.getMessage(), ""));
            }
        }
        return list;
    }

    @Override
    public void importAgent(String exMillesime, String matricule, String nom, String prenom, String nomJeuneFille, 
                                Date dateNaiss, String cni, String utLogin, String ipAdresse, boolean actif) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtAgentImport = con.prepareCall("CALL psAgent_Import( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (exMillesime == null) {
                stmtAgentImport.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtAgentImport.setString(1, exMillesime);
            }
            if (matricule == null) {
                stmtAgentImport.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(2, matricule);
            }
            if (nom == null) {
                stmtAgentImport.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(3, nom);
            }
            if (prenom == null) {
                stmtAgentImport.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(4, prenom);
            }
            if (nomJeuneFille == null) {
                stmtAgentImport.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(5, nomJeuneFille);
            }
            if (dateNaiss == null) {
                stmtAgentImport.setNull(6, java.sql.Types.DATE);
            } else {
                stmtAgentImport.setDate(6, new java.sql.Date(dateNaiss.getTime()));
            }
            if (cni == null) {
                stmtAgentImport.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(7, cni);
            }

            if (utLogin == null) {
                stmtAgentImport.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(8, utLogin);
            }
            if (ipAdresse == null) {
                stmtAgentImport.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtAgentImport.setString(9, ipAdresse);
            }
            stmtAgentImport.setBoolean(10, actif);

            stmtAgentImport.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AgentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }

    }

    @Override
    public void validerImportation() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            con.prepareCall("CALL psAgent_Import_Valider()").executeUpdate();
        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AgentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public void supprimerAgentBudgetaire(String agMatricule, String userMaj, String ipAdresse) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmttblAgentD = con.prepareCall("CALL psAgent_DeleteMatBud( ?, ?, ?)");
            if (agMatricule == null) {
                stmttblAgentD.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentD.setString(1, agMatricule);
            }
            if (userMaj == null) {
                stmttblAgentD.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentD.setString(2, userMaj);
            }
            if (ipAdresse == null) {
                stmttblAgentD.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmttblAgentD.setString(3, ipAdresse);
            }

            stmttblAgentD.executeUpdate();

        } catch (Exception e) {
            throw new RuntimeException(e.getMessage(), e);
        } finally {
            if (con != null) {
                try {
                    con.close();
                } catch (SQLException ex) {
                    Logger.getLogger(AgentDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }
    
    @Override
    public List<Agent> getAgentBudgetaire(String exMillesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psAgent_ListBudgetaire(?, ?)");
            
            stmt.setString(1, exMillesime);
            stmt.setString(2, organisationID);

            List<Agent> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Agent o = new Agent();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    o.setMillesime(null);
                }
                o.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    o.setMatricule(null);
                }
                o.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    o.setNom(null);
                }
                o.setNomJeuneFille(rs.getString("nomJeuneFille"));
                if (rs.wasNull()) {
                    o.setNomJeuneFille(null);
                }
                o.setPrenom(rs.getString("prenom"));
                if (rs.wasNull()) {
                    o.setPrenom(null);
                }
                o.setDateNaissance(rs.getDate("dateNaissance"));
                if (rs.wasNull()) {
                    o.setDateNaissance(null);
                }
                o.setNumCNI(rs.getString("numCNI"));
                if (rs.wasNull()) {
                    o.setNumCNI(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setMatriculeBudgetaire(rs.getBoolean("matriculeBudgetaire"));
                o.setActif(rs.getBoolean("actif"));
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
