/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IOrdreMissionDao;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.view.VueAgentOM;
import cm.eusoworks.entities.exception.GrecoException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class OrdreMissionDao implements IOrdreMissionDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public String ajouter(OrdreMission o) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionI = con.prepareCall("CALL psOrdreMission_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (o.getLastUpdate() == null) {
                stmtpsordremissionI.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsordremissionI.setDate(1, new java.sql.Date(o.getLastUpdate().getTime()));
            }
            if (o.getUserUpdate() == null) {
                stmtpsordremissionI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(2, o.getUserUpdate());
            }
            if (o.getIpUpdate() == null) {
                stmtpsordremissionI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(3, o.getIpUpdate());
            }
            if (o.getOmID() == null) {
                stmtpsordremissionI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(4, o.getOmID());
            }
            if (o.getMotif() == null) {
                stmtpsordremissionI.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(5, o.getMotif());
            }
            if (o.getGrade() == null) {
                stmtpsordremissionI.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(6, o.getGrade());
            }
            if (o.getMatricule() == null) {
                stmtpsordremissionI.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(7, o.getMatricule());
            }
            if (o.getTacheID() == null) {
                stmtpsordremissionI.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(8, o.getTacheID());
            }
            if (o.getOrganisationID() == null) {
                stmtpsordremissionI.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(9, o.getOrganisationID());
            }
            if (o.getMillesime() == null) {
                stmtpsordremissionI.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(10, o.getMillesime());
            }
            if (o.getActiviteID() == null) {
                stmtpsordremissionI.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(11, o.getActiviteID());
            }
            if (o.getStructureID() == null) {
                stmtpsordremissionI.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(12, o.getStructureID());
            }
            if (o.getAffectation() == null) {
                stmtpsordremissionI.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(13, o.getAffectation());
            }
            if (o.getSituation() == null) {
                stmtpsordremissionI.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(14, o.getSituation());
            }
            if (o.getDestination() == null) {
                stmtpsordremissionI.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(15, o.getDestination());
            }
            if (o.getPassantPar() == null) {
                stmtpsordremissionI.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(16, o.getPassantPar());
            }
            if (o.getMotifReference() == null) {
                stmtpsordremissionI.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(17, o.getMotifReference());
            }
            if (o.getTransport() == null) {
                stmtpsordremissionI.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(18, o.getTransport());
            }
            if (o.getAccompagnant() == null) {
                stmtpsordremissionI.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(19, o.getAccompagnant());
            }
            if (o.getDateDepart() == null) {
                stmtpsordremissionI.setNull(20, java.sql.Types.DATE);
            } else {
                stmtpsordremissionI.setDate(20, new java.sql.Date(o.getDateDepart().getTime()));
            }
            if (o.getDateRetour() == null) {
                stmtpsordremissionI.setNull(21, java.sql.Types.DATE);
            } else {
                stmtpsordremissionI.setDate(21, new java.sql.Date(o.getDateRetour().getTime()));
            }
            stmtpsordremissionI.setInt(22, o.getTypeMission());

            if (o.getOrdonnateur() == null) {
                stmtpsordremissionI.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(23, o.getOrdonnateur());
            }

            stmtpsordremissionI.setInt(24, o.getNbJours());

            if (o.getMontantGlobal() == null) {
                stmtpsordremissionI.setBigDecimal(25, BigDecimal.ZERO);
            } else {
                stmtpsordremissionI.setBigDecimal(25, o.getMontantGlobal());
            }
            if (o.getMontantOP() == null) {
                stmtpsordremissionI.setBigDecimal(26, BigDecimal.ZERO);
            } else {
                stmtpsordremissionI.setBigDecimal(26, o.getMontantOP());
            }
            if (o.getNumeroOP() == null) {
                stmtpsordremissionI.setNull(27, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(27, o.getNumeroOP());
            }
            if (o.getBeneficiaire() == null) {
                stmtpsordremissionI.setNull(28, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(28, o.getBeneficiaire());
            }

            stmtpsordremissionI.executeQuery();
            return o.getOmID();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(OrdreMission o) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionI = con.prepareCall("CALL psOrdreMission_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (o.getLastUpdate() == null) {
                stmtpsordremissionI.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsordremissionI.setDate(1, new java.sql.Date(o.getLastUpdate().getTime()));
            }
            if (o.getUserUpdate() == null) {
                stmtpsordremissionI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(2, o.getUserUpdate());
            }
            if (o.getIpUpdate() == null) {
                stmtpsordremissionI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(3, o.getIpUpdate());
            }
            if (o.getOmID() == null) {
                stmtpsordremissionI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(4, o.getOmID());
            }
            if (o.getMotif() == null) {
                stmtpsordremissionI.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(5, o.getMotif());
            }
            if (o.getGrade() == null) {
                stmtpsordremissionI.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(6, o.getGrade());
            }
            if (o.getMatricule() == null) {
                stmtpsordremissionI.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(7, o.getMatricule());
            }
            if (o.getTacheID() == null) {
                stmtpsordremissionI.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(8, o.getTacheID());
            }
            if (o.getOrganisationID() == null) {
                stmtpsordremissionI.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(9, o.getOrganisationID());
            }
            if (o.getMillesime() == null) {
                stmtpsordremissionI.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(10, o.getMillesime());
            }
            if (o.getActiviteID() == null) {
                stmtpsordremissionI.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(11, o.getActiviteID());
            }
            if (o.getStructureID() == null) {
                stmtpsordremissionI.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(12, o.getStructureID());
            }
            if (o.getAffectation() == null) {
                stmtpsordremissionI.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(13, o.getAffectation());
            }
            if (o.getSituation() == null) {
                stmtpsordremissionI.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(14, o.getSituation());
            }
            if (o.getDestination() == null) {
                stmtpsordremissionI.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(15, o.getDestination());
            }
            if (o.getPassantPar() == null) {
                stmtpsordremissionI.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(16, o.getPassantPar());
            }
            if (o.getMotifReference() == null) {
                stmtpsordremissionI.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(17, o.getMotifReference());
            }
            if (o.getTransport() == null) {
                stmtpsordremissionI.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(18, o.getTransport());
            }
            if (o.getAccompagnant() == null) {
                stmtpsordremissionI.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(19, o.getAccompagnant());
            }
            if (o.getDateDepart() == null) {
                stmtpsordremissionI.setNull(20, java.sql.Types.DATE);
            } else {
                stmtpsordremissionI.setDate(20, new java.sql.Date(o.getDateDepart().getTime()));
            }
            if (o.getDateRetour() == null) {
                stmtpsordremissionI.setNull(21, java.sql.Types.DATE);
            } else {
                stmtpsordremissionI.setDate(21, new java.sql.Date(o.getDateRetour().getTime()));
            }

            stmtpsordremissionI.setInt(22, o.getTypeMission());

            if (o.getOrdonnateur() == null) {
                stmtpsordremissionI.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(23, o.getOrdonnateur());
            }

            stmtpsordremissionI.setInt(24, o.getNbJours());

            if (o.getMontantGlobal() == null) {
                stmtpsordremissionI.setBigDecimal(25, BigDecimal.ZERO);
            } else {
                stmtpsordremissionI.setBigDecimal(25, o.getMontantGlobal());
            }
            if (o.getMontantOP() == null) {
                stmtpsordremissionI.setBigDecimal(26, BigDecimal.ZERO);
            } else {
                stmtpsordremissionI.setBigDecimal(26, o.getMontantOP());
            }
            if (o.getNumeroOP() == null) {
                stmtpsordremissionI.setNull(27, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(27, o.getNumeroOP());
            }
            if (o.getBeneficiaire() == null) {
                stmtpsordremissionI.setNull(28, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionI.setString(28, o.getBeneficiaire());
            }

            stmtpsordremissionI.executeQuery();

        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String omID, String user, String ipAdresse) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionD = con.prepareCall("CALL psOrdreMission_Delete( ?, ?, ?)");

            if (omID == null) {
                stmtpsordremissionD.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionD.setString(1, omID);
            }
            if (user == null) {
                stmtpsordremissionD.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionD.setString(2, user);
            }
            if (ipAdresse == null) {
                stmtpsordremissionD.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionD.setString(3, ipAdresse);
            }

            stmtpsordremissionD.executeUpdate();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public OrdreMission getOrdreMission(String omID) {
        Connection con = null;
        OrdreMission e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionS = con.prepareCall("CALL psOrdreMission_Find( ?)");

            if (omID == null) {
                stmtpsordremissionS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(1, omID);
            }

            ResultSet rs = stmtpsordremissionS.executeQuery();
            while (rs.next()) {
                e = new OrdreMission();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setOmID(rs.getString("omID"));

                e.setMotif(rs.getString("motif"));

                e.setGrade(rs.getString("grade"));
                if (rs.wasNull()) {
                    e.setGrade(null);
                }
                e.setMatricule(rs.getString("matricule"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setAffectation(rs.getString("affectation"));
                if (rs.wasNull()) {
                    e.setAffectation(null);
                }
                e.setSituation(rs.getString("situation"));
                if (rs.wasNull()) {
                    e.setSituation(null);
                }
                e.setDestination(rs.getString("destination"));

                e.setPassantPar(rs.getString("passantPar"));
                if (rs.wasNull()) {
                    e.setPassantPar(null);
                }
                e.setMotifReference(rs.getString("motifReference"));
                if (rs.wasNull()) {
                    e.setMotifReference(null);
                }
                e.setTransport(rs.getString("transport"));
                if (rs.wasNull()) {
                    e.setTransport(null);
                }
                e.setAccompagnant(rs.getString("accompagnant"));
                if (rs.wasNull()) {
                    e.setAccompagnant(null);
                }
                e.setDateDepart(rs.getDate("dateDepart"));

                e.setDateRetour(rs.getDate("dateRetour"));

                e.setTypeMission(rs.getInt("typeMission"));

                e.setNomAgent(rs.getString("nomAgent"));

                e.setPrenomAgent(rs.getString("prenomAgent"));

                e.setNbJours(rs.getInt("nbJours"));
                e.setNumeroOP(rs.getString("numeroOP"));
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantGlobal(rs.getBigDecimal("montantGlobal"));
                e.setMontantOP(rs.getBigDecimal("montantOP"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception eb) {
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public List<OrdreMission> getOMByOrganisation(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionS = con.prepareCall("CALL psOrdreMission_SearchByOrganisation( ?, ?)");

            if (millesime == null) {
                stmtpsordremissionS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsordremissionS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(2, organisationID);
            }

            List<OrdreMission> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionS.executeQuery();
            while (rs.next()) {
                OrdreMission e = new OrdreMission();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setOmID(rs.getString("omID"));

                e.setMotif(rs.getString("motif"));

                e.setGrade(rs.getString("grade"));
                if (rs.wasNull()) {
                    e.setGrade(null);
                }
                e.setMatricule(rs.getString("matricule"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setAffectation(rs.getString("affectation"));
                if (rs.wasNull()) {
                    e.setAffectation(null);
                }
                e.setSituation(rs.getString("situation"));
                if (rs.wasNull()) {
                    e.setSituation(null);
                }
                e.setDestination(rs.getString("destination"));

                e.setPassantPar(rs.getString("passantPar"));
                if (rs.wasNull()) {
                    e.setPassantPar(null);
                }
                e.setMotifReference(rs.getString("motifReference"));
                if (rs.wasNull()) {
                    e.setMotifReference(null);
                }
                e.setTransport(rs.getString("transport"));
                if (rs.wasNull()) {
                    e.setTransport(null);
                }
                e.setAccompagnant(rs.getString("accompagnant"));
                if (rs.wasNull()) {
                    e.setAccompagnant(null);
                }
                e.setDateDepart(rs.getDate("dateDepart"));

                e.setDateRetour(rs.getDate("dateRetour"));

                e.setTypeMission(rs.getInt("typeMission"));

                e.setNomAgent(rs.getString("nomAgent"));

                e.setPrenomAgent(rs.getString("prenomAgent"));

                e.setNbJours(rs.getInt("nbJours"));
                e.setNumeroOP(rs.getString("numeroOP"));
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantGlobal(rs.getBigDecimal("montantGlobal"));
                e.setMontantOP(rs.getBigDecimal("montantOP"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception eb) {
                }

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<OrdreMission> getOMByAgent(String millesime, String organisationID, String matricule) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionS = con.prepareCall("CALL psOrdreMission_SearchByAgent( ?, ?, ?)");

            if (millesime == null) {
                stmtpsordremissionS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsordremissionS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(2, organisationID);
            }
            if (matricule == null) {
                stmtpsordremissionS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(3, matricule);
            }

            List<OrdreMission> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionS.executeQuery();
            while (rs.next()) {
                OrdreMission e = new OrdreMission();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setOmID(rs.getString("omID"));

                e.setMotif(rs.getString("motif"));

                e.setGrade(rs.getString("grade"));
                if (rs.wasNull()) {
                    e.setGrade(null);
                }
                e.setMatricule(rs.getString("matricule"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setAffectation(rs.getString("affectation"));
                if (rs.wasNull()) {
                    e.setAffectation(null);
                }
                e.setSituation(rs.getString("situation"));
                if (rs.wasNull()) {
                    e.setSituation(null);
                }
                e.setDestination(rs.getString("destination"));

                e.setPassantPar(rs.getString("passantPar"));
                if (rs.wasNull()) {
                    e.setPassantPar(null);
                }
                e.setMotifReference(rs.getString("motifReference"));
                if (rs.wasNull()) {
                    e.setMotifReference(null);
                }
                e.setTransport(rs.getString("transport"));
                if (rs.wasNull()) {
                    e.setTransport(null);
                }
                e.setAccompagnant(rs.getString("accompagnant"));
                if (rs.wasNull()) {
                    e.setAccompagnant(null);
                }
                e.setDateDepart(rs.getDate("dateDepart"));

                e.setDateRetour(rs.getDate("dateRetour"));

                e.setTypeMission(rs.getInt("typeMission"));

                e.setNomAgent(rs.getString("nomAgent"));

                e.setPrenomAgent(rs.getString("prenomAgent"));

                e.setNbJours(rs.getInt("nbJours"));
                e.setNumeroOP(rs.getString("numeroOP"));
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantGlobal(rs.getBigDecimal("montantGlobal"));
                e.setMontantOP(rs.getBigDecimal("montantOP"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception eb) {
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<OrdreMission> getOMByTache(String millesime, String organisationID, String tacheID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionS = con.prepareCall("CALL psOrdreMission_SearchByTache( ?, ?, ?)");

            if (millesime == null) {
                stmtpsordremissionS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsordremissionS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(2, organisationID);
            }
            if (tacheID == null) {
                stmtpsordremissionS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(3, tacheID);
            }

            List<OrdreMission> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionS.executeQuery();
            while (rs.next()) {
                OrdreMission e = new OrdreMission();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setOmID(rs.getString("omID"));

                e.setMotif(rs.getString("motif"));

                e.setGrade(rs.getString("grade"));
                if (rs.wasNull()) {
                    e.setGrade(null);
                }
                e.setMatricule(rs.getString("matricule"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setAffectation(rs.getString("affectation"));
                if (rs.wasNull()) {
                    e.setAffectation(null);
                }
                e.setSituation(rs.getString("situation"));
                if (rs.wasNull()) {
                    e.setSituation(null);
                }
                e.setDestination(rs.getString("destination"));

                e.setPassantPar(rs.getString("passantPar"));
                if (rs.wasNull()) {
                    e.setPassantPar(null);
                }
                e.setMotifReference(rs.getString("motifReference"));
                if (rs.wasNull()) {
                    e.setMotifReference(null);
                }
                e.setTransport(rs.getString("transport"));
                if (rs.wasNull()) {
                    e.setTransport(null);
                }
                e.setAccompagnant(rs.getString("accompagnant"));
                if (rs.wasNull()) {
                    e.setAccompagnant(null);
                }
                e.setDateDepart(rs.getDate("dateDepart"));

                e.setDateRetour(rs.getDate("dateRetour"));

                e.setTypeMission(rs.getInt("typeMission"));

                e.setNomAgent(rs.getString("nomAgent"));

                e.setPrenomAgent(rs.getString("prenomAgent"));

                e.setNbJours(rs.getInt("nbJours"));
                e.setNumeroOP(rs.getString("numeroOP"));
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantGlobal(rs.getBigDecimal("montantGlobal"));
                e.setMontantOP(rs.getBigDecimal("montantOP"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception eb) {
                }
                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<OrdreMission> getOMByStructure(String millesime, String organisationID, String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionS = con.prepareCall("CALL psOrdreMission_SearchByStructure( ?, ?, ?)");

            if (millesime == null) {
                stmtpsordremissionS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsordremissionS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(2, organisationID);
            }
            if (structureID == null) {
                stmtpsordremissionS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(3, structureID);
            }

            List<OrdreMission> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionS.executeQuery();
            while (rs.next()) {
                OrdreMission e = new OrdreMission();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setOmID(rs.getString("omID"));

                e.setMotif(rs.getString("motif"));

                e.setGrade(rs.getString("grade"));
                if (rs.wasNull()) {
                    e.setGrade(null);
                }
                e.setMatricule(rs.getString("matricule"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setAffectation(rs.getString("affectation"));
                if (rs.wasNull()) {
                    e.setAffectation(null);
                }
                e.setSituation(rs.getString("situation"));
                if (rs.wasNull()) {
                    e.setSituation(null);
                }
                e.setDestination(rs.getString("destination"));

                e.setPassantPar(rs.getString("passantPar"));
                if (rs.wasNull()) {
                    e.setPassantPar(null);
                }
                e.setMotifReference(rs.getString("motifReference"));
                if (rs.wasNull()) {
                    e.setMotifReference(null);
                }
                e.setTransport(rs.getString("transport"));
                if (rs.wasNull()) {
                    e.setTransport(null);
                }
                e.setAccompagnant(rs.getString("accompagnant"));
                if (rs.wasNull()) {
                    e.setAccompagnant(null);
                }
                e.setDateDepart(rs.getDate("dateDepart"));

                e.setDateRetour(rs.getDate("dateRetour"));

                e.setTypeMission(rs.getInt("typeMission"));

                e.setNomAgent(rs.getString("nomAgent"));

                e.setPrenomAgent(rs.getString("prenomAgent"));

                e.setNbJours(rs.getInt("nbJours"));
                e.setNumeroOP(rs.getString("numeroOP"));
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantGlobal(rs.getBigDecimal("montantGlobal"));
                e.setMontantOP(rs.getBigDecimal("montantOP"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception eb) {
                }

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueAgentOM> getOMNumberByAgent(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsordremissionS = con.prepareCall("CALL psOrdreMission_A( ?, ?)");

            if (millesime == null) {
                stmtpsordremissionS.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsordremissionS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsordremissionS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsordremissionS.setString(2, organisationID);
            }

            List<VueAgentOM> list = new ArrayList<>();
            ResultSet rs = stmtpsordremissionS.executeQuery();
            while (rs.next()) {
                VueAgentOM e = new VueAgentOM();

                e.setMatricule(rs.getString("matricule"));

                e.setNom(rs.getString("nom"));

                e.setPrenom(rs.getString("prenom"));

                e.setNbOM(rs.getInt("nbOM"));
                
                try {
                    e.setNbJours(rs.getInt("nbJours"));
                } catch (Exception ex) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void reservationOM(String omID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psOrdreMission_Reserve( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (omID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, omID);
            }
            stmtpsEngagementReserve.setBoolean(2, reserve);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            reserve = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void reservationOMAnnuler(String omID, boolean annuler, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psOrdreMission_Reserve_Annuler( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (omID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, omID);
            }
            stmtpsEngagementReserve.setBoolean(2, annuler);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            annuler = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
