/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IOperationDao;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.view.VueOpDisponiblePipe;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class OperationDao implements IOperationDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public void prepaAjouter(PrepaOperationBudgetaire act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaOperation_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getTacheID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getTacheID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getDateDebut() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(act.getDateDebut().getTime()));
            }
            if (act.getDateFin() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(act.getDateFin().getTime()));
            }
            if (act.getResultatFr() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getResultatFr());
            }
            if (act.getResultatUs() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getResultatUs());
            }
            if (act.getIndicateurFr() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getIndicateurFr());
            }
            if (act.getIndicateurUs() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getIndicateurUs());
            }
            if (act.getSourceVerificationFr() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getSourceVerificationFr());
            }
            if (act.getSourceVerificationUs() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, act.getSourceVerificationUs());
            }
            if (act.getAe() == null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setBigDecimal(14, act.getAe());
            }
            if (act.getCp() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setBigDecimal(15, act.getCp());
            }
            if (act.getCompteCode() == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, act.getCompteCode());
            }
            if (act.getFinancementID() == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, act.getFinancementID());
            }
            if (act.getStructureID() == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, act.getStructureID());
            }
            if (act.getActiviteBudgetiseID() == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, act.getActiviteBudgetiseID());
            }
            if (act.getPosteComptableID() == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, act.getPosteComptableID());
            }
            if (act.getCalendrier() == null) {
                stmt.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(21, act.getCalendrier());
            }
            if (act.getBudgetID() == null) {
                stmt.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(22, act.getBudgetID());
            }
            if (act.getBudgetExploite() == null) {
                stmt.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(23, act.getBudgetExploite());
            }

//            System.out.println("tentative d'ajout paragraphe");
            stmt.executeQuery();

        } catch (Exception ex) {
//            System.out.println("Ajout paragraphe ");
            ex.printStackTrace();
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void prepaModifier(PrepaOperationBudgetaire act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaOperation_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getTacheID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getTacheID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getDateDebut() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(act.getDateDebut().getTime()));
            }
            if (act.getDateFin() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(act.getDateFin().getTime()));
            }
            if (act.getResultatFr() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getResultatFr());
            }
            if (act.getResultatUs() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getResultatUs());
            }
            if (act.getIndicateurFr() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getIndicateurFr());
            }
            if (act.getIndicateurUs() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getIndicateurUs());
            }
            if (act.getSourceVerificationFr() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getSourceVerificationFr());
            }
            if (act.getSourceVerificationUs() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, act.getSourceVerificationUs());
            }
            if (act.getAe() == null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setBigDecimal(14, act.getAe());
            }
            if (act.getCp() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setBigDecimal(15, act.getCp());
            }
            if (act.getCompteCode() == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, act.getCompteCode());
            }
            if (act.getFinancementID() == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, act.getFinancementID());
            }
            if (act.getStructureID() == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, act.getStructureID());
            }
            if (act.getActiviteBudgetiseID() == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, act.getActiviteBudgetiseID());
            }
            if (act.getPosteComptableID() == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, act.getPosteComptableID());
            }
            if (act.getCalendrier() == null) {
                stmt.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(21, act.getCalendrier());
            }
            if (act.getBudgetID() == null) {
                stmt.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(22, act.getBudgetID());
            }
            if (act.getBudgetExploite() == null) {
                stmt.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(23, act.getBudgetExploite());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void prepaSupprimer(String tacheID, String user) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaOperation_Delete(?, ?)");
            stmt.setString(1, tacheID);
            stmt.setString(2, user);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public PrepaOperationBudgetaire prepaGetOperation(String tacheID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaOperation_Find( ?)");

            if (tacheID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, tacheID);
            }
            PrepaOperationBudgetaire e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new PrepaOperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("AE"));
                e.setCp(rs.getBigDecimal("CP"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaOperationBudgetaire> prepaGetListOperationByActivite(String activiteParentID, String budgetID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaOperation_List( ?, ?)");

            if (activiteParentID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteParentID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, budgetID);
            }

            List<PrepaOperationBudgetaire> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaOperationBudgetaire e = new PrepaOperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("AE"));
                e.setCp(rs.getBigDecimal("CP"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));

                e.setBudgetExploite(rs.getString("budgetExploite"));
                
                try {
                    e.setCalendrier(rs.getString("calendrier"));
                } catch (Exception enn) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ajouter(OperationBudgetaire act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOperation_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getTacheID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getTacheID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getDateDebut() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(act.getDateDebut().getTime()));
            }
            if (act.getDateFin() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(act.getDateFin().getTime()));
            }
            if (act.getResultatFr() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getResultatFr());
            }
            if (act.getResultatUs() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getResultatUs());
            }
            if (act.getIndicateurFr() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getIndicateurFr());
            }
            if (act.getIndicateurUs() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getIndicateurUs());
            }
            if (act.getSourceVerificationFr() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getSourceVerificationFr());
            }
            if (act.getSourceVerificationUs() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, act.getSourceVerificationUs());
            }
            if (act.getAe() == null) {
                stmt.setBigDecimal(14, BigDecimal.ZERO);
            } else {
                stmt.setBigDecimal(14, act.getAe());
            }
            if (act.getCp() == null) {
                stmt.setBigDecimal(15, BigDecimal.ZERO);
            } else {
                stmt.setBigDecimal(15, act.getCp());
            }
            if (act.getCompteCode() == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, act.getCompteCode());
            }
            if (act.getFinancementID() == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, act.getFinancementID());
            }
            if (act.getStructureID() == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, act.getStructureID());
            }
            if (act.getActiviteBudgetiseID() == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, act.getActiviteBudgetiseID());
            }
            if (act.getPosteComptableID() == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, act.getPosteComptableID());
            }
            if (act.getCalendrier() == null) {
                stmt.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(21, act.getCalendrier());
            }
            if (act.getBudgetID() == null) {
                stmt.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(22, act.getBudgetID());
            }
            if (act.getBudgetExploite() == null) {
                stmt.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(23, act.getBudgetExploite());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(OperationBudgetaire act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOperation_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getTacheID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getTacheID());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getLibelleUs());
            }
            if (act.getDateDebut() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(act.getDateDebut().getTime()));
            }
            if (act.getDateFin() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(act.getDateFin().getTime()));
            }
            if (act.getResultatFr() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getResultatFr());
            }
            if (act.getResultatUs() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, act.getResultatUs());
            }
            if (act.getIndicateurFr() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, act.getIndicateurFr());
            }
            if (act.getIndicateurUs() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, act.getIndicateurUs());
            }
            if (act.getSourceVerificationFr() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, act.getSourceVerificationFr());
            }
            if (act.getSourceVerificationUs() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, act.getSourceVerificationUs());
            }
            if (act.getAe() == null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setBigDecimal(14, act.getAe());
            }
            if (act.getCp() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setBigDecimal(15, act.getCp());
            }
            if (act.getCompteCode() == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, act.getCompteCode());
            }
            if (act.getFinancementID() == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, act.getFinancementID());
            }
            if (act.getStructureID() == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, act.getStructureID());
            }
            if (act.getActiviteBudgetiseID() == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, act.getActiviteBudgetiseID());
            }
            if (act.getPosteComptableID() == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, act.getPosteComptableID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String tacheID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOperation_Delete(?)");
            stmt.setString(1, tacheID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public OperationBudgetaire getOperation(String tacheID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psOperation_Find( ?)");

            if (tacheID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, tacheID);
            }
            OperationBudgetaire e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new OperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("AE"));
                e.setCp(rs.getBigDecimal("CP"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<OperationBudgetaire> getListOperationByActivite(String activiteParentID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psOperation_List( ?)");

            if (activiteParentID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteParentID);
            }
            List<OperationBudgetaire> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                OperationBudgetaire e = new OperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("AE"));
                e.setCp(rs.getBigDecimal("CP"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception ec) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<OperationBudgetaire> getListOperationByActiviteAndStructure(String activiteParentID, String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psOperation_List_Structure( ?, ?)");

            if (activiteParentID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteParentID);
            }
            if (structureID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, structureID);
            }
            
            List<OperationBudgetaire> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                OperationBudgetaire e = new OperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("AE"));
                e.setCp(rs.getBigDecimal("CP"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception ec) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public BigDecimal getDisponible(OperationBudgetaire op) {
        Connection con = null;
        BigDecimal disponible = new BigDecimal(0);
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOperation_Disponible(?, ?)");
            stmt.setString(1, op.getTacheID());
            stmt.registerOutParameter(2, java.sql.Types.DECIMAL);
            stmt.setBigDecimal(2, disponible);
            stmt.executeQuery();

            disponible = stmt.getBigDecimal(2);
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return disponible;
    }

    @Override
    public VueOpDisponiblePipe getDisponiblePipe(String tacheID) {
        Connection con = null;
        VueOpDisponiblePipe disponible = new VueOpDisponiblePipe();
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOperation_DisponiblePipe(?)");
            stmt.setString(1, tacheID);
            stmt.executeQuery();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                disponible.setTacheID(rs.getString("tacheID"));
                disponible.setAe(rs.getBigDecimal("ae"));
                disponible.setEngage(rs.getBigDecimal("engage"));
                disponible.setPipe(rs.getBigDecimal("pipe"));
                disponible.setReste(rs.getBigDecimal("reste"));
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return disponible;
    }

     @Override
    public List<OperationBudgetaire> getListOperationByActiviteExecution(String activiteParentID, String budgetID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psOperation_ExecutionList( ?, ?)");

            if (activiteParentID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteParentID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, budgetID);
            }
            List<OperationBudgetaire> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                OperationBudgetaire e = new OperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("dotation"));
                e.setCp(rs.getBigDecimal("disponible"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception ec) {
                }
                try {
                    e.setMillesime(rs.getString("millesime"));
                } catch (Exception ec) {
                }
                try {
                    e.setChapitre(rs.getString("chapitre"));
                } catch (Exception ec) {
                }
                try {
                    e.setProgramme(rs.getString("programme"));
                } catch (Exception ec) {
                }
                try {
                    e.setAction(rs.getString("action"));
                } catch (Exception ec) {
                }
                try {
                    e.setTacheCode(rs.getString("tacheCode"));
                } catch (Exception ec) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PrepaOperationBudgetaire> prepaGetListOperationByActiviteWithCollectif(String activiteID, String budgetID, String budgetCollectifID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psPrepaOperation_ListWithCollectif( ?, ?, ?)");

            if (activiteID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, activiteID);
            }
            if (budgetID == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, budgetID);
            }
            if (budgetCollectifID == null) {
                stmtpsactiviteS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(3, budgetCollectifID);
            }

            List<PrepaOperationBudgetaire> list = new ArrayList<>();

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                PrepaOperationBudgetaire e = new PrepaOperationBudgetaire();

                e.setLastUpdate(rs.getDate("last_update"));
                e.setUserUpdate(rs.getString("user_update"));
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    e.setLibelleUs(null);
                }
                e.setDateDebut(rs.getDate("dateDebut"));
                e.setDateFin(rs.getDate("dateFin"));
                e.setResultatFr(rs.getString("resultatFr"));
                e.setResultatUs(rs.getString("resultatUs"));
                if (rs.wasNull()) {
                    e.setResultatUs(null);
                }
                e.setIndicateurFr(rs.getString("indicateurFr"));
                e.setIndicateurUs(rs.getString("indicateurUs"));
                if (rs.wasNull()) {
                    e.setIndicateurUs(null);
                }
                e.setSourceVerificationFr(rs.getString("sourceVerificationFr"));
                e.setSourceVerificationUs(rs.getString("sourceVerificationUs"));
                if (rs.wasNull()) {
                    e.setSourceVerificationUs(null);
                }
                e.setAe(rs.getBigDecimal("AE"));
                e.setCp(rs.getBigDecimal("CP"));
                e.setCompteCode(rs.getString("CompteCode"));
                e.setFinancementID(rs.getString("financementID"));
                e.setStructureID(rs.getString("structureID"));
                e.setActiviteBudgetiseID(rs.getString("activiteBudgetiseID"));
                e.setPosteComptableID(rs.getString("posteComptableID"));
                e.setOrdreDansActivite(rs.getInt("ordreDansActivite"));

                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setStructureAbbreviation(rs.getString("structureLibelle"));
                e.setFinancementAbbreviation(rs.getString("financementLibelle"));
                e.setPosteComptableLibelle(rs.getString("pcLibelle"));

                e.setBudgetExploite(rs.getString("budgetExploite"));
                
                try {
                    e.setCalendrier(rs.getString("calendrier"));
                } catch (Exception enn) {
                }
                
                try {
                    e.setAECollectif(rs.getBigDecimal("aeCollectif"));
                } catch (Exception en) {
                }
                try {
                    e.setCPCollectif(rs.getBigDecimal("cpCollectif"));
                } catch (Exception en) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void prepaCollectifInsert(String budgetID, String budgetCollectifID, PrepaOperationBudgetaire act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaOperation_Collectif(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getTacheID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getTacheID());
            }
            if (act.getAe() == null) {
                stmt.setNull(4, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(4, act.getAe());
            }
            if (act.getCp() == null) {
                stmt.setNull(5, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(5, act.getCp());
            }
            if (act.getAECollectif()== null) {
                stmt.setNull(6, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(6, act.getAECollectif());
            }
            if (act.getCPCollectif()== null) {
                stmt.setNull(7, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(7, act.getCPCollectif());
            }
            if (budgetID == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, budgetID);
            }
            if (budgetCollectifID == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, budgetCollectifID);
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int prepaCollectifEnExecution(String budgetInitialID, String budgetCollectifID, String user_update) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPrepaOperation_CollectifTransfert(?, ?, ?)");
            if (budgetInitialID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, budgetInitialID);
            }
            if (budgetCollectifID == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, budgetCollectifID);
            }
            if (user_update == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, user_update);
            }
            

            stmt.executeQuery();

            return 1;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return -1;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

  
}
