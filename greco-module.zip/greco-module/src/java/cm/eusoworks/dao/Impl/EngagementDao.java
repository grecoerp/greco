/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IEngagementDao;
import cm.eusoworks.entities.cls.CleValeur;
import cm.eusoworks.entities.model.Bordereau;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.entities.view.VueEngagementJournal;
import cm.eusoworks.entities.view.VueEngagementLivre;
import cm.eusoworks.entities.view.VueEngagementStat;
import cm.eusoworks.entities.view.VueEngagementState;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Liasse;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.Mandatement;
import cm.eusoworks.entities.model.Paiement;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueControle;
import cm.eusoworks.entities.view.VueLeveeDetails;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class EngagementDao implements IEngagementDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public EngagementType getEngagementType(String typeID) {
        Connection con = null;
        EngagementType e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementTypeFind = con.prepareCall("CALL psEngagementType_Find( ?)");

            if (typeID == null) {
                stmtpsEngagementTypeFind.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementTypeFind.setString(1, typeID);
            }

            ResultSet rs = stmtpsEngagementTypeFind.executeQuery();
            while (rs.next()) {
                e = new EngagementType();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTypeID(rs.getString("typeID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<EngagementType> getEngagementType() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementTypeFind = con.prepareCall("CALL psEngagementType_List( )");

            List<EngagementType> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementTypeFind.executeQuery();
            while (rs.next()) {
                EngagementType e = new EngagementType();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setTypeID(rs.getString("typeID"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String ajouter(Engagement e) throws GrecoException {
        Connection con = null;
        String numDossier = null;
        con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagement_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getLastUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(1, new java.sql.Date(e.getLastUpdate().getTime()));
            }
            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getIpUpdate());
            }
            if (e.getEngagementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getEngagementID());
            }
            if (e.getNumDossier() == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, numDossier);
            }

            stmtpsEngagementInsert.setInt(6, e.getEtat());

            if (e.getDateValidation() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(7, new java.sql.Date(e.getDateValidation().getTime()));
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getReference());
            }
            if (e.getObjet() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, e.getObjet());
            }
            if (e.getDateSignature() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(10, new java.sql.Date(e.getDateSignature().getTime()));
            }
            if (e.getSignataire() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, e.getSignataire());
            }

            if (e.getMontantTTC() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(12, e.getMontantTTC());
            }
            if (e.getMontantTAXE() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(13, e.getMontantTAXE());
            }
            if (e.getMontantNAP() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(14, e.getMontantNAP());
            }
            if (e.getMontantRG() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(15, e.getMontantRG());
            }

            if (e.getBeneficiaire() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(16, e.getBeneficiaire());
            }
            if (e.getFournisseurID() == null) {
                stmtpsEngagementInsert.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(17, e.getFournisseurID());
            }
            if (e.getMatricule() == null) {
                stmtpsEngagementInsert.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(18, e.getMatricule());
            }
            if (e.getStructureBenefID() == null) {
                stmtpsEngagementInsert.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(19, e.getStructureBenefID());
            }
            if (e.getTacheID() == null) {
                stmtpsEngagementInsert.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(20, e.getTacheID());
            }
            if (e.getOrganisationID() == null) {
                stmtpsEngagementInsert.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(21, e.getOrganisationID());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(22, e.getMillesime());
            }
            if (e.getActiviteID() == null) {
                stmtpsEngagementInsert.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(23, e.getActiviteID());
            }
            if (e.getTypeID() == null) {
                stmtpsEngagementInsert.setNull(24, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(24, e.getTypeID());
            }
            if (e.getStructureID() == null) {
                stmtpsEngagementInsert.setNull(25, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(25, e.getStructureID());
            }

            if (e.getGestionnaire() == null) {
                stmtpsEngagementInsert.setNull(26, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(26, e.getGestionnaire());
            }

            if (e.getDecisionID() == null) {
                stmtpsEngagementInsert.setNull(27, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(27, e.getDecisionID());
            }

            if (e.getBcaID() == null) {
                stmtpsEngagementInsert.setNull(28, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(28, e.getBcaID());
            }

            if (e.getOmID() == null) {
                stmtpsEngagementInsert.setNull(29, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(29, e.getOmID());
            }

            stmtpsEngagementInsert.registerOutParameter(5, java.sql.Types.VARCHAR);

            stmtpsEngagementInsert.executeUpdate();

            numDossier = stmtpsEngagementInsert.getString(5);
            return numDossier;

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(Engagement e) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementInsert = con.prepareCall("CALL psEngagement_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getLastUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(1, new java.sql.Date(e.getLastUpdate().getTime()));
            }
            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getIpUpdate());
            }
            if (e.getEngagementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getEngagementID());
            }
            if (e.getNumDossier() == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, e.getNumDossier());
            }

            stmtpsEngagementInsert.setInt(6, e.getEtat());

            if (e.getDateValidation() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(7, new java.sql.Date(e.getDateValidation().getTime()));
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getReference());
            }
            if (e.getObjet() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, e.getObjet());
            }
            if (e.getDateSignature() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(10, new java.sql.Date(e.getDateSignature().getTime()));
            }
            if (e.getSignataire() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, e.getSignataire());
            }
            if (e.getMontantTTC() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(12, e.getMontantTTC());
            }
            if (e.getMontantTAXE() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(13, e.getMontantTAXE());
            }
            if (e.getMontantNAP() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(14, e.getMontantNAP());
            }
            if (e.getMontantRG() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(15, e.getMontantRG());
            }
            if (e.getBeneficiaire() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(16, e.getBeneficiaire());
            }
            if (e.getFournisseurID() == null) {
                stmtpsEngagementInsert.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(17, e.getFournisseurID());
            }
            if (e.getMatricule() == null) {
                stmtpsEngagementInsert.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(18, e.getMatricule());
            }
            if (e.getStructureBenefID() == null) {
                stmtpsEngagementInsert.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(19, e.getStructureBenefID());
            }
            if (e.getTacheID() == null) {
                stmtpsEngagementInsert.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(20, e.getTacheID());
            }
            if (e.getOrganisationID() == null) {
                stmtpsEngagementInsert.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(21, e.getOrganisationID());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(22, e.getMillesime());
            }
            if (e.getActiviteID() == null) {
                stmtpsEngagementInsert.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(23, e.getActiviteID());
            }
            if (e.getTypeID() == null) {
                stmtpsEngagementInsert.setNull(24, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(24, e.getTypeID());
            }
            if (e.getStructureID() == null) {
                stmtpsEngagementInsert.setNull(25, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(25, e.getStructureID());
            }
            if (e.getGestionnaire() == null) {
                stmtpsEngagementInsert.setNull(26, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(26, e.getGestionnaire());
            }
            if (e.getDecisionID() == null) {
                stmtpsEngagementInsert.setNull(27, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(27, e.getDecisionID());
            }
            if (e.getBcaID() == null) {
                stmtpsEngagementInsert.setNull(28, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(28, e.getBcaID());
            }
            if (e.getOmID() == null) {
                stmtpsEngagementInsert.setNull(29, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(29, e.getOmID());
            }

            stmtpsEngagementInsert.executeUpdate();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String engagementID, String user, String ipAdresse) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psEngagement_Delete( ?, ?, ?)");

            if (engagementID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, engagementID);
            }
            if (user == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, user);
            }
            if (ipAdresse == null) {
                stmtpsEngagementDelete.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(3, ipAdresse);
            }

            stmtpsEngagementDelete.executeUpdate();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Engagement getEngagement(String engagementID) {
        Connection con = null;
        Engagement e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementFind = con.prepareCall("CALL psEngagement_Find( ?)");

            if (engagementID == null) {
                stmtpsEngagementFind.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementFind.setString(1, engagementID);
            }

            ResultSet rs = stmtpsEngagementFind.executeQuery();
            while (rs.next()) {
                e = new Engagement();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setEngagementID(rs.getString("engagementID"));

                e.setNumDossier(rs.getString("numDossier"));

                e.setEtat(rs.getInt("etat"));

                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setReference(rs.getString("reference"));

                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setSignataire(rs.getString("signataire"));
                if (rs.wasNull()) {
                    e.setSignataire(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTAXE(rs.getBigDecimal("montantTAXE"));
                if (rs.wasNull()) {
                    e.setMontantTAXE(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));

                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setTypeID(rs.getString("typeID"));

                e.setStructureID(rs.getString("structureID"));

                e.setGestionnaire(rs.getString("gestionnaire"));

                e.setDecisionID(rs.getString("decisionID"));
                if (rs.wasNull()) {
                    e.setDecisionID(null);
                }
                e.setBcaID(rs.getString("bcaID"));
                if (rs.wasNull()) {
                    e.setBcaID(null);
                }
                e.setOmID(rs.getString("omID"));
                if (rs.wasNull()) {
                    e.setOmID(null);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Engagement getEngagementByDossier(String dossier) {
        Connection con = null;
        Engagement e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementFind = con.prepareCall("CALL psEngagement_Find_Dossier( ?)");

            if (dossier == null) {
                stmtpsEngagementFind.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementFind.setString(1, dossier);
            }

            ResultSet rs = stmtpsEngagementFind.executeQuery();
            while (rs.next()) {
                e = new Engagement();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setEngagementID(rs.getString("engagementID"));

                e.setNumDossier(rs.getString("numDossier"));

                e.setEtat(rs.getInt("etat"));

                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setReference(rs.getString("reference"));

                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setSignataire(rs.getString("signataire"));
                if (rs.wasNull()) {
                    e.setSignataire(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTAXE(rs.getBigDecimal("montantTAXE"));
                if (rs.wasNull()) {
                    e.setMontantTAXE(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));

                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setTypeID(rs.getString("typeID"));

                e.setStructureID(rs.getString("structureID"));

                e.setGestionnaire(rs.getString("gestionnaire"));

                e.setDecisionID(rs.getString("decisionID"));
                if (rs.wasNull()) {
                    e.setDecisionID(null);
                }
                e.setBcaID(rs.getString("bcaID"));
                if (rs.wasNull()) {
                    e.setBcaID(null);
                }
                e.setOmID(rs.getString("omID"));
                if (rs.wasNull()) {
                    e.setOmID(null);
                }
                e.setCaptcha(rs.getString("captcha"));
                if (rs.wasNull()) {
                    e.setCaptcha(null);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Engagement> getEngagementByOrganisation(String millesime, String organisationID, String listeEtat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_SearchByOrganisation( ?, ?, ?)");

            if (millesime == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(2, organisationID);
            }

            if (listeEtat == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, listeEtat);
            }

            List<Engagement> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                Engagement e = new Engagement();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setEngagementID(rs.getString("engagementID"));

                e.setNumDossier(rs.getString("numDossier"));

                e.setEtat(rs.getInt("etat"));

                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setReference(rs.getString("reference"));

                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setSignataire(rs.getString("signataire"));
                if (rs.wasNull()) {
                    e.setSignataire(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTAXE(rs.getBigDecimal("montantTAXE"));
                if (rs.wasNull()) {
                    e.setMontantTAXE(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));

                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setTypeID(rs.getString("typeID"));

                e.setStructureID(rs.getString("structureID"));

                e.setGestionnaire(rs.getString("gestionnaire"));

                e.setDecisionID(rs.getString("decisionID"));
                if (rs.wasNull()) {
                    e.setDecisionID(null);
                }
                e.setBcaID(rs.getString("bcaID"));
                if (rs.wasNull()) {
                    e.setBcaID(null);
                }
                e.setOmID(rs.getString("omID"));
                if (rs.wasNull()) {
                    e.setOmID(null);
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Engagement> getEngagementByFournisseur(String millesime, String organisationID, String fournisseurID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByOrdonnateur(String millesime, String organisationID, String matriculeOrdo, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByAgent(String millesime, String organisationID, String matriculeAgent, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByTache(String millesime, String organisationID, String tacheID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByStructure(String millesime, String organisationID, String structureID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByType(String millesime, String organisationID, String typeID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByBCA(String millesime, String organisationID, String bcaID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByDecision(String millesime, String organisationID, String decisionID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Engagement> getEngagementByOM(String millesime, String organisationID, String omID, String listeEtat) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public VueEngagementStat getEngagementStat(String exMillesime) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<VueEngagementDossier> getDossiers(String organisationID, String millesime, String numdossier, String listeEtat, String engagementType,
            String cpte, Date dateEnregDebut, Date dateEnregFin, Date dateValidDebut, Date dateValidFin, String beneficiare) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Search( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (numdossier == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(3, numdossier);
            }
            if (listeEtat == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, listeEtat);
            }
            if (engagementType == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(5, engagementType);
            }
            if (cpte == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, cpte);
            }
            if (dateEnregDebut == null) {
                stmtpsEngagementSearch.setNull(7, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(7, new java.sql.Date(dateEnregDebut.getTime()));
            }
            if (dateEnregFin == null) {
                stmtpsEngagementSearch.setNull(8, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(8, new java.sql.Date(dateEnregFin.getTime()));
            }
            if (dateValidDebut == null) {
                stmtpsEngagementSearch.setNull(9, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(9, new java.sql.Date(dateValidDebut.getTime()));
            }
            if (dateValidFin == null) {
                stmtpsEngagementSearch.setNull(10, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(10, new java.sql.Date(dateValidFin.getTime()));
            }
            if (beneficiare == null) {
                stmtpsEngagementSearch.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(11, beneficiare);
            }

            List<VueEngagementDossier> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementDossier e = new VueEngagementDossier();
                e.setType(rs.getInt("type"));
                e.setEngagementID(rs.getString("engagementID"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCompte(rs.getString("compte"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setEtatID(rs.getInt("etat"));

                try {
                    e.setBcaID(rs.getString("bcaID"));
                } catch (Exception ea) {
                }
                try {
                    e.setOmID(rs.getString("omID"));
                } catch (Exception ea) {
                }
                try {
                    e.setDecisionID(rs.getString("decisionID"));
                } catch (Exception ea) {
                }
                try {
                    e.setLettreCommandeID(rs.getString("lettreCommandeID"));
                } catch (Exception ea) {
                }
                try {
                    e.setMarcheID(rs.getString("marcheID"));
                } catch (Exception ea) {
                }

                try {
                    e.setOrganisationID(rs.getString("organisationID"));
                } catch (Exception ea) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementDossier> getDossiersResteALiquider(String organisationID, String millesime, String numdossier, String listeEtat, String engagementType,
            String cpte, Date dateEnregDebut, Date dateEnregFin, Date dateValidDebut, Date dateValidFin, String beneficiare) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Search_RAL( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (numdossier == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(3, numdossier);
            }
            if (listeEtat == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, listeEtat);
            }
            if (engagementType == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(5, engagementType);
            }
            if (cpte == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, cpte);
            }
            if (dateEnregDebut == null) {
                stmtpsEngagementSearch.setNull(7, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(7, new java.sql.Date(dateEnregDebut.getTime()));
            }
            if (dateEnregFin == null) {
                stmtpsEngagementSearch.setNull(8, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(8, new java.sql.Date(dateEnregFin.getTime()));
            }
            if (dateValidDebut == null) {
                stmtpsEngagementSearch.setNull(9, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(9, new java.sql.Date(dateValidDebut.getTime()));
            }
            if (dateValidFin == null) {
                stmtpsEngagementSearch.setNull(10, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(10, new java.sql.Date(dateValidFin.getTime()));
            }
            if (beneficiare == null) {
                stmtpsEngagementSearch.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(11, beneficiare);
            }

            List<VueEngagementDossier> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementDossier e = new VueEngagementDossier();
                e.setType(rs.getInt("type"));
                e.setEngagementID(rs.getString("engagementID"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCompte(rs.getString("compte"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setEtatID(rs.getInt("etat"));

                try {
                    e.setBcaID(rs.getString("bcaID"));
                } catch (Exception ea) {
                }
                try {
                    e.setOmID(rs.getString("omID"));
                } catch (Exception ea) {
                }
                try {
                    e.setDecisionID(rs.getString("decisionID"));
                } catch (Exception ea) {
                }
                try {
                    e.setLettreCommandeID(rs.getString("lettreCommandeID"));
                } catch (Exception ea) {
                }
                try {
                    e.setMarcheID(rs.getString("marcheID"));
                } catch (Exception ea) {
                }

                try {
                    e.setOrganisationID(rs.getString("organisationID"));
                } catch (Exception ea) {
                }
                try {
                    e.setMontantRAL(rs.getBigDecimal("montantRAL"));
                } catch (Exception es) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementJournal> getJournal(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Journal( ?)");

            if (engagementID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, engagementID);
            }

            List<VueEngagementJournal> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementJournal e = new VueEngagementJournal();
                e.setEngagementID(rs.getString("engagementID"));
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                e.setMotif(rs.getString("motif"));
                e.setLogin(rs.getString("login"));
                e.setUser(rs.getString("user"));
                e.setDateOperation(rs.getDate("dateOperation"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void reservation(String engagementID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psEngagement_Reserve( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (engagementID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, engagementID);
            }
            stmtpsEngagementReserve.setBoolean(2, reserve);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            reserve = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void annulerReservation(String engagementID, boolean annule, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psEngagement_Reserve_Annule( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            if (engagementID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, engagementID);
            }
            stmtpsEngagementReserve.setBoolean(2, annule);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            annule = stmtpsEngagementReserve.getBoolean(2);

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementLivre> getLivreJournal(String organisationID, String millesime, String numdossier, String etat, String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin, Date dateValidDebut, Date dateValidFin, String beneficiare) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_LivreJournal( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (numdossier == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(3, numdossier);
            }
            if (etat == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, etat);
            }
            if (engagementType == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(5, engagementType);
            }
            if (cpte == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, cpte);
            }
            if (dateEnregDebut == null) {
                stmtpsEngagementSearch.setNull(7, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(7, new java.sql.Date(dateEnregDebut.getTime()));
            }
            if (dateEnregFin == null) {
                stmtpsEngagementSearch.setNull(8, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(8, new java.sql.Date(dateEnregFin.getTime()));
            }
            if (dateValidDebut == null) {
                stmtpsEngagementSearch.setNull(9, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(9, new java.sql.Date(dateValidDebut.getTime()));
            }
            if (dateValidFin == null) {
                stmtpsEngagementSearch.setNull(10, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(10, new java.sql.Date(dateValidFin.getTime()));
            }
            if (beneficiare == null) {
                stmtpsEngagementSearch.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(11, beneficiare);
            }

            List<VueEngagementLivre> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementLivre e = new VueEngagementLivre();
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                e.setMillesime(rs.getString("millesime"));
                e.setExercice(rs.getString("exercice"));
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCodeTache(rs.getString("codeTache"));
                e.setCompte(rs.getString("compte"));
                e.setDateSignature(rs.getDate("dateSignature"));
                e.setEtat(rs.getInt("etat"));
                e.setLastUpdate(rs.getDate("lastUpdate"));
                e.setLibelleTache(rs.getString("libelleTache"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                e.setStructure(rs.getString("structure"));
                e.setType(rs.getString("type"));
                e.setTypeID(rs.getInt("typeID"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String genererBordereau(String organisationID, String millesime, int type, String source, String destination, String agent, String userUpdate) {
        Connection con = null;
        String bordereau = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psBordereau_Insert( ?, ?, ?, ?, ?, ?, ?, ?)");
            stmtpsEngagementSearch.registerOutParameter(8, java.sql.Types.VARCHAR);
            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            stmtpsEngagementSearch.setInt(3, type);

            if (source == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, source);
            }
            if (destination == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(5, destination);
            }
            if (agent == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, agent);
            }
            if (userUpdate == null) {
                stmtpsEngagementSearch.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(7, userUpdate);
            }
            stmtpsEngagementSearch.setString(8, bordereau);

            stmtpsEngagementSearch.executeQuery();

            bordereau = stmtpsEngagementSearch.getString(8);

            return bordereau;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void transmissionEngagement(String organisationID, String millesime, String bordereau,
            VueEngagementDossier dossier, int etatDossier, String userUpdate) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_BordereauInsert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            stmtpsEngagementSearch.setString(1, "BE" + StringUtil.generatedID());
            if (dossier.getEngagementID() == null) {
                System.out.println(dossier.getEngagementID());
                stmtpsEngagementSearch.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(2, dossier.getEngagementID());
                System.out.println(dossier.getEngagementID());
            }
            if (bordereau == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, bordereau);
            }
            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(5, millesime);
            }
            // if (etatDossier == DialogOpenMode.transmiPourRegularite) {
            String num = "";

            if (dossier.getNumDossier() == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, dossier.getNumDossier());
            }

            if (dossier.getObjet() == null) {
                stmtpsEngagementSearch.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(7, dossier.getObjet());
            }
            if (dossier.getBeneficiaire() == null) {
                stmtpsEngagementSearch.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(8, dossier.getBeneficiaire());
            }

            stmtpsEngagementSearch.setBigDecimal(9, dossier.getMontant());

            stmtpsEngagementSearch.setInt(10, etatDossier);

            if (userUpdate == null) {
                stmtpsEngagementSearch.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(11, userUpdate);
            }

            if (dossier.getNumeroOP() == null) {
                stmtpsEngagementSearch.setString(12, "");
            } else {
                stmtpsEngagementSearch.setString(12, dossier.getNumeroOP());
            }

            stmtpsEngagementSearch.executeQuery();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public VueEngagementLivre getFicheDossier(String numDossier) {
        Connection con = null;
        VueEngagementLivre e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Fiche( ?)");

            if (numDossier == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, numDossier);
            }
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                e = new VueEngagementLivre();
                e.setLibelleFr(rs.getString("libelleFr"));
                e.setLibelleUs(rs.getString("libelleUs"));
                e.setMillesime(rs.getString("millesime"));
                e.setExercice(rs.getString("exercice"));
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCodeTache(rs.getString("codeTache"));
                e.setCompte(rs.getString("compte"));
                e.setCompteLibelle(rs.getString("compteLibelle"));
                e.setDateSignature(rs.getDate("dateSignature"));
                e.setSignataire(rs.getString("signataire"));
                e.setReference(rs.getString("reference"));
                e.setEtat(rs.getInt("etat"));
                e.setDateEnregistrement(rs.getDate("dateEnregistrement"));
                e.setLibelleTache(rs.getString("libelleTache"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                e.setStructure(rs.getString("structure"));
                e.setType(rs.getString("type"));
                e.setTypeID(rs.getInt("typeID"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bordereau> getBordereauTransmission(String organisationID, String millesime, String numBordereau, String numdossier, Date dateEnregDebut, Date dateEnregFin, int typeTransmission) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psBordereau_List(?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (numBordereau == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, numBordereau);
            }
            if (numdossier == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, numdossier);
            }
            if (dateEnregDebut == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(5, new java.sql.Date(dateEnregDebut.getTime()));
            }
            if (dateEnregFin == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(6, new java.sql.Date(dateEnregFin.getTime()));
            }
            stmtpsEngagementSearch.setInt(7, typeTransmission);

            List<Bordereau> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                Bordereau e = new Bordereau();
                e.setType(rs.getInt("type"));
                e.setAgent(rs.getString("agent"));
                e.setDateGeneration(rs.getDate("dateGeneration"));
                e.setDestination(rs.getString("destination"));
                e.setMillesime(rs.getString("millesime"));
                e.setNumBordereau(rs.getString("numBordereau"));
                e.setNumordre(rs.getString("numOrdre"));
                e.setOrganisationID(rs.getString("organisationID"));
                e.setSource(rs.getString("source"));
                e.setUserUpdate(rs.getString("user_update"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementDossier> getDossiersByNumBordereau(String numBordereau) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_SearchByNumBordereau(?)");

            if (numBordereau == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, numBordereau);
            }

            List<VueEngagementDossier> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementDossier e = new VueEngagementDossier();
                e.setType(rs.getInt("type"));
                e.setEngagementID(rs.getString("engagementID"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCompte(rs.getString("compte"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setEtatID(rs.getInt("etat"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bordereau> getBordereauTransmissionEnCours(String organisationID, String millesime, int typeTransmission) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psBordereau_EnCours_List(?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            stmtpsEngagementSearch.setInt(3, typeTransmission);

            List<Bordereau> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                Bordereau e = new Bordereau();
                e.setType(rs.getInt("type"));
                e.setAgent(rs.getString("agent"));
                e.setDateGeneration(rs.getDate("dateGeneration"));
                e.setDestination(rs.getString("destination"));
                e.setMillesime(rs.getString("millesime"));
                e.setNumBordereau(rs.getString("numBordereau"));
                e.setNumordre(rs.getString("numOrdre"));
                e.setOrganisationID(rs.getString("organisationID"));
                e.setSource(rs.getString("source"));
                e.setUserUpdate(rs.getString("user_update"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementDossier> getDossiersAtTypeTransmission(String organisationID, String millesime, String numBordereau, String numdossier, Date dateEnregDebut, Date dateEnregFin, int typeTransmission) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_AtTransmission_Search( ?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (numBordereau == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(3, numBordereau);
            }
            if (numdossier == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(4, numdossier);
            }
            if (dateEnregDebut == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(5, new java.sql.Date(dateEnregDebut.getTime()));
            }
            if (dateEnregFin == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.DATE);
            } else {
                stmtpsEngagementSearch.setDate(6, new java.sql.Date(dateEnregFin.getTime()));
            }
            stmtpsEngagementSearch.setInt(7, typeTransmission);

            List<VueEngagementDossier> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementDossier e = new VueEngagementDossier();
                e.setType(rs.getInt("type"));
                e.setEngagementID(rs.getString("engagementID"));
                e.setNumDossier(rs.getString("numDossier"));
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCompte(rs.getString("compte"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setEtatID(rs.getInt("etat"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void transmissionAnnulationEngagement(String organisationID, String millesime, String bordereau, VueEngagementDossier dossier, int etatDossier, String userUpdate) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_BordereauInsert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            stmtpsEngagementSearch.setString(1, "BE" + StringUtil.generatedID());
            if (dossier.getEngagementID() == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(2, dossier.getEngagementID());
            }
            if (bordereau == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, bordereau);
            }
            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(5, millesime);
            }

            if (dossier.getNumDossier() == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, dossier.getNumDossier());
            }
            if (dossier.getObjet() == null) {
                stmtpsEngagementSearch.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(7, dossier.getObjet());
            }
            if (dossier.getBeneficiaire() == null) {
                stmtpsEngagementSearch.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(8, dossier.getBeneficiaire());
            }

            stmtpsEngagementSearch.setBigDecimal(9, dossier.getMontant());

            stmtpsEngagementSearch.setInt(10, etatDossier);

            if (userUpdate == null) {
                stmtpsEngagementSearch.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(11, userUpdate);
            }

            if (dossier.getNumeroOP() == null) {
                stmtpsEngagementSearch.setString(12, "");
            } else {
                stmtpsEngagementSearch.setString(12, dossier.getNumeroOP());
            }

            stmtpsEngagementSearch.executeQuery();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String valider(String engagementID, boolean valider, String motif, String user) {
        Connection con = null;
        String captcha = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Valider( ?, ?, ?, ?, ?)");
            stmtpsEngagementSearch.registerOutParameter(5, java.sql.Types.VARCHAR);
            if (engagementID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, engagementID);
            }
            stmtpsEngagementSearch.setBoolean(2, valider);
            if (motif == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, motif);
            }
            if (user == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, user);
            }
            stmtpsEngagementSearch.setString(5, captcha);
            stmtpsEngagementSearch.executeQuery();
            captcha = stmtpsEngagementSearch.getString(5);

            return captcha;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String validerRegularite(String engagementID, boolean valider, String motif, String user) {
        Connection con = null;
        String captcha = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_ValiderRegularite( ?, ?, ?, ?, ?)");
            stmtpsEngagementSearch.registerOutParameter(5, java.sql.Types.VARCHAR);
            if (engagementID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, engagementID);
            }
            stmtpsEngagementSearch.setBoolean(2, valider);
            if (motif == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, motif);
            }
            if (user == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, user);
            }
            stmtpsEngagementSearch.setString(5, captcha);
            stmtpsEngagementSearch.executeQuery();
            captcha = stmtpsEngagementSearch.getString(5);

            return captcha;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void valider_annuler(String engagementID, String motif, String user) {
        Connection con = null;
        String captcha = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Valider_Annuler( ?, ?, ?)");
            if (engagementID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, engagementID);
            }
            if (motif == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(2, motif);
            }
            if (user == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(3, user);
            }

            stmtpsEngagementSearch.executeQuery();

        } catch (Exception ex) {

        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public VueEngagementState getEtatengagement(String numDossier) {

        Connection con = null;
        VueEngagementState e = new VueEngagementState();
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_Process( ?)");

            if (numDossier == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, numDossier);
            }

            e = new VueEngagementState();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {

                try {
                    e.setStateEngage(rs.getBoolean("stateEngage"));
                } catch (Exception ex) {
                }
                try {
                    e.setStateEngage(rs.getBoolean("stateLiquide"));
                } catch (Exception ex) {
                }
                try {
                    e.setStateEngage(rs.getBoolean("stateMandate"));
                } catch (Exception ex) {
                }
                try {
                    e.setStateEngage(rs.getBoolean("stateRegle"));
                } catch (Exception ex) {
                }
                try {
                    e.setDateEngage(rs.getDate("dateEngage"));
                } catch (Exception ex) {
                }
                try {
                    e.setDateEngage(rs.getDate("dateLiquide"));
                } catch (Exception ex) {
                }
                try {
                    e.setDateEngage(rs.getDate("dateMandate"));
                } catch (Exception ex) {
                }
                try {
                    e.setDateEngage(rs.getDate("dateRegle"));
                } catch (Exception ex) {
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public void liquidationEnregistrement(String userUpdate, String ipAdresse, String machine, String liquidationID,
            String engagementID, String objet, BigDecimal montantTVA, BigDecimal montantIR, BigDecimal montantNAP,
            BigDecimal montantRG, String beneficiaire, String pieces, String livrables) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psLiquidation_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (liquidationID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, liquidationID);
            }
            if (engagementID == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, engagementID);
            }

            if (objet == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, objet);
            }

            if (montantTVA == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(7, montantTVA);
            }
            if (montantIR == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(8, montantIR);
            }
            if (montantNAP == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(9, montantNAP);
            }
            if (montantRG == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(10, montantRG);
            }

            if (beneficiaire == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, beneficiaire);
            }
            if (pieces == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.BLOB);
            } else {
                stmtpsEngagementInsert.setString(12, pieces);
            }
            if (livrables == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.BLOB);
            } else {
                stmtpsEngagementInsert.setString(13, livrables);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void liquidationModifier(String userUpdate, String ipAdresse, String machine, String liquidationID, String engagementID, String objet, BigDecimal montantTVA, BigDecimal montantIR, BigDecimal montantNAP, BigDecimal montantRG, String beneficiaire, String pieces, String livrables) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psLiquidation_Modifier( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (liquidationID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, liquidationID);
            }
            if (engagementID == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, engagementID);
            }

            if (objet == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, objet);
            }

            if (montantTVA == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(7, montantTVA);
            }
            if (montantIR == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(8, montantIR);
            }
            if (montantNAP == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(9, montantNAP);
            }
            if (montantRG == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(10, montantRG);
            }

            if (beneficiaire == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, beneficiaire);
            }
            if (pieces == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.BLOB);
            } else {
                stmtpsEngagementInsert.setString(12, pieces);
            }
            if (livrables == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.BLOB);
            } else {
                stmtpsEngagementInsert.setString(13, livrables);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void liquidationSupprimer(String userUpdate, String ipAdresse, String machine, String liquidationID) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psLiquidation_Supprimer( ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (liquidationID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, liquidationID);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void liquidationValider(String userUpdate, String ipAdresse, String machine, String liquidationID, String observations, boolean isValidation, String engagementID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psLiquidation_Valider( ?, ?, ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, machine);
            }
            if (liquidationID == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, liquidationID);
            }
            if (observations == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, observations);
            }

            stmt.setBoolean(6, isValidation);

            if (engagementID == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, engagementID);
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Liquidation liquidationFind(String liquidationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psLiquidation_Find( ?)");

            if (liquidationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, liquidationID);
            }
            Liquidation e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new Liquidation();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setEngagementID(rs.getString("engagementID"));
                if (rs.wasNull()) {
                    e.setEngagementID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setDateLiquidation(rs.getDate("dateLiquidation"));
                if (rs.wasNull()) {
                    e.setDateLiquidation(null);
                }
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTVA(rs.getBigDecimal("montantTVA"));

                e.setMontantIR(rs.getBigDecimal("montantIR"));

                e.setMontantNAP(rs.getBigDecimal("montantNAP"));

                e.setMontantRG(rs.getBigDecimal("montantRG"));

                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setLivrables(rs.getString("livrables"));
                if (rs.wasNull()) {
                    e.setLivrables(null);
                }
                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setUserValidation(rs.getString("userValidation"));
                if (rs.wasNull()) {
                    e.setUserValidation(null);
                }
                e.setObsValidation(rs.getString("obsValidation"));
                if (rs.wasNull()) {
                    e.setObsValidation(null);
                }
                e.setDateRejet(rs.getDate("dateRejet"));
                if (rs.wasNull()) {
                    e.setDateRejet(null);
                }
                e.setUserRejet(rs.getString("userRejet"));
                if (rs.wasNull()) {
                    e.setUserRejet(null);
                }
                e.setMotifRejet(rs.getString("motifRejet"));
                if (rs.wasNull()) {
                    e.setMotifRejet(null);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();

            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liquidation> liquidationByEngagement(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psLiquidation_ListByEngagement( ?)");

            if (engagementID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, engagementID);
            }

            List<Liquidation> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liquidation e = new Liquidation();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setEngagementID(rs.getString("engagementID"));
                if (rs.wasNull()) {
                    e.setEngagementID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setDateLiquidation(rs.getDate("dateLiquidation"));
                if (rs.wasNull()) {
                    e.setDateLiquidation(null);
                }
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTVA(rs.getBigDecimal("montantTVA"));

                e.setMontantIR(rs.getBigDecimal("montantIR"));

                e.setMontantNAP(rs.getBigDecimal("montantNAP"));

                e.setMontantRG(rs.getBigDecimal("montantRG"));

                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setLivrables(rs.getString("livrables"));
                if (rs.wasNull()) {
                    e.setLivrables(null);
                }
                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setUserValidation(rs.getString("userValidation"));
                if (rs.wasNull()) {
                    e.setUserValidation(null);
                }
                e.setObsValidation(rs.getString("obsValidation"));
                if (rs.wasNull()) {
                    e.setObsValidation(null);
                }
                e.setDateRejet(rs.getDate("dateRejet"));
                if (rs.wasNull()) {
                    e.setDateRejet(null);
                }
                e.setUserRejet(rs.getString("userRejet"));
                if (rs.wasNull()) {
                    e.setUserRejet(null);
                }
                e.setMotifRejet(rs.getString("motifRejet"));
                if (rs.wasNull()) {
                    e.setMotifRejet(null);
                }

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();

            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liquidation> liquidationByEtat(String engagementID, int etat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psLiquidation_ListByEtat( ?, ?)");

            if (engagementID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, engagementID);
            }
            stmt.setInt(2, etat);

            List<Liquidation> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liquidation e = new Liquidation();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setEngagementID(rs.getString("engagementID"));
                if (rs.wasNull()) {
                    e.setEngagementID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setDateLiquidation(rs.getDate("dateLiquidation"));
                if (rs.wasNull()) {
                    e.setDateLiquidation(null);
                }
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTVA(rs.getBigDecimal("montantTVA"));

                e.setMontantIR(rs.getBigDecimal("montantIR"));

                e.setMontantNAP(rs.getBigDecimal("montantNAP"));

                e.setMontantRG(rs.getBigDecimal("montantRG"));

                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setLivrables(rs.getString("livrables"));
                if (rs.wasNull()) {
                    e.setLivrables(null);
                }
                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setUserValidation(rs.getString("userValidation"));
                if (rs.wasNull()) {
                    e.setUserValidation(null);
                }
                e.setObsValidation(rs.getString("obsValidation"));
                if (rs.wasNull()) {
                    e.setObsValidation(null);
                }
                e.setDateRejet(rs.getDate("dateRejet"));
                if (rs.wasNull()) {
                    e.setDateRejet(null);
                }
                e.setUserRejet(rs.getString("userRejet"));
                if (rs.wasNull()) {
                    e.setUserRejet(null);
                }
                e.setMotifRejet(rs.getString("motifRejet"));
                if (rs.wasNull()) {
                    e.setMotifRejet(null);
                }

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();

            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void liquidationValiderAnnuler(String userUpdate, String ipAdresse, String machine, String liquidationID, String observations, String engagementID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psLiquidation_ValiderAnnuler( ?, ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, machine);
            }
            if (liquidationID == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, liquidationID);
            }
            if (observations == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, observations);
            }

            if (engagementID == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, engagementID);
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liquidation> liquidationByEtatOnly(String organisationID, String millesime, String numdossier, String etat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psLiquidation_ListByEtatOnly( ?, ?, ?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (numdossier == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, numdossier);
            }
            stmt.setString(4, etat);

            List<Liquidation> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liquidation e = new Liquidation();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setEngagementID(rs.getString("engagementID"));
                if (rs.wasNull()) {
                    e.setEngagementID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setDateLiquidation(rs.getDate("dateLiquidation"));
                if (rs.wasNull()) {
                    e.setDateLiquidation(null);
                }
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));

                e.setMontantTVA(rs.getBigDecimal("montantTVA"));

                e.setMontantIR(rs.getBigDecimal("montantIR"));

                e.setMontantNAP(rs.getBigDecimal("montantNAP"));

                e.setMontantRG(rs.getBigDecimal("montantRG"));

                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setLivrables(rs.getString("livrables"));
                if (rs.wasNull()) {
                    e.setLivrables(null);
                }
                e.setDateValidation(rs.getDate("dateValidation"));
                if (rs.wasNull()) {
                    e.setDateValidation(null);
                }
                e.setUserValidation(rs.getString("userValidation"));
                if (rs.wasNull()) {
                    e.setUserValidation(null);
                }
                e.setObsValidation(rs.getString("obsValidation"));
                if (rs.wasNull()) {
                    e.setObsValidation(null);
                }
                e.setDateRejet(rs.getDate("dateRejet"));
                if (rs.wasNull()) {
                    e.setDateRejet(null);
                }
                e.setUserRejet(rs.getString("userRejet"));
                if (rs.wasNull()) {
                    e.setUserRejet(null);
                }
                e.setMotifRejet(rs.getString("motifRejet"));
                if (rs.wasNull()) {
                    e.setMotifRejet(null);
                }
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                    if (rs.wasNull()) {
                        e.setNumDossier("");
                    }
                } catch (Exception s) {
                }

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();

            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class
                        .getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void MandatementEnregistrement(String userUpdate, String ipAdresse, String machine, String mandatementID, String liquidationID, String ordonnateur, BigDecimal montantMandate, String rib, String numeroOP, String objet) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psMandatement_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, mandatementID);
            }
            if (liquidationID == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, liquidationID);
            }

            if (ordonnateur == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, ordonnateur);
            }

            if (montantMandate == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(7, montantMandate);
            }

            if (rib == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, rib);
            }
            if (numeroOP == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, numeroOP);
            }
            if (objet == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(10, objet);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void MandatementModifier(String userUpdate, String ipAdresse, String machine, String mandatementID, String ordonnateur, String rib, String numeroOP, String objet) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psMandatement_Modifier( ?, ?, ?, ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, mandatementID);
            }
            if (ordonnateur == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, ordonnateur);
            }

            if (rib == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, rib);
            }

            if (numeroOP == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(7, numeroOP);
            }
            if (objet == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, objet);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void MandatementSupprimer(String userUpdate, String ipAdresse, String machine, String mandatementID) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psMandatement_Delete( ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, mandatementID);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Mandatement MandatementFind(String mandatementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatement_Find( ?)");

            if (mandatementID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, mandatementID);
            }
            Mandatement e = null;

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new Mandatement();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    e.setMandatementID(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setOrdonnateur(rs.getString("ordonnateur"));
                if (rs.wasNull()) {
                    e.setOrdonnateur(null);
                }
                e.setMontantMandate(rs.getBigDecimal("montantMandate"));
                if (rs.wasNull()) {
                    e.setMontantMandate(null);
                }
                e.setDateMandatement(rs.getDate("dateMandatement"));
                if (rs.wasNull()) {
                    e.setDateMandatement(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                if (rs.wasNull()) {
                    e.setMontantTVA(null);
                }
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                if (rs.wasNull()) {
                    e.setMontantIR(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setDateControleRegularite(rs.getDate("dateControleRegularite"));
                if (rs.wasNull()) {
                    e.setDateControleRegularite(null);
                }
                e.setUserControleReg(rs.getString("userControleReg"));
                if (rs.wasNull()) {
                    e.setUserControleReg(null);
                }
                e.setObsControleReg(rs.getString("obsControleReg"));
                if (rs.wasNull()) {
                    e.setObsControleReg(null);
                }
                e.setNumDossier(rs.getString("numDossier"));
                if (rs.wasNull()) {
                    e.setNumDossier(null);
                }
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Mandatement> MandatementFindByLiquidation(String liquidationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatement_FindByLiquidation( ?)");

            if (liquidationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, liquidationID);
            }
            List<Mandatement> list = new ArrayList<>();

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Mandatement e = new Mandatement();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    e.setMandatementID(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setOrdonnateur(rs.getString("ordonnateur"));
                if (rs.wasNull()) {
                    e.setOrdonnateur(null);
                }
                e.setMontantMandate(rs.getBigDecimal("montantMandate"));
                if (rs.wasNull()) {
                    e.setMontantMandate(null);
                }
                e.setDateMandatement(rs.getDate("dateMandatement"));
                if (rs.wasNull()) {
                    e.setDateMandatement(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                if (rs.wasNull()) {
                    e.setMontantTVA(null);
                }
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                if (rs.wasNull()) {
                    e.setMontantIR(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setDateControleRegularite(rs.getDate("dateControleRegularite"));
                if (rs.wasNull()) {
                    e.setDateControleRegularite(null);
                }
                e.setUserControleReg(rs.getString("userControleReg"));
                if (rs.wasNull()) {
                    e.setUserControleReg(null);
                }
                e.setObsControleReg(rs.getString("obsControleReg"));
                if (rs.wasNull()) {
                    e.setObsControleReg(null);
                }
                e.setNumDossier(rs.getString("numDossier"));
                if (rs.wasNull()) {
                    e.setNumDossier(null);
                }
                e.setNumeroOP(rs.getString("numeroOP"));

                e.setObjet(rs.getString("objet"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Mandatement> MandatementEnCours() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatement_EnCours( )");

            List<Mandatement> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Mandatement e = new Mandatement();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    e.setMandatementID(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setOrdonnateur(rs.getString("ordonnateur"));
                if (rs.wasNull()) {
                    e.setOrdonnateur(null);
                }
                e.setMontantMandate(rs.getBigDecimal("montantMandate"));
                if (rs.wasNull()) {
                    e.setMontantMandate(null);
                }
                e.setDateMandatement(rs.getDate("dateMandatement"));
                if (rs.wasNull()) {
                    e.setDateMandatement(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                if (rs.wasNull()) {
                    e.setMontantTVA(null);
                }
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                if (rs.wasNull()) {
                    e.setMontantIR(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setDateControleRegularite(rs.getDate("dateControleRegularite"));
                if (rs.wasNull()) {
                    e.setDateControleRegularite(null);
                }
                e.setUserControleReg(rs.getString("userControleReg"));
                if (rs.wasNull()) {
                    e.setUserControleReg(null);
                }
                e.setObsControleReg(rs.getString("obsControleReg"));
                if (rs.wasNull()) {
                    e.setObsControleReg(null);
                }
                e.setNumDossier(rs.getString("numDossier"));
                if (rs.wasNull()) {
                    e.setNumDossier(null);
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Mandatement> MandatementByEtat(String organisationID, String millesime, String numdossier, String etat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatement_FindByEtat( ?, ?, ?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (numdossier == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, numdossier);
            }
            if (etat == null) {
                stmt.setNull(4, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(4, Integer.valueOf(etat));
            }

            List<Mandatement> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Mandatement e = new Mandatement();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    e.setMandatementID(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setOrdonnateur(rs.getString("ordonnateur"));
                if (rs.wasNull()) {
                    e.setOrdonnateur(null);
                }
                e.setMontantMandate(rs.getBigDecimal("montantMandate"));
                if (rs.wasNull()) {
                    e.setMontantMandate(null);
                }
                e.setDateMandatement(rs.getDate("dateMandatement"));
                if (rs.wasNull()) {
                    e.setDateMandatement(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                if (rs.wasNull()) {
                    e.setMontantTVA(null);
                }
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                if (rs.wasNull()) {
                    e.setMontantIR(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setDateControleRegularite(rs.getDate("dateControleRegularite"));
                if (rs.wasNull()) {
                    e.setDateControleRegularite(null);
                }
                e.setUserControleReg(rs.getString("userControleReg"));
                if (rs.wasNull()) {
                    e.setUserControleReg(null);
                }
                e.setObsControleReg(rs.getString("obsControleReg"));
                if (rs.wasNull()) {
                    e.setObsControleReg(null);
                }
                e.setNumDossier(rs.getString("numDossier"));
                if (rs.wasNull()) {
                    e.setNumDossier(null);
                }
                e.setNumeroOP(rs.getString("numeroOP"));

                e.setObjet(rs.getString("objet"));

                e.setDetails(etat);

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Mandatement> MandatementByEtatRubriques(String organisationID, String millesime, String numdossier, String etat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatement_FindByEtatRubrique( ?, ?, ?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (numdossier == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, numdossier);
            }
            if (etat == null) {
                stmt.setNull(4, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(4, Integer.valueOf(etat));
            }

            List<Mandatement> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Mandatement e = new Mandatement();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    e.setMandatementID(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setOrdonnateur(rs.getString("ordonnateur"));
                if (rs.wasNull()) {
                    e.setOrdonnateur(null);
                }
                e.setMontantMandate(rs.getBigDecimal("montantMandate"));
                if (rs.wasNull()) {
                    e.setMontantMandate(null);
                }
                e.setDateMandatement(rs.getDate("dateMandatement"));
                if (rs.wasNull()) {
                    e.setDateMandatement(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                if (rs.wasNull()) {
                    e.setMontantTVA(null);
                }
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                if (rs.wasNull()) {
                    e.setMontantIR(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setDateControleRegularite(rs.getDate("dateControleRegularite"));
                if (rs.wasNull()) {
                    e.setDateControleRegularite(null);
                }
                e.setUserControleReg(rs.getString("userControleReg"));
                if (rs.wasNull()) {
                    e.setUserControleReg(null);
                }
                e.setObsControleReg(rs.getString("obsControleReg"));
                if (rs.wasNull()) {
                    e.setObsControleReg(null);
                }
                e.setNumDossier(rs.getString("numDossier"));
                if (rs.wasNull()) {
                    e.setNumDossier(null);
                }
                e.setNumeroOP(rs.getString("numeroOP"));

                e.setObjet(rs.getString("objet"));

                e.setDetails(etat);

                try {
                    e.setRubriqueID(rs.getString("rubriqueID"));
                } catch (Exception ef) {
                }
                try {
                    e.setRubrique(rs.getString("rubrique"));
                } catch (Exception ef) {
                }
                try {
                    e.setRubriqueMontant(rs.getBigDecimal("rubriqueMontant"));
                } catch (Exception ef) {
                }
                try {
                    e.setCompteCredit(rs.getString("compteCredit"));
                } catch (Exception ef) {
                }
                try {
                    e.setCompteDebit(rs.getString("compteDebit"));
                } catch (Exception ef) {
                }
                try {
                    e.setJournalID(rs.getString("journalID"));
                } catch (Exception ef) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Mandatement> MandatementByEtatRubriquesPaiement(String organisationID, String millesime, String numdossier, String etat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psMandatement_FindByEtatRubriquePaiement( ?, ?, ?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (millesime == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, millesime);
            }
            if (numdossier == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, numdossier);
            }
            if (etat == null) {
                stmt.setNull(4, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(4, Integer.valueOf(etat));
            }

            List<Mandatement> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Mandatement e = new Mandatement();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setMachine(rs.getString("machine"));
                if (rs.wasNull()) {
                    e.setMachine(null);
                }
                e.setMandatementID(rs.getString("mandatementID"));
                if (rs.wasNull()) {
                    e.setMandatementID(null);
                }
                e.setLiquidationID(rs.getString("liquidationID"));
                if (rs.wasNull()) {
                    e.setLiquidationID(null);
                }
                e.setNumOrdre(rs.getInt("numOrdre"));

                e.setEtat(rs.getInt("etat"));

                e.setOrdonnateur(rs.getString("ordonnateur"));
                if (rs.wasNull()) {
                    e.setOrdonnateur(null);
                }
                e.setMontantMandate(rs.getBigDecimal("montantMandate"));
                if (rs.wasNull()) {
                    e.setMontantMandate(null);
                }
                e.setDateMandatement(rs.getDate("dateMandatement"));
                if (rs.wasNull()) {
                    e.setDateMandatement(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                if (rs.wasNull()) {
                    e.setMontantTVA(null);
                }
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                if (rs.wasNull()) {
                    e.setMontantIR(null);
                }
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                if (rs.wasNull()) {
                    e.setMontantNAP(null);
                }
                e.setMontantRG(rs.getBigDecimal("montantRG"));
                if (rs.wasNull()) {
                    e.setMontantRG(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setPieces(rs.getString("pieces"));
                if (rs.wasNull()) {
                    e.setPieces(null);
                }
                e.setRib(rs.getString("rib"));
                if (rs.wasNull()) {
                    e.setRib(null);
                }
                e.setDateControleRegularite(rs.getDate("dateControleRegularite"));
                if (rs.wasNull()) {
                    e.setDateControleRegularite(null);
                }
                e.setUserControleReg(rs.getString("userControleReg"));
                if (rs.wasNull()) {
                    e.setUserControleReg(null);
                }
                e.setObsControleReg(rs.getString("obsControleReg"));
                if (rs.wasNull()) {
                    e.setObsControleReg(null);
                }
                e.setNumDossier(rs.getString("numDossier"));
                if (rs.wasNull()) {
                    e.setNumDossier(null);
                }
                e.setNumeroOP(rs.getString("numeroOP"));

                e.setObjet(rs.getString("objet"));

                e.setDetails(etat);

                try {
                    e.setRubriqueID(rs.getString("rubriqueID"));
                } catch (Exception ef) {
                }
                try {
                    e.setRubrique(rs.getString("rubrique"));
                } catch (Exception ef) {
                }
                try {
                    e.setRubriqueMontant(rs.getBigDecimal("rubriqueMontant"));
                } catch (Exception ef) {
                }
                try {
                    e.setCompteCredit(rs.getString("compteCredit"));
                } catch (Exception ef) {
                }
                try {
                    e.setCompteDebit(rs.getString("compteDebit"));
                } catch (Exception ef) {
                }
                try {
                    e.setJournalID(rs.getString("journalID"));
                } catch (Exception ef) {
                }
                try {
                    e.setReglementEnCours(rs.getBigDecimal("reglementEnCours"));
                } catch (Exception ef) {
                }
                try {
                    e.setReglementRestant(rs.getBigDecimal("reglementRestant"));
                } catch (Exception ef) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void MandatementValider(String userUpdate, String ipAdresse, String machine, String mandatementID, String pieces) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psMandatement_Valider( ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, mandatementID);
            }
            if (pieces == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, pieces);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void MandatementValiderAnnuler(String userUpdate, String ipAdresse, String machine, String mandatementID, String motif) throws GrecoException {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psMandatement_ValiderAnnuler( ?, ?, ?, ?, ?)");

            if (userUpdate == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, userUpdate);
            }
            if (ipAdresse == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, ipAdresse);
            }
            if (machine == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, machine);
            }
            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, mandatementID);
            }
            if (motif == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, motif);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int MandatementLiasseAjouter(String mandatementID, List<String> liasses, String userUpdate, String ipUpdate) throws GrecoException {
        Connection con = null;
        int nbInserted = 0;
        try {

            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psMandatementLiasse_Insert(?, ?, ?, ?)");
            for (String liasseID : liasses) {
                if (userUpdate == null) {
                    stmt.setNull(1, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(1, userUpdate);
                }
                if (ipUpdate == null) {
                    stmt.setNull(2, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(2, ipUpdate);
                }
                if (liasseID == null) {
                    stmt.setNull(3, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(3, liasseID);
                }
                if (mandatementID == null) {
                    stmt.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    stmt.setString(4, mandatementID);
                }

                try {
                    stmt.executeQuery();
                    nbInserted++;
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("******MandatementLiasseAjouter liasse erreur save one *******");
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(DroitsDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return nbInserted;
    }

    @Override
    public void MandatementLiasseSupprimer(String mandatementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psMandatementLiasse_Delete(?)");
            stmt.setString(1, mandatementID);
            stmt.executeQuery();
        } catch (SQLException ex) {
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liasse> MandatementLiasseListe(String mandatementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psMandatementLiasse_List(?)");
            stmt.setString(1, mandatementID);
            stmt.executeQuery();

            List<Liasse> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liasse o = new Liasse();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setLiasseID(rs.getString("liasseID"));
                if (rs.wasNull()) {
                    o.setLiasseID(null);
                }
                o.setTypeID(rs.getString("typeID"));
                if (rs.wasNull()) {
                    o.setTypeID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liasse> MandatementLiasseListeComplete(String mandatementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasseMandatement_List( ? )");

            stmt.setString(1, mandatementID);

            List<Liasse> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liasse o = new Liasse();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setLiasseID(rs.getString("liasseID"));
                if (rs.wasNull()) {
                    o.setLiasseID(null);
                }
                o.setTypeID(rs.getString("typeID"));
                if (rs.wasNull()) {
                    o.setTypeID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public VueControle controle(String id, String libelle, int type, int controleID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psEngagementControle(?, ?, ?, ?)");

            if (id == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, id);
            }
            stmt.setString(2, libelle);
            stmt.setInt(3, type);
            stmt.setInt(4, controleID);

            VueControle e = null;

            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new VueControle();

                e.setLibelle(rs.getString("libelle"));
                if (rs.wasNull()) {
                    e.setLibelle(null);
                }
                e.setObservations(rs.getString("observations"));
                if (rs.wasNull()) {
                    e.setObservations(null);
                }
                e.setResult(rs.getInt("result"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            System.out.println("Controle " + controleID);
            ex.printStackTrace();
            return new VueControle(libelle, "Impossible d'effectuer ce controle. Problème technique", VueControle.ECHEC);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void demandeLevee(String id, int type, VueControle vue, String userDemande) {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagement_DemandeLevee( ?, ?, ?, ?, ?, ?, ?, ?)");

            stmtpsEngagementInsert.setString(1, "DLV" + StringUtil.generatedID());

            if (id == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, id);
            }

            stmtpsEngagementInsert.setInt(3, type);
            stmtpsEngagementInsert.setInt(4, vue.getNumeroControle());

            if (vue.getLibelle() == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, vue.getLibelle());
            }
            if (vue.getObservations() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, vue.getObservations());
            }
            if (vue.getMotifLevee() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(7, vue.getMotifLevee());
            }
            if (userDemande == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, userDemande);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void leveeDemande(String id, int type, int numeroControle, String userLevee) {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagement_LeveeDemande( ?, ?, ?, ?)");

            stmtpsEngagementInsert.setString(1, id);
            stmtpsEngagementInsert.setInt(2, type);
            stmtpsEngagementInsert.setInt(3, numeroControle);
            stmtpsEngagementInsert.setString(1, userLevee);

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void deleteDemandeLevee(String id, int type) {
        Connection con = null;

        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagement_DemandeDelete( ?, ?)");

            stmtpsEngagementInsert.setString(1, id);
            stmtpsEngagementInsert.setInt(2, type);

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ajouterLiasse(Liasse pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasse_Insert(?, ?, ?, ?, ?, ?)");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getLiasseID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getLiasseID());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getLibelleUs());
            }
            if (pc.getTypeID() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, pc.getTypeID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierLiasse(Liasse pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasse_Update(?, ?, ?, ?, ?, ?)");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getLiasseID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getLiasseID());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getLibelleUs());
            }
            if (pc.getTypeID() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, pc.getTypeID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerLiasse(String liasseID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasse_Delete(?)");
            stmt.setString(1, liasseID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liasse> getLiasse() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasse_List()");

            List<Liasse> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liasse o = new Liasse();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }

                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }

                o.setLiasseID(rs.getString("liasseID"));
                if (rs.wasNull()) {
                    o.setLiasseID(null);
                }

                o.setTypeID(rs.getString("typeID"));
                if (rs.wasNull()) {
                    o.setTypeID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liasse> getLiasse(String mandatementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasseMandatement_List( ? )");

            stmt.setString(1, mandatementID);

            List<Liasse> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liasse o = new Liasse();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setLiasseID(rs.getString("liasseID"));
                if (rs.wasNull()) {
                    o.setLiasseID(null);
                }
                o.setTypeID(rs.getString("typeID"));
                if (rs.wasNull()) {
                    o.setTypeID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Liasse> getLiasseByEngagement(String engagementID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLiasseEngagement_List( ? )");

            stmt.setString(1, engagementID);

            List<Liasse> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Liasse o = new Liasse();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }

                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }

                o.setLiasseID(rs.getString("liasseID"));
                if (rs.wasNull()) {
                    o.setLiasseID(null);
                }

                o.setTypeID(rs.getString("typeID"));
                if (rs.wasNull()) {
                    o.setTypeID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementDossier> getMandatements(String organisationID, String millesime, String numdossier, String etat, String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin, Date dateValidDebut, Date dateValidFin, String beneficiare) {
        {
            Connection con = null;
            try {
                con = dataSource.getConnection();
                CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psMandatement_Search( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

                if (organisationID == null) {
                    stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
                } else {
                    stmtpsEngagementSearch.setString(1, organisationID);
                }
                if (millesime == null) {
                    stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
                } else {
                    stmtpsEngagementSearch.setString(2, millesime);
                }
                if (numdossier == null) {
                    stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
                } else {
                    stmtpsEngagementSearch.setString(3, numdossier);
                }
                if (etat == null) {
                    stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
                } else {
                    stmtpsEngagementSearch.setString(4, etat);
                }
                if (engagementType == null) {
                    stmtpsEngagementSearch.setNull(5, java.sql.Types.VARCHAR);
                } else {
                    stmtpsEngagementSearch.setString(5, engagementType);
                }
                if (cpte == null) {
                    stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
                } else {
                    stmtpsEngagementSearch.setString(6, cpte);
                }
                if (dateEnregDebut == null) {
                    stmtpsEngagementSearch.setNull(7, java.sql.Types.DATE);
                } else {
                    stmtpsEngagementSearch.setDate(7, new java.sql.Date(dateEnregDebut.getTime()));
                }
                if (dateEnregFin == null) {
                    stmtpsEngagementSearch.setNull(8, java.sql.Types.DATE);
                } else {
                    stmtpsEngagementSearch.setDate(8, new java.sql.Date(dateEnregFin.getTime()));
                }
                if (dateValidDebut == null) {
                    stmtpsEngagementSearch.setNull(9, java.sql.Types.DATE);
                } else {
                    stmtpsEngagementSearch.setDate(9, new java.sql.Date(dateValidDebut.getTime()));
                }
                if (dateValidFin == null) {
                    stmtpsEngagementSearch.setNull(10, java.sql.Types.DATE);
                } else {
                    stmtpsEngagementSearch.setDate(10, new java.sql.Date(dateValidFin.getTime()));
                }
                if (beneficiare == null) {
                    stmtpsEngagementSearch.setNull(11, java.sql.Types.VARCHAR);
                } else {
                    stmtpsEngagementSearch.setString(11, beneficiare);
                }

                List<VueEngagementDossier> list = new ArrayList<>();
                ResultSet rs = stmtpsEngagementSearch.executeQuery();
                while (rs.next()) {
                    VueEngagementDossier e = new VueEngagementDossier();
                    e.setType(rs.getInt("type"));
                    e.setEngagementID(rs.getString("engagementID"));
                    e.setNumDossier(rs.getString("numDossier"));
                    e.setObjet(rs.getString("objet"));
                    if (rs.wasNull()) {
                        e.setObjet(null);
                    }
                    e.setBeneficiaire(rs.getString("beneficiaire"));
                    e.setCompte(rs.getString("compte"));
                    e.setMontant(rs.getBigDecimal("montant"));
                    e.setEtatID(rs.getInt("etat"));

                    try {
                        e.setBcaID(rs.getString("bcaID"));
                    } catch (Exception ea) {
                    }
                    try {
                        e.setOmID(rs.getString("omID"));
                    } catch (Exception ea) {
                    }
                    try {
                        e.setDecisionID(rs.getString("decisionID"));
                    } catch (Exception ea) {
                    }
                    try {
                        e.setLettreCommandeID(rs.getString("lettreCommandeID"));
                    } catch (Exception ea) {
                    }
                    try {
                        e.setMarcheID(rs.getString("marcheID"));
                    } catch (Exception ea) {
                    }

                    try {
                        e.setOrganisationID(rs.getString("organisationID"));
                    } catch (Exception ea) {
                    }
                    try {
                        e.setNumeroOP(rs.getString("numeroOP"));
                    } catch (Exception ex) {
                    }

                    list.add(e);
                }
                rs.close();
                return list;
            } catch (Exception ex) {
                return null;
            } finally {
                try {
                    con.close();
                } catch (Exception ex) {
                    Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

    @Override
    public String ajouterPipe(Engagement e) throws GrecoException {
        Connection con = null;
        String numDossier = null;
        con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagementPipe_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getLastUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(1, new java.sql.Date(e.getLastUpdate().getTime()));
            }
            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getIpUpdate());
            }
            if (e.getEngagementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getEngagementID());
            }

            stmtpsEngagementInsert.setInt(5, e.getEtat());

            if (e.getObjet() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, e.getObjet());
            }

            if (e.getMontantTTC() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(7, e.getMontantTTC());
            }
            if (e.getBeneficiaire() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getBeneficiaire());
            }
            if (e.getFournisseurID() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, e.getFournisseurID());
            }
            if (e.getMatricule() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(10, e.getMatricule());
            }
            if (e.getStructureBenefID() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, e.getStructureBenefID());
            }
            if (e.getTacheID() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(12, e.getTacheID());
            }
            if (e.getOrganisationID() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(13, e.getOrganisationID());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(14, e.getMillesime());
            }
            if (e.getActiviteID() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(15, e.getActiviteID());
            }
            if (e.getTypeID() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(16, e.getTypeID());
            }
            if (e.getStructureID() == null) {
                stmtpsEngagementInsert.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(17, e.getStructureID());
            }
            stmtpsEngagementInsert.setBoolean(18, e.isDepassement());

            if (e.getNumeroOPNet() == null) {
                stmtpsEngagementInsert.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(19, e.getNumeroOPNet());
            }

            if (e.getNumeroOPTaxe() == null) {
                stmtpsEngagementInsert.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(20, e.getNumeroOPTaxe());
            }
            if (e.getMontantNet() == null) {
                stmtpsEngagementInsert.setNull(21, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(21, e.getMontantNet());
            }
            if (e.getMontantTaxe() == null) {
                stmtpsEngagementInsert.setNull(22, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(22, e.getMontantTaxe());
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(23, e.getReference());
            }

            stmtpsEngagementInsert.executeUpdate();

            return "";

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierPipe(Engagement e) throws GrecoException {
        Connection con = null;
        String numDossier = null;
        con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagementPipe_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getLastUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(1, new java.sql.Date(e.getLastUpdate().getTime()));
            }
            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getIpUpdate());
            }
            if (e.getEngagementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getEngagementID());
            }

            stmtpsEngagementInsert.setInt(5, e.getEtat());

            if (e.getObjet() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, e.getObjet());
            }

            if (e.getMontantTTC() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(7, e.getMontantTTC());
            }
            if (e.getBeneficiaire() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getBeneficiaire());
            }
            if (e.getFournisseurID() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, e.getFournisseurID());
            }
            if (e.getMatricule() == null) {
                stmtpsEngagementInsert.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(10, e.getMatricule());
            }
            if (e.getStructureBenefID() == null) {
                stmtpsEngagementInsert.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(11, e.getStructureBenefID());
            }
            if (e.getTacheID() == null) {
                stmtpsEngagementInsert.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(12, e.getTacheID());
            }
            if (e.getOrganisationID() == null) {
                stmtpsEngagementInsert.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(13, e.getOrganisationID());
            }
            if (e.getMillesime() == null) {
                stmtpsEngagementInsert.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(14, e.getMillesime());
            }
            if (e.getActiviteID() == null) {
                stmtpsEngagementInsert.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(15, e.getActiviteID());
            }
            if (e.getTypeID() == null) {
                stmtpsEngagementInsert.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(16, e.getTypeID());
            }
            if (e.getStructureID() == null) {
                stmtpsEngagementInsert.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(17, e.getStructureID());
            }
            stmtpsEngagementInsert.setBoolean(18, e.isDepassement());

            if (e.getNumeroOPNet() == null) {
                stmtpsEngagementInsert.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(19, e.getNumeroOPNet());
            }

            if (e.getNumeroOPTaxe() == null) {
                stmtpsEngagementInsert.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(20, e.getNumeroOPTaxe());
            }
            if (e.getMontantNet() == null) {
                stmtpsEngagementInsert.setNull(21, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(21, e.getMontantNet());
            }
            if (e.getMontantTaxe() == null) {
                stmtpsEngagementInsert.setNull(22, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(22, e.getMontantTaxe());
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(23, e.getReference());
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerPipe(String engagementPipeID, String user, String ipAdresse) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementDelete = con.prepareCall("CALL psEngagementPipe_Delete( ?, ?, ?)");

            if (engagementPipeID == null) {
                stmtpsEngagementDelete.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(1, engagementPipeID);
            }
            if (user == null) {
                stmtpsEngagementDelete.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(2, user);
            }
            if (ipAdresse == null) {
                stmtpsEngagementDelete.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementDelete.setString(3, ipAdresse);
            }

            stmtpsEngagementDelete.executeUpdate();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEngagementDossier> getEngagementPipe(String millesime, String organisationID, String programmeID, String operationID, String typeID, String beneficiaire, int nbJours, boolean isPipe) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagementPipe_Search( ?, ?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (programmeID == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(3, programmeID);
            }
            if (operationID == null) {
                stmtpsEngagementSearch.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(4, operationID);
            }
            if (typeID == null) {
                stmtpsEngagementSearch.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(5, typeID);
            }
            if (beneficiaire == null) {
                stmtpsEngagementSearch.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(6, beneficiaire);
            }

            stmtpsEngagementSearch.setInt(7, nbJours);

            stmtpsEngagementSearch.setBoolean(8, isPipe);

            List<VueEngagementDossier> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();
            while (rs.next()) {
                VueEngagementDossier e = new VueEngagementDossier();
                e.setType(rs.getInt("type"));
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setEngagementID(rs.getString("engagementPipeID"));
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setCompte(rs.getString("compte"));
                e.setMontant(rs.getBigDecimal("montant"));
                e.setEtatID(rs.getInt("etat"));
                try {
                    e.setMillesime(rs.getString("millesime"));
                } catch (Exception ea) {
                }
                try {
                    e.setOrganisationID(rs.getString("organisationID"));
                } catch (Exception ea) {
                }
                /**
                 * ****************
                 */
                try {
                    e.setStructureID(rs.getString("structureID"));
                } catch (Exception ea) {
                }
                try {
                    e.setTacheID(rs.getString("tacheID"));
                } catch (Exception ea) {
                }
                try {
                    e.setActiviteID(rs.getString("activiteID"));
                } catch (Exception ea) {
                }
                try {
                    e.setFournisseurID(rs.getString("fournisseurID"));
                } catch (Exception ea) {
                }
                try {
                    e.setMatricule(rs.getString("matricule"));
                } catch (Exception ea) {
                }
                try {
                    e.setTacheLibelle(rs.getString("tacheLibelle"));
                } catch (Exception ea) {
                }
                try {
                    e.setActiviteLibelle(rs.getString("activiteLibelle"));
                } catch (Exception ea) {
                }
                try {
                    e.setStructureLibelle(rs.getString("structureLibelle"));
                } catch (Exception ea) {
                }
                try {
                    e.setCodeTache(rs.getString("codeTache"));
                } catch (Exception ea) {
                }
                try {
                    e.setNumeroOPNet(rs.getString("numeroOPNet"));
                } catch (Exception ea) {
                }
                try {
                    e.setNumeroOPTaxe(rs.getString("numeroOPTaxe"));
                } catch (Exception ea) {
                }
                try {
                    e.setMontantNet(rs.getBigDecimal("montantNet"));
                } catch (Exception ea) {
                }
                try {
                    e.setMontantTaxe(rs.getBigDecimal("montantTaxe"));
                } catch (Exception ea) {
                }
                try {
                    e.setReference(rs.getString("reference"));
                } catch (Exception ea) {
                }
                try {
                    e.setUpdateUser(Crypto.decrypt(rs.getString("updateUser")));
                } catch (Exception ea) {
                }
                try {
                    e.setUpdateLastDate(rs.getDate("updateLastDate"));
                } catch (Exception ea) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Engagement getEngagementPipe(String engagementPipeID) {
        Connection con = null;
        Engagement e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementFind = con.prepareCall("CALL psEngagementPipe_Find( ?)");

            if (engagementPipeID == null) {
                stmtpsEngagementFind.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementFind.setString(1, engagementPipeID);
            }

            ResultSet rs = stmtpsEngagementFind.executeQuery();
            while (rs.next()) {
                e = new Engagement();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setEngagementID(rs.getString("engagementPipeID"));
                e.setEtat(rs.getInt("etat"));
                e.setObjet(rs.getString("objet"));
                if (rs.wasNull()) {
                    e.setObjet(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));
                e.setOrganisationID(rs.getString("organisationID"));
                e.setMillesime(rs.getString("millesime"));
                e.setActiviteID(rs.getString("activiteID"));
                e.setTypeID(rs.getString("typeID"));
                e.setStructureID(rs.getString("structureID"));

                try {
                    e.setNumeroOPNet(rs.getString("numeroOPNet"));
                } catch (Exception ea) {
                }
                try {
                    e.setNumeroOPTaxe(rs.getString("numeroOPTaxe"));
                } catch (Exception ea) {
                }
                try {
                    e.setMontantNet(rs.getBigDecimal("montantNet"));
                } catch (Exception ea) {
                }
                try {
                    e.setMontantTaxe(rs.getBigDecimal("montantTaxe"));
                } catch (Exception ea) {
                }
                try {
                    e.setReference(rs.getString("reference"));
                } catch (Exception ea) {
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void validerRegulariteOP(Mandatement mandat) {
        Connection con = null;
        CallableStatement stmtpsEngagementInsert = null;
        try {
            con = dataSource.getConnection();
            stmtpsEngagementInsert = con.prepareCall("CALL psEngagement_ValiderRegulariteOP( ?, ?, ? )");

            if (mandat.getMandatementID() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, mandat.getMandatementID());
            }
            if (mandat.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, mandat.getUserUpdate());
            }
            if (mandat.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, mandat.getIpUpdate());
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public boolean modifierPipeOP(VueEngagementDossier e) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementInsert = con.prepareCall("CALL psEngagementPipe_UpdateOP( ?, ?, ?, ?, ?, ?)");

            if (e.getEngagementID() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, e.getEngagementID());
            }
            if (e.getNumeroOPNet() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getNumeroOPNet());
            }
            if (e.getNumeroOPTaxe() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getNumeroOPTaxe());
            }

            if (e.getMontantNet() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(4, e.getMontantNet());
            }

            if (e.getMontantTaxe() == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(5, e.getMontantTaxe());
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, e.getReference());
            }

            stmtpsEngagementInsert.executeUpdate();

            return true;

        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void engagementTypeJournaux(String organisationID, String jrn1, String jrn2, String jrn3, String jrn4, String jrn5) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementInsert = con.prepareCall("CALL psEngagementTypeJournaux( ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, organisationID);
            }
            if (jrn1 == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, jrn1);
            }
            if (jrn2 == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, jrn2);
            }
            if (jrn3 == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, jrn3);
            }
            if (jrn4 == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, jrn4);
            }
            if (jrn5 == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(6, jrn5);
            }

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void validationComptable(String mandatementID, boolean validerCreance, boolean ValiderPaiement) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementInsert = con.prepareCall("CALL psEngagementComptable_Validation( ?, ?, ?)");

            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, mandatementID);
            }

            stmtpsEngagementInsert.setBoolean(2, validerCreance);

            stmtpsEngagementInsert.setBoolean(3, ValiderPaiement);

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void validationComptableAnnuler(String mandatementID, String numDossier, boolean validerCreance, boolean ValiderPaiement) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementInsert = con.prepareCall("CALL psEngagementComptable_Validation_Annulation( ?, ?, ?, ?)");

            if (mandatementID == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, mandatementID);
            }

            if (numDossier == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, numDossier);
            }

            stmtpsEngagementInsert.setBoolean(3, validerCreance);

            stmtpsEngagementInsert.setBoolean(4, ValiderPaiement);

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void validationComptablePaiement(Paiement e, boolean validerCreance) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementInsert = con.prepareCall("CALL psEngagementPaiement_Validation( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (e.getUserUpdate() == null) {
                stmtpsEngagementInsert.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(1, e.getUserUpdate());
            }
            if (e.getIpUpdate() == null) {
                stmtpsEngagementInsert.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(2, e.getIpUpdate());
            }
            if (e.getPaiementID() == null) {
                stmtpsEngagementInsert.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(3, e.getPaiementID());
            }
            if (e.getMandatementID() == null) {
                stmtpsEngagementInsert.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(4, e.getMandatementID());
            }
            if (e.getLiquiditeID() == null) {
                stmtpsEngagementInsert.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(5, e.getLiquiditeID());
            }
            if (e.getMontant() == null) {
                stmtpsEngagementInsert.setNull(6, java.sql.Types.NUMERIC);
            } else {
                stmtpsEngagementInsert.setBigDecimal(6, e.getMontant());
            }
            if (e.getDatePaiement() == null) {
                stmtpsEngagementInsert.setNull(7, java.sql.Types.DATE);
            } else {
                stmtpsEngagementInsert.setDate(7, new java.sql.Date(e.getDatePaiement().getTime()));
            }
            if (e.getReference() == null) {
                stmtpsEngagementInsert.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(8, e.getReference());
            }
            if (e.getDroitID() == null) {
                stmtpsEngagementInsert.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementInsert.setString(9, e.getDroitID());
            }
            stmtpsEngagementInsert.setBoolean(10, validerCreance);

            stmtpsEngagementInsert.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<CleValeur> leveeListByType(String organisationID, String millesime, String typeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_LeveeListBlocages( ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }
            if (typeID == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.INTEGER);
            } else {
                stmtpsEngagementSearch.setInt(3, Integer.valueOf(typeID).intValue());
            }

            List<CleValeur> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();

            while (rs.next()) {
                CleValeur e = new CleValeur();
                e.setCode(rs.getInt("nb"));
                e.setLibelleFr(rs.getString("blocage"));
                e.setLibelleUs(rs.getString("blocage"));
                e.setNumero(rs.getInt("numeroControle"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueLeveeDetails> leveeListByTypeDetails(String organisationID, String millesime, int typeID, int numeroControle) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_LeveeListBlocagesDetails( ?, ?, ?, ?)");

            if (organisationID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, organisationID);
            }
            if (millesime == null) {
                stmtpsEngagementSearch.setNull(2, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(2, millesime);
            }

            stmtpsEngagementSearch.setInt(3, typeID);
            stmtpsEngagementSearch.setInt(4, numeroControle);

            List<VueLeveeDetails> list = new ArrayList<>();
            ResultSet rs = stmtpsEngagementSearch.executeQuery();

            while (rs.next()) {
                VueLeveeDetails e = new VueLeveeDetails();
                e.setId(rs.getString("id"));
                e.setLeveeId(rs.getString("leveeID"));
                e.setIdentifiant(rs.getString("identifiant"));
                e.setBeneficiaire(rs.getString("beneficiaire"));
                e.setBlocage(rs.getString("blocage"));
                e.setMotifLevee(rs.getString("motifLevee"));
                e.setUserDemande(Crypto.decrypt(rs.getString("userDemande")));
                e.setDateDemande(rs.getDate("dateDemande"));
                e.setStatut(rs.getBoolean("statut"));
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void leveeUpdateBlocage(String leveeID, int statut, String userAutorise) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementSearch = con.prepareCall("CALL psEngagement_LeveeUpdateBlocages( ?, ?, ?)");

            if (leveeID == null) {
                stmtpsEngagementSearch.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementSearch.setString(1, leveeID);
            }

            stmtpsEngagementSearch.setInt(2, statut);

            if (userAutorise == null) {
                stmtpsEngagementSearch.setNull(3, java.sql.Types.CHAR);
            } else {
                stmtpsEngagementSearch.setString(3, userAutorise);
            }

            stmtpsEngagementSearch.executeQuery();

        } catch (Exception ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
