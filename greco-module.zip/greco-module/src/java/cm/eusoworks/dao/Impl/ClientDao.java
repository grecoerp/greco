/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IClientDao;
import cm.eusoworks.entities.model.Client;
import cm.eusoworks.entities.model.ClientGroupe;
import cm.eusoworks.entities.model.ClientRemise;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ClientDao implements IClientDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    // <editor-fold defaultstate="collapsed" desc="Client">
    @Override
    public void clientAjouter(Client cl) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClient_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (cl.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(cl.getLastUpdate().getTime()));
            }
            if (cl.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, cl.getUserUpdate());
            }
            if (cl.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, cl.getIpUpdate());
            }
            if (cl.getClientID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, cl.getClientID());
            }
            if (cl.getIdentifiant() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, cl.getIdentifiant());
            }
            if (cl.getNom() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, cl.getNom());
            }
            if (cl.getContact() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, cl.getContact());
            }
            if (cl.getVille() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, cl.getVille());
            }
            if (cl.getTelephone1() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, cl.getTelephone1());
            }
            if (cl.getTelephone2() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, cl.getTelephone2());
            }
            if (cl.getPays() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, cl.getPays());
            }
            if (cl.getFax() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, cl.getFax());
            }
            if (cl.getEmail() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, cl.getEmail());
            }

            stmt.setDouble(14, cl.getRemiseEnCours());

            if (cl.getGroupeClientID() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(15, cl.getGroupeClientID());
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void clientModifier(Client cl) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClient_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (cl.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(cl.getLastUpdate().getTime()));
            }
            if (cl.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, cl.getUserUpdate());
            }
            if (cl.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, cl.getIpUpdate());
            }
            if (cl.getClientID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, cl.getClientID());
            }
            if (cl.getIdentifiant() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, cl.getIdentifiant());
            }
            if (cl.getNom() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, cl.getNom());
            }
            if (cl.getContact() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, cl.getContact());
            }
            if (cl.getVille() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, cl.getVille());
            }
            if (cl.getTelephone1() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, cl.getTelephone1());
            }
            if (cl.getTelephone2() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, cl.getTelephone2());
            }
            if (cl.getPays() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, cl.getPays());
            }
            if (cl.getFax() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, cl.getFax());
            }
            if (cl.getEmail() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, cl.getEmail());
            }

            stmt.setDouble(14, cl.getRemiseEnCours());

            if (cl.getGroupeClientID() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(15, cl.getGroupeClientID());
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void clientSupprimer(String clientID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClient_Delete( ?)");

            if (clientID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, clientID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public Client clientRechercher(String clientID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClient_FindByNom( ? )");

            if (clientID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, clientID);
            }

            Client e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new Client();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setClientID(rs.getString("clientID"));
                if (rs.wasNull()) {
                    e.setClientID(null);
                }
                e.setIdentifiant(rs.getString("identifiant"));
                if (rs.wasNull()) {
                    e.setIdentifiant(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setContact(rs.getString("contact"));
                if (rs.wasNull()) {
                    e.setContact(null);
                }
                e.setVille(rs.getString("ville"));
                if (rs.wasNull()) {
                    e.setVille(null);
                }
                e.setTelephone1(rs.getString("telephone1"));
                if (rs.wasNull()) {
                    e.setTelephone1(null);
                }
                e.setTelephone2(rs.getString("telephone2"));
                if (rs.wasNull()) {
                    e.setTelephone2(null);
                }
                e.setPays(rs.getString("pays"));
                if (rs.wasNull()) {
                    e.setPays(null);
                }
                e.setFax(rs.getString("fax"));
                if (rs.wasNull()) {
                    e.setFax(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setRemiseEnCours(rs.getFloat("remiseEnCours"));
                if (rs.wasNull()) {
                    e.setRemiseEnCours(null);
                }
                e.setGroupeClientID(rs.getString("groupeClientID"));
                if (rs.wasNull()) {
                    e.setGroupeClientID(null);
                }
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Client> clientRechercherByIdentifiant(String identifiant) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClient_FindByIdentifiant( ? )");

            if (identifiant == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, identifiant);
            }

            List<Client> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Client e = new Client();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setClientID(rs.getString("clientID"));
                if (rs.wasNull()) {
                    e.setClientID(null);
                }
                e.setIdentifiant(rs.getString("identifiant"));
                if (rs.wasNull()) {
                    e.setIdentifiant(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setContact(rs.getString("contact"));
                if (rs.wasNull()) {
                    e.setContact(null);
                }
                e.setVille(rs.getString("ville"));
                if (rs.wasNull()) {
                    e.setVille(null);
                }
                e.setTelephone1(rs.getString("telephone1"));
                if (rs.wasNull()) {
                    e.setTelephone1(null);
                }
                e.setTelephone2(rs.getString("telephone2"));
                if (rs.wasNull()) {
                    e.setTelephone2(null);
                }
                e.setPays(rs.getString("pays"));
                if (rs.wasNull()) {
                    e.setPays(null);
                }
                e.setFax(rs.getString("fax"));
                if (rs.wasNull()) {
                    e.setFax(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setRemiseEnCours(rs.getFloat("remiseEnCours"));
                if (rs.wasNull()) {
                    e.setRemiseEnCours(null);
                }
                e.setGroupeClientID(rs.getString("groupeClientID"));
                if (rs.wasNull()) {
                    e.setGroupeClientID(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Client> clientRechercherByNom(String nom) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClient_FindByNom( ? )");

            if (nom == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, nom);
            }

            List<Client> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Client e = new Client();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setClientID(rs.getString("clientID"));
                if (rs.wasNull()) {
                    e.setClientID(null);
                }
                e.setIdentifiant(rs.getString("identifiant"));
                if (rs.wasNull()) {
                    e.setIdentifiant(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setContact(rs.getString("contact"));
                if (rs.wasNull()) {
                    e.setContact(null);
                }
                e.setVille(rs.getString("ville"));
                if (rs.wasNull()) {
                    e.setVille(null);
                }
                e.setTelephone1(rs.getString("telephone1"));
                if (rs.wasNull()) {
                    e.setTelephone1(null);
                }
                e.setTelephone2(rs.getString("telephone2"));
                if (rs.wasNull()) {
                    e.setTelephone2(null);
                }
                e.setPays(rs.getString("pays"));
                if (rs.wasNull()) {
                    e.setPays(null);
                }
                e.setFax(rs.getString("fax"));
                if (rs.wasNull()) {
                    e.setFax(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setRemiseEnCours(rs.getFloat("remiseEnCours"));
                if (rs.wasNull()) {
                    e.setRemiseEnCours(null);
                }
                e.setGroupeClientID(rs.getString("groupeClientID"));
                if (rs.wasNull()) {
                    e.setGroupeClientID(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Client> clientList() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClient_List( )");

            List<Client> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Client e = new Client();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setClientID(rs.getString("clientID"));
                if (rs.wasNull()) {
                    e.setClientID(null);
                }
                e.setIdentifiant(rs.getString("identifiant"));
                if (rs.wasNull()) {
                    e.setIdentifiant(null);
                }
                e.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    e.setNom(null);
                }
                e.setContact(rs.getString("contact"));
                if (rs.wasNull()) {
                    e.setContact(null);
                }
                e.setVille(rs.getString("ville"));
                if (rs.wasNull()) {
                    e.setVille(null);
                }
                e.setTelephone1(rs.getString("telephone1"));
                if (rs.wasNull()) {
                    e.setTelephone1(null);
                }
                e.setTelephone2(rs.getString("telephone2"));
                if (rs.wasNull()) {
                    e.setTelephone2(null);
                }
                e.setPays(rs.getString("pays"));
                if (rs.wasNull()) {
                    e.setPays(null);
                }
                e.setFax(rs.getString("fax"));
                if (rs.wasNull()) {
                    e.setFax(null);
                }
                e.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    e.setEmail(null);
                }
                e.setRemiseEnCours(rs.getFloat("remiseEnCours"));
                if (rs.wasNull()) {
                    e.setRemiseEnCours(null);
                }
                e.setGroupeClientID(rs.getString("groupeClientID"));
                if (rs.wasNull()) {
                    e.setGroupeClientID(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void clientAjouterGroupe(Date last_update, String user_update, String ip_update, String clientID, String groupeClientID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClient_UpdateGroupe( ?, ?, ?, ?, ?)");

            if (last_update == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(last_update.getTime()));
            }
            if (user_update == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, user_update);
            }
            if (ip_update == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, ip_update);
            }
            if (clientID == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, clientID);
            }
            if (groupeClientID == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, groupeClientID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    // </editor-fold> 
    
    // <editor-fold defaultstate="collapsed" desc="ClientGroupe">
    @Override
    public void groupeClientAjouter(ClientGroupe grp) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClientGroupe_Insert( ?, ?, ?, ?, ?)");

            if (grp.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(grp.getLastUpdate().getTime()));
            }
            if (grp.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, grp.getUserUpdate());
            }
            if (grp.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, grp.getIpUpdate());
            }
            if (grp.getGroupeClientID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, grp.getGroupeClientID());
            }
            if (grp.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, grp.getLibelleFr());
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void groupeClientModifier(ClientGroupe grp) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClientGroupe_Update( ?, ?, ?, ?, ?)");

            if (grp.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(grp.getLastUpdate().getTime()));
            }
            if (grp.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, grp.getUserUpdate());
            }
            if (grp.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, grp.getIpUpdate());
            }
            if (grp.getGroupeClientID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, grp.getGroupeClientID());
            }
            if (grp.getLibelleFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, grp.getLibelleFr());
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void groupeClientSupprimer(String clientGroupeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClientGroupe_Delete( ?)");

            if (clientGroupeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, clientGroupeID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public ClientGroupe groupeClientRechercher(String clientGroupeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClientGroupe_Find(? )");

            if (clientGroupeID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, clientGroupeID);
            }
            ClientGroupe e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new ClientGroupe();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setGroupeClientID(rs.getString("groupeClientID"));
                if (rs.wasNull()) {
                    e.setGroupeClientID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<ClientGroupe> groupeClientList() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClientGroupe_List( )");

            List<ClientGroupe> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ClientGroupe e = new ClientGroupe();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    e.setUserUpdate(null);
                }
                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setGroupeClientID(rs.getString("groupeClientID"));
                if (rs.wasNull()) {
                    e.setGroupeClientID(null);
                }
                e.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    e.setLibelleFr(null);
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // </editor-fold>  
    
    // <editor-fold defaultstate="collapsed" desc="Remise Client">
    @Override
    public void remiseClientAjouter(ClientRemise rem) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClientRemise_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (rem.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(rem.getLastUpdate().getTime()));
            }
            if (rem.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, rem.getUserUpdate());
            }
            if (rem.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, rem.getIpUpdate());
            }
            if (rem.getRemiseID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, rem.getRemiseID());
            }
            if (rem.getClientID() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, rem.getClientID());
            }

            stmt.setFloat(6, rem.getRemise());

            if (rem.getDateDebut() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(rem.getDateDebut().getTime()));
            }
            if (rem.getDateFin() == null) {
                stmt.setNull(8, java.sql.Types.DATE);
            } else {
                stmt.setDate(8, new java.sql.Date(rem.getDateFin().getTime()));
            }
            stmt.setBoolean(9, rem.getEncours());

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void remiseClientModifier(ClientRemise rem) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClientRemise_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (rem.getLastUpdate() == null) {
                stmt.setNull(1, java.sql.Types.DATE);
            } else {
                stmt.setDate(1, new java.sql.Date(rem.getLastUpdate().getTime()));
            }
            if (rem.getUserUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, rem.getUserUpdate());
            }
            if (rem.getIpUpdate() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, rem.getIpUpdate());
            }
            if (rem.getRemiseID() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, rem.getRemiseID());
            }
            if (rem.getClientID() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, rem.getClientID());
            }

            stmt.setFloat(6, rem.getRemise());

            if (rem.getDateDebut() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(rem.getDateDebut().getTime()));
            }
            if (rem.getDateFin() == null) {
                stmt.setNull(8, java.sql.Types.DATE);
            } else {
                stmt.setDate(8, new java.sql.Date(rem.getDateFin().getTime()));
            }
            stmt.setBoolean(9, rem.getEncours());

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void remiseClientSupprimer(String clientRemiseID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psClientRemise_Delete( ?)");

            if (clientRemiseID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, clientRemiseID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public ClientRemise remiseClientRechercher(String clientRemiseID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClientRemise_Find( ?)");

            ClientRemise e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new ClientRemise();
		
		 e.setLastUpdate(rs.getDate("last_update"));
		if (rs.wasNull())e.setLastUpdate(null); 
		 e.setUserUpdate(rs.getString("user_update"));
		if (rs.wasNull())e.setUserUpdate(null); 
		 e.setIpUpdate(rs.getString("ip_update"));
		if (rs.wasNull())e.setIpUpdate(null); 
		 e.setRemiseID(rs.getString("remiseID"));
		if (rs.wasNull())e.setRemiseID(null); 
		 e.setClientID(rs.getString("clientID"));
		if (rs.wasNull())e.setClientID(null); 
		 e.setRemise(rs.getFloat("remise"));
		if (rs.wasNull())e.setRemise(0f); 
		 e.setDateDebut(rs.getDate("dateDebut"));
		if (rs.wasNull())e.setDateDebut(null); 
		 e.setDateFin(rs.getDate("dateFin"));
		if (rs.wasNull())e.setDateFin(null); 
		 e.setEncours(rs.getBoolean("encours"));
		if (rs.wasNull())e.setEncours(false); 
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<ClientRemise> remiseClientList(String clientID, Date dateReference) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psClientRemise_List( ?, ?)");


            List<ClientRemise> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                ClientRemise e = new ClientRemise();
		
		 e.setLastUpdate(rs.getDate("last_update"));
		if (rs.wasNull())e.setLastUpdate(null); 
		 e.setUserUpdate(rs.getString("user_update"));
		if (rs.wasNull())e.setUserUpdate(null); 
		 e.setIpUpdate(rs.getString("ip_update"));
		if (rs.wasNull())e.setIpUpdate(null); 
		 e.setRemiseID(rs.getString("remiseID"));
		if (rs.wasNull())e.setRemiseID(null); 
		 e.setClientID(rs.getString("clientID"));
		if (rs.wasNull())e.setClientID(null); 
		 e.setRemise(rs.getFloat("remise"));
		if (rs.wasNull())e.setRemise(0f); 
		 e.setDateDebut(rs.getDate("dateDebut"));
		if (rs.wasNull())e.setDateDebut(null); 
		 e.setDateFin(rs.getDate("dateFin"));
		if (rs.wasNull())e.setDateFin(null); 
		 e.setEncours(rs.getBoolean("encours"));
		if (rs.wasNull())e.setEncours(false); 
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(ClientDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    // </editor-fold> 
    
    
}
