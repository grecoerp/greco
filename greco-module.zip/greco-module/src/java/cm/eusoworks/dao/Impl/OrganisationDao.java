/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IOrganisationDao;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.DatabaseOptions;
import cm.eusoworks.entities.model.Notes;
import cm.eusoworks.entities.model.OrgOptions;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class OrganisationDao implements IOrganisationDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public int ajouter(Organisation org, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getOrganisationID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getOrganisationID());
            }
            if (org.getCode() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getCode());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(9, java.sql.Types.DATE);
            } else {
                stmt.setDate(9, new java.sql.Date(org.getDateCreation().getTime()));
            }
            if (org.getDateCessation() == null) {
                stmt.setNull(10, java.sql.Types.DATE);
            } else {
                stmt.setDate(10, new java.sql.Date(org.getDateCessation().getTime()));
            }

            stmt.setBoolean(11, org.getActif());
            stmt.registerOutParameter(12, java.sql.Types.INTEGER);
            stmt.setInt(12, codeErreur);

            stmt.executeQuery();

            codeErreur = stmt.getInt(12);
            return codeErreur;
        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int modifier(Organisation org, int codeErreur) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getOrganisationID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getOrganisationID());
            }
            if (org.getCode() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getCode());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(9, java.sql.Types.DATE);
            } else {
                stmt.setDate(9, new java.sql.Date(org.getDateCreation().getTime()));
            }
            if (org.getDateCessation() == null) {
                stmt.setNull(10, java.sql.Types.DATE);
            } else {
                stmt.setDate(10, new java.sql.Date(org.getDateCessation().getTime()));
            }

            stmt.setBoolean(11, org.getActif());
            stmt.registerOutParameter(12, java.sql.Types.INTEGER);
            stmt.setInt(12, codeErreur);

            stmt.executeQuery();

            codeErreur = stmt.getInt(12);
            return codeErreur;
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String organisationID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_Delete(?)");
            stmt.setString(1, organisationID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public Organisation rechercherById(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_SearchID(?)");
            stmt.setString(1, organisationID);

            Organisation o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Organisation();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Organisation> rechercherByCode(String code) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_SearchCode(?)");
            stmt.setString(1, code);

            List<Organisation> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Organisation o = new Organisation();
                o = new Organisation();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Organisation> listeOrganisation(boolean active) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_List(?)");
            stmt.setBoolean(1, active);

            List<Organisation> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Organisation o = new Organisation();
                o = new Organisation();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Organisation> listeOrganisationUsersByRole(String login, String role ) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_ListByUser(?, ?)");
            stmt.setString(1, login);
            if(role ==null){
                stmt.setNull(2, java.sql.Types.VARCHAR);
            }else {
                stmt.setString(2, role);
            }

            List<Organisation> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Organisation o = new Organisation();
                o = new Organisation();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public void ajouterStructure(Structure org) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getStructureID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getStructureID());
            }
            if (org.getCode() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getCode());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(9, java.sql.Types.DATE);
            } else {
                stmt.setDate(9, new java.sql.Date(org.getDateCreation().getTime()));
            }
            if (org.getDateCessation() == null) {
                stmt.setNull(10, java.sql.Types.DATE);
            } else {
                stmt.setDate(10, new java.sql.Date(org.getDateCessation().getTime()));
            }

            stmt.setBoolean(11, org.getActif());

            if (org.getOrganisationID() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, org.getOrganisationID());
            }
            if (org.getCategorieCode() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, org.getCategorieCode());
            }
            if (org.getFonctionCode() == null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(14, org.getFonctionCode());
            }
            if (org.getLocaliteCode() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(15, org.getLocaliteCode());
            }
            if (org.getPosteComptableID() == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, org.getPosteComptableID());
            }
            if (org.getStructureParentID() == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, org.getStructureParentID());
            }
            if (org.getUniteOrganiqueID() == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, org.getUniteOrganiqueID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierStructure(Structure org) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?)");
            if (org.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, org.getUserUpdate());
            }
            if (org.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, org.getIpUpdate());
            }
            if (org.getStructureID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, org.getStructureID());
            }
            if (org.getCode() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, org.getCode());
            }
            if (org.getAbbreviationFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, org.getAbbreviationFr());
            }
            if (org.getAbbreviationUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, org.getAbbreviationUs());
            }
            if (org.getLibelleFr() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, org.getLibelleFr());
            }
            if (org.getLibelleUs() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, org.getLibelleUs());
            }
            if (org.getDateCreation() == null) {
                stmt.setNull(9, java.sql.Types.DATE);
            } else {
                stmt.setDate(9, new java.sql.Date(org.getDateCreation().getTime()));
            }
            if (org.getDateCessation() == null) {
                stmt.setNull(10, java.sql.Types.DATE);
            } else {
                stmt.setDate(10, new java.sql.Date(org.getDateCessation().getTime()));
            }

            stmt.setBoolean(11, org.getActif());

            if (org.getOrganisationID() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, org.getOrganisationID());
            }
            if (org.getCategorieCode() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, org.getCategorieCode());
            }
            if (org.getFonctionCode() == null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(14, org.getFonctionCode());
            }
            if (org.getLocaliteCode() == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(15, org.getLocaliteCode());
            }
            if (org.getPosteComptableID() == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, org.getPosteComptableID());
            }
            if (org.getStructureParentID() == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, org.getStructureParentID());
            }
            if (org.getUniteOrganiqueID() == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, org.getUniteOrganiqueID());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerStructure(String structureID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_Delete(?)");
            stmt.setString(1, structureID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Structure> listeStructuresOrganisation(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_List(?)");

            stmt.setString(1, organisationID);

            List<Structure> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Structure o = new Structure();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setStructureID(rs.getString("structureID"));
                if (rs.wasNull()) {
                    o.setStructureID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCategorieCode(rs.getString("CategorieCode"));
                if (rs.wasNull()) {
                    o.setCategorieCode(null);
                }
                o.setFonctionCode(rs.getString("FonctionCode"));
                if (rs.wasNull()) {
                    o.setFonctionCode(null);
                }
                o.setLocaliteCode(rs.getString("LocaliteCode"));
                if (rs.wasNull()) {
                    o.setLocaliteCode(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setStructureParentID(rs.getString("structureParentID"));
                if (rs.wasNull()) {
                    o.setStructureParentID(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Structure> listeStructuresUserByOrganisation(String organisationID, String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersStructure_ListByLogin(?, ?)");

            stmt.setString(1, organisationID);
            stmt.setString(2, login);

            List<Structure> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Structure o = new Structure();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setStructureID(rs.getString("structureID"));
                if (rs.wasNull()) {
                    o.setStructureID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCategorieCode(rs.getString("CategorieCode"));
                if (rs.wasNull()) {
                    o.setCategorieCode(null);
                }
                o.setFonctionCode(rs.getString("FonctionCode"));
                if (rs.wasNull()) {
                    o.setFonctionCode(null);
                }
                o.setLocaliteCode(rs.getString("LocaliteCode"));
                if (rs.wasNull()) {
                    o.setLocaliteCode(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setStructureParentID(rs.getString("structureParentID"));
                if (rs.wasNull()) {
                    o.setStructureParentID(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public void saveParametres(String organisationID, String zoneEco, String paysFr, String paysUs, String deviseFr, String deviseUs, String orgSigleFr,
            String orgSigleUs, String orgLibelleFr, String orgLibelleUs, String orgContact, String appAbreviationFr, String appAbreviationUs, String appTitleFr, String appTitleUs,
            String user, String adresseIP, String machine, String motif, String tutelleFr, String tutelleUs) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOption_Organisation( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (zoneEco == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, zoneEco);
            }
            if (paysFr == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, paysFr);
            }
            if (paysUs == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, paysUs);
            }
            if (deviseFr == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, deviseFr);
            }
            if (deviseUs == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, deviseUs);
            }
            if (orgSigleFr == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, orgSigleFr);
            }
            if (orgSigleUs == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, orgSigleUs);
            }
            if (orgLibelleFr == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, orgLibelleFr);
            }
            if (orgLibelleUs == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, orgLibelleUs);
            }
            if (orgContact == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, orgContact);
            }
            if (appAbreviationFr == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, appAbreviationFr);
            }
            if (appAbreviationUs == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, appAbreviationUs);
            }
            if (appTitleFr == null) {
                stmt.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(14, appTitleFr);
            }
            if (appTitleUs == null) {
                stmt.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(15, appTitleUs);
            }
            if (user == null) {
                stmt.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(16, user);
            }
            if (adresseIP == null) {
                stmt.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(17, adresseIP);
            }
            if (machine == null) {
                stmt.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(18, machine);
            }
            if (motif == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, motif);
            }
            if (tutelleFr == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, tutelleFr);
            }
            if (tutelleUs == null) {
                stmt.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(21, tutelleUs);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    
    @Override
    public void saveParametres(OrgOptions op) {
        saveParametres(op.getOrganisationID(), op.getZoneEco(), op.getPaysFr(), op.getPaysUs(), op.getDeviseFr(), op.getDeviseUs(),
                op.getOrgSigleFr(), op.getOrgSigleUs(), op.getOrgLibelleFr(), op.getOrgLibelleUs(), op.getOrgContact(), op.getAppAbreviationFr(),
                op.getAppAbreviationUs(), op.getAppTitleFr(), op.getAppTitleUs(), op.getUserUpdate(), op.getIpUpdate(), op.getMachine(), op.getMotif(),
                op.getTutelleFr(), op.getTutelleUs());
    }

    @Override
    public OrgOptions getOptionOrganisation(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psOption_OrganisationFind( ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }

            OrgOptions e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new OrgOptions();

                e.setZoneEco(rs.getString("zoneEco"));
                if (rs.wasNull()) {
                    e.setZoneEco(null);
                }
                e.setPaysFr(rs.getString("paysFr"));
                if (rs.wasNull()) {
                    e.setPaysFr(null);
                }
                e.setPaysUs(rs.getString("paysUs"));
                if (rs.wasNull()) {
                    e.setPaysUs(null);
                }
                e.setDeviseFr(rs.getString("deviseFr"));
                if (rs.wasNull()) {
                    e.setDeviseFr(null);
                }
                e.setDeviseUs(rs.getString("deviseUs"));
                if (rs.wasNull()) {
                    e.setDeviseUs(null);
                }
                e.setOrgSigleFr(rs.getString("orgSigleFr"));
                if (rs.wasNull()) {
                    e.setOrgSigleFr(null);
                }
                e.setOrgSigleUs(rs.getString("orgSigleUs"));
                if (rs.wasNull()) {
                    e.setOrgSigleUs(null);
                }
                e.setOrgLibelleFr(rs.getString("orgLibelleFr"));
                if (rs.wasNull()) {
                    e.setOrgLibelleFr(null);
                }
                e.setOrgLibelleUs(rs.getString("orgLibelleUs"));
                if (rs.wasNull()) {
                    e.setOrgLibelleUs(null);
                }
                e.setOrgContact(rs.getString("orgContact"));
                if (rs.wasNull()) {
                    e.setOrgContact(null);
                }
                e.setAppAbreviationFr(rs.getString("appAbreviationFr"));
                if (rs.wasNull()) {
                    e.setAppAbreviationFr(null);
                }
                e.setAppAbreviationUs(rs.getString("appAbreviationUs"));
                if (rs.wasNull()) {
                    e.setAppAbreviationUs(null);
                }
                e.setAppTitleFr(rs.getString("appTitleFr"));
                if (rs.wasNull()) {
                    e.setAppTitleFr(null);
                }
                e.setAppTitleUs(rs.getString("appTitleUs"));
                if (rs.wasNull()) {
                    e.setAppTitleUs(null);
                }
                e.setTutelleFr(rs.getString("tutelleFr"));
                if (rs.wasNull()) {
                    e.setTutelleFr(null);
                }
                e.setTutelleUs(rs.getString("tutelleUs"));
                if (rs.wasNull()) {
                    e.setTutelleUs(null);
                }
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(OrganisationDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Structure> listeStructuresFilles(String organisationID, String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_ListChilds(?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (structureID == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, structureID);
            }

            List<Structure> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Structure o = new Structure();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setStructureID(rs.getString("structureID"));
                if (rs.wasNull()) {
                    o.setStructureID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCategorieCode(rs.getString("CategorieCode"));
                if (rs.wasNull()) {
                    o.setCategorieCode(null);
                }
                o.setFonctionCode(rs.getString("FonctionCode"));
                if (rs.wasNull()) {
                    o.setFonctionCode(null);
                }
                o.setLocaliteCode(rs.getString("LocaliteCode"));
                if (rs.wasNull()) {
                    o.setLocaliteCode(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setStructureParentID(rs.getString("structureParentID"));
                if (rs.wasNull()) {
                    o.setStructureParentID(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setChilds(rs.getInt("childs"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Structure> listeStructuresByUniteOrganique(String organisationID, String uniteOrganiqueID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_ListByUniteOrg(?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (uniteOrganiqueID == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, uniteOrganiqueID);
            }

            List<Structure> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Structure o = new Structure();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setStructureID(rs.getString("structureID"));
                if (rs.wasNull()) {
                    o.setStructureID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));

                o.setOrganisationID(rs.getString("organisationID"));
                if (rs.wasNull()) {
                    o.setOrganisationID(null);
                }
                o.setCategorieCode(rs.getString("CategorieCode"));
                if (rs.wasNull()) {
                    o.setCategorieCode(null);
                }
                o.setFonctionCode(rs.getString("FonctionCode"));
                if (rs.wasNull()) {
                    o.setFonctionCode(null);
                }
                o.setLocaliteCode(rs.getString("LocaliteCode"));
                if (rs.wasNull()) {
                    o.setLocaliteCode(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setStructureParentID(rs.getString("structureParentID"));
                if (rs.wasNull()) {
                    o.setStructureParentID(null);
                }
                o.setUniteOrganiqueID(rs.getString("uniteOrganiqueID"));
                if (rs.wasNull()) {
                    o.setUniteOrganiqueID(null);
                }
                o.setChilds(rs.getInt("childs"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public int structureMaxOrdre(String caCode, String loCode) {
        Connection con = null;
        int codeErreur = 0;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psStructure_MaxOrdre(?, ?, ?)");
            if (caCode == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, caCode);
            }
            if (loCode == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, loCode);
            }

            stmt.registerOutParameter(3, java.sql.Types.INTEGER);
            stmt.setInt(3, codeErreur);

            stmt.executeQuery();

            codeErreur = stmt.getInt(3);
            return codeErreur;
        } catch (SQLException ex) {
            return 0;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void noteSuppression(String noteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psNotes_Delete( ?)");

            if (noteID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, noteID);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public List<Notes> noteRechercher(String organisationID, String noteID, String moduleID, String userLogins, Date dateAffichageDebut, Date dateAffichageFin, String userupdate, Integer statut) {
        Connection con = null;
        List<Notes> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psNotes_Find( ?, ?, ?, ?, ?, ?, ?, ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }
            if (noteID == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, noteID);
            }
            if (moduleID == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, moduleID);
            }
            if (userLogins == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, userLogins);
            }
            if (dateAffichageDebut == null) {
                stmt.setNull(5, java.sql.Types.DATE);
            } else {
                stmt.setDate(5, new java.sql.Date(dateAffichageDebut.getTime()));
            }
            if (dateAffichageFin == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(dateAffichageFin.getTime()));
            }
            if (userupdate == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, userupdate);
            }
            if (statut == null) {
                stmt.setNull(8, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(8, statut);
            }

            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Notes n = new Notes();
                n.setContenu(rs.getString("contenu"));
                n.setDateAffichage(rs.getDate("dateAffichage"));
                n.setIpUpdate(rs.getString("ip_update"));
                n.setLastUpdate(rs.getDate("last_update"));
                n.setModuleIDs(rs.getString("moduleIDs"));
                n.setNoteID(rs.getString("noteID"));
                n.setObjet(rs.getString("objet"));
                n.setOrganisationIDs(rs.getString("organisationIDs"));
                n.setStatut(rs.getInt("statut"));
                n.setUserLogins(rs.getString("userLogins"));
                n.setUserUpdate(rs.getString("user_update"));

                list.add(n);
            }
            return list;
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void noteAjout(String userupdate, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psNotes_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (userupdate == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, userupdate);
            }
            if (ip_update == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ip_update);
            }
            if (noteID == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, noteID);
            }
            if (objet == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, objet);
            }
            if (contenu == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, contenu);
            }
            if (dateAffichage == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(dateAffichage.getTime()));
            }
            if (statut == null) {
                stmt.setNull(7, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(7, statut);
            }
            if (organisationIDs == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, organisationIDs);
            }
            if (moduleIDs == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, moduleIDs);
            }
            if (userLogins == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, userLogins);
            }

            stmt.executeUpdate();
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void noteModification(String user_update, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psNotes_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (user_update == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, user_update);
            }
            if (ip_update == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ip_update);
            }
            if (noteID == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, noteID);
            }
            if (objet == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, objet);
            }
            if (contenu == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, contenu);
            }
            if (dateAffichage == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(dateAffichage.getTime()));
            }
            if (statut == null) {
                stmt.setNull(7, java.sql.Types.INTEGER);
            } else {
                stmt.setInt(7, statut);
            }
            if (organisationIDs == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, organisationIDs);
            }
            if (moduleIDs == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, moduleIDs);
            }
            if (userLogins == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, userLogins);
            }

            stmt.executeUpdate();

        } catch (Exception ex) {
            throw new RuntimeException(ex);
        }
    }

    @Override
    public void saveBackupDBParameters(String user_update, String ip_update, String organisationID, String adresseIP, String port, String username, String password, String database, String dumpPath) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_Database(?, ?, ?, ?, ?, ?, ?, ?, ?)");

            stmt.setString(1, user_update);
            stmt.setString(2, ip_update);
            stmt.setString(3, organisationID);
            stmt.setString(4, adresseIP);
            stmt.setString(5, port);
            stmt.setString(6, username);
            stmt.setString(7, password);
            stmt.setString(8, database);
            stmt.setString(9, dumpPath);

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public DatabaseOptions databaseGetParameters(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall(" CALL psOrganisation_Database_List( ?)");

            if (organisationID == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, organisationID);
            }

            DatabaseOptions e = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                e = new DatabaseOptions();
                e.setAkl(rs.getString("AKL"));
                e.setO980(rs.getString("O980"));
                e.setOrganisationID(rs.getString("organisationID"));
                e.setQs89(rs.getString("QS89"));
                e.setRt34(rs.getString("RT34"));
                e.setSsr4(rs.getString("SSR4"));
                e.setYu78(rs.getString("YU78"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            Logger.getLogger(OrganisationDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(OrganisationDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
