/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IBanqueDao;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Agence;
import cm.eusoworks.entities.model.Banque;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class BanqueDao implements IBanqueDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public void banqueAjout(Banque b) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psBanque_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (b.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, b.getUserUpdate());
            }
            if (b.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, b.getIpUpdate());
            }
            if (b.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, b.getCode());
            }
            if (b.getSigle() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, b.getSigle());
            }
            if (b.getDesignation() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, b.getDesignation());
            }
            if (b.getAdresse() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, b.getAdresse());
            }
            if (b.getIban() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, b.getIban());
            }
            if (b.getSwift() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, b.getSwift());
            }
            if (b.getVille() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, b.getVille());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void banqueModifier(Banque b) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psBanque_Update(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (b.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, b.getUserUpdate());
            }
            if (b.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, b.getIpUpdate());
            }
            if (b.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, b.getCode());
            }
            if (b.getSigle() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, b.getSigle());
            }
            if (b.getDesignation() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, b.getDesignation());
            }
            if (b.getAdresse() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, b.getAdresse());
            }
            if (b.getIban() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, b.getIban());
            }
            if (b.getSwift() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, b.getSwift());
            }
            if (b.getVille() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, b.getVille());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void banqueSupprimer(String codeBanque, boolean withAgences) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psBanque_Delete(?, ?)");
            if (codeBanque == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, codeBanque);
            }
            stmt.setBoolean(2, withAgences);

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Banque banqueRechercher(String codeBanque) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psBanque_Find( ?)");

            if (codeBanque == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, codeBanque);
            }
            Banque e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new Banque();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setCode(rs.getString("code"));

                e.setSigle(rs.getString("sigle"));

                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setVille(rs.getString("ville"));

                e.setAdresse(rs.getString("adresse"));

                e.setIban(rs.getString("iban"));
                if (rs.wasNull()) {
                    e.setIban(null);
                }
                e.setSwift(rs.getString("swift"));
                if (rs.wasNull()) {
                    e.setSwift(null);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Banque> banqueListe() {
        Connection con = null;
        List<Banque> listBanques = new ArrayList<>();
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psBanque_Select()");
            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Banque e = new Banque();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setCode(rs.getString("code"));

                e.setSigle(rs.getString("sigle"));

                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setVille(rs.getString("ville"));

                e.setAdresse(rs.getString("adresse"));

                e.setIban(rs.getString("iban"));
                if (rs.wasNull()) {
                    e.setIban(null);
                }
                e.setSwift(rs.getString("swift"));
                if (rs.wasNull()) {
                    e.setSwift(null);
                }

                listBanques.add(e);

            }
            rs.close();
            return listBanques;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void agenceAjout(Agence b) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psBanqueAgence_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (b.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, b.getUserUpdate());
            }
            if (b.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, b.getIpUpdate());
            }
            if (b.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, b.getCode());
            }
            if (b.getSigle() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, b.getSigle());
            }
            if (b.getDesignation() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, b.getDesignation());
            }
            if (b.getAdresse() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, b.getAdresse());
            }
            if (b.getIban() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, b.getIban());
            }
            if (b.getSwift() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, b.getSwift());
            }
            if (b.getCodeBanque() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, b.getCodeBanque());
            }
            if (b.getVille() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, b.getVille());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void agenceModifier(Agence b) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psBanqueAgence_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (b.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, b.getUserUpdate());
            }
            if (b.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, b.getIpUpdate());
            }
            if (b.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, b.getCode());
            }
            if (b.getSigle() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, b.getSigle());
            }
            if (b.getDesignation() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, b.getDesignation());
            }
            if (b.getAdresse() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, b.getAdresse());
            }
            if (b.getIban() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, b.getIban());
            }
            if (b.getSwift() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, b.getSwift());
            }
            if (b.getCodeBanque() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, b.getCodeBanque());
            }
            if (b.getVille() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, b.getVille());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void agenceSupprimer(String codeBanque, String codeAgence) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psBanqueAgence_Delete(?, ?)");
            if (codeBanque == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, codeBanque);
            }
            if (codeAgence == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, codeAgence);
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Agence agenceRechercher(String codeAgence, String codeBanque) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psBanqueAgence_Find( ?, ?)");

            if (codeAgence == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, codeAgence);
            }
            if (codeBanque == null) {
                stmtpsactiviteS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(2, codeBanque);
            }
            Agence e = null;

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                e = new Agence();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setCode(rs.getString("code"));

                e.setSigle(rs.getString("sigle"));

                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setVille(rs.getString("ville"));

                e.setAdresse(rs.getString("adresse"));

                e.setIban(rs.getString("iban"));
                if (rs.wasNull()) {
                    e.setIban(null);
                }
                e.setSwift(rs.getString("swift"));
                if (rs.wasNull()) {
                    e.setSwift(null);
                }
                e.setCodeBanque(rs.getString("codeBanque"));
                if (rs.wasNull()) {
                    e.setCodeBanque(null);
                }

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Agence> agenceListe(String codeBanque) {
        Connection con = null;
        List<Agence> listAgences = new ArrayList<>();
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psBanqueAgence_Select( ?)");

            if (codeBanque == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, codeBanque);
            }

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                Agence e = new Agence();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setCode(rs.getString("code"));

                e.setSigle(rs.getString("sigle"));

                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setVille(rs.getString("ville"));

                e.setAdresse(rs.getString("adresse"));

                e.setIban(rs.getString("iban"));
                if (rs.wasNull()) {
                    e.setIban(null);
                }
                e.setSwift(rs.getString("swift"));
                if (rs.wasNull()) {
                    e.setSwift(null);
                }
                e.setCodeBanque(rs.getString("codeBanque"));
                if (rs.wasNull()) {
                    e.setCodeBanque(null);
                }

                listAgences.add(e);

            }
            rs.close();
            return listAgences;

        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueFournisseurRIB> ribByFournisseur(String fournisseurID) {
        Connection con = null;
        List<VueFournisseurRIB> listRIB = new ArrayList<>();
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsactiviteS = con.prepareCall("CALL psFournisseurRIB_Select( ?)");

            if (fournisseurID == null) {
                stmtpsactiviteS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsactiviteS.setString(1, fournisseurID);
            }

            ResultSet rs = stmtpsactiviteS.executeQuery();
            while (rs.next()) {
                VueFournisseurRIB e = new VueFournisseurRIB();

                e.setCodeAgence(rs.getString("codeAgence"));
                e.setCodeBanque(rs.getString("codeBanque"));
                e.setDesignationAgence(rs.getString("designationAgence"));
                e.setDesignationBanque(rs.getString("designationBanque"));
                e.setFournisseurID(rs.getString("fournisseurID"));
                e.setNumContribuable(rs.getString("numContribuable"));
                e.setRaisonSociale(rs.getString("raisonSociale"));
                e.setRib(rs.getString("rib"));
                e.setSigle(rs.getString("sigle"));

                listRIB.add(e);

            }
            rs.close();
            return listRIB;

        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ribSupprimer(String user, String adresseIP, String rib)  throws GrecoException{
        Connection con = null;
        try {
            con = dataSource.getConnection();

            CallableStatement stmt = con.prepareCall("CALL psFournisseurRIB_Delete(?, ?, ?)");
            if (user == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, user);
            }
            if (adresseIP == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, adresseIP);
            }
            if (rib == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, rib);
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ribAjout(String user_update, String ip_update, String fournisseurBanqueID, String fournisseurID, String codeBanque, String rib)  throws GrecoException{
        Connection con = null;
         
        try {
            con = dataSource.getConnection();
            
            if(fournisseurBanqueID == null){
                fournisseurBanqueID = "FB"+StringUtil.generatedID();
            }
                     
            CallableStatement stmt = con.prepareCall("CALL psFournisseurRIB_Insert(?, ?, ?, ?, ?, ?)");
            if (user_update == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, user_update);
            }
            if (ip_update == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, ip_update);
            }
            if (fournisseurBanqueID == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, fournisseurBanqueID);
            }
            if (fournisseurID == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, fournisseurID);
            }
            if (codeBanque == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, codeBanque);
            }
            if (rib == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, rib);
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(BanqueDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
