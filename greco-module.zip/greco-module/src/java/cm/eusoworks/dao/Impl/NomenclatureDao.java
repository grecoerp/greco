/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.INomenclatureDao;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.exception.GrecoException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class NomenclatureDao implements INomenclatureDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public void ajouterCategorie(Categorie act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierCategorie(Categorie act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Update(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerCategorie(String codeCategorie) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Delete(?)");
            stmt.setString(1, codeCategorie);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Categorie getCategorie(String codeCategorie) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Find(?)");
            
            stmt.setString(1, codeCategorie);

            Categorie o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Categorie();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Categorie> getListCategorieAll() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_SL()");

            List<Categorie> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Categorie o = new Categorie();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Categorie> getListCategorieByNiveau(int niveauID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Niveau(?)");
            
            stmt.setInt(1, niveauID);

            List<Categorie> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Categorie o = new Categorie();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Categorie> getListCategorieRacines() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Root()");

            List<Categorie> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Categorie o = new Categorie();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Categorie> getListCategorieChilds(String codeCategorie) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCategorie_Childs(?)");
            
            stmt.setString(1, codeCategorie);

            List<Categorie> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Categorie o = new Categorie();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));

                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    @Override
    public void ajouterFonction(Fonction act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierFonction(Fonction act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Update(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerFonction(String codeFonction) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Delete(?)");
            stmt.setString(1, codeFonction);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Fonction getFonction(String codeFonction) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Find(?)");
            
            stmt.setString(1, codeFonction);

            Fonction o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Fonction();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Fonction> getListFonctionAll() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_SL()");

            List<Fonction> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Fonction o = new Fonction();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Fonction> getListFonctionByNiveau(int niveauID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Niveau(?)");
            
            stmt.setInt(1, niveauID);

            List<Fonction> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Fonction o = new Fonction();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Fonction> getListFonctionRacines() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Root()");

            List<Fonction> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Fonction o = new Fonction();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Fonction> getListFonctionChilds(String codeCategorie) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psFonction_Childs(?)");
            
            stmt.setString(1, codeCategorie);

            List<Fonction> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Fonction o = new Fonction();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
    @Override
    public void ajouterLocalite(Localite act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierLocalite(Localite act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Update(?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerLocalite(String codeLocalite) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Delete(?)");
            stmt.setString(1, codeLocalite);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Localite getLocalite(String codeLocalite) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Find(?)");
            
            stmt.setString(1, codeLocalite);

            Localite o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Localite();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Localite> getListLocaliteAll() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_SL()");

            List<Localite> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Localite o = new Localite();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Localite> getListLocaliteByNiveau(int niveauID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Niveau(?)");
            
            stmt.setInt(1, niveauID);

            List<Localite> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Localite o = new Localite();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Localite> getListLocaliteRacines() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Root()");

            List<Localite> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Localite o = new Localite();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Localite> getListLocaliteChilds(String codeLocalite) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psLocalite_Childs(?)");
            
            stmt.setString(1, codeLocalite);

            List<Localite> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Localite o = new Localite();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    
    @Override
    public void ajouterCompte(Compte act, boolean creerIfNotExists) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());
            if(act.getNature() == null){
                stmt.setNull(10, java.sql.Types.INTEGER);
            }else {
                stmt.setString(10, act.getNature());
            }
            
            stmt.setBoolean(11, act.isLettrage());
            stmt.setBoolean(12, act.isPointage());
            stmt.setBoolean(13, act.isCentralisateur());
            stmt.setBoolean(14, act.isAffichage());
            stmt.setBoolean(15, creerIfNotExists);
            

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierCompte(Compte act) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (act.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, act.getUserUpdate());
            }
            if (act.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, act.getIpUpdate());
            }
            if (act.getCode() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, act.getCode());
            }
            if (act.getAbbreviationFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, act.getAbbreviationFr());
            }
            if (act.getAbbreviationUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, act.getAbbreviationUs());
            }
            if (act.getLibelleFr() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, act.getLibelleFr());
            }
            if (act.getLibelleUs() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, act.getLibelleUs());
            }
            if (act.getParentCode() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, act.getParentCode());
            }

            stmt.setInt(9, act.getNiveauID());
            if(act.getNature() == null){
                stmt.setNull(10, java.sql.Types.INTEGER);
            }else {
                stmt.setString(10, act.getNature());
            }
            stmt.setBoolean(11, act.isLettrage());
            stmt.setBoolean(12, act.isPointage());
            stmt.setBoolean(13, act.isCentralisateur());
            stmt.setBoolean(14, act.isAffichage());

            stmt.executeQuery();

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerCompte(String codeCompte) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Delete(?)");
            stmt.setString(1, codeCompte);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Compte getCompte(String codeCompte) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Find(?)");
            
            stmt.setString(1, codeCompte);

            Compte o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new Compte();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNature(rs.getString("nature"));
            }
            return o;
        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Compte> getListCompteAll() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_SL()");

            List<Compte> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Compte o = new Compte();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));
                o.setNature(rs.getString("nature"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Compte> getListCompteByNiveau(int niveauID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Niveau(?)");
            
            stmt.setInt(1, niveauID);

            List<Compte> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Compte o = new Compte();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));
                o.setNature(rs.getString("nature"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Compte> getListCompteRacines() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Root()");

            List<Compte> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Compte o = new Compte();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));
                o.setNature(rs.getString("nature"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Compte> getListCompteChilds(String codeCompte) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Childs(?)");
            
            stmt.setString(1, codeCompte);

            List<Compte> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Compte o = new Compte();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));
                o.setNature(rs.getString("nature"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public List<Compte> getListCompteUtilisables() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psCompte_Utilisables()");

            List<Compte> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Compte o = new Compte();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setParentCode(rs.getString("parent_Code"));
                if (rs.wasNull()) {
                    o.setParentCode(null);
                }
                o.setNiveauID(rs.getInt("niveauID"));
                o.setNbChilds(rs.getInt("childs"));
                o.setNature(rs.getString("nature"));


                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
