/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IDecisionDao;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.entities.exception.GrecoException;
import java.math.BigDecimal;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class DecisionDao implements IDecisionDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public String ajouterModele(DecisionModele d) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionmodeleI = con.prepareCall("CALL psDecisionModele_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (d.getLastUpdate() == null) {
                stmtpsdecisionmodeleI.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsdecisionmodeleI.setDate(1, new java.sql.Date(d.getLastUpdate().getTime()));
            }
            if (d.getUserUpdate() == null) {
                stmtpsdecisionmodeleI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(2, d.getUserUpdate());
            }
            if (d.getIpUpdate() == null) {
                stmtpsdecisionmodeleI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(3, d.getIpUpdate());
            }
            if (d.getModeleID() == null) {
                stmtpsdecisionmodeleI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(4, d.getModeleID());
            }
            if (d.getOrganisationID() == null) {
                stmtpsdecisionmodeleI.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(5, d.getOrganisationID());
            }
            if (d.getMillesime() == null) {
                stmtpsdecisionmodeleI.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(6, d.getMillesime());
            }
            if (d.getDescription() == null) {
                stmtpsdecisionmodeleI.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(7, d.getDescription());
            }
            if (d.getContenu() == null) {
                stmtpsdecisionmodeleI.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(8, d.getContenu());
            }
            if (d.getEntete1Fr() == null) {
                stmtpsdecisionmodeleI.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(9, d.getEntete1Fr());
            }
            if (d.getEntete2Fr() == null) {
                stmtpsdecisionmodeleI.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(10, d.getEntete2Fr());
            }
            if (d.getEntete3Fr() == null) {
                stmtpsdecisionmodeleI.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(11, d.getEntete3Fr());
            }
            if (d.getEntete4Fr() == null) {
                stmtpsdecisionmodeleI.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(12, d.getEntete4Fr());
            }
            if (d.getEntete5Fr() == null) {
                stmtpsdecisionmodeleI.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(13, d.getEntete5Fr());
            }
            
            if (d.getEntete1Us() == null) {
                stmtpsdecisionmodeleI.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(14, d.getEntete1Us());
            }
            if (d.getEntete2Us() == null) {
                stmtpsdecisionmodeleI.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(15, d.getEntete2Us());
            }
            if (d.getEntete3Us() == null) {
                stmtpsdecisionmodeleI.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(16, d.getEntete3Us());
            }
            if (d.getEntete4Us() == null) {
                stmtpsdecisionmodeleI.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(17, d.getEntete4Us());
            }
            if (d.getEntete5Us() == null) {
                stmtpsdecisionmodeleI.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(18, d.getEntete5Us());
            }
            
            stmtpsdecisionmodeleI.executeUpdate();
            return d.getModeleID();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierModele(DecisionModele d) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionmodeleI = con.prepareCall("CALL psDecisionModele_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (d.getLastUpdate() == null) {
                stmtpsdecisionmodeleI.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsdecisionmodeleI.setDate(1, new java.sql.Date(d.getLastUpdate().getTime()));
            }
            if (d.getUserUpdate() == null) {
                stmtpsdecisionmodeleI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(2, d.getUserUpdate());
            }
            if (d.getIpUpdate() == null) {
                stmtpsdecisionmodeleI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(3, d.getIpUpdate());
            }
            if (d.getModeleID() == null) {
                stmtpsdecisionmodeleI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(4, d.getModeleID());
            }
            if (d.getOrganisationID() == null) {
                stmtpsdecisionmodeleI.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(5, d.getOrganisationID());
            }
            if (d.getMillesime() == null) {
                stmtpsdecisionmodeleI.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(6, d.getMillesime());
            }
            if (d.getDescription() == null) {
                stmtpsdecisionmodeleI.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(7, d.getDescription());
            }
            if (d.getContenu() == null) {
                stmtpsdecisionmodeleI.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(8, d.getContenu());
            }
            if (d.getEntete1Fr() == null) {
                stmtpsdecisionmodeleI.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(9, d.getEntete1Fr());
            }
            if (d.getEntete2Fr() == null) {
                stmtpsdecisionmodeleI.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(10, d.getEntete2Fr());
            }
            if (d.getEntete3Fr() == null) {
                stmtpsdecisionmodeleI.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(11, d.getEntete3Fr());
            }
            if (d.getEntete4Fr() == null) {
                stmtpsdecisionmodeleI.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(12, d.getEntete4Fr());
            }
            if (d.getEntete5Fr() == null) {
                stmtpsdecisionmodeleI.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(13, d.getEntete5Fr());
            }
            
            if (d.getEntete1Us() == null) {
                stmtpsdecisionmodeleI.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(14, d.getEntete1Us());
            }
            if (d.getEntete2Us() == null) {
                stmtpsdecisionmodeleI.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(15, d.getEntete2Us());
            }
            if (d.getEntete3Us() == null) {
                stmtpsdecisionmodeleI.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(16, d.getEntete3Us());
            }
            if (d.getEntete4Us() == null) {
                stmtpsdecisionmodeleI.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(17, d.getEntete4Us());
            }
            if (d.getEntete5Us() == null) {
                stmtpsdecisionmodeleI.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(18, d.getEntete5Us());
            }
            stmtpsdecisionmodeleI.executeUpdate();

        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerModele(String modeleID, String user, String ipAdresse) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionmodeleD = con.prepareCall("CALL psDecisionModele_Delete( ?, ?, ?)");

            if (modeleID == null) {
                stmtpsdecisionmodeleD.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleD.setString(1, modeleID);
            }
            if (user == null) {
                stmtpsdecisionmodeleD.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleD.setString(2, user);
            }
            if (ipAdresse == null) {
                stmtpsdecisionmodeleD.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleD.setString(3, ipAdresse);
            }
            stmtpsdecisionmodeleD.executeUpdate();
            
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public DecisionModele getModele(String modeleID) {
        Connection con = null;
        DecisionModele e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionmodeleSL = con.prepareCall("CALL psDecisionModele_Find( ?)");

            if (modeleID == null) {
                stmtpsdecisionmodeleSL.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsdecisionmodeleSL.setString(1, modeleID);
            }

            ResultSet rs = stmtpsdecisionmodeleSL.executeQuery();
            while (rs.next()) {
                e = new DecisionModele();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setModeleID(rs.getString("modeleID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setDescription(rs.getString("description"));

                e.setContenu(rs.getString("contenu"));
                if (rs.wasNull()) {
                    e.setContenu(null);
                }
                e.setEntete1Fr(rs.getString("entete1Fr"));
                e.setEntete2Fr(rs.getString("entete2Fr"));
                e.setEntete3Fr(rs.getString("entete3Fr"));
                e.setEntete4Fr(rs.getString("entete4Fr"));
                e.setEntete5Fr(rs.getString("entete5Fr"));
                
                e.setEntete1Us(rs.getString("entete1Us"));
                e.setEntete2Us(rs.getString("entete2Us"));
                e.setEntete3Us(rs.getString("entete3Us"));
                e.setEntete4Us(rs.getString("entete4Us"));
                e.setEntete5Us(rs.getString("entete5Us"));
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<DecisionModele> getModeleByOrganisation(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionmodeleSL = con.prepareCall("CALL psDecisionModele_Search( ?, ?)");

            if (millesime == null) {
                stmtpsdecisionmodeleSL.setNull(1, java.sql.Types.CHAR);
            } else {
                stmtpsdecisionmodeleSL.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsdecisionmodeleSL.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleSL.setString(2, organisationID);
            }

            List<DecisionModele> list = new ArrayList<>();
            ResultSet rs = stmtpsdecisionmodeleSL.executeQuery();
            while (rs.next()) {
                DecisionModele e = new DecisionModele();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setModeleID(rs.getString("modeleID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setDescription(rs.getString("description"));

                e.setContenu(rs.getString("contenu"));
                if (rs.wasNull()) {
                    e.setContenu(null);
                }
                e.setEntete1Fr(rs.getString("entete1Fr"));
                e.setEntete2Fr(rs.getString("entete2Fr"));
                e.setEntete3Fr(rs.getString("entete3Fr"));
                e.setEntete4Fr(rs.getString("entete4Fr"));
                e.setEntete5Fr(rs.getString("entete5Fr"));
                
                e.setEntete1Us(rs.getString("entete1Us"));
                e.setEntete2Us(rs.getString("entete2Us"));
                e.setEntete3Us(rs.getString("entete3Us"));
                e.setEntete4Us(rs.getString("entete4Us"));
                e.setEntete5Us(rs.getString("entete5Us"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String ajouterDecision(Decision d) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionI = con.prepareCall("CALL psDecision_Insert( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (d.getLastUpdate() == null) {
                stmtpsdecisionI.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsdecisionI.setDate(1, new java.sql.Date(d.getLastUpdate().getTime()));
            }
            if (d.getUserUpdate() == null) {
                stmtpsdecisionI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(2, d.getUserUpdate());
            }
            if (d.getIpUpdate() == null) {
                stmtpsdecisionI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(3, d.getIpUpdate());
            }
            if (d.getDecisionID() == null) {
                stmtpsdecisionI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(4, d.getDecisionID());
            }
            if (d.getReference() == null) {
                stmtpsdecisionI.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(5, d.getReference());
            }
            if (d.getDateSignature() == null) {
                stmtpsdecisionI.setNull(6, java.sql.Types.DATE);
            } else {
                stmtpsdecisionI.setDate(6, new java.sql.Date(d.getDateSignature().getTime()));
            }
            if (d.getMontant() == null) {
                stmtpsdecisionI.setNull(7, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(7, d.getMontant());
            }
            if (d.getBeneficiaire() == null) {
                stmtpsdecisionI.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(8, d.getBeneficiaire());
            }
            if (d.getFournisseurID() == null) {
                stmtpsdecisionI.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(9, d.getFournisseurID());
            }
            if (d.getMatricule() == null) {
                stmtpsdecisionI.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(10, d.getMatricule());
            }
            if (d.getStructureBenefID() == null) {
                stmtpsdecisionI.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(11, d.getStructureBenefID());
            }
            if (d.getTacheID() == null) {
                stmtpsdecisionI.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(12, d.getTacheID());
            }
            if (d.getOrganisationID() == null) {
                stmtpsdecisionI.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(13, d.getOrganisationID());
            }
            if (d.getMillesime() == null) {
                stmtpsdecisionI.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(14, d.getMillesime());
            }
            if (d.getActiviteID() == null) {
                stmtpsdecisionI.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(15, d.getActiviteID());
            }
            if (d.getStructureID() == null) {
                stmtpsdecisionI.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(16, d.getStructureID());
            }
            if (d.getModeleID() == null) {
                stmtpsdecisionI.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(17, d.getModeleID());
            }
            if (d.getObjet() == null) {
                stmtpsdecisionI.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(18, d.getObjet());
            }
            if (d.getSignataire()== null) {
                stmtpsdecisionI.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(19, d.getSignataire());
            }
            if (d.getOrdonnateur()== null) {
                stmtpsdecisionI.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(20, d.getOrdonnateur());
            }
            if (d.getMontantTVA()== null) {
                stmtpsdecisionI.setNull(21, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(21, d.getMontantTVA());
            }
            if (d.getMontantIR()== null) {
                stmtpsdecisionI.setNull(22, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(22, d.getMontantIR());
            }
            if (d.getMontantHT()== null) {
                stmtpsdecisionI.setNull(23, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(23, d.getMontantHT());
            }
            if (d.getMontantTTC()== null) {
                stmtpsdecisionI.setNull(24, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(24, d.getMontantTTC());
            }
            if (d.getMontantNAP()== null) {
                stmtpsdecisionI.setNull(25, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(25, d.getMontantNAP());
            }
            if (d.getNumeroOPNap()== null) {
                stmtpsdecisionI.setNull(26, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(26, d.getNumeroOPNap());
            }
            if (d.getNumeroOPTaxe()== null) {
                stmtpsdecisionI.setNull(27, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(27, d.getNumeroOPTaxe());
            }
            if (d.getRib()== null) {
                stmtpsdecisionI.setNull(28, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(28, d.getRib());
            }

            stmtpsdecisionI.executeUpdate();
            return d.getDecisionID();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierDecision(Decision d) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionI = con.prepareCall("CALL psDecision_Update( ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

            if (d.getLastUpdate() == null) {
                stmtpsdecisionI.setNull(1, java.sql.Types.DATE);
            } else {
                stmtpsdecisionI.setDate(1, new java.sql.Date(d.getLastUpdate().getTime()));
            }
            if (d.getUserUpdate() == null) {
                stmtpsdecisionI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(2, d.getUserUpdate());
            }
            if (d.getIpUpdate() == null) {
                stmtpsdecisionI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(3, d.getIpUpdate());
            }
            if (d.getDecisionID() == null) {
                stmtpsdecisionI.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(4, d.getDecisionID());
            }
            if (d.getReference() == null) {
                stmtpsdecisionI.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(5, d.getReference());
            }
            if (d.getDateSignature() == null) {
                stmtpsdecisionI.setNull(6, java.sql.Types.DATE);
            } else {
                stmtpsdecisionI.setDate(6, new java.sql.Date(d.getDateSignature().getTime()));
            }
            if (d.getMontant() == null) {
                stmtpsdecisionI.setNull(7, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(7, d.getMontant());
            }
            if (d.getBeneficiaire() == null) {
                stmtpsdecisionI.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(8, d.getBeneficiaire());
            }
            if (d.getFournisseurID() == null) {
                stmtpsdecisionI.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(9, d.getFournisseurID());
            }
            if (d.getMatricule() == null) {
                stmtpsdecisionI.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(10, d.getMatricule());
            }
            if (d.getStructureBenefID() == null) {
                stmtpsdecisionI.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(11, d.getStructureBenefID());
            }
            if (d.getTacheID() == null) {
                stmtpsdecisionI.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(12, d.getTacheID());
            }
            if (d.getOrganisationID() == null) {
                stmtpsdecisionI.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(13, d.getOrganisationID());
            }
            if (d.getMillesime() == null) {
                stmtpsdecisionI.setNull(14, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(14, d.getMillesime());
            }
            if (d.getActiviteID() == null) {
                stmtpsdecisionI.setNull(15, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(15, d.getActiviteID());
            }
            if (d.getStructureID() == null) {
                stmtpsdecisionI.setNull(16, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(16, d.getStructureID());
            }
            if (d.getModeleID() == null) {
                stmtpsdecisionI.setNull(17, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(17, d.getModeleID());
            }
            if (d.getObjet() == null) {
                stmtpsdecisionI.setNull(18, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(18, d.getObjet());
            }
            if (d.getSignataire()== null) {
                stmtpsdecisionI.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(19, d.getSignataire());
            }
            if (d.getOrdonnateur()== null) {
                stmtpsdecisionI.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(20, d.getOrdonnateur());
            }
            if (d.getMontantTVA()== null) {
                stmtpsdecisionI.setNull(21, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(21, d.getMontantTVA());
            }
            if (d.getMontantIR()== null) {
                stmtpsdecisionI.setNull(22, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(22, d.getMontantIR());
            }
            if (d.getMontantHT()== null) {
                stmtpsdecisionI.setNull(23, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(23, d.getMontantHT());
            }
            if (d.getMontantTTC()== null) {
                stmtpsdecisionI.setNull(24, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(24, d.getMontantTTC());
            }
            if (d.getMontantNAP()== null) {
                stmtpsdecisionI.setNull(25, java.sql.Types.DECIMAL);
            } else {
                stmtpsdecisionI.setBigDecimal(25, d.getMontantNAP());
            }
            if (d.getNumeroOPNap()== null) {
                stmtpsdecisionI.setNull(26, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(26, d.getNumeroOPNap());
            }
            if (d.getNumeroOPTaxe()== null) {
                stmtpsdecisionI.setNull(27, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(27, d.getNumeroOPTaxe());
            }
            if (d.getRib()== null) {
                stmtpsdecisionI.setNull(28, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionI.setString(28, d.getRib());
            }
            
            stmtpsdecisionI.executeUpdate();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerDecision(String decisionID, String user, String ipAdresse) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionD = con.prepareCall("CALL psDecision_Delete( ?, ?, ?)");

            if (decisionID == null) {
                stmtpsdecisionD.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionD.setString(1, decisionID);
            }
            if (user == null) {
                stmtpsdecisionD.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionD.setString(2, user);
            }
            if (ipAdresse == null) {
                stmtpsdecisionD.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionD.setString(3, ipAdresse);
            }

            stmtpsdecisionD.executeUpdate();
        } catch (Exception ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Decision getDecision(String decisionID) {
        Connection con = null;
        Decision e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionSL = con.prepareCall("CALL psDecision_Find( ?)");

            if (decisionID == null) {
                stmtpsdecisionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(1, decisionID);
            }
            List<Decision> list = new ArrayList<>();
            ResultSet rs = stmtpsdecisionSL.executeQuery();
            while (rs.next()) {
                e = new Decision();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setDecisionID(rs.getString("decisionID"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setMontant(rs.getBigDecimal("montant"));
                if (rs.wasNull()) {
                    e.setMontant(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setBudget(rs.getString("budget"));

                e.setOrganisationLibelle(rs.getString("organisationLibelle"));

                e.setImputation(rs.getString("imputation"));
                
                e.setModeleID(rs.getString("modeleID"));
                
                e.setObjet(rs.getString("objet"));
                
                e.setSignataire(rs.getString("signataire"));
                
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                e.setNumeroOPNap(rs.getString("numeroOPNap"));
                e.setNumeroOPTaxe(rs.getString("numeroOPTaxe"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception ev) {
                }

                list.add(e);
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Decision> getDecisionByOrganisation(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionSL = con.prepareCall("CALL psDecision_SearchByOrganisation( ?, ?)");

            if (millesime == null) {
                stmtpsdecisionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsdecisionSL.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(2, organisationID);
            }
            List<Decision> list = new ArrayList<>();
            ResultSet rs = stmtpsdecisionSL.executeQuery();
            while (rs.next()) {
                Decision e = new Decision();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setDecisionID(rs.getString("decisionID"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setMontant(rs.getBigDecimal("montant"));
                if (rs.wasNull()) {
                    e.setMontant(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setBudget(rs.getString("budget"));

                e.setOrganisationLibelle(rs.getString("organisationLibelle"));

                e.setImputation(rs.getString("imputation"));
                
                e.setModeleID(rs.getString("modeleID"));
                
                e.setObjet(rs.getString("objet"));
                
                e.setSignataire(rs.getString("signataire"));
                
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                e.setNumeroOPNap(rs.getString("numeroOPNap"));
                e.setNumeroOPTaxe(rs.getString("numeroOPTaxe"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception ev) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Decision> getDecisionByOrganisationAndDate(String millesime, String organisationID, Date date) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionSL = con.prepareCall("CALL psDecision_SearchByDate( ?, ?, ?)");

            if (millesime == null) {
                stmtpsdecisionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsdecisionSL.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(2, organisationID);
            }
            if (date == null) {
                stmtpsdecisionSL.setNull(3, java.sql.Types.DATE);
            } else {
                stmtpsdecisionSL.setDate(3, new java.sql.Date(date.getTime()));
            }
            List<Decision> list = new ArrayList<>();
            ResultSet rs = stmtpsdecisionSL.executeQuery();
            while (rs.next()) {
                Decision e = new Decision();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setDecisionID(rs.getString("decisionID"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setMontant(rs.getBigDecimal("montant"));
                if (rs.wasNull()) {
                    e.setMontant(null);
                }
                e.setBeneficiaire(rs.getString("beneficiaire"));
                if (rs.wasNull()) {
                    e.setBeneficiaire(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));
                if (rs.wasNull()) {
                    e.setFournisseurID(null);
                }
                e.setMatricule(rs.getString("matricule"));
                if (rs.wasNull()) {
                    e.setMatricule(null);
                }
                e.setStructureBenefID(rs.getString("structureBenefID"));
                if (rs.wasNull()) {
                    e.setStructureBenefID(null);
                }
                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setActiviteID(rs.getString("activiteID"));

                e.setStructureID(rs.getString("structureID"));

                e.setBudget(rs.getString("budget"));

                e.setOrganisationLibelle(rs.getString("organisationLibelle"));

                e.setImputation(rs.getString("imputation"));
                
                e.setModeleID(rs.getString("modeleID"));
                
                e.setObjet(rs.getString("objet"));
                
                e.setSignataire(rs.getString("signataire"));
                
                e.setOrdonnateur(rs.getString("ordonnateur"));
                e.setMontantTVA(rs.getBigDecimal("montantTVA"));
                e.setMontantIR(rs.getBigDecimal("montantIR"));
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                e.setMontantNAP(rs.getBigDecimal("montantNAP"));
                e.setNumeroOPNap(rs.getString("numeroOPNap"));
                e.setNumeroOPTaxe(rs.getString("numeroOPTaxe"));
                e.setEtat(rs.getInt("etat"));
                try {
                    e.setNumDossier(rs.getString("numDossier"));
                } catch (Exception ev) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Date> getDateDecisionByOrganisation(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionSL = con.prepareCall("CALL psDecision_GetDate( ?, ?)");

            if (millesime == null) {
                stmtpsdecisionSL.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsdecisionSL.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionSL.setString(2, organisationID);
            }
            
            List<Date> list = new ArrayList<>();
            ResultSet rs = stmtpsdecisionSL.executeQuery();
            while (rs.next()) {
                list.add(rs.getDate("date"));
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void dupliquerModele(String modeleID, String name, String newModeleID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsdecisionmodeleI = con.prepareCall("CALL psDecisionModele_Dupliquer( ?, ?, ?)");

            if (modeleID == null) {
                stmtpsdecisionmodeleI.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(1, modeleID);
            }
            if (name == null) {
                stmtpsdecisionmodeleI.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(2, name);
            }
            if (newModeleID == null) {
                stmtpsdecisionmodeleI.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsdecisionmodeleI.setString(3, newModeleID);
            }
            
            stmtpsdecisionmodeleI.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    @Override
    public void reservationDecision(String decisionID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psDecision_Reserve( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (decisionID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, decisionID);
            }
            stmtpsEngagementReserve.setBoolean(2, reserve);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            reserve = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

     @Override
    public void reservationDecisionAnnuler(String decisionID, boolean annule, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psDecision_Reserve_Annuler( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (decisionID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, decisionID);
            }
            stmtpsEngagementReserve.setBoolean(2, annule);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            annule = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
