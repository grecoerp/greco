/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IBonCommandeDao;
import cm.eusoworks.dao.IEngagementDao;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.BcaArticles;
import cm.eusoworks.entities.view.VueStructureBCA;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.view.VueControle;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class BonCommandeDao implements IBonCommandeDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @EJB
    IEngagementDao engagementDao;

    @Override
    public String ajouter(Bca a) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBca_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (a.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, a.getUserUpdate());
            }
            if (a.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, a.getIpUpdate());
            }
            if (a.getBcaID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, a.getBcaID());
            }
            if (a.getObjet() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, a.getObjet());
            }
            if (a.getReference() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, a.getReference());
            }
            if (a.getDelaiLivraison() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(a.getDelaiLivraison().getTime()));
            }
            if (a.getDateSignature() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(a.getDateSignature().getTime()));
            }
            if (a.getLieuSignature() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, a.getLieuSignature());
            }
            if (a.getEntete1() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, a.getEntete1());
            }
            if (a.getEntete2() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, a.getEntete2());
            }
            if (a.getEntete3() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, a.getEntete3());
            }
            if (a.getEntete4() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, a.getEntete4());
            }
            if (a.getEntete5() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, a.getEntete5());
            }
            if (a.getMontantTTC() == null) {
                stmt.setNull(14, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(14, a.getMontantTTC());
            }
            if (a.getMontantHT() == null) {
                stmt.setNull(15, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(15, a.getMontantHT());
            }
            if (a.getTauxTVA() == null) {
                stmt.setNull(16, java.sql.Types.FLOAT);
            } else {
                stmt.setFloat(16, a.getTauxTVA());
            }
            if (a.getTauxIR() == null) {
                stmt.setNull(17, java.sql.Types.FLOAT);
            } else {
                stmt.setFloat(17, a.getTauxIR());
            }
            if (a.getNap() == null) {
                stmt.setNull(18, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(18, a.getNap());
            }
            if (a.getFournisseurID() == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, a.getFournisseurID());
            }
            if (a.getMatriculeOrdo() == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, a.getMatriculeOrdo());
            }
            if (a.getTacheID() == null) {
                stmt.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(21, a.getTacheID());
            }
            if (a.getOrganisationID() == null) {
                stmt.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(22, a.getOrganisationID());
            }
            if (a.getMillesime() == null) {
                stmt.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(23, a.getMillesime());
            }
            if (a.getActiviteID() == null) {
                stmt.setNull(24, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(24, a.getActiviteID());
            }
            if (a.getStructureID() == null) {
                stmt.setNull(25, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(25, a.getStructureID());
            }
            try {
                if (a.getTypeID() == null) {
                    stmt.setString(26, "1");
                } else {
                    stmt.setString(26, a.getTypeID());
                }
            } catch (Exception e) {
            }
            try {
                if (a.getMontantRG() == null) {
                    stmt.setNull(27, java.sql.Types.DECIMAL);
                } else {
                    stmt.setBigDecimal(27, a.getMontantRG());
                }
            } catch (Exception e) {
            }

            stmt.executeQuery();

            return a.getBcaID();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(Bca a) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBca_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (a.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, a.getUserUpdate());
            }
            if (a.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, a.getIpUpdate());
            }
            if (a.getBcaID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, a.getBcaID());
            }
            if (a.getObjet() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, a.getObjet());
            }
            if (a.getReference() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, a.getReference());
            }
            if (a.getDelaiLivraison() == null) {
                stmt.setNull(6, java.sql.Types.DATE);
            } else {
                stmt.setDate(6, new java.sql.Date(a.getDelaiLivraison().getTime()));
            }
            if (a.getDateSignature() == null) {
                stmt.setNull(7, java.sql.Types.DATE);
            } else {
                stmt.setDate(7, new java.sql.Date(a.getDateSignature().getTime()));
            }
            if (a.getLieuSignature() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, a.getLieuSignature());
            }
            if (a.getEntete1() == null) {
                stmt.setNull(9, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(9, a.getEntete1());
            }
            if (a.getEntete2() == null) {
                stmt.setNull(10, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(10, a.getEntete2());
            }
            if (a.getEntete3() == null) {
                stmt.setNull(11, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(11, a.getEntete3());
            }
            if (a.getEntete4() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, a.getEntete4());
            }
            if (a.getEntete5() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, a.getEntete5());
            }
            if (a.getMontantTTC() == null) {
                stmt.setNull(14, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(14, a.getMontantTTC());
            }
            if (a.getMontantHT() == null) {
                stmt.setNull(15, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(15, a.getMontantHT());
            }
            if (a.getTauxTVA() == null) {
                stmt.setNull(16, java.sql.Types.FLOAT);
            } else {
                stmt.setFloat(16, a.getTauxTVA());
            }
            if (a.getTauxIR() == null) {
                stmt.setNull(17, java.sql.Types.FLOAT);
            } else {
                stmt.setFloat(17, a.getTauxIR());
            }
            if (a.getNap() == null) {
                stmt.setNull(18, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(18, a.getNap());
            }
            if (a.getFournisseurID() == null) {
                stmt.setNull(19, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(19, a.getFournisseurID());
            }
            if (a.getMatriculeOrdo() == null) {
                stmt.setNull(20, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(20, a.getMatriculeOrdo());
            }
            if (a.getTacheID() == null) {
                stmt.setNull(21, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(21, a.getTacheID());
            }
            if (a.getOrganisationID() == null) {
                stmt.setNull(22, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(22, a.getOrganisationID());
            }
            if (a.getMillesime() == null) {
                stmt.setNull(23, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(23, a.getMillesime());
            }
            if (a.getActiviteID() == null) {
                stmt.setNull(24, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(24, a.getActiviteID());
            }
            if (a.getStructureID() == null) {
                stmt.setNull(25, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(25, a.getStructureID());
            }

            try {
                if (a.getTypeID() == null) {
                    stmt.setString(26, "1");
                } else {
                    stmt.setString(26, a.getTypeID());
                }
            } catch (Exception e) {
            }
            try {
                if (a.getMontantRG() == null) {
                    stmt.setNull(27, java.sql.Types.DECIMAL);
                } else {
                    stmt.setBigDecimal(27, a.getMontantRG());
                }
            } catch (Exception e) {
            }

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String bcaID, String user, String ipAdresse) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBca_Delete(?, ?, ?)");
            stmt.setString(1, bcaID);
            stmt.setString(2, user);
            stmt.setString(3, ipAdresse);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Bca getBCA(String bcaID) {
        Connection con = null;
        Bca e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_Find( ?)");

            if (bcaID == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, bcaID);
            }

            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setTypeID(rs.getString("typeID"));
                } catch (Exception ee) {
                }
                try {
                    e.setMontantRG(rs.getBigDecimal("montantRG"));
                } catch (Exception ezz) {
                }
            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByOrganisation(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByOrganisation( ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByOrganisationNotUsed(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByOrganisationNotUsed( ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByFournisseur(String millesime, String organisationID, String fournisseurID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByFournisseur( ?, ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            if (fournisseurID == null) {
                stmtpsBCAS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(3, fournisseurID);
            }
            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByOrdonnateur(String millesime, String organisationID, String matriculeOrdo) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByOrdonnateur( ?, ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            if (matriculeOrdo == null) {
                stmtpsBCAS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(3, matriculeOrdo);
            }
            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByTache(String millesime, String organisationID, String tacheID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByTache( ?, ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            if (tacheID == null) {
                stmtpsBCAS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(3, tacheID);
            }
            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }
                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByStructure( ?, ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            if (structureID == null) {
                stmtpsBCAS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(3, structureID);
            }
            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID, int etat) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByStructureEtat( ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            if (structureID == null) {
                stmtpsBCAS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(3, structureID);
            }

            stmtpsBCAS.setInt(4, etat);

            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }
                try {
                    e.setEtat(rs.getInt("etat"));
                } catch (Exception ek) {
                    ek.printStackTrace();
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ajouterLigne(BcaArticles a) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBcaArticle_Insert(?, ?, ?, ?, ?, ?)");
            if (a.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, a.getUserUpdate());
            }
            if (a.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, a.getIpUpdate());
            }
            if (a.getAmId() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, a.getAmId());
            }
            if (a.getPrixUnitaire() == null) {
                stmt.setNull(4, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(4, a.getPrixUnitaire());
            }
            stmt.setFloat(5, a.getQuantite());
            if (a.getBcaID() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, a.getBcaID());
            }

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierLigne(BcaArticles a) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBcaArticle_Update(?, ?, ?, ?, ?, ?)");
            if (a.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, a.getUserUpdate());
            }
            if (a.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, a.getIpUpdate());
            }
            if (a.getAmId() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, a.getAmId());
            }
            if (a.getPrixUnitaire() == null) {
                stmt.setNull(4, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(4, a.getPrixUnitaire());
            }
            stmt.setFloat(5, a.getQuantite());
            if (a.getBcaID() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, a.getBcaID());
            }

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerLigne(String bcaId, String amId, String user, String ip) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBcaArticle_Delete(?, ?, ?,?)");
            stmt.setString(1, bcaId);
            stmt.setString(2, amId);
            stmt.setString(3, user);
            stmt.setString(4, ip);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<BcaArticles> getBCALignes(String bcaID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAARTICLESS = con.prepareCall("CALL psBcaArticle_Lignes( ?)");

            if (bcaID == null) {
                stmtpsBCAARTICLESS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAARTICLESS.setString(1, bcaID);
            }
            List<BcaArticles> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAARTICLESS.executeQuery();
            while (rs.next()) {
                BcaArticles e = new BcaArticles();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setAmId(rs.getString("amId"));

                e.setPrixUnitaire(rs.getBigDecimal("prixUnitaire"));

                e.setQuantite(rs.getInt("quantite"));

                e.setBcaID(rs.getString("bcaID"));

                e.setRefArticle(rs.getString("refArticle"));

                e.setDesignation(rs.getString("designation"));

                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));

                e.setNumOrdre(rs.getInt("numOrdre"));

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public BcaArticles getBCAArticle(String bcaID, String amId) {
        Connection con = null;
        BcaArticles e = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAARTICLESS = con.prepareCall("CALL psBcaArticle_Find( ?)");

            if (bcaID == null) {
                stmtpsBCAARTICLESS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAARTICLESS.setString(1, bcaID);
            }
            if (amId == null) {
                stmtpsBCAARTICLESS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAARTICLESS.setString(2, amId);
            }

            ResultSet rs = stmtpsBCAARTICLESS.executeQuery();
            while (rs.next()) {
                e = new BcaArticles();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setAmId(rs.getString("amId"));

                e.setPrixUnitaire(rs.getBigDecimal("prixUnitaire"));

                e.setQuantite(rs.getInt("quantite"));

                e.setBcaID(rs.getString("bcaID"));

                e.setRefArticle(rs.getString("refArticle"));

                e.setDesignation(rs.getString("designation"));

                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));

                e.setNumOrdre(rs.getInt("numOrdre"));

            }
            rs.close();
            return e;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueStructureBCA> getBCANumberByStructure(String millesime, String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBcaNumberByStructure = con.prepareCall("CALL psBca_NumberByStructure( ?, ?, ?)");

            if (millesime == null) {
                stmtpsBcaNumberByStructure.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBcaNumberByStructure.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBcaNumberByStructure.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBcaNumberByStructure.setString(2, organisationID);
            }

            stmtpsBcaNumberByStructure.setString(3, "1");

            List<VueStructureBCA> list = new ArrayList<>();
            ResultSet rs = stmtpsBcaNumberByStructure.executeQuery();
            while (rs.next()) {
                VueStructureBCA e = new VueStructureBCA();

                e.setStructureID(rs.getString("structureID"));

                e.setCode(rs.getString("code"));

                e.setAbbreviationFr(rs.getString("abbreviationFr"));

                e.setAbbreviationUs(rs.getString("abbreviationUs"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));

                e.setNbBCA(rs.getInt("nbBCA"));

                e.setEtat(rs.getInt("etat"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerTousArticles(String bcaID, String user, String ip) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBcaArticle_DeleteAll(?, ?, ?)");
            stmt.setString(1, bcaID);
            stmt.setString(2, user);
            stmt.setString(3, ip);
            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Article> getArticleLignes(String bcaID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAARTICLESS = con.prepareCall("CALL psBcaArticle_LignesA( ?)");

            if (bcaID == null) {
                stmtpsBCAARTICLESS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAARTICLESS.setString(1, bcaID);
            }
            List<Article> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAARTICLESS.executeQuery();
            while (rs.next()) {
                Article e = new Article();

                e.setAmId(rs.getString("amId"));

                e.setSrId(rs.getString("srId"));
                if (rs.wasNull()) {
                    e.setSrId(null);
                }
                e.setMillesime(rs.getString("millesime"));
                if (rs.wasNull()) {
                    e.setMillesime(null);
                }
                e.setNumRubrique(rs.getString("numRubrique"));
                if (rs.wasNull()) {
                    e.setNumRubrique(null);
                }
                e.setNumSousRubrique(rs.getString("numSousRubrique"));
                if (rs.wasNull()) {
                    e.setNumSousRubrique(null);
                }
                e.setRefArticle(rs.getString("refArticle"));
                if (rs.wasNull()) {
                    e.setRefArticle(null);
                }
                e.setDateDebutValid(rs.getDate("dateDebutValid"));
                if (rs.wasNull()) {
                    e.setDateDebutValid(null);
                }
                e.setDateFinValid(rs.getDate("dateFinValid"));
                if (rs.wasNull()) {
                    e.setDateFinValid(null);
                }
                e.setDesignation(rs.getString("designation"));
                if (rs.wasNull()) {
                    e.setDesignation(null);
                }
                e.setConditionnement(rs.getString("conditionnement"));
                if (rs.wasNull()) {
                    e.setConditionnement(null);
                }
                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));
                if (rs.wasNull()) {
                    e.setPrixDeReference(null);
                }
                e.setPrixUnitaire(rs.getBigDecimal("prixUnitaire"));
                if (rs.wasNull()) {
                    e.setPrixUnitaire(null);
                }
                e.setPrixTotal(rs.getBigDecimal("prixTotal"));
                if (rs.wasNull()) {
                    e.setPrixTotal(null);
                }
                try {
                    e.setPrixMax(rs.getBigDecimal("prixMax"));
                    if (rs.wasNull()) {
                        e.setPrixMax(null);
                    }
                } catch (Exception ee) {
                }
                e.setQuantite(rs.getFloat("quantite"));
                e.setNumOrdre(rs.getInt("numOrdre"));

                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueControle> getControleResult(String bcaID, String typeID) {
        List<VueControle> list = new ArrayList<>();
        int type = 1;
        try {
            type = Integer.valueOf(typeID);
        } catch (Exception e) {
        }
        if (type == 1) {
            VueControle v1 = engagementDao.controle(bcaID, "Accréditation du gestionnaire", type, 1);
            v1.setNumeroControle(1);
            VueControle v2 = engagementDao.controle(bcaID, "Procédure. Montant < 5 000 000", type, 2);
            v2.setNumeroControle(2);
            VueControle v3 = engagementDao.controle(bcaID, "Disponible sur la tâche", type, 3);
            v3.setNumeroControle(3);
            VueControle v4 = engagementDao.controle(bcaID, "Morcellement de la dépense", type, 4);
            v4.setNumeroControle(4);
            VueControle v5 = engagementDao.controle(bcaID, "Respect des prix de la mercuriale", type, 5);
            v5.setNumeroControle(5);
            VueControle v6 = engagementDao.controle(bcaID, "Disponibilité du Relevé d'identité bancaire", type, 6);
            v6.setNumeroControle(6);

            list.add(v1);
            list.add(v2);
            list.add(v3);
            list.add(v4);
            list.add(v5);
            list.add(v6);
        }
        else if (type == 2) {
            VueControle v1 = engagementDao.controle(bcaID, "Accréditation du gestionnaire", type, 1);
            v1.setNumeroControle(1);
            VueControle v2 = engagementDao.controle(bcaID, "Procédure. 5 000 000 >= LC < 50 000 000", type, 2);
            v2.setNumeroControle(2);
            VueControle v3 = engagementDao.controle(bcaID, "Disponible sur la tâche", type, 3);
            v3.setNumeroControle(3);
            VueControle v5 = engagementDao.controle(bcaID, "Respect des prix de la mercuriale", type, 5);
            v5.setNumeroControle(5);
            VueControle v6 = engagementDao.controle(bcaID, "Disponibilité du Relevé d'identité bancaire", type, 6);
            v6.setNumeroControle(6);

            list.add(v1);
            list.add(v2);
            list.add(v3);
            list.add(v5);
            list.add(v6);
        }
        else if (type == 3) {
            VueControle v1 = engagementDao.controle(bcaID, "Accréditation du gestionnaire", type, 1);
            v1.setNumeroControle(1);
            VueControle v2 = engagementDao.controle(bcaID, "Procédure. MARCHE >= 50 000 000", type, 2);
            v2.setNumeroControle(2);
            VueControle v3 = engagementDao.controle(bcaID, "Disponible sur la tâche", type, 3);
            v3.setNumeroControle(3);
            VueControle v5 = engagementDao.controle(bcaID, "Respect des prix de la mercuriale", type, 5);
            v5.setNumeroControle(5);
            VueControle v6 = engagementDao.controle(bcaID, "Disponibilité du Relevé d'identité bancaire", type, 6);
            v6.setNumeroControle(6);

            list.add(v1);
            list.add(v2);
            list.add(v3);
            list.add(v5);
            list.add(v6);
        }
        else if (type == 4) {
            VueControle v11 = engagementDao.controle(bcaID, "Accréditation du gestionnaire", type, 11);
            v11.setNumeroControle(11);
            VueControle v8 = engagementDao.controle(bcaID, "Disponible sur la tâche", type, 8);
            v8.setNumeroControle(8);
            VueControle v9 = engagementDao.controle(bcaID, "Chevauchement de période de mission", type, 9);
            v9.setNumeroControle(9);
            VueControle v10 = engagementDao.controle(bcaID, "Quota de jours de mission", type, 10);
            v10.setNumeroControle(10);
            VueControle v13 = engagementDao.controle(bcaID, "Vérification de l'imputation ", type, 13);
            v13.setNumeroControle(13);

            list.add(v11);
            list.add(v8);
            list.add(v9);
            list.add(v10);
            list.add(v13);
        }
        else if (type == 5) {
            VueControle v12 = engagementDao.controle(bcaID, "Accréditation du gestionnaire", type, 12);
            v12.setNumeroControle(12);
            VueControle v7 = engagementDao.controle(bcaID, "Disponible sur la tâche", type, 7);
            v7.setNumeroControle(7);
            VueControle v6 = engagementDao.controle(bcaID, "Disponibilité du Relevé d'identité bancaire", type, 6);
            v6.setNumeroControle(6);

            list.add(v12);
            list.add(v7);
            list.add(v6);
        }

        return list;
    }

    @Override
    public void reservationBCA(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psBca_Reserve( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (bcaID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, bcaID);
            }
            stmtpsEngagementReserve.setBoolean(2, reserve);
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            reserve = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierRIB(String bcaID, String rib) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psBca_UpdateRIB( ?, ?)");
            if (bcaID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, bcaID);
            }

            if (rib == null) {
                stmtpsEngagementReserve.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(2, rib);
            }

            stmtpsEngagementReserve.executeUpdate();

        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ajouterLigneDefinitive(BcaArticles a) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBcaArticleDefinitif_Insert(?, ?, ?, ?, ?, ?, ?)");
            if (a.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, a.getUserUpdate());
            }
            if (a.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, a.getIpUpdate());
            }
            if (a.getAmId() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, a.getAmId());
            }
            if (a.getPrixUnitaire() == null) {
                stmt.setNull(4, java.sql.Types.DECIMAL);
            } else {
                stmt.setBigDecimal(4, a.getPrixUnitaire());
            }
            stmt.setFloat(5, a.getQuantite());
            if (a.getBcaID() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, a.getBcaID());
            }
            if (a.getLiquidationID() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, a.getLiquidationID());
            }

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

    }

    @Override
    public List<BcaArticles> getBCALignesDefinitive(String liquidationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAARTICLESS = con.prepareCall("CALL psBcaArticleDefinitif_Lignes( ?)");

            if (liquidationID == null) {
                stmtpsBCAARTICLESS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAARTICLESS.setString(1, liquidationID);
            }
            List<BcaArticles> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAARTICLESS.executeQuery();
            while (rs.next()) {
                BcaArticles e = new BcaArticles();

                e.setLastUpdate(rs.getDate("last_update"));

                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setAmId(rs.getString("amId"));

                e.setPrixUnitaire(rs.getBigDecimal("prixUnitaire"));

                e.setQuantite(rs.getInt("quantite"));

                e.setBcaID(rs.getString("bcaID"));

                e.setRefArticle(rs.getString("refArticle"));

                e.setDesignation(rs.getString("designation"));

                e.setPrixDeReference(rs.getBigDecimal("prixDeReference"));

                e.setNumOrdre(rs.getInt("numOrdre"));

                try {
                    e.setLiquidationID(rs.getString("liquidationID"));
                } catch (Exception ex) {
                }
                list.add(e);

            }
            rs.close();
            return list;
        } catch (Exception ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerTousArticlesDefinitive(String liquidationID, String user, String ip) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psBcaArticleDefinitif_DeleteAll(?, ?, ?)");
            stmt.setString(1, liquidationID);
            stmt.setString(2, user);
            stmt.setString(3, ip);
            stmt.executeQuery();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueStructureBCA> getBCANumberByStructure(String millesime, String organisationID, String typeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBcaNumberByStructure = con.prepareCall("CALL psBca_NumberByStructure( ?, ?, ?)");

            if (millesime == null) {
                stmtpsBcaNumberByStructure.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBcaNumberByStructure.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBcaNumberByStructure.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBcaNumberByStructure.setString(2, organisationID);
            }
            if (typeID == null) {
                stmtpsBcaNumberByStructure.setString(3, "1");
            } else {
                stmtpsBcaNumberByStructure.setString(3, typeID);
            }

            List<VueStructureBCA> list = new ArrayList<>();
            ResultSet rs = stmtpsBcaNumberByStructure.executeQuery();
            while (rs.next()) {
                VueStructureBCA e = new VueStructureBCA();

                e.setStructureID(rs.getString("structureID"));

                e.setCode(rs.getString("code"));

                e.setAbbreviationFr(rs.getString("abbreviationFr"));

                e.setAbbreviationUs(rs.getString("abbreviationUs"));

                e.setLibelleFr(rs.getString("libelleFr"));

                e.setLibelleUs(rs.getString("libelleUs"));

                e.setNbBCA(rs.getInt("nbBCA"));

                e.setEtat(rs.getInt("etat"));

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID, int etat, String typeID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsBCAS = con.prepareCall("CALL psBCA_SearchByStructureEtatType( ?, ?, ?, ?, ?)");

            if (millesime == null) {
                stmtpsBCAS.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(1, millesime);
            }
            if (organisationID == null) {
                stmtpsBCAS.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(2, organisationID);
            }
            if (structureID == null) {
                stmtpsBCAS.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(3, structureID);
            }

            stmtpsBCAS.setInt(4, etat);

            if (typeID == null) {
                stmtpsBCAS.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsBCAS.setString(5, typeID);
            }

            List<Bca> list = new ArrayList<>();
            ResultSet rs = stmtpsBCAS.executeQuery();
            while (rs.next()) {
                Bca e = new Bca();

                e.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    e.setLastUpdate(null);
                }
                e.setUserUpdate(rs.getString("user_update"));

                e.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    e.setIpUpdate(null);
                }
                e.setBcaID(rs.getString("bcaID"));

                e.setObjet(rs.getString("objet"));

                e.setReference(rs.getString("reference"));
                if (rs.wasNull()) {
                    e.setReference(null);
                }
                e.setDelaiLivraison(rs.getDate("delaiLivraison"));
                if (rs.wasNull()) {
                    e.setDelaiLivraison(null);
                }
                e.setDateSignature(rs.getDate("dateSignature"));
                if (rs.wasNull()) {
                    e.setDateSignature(null);
                }
                e.setLieuSignature(rs.getString("lieuSignature"));
                if (rs.wasNull()) {
                    e.setLieuSignature(null);
                }
                e.setEntete1(rs.getString("entete1"));
                if (rs.wasNull()) {
                    e.setEntete1(null);
                }
                e.setEntete2(rs.getString("entete2"));
                if (rs.wasNull()) {
                    e.setEntete2(null);
                }
                e.setEntete3(rs.getString("entete3"));
                if (rs.wasNull()) {
                    e.setEntete3(null);
                }
                e.setEntete4(rs.getString("entete4"));
                if (rs.wasNull()) {
                    e.setEntete4(null);
                }
                e.setEntete5(rs.getString("entete5"));
                if (rs.wasNull()) {
                    e.setEntete5(null);
                }
                e.setMontantTTC(rs.getBigDecimal("montantTTC"));
                if (rs.wasNull()) {
                    e.setMontantTTC(null);
                }
                e.setMontantHT(rs.getBigDecimal("montantHT"));
                if (rs.wasNull()) {
                    e.setMontantHT(null);
                }
                e.setTauxTVA(rs.getFloat("tauxTVA"));
                if (rs.wasNull()) {
                    e.setTauxTVA(null);
                }
                e.setTauxIR(rs.getFloat("tauxIR"));
                if (rs.wasNull()) {
                    e.setTauxIR(null);
                }
                e.setNap(rs.getBigDecimal("nap"));
                if (rs.wasNull()) {
                    e.setNap(null);
                }
                e.setFournisseurID(rs.getString("fournisseurID"));

                e.setMatriculeOrdo(rs.getString("matriculeOrdo"));

                e.setTacheID(rs.getString("tacheID"));

                e.setOrganisationID(rs.getString("organisationID"));

                e.setMillesime(rs.getString("millesime"));

                e.setFournisseur(rs.getString("fournisseur"));

                e.setStructureID(rs.getString("structureID"));

                e.setActiviteID(rs.getString("activiteID"));

                try {
                    e.setBudgetExploite(rs.getString("budgetExploite"));
                } catch (Exception en) {
                    en.printStackTrace();
                }
                try {
                    e.setEtat(rs.getInt("etat"));
                } catch (Exception ek) {
                    ek.printStackTrace();
                }

                try {
                    e.setTypeID(rs.getString("typeID"));
                } catch (Exception eh) {
                }
                try {
                    e.setMontantRG(rs.getBigDecimal("montantRG"));
                } catch (Exception enn) {
                }

                list.add(e);
            }
            rs.close();
            return list;
        } catch (Exception ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(BonCommandeDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void reservationBCAAnnuler(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmtpsEngagementReserve = con.prepareCall("CALL psBca_Reserve_Annuler( ?, ?, ?, ?, ?)");
            stmtpsEngagementReserve.registerOutParameter(2, java.sql.Types.BOOLEAN);
            stmtpsEngagementReserve.registerOutParameter(3, java.sql.Types.VARCHAR);
            if (bcaID == null) {
                stmtpsEngagementReserve.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(1, bcaID);
            }
            stmtpsEngagementReserve.setBoolean(2, reserve);
            
            if (motif == null) {
                stmtpsEngagementReserve.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(3, motif);
            }
            if (login == null) {
                stmtpsEngagementReserve.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(4, login);
            }
            if (adresseIP == null) {
                stmtpsEngagementReserve.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmtpsEngagementReserve.setString(5, adresseIP);
            }

            stmtpsEngagementReserve.executeUpdate();

            reserve = stmtpsEngagementReserve.getBoolean(2);
            motif = stmtpsEngagementReserve.getString(3);
        } catch (Exception ex) {
            ex.printStackTrace();
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (Exception ex) {
                Logger.getLogger(EngagementDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
