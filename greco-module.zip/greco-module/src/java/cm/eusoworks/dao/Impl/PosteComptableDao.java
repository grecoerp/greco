/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IPosteComptableDao;
import cm.eusoworks.entities.model.PosteComptable;
import cm.eusoworks.entities.model.PosteComptableNature;
import cm.eusoworks.entities.exception.GrecoException;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class PosteComptableDao implements IPosteComptableDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;
    
    
    @Override
    public void ajouter(PosteComptable pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_Insert(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getPosteComptableID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getPosteComptableID());
            }
            if (pc.getCode() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getCode());
            }
            if (pc.getAbbreviationFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getAbbreviationFr());
            }
            if (pc.getAbbreviationUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, pc.getAbbreviationUs());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, pc.getLibelleUs());
            }
            if (pc.getDateCreation() == null) {
                stmt.setNull(9, java.sql.Types.DATE);
            } else {
                stmt.setDate(9, new java.sql.Date(pc.getDateCreation().getTime()));
            }
            if (pc.getDateCessation() == null) {
                stmt.setNull(10, java.sql.Types.DATE);
            } else {
                stmt.setDate(10, new java.sql.Date(pc.getDateCessation().getTime()));
            }

            stmt.setBoolean(11, pc.getActif());
            if (pc.getCodeLocalite() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, pc.getCodeLocalite());
            }
            if (pc.getNaturePC() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, pc.getNaturePC());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(PosteComptable pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getPosteComptableID() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getPosteComptableID());
            }
            if (pc.getCode() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getCode());
            }
            if (pc.getAbbreviationFr() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getAbbreviationFr());
            }
            if (pc.getAbbreviationUs() == null) {
                stmt.setNull(6, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(6, pc.getAbbreviationUs());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(7, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(7, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(8, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(8, pc.getLibelleUs());
            }
            if (pc.getDateCreation() == null) {
                stmt.setNull(9, java.sql.Types.DATE);
            } else {
                stmt.setDate(9, new java.sql.Date(pc.getDateCreation().getTime()));
            }
            if (pc.getDateCessation() == null) {
                stmt.setNull(10, java.sql.Types.DATE);
            } else {
                stmt.setDate(10, new java.sql.Date(pc.getDateCessation().getTime()));
            }

            stmt.setBoolean(11, pc.getActif());
            if (pc.getCodeLocalite() == null) {
                stmt.setNull(12, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(12, pc.getCodeLocalite());
            }
            if (pc.getNaturePC() == null) {
                stmt.setNull(13, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(13, pc.getNaturePC());
            }

            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimer(String posteComptableID) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_Delete(?)");
            stmt.setString(1, posteComptableID);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public PosteComptable rechercherById(String posteComptableID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_SearchID(?)");
            stmt.setString(1, posteComptableID);
            
            PosteComptable o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> rechercherByCode(String codePC) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_SearchCode(?)");
            stmt.setString(1, codePC);
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> listePosteComptableActifs() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_List(?)");
            stmt.setBoolean(1, true);
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> listePosteComptableComplete() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_List(?)");
            stmt.setBoolean(1, false);
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> getPosteComptableOfLocalite(String localiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_Of_Localite(?)");
            stmt.setString(1, localiteID);
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> getPosteComptableByLocalite(String localiteID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_By_Localite(?)");
            stmt.setString(1, localiteID+"%");
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void ajouterPCNature(PosteComptableNature pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPCNature_Insert(?, ?, ?, ?, ?)");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getNaturePC() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getNaturePC());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getLibelleUs());
            }
           
            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifierPCNature(PosteComptableNature pc) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPCNature_Update(?, ?, ?, ?, ?)");
            if (pc.getUserUpdate() == null) {
                stmt.setNull(1, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(1, pc.getUserUpdate());
            }
            if (pc.getIpUpdate() == null) {
                stmt.setNull(2, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(2, pc.getIpUpdate());
            }
            if (pc.getNaturePC() == null) {
                stmt.setNull(3, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(3, pc.getNaturePC());
            }
            if (pc.getLibelleFr() == null) {
                stmt.setNull(4, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(4, pc.getLibelleFr());
            }
            if (pc.getLibelleUs() == null) {
                stmt.setNull(5, java.sql.Types.VARCHAR);
            } else {
                stmt.setString(5, pc.getLibelleUs());
            }
           
            stmt.executeQuery();

        } catch (Exception ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void supprimerPCNature(String naturePC) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPCNature_Delete(?)");
            stmt.setString(1, naturePC);
            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public PosteComptableNature rechercherPCNatureById(String naturePC) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPCNature_SearchID(?)");
            stmt.setString(1, naturePC);
            
            PosteComptableNature o = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                o = new PosteComptableNature();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                
            }
            return o;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptableNature> getPosteComptableNature() {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPCNature_List()");
            
            List<PosteComptableNature> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptableNature o = new PosteComptableNature();
                o = new PosteComptableNature();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                o.setPosteComptableCount(rs.getInt("posteComptableCount"));
                if (rs.wasNull()) {
                    o.setPosteComptableCount(0);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> getPosteComptableByNature(String naturePC) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_By_Nature(?)");
            stmt.setString(1, naturePC);
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<PosteComptable> getPosteComptableByLocaliteAndNature(String localiteID, String naturePC) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psPosteComptable_By_Localite_And_Nature(?, ?)");
            stmt.setString(1, localiteID+"%");
            stmt.setString(2, naturePC);
            
            List<PosteComptable> list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                PosteComptable o = new PosteComptable();
                o = new PosteComptable();
                o.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    o.setIpUpdate(null);
                }
                o.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    o.setLastUpdate(null);
                }
                o.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    o.setUserUpdate(null);
                }
                o.setPosteComptableID(rs.getString("posteComptableID"));
                if (rs.wasNull()) {
                    o.setPosteComptableID(null);
                }
                o.setCode(rs.getString("code"));
                if (rs.wasNull()) {
                    o.setCode(null);
                }
                o.setAbbreviationFr(rs.getString("abbreviationFr"));
                if (rs.wasNull()) {
                    o.setAbbreviationFr(null);
                }
                o.setAbbreviationUs(rs.getString("abbreviationUs"));
                if (rs.wasNull()) {
                    o.setAbbreviationUs(null);
                }
                o.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    o.setLibelleFr(null);
                }
                o.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    o.setLibelleUs(null);
                }
                o.setDateCreation(rs.getDate("dateCreation"));
                if (rs.wasNull()) {
                    o.setDateCreation(null);
                }
                o.setDateCessation(rs.getDate("dateCessation"));
                if (rs.wasNull()) {
                    o.setDateCessation(null);
                }
                o.setActif(rs.getBoolean("actif"));
                o.setCodeLocalite(rs.getString("codeLocalite"));
                if (rs.wasNull()) {
                    o.setCodeLocalite(null);
                }
                o.setNaturePC(rs.getString("naturePC"));
                if (rs.wasNull()) {
                    o.setNaturePC(null);
                }
                
                list.add(o);
            }
            return list;
        } catch (SQLException ex) {
            return Collections.EMPTY_LIST;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
}
