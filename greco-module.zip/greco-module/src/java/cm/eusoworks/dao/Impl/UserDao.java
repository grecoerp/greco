/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.dao.Impl;

import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.entities.model.Userpreferences;
import cm.eusoworks.entities.model.Users;
import cm.eusoworks.entities.view.VueTrack;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.UserGroupe;
import cm.eusoworks.entities.model.UserProfils;
import cm.eusoworks.entities.view.VueMachine;
import cm.eusoworks.entities.view.VueEntiteReduit;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.annotation.Resource;
import javax.sql.DataSource;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class UserDao implements IUserDao {

    @Resource(lookup = "jdbc/greco")
    private DataSource dataSource;

    @Override
    public Users rechercher(String login) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUser_SelectByLogin( ? )");
            stmt.setString(1, login);

            Users user = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                user = new Users();
                user.setActif(rs.getBoolean("actif"));
                if (rs.wasNull()) {
                    user.setActif(false);
                }
                user.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    user.setEmail(null);
                }
                user.setFonction(rs.getString("fonction"));
                if (rs.wasNull()) {
                    user.setFonction(null);
                }
                user.setImmatriculation(rs.getString("immatriculation"));
                if (rs.wasNull()) {
                    user.setImmatriculation(null);
                }
                user.setIpUpdate(rs.getString("ipUpdate"));
                if (rs.wasNull()) {
                    user.setIpUpdate(null);
                }
                user.setLastUpdate(rs.getDate("lastUpdate"));
                if (rs.wasNull()) {
                    user.setLastUpdate(null);
                }
                user.setLogin(rs.getString("login"));
                if (rs.wasNull()) {
                    user.setLogin(null);
                }
                user.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    user.setNom(null);
                }
                user.setPassword(rs.getString("password"));
                if (rs.wasNull()) {
                    user.setPassword(null);
                }
                user.setPrenom(rs.getString("prenom"));
                if (rs.wasNull()) {
                    user.setPrenom("");
                }
                user.setUserUpdate(rs.getString("userUpdate"));
                if (rs.wasNull()) {
                    user.setUserUpdate("");
                }
                user.setService(rs.getString("service"));
                if (rs.wasNull()) {
                    user.setService("");
                }

                user.setStructure(rs.getString("structure"));
                if (rs.wasNull()) {
                    user.setStructure("");
                }

                user.setStructureID(rs.getString("structureID"));
                if (rs.wasNull()) {
                    user.setStructureID("");
                }

                user.setFacebook(rs.getString("facebook"));
                if (rs.wasNull()) {
                    user.setFacebook("");
                }
                user.setWhatsapp(rs.getString("whatsapp"));
                if (rs.wasNull()) {
                    user.setWhatsapp("");
                }
                user.setTwitter(rs.getString("twitter"));
                if (rs.wasNull()) {
                    user.setTwitter("");
                }
                user.setLinkedln(rs.getString("linkedln"));
                if (rs.wasNull()) {
                    user.setLinkedln("");
                }
                user.setGoogleplus(rs.getString("googleplus"));
                if (rs.wasNull()) {
                    user.setGoogleplus("");
                }
                user.setTelephone(rs.getString("telephone"));
                if (rs.wasNull()) {
                    user.setTelephone("");
                }

            }
            return user;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
//            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public boolean authentifier(String login, String password) {
        boolean res = false;
        Users user = null;
        try {
            user = rechercher(login);
        } catch (GrecoException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        }
        if (user != null) {
            if (user.getPassword().equals(password)) {
                res = true;
            }
        }
        return res;
    }

    @Override
    public List<Systeme> getSystemeListByUser(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psSysteme_SelectByLogin(?)");
            stmt.setString(1, login);

            List<Systeme> sysUsers = new ArrayList();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Systeme sys = new Systeme();
                sys.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    sys.setIpUpdate(null);
                }
                sys.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    sys.setLastUpdate(null);
                }
                sys.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    sys.setUserUpdate(null);
                }
                sys.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    sys.setLibelleFr(null);
                }
                sys.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    sys.setLibelleUs(null);
                }
                sys.setSystemeID(rs.getString("systemeID"));
                if (rs.wasNull()) {
                    sys.setSystemeID(null);
                }
                sys.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    sys.setNumOrdre(0);
                }
                sysUsers.add(sys);
            }
            return sysUsers;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Userpreferences getUserPreferences(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUser_Preferences(?)");
            stmt.setString(1, login);

            Userpreferences pref = null;
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                pref = new Userpreferences();
                pref.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    pref.setIpUpdate(null);
                }
                pref.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    pref.setLastUpdate(null);
                }
                pref.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    pref.setUserUpdate(null);
                }
                pref.setLangue(rs.getString("langue"));
                if (rs.wasNull()) {
                    pref.setLangue(null);
                }
                pref.setSound(rs.getBoolean("sound"));
                if (rs.wasNull()) {
                    pref.setSound(false);
                }
                pref.setSoundFail(rs.getBoolean("soundFail"));
                if (rs.wasNull()) {
                    pref.setSoundFail(false);
                }
                pref.setSoundSuccess(rs.getBoolean("soundSuccess"));
                if (rs.wasNull()) {
                    pref.setSoundSuccess(false);
                }
                pref.setAnimation(rs.getBoolean("animation"));
                if (rs.wasNull()) {
                    pref.setAnimation(false);
                }
                pref.setLogin(rs.getString("login"));
                if (rs.wasNull()) {
                    pref.setAnimation(false);
                }
                pref.setBackground(rs.getString("background"));
                if (rs.wasNull()) {
                    pref.setBackground("");
                }
            }
            return pref;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Modules> getModuleListByUser(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psModules_SelectByLogin(?)");
            stmt.setString(1, login);

            List<Modules> modUsers = new ArrayList();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Modules m = new Modules();
                m.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    m.setIpUpdate(null);
                }
                m.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    m.setLastUpdate(null);
                }
                m.setUserUpdate(rs.getString("user_update"));
                if (rs.wasNull()) {
                    m.setUserUpdate(null);
                }
                m.setLibelleFr(rs.getString("libelleFr"));
                if (rs.wasNull()) {
                    m.setLibelleFr(null);
                }
                m.setLibelleUs(rs.getString("libelleUs"));
                if (rs.wasNull()) {
                    m.setLibelleUs(null);
                }
                m.setModuleID(rs.getString("moduleID"));
                if (rs.wasNull()) {
                    m.setModuleID(null);
                }
                m.setSystemeID(rs.getString("systemeID"));
                if (rs.wasNull()) {
                    m.setSystemeID(null);
                }
                m.setNumOrdre(rs.getInt("numOrdre"));
                if (rs.wasNull()) {
                    m.setNumOrdre(0);
                }
                m.setIcon(rs.getString("icon"));
                if (rs.wasNull()) {
                    m.setIcon(null);
                }
                m.setIconRoll(rs.getString("iconRoll"));
                if (rs.wasNull()) {
                    m.setIconRoll(null);
                }
                modUsers.add(m);
            }
            return modUsers;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void savePreferences(String locale, boolean sound, boolean soundFail, boolean soundSuccess, boolean soundWait, String ipAdress, String userUpdate, String imageFond) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUserPreference_Save(?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, locale);
            stmt.setBoolean(2, sound);
            stmt.setBoolean(3, soundFail);
            stmt.setBoolean(4, soundSuccess);
            stmt.setBoolean(5, soundWait);
            stmt.setString(6, ipAdress);
            stmt.setString(7, userUpdate);
            stmt.setString(8, imageFond);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void updatePassword(String login, String newPassword) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUser_UpdatePassword(?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, newPassword);

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void deleteUser(String login) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsers_Delete(?)");
            stmt.setString(1, login);

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<Users> getListUsersByOrganisation(String organisationID) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsers_SelectByOrganisation(?)");
            stmt.setString(1, organisationID);

            List<Users> listUser = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Users user = new Users();
                user.setActif(rs.getBoolean("actif"));
                if (rs.wasNull()) {
                    user.setActif(false);
                }
                user.setEmail(rs.getString("email"));
                if (rs.wasNull()) {
                    user.setEmail(null);
                }
                user.setFonction(rs.getString("fonction"));
                if (rs.wasNull()) {
                    user.setFonction(null);
                }
                user.setImmatriculation(rs.getString("immatriculation"));
                if (rs.wasNull()) {
                    user.setImmatriculation(null);
                }
                user.setIpUpdate(rs.getString("ip_update"));
                if (rs.wasNull()) {
                    user.setIpUpdate(null);
                }
                user.setLastUpdate(rs.getDate("last_update"));
                if (rs.wasNull()) {
                    user.setLastUpdate(null);
                }
                user.setLogin(rs.getString("login"));
                if (rs.wasNull()) {
                    user.setLogin(null);
                }
                user.setNom(rs.getString("nom"));
                if (rs.wasNull()) {
                    user.setNom(null);
                }
                user.setPassword(rs.getString("password"));
                if (rs.wasNull()) {
                    user.setPassword(null);
                }
                user.setPrenom(rs.getString("prenom"));
                if (rs.wasNull()) {
                    user.setPrenom("");
                }
                user.setUserUpdate(rs.getString("userUpdate"));
                if (rs.wasNull()) {
                    user.setUserUpdate("");
                }
                user.setService(rs.getString("service"));
                if (rs.wasNull()) {
                    user.setService("");
                }
                try {
                    user.setDateCreation(rs.getDate("dateCreation"));
                } catch (Exception e) {
                    Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, e);
                }

                user.setOrganisationID(rs.getString("organisationID"));
                user.setStructure(rs.getString("structure"));
                if (rs.wasNull()) {
                    user.setStructure("");
                }
                user.setStructureID(rs.getString("structureID"));
                if (rs.wasNull()) {
                    user.setStructureID("");
                }
                user.setFacebook(rs.getString("facebook"));
                if (rs.wasNull()) {
                    user.setFacebook("");
                }
                user.setWhatsapp(rs.getString("whatsapp"));
                if (rs.wasNull()) {
                    user.setWhatsapp("");
                }
                user.setTwitter(rs.getString("twitter"));
                if (rs.wasNull()) {
                    user.setTwitter("");
                }
                user.setLinkedln(rs.getString("linkedln"));
                if (rs.wasNull()) {
                    user.setLinkedln("");
                }
                user.setGoogleplus(rs.getString("googleplus"));
                if (rs.wasNull()) {
                    user.setGoogleplus("");
                }
                user.setTelephone(rs.getString("telephone"));
                if (rs.wasNull()) {
                    user.setTelephone("");
                }

                listUser.add(user);
            }
            return listUser;
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void enregistrer(String user_update, String ip_update, String login, String password, String nom, String prenom,
            String immatriculation, String fonction, String email, boolean actif, String service, String organisationID, String structureID,
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String telephone) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsers_Insert(?, ?, ?, ?, ?, ?, ?, ?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, user_update);
            stmt.setString(2, ip_update);
            stmt.setString(3, login);
            stmt.setString(4, password);
            stmt.setString(5, nom);
            stmt.setString(6, prenom);
            stmt.setString(7, immatriculation);
            stmt.setString(8, fonction);
            stmt.setString(9, email);
            stmt.setBoolean(10, actif);
            stmt.setString(11, service);
            stmt.setString(12, organisationID);
            stmt.setString(13, structureID);

            stmt.setString(14, facebook);
            stmt.setString(15, whatsapp);
            stmt.setString(16, twitter);
            stmt.setString(17, linkedln);
            stmt.setString(18, googleplus);
            stmt.setString(19, telephone);

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void modifier(String user_update, String ip_update, String login, String password, String nom, String prenom, String immatriculation, String fonction, String email, boolean actif, String service, String organisationID, String structureID,
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String telephone) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsers_Update(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, user_update);
            stmt.setString(2, ip_update);
            stmt.setString(3, login);
            stmt.setString(4, password);
            System.out.println(password);
            stmt.setString(5, nom);
            stmt.setString(6, prenom);
            stmt.setString(7, immatriculation);
            stmt.setString(8, fonction);
            stmt.setString(9, email);
            stmt.setBoolean(10, actif);
            stmt.setString(11, service);
            stmt.setString(12, organisationID);
            stmt.setString(13, structureID);

            stmt.setString(14, facebook);
            stmt.setString(15, whatsapp);
            stmt.setString(16, twitter);
            stmt.setString(17, linkedln);
            stmt.setString(18, googleplus);
            stmt.setString(19, telephone);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void saveConnection(String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUser_Connect(?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, user_update);
            stmt.setString(2, ip_update);
            stmt.setString(3, hostname);
            stmt.setString(4, mac);
            stmt.setString(5, motif);
            stmt.setString(6, login);
            stmt.setString(7, md5HostName);

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueTrack> getTracking(String login, Date dateDebut, Date dateFin) {
        Connection con = null;
        List<VueTrack> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psTrack_Users(?, ?, ?)");
            stmt.setString(1, login);
            stmt.setDate(2, new java.sql.Date(dateDebut.getTime()));
            stmt.setDate(3, new java.sql.Date(dateFin.getTime()));

            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueTrack v = new VueTrack();

                v.setlUJ2(rs.getDate("lUJ2"));
                v.setM2M(rs.getString("m2M"));
                v.setmAT7(rs.getString("mAT7"));
                v.setnM(rs.getString("nM"));
                v.setpM(rs.getString("pM"));
                v.setR36(rs.getString("r36"));
                v.settR78(rs.getString("tR78"));
                v.setyU9(rs.getString("yU9"));
                v.setzZ33(rs.getString("zZ33"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueTrack> getTrackingMachine(String machineName, Date dateDebut, Date dateFin) {
        Connection con = null;
        List<VueTrack> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psTrack_Machines(?, ?, ?)");
            stmt.setString(1, machineName);
            stmt.setDate(2, new java.sql.Date(dateDebut.getTime()));
            stmt.setDate(3, new java.sql.Date(dateFin.getTime()));

            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueTrack v = new VueTrack();

                v.setlUJ2(rs.getDate("lUJ2"));
                v.setM2M(rs.getString("m2M"));
                v.setmAT7(rs.getString("mAT7"));
                v.setnM(rs.getString("nM"));
                v.setpM(rs.getString("pM"));
                v.setR36(rs.getString("r36"));
                v.settR78(rs.getString("tR78"));
                v.setyU9(rs.getString("yU9"));
                v.setzZ33(rs.getString("zZ33"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            ex.printStackTrace();
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueMachine> getListMachine() {
        Connection con = null;
        List<VueMachine> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psTrack_Machine_List()");

            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueMachine v = new VueMachine();
                v.setR36(rs.getString("r36"));
                v.settR78(rs.getString("tR78"));
                v.setyU9(rs.getString("yU9"));
                v.setHost(rs.getString("dM5"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueTrack> getTrackingDossier(String dossier) {
        Connection con = null;
        List<VueTrack> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psTrack_Dossier(?)");
            stmt.setString(1, dossier);

            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueTrack v = new VueTrack();

                v.setlUJ2(rs.getDate("lUJ2"));
                v.setM2M(rs.getString("m2M"));
                v.setmAT7(rs.getString("mAT7"));
                v.setnM(rs.getString("nM"));
                v.setpM(rs.getString("pM"));
                v.setR36(rs.getString("r36"));
                v.settR78(rs.getString("tR78"));
                v.setyU9(rs.getString("yU9"));
                v.setzZ33(rs.getString("zZ33"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void profilInsert(String user_update, String ip_update, String profilID, String login, String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void profilUpdate(String user_update, String ip_update, String profilID, String login, String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void profilDeleteByLoginAndGroupe(String user_update, String ip_update, String login, String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void profilDeleteByLogin(String user_update, String ip_update, String login) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void profilDeleteByGroupe(String user_update, String ip_update, String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UserProfils profilGetByID(String profilID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserProfils> profilGetByLogin(String login) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserProfils> profilGetByLoginAndModule(String login, String moduleID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void groupeDeleteByGroup(String user_update, String ip_update, String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void groupeInsert(String user_update, String ip_update, String groupeID, String libelleFr, String description, String proprietaire, String profils) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void groupeUpdate(String user_update, String ip_update, String groupeID, String libelleFr, String description, String proprietaire, String profils) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public UserGroupe groupeGetByID(String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserGroupe> groupeGetByLogin(String login) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserGroupe> groupeGetByModule(String moduleID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserGroupe> groupeGetByLoginAndModule(String login, String moduleID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserGroupe> groupeGetSousGroupe(String groupeID) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<UserGroupe> groupeGetSousGroupeByProprietaire(String groupeID, String login) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void modifierReseauSociaux(String user_update, String ip_update, String login,
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String email, String telephone) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsers_UpdateSocial(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, user_update);
            stmt.setString(2, ip_update);
            stmt.setString(3, login);
            stmt.setString(4, facebook);
            stmt.setString(5, whatsapp);
            stmt.setString(6, twitter);
            stmt.setString(7, linkedln);
            stmt.setString(8, googleplus);
            stmt.setString(9, telephone);
            stmt.setString(10, email);

            stmt.executeQuery();
        } catch (SQLException ex) {
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void journalisation(String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName, 
            String os, String arhitecture, String function, String module, int categorie, String id) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psOrganisation_Trace(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            stmt.setString(1, user_update);
            stmt.setString(2, ip_update);
            stmt.setString(3, hostname);
            stmt.setString(4, mac);
            stmt.setString(5, motif);
            stmt.setString(6, login);
            stmt.setString(7, md5HostName);
            stmt.setString(8, os);
            stmt.setString(9, arhitecture);
            stmt.setString(10, function);
            stmt.setString(11, module);
            stmt.setInt(12, categorie);
            stmt.setString(13, id);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEntiteReduit> userOrganisationList(String loginHierarchie, String login) {
        Connection con = null;
        List<VueEntiteReduit> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersOrganisation_List(?, ?)");
            stmt.setString(1, loginHierarchie);
            stmt.setString(2, login);


            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueEntiteReduit v = new VueEntiteReduit();

                v.setCode(rs.getString("code"));
                v.setId(rs.getString("organisationID"));
                v.setLibelleFr(rs.getString("libelleFr"));
                v.setLibelleUs(rs.getString("libelleUs"));
                v.setOcag(rs.getString("ocag"));
                v.setChecked(rs.getBoolean("checked"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            return null;
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userOrganisationDelete(String login) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersOrganisation_Delete( ?)");
            stmt.setString(1, login);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userOrganisationSave(String login, VueEntiteReduit org) {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersOrganisation_Save(?, ?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, org.getId());
            stmt.setString(3, org.getOcag());

            stmt.executeQuery();
            
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    
    @Override
    public List<VueEntiteReduit> userStructureList(String loginHierarchie, String login) throws GrecoException {
        Connection con = null;
        List<VueEntiteReduit> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersStructure_List(?, ?)");
            stmt.setString(1, loginHierarchie);
            stmt.setString(2, login);


            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueEntiteReduit v = new VueEntiteReduit();

                v.setCode(rs.getString("code"));
                v.setId(rs.getString("structureID"));
                v.setLibelleFr(rs.getString("libelleFr"));
                v.setLibelleUs(rs.getString("libelleUs"));
                v.setChecked(rs.getBoolean("checked"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userStructureDelete(String login) throws GrecoException{
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersStructure_Delete( ?)");
            stmt.setString(1, login);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userStructureSave(String login, VueEntiteReduit org) throws GrecoException{
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersStructure_Save(?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, org.getId());

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
    
    @Override
    public List<VueEntiteReduit> userSourceFinancementList(String loginHierarchie, String login) throws GrecoException {
        Connection con = null;
        List<VueEntiteReduit> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersSourceFinancement_List(?, ?)");
            stmt.setString(1, loginHierarchie);
            stmt.setString(2, login);


            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueEntiteReduit v = new VueEntiteReduit();
                v.setId(rs.getString("financementID"));
                v.setLibelleFr(rs.getString("libelleFr"));
                v.setLibelleUs(rs.getString("libelleUs"));
                v.setChecked(rs.getBoolean("checked"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userSourceFinancementDelete(String login) throws GrecoException{
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersSourceFinancement_Delete( ?)");
            stmt.setString(1, login);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userSourceFinancementSave(String login, VueEntiteReduit org) throws GrecoException{
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersSourceFinancement_Save(?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, org.getId());

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEntiteReduit> userProgrammeList(String loginHierarchie, String login, String millesime) throws GrecoException {
        Connection con = null;
        List<VueEntiteReduit> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersActivite_List(?, ?, ?)");
            stmt.setString(1, loginHierarchie);
            stmt.setString(2, login);
            stmt.setString(3, millesime);


            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueEntiteReduit v = new VueEntiteReduit();

                v.setId(rs.getString("activiteID"));
                v.setLibelleFr(rs.getString("libelleFr"));
                v.setLibelleUs(rs.getString("libelleUs"));
                v.setChecked(rs.getBoolean("checked"));
                v.setIntValue(rs.getInt("niveauActiviteID"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public List<VueEntiteReduit> userProgrammeActionList(String loginHierarchie, String login, String activiteParentID, String millesime) throws GrecoException {
        Connection con = null;
        List<VueEntiteReduit> list = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersActivite_ListChilds(?, ?, ?, ?)");
            stmt.setString(1, loginHierarchie);
            stmt.setString(2, login);
            stmt.setString(3, activiteParentID);
            stmt.setString(4, millesime);


            list = new ArrayList<>();
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                VueEntiteReduit v = new VueEntiteReduit();

                v.setId(rs.getString("activiteID"));
                v.setLibelleFr(rs.getString("libelleFr"));
                v.setLibelleUs(rs.getString("libelleUs"));
                v.setChecked(rs.getBoolean("checked"));
                v.setIntValue(rs.getInt("niveauActiviteID"));
                list.add(v);
            }
            rs.close();
            return list;

        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userProgrammeDelete(String login, String millesime, int type) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersActivite_Delete( ?, ?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, millesime);
            stmt.setInt(3, type);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public void userProgrammeSave(String login, String activiteParentID, String millesime, int type, VueEntiteReduit activite) throws GrecoException {
        Connection con = null;
        try {
            con = dataSource.getConnection();
            CallableStatement stmt = con.prepareCall("CALL psUsersActivite_Save(?, ?, ?, ?, ?, ?)");
            stmt.setString(1, login);
            stmt.setString(2, activite.getId());
            stmt.setString(3, activiteParentID);
            stmt.setString(4, millesime);
            stmt.setInt(5, activite.getIntValue());
            stmt.setInt(6, type);

            stmt.executeQuery();
        } catch (SQLException ex) {
            Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            throw new GrecoException(ex);
        } finally {
            try {
                con.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDao.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

}
