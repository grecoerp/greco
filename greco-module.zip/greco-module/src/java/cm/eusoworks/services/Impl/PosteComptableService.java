/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IPosteComptableDao;
import cm.eusoworks.entities.model.PosteComptable;
import cm.eusoworks.entities.model.PosteComptableNature;
import cm.eusoworks.services.IPosteComptableService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class PosteComptableService implements IPosteComptableService{

    @EJB
    IPosteComptableDao posteComptableDao;
    
    
    @Override
    public void ajouter(PosteComptable pc) throws GrecoException {
        pc.setPosteComptableID("PC"+StringUtil.generatedID());
        posteComptableDao.ajouter(pc);
    }

    @Override
    public void modifier(PosteComptable pc) throws GrecoException {
        posteComptableDao.modifier(pc);
    }

    @Override
    public void supprimer(String posteComptableID) throws GrecoException {
        posteComptableDao.supprimer(posteComptableID);
    }

    @Override
    public PosteComptable rechercherById(String posteComptableID) {
        return posteComptableDao.rechercherById(posteComptableID);
    }

    @Override
    public List<PosteComptable> rechercherByCode(String codePC) {
        return posteComptableDao.rechercherByCode(codePC);
    }

    @Override
    public List<PosteComptable> listePosteComptableActifs() {
        return posteComptableDao.listePosteComptableActifs();
    }

    @Override
    public List<PosteComptable> listePosteComptableComplete() {
       return posteComptableDao.listePosteComptableComplete();
               
    }
    
    @Override
    public List<PosteComptable> getPosteComptableOfLocalite(String localiteID){
        return posteComptableDao.getPosteComptableOfLocalite(localiteID);
    }
    
    @Override
    public List<PosteComptable> getPosteComptableByLocalite(String localiteID){
        return posteComptableDao.getPosteComptableByLocalite(localiteID);
    }

    @Override
    public void ajouterPCNature(PosteComptableNature pc) throws GrecoException {
        posteComptableDao.ajouterPCNature(pc);
    }

    @Override
    public void modifierPCNature(PosteComptableNature pc) throws GrecoException {
        posteComptableDao.modifierPCNature(pc);
    }

    @Override
    public void supprimerPCNature(String naturePC) throws GrecoException {
        posteComptableDao.supprimerPCNature(naturePC);
    }

    @Override
    public PosteComptableNature rechercherPCNatureById(String naturePC) {
        return posteComptableDao.rechercherPCNatureById(naturePC);
    }

    @Override
    public List<PosteComptableNature> getPosteComptableNature() {
        return posteComptableDao.getPosteComptableNature();
    }

    @Override
    public List<PosteComptable> getPosteComptableByNature(String naturePC) {
        return posteComptableDao.getPosteComptableByNature(naturePC);
    }

    @Override
    public List<PosteComptable> getPosteComptableByLocaliteAndNature(String localiteID, String naturePC) {
        return posteComptableDao.getPosteComptableByLocaliteAndNature(localiteID, naturePC);
    }
    
}
