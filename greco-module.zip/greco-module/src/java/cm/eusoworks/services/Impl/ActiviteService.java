/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IActiviteDao;
import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.services.IActiviteService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaActivite;
import java.util.List;
import javax.ejb.EJB;

import utils.StringUtil;
/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ActiviteService implements IActiviteService {

    @EJB
    IActiviteDao activiteDao;
    
    @EJB
    IUserDao userDao;
    
    
    @Override
    public void ajouter(Activite act) throws GrecoException {
        act.setActiviteID("ATV"+StringUtil.generatedID());
        activiteDao.ajouter(act);
    }

    @Override
    public void modifier(Activite act) throws GrecoException {
        activiteDao.modifier(act);
    }

    @Override
    public void supprimer(String activiteID) throws GrecoException {
        activiteDao.supprimer(activiteID);
    }

    @Override
    public Activite getActivite(String activiteID) {
        return activiteDao.getActivite(activiteID);
    }

    @Override
    public List<Activite> getListActivite(String organisationID, String millesime) {
        return activiteDao.getListActivite(organisationID, millesime);
    }

    @Override
    public List<Activite> getListActiviteRoots(String organisationID, String millesime) {
        return activiteDao.getListActiviteRoots(organisationID, millesime);
    }

    @Override
    public List<Activite> getListActiviteChilds(String activiteID) {
        return activiteDao.getListActiviteChilds(activiteID);
    }

    @Override
    public List<Activite> getListActiviteChildsAndOperationCount(String activiteID){
        return activiteDao.getListActiviteChildsAndOperationCount(activiteID);
    }

    @Override
    public int copierOperation(String TacheSourceID, String tacheDestinationID, String structureDestinationID) {
        return activiteDao.copierOperation(TacheSourceID, tacheDestinationID, structureDestinationID);
    }

    @Override
    public List<Activite> getListActiviteNiveau(String organisationID, int niveauID, String millesime) {
        return activiteDao.getListActiviteNiveau(organisationID, niveauID, millesime);
    }

    @Override
    public List<Activite> getListTacheBudgetiseByStructure(String millesime, String organisationID, String structureID) {
        return activiteDao.getListTacheBudgetiseByStructure(millesime, organisationID, structureID);
    }
    
    
    // prepa activite
    @Override
    public void prepaAjouter(PrepaActivite act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        act.setActiviteID("PATV"+StringUtil.generatedID());
        activiteDao.prepaAjouter(act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getActiviteID());
    }

    @Override
    public void prepaModifier(PrepaActivite act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        activiteDao.prepaModifier(act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getActiviteID());
    }

    @Override
    public void prepaSupprimer(String activiteID, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        activiteDao.prepaSupprimer(activiteID);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, activiteID);
    }

    @Override
    public PrepaActivite prepaGetActivite(String activiteID) {
        return activiteDao.prepaGetActivite(activiteID);
    }

    @Override
    public List<PrepaActivite> prepaGetListActivite(String organisationID, String millesime) {
        return activiteDao.prepaGetListActivite(organisationID, millesime);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteRoots(String organisationID, String millesime) {
        return activiteDao.prepaGetListActiviteRoots(organisationID, millesime);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChilds(String activiteID) {
        return activiteDao.prepaGetListActiviteChilds(activiteID);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChildsAndOperationCount(String activiteID){
        return activiteDao.prepaGetListActiviteChildsAndOperationCount(activiteID);
    }

    @Override
    public int prepaCopierOperation(String TacheSourceID, String tacheDestinationID, String structureDestinationID) {
        return activiteDao.prepaCopierOperation(TacheSourceID, tacheDestinationID, structureDestinationID);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteNiveau(String organisationID, int niveauID, String millesime) {
        return activiteDao.prepaGetListActiviteNiveau(organisationID, niveauID, millesime);
    }

    @Override
    public List<PrepaActivite> prepaGetListTacheBudgetiseByStructure(String millesime, String organisationID, String structureID) {
        return activiteDao.prepaGetListTacheBudgetiseByStructure(millesime, organisationID, structureID);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteRootsByBudget(String organisationID, String millesime, String budgetID) {
        return activiteDao.prepaGetListActiviteRootsByBudget(organisationID, millesime, budgetID);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChildsByBudget(String activiteID, String budgetID) {
       return activiteDao.prepaGetListActiviteChildsByBudget(activiteID, budgetID);
    }

    @Override
    public List<PrepaActivite> prepaGetListActiviteChildsAndOperationCountByBudget(String activiteID, String budgetID) {
       return activiteDao.prepaGetListActiviteChildsAndOperationCountByBudget(activiteID, budgetID);
    }
}
