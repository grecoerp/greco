/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IUniteOrganiqueDao;
import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.services.IUniteOrganiqueService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.NiveauOrganique;
import java.util.List;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class UniteOrganiqueService implements IUniteOrganiqueService {

    @javax.ejb.EJB
    IUniteOrganiqueDao uniteOrganiqueDao;
    
    @Override
    public int ajouter(UniteOrganique org, int codeErreur) throws GrecoException {
        org.setUniteOrganiqueID("UO"+StringUtil.generatedID());
        return uniteOrganiqueDao.ajouter(org, codeErreur);
    }

    @Override
    public int modifier(UniteOrganique org, int codeErreur) throws GrecoException {
        return uniteOrganiqueDao.modifier(org, codeErreur);
    }

    @Override
    public void supprimer(String uniteOrganiqueID) throws GrecoException {
        uniteOrganiqueDao.supprimer(uniteOrganiqueID);
    }

    @Override
    public UniteOrganique rechercherById(String uniteOrganiqueID) {
        return uniteOrganiqueDao.rechercherById(uniteOrganiqueID);
    }

    @Override
    public UniteOrganique rechercherByOrder(int numOrdre) {
        return uniteOrganiqueDao.rechercherByOrder(numOrdre);
    }

    @Override
    public List<UniteOrganique> listeUniteOrganique(String organisationID) {
        return uniteOrganiqueDao.listeUniteOrganique(organisationID);
    }

    @Override
    public List<UniteOrganique> listeUniteOrganiqueFilles(String uniteOrganiqueID) {
        return uniteOrganiqueDao.listeUniteOrganiqueFilles(uniteOrganiqueID);
    }

    @Override
    public List<UniteOrganique> getUniteOrganiqueForStructure(String structureID) {
        return uniteOrganiqueDao.getUniteOrganiqueForStructure(structureID);
    }

    @Override
    public List<UniteOrganique> getUniteOrganiqueFillesForStructure(String structureID) {
        return uniteOrganiqueDao.getUniteOrganiqueFillesForStructure(structureID);
    }

    @Override
    public int ajouterNiveau(NiveauOrganique org, int codeErreur) throws GrecoException {
        return uniteOrganiqueDao.ajouterNiveau(org, codeErreur);
    }

    @Override
    public int modifierNiveau(NiveauOrganique org, int codeErreur) throws GrecoException {
        return uniteOrganiqueDao.modifierNiveau(org, codeErreur);
    }

    @Override
    public void supprimerNiveau(int niveauOrganiqueID) throws GrecoException {
        uniteOrganiqueDao.supprimerNiveau(niveauOrganiqueID);
    }

    @Override
    public NiveauOrganique rechercherNiveauById(String niveauOrganiqueID) {
        return uniteOrganiqueDao.rechercherNiveauById(niveauOrganiqueID);
    }

    @Override
    public List<NiveauOrganique> listeNiveauOrganique(String organisationID) {
        return uniteOrganiqueDao.listeNiveauOrganique(organisationID);
    }

    @Override
    public List<UniteOrganique> listeUniteOrganiqueByNiveau(String organisationID, int niveauOrganiqueID) {
        return uniteOrganiqueDao.listeUniteOrganiqueByNiveau(organisationID, niveauOrganiqueID);
    }
    
}
