/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.INomenclatureDao;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.services.INomenclatureService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class NomenclatureService implements INomenclatureService {

    @EJB
    INomenclatureDao nomenclatureDao;
    
    @Override
    public void ajouterCategorie(Categorie act) throws GrecoException {
        nomenclatureDao.ajouterCategorie(act);
    }

    @Override
    public void modifierCategorie(Categorie act) throws GrecoException {
        nomenclatureDao.modifierCategorie(act);
    }

    @Override
    public void supprimerCategorie(String codeCategorie) throws GrecoException {
        nomenclatureDao.supprimerCategorie(codeCategorie);
    }

    @Override
    public Categorie getCategorie(String codeCategorie) {
        return nomenclatureDao.getCategorie(codeCategorie);
    }

    @Override
    public List<Categorie> getListCategorieAll() {
        return nomenclatureDao.getListCategorieAll();
                
    }

    @Override
    public List<Categorie> getListCategorieByNiveau(int niveauID) {
        return nomenclatureDao.getListCategorieByNiveau(niveauID);
    }

    @Override
    public List<Categorie> getListCategorieRacines() {
        return nomenclatureDao.getListCategorieRacines();
    }

    @Override
    public List<Categorie> getListCategorieChilds(String codeCategorie) {
        return nomenclatureDao.getListCategorieChilds(codeCategorie);
    }

    @Override
    public void ajouterFonction(Fonction act) throws GrecoException {
        nomenclatureDao.ajouterFonction(act);
    }

    @Override
    public void modifierFonction(Fonction act) throws GrecoException {
        nomenclatureDao.modifierFonction(act);
    }

    @Override
    public void supprimerFonction(String codeFonction) throws GrecoException {
        nomenclatureDao.supprimerFonction(codeFonction);
    }

    @Override
    public Fonction getFonction(String codeFonction) {
        return nomenclatureDao.getFonction(codeFonction);
    }

    @Override
    public List<Fonction> getListFonctionAll() {
        return nomenclatureDao.getListFonctionAll();
    }

    @Override
    public List<Fonction> getListFonctionByNiveau(int niveauID) {
        return nomenclatureDao.getListFonctionByNiveau(niveauID);
    }

    @Override
    public List<Fonction> getListFonctionRacines() {
        return nomenclatureDao.getListFonctionRacines();
    }

    @Override
    public List<Fonction> getListFonctionChilds(String codeFonction) {
        return nomenclatureDao.getListFonctionChilds(codeFonction);
    }

    @Override
    public void ajouterLocalite(Localite act) throws GrecoException {
        nomenclatureDao.ajouterLocalite(act);
    }

    @Override
    public void modifierLocalite(Localite act) throws GrecoException {
        nomenclatureDao.modifierLocalite(act);
    }

    @Override
    public void supprimerLocalite(String codeLocalite) throws GrecoException {
        nomenclatureDao.supprimerLocalite(codeLocalite);
    }

    @Override
    public Localite getLocalite(String codeLocalite) {
        return nomenclatureDao.getLocalite(codeLocalite);
    }

    @Override
    public List<Localite> getListLocaliteAll() {
        return nomenclatureDao.getListLocaliteAll();
    }

    @Override
    public List<Localite> getListLocaliteByNiveau(int niveauID) {
        return nomenclatureDao.getListLocaliteByNiveau(niveauID);
    }

    @Override
    public List<Localite> getListLocaliteRacines() {
        return nomenclatureDao.getListLocaliteRacines();
    }

    @Override
    public List<Localite> getListLocaliteChilds(String codeLocalite) {
        return nomenclatureDao.getListLocaliteChilds(codeLocalite);
    }

    @Override
    public void ajouterCompte(Compte act, boolean creerIfNotExists) throws GrecoException {
        nomenclatureDao.ajouterCompte(act, creerIfNotExists);
    }

    @Override
    public void modifierCompte(Compte act) throws GrecoException {
        nomenclatureDao.modifierCompte(act);
    }

    @Override
    public void supprimerCompte(String codeCompte) throws GrecoException {
        nomenclatureDao.supprimerCompte(codeCompte);
    }

    @Override
    public Compte getCompte(String codeCompte) {
        return nomenclatureDao.getCompte(codeCompte);
    }

    @Override
    public List<Compte> getListCompteAll() {
        return nomenclatureDao.getListCompteAll();
    }

    @Override
    public List<Compte> getListCompteByNiveau(int niveauID) {
        return nomenclatureDao.getListCompteByNiveau(niveauID);
    }

    @Override
    public List<Compte> getListCompteRacines() {
        return nomenclatureDao.getListCompteRacines();
    }

    @Override
    public List<Compte> getListCompteChilds(String codeCompte) {
        return nomenclatureDao.getListCompteChilds(codeCompte);
    }
    
    @Override
    public List<Compte> getListCompteUtilisables() {
        return nomenclatureDao.getListCompteUtilisables();
    }

}
