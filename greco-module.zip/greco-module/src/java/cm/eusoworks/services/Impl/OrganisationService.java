/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IOrganisationDao;
import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.services.IOrganisationService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.DatabaseOptions;
import cm.eusoworks.entities.model.Notes;
import cm.eusoworks.entities.model.OrgOptions;
import java.util.Date;
import java.util.List;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class OrganisationService implements IOrganisationService {

    @javax.ejb.EJB
    IOrganisationDao organisationDao;
    
    @javax.ejb.EJB
    private IUserDao userDao;

    @Override
    public int ajouter(Organisation org, int codeErreur) throws GrecoException {
        org.setOrganisationID("ORG"+StringUtil.generatedID());
        return organisationDao.ajouter(org, codeErreur);
    }

    @Override
    public int modifier(Organisation org, int codeErreur) throws GrecoException {
        return organisationDao.modifier(org, codeErreur);
    }

    @Override
    public void supprimer(String organisationID) throws GrecoException {
        organisationDao.supprimer(organisationID);
    }

    @Override
    public Organisation rechercherById(String organisationID) {
        return organisationDao.rechercherById(organisationID);
    }

    @Override
    public List<Organisation> rechercherByCode(String code) {
        return organisationDao.rechercherByCode(code);
    }

    @Override
    public List<Organisation> listeOrganisationActives() {
        return organisationDao.listeOrganisation(true);
    }

    @Override
    public List<Organisation> listeOrganisationComplete() {
        return organisationDao.listeOrganisation(false);
    }

    @Override
    public void ajouterStructure(Structure org) throws GrecoException {
        org.setStructureID("STR"+StringUtil.generatedID());
        organisationDao.ajouterStructure(org);
    }

    @Override
    public void modifierStructure(Structure org) throws GrecoException {
        organisationDao.modifierStructure(org);
    }

    @Override
    public void supprimerStructure(String structureID) throws GrecoException {
        organisationDao.supprimerStructure(structureID);
    }

    @Override
    public List<Structure> listeStructuresOrganisation(String organisationID) {
        return organisationDao.listeStructuresOrganisation(organisationID);
    }
    
    @Override
    public List<Structure> listeStructuresUserByOrganisation(String organisationID, String login) {
        return organisationDao.listeStructuresUserByOrganisation(organisationID, login);
    }
    
    public void saveParametres(String organisationID, String zoneEco, String paysFr, String paysUs, String deviseFr, String deviseUs, String orgSigleFr, 
            String orgSigleUs, String orgLibelleFr, String orgLibelleUs, String orgContact, String appAbreviationFr, String appAbreviationUs, String appTitleFr, String appTitleUs, String user, String adresseIP, String machine, String motif,
                String tutelleFr, String tutelleUs) {
        organisationDao.saveParametres(organisationID, zoneEco, paysFr, paysUs, deviseFr, deviseUs, orgSigleFr, orgSigleUs, orgLibelleFr, orgLibelleUs, orgContact, appAbreviationFr, appAbreviationUs, appTitleFr, appTitleUs,
                                        user, adresseIP, machine, motif, tutelleFr, tutelleUs);
        
    }

    @Override
    public void saveParametres(OrgOptions op) {
        organisationDao.saveParametres(op);
    }

    @Override
    public OrgOptions getOptionOrganisation(String organisationID) {
        return organisationDao.getOptionOrganisation(organisationID);
    }

    @Override
    public List<Structure> listeStructuresFilles(String organisationID, String structureID) {
        return organisationDao.listeStructuresFilles(organisationID, structureID);
    }

    @Override
    public List<Structure> listeStructuresByUniteOrganique(String organisationID, String uniteOrganiqueID) {
        return organisationDao.listeStructuresByUniteOrganique(organisationID, uniteOrganiqueID);
    }

    @Override
    public int structureMaxOrdre(String caCode, String loCode) {
        return organisationDao.structureMaxOrdre(caCode, loCode);
    }

    @Override
    public void noteModification(String user_update, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins) {
        organisationDao.noteModification(user_update, ip_update, noteID, objet, contenu, dateAffichage, statut, organisationIDs, moduleIDs, userLogins);
    }

    @Override
    public void noteAjout(String userupdate, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins) {
        String ntID = "NT"+StringUtil.generatedID();
        organisationDao.noteAjout(userupdate, ip_update, ntID, objet, contenu, dateAffichage, statut, organisationIDs, moduleIDs, userLogins);
    }

    @Override
    public List<Notes> noteRechercher(String organisationID, String noteID, String moduleID, String userLogins, Date dateAffichageDebut, Date dateAffichageFin, String userupdate, Integer statut) {
        return organisationDao.noteRechercher(organisationID, noteID, moduleID, userLogins, dateAffichageDebut, dateAffichageFin, userupdate, statut);
    }

    @Override
    public void noteSuppression(String noteID) {
        organisationDao.noteSuppression(noteID);
    }

    @Override
    public void saveBackupDBParameters(String organisationID, String adresseIP, String port, String username, String password, String database, String dumpPath, 
                                        String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        try {
            organisationDao.saveBackupDBParameters(user_update, ip_update, organisationID, adresseIP, port, username, password, database, dumpPath);
            userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, organisationID);
        } catch (Exception e) {
            throw new GrecoException(e);
        }
    }

    @Override
    public DatabaseOptions databaseGetParameters(String organisationID) {
        return organisationDao.databaseGetParameters(organisationID);
    }


    @Override
    public List<Organisation> listeOrganisationUserActives(String login) {
        return organisationDao.listeOrganisationUsersByRole(login, null);
    }

    @Override
    public List<Organisation> listeOrganisationUserOrdonnateurs(String login) {
        return organisationDao.listeOrganisationUsersByRole(login, "1");
    }

    @Override
    public List<Organisation> listeOrganisationUserControleur(String login) {
        return organisationDao.listeOrganisationUsersByRole(login, "2");
    }

    @Override
    public List<Organisation> listeOrganisationUserComptable(String login) {
        return organisationDao.listeOrganisationUsersByRole(login, "3");
    }

    @Override
    public List<Organisation> listeOrganisationUserGestion(String login) {
        return organisationDao.listeOrganisationUsersByRole(login, "4");
    }

}
