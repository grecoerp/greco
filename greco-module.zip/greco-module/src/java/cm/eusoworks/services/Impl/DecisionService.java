/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IDecisionDao;
import cm.eusoworks.entities.model.Decision;
import cm.eusoworks.entities.model.DecisionModele;
import cm.eusoworks.services.IDecisionService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class DecisionService implements IDecisionService {

    @EJB
    IDecisionDao decisionDao;

    @Override
    public String ajouterModele(DecisionModele d) throws GrecoException {
        d.setModeleID("DM"+StringUtil.generatedID());
        decisionDao.ajouterModele(d);
        return d.getModeleID();
    }

    @Override
    public void modifierModele(DecisionModele d) throws GrecoException {
        decisionDao.modifierModele(d);
    }

    @Override
    public void supprimerModele(String modeleID, String user, String ipAdresse) throws GrecoException {
        decisionDao.supprimerModele(modeleID, user, ipAdresse);
    }

    @Override
    public DecisionModele getModele(String modeleID) {
        return decisionDao.getModele(modeleID);
    }

    @Override
    public List<DecisionModele> getModeleByOrganisation(String millesime, String organisationID) {
        return decisionDao.getModeleByOrganisation(millesime, organisationID);
    }

    @Override
    public String ajouterDecision(Decision d) throws GrecoException {
        d.setDecisionID("DC"+StringUtil.generatedID());
        decisionDao.ajouterDecision(d);
        return d.getDecisionID();
    }

    @Override
    public void modifierDecision(Decision d) throws GrecoException {
        decisionDao.modifierDecision(d);
    }

    @Override
    public void supprimerDecision(String decisionID, String user, String ipAdresse) throws GrecoException {
        decisionDao.supprimerDecision(decisionID, user, ipAdresse);
    }

    @Override
    public Decision getDecision(String decisionID) {
        return decisionDao.getDecision(decisionID);
    }

    @Override
    public List<Decision> getDecisionByOrganisation(String millesime, String organisationID) {
        return decisionDao.getDecisionByOrganisation(millesime, organisationID);
    }

    @Override
    public List<Decision> getDecisionByOrganisationAndDate(String millesime, String organisationID, Date date) {
        return decisionDao.getDecisionByOrganisationAndDate(millesime, organisationID, date);
    }

    @Override
    public List<Date> getDateDecisionByOrganisation(String millesime, String organisationID) {
       return decisionDao.getDateDecisionByOrganisation(millesime, organisationID);
    }

    @Override
    public void dupliquerModele(String modeleID, String name) {
        decisionDao.dupliquerModele(modeleID, name, "DM"+StringUtil.generatedID());
    }
    
    @Override
    public void reservationDecision(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        decisionDao.reservationDecision(bcaID, reserve, motif, login, adresseIP);
    }

    @Override
    public void reservationDecisionAnnuler(String decisionID, boolean annuler, String motif, String login, String adresseIP) throws GrecoException {
        decisionDao.reservationDecisionAnnuler(decisionID, annuler, motif, login, adresseIP);
    }
    
}
