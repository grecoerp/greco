/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IPrepaMarcheDao;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.PrepaMarche;
import cm.eusoworks.entities.model.PrepaMarcheContractant;
import cm.eusoworks.entities.model.PrepaMarcheFinancement;
import cm.eusoworks.entities.model.PrepaMarcheGestion;
import cm.eusoworks.entities.model.PrepaMarcheMO;
import cm.eusoworks.entities.model.PrepaMarchePhasage;
import cm.eusoworks.entities.model.PrepaMarchePrestation;
import cm.eusoworks.entities.model.PrepaMarcheTypeAO;
import cm.eusoworks.entities.view.VuePrepaMarche;
import cm.eusoworks.entities.view.VuePrepaMarcheArticle;
import cm.eusoworks.entities.view.VuePrepaMarcheJournal;
import cm.eusoworks.services.IPrepaMarcheService;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class PrepaMarcheService implements IPrepaMarcheService {

    @EJB
    IPrepaMarcheDao prepaMarcheDao;
    
    //<editor-fold defaultstate="collapsed" desc="Marche">
    @Override
    public int deleteMarche(String paId) {
        return prepaMarcheDao.deleteMarche(paId);
    }

    @Override
    public PrepaMarche saveMarche(PrepaMarche marche, PrepaMarcheGestion gestion, PrepaMarchePhasage phasage) {

        if (marche == null) {
            System.out.print("MARCHE IS NULL");
            return null;
        }

        if (StringUtil.isNullOrEmpty(marche.getPaId())) {
            System.out.print("MARCHE ID IS NULL");
            return null;
        }
        String paId = marche.getPaId();
        String naturePrestationId = marche.getNaturePrestationId();
        String contractantId = marche.getContractantId();
        String typeAOId = marche.getTypeAOId();
        String financementId = marche.getFinancementId();
        Integer numOrdre = marche.getNumOrdre();
        String maitreOuvrage = marche.getMaitreOuvrage();
        Boolean annualite = marche.getAnnualite();
        String motifGreAGre = marche.getMotifGreAGre();
        Date dateDebut = marche.getDateDebut();
        Date dateFin = marche.getDateFin();
        Date dateLancement = marche.getDateLancement();
        Date dateAttribution = marche.getDateAttribution();
        Date dateSignature = marche.getDateSignature();
        Date dateDemarrage = marche.getDateDemarrage();
        Date dateReception = marche.getDateReception();
        Date dateLancementCP = marche.getDateLancementCP();
        Date dateAttributionCP = marche.getDateAttributionCP();
        Date dateSignatureCP = marche.getDateSignatureCP();
        Date dateDemarrageCP = marche.getDateDemarrageCP();
        Date dateReceptionCP = marche.getDateReceptionCP();
        String userMaj = marche.getUserMaj();
        Date dateMaj = marche.getDateMaj();
        System.out.print("GESTION ID:" + gestion.getPaId());
        Boolean uniteExistante = gestion.getUniteExistante();
        String intitule = gestion.getIntitule();
        String nom = gestion.getNom();
        String posteOccupe = gestion.getPosteOccupe();
        String adresse = gestion.getAdresse();
        String email = gestion.getEmail();
        String telephone = gestion.getTelephone();
        System.out.print("PHASAGE ID:" + phasage.getPaId());
        Integer annee1 = phasage.getAnnee1();
        String intitule1 = phasage.getIntitule1();
        BigDecimal cout1 = phasage.getCout1();
        Integer annee2 = phasage.getAnnee2();
        String intitule2 = phasage.getIntitule2();
        BigDecimal cout2 = phasage.getCout2();
        Integer annee3 = phasage.getAnnee3();
        String intitule3 = phasage.getIntitule3();
        BigDecimal cout3 = phasage.getCout3();
        Integer annee4 = phasage.getAnnee4();
        String intitule4 = phasage.getIntitule4();
        BigDecimal cout4 = phasage.getCout4();
        Integer annee5 = phasage.getAnnee5();
        String intitule5 = phasage.getIntitule5();
        BigDecimal cout5 = phasage.getCout5();
        System.out.print("BEFORE SAVE");
        prepaMarcheDao.saveMarche(paId, naturePrestationId, contractantId, typeAOId, financementId, numOrdre, maitreOuvrage, annualite, motifGreAGre, dateDebut, dateFin, dateLancement, dateAttribution, dateSignature, dateDemarrage, dateReception, dateLancementCP, dateAttributionCP, dateSignatureCP, dateDemarrageCP, dateReceptionCP, annee1, intitule1, cout1, annee2, intitule2, cout2, annee3, intitule3, cout3, annee4, intitule4, cout4, annee5, intitule5, cout5, uniteExistante, intitule, nom, posteOccupe, adresse, email, telephone, userMaj, dateMaj);
        System.out.print("AFTER SAVE");
        return marche;
    }

    @Override
    public int deleteMarcheContractant(String contractantId) {
        return prepaMarcheDao.deleteMarcheContractant(contractantId);
    }

    @Override
    public PrepaMarcheContractant saveMarcheContractant(PrepaMarcheContractant contractant) {

        if (contractant == null) {
            return null;
        }
        String contractantId = StringUtil.isNullOrEmpty(contractant.getContractantId()) ? StringUtil.generatedID() : contractant.getContractantId();
        String libelleFr = contractant.getLibelleFr();
        String libelleUs = contractant.getLibelleUs();
        String userMaj = contractant.getUserMaj();
        Date dateMaj = contractant.getDateMaj();

        prepaMarcheDao.saveMarcheContractant(contractantId, libelleFr, libelleUs, userMaj, dateMaj);
        return contractant;
    }

    @Override
    public int deleteMarcheFinancement(String financementId) {
        return prepaMarcheDao.deleteMarcheFinancement(financementId);
    }

    @Override
    public PrepaMarcheFinancement saveMarcheFinancement(PrepaMarcheFinancement financement) {

        if (financement == null) {
            return null;
        }
        String financementId = StringUtil.isNullOrEmpty(financement.getFinancementId()) ? StringUtil.generatedID() : financement.getFinancementId();
        String abbreviation = financement.getAbbreviation();
        String libelleFr = financement.getLibelleFr();
        String libelleUs = financement.getLibelleUs();
        String userMaj = financement.getUserMaj();
        Date dateMaj = financement.getDateMaj();
        prepaMarcheDao.saveMarcheFinancement(financementId, abbreviation, libelleFr, libelleUs, userMaj, dateMaj);
        return financement;
    }

    @Override
    public int deleteMarchePrestation(String naturePrestationId) {
        return prepaMarcheDao.deleteMarchePrestation(naturePrestationId);
    }

    @Override
    public PrepaMarchePrestation saveMarchePrestation(PrepaMarchePrestation prestation) {

        if (prestation == null) {
            return null;
        }
        String naturePrestationId = StringUtil.isNullOrEmpty(prestation.getNaturePrestationId()) ? StringUtil.generatedID() : prestation.getNaturePrestationId();
        String code = prestation.getCode();
        String abbreviation = prestation.getAbbreviation();
        String libelleFr = prestation.getLibelleFr();
        String libelleUs = prestation.getLibelleUs();
        String userMaj = prestation.getUserMaj();
        Date dateMaj = prestation.getDateMaj();

        prepaMarcheDao.saveMarchePrestation(naturePrestationId, code, abbreviation, libelleFr, libelleUs, userMaj, dateMaj);
        return prestation;
    }

    @Override
    public int deleteMarcheTypeAO(String typeAOId) {
        return prepaMarcheDao.deleteMarcheTypeAO(typeAOId);
    }

    @Override
    public PrepaMarcheTypeAO saveMarcheTypeAO(PrepaMarcheTypeAO typeAO) {

        if (typeAO == null) {
            return null;
        }
        String typeAOId = StringUtil.isNullOrEmpty(typeAO.getTypeAOId()) ? StringUtil.generatedID() : typeAO.getTypeAOId();
        String code = typeAO.getCode();
        String libelle = typeAO.getLibelle();
        String userMaj = typeAO.getUserMaj();
        Date dateMaj = typeAO.getDateMaj();

        prepaMarcheDao.saveMarcheTypeAO(typeAOId, code, libelle, userMaj, dateMaj);
        return typeAO;
    }

    @Override
    public PrepaMarche getMarche(String paId) {
        try {
            return prepaMarcheDao.getMarches(null, null, paId, null, null, null, null).get(0);
        } catch (Exception e) {
            System.err.print(e);
            return null;
        }
    }

    @Override
    public List<PrepaMarche> getMarches(String exMillesime) {
        return prepaMarcheDao.getMarches(exMillesime, null, null, null, null, null, null);
    }

    @Override
    public List<PrepaMarche> getMarches(String exMillesime, String chCode) {
        return prepaMarcheDao.getMarches(exMillesime, chCode, null, null, null, null, null);
    }

    @Override
    public List<PrepaMarche> getMarches(String exMillesime, String chCode, String paId, String naturePrestationId, String contractantId, String typeAOId, String financementId) {
        return prepaMarcheDao.getMarches(exMillesime, chCode, paId, naturePrestationId, contractantId, typeAOId, financementId);
    }

    @Override
    public PrepaMarcheContractant getMarcheContractant(String contractantId) {
        return prepaMarcheDao.getMarcheContractants(contractantId).get(0);
    }

    @Override
    public List<PrepaMarcheContractant> getMarcheContractants() {
        return prepaMarcheDao.getMarcheContractants(null);
    }

    @Override
    public PrepaMarcheFinancement getMarcheFinancement(String financementId) {
        try {
            return prepaMarcheDao.getMarcheFinancements(financementId).get(0);
        } catch (Exception e) {
            System.err.print(e);
            return null;
        }
    }

    @Override
    public List<PrepaMarcheFinancement> getMarcheFinancements() {
        return prepaMarcheDao.getMarcheFinancements(null);
    }

    @Override
    public PrepaMarchePrestation getMarchePrestations(String naturePrestationId) {
        try {
            return prepaMarcheDao.getMarchePrestations(naturePrestationId).get(0);
        } catch (Exception e) {
            System.err.print(e);
            return null;
        }
    }

    @Override
    public List<PrepaMarchePrestation> getMarchePrestations() {
        return prepaMarcheDao.getMarchePrestations(null);
    }

    @Override
    public PrepaMarcheTypeAO getMarcheTypeAO(String typeAOId) {
        try {
            return prepaMarcheDao.getMarcheTypeAOs(typeAOId).get(0);
        } catch (Exception e) {
            System.err.print(e);
            return null;
        }
    }

    @Override
    public List<PrepaMarcheTypeAO> getMarcheTypeAOs() {
        return prepaMarcheDao.getMarcheTypeAOs(null);
    }

    @Override
    public List<OperationBudgetaire> getParagrapheParChapitreEtNature(String exMillesime, String chCode, String neLike) {
        return prepaMarcheDao.getParagrapheParChapitreEtNature(exMillesime, chCode, neLike);
    }

    @Override
    public List<VuePrepaMarche> getMarcheByPaId(String paId) {
        return prepaMarcheDao.getMarcheByPaId(paId);
    }

    @Override
    public List<VuePrepaMarcheJournal> getMarcheJournal(String exMillesime, String chCode, String maitreOuvrage) {
        return prepaMarcheDao.getMarcheJournal(exMillesime, chCode, maitreOuvrage);
    }

    @Override
    public List<VuePrepaMarcheJournal> getMarcheListeMO(String exMillesime, String chCode) {
        return prepaMarcheDao.getMarcheListeMO(exMillesime, chCode);
    }

    @Override
    public List<VuePrepaMarche> getListeMarcheByExerciceChapitre(String exMillesime, String chCode) {
        return prepaMarcheDao.getListeMarcheByExerciceChapitre(exMillesime, chCode);
    }

    @Override
    public List<VuePrepaMarcheJournal> getListeMarcheAttribueByChapitre(String exMillesime, String chCode) {
        return prepaMarcheDao.getListeMarcheAttribueByChapitre(exMillesime, chCode);
    }

    @Override
    public List<VuePrepaMarcheJournal> getListeMarcheAttribueByRegionAndChapitre(String exMillesime, String chCode, String prProvinceID) {
        return prepaMarcheDao.getListeMarcheAttribueByRegionAndChapitre(exMillesime, chCode, prProvinceID);
    }
    @Override
    public List<VuePrepaMarcheJournal> getMarcheAbbreviationUnique(String abbreviationSF,String abbreviationPr,String abbreviationAO) {
        return prepaMarcheDao.getMarcheAbbreviationUnique( abbreviationSF, abbreviationPr, abbreviationAO);
    }
    //</editor-fold>

    @Override
    public List<VuePrepaMarche> getListeMarcheRecovery(String exMillesime, String chCode) {
        return prepaMarcheDao.getListeMarcheRecovery(exMillesime, chCode);
    }

    @Override
    public List<VuePrepaMarcheArticle> getListeMarcheArticle(String arCode, String user) {
        return prepaMarcheDao.getListeMarcheArticle(arCode, user);
    }

    @Override
    public int deleteMarcheMO(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public int saveMarcheMO(PrepaMarcheMO pmmo) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public PrepaMarcheMO getMarcheMO(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<PrepaMarcheMO> getMarcheMOParExercice(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<PrepaMarcheMO> getMarcheMOChapitres(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<PrepaMarcheMO> getMarcheMOStructures(String string) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    
}
