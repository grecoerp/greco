/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IAgentDao;
import cm.eusoworks.entities.cls.CleValeur;
import cm.eusoworks.entities.model.Agent;
import cm.eusoworks.services.IAgentService;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class AgentService implements IAgentService {

    @EJB
    IAgentDao agentDao;

    @Override
    public Agent getAgent(String agMatricule) {
        return agentDao.getAgent(agMatricule);
    }

    @Override
    public List<Agent> getAgents(String prefix) {
        return agentDao.getAgents(prefix);
    }

    @Override
    public String ajouterAgentBudgetaire( Agent agentBudgetaire) {
        return agentDao.ajouterAgentBudgetaire(agentBudgetaire);
    }

    @Override
    public void modifierAgentBudgetaire(Agent agentBudgetaire) {
        agentDao.modifierAgentBudgetaire(agentBudgetaire);
    }

    @Override
    public List<CleValeur> importAgent(List<Agent> list) {
        return agentDao.importAgent(list);
    }

    @Override
    public void importAgent(String exMillesime, String matricule, String nom, String prenom, String nomJeuneFille, Date dateNaiss, String cni, String utLogin, String ipAdresse, boolean actif) {
        agentDao.importAgent(exMillesime, matricule, nom, prenom, nomJeuneFille, dateNaiss, cni, utLogin, ipAdresse, actif);
    }

    @Override
    public void validerImportation() {
        agentDao.validerImportation();
    }

    @Override
    public void supprimerAgentBudgetaire(String agMatricule, String userMaj, String ipAdresse) {
        agentDao.supprimerAgentBudgetaire(agMatricule, userMaj, ipAdresse);
    }

    @Override
    public List<Agent> getAgentBudgetaire(String exMillesime, String organisationID) {
        return agentDao.getAgentBudgetaire(exMillesime, organisationID);
    }
    
    
    
    
    
}
