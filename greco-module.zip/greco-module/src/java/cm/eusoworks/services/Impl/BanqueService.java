/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IBanqueDao;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Agence;
import cm.eusoworks.entities.model.Banque;
import cm.eusoworks.entities.view.VueFournisseurRIB;
import cm.eusoworks.services.IBanqueService;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class BanqueService implements IBanqueService {

    @EJB
    IBanqueDao banqueDao;

    @Override
    public void banqueAjout(Banque b) throws GrecoException {
        banqueDao.banqueAjout(b);
    }

    @Override
    public void banqueModifier(Banque b) throws GrecoException {
        banqueDao.banqueModifier(b);
    }

    @Override
    public void banqueSupprimer(String codeBanque, boolean withAgences) throws GrecoException {
        banqueDao.banqueSupprimer(codeBanque, withAgences);
    }

    @Override
    public Banque banqueRechercher(String codeBanque) {
        return banqueDao.banqueRechercher(codeBanque);
    }

    @Override
    public List<Banque> banqueListe() {
        return banqueDao.banqueListe();
    }

    @Override
    public void agenceAjout(Agence a) throws GrecoException {
        banqueDao.agenceAjout(a);
    }

    @Override
    public void agenceModifier(Agence a) throws GrecoException {
        banqueDao.agenceModifier(a);
    }

    @Override
    public void agenceSupprimer(String codeBanque, String codeAgence) throws GrecoException {
        banqueDao.agenceSupprimer(codeBanque, codeAgence);
    }

    @Override
    public Agence agenceRechercher(String codeAgence, String codeBanque) {
        return banqueDao.agenceRechercher(codeAgence, codeBanque);
    }

    @Override
    public List<Agence> agenceListe(String codeBanque) {
        return banqueDao.agenceListe(codeBanque);
    }

    @Override
    public List<VueFournisseurRIB> ribByFournisseur(String fournisseurID) {
        return banqueDao.ribByFournisseur(fournisseurID);
    }

    @Override
    public void ribSupprimer(String user, String adresseIP, String rib)  throws GrecoException{
        banqueDao.ribSupprimer(user, adresseIP, rib);
    }

    @Override
    public void ribAjout(String user_update, String ip_update, String fournisseurBanqueID, String fournisseurID, String codeBanque, String rib) throws GrecoException {
        banqueDao.ribAjout(user_update, ip_update, fournisseurBanqueID, fournisseurID, codeBanque, rib);
    }
     
}
