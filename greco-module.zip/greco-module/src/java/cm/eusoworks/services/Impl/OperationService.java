/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IOperationDao;
import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.services.IOperationService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.view.VueOpDisponiblePipe;
import java.math.BigDecimal;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class OperationService implements IOperationService {

    @EJB
    IOperationDao operationDao;
    
    @EJB
    IUserDao userDao;

    @Override
    public void prepaAjouter(PrepaOperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        act.setTacheID("OPR"+StringUtil.generatedID());
        operationDao.prepaAjouter(act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getTacheID());
    }

    @Override
    public void prepaModifier(PrepaOperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        operationDao.prepaModifier(act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getTacheID());
    }

    @Override
    public void prepaSupprimer(String tacheID, String user, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        operationDao.prepaSupprimer(tacheID, user);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, tacheID);
    }

    @Override
    public PrepaOperationBudgetaire prepaGetOperation(String tacheID) {
        return operationDao.prepaGetOperation(tacheID);
    }

    @Override
    public List<PrepaOperationBudgetaire> prepaGetListOperationByActivite(String activiteID, String budgetID) {
        return operationDao.prepaGetListOperationByActivite(activiteID, budgetID);
    }

    
    @Override
    public void ajouter(OperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        act.setTacheID("OPR"+StringUtil.generatedID());
        operationDao.ajouter(act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getTacheID());
    }

    @Override
    public void modifier(OperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        operationDao.modifier(act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getTacheID());
    }

    @Override
    public void supprimer(String tacheID, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        operationDao.supprimer(tacheID);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, tacheID);
    }

    @Override
    public OperationBudgetaire getOperation(String tacheID) {
        return operationDao.getOperation(tacheID);
    }

    @Override
    public List<OperationBudgetaire> getListOperationByActivite(String activiteID) {
        return operationDao.getListOperationByActivite(activiteID);
    }

    @Override
    public BigDecimal getDisponible(OperationBudgetaire op) {
        return operationDao.getDisponible(op);
    }

    @Override
    public int prepaCopierSelectOperation(List<PrepaOperationBudgetaire> listeOperation, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) {
        int nbOperation = 0;
        for (PrepaOperationBudgetaire pob : listeOperation) {
            try {
                prepaAjouter(pob, user_update, ip_update, hostname, mac, motif, md5HostName, os, arhitecture, function, module);
                nbOperation++;
            } catch (Exception e) {
            }
        }
        
        return nbOperation;
    }

    @Override
    public VueOpDisponiblePipe getDisponiblePipe(String tacheID) {
        return operationDao.getDisponiblePipe(tacheID);
    }

    @Override
    public List<OperationBudgetaire> getListOperationByActiviteAndStructure(String activiteID, String structureID) {
        return operationDao.getListOperationByActiviteAndStructure(activiteID, structureID);
    }

    @Override
    public List<OperationBudgetaire> getListOperationByActiviteExecution(String activiteID, String budgetID) {
        return operationDao.getListOperationByActiviteExecution(activiteID, budgetID);
    }

    @Override
    public List<PrepaOperationBudgetaire> prepaGetListOperationByActiviteWithCollectif(String activiteID, String budgetID, String budgetCollectifID) {
        return operationDao.prepaGetListOperationByActiviteWithCollectif(activiteID, budgetID, budgetCollectifID);
    }

    @Override
    public void prepaCollectifInsert(String budgetID, String budgetCollectifID, PrepaOperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        operationDao.prepaCollectifInsert(budgetID, budgetCollectifID, act);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 2, act.getTacheID());
    }

    @Override
    public int prepaCollectifEnExecution(String budgetInitialID, String budgetCollectifID, String user_update) {
        return operationDao.prepaCollectifEnExecution(budgetInitialID, budgetCollectifID, user_update);
    }
 
   
}
