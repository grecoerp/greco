/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IComptaDao;
import cm.eusoworks.dao.IDroitsDao;
import cm.eusoworks.dao.IEngagementDao;
import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.cls.CleValeur;
import cm.eusoworks.entities.model.Bordereau;
import cm.eusoworks.entities.model.Engagement;
import cm.eusoworks.entities.model.EngagementType;
import cm.eusoworks.entities.view.VueEngagementDossier;
import cm.eusoworks.entities.view.VueEngagementJournal;
import cm.eusoworks.entities.view.VueEngagementLivre;
import cm.eusoworks.entities.view.VueEngagementStat;
import cm.eusoworks.entities.view.VueEngagementState;
import cm.eusoworks.services.IEngagementService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Ecritures;
import cm.eusoworks.entities.model.Liasse;
import cm.eusoworks.entities.model.Liquidation;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.entities.model.Mandatement;
import cm.eusoworks.entities.model.MandatementDroits;
import cm.eusoworks.entities.model.Paiement;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueControle;
import cm.eusoworks.entities.view.VueLeveeDetails;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class EngagementService implements IEngagementService {

    @EJB
    IEngagementDao engagementDao;
    @EJB
    IUserDao userDao;
    @EJB
    IDroitsDao droitsDao;
    @EJB
    IComptaDao comptaDao;

    @Override
    public EngagementType getEngagementType(String typeID) {
        return engagementDao.getEngagementType(typeID);
    }

    @Override
    public List<EngagementType> getEngagementType() {
        return engagementDao.getEngagementType();
    }

    @Override
    public String ajouter(Engagement e) throws GrecoException {
        e.setEngagementID("EJ" + StringUtil.generatedID());
        return engagementDao.ajouter(e);
    }

    @Override
    public void modifier(Engagement act) throws GrecoException {
        engagementDao.modifier(act);
    }

    @Override
    public void supprimer(String engagementID, String user, String ipAdresse) throws GrecoException {
        engagementDao.supprimer(engagementID, user, ipAdresse);
    }

    @Override
    public Engagement getEngagement(String engagementID) {
        return engagementDao.getEngagement(engagementID);
    }

    @Override
    public List<Engagement> getEngagementByOrganisation(String millesime, String organisationID, String listeEtat) {
        return engagementDao.getEngagementByOrganisation(millesime, organisationID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByFournisseur(String millesime, String organisationID, String fournisseurID, String listeEtat) {
        return engagementDao.getEngagementByFournisseur(millesime, organisationID, fournisseurID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByOrdonnateur(String millesime, String organisationID, String matriculeOrdo, String listeEtat) {
        return engagementDao.getEngagementByOrdonnateur(millesime, organisationID, matriculeOrdo, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByAgent(String millesime, String organisationID, String matriculeAgent, String listeEtat) {
        return engagementDao.getEngagementByAgent(millesime, organisationID, matriculeAgent, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByTache(String millesime, String organisationID, String tacheID, String listeEtat) {
        return engagementDao.getEngagementByTache(millesime, organisationID, tacheID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByStructure(String millesime, String organisationID, String structureID, String listeEtat) {
        return engagementDao.getEngagementByStructure(millesime, organisationID, structureID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByType(String millesime, String organisationID, String typeID, String listeEtat) {
        return engagementDao.getEngagementByType(millesime, organisationID, typeID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByBCA(String millesime, String organisationID, String bcaID, String listeEtat) {
        return engagementDao.getEngagementByBCA(millesime, organisationID, bcaID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByDecision(String millesime, String organisationID, String decisionID, String listeEtat) {
        return engagementDao.getEngagementByDecision(millesime, organisationID, decisionID, listeEtat);
    }

    @Override
    public List<Engagement> getEngagementByOM(String millesime, String organisationID, String omID, String listeEtat) {
        return engagementDao.getEngagementByOM(millesime, organisationID, omID, listeEtat);
    }

    @Override
    public VueEngagementStat getEngagementStat(String exMillesime) {
        return engagementDao.getEngagementStat(exMillesime);
    }

    @Override
    public List<VueEngagementDossier> getDossiers(String organisationID, String millesime, String numdossier, String etat,
            String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin,
            Date dateValidDebut, Date dateValidFin, String beneficiare) {
        return engagementDao.getDossiers(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut,
                dateEnregFin, dateValidDebut, dateValidFin, beneficiare);
    }

    @Override
    public List<VueEngagementDossier> getDossiersResteALiquider(String organisationID, String millesime, String numdossier, String etat,
            String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin,
            Date dateValidDebut, Date dateValidFin, String beneficiare) {
        return engagementDao.getDossiersResteALiquider(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut,
                dateEnregFin, dateValidDebut, dateValidFin, beneficiare);
    }

    @Override
    public Engagement getEngagementByDossier(String dossier) {
        return engagementDao.getEngagementByDossier(dossier);
    }

    @Override
    public List<VueEngagementJournal> getJournal(String engagementID) {
        return engagementDao.getJournal(engagementID);
    }

    @Override
    public void reservation(String engagementID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        engagementDao.reservation(engagementID, reserve, motif, login, adresseIP);
    }

    @Override
    public void annulerReservation(String engagementID, boolean annule, String motif, String login, String adresseIP) throws GrecoException {
        engagementDao.annulerReservation(engagementID, annule, motif, login, adresseIP);
    }

    @Override
    public List<VueEngagementLivre> getLivreJournal(String organisationID, String millesime, String numdossier, String etat, String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin, Date dateValidDebut, Date dateValidFin, String beneficiare) {
        return engagementDao.getLivreJournal(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut, dateEnregFin, dateValidDebut, dateValidFin, beneficiare);
    }

    @Override
    public String transmissionDossier(String organisationID, String millesime, int type, String source, String destination, String agent, List<VueEngagementDossier> dossiers, String userUpdate, int etatDossier) {
        String numBordereau = null;
        try {
            numBordereau = engagementDao.genererBordereau(organisationID, millesime, type, source, destination, agent, userUpdate);
            if (numBordereau != null) {
                for (VueEngagementDossier d : dossiers) {
                    try {
                        engagementDao.transmissionEngagement(organisationID, millesime, numBordereau, d, etatDossier, userUpdate);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
        }
        return numBordereau;
    }

    @Override
    public VueEngagementLivre getFicheDossier(String numDossier) {
        return engagementDao.getFicheDossier(numDossier);
    }

    @Override
    public List<Bordereau> getBordereauTransmission(String organisationID, String millesime, String numBordereau, String numdossier, Date dateEnregDebut, Date dateEnregFin, int typeTransmission) {
        return engagementDao.getBordereauTransmission(organisationID, millesime, numBordereau, numdossier, dateEnregDebut, dateEnregFin, typeTransmission);
    }

    @Override
    public List<VueEngagementDossier> getDossiersByNumBordereau(String numBordereau) {
        return engagementDao.getDossiersByNumBordereau(numBordereau);
    }

    @Override
    public List<Bordereau> getBordereauTransmissionEnCours(String organisationID, String millesime, int typeTransmission) {
        return engagementDao.getBordereauTransmissionEnCours(organisationID, millesime, typeTransmission);
    }

    @Override
    public List<VueEngagementDossier> getDossiersAtTypeTransmission(String organisationID, String millesime, String numBordereau, String numdossier, Date dateEnregDebut, Date dateEnregFin, int typeTransmission) {
        return engagementDao.getDossiersAtTypeTransmission(organisationID, millesime, numBordereau, numdossier, dateEnregDebut, dateEnregFin, typeTransmission);
    }

    @Override
    public String transmissionAnnulationDossier(String organisationID, String millesime, int type, String source, String destination, String agent, List<VueEngagementDossier> dossiers, String userUpdate, int etatDossier) {
        String numBordereau = null;
        try {
            numBordereau = engagementDao.genererBordereau(organisationID, millesime, type, source, destination, agent, userUpdate);
            if (numBordereau != null) {
                for (VueEngagementDossier d : dossiers) {
                    try {
                        engagementDao.transmissionAnnulationEngagement(organisationID, millesime, numBordereau, d, etatDossier, userUpdate);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } catch (Exception e) {
        }
        return numBordereau;
    }

    @Override
    public String valider(String engagementID, boolean valider, String motif, String user) {
        return engagementDao.valider(engagementID, valider, motif, user);
    }

    @Override
    public String validerRegularite(String engagementID, boolean valider, String motif, String user) {
        return engagementDao.validerRegularite(engagementID, valider, motif, user);
    }

    @Override
    public void valider_annuler(String engagementID, String motif, String user) {
        engagementDao.valider_annuler(engagementID, motif, user);
    }

    @Override
    public VueEngagementState getEtatengagement(String numDossier) {
        return engagementDao.getEtatengagement(numDossier);
    }

    @Override
    public String liquidationEnregistrement(String userUpdate, String ipAdresse, String machine, String liquidationID, String engagementID, String objet, BigDecimal montantTVA,
            BigDecimal montantIR, BigDecimal montantNAP, BigDecimal montantRG, String beneficiaire, String pieces, String livrables, List<LiquidationDroits> list) throws GrecoException {
        if (liquidationID == null) {
            liquidationID = "LIQ" + StringUtil.generatedID();
        }
        engagementDao.liquidationEnregistrement(userUpdate, ipAdresse, machine, liquidationID, engagementID, objet, montantTVA, montantIR, montantNAP, montantRG, beneficiaire, pieces, livrables);
        //enregistrer les rubriques qui ont ete liquidees 
        for (LiquidationDroits liq : list) {
            liq.setLiquidationID(liquidationID);
        }
        droitsDao.ajouterLiquidationDroit(list);
        return liquidationID;
    }

    @Override
    public void liquidationModifier(String userUpdate, String ipAdresse, String machine, String liquidationID, String engagementID, String objet,
            BigDecimal montantTVA, BigDecimal montantIR, BigDecimal montantNAP, BigDecimal montantRG, String beneficiaire, String pieces, String livrables, List<LiquidationDroits> list) throws GrecoException {
        engagementDao.liquidationModifier(userUpdate, ipAdresse, machine, liquidationID, engagementID, objet, montantTVA, montantIR, montantNAP, montantRG, beneficiaire, pieces, livrables);
        try {
            droitsDao.supprimerLiquidationDroit(liquidationID);
            droitsDao.ajouterLiquidationDroit(list);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    @Override
    public void liquidationSupprimer(String userUpdate, String ipAdresse, String machine, String liquidationID) throws GrecoException {
        engagementDao.liquidationSupprimer(userUpdate, ipAdresse, machine, liquidationID);
    }

    @Override
    public void liquidationValider(String userUpdate, String ipAdresse, String machine, String liquidationID, String observations, boolean isValidation, String engagementID) throws GrecoException {
        engagementDao.liquidationValider(userUpdate, ipAdresse, machine, liquidationID, observations, isValidation, engagementID);
    }

    @Override
    public Liquidation liquidationFind(String liquidationID) {
        return engagementDao.liquidationFind(liquidationID);
    }

    @Override
    public List<Liquidation> liquidationByEngagement(String engagementID) {
        return engagementDao.liquidationByEngagement(engagementID);
    }

    @Override
    public List<Liquidation> liquidationByEtat(String engagementID, int etat) {
        return engagementDao.liquidationByEtat(engagementID, etat);
    }

    @Override
    public List<Liquidation> liquidationByEtatOnly(String organisationID, String millesime, String numdossier, String etat) {
        return engagementDao.liquidationByEtatOnly(organisationID, millesime, numdossier, etat);
    }

    @Override
    public void liquidationValiderAnnuler(String userUpdate, String ipAdresse, String machine, String liquidationID, String observations, String engagementID) throws GrecoException {
        engagementDao.liquidationValiderAnnuler(userUpdate, ipAdresse, machine, liquidationID, observations, engagementID);
    }

    @Override
    public void MandatementEnregistrement(String userUpdate, String ipAdresse, String machine, String mandatementID, String liquidationID, String ordonnateur,
            BigDecimal montantMandate, String rib, String numeroOP, String objet, List<String> listPiecesID, List<MandatementDroits> droits) throws GrecoException {
        if (mandatementID == null) {
            mandatementID = "MDT" + StringUtil.generatedID();
        }
        // ajout du mandatement
        engagementDao.MandatementEnregistrement(userUpdate, ipAdresse, machine, mandatementID, liquidationID, ordonnateur, montantMandate, rib, numeroOP, objet);
        // ajout de la liasse
        try {
            engagementDao.MandatementLiasseAjouter(mandatementID, listPiecesID, userUpdate, ipAdresse);
        } catch (Exception e) {
            System.out.println("MandatementEnregistrement 320");
            e.printStackTrace();
        }

        // ajout des pieces
        for (MandatementDroits d : droits) {
            d.setMandatementID(mandatementID);
        }
        droitsDao.ajouterMandatementDroit(droits);

    }

    @Override
    public void MandatementModifier(String userUpdate, String ipAdresse, String machine, String mandatementID, String ordonnateur,
            String rib, String numeroOP, String objet, List<String> listPiecesID, List<MandatementDroits> droits) throws GrecoException {
        engagementDao.MandatementModifier(userUpdate, ipAdresse, machine, mandatementID, ordonnateur, rib, numeroOP, objet);
        // suppression de la liasse et ajout
        engagementDao.MandatementLiasseSupprimer(mandatementID);
        engagementDao.MandatementLiasseAjouter(mandatementID, listPiecesID, userUpdate, ipAdresse);
        // suppression des droits et ajout 
        droitsDao.supprimerMandatementDroit(mandatementID);
        droitsDao.ajouterMandatementDroit(droits);
    }

    @Override
    public void MandatementSupprimer(String userUpdate, String ipAdresse, String machine, String mandatementID) throws GrecoException {
        engagementDao.MandatementSupprimer(userUpdate, ipAdresse, machine, mandatementID);
    }

    @Override
    public Mandatement MandatementFind(String mandatementID) {
        return engagementDao.MandatementFind(mandatementID);
    }

    @Override
    public List<Mandatement> MandatementFindByLiquidation(String liquidationID) {
        return engagementDao.MandatementFindByLiquidation(liquidationID);
    }

    @Override
    public List<Mandatement> MandatementEnCours() {
        return engagementDao.MandatementEnCours();
    }

    @Override
    public List<Mandatement> MandatementByEtat(String organisationID, String millesime, String numdossier, String etat) {
        return engagementDao.MandatementByEtat(organisationID, millesime, numdossier, etat);
    }

    @Override
    public void MandatementValider(String userUpdate, String ipAdresse, String machine, String mandatementID, String pieces) throws GrecoException {
        engagementDao.MandatementValider(userUpdate, ipAdresse, machine, mandatementID, pieces);
    }

    @Override
    public void MandatementValiderAnnuler(String userUpdate, String ipAdresse, String machine, String mandatementID, String motif) throws GrecoException {
        engagementDao.MandatementValiderAnnuler(userUpdate, ipAdresse, machine, mandatementID, motif);
    }

    @Override
    public void demandeLevee(String id, int type, List<VueControle> list, String userDemande, String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName, String os, String arhitecture, String function, String module, int categorie) {
        try {
            engagementDao.deleteDemandeLevee(id, type);
            for (VueControle v : list) {
                engagementDao.demandeLevee(id, type, v, userDemande);
                userDao.journalisation(user_update, ip_update, hostname, mac, Crypto.encrypt("Demande levée pour :" + v.getLibelle() + "car " + v.getObservations()), login, md5HostName, os, arhitecture, function, module, 3, id);
            }
        } catch (Exception e) {
        }

    }

    @Override
    public void leveeDemande(String id, int type, int numeroControle, String userLevee, String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName, String os, String arhitecture, String function, String module, int categorie) {
        engagementDao.leveeDemande(id, type, numeroControle, userLevee);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, login, md5HostName, os, arhitecture, function, module, 3, id);
    }

    @Override
    public void ajouterLiasse(Liasse l) throws GrecoException {
        if (l.getLiasseID() == null) {
            l.setLiasseID("LIA" + StringUtil.generatedID());
        }
        engagementDao.ajouterLiasse(l);
    }

    @Override
    public void modifierLiasse(Liasse pc) throws GrecoException {
        engagementDao.modifierLiasse(pc);
    }

    @Override
    public void supprimerLiasse(String liasseID) throws GrecoException {
        engagementDao.supprimerLiasse(liasseID);
    }

    @Override
    public List<Liasse> getLiasse() {
        return engagementDao.getLiasse();
    }

    @Override
    public List<Liasse> getLiasse(String mandatementID) {
        return engagementDao.getLiasse(mandatementID);
    }

    @Override
    public List<Liasse> getLiasseByEngagement(String engagementID) {
        return engagementDao.getLiasseByEngagement(engagementID);
    }

    @Override
    public List<VueEngagementDossier> getMandatements(String organisationID, String millesime, String numdossier, String etat, String engagementType, String cpte, Date dateEnregDebut, Date dateEnregFin, Date dateValidDebut, Date dateValidFin, String beneficiare) {
        return engagementDao.getMandatements(organisationID, millesime, numdossier, etat, engagementType, cpte, dateEnregDebut, dateEnregFin, dateValidDebut, dateValidFin, beneficiare);

    }

    @Override
    public String ajouterPipe(Engagement e) throws GrecoException {
        e.setEngagementID("FL" + StringUtil.generatedID());
        return engagementDao.ajouterPipe(e);
    }

    @Override
    public void modifierPipe(Engagement act) throws GrecoException {
        engagementDao.modifierPipe(act);
    }

    @Override
    public void supprimerPipe(String engagementPipeID, String user, String ipAdresse) throws GrecoException {
        engagementDao.supprimerPipe(engagementPipeID, user, ipAdresse);
    }

    @Override
    public List<VueEngagementDossier> getEngagementPipe(String millesime, String organisationID, String programmeID, String operationID, String typeID, String beneficiaire, int nbJours, boolean isPipe) {
        return engagementDao.getEngagementPipe(millesime, organisationID, programmeID, operationID, typeID, beneficiaire, nbJours, isPipe);
    }

    @Override
    public Engagement getEngagementPipe(String engagementPipeID) {
        return engagementDao.getEngagementPipe(engagementPipeID);
    }

    @Override
    public String validerRegulariteOP(String engagementID, boolean valider, String motif, String user, List<Mandatement> list) {
        String captcha = null;
        captcha = engagementDao.validerRegularite(engagementID, valider, motif, user);
        if (valider) {
            try {
                for (Mandatement mandatement : list) {
                    engagementDao.validerRegulariteOP(mandatement);
                }
            } catch (Exception e) {
                return null;
            }
        }

        return captcha;
    }

    @Override
    public int modifierPipeOP(List<VueEngagementDossier> listDossiers) throws GrecoException {
        int nb = 0;
        boolean result = false;
        for (VueEngagementDossier d : listDossiers) {
            try {
                result = engagementDao.modifierPipeOP(d);
            } catch (Exception e) {
                result = false;
            }
            if (result) {
                nb++;
            }
        }
        return nb;
    }

    @Override
    public void engagementTypeJournaux(String organisationID, String jrn1, String jrn2, String jrn3, String jrn4, String jrn5) {
        engagementDao.engagementTypeJournaux(organisationID, jrn1, jrn2, jrn3, jrn4, jrn5);
    }

    @Override
    public List<Mandatement> MandatementByEtatRubriques(String organisationID, String millesime, String numdossier, String etat) {
        return engagementDao.MandatementByEtatRubriques(organisationID, millesime, numdossier, etat);
    }
    
    @Override
    public List<Mandatement> MandatementByEtatRubriquesPaiement(String organisationID, String millesime, String numdossier, String etat) {
        return engagementDao.MandatementByEtatRubriquesPaiement(organisationID, millesime, numdossier, etat);
    }

    @Override
    public void validationComptable(List<String> mandatements, List<Ecritures> ecritures, boolean validerCreance, boolean ValiderPaiement) throws GrecoException {
        try {
            for (String opID : mandatements) {
                engagementDao.validationComptable(opID, validerCreance, ValiderPaiement);
            }
            int ordre = comptaDao.ecritureNumOrdreValidation();
            for (Ecritures e : ecritures) {
                e.setNumOrdreValidation(Long.valueOf(ordre));
                comptaDao.ecritureComptable(e);
            }
        } catch (Exception e) {
            throw new GrecoException(e);
        }

    }
    
    @Override
    public void validationComptablePaiement(List<Paiement> mandatements, List<Ecritures> ecritures, boolean ValiderPaiement) throws GrecoException {
        try {
            for (Paiement opID : mandatements) {
                opID.setPaiementID("RG"+StringUtil.generatedID());
                engagementDao.validationComptablePaiement(opID, ValiderPaiement);
            }
            int ordre = comptaDao.ecritureNumOrdreValidation();
            for (Ecritures e : ecritures) {
                e.setNumOrdreValidation(Long.valueOf(ordre));
                comptaDao.ecritureComptable(e);
            }
        } catch (Exception e) {
            throw new GrecoException(e);
        }

    }

    @Override
    public void validationComptableAnnuler(List<String> mandatements, String numDossier, boolean validerCreance, boolean ValiderPaiement) throws GrecoException {
        try {
            for (String opID : mandatements) {
                engagementDao.validationComptableAnnuler(opID, numDossier, validerCreance, ValiderPaiement);
            }
        } catch (Exception e) {
            throw new GrecoException(e);
        }
    }

    @Override
    public List<CleValeur> leveeListByType(String organisationID, String millesime, String typeID) {
        return engagementDao.leveeListByType(organisationID, millesime, typeID);
    }

    @Override
    public List<VueLeveeDetails> leveeListByTypeDetails(String organisationID, String millesime, int typeID, int numeroControle) {
        return engagementDao.leveeListByTypeDetails(organisationID, millesime, typeID, numeroControle);
    }

    @Override
    public void leveeUpdateBlocage(List<String> activerList, List<String> desactiverList, String userAutorise) {
        if(!activerList.isEmpty()){
            for (String leveeID : activerList) {
                engagementDao.leveeUpdateBlocage(leveeID, 1, userAutorise);
            }
        }
        if(!desactiverList.isEmpty()){
            for (String leveeID : desactiverList) {
                engagementDao.leveeUpdateBlocage(leveeID, 0, userAutorise);
            }
        }
    }

}
