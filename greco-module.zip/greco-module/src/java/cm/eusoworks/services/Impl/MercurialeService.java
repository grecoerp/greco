/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IMercurialeDao;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Rubrique;
import cm.eusoworks.entities.model.SousRubrique;
import cm.eusoworks.services.IMercurialeService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class MercurialeService implements IMercurialeService {

    @EJB
    IMercurialeDao mercurialeDao ;

    @Override
    public String ajouterArticle(Article act) throws GrecoException {
        return mercurialeDao.ajouterArticle(act);
    }

    @Override
    public void modifierArticle(Article act) throws GrecoException {
        mercurialeDao.modifierArticle(act);
    }

    @Override
    public void supprimerArticle(String amId) throws GrecoException {
        mercurialeDao.supprimerArticle(amId);
    }

    @Override
    public Article getArticle(String millesime, String amId) {
        return mercurialeDao.getArticle(millesime, amId);
    }

    @Override
    public List<Article> rchercherArticle(String millesime, String chaineRecherchee) {
        return mercurialeDao.rchercherArticle(millesime, chaineRecherchee);
    }

    @Override
    public List<Rubrique> getListRubriques(String millesime) {
        return mercurialeDao.getListRubriques(millesime);
    }

    @Override
    public List<SousRubrique> getListSousRubriques(String millesime, String numRubrique) {
        return mercurialeDao.getListSousRubriques(millesime, numRubrique);
    }

    @Override
    public List<Article> getListArticleBySousRubrique(String exMillesime, String numSousRubrique) {
        return mercurialeDao.getListArticleBySousRubrique(exMillesime, numSousRubrique);
    }

    @Override
    public Article getArticle(String amId) {
        return mercurialeDao.getArticle(amId);
    }

    @Override
    public Article getArticle(String millesime, String refArticle, Date dateEmission) {
        return mercurialeDao.getArticle(millesime, refArticle, dateEmission);
    }

    @Override
    public List<Article> getStockArticles(String exMillesime, String find, boolean isRefOrDesignation) {
        return mercurialeDao.getStockArticles(exMillesime, find, isRefOrDesignation);
    }

    @Override
    public Article getStockArticle(String exMillesime, String reference) {
        return mercurialeDao.getStockArticle(exMillesime, reference);
    }
}
