/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IBonCommandeDao;
import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.model.Bca;
import cm.eusoworks.entities.model.BcaArticles;
import cm.eusoworks.entities.view.VueStructureBCA;
import cm.eusoworks.services.IBonCommandeService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.view.VueControle;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class BonCommandeService implements IBonCommandeService {

    @EJB
    IBonCommandeDao  bonCommandeDao;
    
    @EJB
    IUserDao userDao;

    @Override
    public String ajouter(Bca bca) throws GrecoException {
        bca.setBcaID("BCA"+StringUtil.generatedID());
        try {
            if(bca.getTypeID() == null) bca.setTypeID("1");
        } catch (Exception e) {
        }
        
        bonCommandeDao.ajouter(bca);
        return bca.getBcaID();
    }

    @Override
    public void modifier(Bca bca) throws GrecoException {
        bonCommandeDao.modifier(bca);
    }

    @Override
    public void supprimer(String bcaID, String user, String ipAdresse) throws GrecoException {
        bonCommandeDao.supprimer(bcaID, user, ipAdresse);
    }

    @Override
    public Bca getBCA(String bcaID) {
        return bonCommandeDao.getBCA(bcaID);
    }

    @Override
    public List<Bca> getBCAByOrganisation(String millesime, String organisationID) {
        return bonCommandeDao.getBCAByOrganisation(millesime, organisationID);
    }

    @Override
    public List<Bca> getBCAByFournisseur(String millesime, String organisationID, String fournisseurID) {
        return bonCommandeDao.getBCAByFournisseur(millesime, organisationID, fournisseurID);
    }

    @Override
    public List<Bca> getBCAByOrdonnateur(String millesime, String organisationID, String matriculeOrdo) {
        return bonCommandeDao.getBCAByOrdonnateur(millesime, organisationID, matriculeOrdo);
    }

    @Override
    public List<Bca> getBCAByTache(String millesime, String organisationID, String tacheID) {
        return bonCommandeDao.getBCAByTache(millesime, organisationID, tacheID);
    }

    @Override
    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID) {
        return bonCommandeDao.getBCAByStructure(millesime, organisationID, structureID);
    }
    
    @Override
    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID, int etat) {
        return bonCommandeDao.getBCAByStructure(millesime, organisationID, structureID, etat);
    }

    @Override
    public void ajouterLigne(BcaArticles article) throws GrecoException {
        bonCommandeDao.ajouterLigne(article);
        
    }

    @Override
    public void modifierLigne(BcaArticles bcaArticle) throws GrecoException {
        bonCommandeDao.modifierLigne(bcaArticle);
    }

    @Override
    public void supprimerLigne(String bcaId, String amId, String user, String ip) throws GrecoException {
        bonCommandeDao.supprimerLigne(bcaId, amId, user, ip);
    }

    @Override
    public List<BcaArticles> getBCALignes(String bcaID) {
        return bonCommandeDao.getBCALignes(bcaID);
    }

    @Override
    public BcaArticles getBCAArticle(String bcaID, String amId) {
        return bonCommandeDao.getBCAArticle(bcaID, amId);
    }

    @Override
    public List<VueStructureBCA> getBCANumberByStructure(String millesime, String organisationID) {
        return bonCommandeDao.getBCANumberByStructure(millesime, organisationID);
    }
    
    @Override
    public List<VueStructureBCA> getBCANumberByStructure(String millesime, String organisationID, String typeID){
        return bonCommandeDao.getBCANumberByStructure(millesime, organisationID, typeID);
    }

    @Override
    public void supprimerTousArticles(String bcaID,String user, String ip) {
        bonCommandeDao.supprimerTousArticles( bcaID, user, ip);
    }

    @Override
    public List<Article> getArticleLignes(String bcaID) {
        return bonCommandeDao.getArticleLignes(bcaID);
    }

    @Override
    public List<Bca> getBCAByOrganisationNotUsed(String millesime, String organisationID) {
        return bonCommandeDao.getBCAByOrganisationNotUsed(millesime, organisationID);
    }

    @Override
    public List<VueControle> getControleResult(String bcaID, String typeID) {
        return bonCommandeDao.getControleResult(bcaID, typeID);
    }

    @Override
    public void reservationBCA(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        bonCommandeDao.reservationBCA(bcaID, reserve, motif, login, adresseIP);
    }

    @Override
    public void modifierRIB(String bcaID, String rib, String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName, String os, String arhitecture, String function, String module, int categorie) throws GrecoException {
        bonCommandeDao.modifierRIB(bcaID, rib);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, login, md5HostName, os, arhitecture, function, module, categorie, bcaID);
        
    }

    @Override
    public void ajouterLigneDefinitive(String liquidationID, List<BcaArticles> listeArticles, String user, String ip) throws GrecoException {
        bonCommandeDao.supprimerTousArticlesDefinitive(liquidationID, user, ip);
        for (BcaArticles article : listeArticles) {
            bonCommandeDao.ajouterLigneDefinitive(article);
        }
        
    }

    @Override
    public List<BcaArticles> getBCALignesDefinitives(String liquidationID) {
        return bonCommandeDao.getBCALignesDefinitive(liquidationID);
    }

    @Override
    public void supprimerTousArticlesDefinitif(String liquidationID, String user, String ip) {
        bonCommandeDao.supprimerTousArticlesDefinitive(liquidationID, user, ip);
    }

    @Override
    public List<Bca> getBCAByStructure(String millesime, String organisationID, String structureID, int etat, String typeID) {
        return bonCommandeDao.getBCAByStructure(millesime, organisationID, structureID, etat, typeID);
    }

    @Override
    public void reservationBCAAnnuler(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        bonCommandeDao.reservationBCAAnnuler(bcaID, reserve, motif, login, adresseIP);
    }
    
    
    
}
