/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.dao.IVirementDao;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Virement;
import cm.eusoworks.entities.model.VirementTache;
import cm.eusoworks.services.IVirementService;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class VirementService implements IVirementService {

    @EJB
    IVirementDao virementDao;
    
    @EJB
    IUserDao userDao;

    @Override
    public String ajouter(Virement act, List<VirementTache> list) throws GrecoException {
        if(act.getVirementID() == null){
            act.setVirementID("VIR"+StringUtil.generatedID());
            virementDao.ajouterVirement(act);
        }else {
            virementDao.modifierVirement(act);
        }
        virementDao.supprimerTaches(act.getVirementID());
        if(list != null && !list.isEmpty()){
            for (VirementTache vt : list) {
                if(vt.getVirementTacheID() == null){
                    vt.setVirementTacheID("VRT"+StringUtil.generatedID());
                }
                vt.setVirementID(act.getVirementID());
                vt.setUserUpdate(act.getUserUpdate());
                vt.setIpUpdate(act.getIpUpdate());
                virementDao.ajouterTache(vt);
            }
        }
        return act.getVirementID();
    }

    @Override
    public void supprimer(String virementID, String userUpdate) throws GrecoException {
        virementDao.supprimer(virementID, userUpdate);
    }

    @Override
    public Virement getVirement(String virementID) {
        return virementDao.getVirement(virementID);
    }

    @Override
    public List<VirementTache> getListTache(String virementID) {
        return virementDao.getListTache(virementID);
    }

    @Override
    public List<Virement> getListVirement(String organisationID, String millesime, String budgetID, int mode) {
        return virementDao.getListVirement(organisationID, millesime, budgetID, mode);
    }

    @Override
    public List<VirementTache> getDisponibleTache(String organisationID, String millesime, String budgetID, String chapitre, String tacheCode, String paragraphe) {
        return virementDao.getDisponibleTache(organisationID, millesime, budgetID, chapitre, tacheCode, paragraphe);
    }

    @Override
    public void reserver(String virementID, String userUpdate) throws GrecoException {
        virementDao.reserver(virementID, userUpdate);
    }

    @Override
    public void reservation_annuler(String virementID, String userUpdate) throws GrecoException {
        virementDao.reservation_annuler(virementID, userUpdate);
    }

    @Override
    public void visaBudgetaire(String virementID, String userUpdate) throws GrecoException {
        virementDao.visaBudgetaire(virementID, userUpdate);
    }

    @Override
    public void visaBudgetaire_annuler(String virementID, String userUpdate) throws GrecoException {
        virementDao.visaBudgetaire_annuler(virementID, userUpdate);
    }

    @Override
    public void valider(String virementID, String userUpdate, String arrete, Date dateSignature) throws GrecoException {
        virementDao.valider(virementID, userUpdate, arrete, dateSignature);
    }

    @Override
    public void valider_annuler(String virementID, String userUpdate) throws GrecoException {
        virementDao.valider_annuler(virementID, userUpdate);
    }
    
}
