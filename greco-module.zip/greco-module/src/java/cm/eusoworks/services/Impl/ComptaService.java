/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IComptaDao;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Axe;
import cm.eusoworks.entities.model.ComptaLibelle;
import cm.eusoworks.entities.model.CompteLiquidite;
import cm.eusoworks.entities.model.Devise;
import cm.eusoworks.entities.model.Journaux;
import cm.eusoworks.entities.model.ReglementMode;
import cm.eusoworks.services.IComptaService;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ComptaService implements IComptaService {

    @EJB
    IComptaDao comptaDao;

    // <editor-fold defaultstate="collapsed" desc="ReglementMode">
    @Override
    public void reglementModeAjouter(ReglementMode rg) {
        rg.setReglementID("RGM" + StringUtil.generatedID());
        comptaDao.reglementModeAjouter(rg);
    }

    @Override
    public void reglementModeModifier(ReglementMode rg) {
        comptaDao.reglementModeModifier(rg);
    }

    @Override
    public void reglementModeSupprimer(String ReglementModeID) {
        comptaDao.reglementModeSupprimer(ReglementModeID);
    }

    @Override
    public ReglementMode reglementModeRechercher(String reglementModeID) {
        return comptaDao.reglementModeRechercher(reglementModeID);
    }

    @Override
    public List<ReglementMode> reglementModeListe() {
        return comptaDao.reglementModeListe();
    }
    // </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="Devise">
    @Override
    public void deviseAjouter(Devise dv) {
        dv.setDeviseID("DVS" + StringUtil.generatedID());
        comptaDao.deviseAjouter(dv);
    }

    @Override
    public void deviseModifier(Devise dv) {
        comptaDao.deviseModifier(dv);
    }

    @Override
    public void deviseSupprimer(String deviseID) {
        comptaDao.deviseSupprimer(deviseID);
    }

    @Override
    public Devise deviseRechercher(String deviseID) {
        return comptaDao.deviseRechercher(deviseID);
    }

    @Override
    public List<Devise> deviseRechercherLabel(String label) {
        return comptaDao.deviseRechercherLabel(label);
    }

    @Override
    public List<Devise> deviseList() {
        return comptaDao.deviseList();
    }

    // </editor-fold> 
    
    // <editor-fold defaultstate="collapsed" desc="Axe">
    @Override
    public void axeAjouter(Axe dv) {
        dv.setAxeID(dv.getAbbreviationFr());
        comptaDao.axeAjouter(dv);
    }

    @Override
    public void axeModifier(Axe dv) {
        comptaDao.axeModifier(dv);
    }

    @Override
    public void axeSupprimer(String axeID) {
        comptaDao.axeSupprimer(axeID);
    }

    @Override
    public List<Axe> axeList() {
        return comptaDao.axeList();
    }

    // </editor-fold> 
    
    // <editor-fold defaultstate="collapsed" desc="Jornaux compatbles">
    @Override
    public void journauxAjouter(Journaux dv) {
        dv.setJournalID(dv.getAbbreviationFr());
        comptaDao.journauxAjouter(dv);
    }

    @Override
    public void journauxModifier(Journaux dv) {
        comptaDao.journauxModifier(dv);
    }

    @Override
    public void journauxSupprimer(String axeID) {
        comptaDao.journauxSupprimer(axeID);
    }

    @Override
    public List<Journaux> journauxList() {
        return comptaDao.journauxList();
    }

    // </editor-fold> 

    // <editor-fold defaultstate="collapsed" desc="compta libelle">
    @Override
    public List<ComptaLibelle> comptaLibelleList(String organisationID) {
        return comptaDao.comptaLibelleList(organisationID);
    }

    @Override
    public void comptaLibelleDeleteAll(String organisationID) {
        comptaDao.comptaLibelleDeleteAll(organisationID);
    }

    @Override
    public void comptaLibelleInsert(List<ComptaLibelle> list) throws GrecoException {
        ComptaLibelle c = list.get(0);
        comptaDao.comptaLibelleDeleteAll(c.getOrganisationID());
        for (ComptaLibelle libelle : list) {
            comptaDao.comptaLibelleInsert(libelle.getOrganisationID(), libelle.getCode(), libelle.getLibelle());
        }
        
    }
     // </editor-fold> 
    
    // <editor-fold defaultstate="collapsed" desc="compte de liquidite">

    @Override
    public void liquiditeAjouter(CompteLiquidite org) throws GrecoException {
        org.setLiquiditeID("CLQ" + StringUtil.generatedID());
        comptaDao.liquiditeAjouter(org);
    }
    

    @Override
    public void liquiditeModifier(CompteLiquidite org) throws GrecoException {
        comptaDao.liquiditeModifier(org);
    }

    @Override
    public void liquiditeSupprimer(String liquiditeID) throws GrecoException {
        comptaDao.liquiditeSupprimer(liquiditeID);
    }

    @Override
    public CompteLiquidite liquiditeRechercherById(String liquiditeID) {
        return comptaDao.liquiditeRechercherById(liquiditeID);
    }

    @Override
    public List<CompteLiquidite> liquiditeListe(int type) {
        return comptaDao.liquiditeListe(type);
    }

    @Override
    public List<CompteLiquidite> liquiditeListeBanques() {
        return comptaDao.liquiditeListe(CompteLiquidite.BANQUE);
                
    }

    @Override
    public List<CompteLiquidite> liquiditeListeCaisses() {
        return comptaDao.liquiditeListe(CompteLiquidite.CAISSE);
    }
    
     // </editor-fold> 
}
