/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IClientDao;
import cm.eusoworks.entities.model.Client;
import cm.eusoworks.entities.model.ClientGroupe;
import cm.eusoworks.entities.model.ClientRemise;
import cm.eusoworks.services.IClientService;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ClientService implements IClientService {

    @EJB
    IClientDao clientDao;

    // <editor-fold defaultstate="collapsed" desc="Client">
    @Override
    public void clientAjouter(Client cl) {
        cl.setClientID("CLI"+StringUtil.generatedID());
        clientDao.clientAjouter(cl);
    }

    @Override
    public void clientModifier(Client cl) {
        clientDao.clientModifier(cl);
    }

    @Override
    public void clientSupprimer(String clientID) {
        clientDao.clientSupprimer(clientID);
    }

    @Override
    public Client clientRechercher(String clientID) {
        return clientDao.clientRechercher(clientID);
    }

    @Override
    public List<Client> clientRechercherByIdentifiant(String identifiant) {
        return clientDao.clientRechercherByIdentifiant(identifiant);
    }

    @Override
    public List<Client> clientRechercherByNom(String nom) {
        return clientDao.clientRechercherByNom(nom);
    }

    @Override
    public List<Client> clientList() {
        return clientDao.clientList();
    }

    @Override
    public void clientAjouterGroupe(Date last_update, String user_update, String ip_update, String clientID, String groupeClientID) {
        clientDao.clientAjouterGroupe(last_update, user_update, ip_update, clientID, groupeClientID);
    }

// </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="ClientGroupe">

    @Override
    public void groupeClientAjouter(ClientGroupe grp) {
        grp.setGroupeClientID("CGP"+StringUtil.generatedID());
        clientDao.groupeClientAjouter(grp);
    }

    @Override
    public void groupeClientModifier(ClientGroupe grp) {
        clientDao.groupeClientModifier(grp);
    }

    @Override
    public void groupeClientSupprimer(String clientGroupeID) {
        clientDao.groupeClientSupprimer(clientGroupeID);
    }

    @Override
    public ClientGroupe groupeClientRechercher(String clientGroupeID) {
        return clientDao.groupeClientRechercher(clientGroupeID);
    }

    @Override
    public List<ClientGroupe> groupeClientList() {
        return clientDao.groupeClientList();
    }

    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Client Remise">

    @Override
    public void remiseClientAjouter(ClientRemise rem) {
        rem.setRemiseID("CRM"+StringUtil.generatedID());
        clientDao.remiseClientAjouter(rem);
    }

    @Override
    public void remiseClientModifier(ClientRemise rem) {
        clientDao.remiseClientModifier(rem);
    }

    @Override
    public void remiseClientSupprimer(String clientRemiseID) {
        clientDao.remiseClientSupprimer(clientRemiseID);
    }

    @Override
    public ClientRemise remiseClientRechercher(String clientRemiseID) {
        return clientDao.remiseClientRechercher(clientRemiseID);
    }

    @Override
    public List<ClientRemise> remiseClientList(String clientID, Date dateReference) {
        return clientDao.remiseClientList(clientID, dateReference);
    }
    
    // </editor-fold>
}
