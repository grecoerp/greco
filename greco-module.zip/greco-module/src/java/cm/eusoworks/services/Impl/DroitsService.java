/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IDroitsDao;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.model.LiquidationDroits;
import cm.eusoworks.services.IDroitsService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.MandatementDroits;
import java.util.List;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class DroitsService implements IDroitsService {

    @javax.ejb.EJB
    IDroitsDao droitsDao;
    
    @Override
    public int ajouter(Droits droit, int codeErreur) throws GrecoException {
        droit.setDroitID("DR"+StringUtil.generatedID());
        return droitsDao.ajouter(droit, codeErreur);
    }

    @Override
    public int modifier(Droits droit, int codeErreur) throws GrecoException {
        return droitsDao.modifier(droit, codeErreur);
    }

    @Override
    public void supprimer(String droitID) throws GrecoException {
        droitsDao.supprimer(droitID);
    }

    @Override
    public Droits rechercherById(String droitID) {
        return droitsDao.rechercherById(droitID);
    }

    @Override
    public List<Droits> listeDroits() {
        return droitsDao.listeDroits();
    }

    @Override
    public List<Droits> listeDroitsNAP() {
        return droitsDao.listeDroitsNAP();
    }

    @Override
    public List<Droits> listeDroitsRetenues() {
        return droitsDao.listeDroitsRetenues();
    }
    
    @Override
    public int ajouterLiquidationDroit(List<LiquidationDroits> droits) {
        return droitsDao.ajouterLiquidationDroit(droits);
    }

    @Override
    public void supprimerLiquidationDroit(String engagementID) {
        droitsDao.supprimerLiquidationDroit(engagementID);
    }

    @Override
    public List<LiquidationDroits> listeLiquidationDroits(String engagementID) {
        return droitsDao.listeLiquidationDroits(engagementID);
                
    }

    @Override
    public List<LiquidationDroits> listeLiquidationDroitsNAP(String engagementID) {
        return droitsDao.listeLiquidationDroitsNAP(engagementID);
    }

    @Override
    public List<LiquidationDroits> listeLiquidationDroitsRetenues(String engagementID) {
        return droitsDao.listeLiquidationDroitsRetenues(engagementID);
    }
    
    @Override
    public int ajouterMandatementDroit(List<MandatementDroits> droits) {
        return droitsDao.ajouterMandatementDroit(droits);
    }

    @Override
    public void supprimerMandatementDroit(String mandatementID) {
        droitsDao.supprimerMandatementDroit(mandatementID);
    }

    @Override
    public List<MandatementDroits> listeMandatementDroits(String mandatementID) {
        return droitsDao.listeMandatementDroits(mandatementID);
                
    }

   
}
