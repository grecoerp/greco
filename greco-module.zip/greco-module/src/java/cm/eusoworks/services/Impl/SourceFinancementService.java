/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.ISourceFinancementDao;
import cm.eusoworks.entities.model.SourceFinancement;
import cm.eusoworks.services.ISourceFinancementService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class SourceFinancementService implements ISourceFinancementService{

    @EJB
    ISourceFinancementDao sourceFinancementDao;
    
    
    @Override
    public void ajouter(SourceFinancement sf) throws GrecoException {
        sf.setFinancementID("SF"+StringUtil.generatedID());
        sourceFinancementDao.ajouter(sf);
    }

    @Override
    public void modifier(SourceFinancement sf) throws GrecoException {
        sourceFinancementDao.modifier(sf);
    }

    @Override
    public void supprimer(String posteComptableID) throws GrecoException {
        sourceFinancementDao.supprimer(posteComptableID);
    }

    @Override
    public SourceFinancement rechercherById(String posteComptableID) {
        return sourceFinancementDao.rechercherById(posteComptableID);
    }

    @Override
    public List<SourceFinancement> listeSourceFinancement(String login) {
        return sourceFinancementDao.listeSourceFinancement(login);
    }
    
    @Override
    public List<SourceFinancement> listeSourceFinancement() {
        return sourceFinancementDao.listeSourceFinancement();
    }

}
