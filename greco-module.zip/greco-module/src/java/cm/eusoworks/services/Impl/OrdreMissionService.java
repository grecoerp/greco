/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IOrdreMissionDao;
import cm.eusoworks.entities.model.OrdreMission;
import cm.eusoworks.entities.view.VueAgentOM;
import cm.eusoworks.services.IOrdreMissionService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class OrdreMissionService implements IOrdreMissionService {

    @EJB
    IOrdreMissionDao ordreMissionDao;

    @Override
    public String ajouter(OrdreMission om) throws GrecoException {
        om.setOmID("OM"+StringUtil.generatedID());
        ordreMissionDao.ajouter(om);
        return om.getOmID();
    }

    @Override
    public void modifier(OrdreMission om) throws GrecoException {
        ordreMissionDao.modifier(om);
    }

    @Override
    public void supprimer(String omID, String user, String ipAdresse) throws GrecoException {
        ordreMissionDao.supprimer(omID, user, ipAdresse);
    }

    @Override
    public OrdreMission getOrdreMission(String omID) {
        return ordreMissionDao.getOrdreMission(omID);
    }

    @Override
    public List<OrdreMission> getOMByOrganisation(String millesime, String organisationID) {
        return ordreMissionDao.getOMByOrganisation(millesime, organisationID);
    }

    @Override
    public List<OrdreMission> getOMByAgent(String millesime, String organisationID, String matricule) {
        return ordreMissionDao.getOMByAgent(millesime, organisationID, matricule);
    }

    @Override
    public List<OrdreMission> getOMByTache(String millesime, String organisationID, String tacheID) {
        return ordreMissionDao.getOMByTache(millesime, organisationID, tacheID);
    }

    @Override
    public List<OrdreMission> getOMByStructure(String millesime, String organisationID, String structureID) {
        return ordreMissionDao.getOMByStructure(millesime, organisationID, structureID);
    }

    @Override
    public List<VueAgentOM> getOMNumberByAgent(String millesime, String organisationID) {
        return ordreMissionDao.getOMNumberByAgent(millesime, organisationID);
    }
    
    @Override
    public void reservationOM(String bcaID, boolean reserve, String motif, String login, String adresseIP) throws GrecoException {
        ordreMissionDao.reservationOM(bcaID, reserve, motif, login, adresseIP);
    }

    @Override
    public void reservationOMAnnuler(String decisionID, boolean annuler, String motif, String login, String adresseIP) throws GrecoException {
        ordreMissionDao.reservationOMAnnuler(decisionID, annuler, motif, login, adresseIP);
    }

}
