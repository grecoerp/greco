/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.INiveauDao;
import cm.eusoworks.entities.model.ActiviteNiveau;
import cm.eusoworks.entities.model.CategorieNiveau;
import cm.eusoworks.entities.model.CompteNiveau;
import cm.eusoworks.entities.model.FonctionNiveau;
import cm.eusoworks.entities.model.LocaliteNiveau;
import cm.eusoworks.entities.model.OptionNiveauMax;
import cm.eusoworks.services.INiveauService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class NiveauService implements INiveauService {
    
    @javax.ejb.EJB
    INiveauDao niveauDao;

    @Override
    public void ajouterNiveauActivite(ActiviteNiveau act)  throws GrecoException{
        niveauDao.ajouterNiveauActivite(act);
    }

    @Override
    public void modifierNiveauActivite(ActiviteNiveau act)  throws GrecoException{
        niveauDao.modifierNiveauActivite(act);
    }

    @Override
    public void supprimerNiveauActivite(int activiteNiveauID)  throws GrecoException{
        niveauDao.supprimerNiveauActivite(activiteNiveauID);
    }

    @Override
    public List<ActiviteNiveau> listeNiveauActivite() {
        return niveauDao.listeNiveauActivite();
    }

    @Override
    public void ajouterNiveauCategorie(CategorieNiveau act)  throws GrecoException{
        niveauDao.ajouterNiveauCategorie(act);
    }

    @Override
    public void modifierNiveauCategorie(CategorieNiveau act)  throws GrecoException{
        niveauDao.modifierNiveauCategorie(act);
    }

    @Override
    public void supprimerNiveauCategorie(int categorieNiveauID)  throws GrecoException{
        niveauDao.supprimerNiveauCategorie(categorieNiveauID);
    }

    @Override
    public List<CategorieNiveau> listeNiveauCategorie() {
        return niveauDao.listeNiveauCategorie();
    }

    @Override
    public void ajouterNiveauCompte(CompteNiveau act)  throws GrecoException{
        niveauDao.ajouterNiveauCompte(act);
    }

    @Override
    public void modifierNiveauCompte(CompteNiveau act)  throws GrecoException{
        niveauDao.modifierNiveauCompte(act);
    }

    @Override
    public void supprimerNiveauCompte(int compteNiveauID)  throws GrecoException{
        niveauDao.supprimerNiveauCompte(compteNiveauID);
    }

    @Override
    public List<CompteNiveau> listeNiveauCompte() {
        return niveauDao.listeNiveauCompte();
    }

    @Override
    public void ajouterNiveauFonction(FonctionNiveau act)  throws GrecoException{
        niveauDao.ajouterNiveauFonction(act);
    }

    @Override
    public void modifierNiveauFonction(FonctionNiveau act)  throws GrecoException{
        niveauDao.modifierNiveauFonction(act);
    }

    @Override
    public void supprimerNiveauFonction(int fonctionNiveauID)  throws GrecoException{
        niveauDao.supprimerNiveauFonction(fonctionNiveauID);
    }

    @Override
    public List<FonctionNiveau> listeNiveauFonction() {
        return niveauDao.listeNiveauFonction();
    }

    @Override
    public void ajouterNiveauLocalite(LocaliteNiveau act)  throws GrecoException{
        niveauDao.ajouterNiveauLocalite(act);
    }

    @Override
    public void modifierNiveauLocalite(LocaliteNiveau act)  throws GrecoException{
        niveauDao.modifierNiveauLocalite(act);
    }

    @Override
    public void supprimerNiveauLocalite(int localiteNiveauID)  throws GrecoException{
        niveauDao.supprimerNiveauLocalite(localiteNiveauID);
    }

    @Override
    public List<LocaliteNiveau> listeNiveauLocalite() {
        return niveauDao.listeNiveauLocalite();
    }

    @Override
    public ActiviteNiveau getNiveauActivite(int ID) {
        return niveauDao.getNiveauActivite( ID);
    }

    @Override
    public CategorieNiveau getNiveauCategorie(int ID) {
        return niveauDao.getNiveauCategorie(ID);
    }

    @Override
    public CompteNiveau getNiveauCompte(int ID) {
        return niveauDao.getNiveauCompte(ID);
    }

    @Override
    public FonctionNiveau getNiveauFonction(int ID) {
        return niveauDao.getNiveauFonction(ID);
    }

    @Override
    public LocaliteNiveau getNiveauLocalite(int ID) {
        return niveauDao.getNiveauLocalite(ID);
    }
    
    @Override
    public void saveParametreNiveau(int fu, int ca, int lo, int pc, int at, String userUpdate, String ipUpdate) throws GrecoException {
        niveauDao.saveParametreNiveau(fu, ca, lo, pc, at, userUpdate, ipUpdate);
    }
    
    @Override
    public OptionNiveauMax getOptionNiveauxMax(){
        return niveauDao.getOptionNiveauxMax();
    }
}
