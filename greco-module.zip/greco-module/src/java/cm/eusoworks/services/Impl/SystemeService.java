/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.ISystemeDao;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.services.ISystemeService;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless 
public class SystemeService implements ISystemeService{

    @javax.ejb.EJB
    private ISystemeDao systemeDao;

    @Override
    public List<Systeme> getListSysteme() {
        return systemeDao.getListSysteme();
    }
    
    public List<Systeme> getSystemeListWithHabilitation(String login){
        return systemeDao.getSystemeListWithHabilitation(login);
    }
    
    public List<Modules> getModuleListWithHabilitation(String login){
        return systemeDao.getModuleListWithHabilitation(login);
    }
    
    public List<Modules> getModuleListWithHabilitation(String login, String systemeID){
        return systemeDao.getModuleListWithHabilitation(login, systemeID);
    }

    @Override
    public List<Systeme> getSystemeListByLogin(String login) {
        return systemeDao.getSystemeListByLogin(login);
    }

}
