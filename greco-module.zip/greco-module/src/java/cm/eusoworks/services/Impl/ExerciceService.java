/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IExerciceDao;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.services.IExerciceService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.PrepaBudgetLexique;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ExerciceService implements IExerciceService {

    @EJB
    IExerciceDao exerciceDao;

    @Override
    public void ajouter(Exercice act) throws GrecoException {
        exerciceDao.ajouter(act);
    }

    @Override
    public void modifier(Exercice act) throws GrecoException {
        exerciceDao.modifier(act);
    }

    @Override
    public void supprimer(String exMillesime) throws GrecoException {
        exerciceDao.supprimer(exMillesime);
    }

    @Override
    public Exercice getExercice(String exMillesime) {
        return exerciceDao.getExercice(exMillesime);
    }

    @Override
    public List<Exercice> getListExercice() {
        return exerciceDao.getListExercice();
    }

    @Override
    public List<Exercice> getListExerciceElaboration() {
        return exerciceDao.getListExerciceElaboration();
    }

    @Override
    public List<Exercice> getListExerciceBudgetisation() {
        return exerciceDao.getListExerciceBudgetisation();
    }

    @Override
    public List<Exercice> getListExerciceExecution() {
        return exerciceDao.getListExerciceExecution();
    }
    
    @Override
    public List<Exercice> getListExerciceCloture() {
        return exerciceDao.getListExerciceCloture();
    }

    @Override
    public void budgetAjouter(PrepaBudget budget) throws GrecoException {
        budget.setBudgetID("BGT"+StringUtil.generatedID());
        exerciceDao.budgetAjouter(budget);
    }

    @Override
    public void budgetModifier(PrepaBudget budget) throws GrecoException {
        exerciceDao.budgetModifier(budget);
    }

    @Override
    public void budgetSupprimer(String userDelete, String ipDelete, String budgetID) throws GrecoException {
        exerciceDao.budgetSupprimer(userDelete, ipDelete, budgetID);
    }

    @Override
    public PrepaBudget budgetGetByID(String budgetID) {
        return exerciceDao.budgetGetByID(budgetID);
    }

    @Override
    public List<PrepaBudget> budgetGetByMillesime(String organisationID, String millesime) {
        return exerciceDao.budgetGetByMillesime(organisationID, millesime);
    }

    @Override
    public List<PrepaBudget> budgetGetByMillesime(String organisationID, String millesime, int typeBudget) {
        return exerciceDao.budgetGetByMillesime(organisationID, millesime, typeBudget);
    }

    @Override
    public List<PrepaBudget> budgetGetByMillesimeOnLine(String organisationID, String millesime, boolean online) {
        return exerciceDao.budgetGetByMillesimeOnLine(organisationID, millesime, online);
    }

    @Override
    public void budgetLexique(String organisationID, String millesime, String lexiqueFr, String lexiqueUs) throws GrecoException {
        exerciceDao.budgetLexique(organisationID, millesime, lexiqueFr, lexiqueUs);
    }

    @Override
    public PrepaBudgetLexique budgetLexiqueFind(String organisationID, String millesime) throws GrecoException {
        return exerciceDao.budgetLexiqueFind(organisationID, millesime);
    }

    @Override
    public void budgetTransfererEnExecution(String millesime, String budgetID) throws GrecoException {
        try {
            exerciceDao.budgetTransfererEnExecution(millesime, budgetID);
        } catch (Exception e) {
            throw (new GrecoException(e));
        }
    }
    
}
