/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IReportDao;
import cm.eusoworks.entities.view.VueBCAReport;
import cm.eusoworks.entities.view.VueEngagementBordereau;
import cm.eusoworks.entities.view.VueLiquidationReport;
import cm.eusoworks.entities.view.VueMandatementReport;
import cm.eusoworks.entities.view.VueMissionFiche;
import cm.eusoworks.entities.view.VueOMReport;
import cm.eusoworks.entities.view.VuePTAOperation;
import cm.eusoworks.entities.view.VuePTAParagraphe;
import cm.eusoworks.entities.view.VuePTAStructureParagraphe;
import cm.eusoworks.entities.view.VuePTATache;
import cm.eusoworks.entities.view.VuePTATacheParagraphe;
import cm.eusoworks.entities.view.VuePaieBulletin;
import cm.eusoworks.entities.view.VuePaieRecapRubrique;
import cm.eusoworks.entities.view.VuePaieRubrique;
import cm.eusoworks.entities.view.VueStructureCodification;
import cm.eusoworks.entities.view.VueSuiviFicheControle;
import cm.eusoworks.entities.view.VueSuiviFicheControleDetails;
import cm.eusoworks.services.IReportService;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;
import javax.ejb.EJB;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class ReportService implements IReportService {

    @EJB
    IReportDao reportDao;

    @Override
    public List<VuePTAOperation> getPTAOperation(String organisationID, String millesime) {
        return reportDao.getPTAOperation(organisationID, millesime);
    }

    @Override
    public List<VuePTATache> getPTATache(String organisationID, String millesime) {
        return reportDao.getPTATache(organisationID, millesime);
    }

    @Override
    public List<VuePTATacheParagraphe> getPTATacheParagraphe(String organisationID, String millesime) {
        return reportDao.getPTATacheParagraphe(organisationID, millesime);
    }

    @Override
    public List<VuePTAParagraphe> getPTAParagraphe(String organisationID, String millesime) {
        return reportDao.getPTAParagraphe(organisationID, millesime);
    }

    @Override
    public List<VueBCAReport> getBcaLignesReport(String bcaID) {
        return reportDao.getBcaLignesReport(bcaID);
    }

    @Override
    public VueOMReport getOM(String omID) {
        return reportDao.getOM(omID);
    }

    @Override
    public List<VueLiquidationReport> getLiquidation(String liquidationID) {
        return reportDao.getLiquidation(liquidationID);
    }

    @Override
    public List<VuePTAStructureParagraphe> getPTAStructureParagraphe(String millesime, String organisationID, String articleID, String compteCode) {
        return reportDao.getPTAStructureParagraphe(millesime, organisationID, articleID, compteCode);
    }

    @Override
    public List<VueEngagementBordereau> getBordereauTransmission(String numBordereau) {
        return reportDao.getBordereauTransmission(numBordereau);
    }

    @Override
    public List<VueStructureCodification> getStructureCodification(String organisationID) {
        return reportDao.getStructureCodification(organisationID);
    }

    @Override
    public List<VueMandatementReport> getMandatementReport(String mandatementID) throws SQLException {
        return reportDao.getMandatementReport(mandatementID);
    }

    @Override
    public VuePaieBulletin getPaieBulletin(String employeID, String millesime, Date datedebut, Date dateFin) {
        return reportDao.getPaieBulletin(employeID, millesime, datedebut, dateFin);
    }

    @Override
    public List<VuePaieRubrique> getPaieRubriquesBase(String employeID, String millesime, Date datedebut, Date dateFin) {
        return reportDao.getPaieRubriquesBase(employeID, millesime, datedebut, dateFin);
    }

    @Override
    public List<VuePaieRubrique> getPaieRubriquesRetenues(String employeID, String millesime, Date datedebut, Date dateFin) {
        return reportDao.getPaieRubriquesRetenues(employeID, millesime, datedebut, dateFin);
    }

    @Override
    public List<VuePaieRubrique> getPaieRubriquesNet(String employeID, String millesime, Date datedebut, Date dateFin) {
        return reportDao.getPaieRubriquesNet(employeID, millesime, datedebut, dateFin);
    }

    @Override
    public List<VuePaieRecapRubrique> getPaieRecapCotisations(Date dateDebut, Date dateFin) {
        return reportDao.getPaieRecapCotisations(dateDebut, dateFin);
    }

    @Override
    public List<VueSuiviFicheControle> getSuiviFicheControleAE(String millesime, String organisationID, String activiteID, String tacheID, int base) {
        return reportDao.getSuiviFicheControleAE(millesime, organisationID, activiteID, tacheID, base);
    }

    @Override
    public List<VueSuiviFicheControleDetails> getSuiviFicheControleAEDetails(String tacheID, int base) {
        return reportDao.getSuiviFicheControleAEDetails(tacheID, base);
    }

    @Override
    public List<VueSuiviFicheControleDetails> getSuiviFicheConsolideeAEDetails(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        return reportDao.getSuiviFicheConsolideeAEDetails(millesime, organisationID, budgetID, structureID, programmeID, actionID, activiteID, tacheID, beneficiaire, base);
    }

    @Override
    public List<VueSuiviFicheControleDetails> getSuiviBudgetConsolideAE(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        return reportDao.getSuiviBudgetConsolideAE(millesime, organisationID, budgetID, structureID, programmeID, actionID, activiteID, tacheID, beneficiaire, base);
    }

    @Override
    public List<VueMissionFiche> getMissionFiche(String organisationID, String millesime, String matricule) {
        return reportDao.getMissionFiche(organisationID, millesime, matricule);
    }

    @Override
    public List<VueSuiviFicheControleDetails> getFileFicheConsolideeDetails(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        return reportDao.getFileFicheConsolideeDetails(millesime, organisationID, budgetID, structureID, programmeID, actionID, activiteID, tacheID, beneficiaire, base);
    }

    @Override
    public List<VueSuiviFicheControleDetails> getFileBudgetConsolide(String millesime, String organisationID, String budgetID, String structureID, String programmeID, String actionID, String activiteID, String tacheID, String beneficiaire, int base) {
        return reportDao.getFileBudgetConsolide(millesime, organisationID, budgetID, structureID, programmeID, actionID, activiteID, tacheID, beneficiaire, base);
    }

}
