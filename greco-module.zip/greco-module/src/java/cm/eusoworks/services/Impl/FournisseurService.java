/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IFournisseurDao;
import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.services.IFournisseurService;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;
import javax.ejb.EJB;
import utils.StringUtil;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class FournisseurService implements IFournisseurService {

    @EJB
    IFournisseurDao fournisseurDao ;

    @Override
    public void ajouter(Fournisseur four) throws GrecoException {
        four.setFournisseurID("CTB"+StringUtil.generatedID());
        fournisseurDao.ajouter(four);
    }

    @Override
    public String ajouterFournisseurBudgetaire(Fournisseur four, String exMillesime) throws GrecoException {
        four.setFournisseurID("CTB"+StringUtil.generatedID());
        return fournisseurDao.ajouterFournisseurBudgetaire(four, exMillesime);
    }

    @Override
    public void modifier(Fournisseur four) throws GrecoException {
        fournisseurDao.modifier(four);
    }

    @Override
    public void supprimer(String fournisseurID) throws GrecoException {
        fournisseurDao.supprimer(fournisseurID);
    }

    @Override
    public Fournisseur getFournisseur(String fournisseurID) {
       return fournisseurDao.getFournisseur(fournisseurID);
    }

    @Override
    public List<Fournisseur> getListFournisseur() {
        return fournisseurDao.getListFournisseur();
    }

    @Override
    public List<Fournisseur> getListFournisseurByNumContribuable(String numContribuable) {
       return fournisseurDao.getListFournisseurByNumContribuable(numContribuable);
    }

}
