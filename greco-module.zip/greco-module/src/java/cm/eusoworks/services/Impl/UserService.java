/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services.Impl;

import cm.eusoworks.dao.IUserDao;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.entities.model.Userpreferences;
import cm.eusoworks.entities.model.Users;
import cm.eusoworks.entities.view.VueTrack;
import cm.eusoworks.services.IUserService;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.UserGroupe;
import cm.eusoworks.entities.model.UserProfils;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueMachine;
import cm.eusoworks.entities.view.VueEntiteReduit;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author macbookair
 */
@javax.ejb.Stateless
public class UserService implements IUserService {

    @javax.ejb.EJB
    private IUserDao userDao;

    @Override
    public Users rechercher(String login) throws GrecoException {
        return userDao.rechercher(login);
    }

    @Override
    public boolean authentifier(String login, String password) {
        return userDao.authentifier(login, password);
    }

    @Override
    public List<Systeme> getSystemeListByUser(String login) {
        return userDao.getSystemeListByUser(login);
    }

    @Override
    public Userpreferences getUserPreferences(String login) {
        return userDao.getUserPreferences(login);
    }

    @Override
    public void savePreferences(String locale, boolean sound, boolean soundFail, boolean soundSuccess, boolean soundWait, String ipAdress, String userUpdate, String imageFond) {
        userDao.savePreferences(locale, sound, soundFail, soundSuccess, soundWait, ipAdress, userUpdate, imageFond);
    }

    @Override
    public List<Modules> getModuleListByUser(String login) {
        return userDao.getModuleListByUser(login);
    }

    @Override
    public void updatePassword(String login, String oldPassword, String newPassword) throws GrecoException {
        Users u = rechercher(login);
        if (!u.getPassword().equals(Crypto.crypterPassword(Crypto.decrypt(login), oldPassword))) {
            throw new GrecoException("L'ancien mot de passe ne correspond pas a celui de l'utilisateur", "Old password not matching with user's own", true);
        } else {
            userDao.updatePassword(login, Crypto.crypterPassword(Crypto.decrypt(login), newPassword));
        }
    }

    @Override
    public void deleteUser(String login) throws GrecoException {
        userDao.deleteUser(login);
    }

    @Override
    public List<Users> getListUsersByOrganisation(String organisationID) {
        return userDao.getListUsersByOrganisation(organisationID);
    }

    @Override
    public void enregistrer(String user_update, String ip_update, String login, String password, String nom, String prenom, String immatriculation, String fonction, String email, boolean actif, String service, String organisationID, String structureID,
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String telephone) throws GrecoException {
        userDao.enregistrer(user_update, ip_update, login, password, nom, prenom, immatriculation, fonction, email, actif, service, organisationID, structureID,
                facebook, whatsapp, twitter, linkedln, googleplus, telephone);
    }

    @Override
    public void modifier(String user_update, String ip_update, String login, String password, String nom, String prenom, String immatriculation, String fonction, String email, boolean actif, String service, String organisationID, String structureID,
            String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String telephone) {
        userDao.modifier(user_update, ip_update, login, password, nom, prenom, immatriculation, fonction, email, actif, service, organisationID, structureID,
                facebook, whatsapp, twitter, linkedln, googleplus, telephone);
    }

    @Override
    public void saveConnection(String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName) {
        try {
            userDao.saveConnection(user_update, ip_update, hostname, mac, motif, login, md5HostName);
        } catch (GrecoException ex) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public List<VueTrack> getTracking(String login, Date dateDebut, Date dateFin) {
        return userDao.getTracking(login, dateDebut, dateFin);
    }

    @Override
    public List<VueTrack> getTrackingMachine(String machineName, Date dateDebut, Date dateFin) {
        return userDao.getTrackingMachine(machineName, dateDebut, dateFin);
    }

    @Override
    public List<VueMachine> getListMachine() {
        return userDao.getListMachine();
    }

    @Override
    public List<VueTrack> getTrackingDossier(String dossier) {
        return userDao.getTrackingDossier(dossier);
    }

    @Override
    public void profilInsert(String user_update, String ip_update, String profilID, String login, String groupeID) {
        userDao.profilInsert(user_update, ip_update, profilID, login, groupeID);
    }

    @Override
    public void profilUpdate(String user_update, String ip_update, String profilID, String login, String groupeID) {
        userDao.profilUpdate(user_update, ip_update, profilID, login, groupeID);
    }

    @Override
    public void profilDeleteByLoginAndGroupe(String user_update, String ip_update, String login, String groupeID) {
        userDao.profilDeleteByLoginAndGroupe(user_update, ip_update, login, groupeID);
    }

    @Override
    public void profilDeleteByLogin(String user_update, String ip_update, String login) {
        userDao.profilDeleteByLogin(user_update, ip_update, login);
    }

    @Override
    public void profilDeleteByGroupe(String user_update, String ip_update, String groupeID) {
        userDao.profilDeleteByGroupe(user_update, ip_update, groupeID);
    }

    @Override
    public UserProfils profilGetByID(String profilID) {
        return userDao.profilGetByID(profilID);
    }

    @Override
    public List<UserProfils> profilGetByLogin(String login) {
        return userDao.profilGetByLogin(login);
    }

    @Override
    public List<UserProfils> profilGetByLoginAndModule(String login, String moduleID) {
        return userDao.profilGetByLoginAndModule(login, moduleID);
    }

    @Override
    public void groupeDeleteByGroup(String user_update, String ip_update, String groupeID) {
        userDao.groupeDeleteByGroup(user_update, ip_update, groupeID);
    }

    @Override
    public void groupeInsert(String user_update, String ip_update, String groupeID, String libelleFr, String description, String proprietaire, String profils) {
        userDao.groupeInsert(user_update, ip_update, groupeID, libelleFr, description, proprietaire, profils);
    }

    @Override
    public void groupeUpdate(String user_update, String ip_update, String groupeID, String libelleFr, String description, String proprietaire, String profils) {
        userDao.groupeUpdate(user_update, ip_update, groupeID, libelleFr, description, proprietaire, profils);
    }

    @Override
    public UserGroupe groupeGetByID(String groupeID) {
        return userDao.groupeGetByID(groupeID);
    }

    @Override
    public List<UserGroupe> groupeGetByLogin(String login) {
        return userDao.groupeGetByLogin(login);
    }

    @Override
    public List<UserGroupe> groupeGetByModule(String moduleID) {
        return userDao.groupeGetByModule(moduleID);
    }

    @Override
    public List<UserGroupe> groupeGetByLoginAndModule(String login, String moduleID) {
        return userDao.groupeGetByLoginAndModule(login, moduleID);
    }

    @Override
    public List<UserGroupe> groupeGetSousGroupe(String groupeID) {
        return userDao.groupeGetSousGroupe(groupeID);
    }

    @Override
    public List<UserGroupe> groupeGetSousGroupeByProprietaire(String groupeID, String login) {
        return userDao.groupeGetSousGroupeByProprietaire(groupeID, login);
    }

    @Override
    public void modifierReseauSociaux(String user_update, String ip_update, String login, String facebook, String whatsapp, String twitter, String linkedln, String googleplus, String email, String telephone) throws GrecoException {
        userDao.modifierReseauSociaux(user_update, ip_update, login, facebook, whatsapp, twitter, linkedln, googleplus, email, telephone);
    }

    @Override
    public void journalisation(String user_update, String ip_update, String hostname, String mac, String motif, String login, String md5HostName, String os, String arhitecture, String function, String module, int categorie, String id) {
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, login, md5HostName, os, arhitecture, function, module, categorie, id);
    }

    @Override
    public List<VueEntiteReduit> userOrganisationList(String loginHierarchie, String login) {
        return userDao.userOrganisationList(loginHierarchie, login);
    }

    @Override
    public void userOrganisationDelete(String login, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) {
        userDao.userOrganisationDelete(login);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
    }

    @Override
    public void userOrganisationSave(String login, List<VueEntiteReduit> orgList, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) {
        try {
            userDao.userOrganisationDelete(login);
            for (VueEntiteReduit v : orgList) {
                userDao.userOrganisationSave(login, v);
            }
            userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
        } catch (Exception e) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, e);
        }

    }

    @Override
    public List<VueEntiteReduit> userStructureList(String loginHierarchie, String login) throws GrecoException {
        return userDao.userStructureList(loginHierarchie, login);
    }

    @Override
    public void userStructureDelete(String login, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        userDao.userStructureDelete(login);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
    }

    @Override
    public void userStructureSave(String login, List<VueEntiteReduit> orgList, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        try {
            userDao.userStructureDelete(login);
            for (VueEntiteReduit v : orgList) {
                userDao.userStructureSave(login, v);
            }
            userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
        } catch (Exception e) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, e);
        }
    }

    // source financement
    @Override
    public List<VueEntiteReduit> userSourceFinancementList(String loginHierarchie, String login) throws GrecoException {
        return userDao.userSourceFinancementList(loginHierarchie, login);
    }

    @Override
    public void userSourceFinancementDelete(String login, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        userDao.userSourceFinancementDelete(login);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
    }

    @Override
    public void userSourceFinancementSave(String login, List<VueEntiteReduit> orgList, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        try {
            userDao.userSourceFinancementDelete(login);
            for (VueEntiteReduit v : orgList) {
                userDao.userSourceFinancementSave(login, v);
            }
            userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
        } catch (Exception e) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, e);
        }
    }
    
    @Override
    public List<VueEntiteReduit> userProgrammeList(String loginHierarchie, String login, String millesime) throws GrecoException {
        return userDao.userProgrammeList(loginHierarchie, login, millesime);
    }
    
    @Override
    public List<VueEntiteReduit> userProgrammeActionList(String loginHierarchie, String login, String activiteParentID, String millesime) throws GrecoException {
        return userDao.userProgrammeActionList(loginHierarchie, login, activiteParentID, millesime);
    }

    @Override
    public void userProgrammeDelete(String login, String millesime, int type, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        userDao.userProgrammeDelete(login, millesime, type);
        userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
    }

    @Override
    public void userProgrammeSave(String login, String activiteParentID, String millesime, int type, 
                            List<VueEntiteReduit> orgList, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException {
        try {
            userDao.userProgrammeDelete(login, millesime, type);
            for (VueEntiteReduit v : orgList) {
                userDao.userProgrammeSave(login, activiteParentID, millesime, type, v);
            }
            userDao.journalisation(user_update, ip_update, hostname, mac, motif, user_update, md5HostName, os, arhitecture, function, module, 1, login);
        } catch (Exception e) {
            Logger.getLogger(UserService.class.getName()).log(Level.SEVERE, null, e);
        }
    }

}
