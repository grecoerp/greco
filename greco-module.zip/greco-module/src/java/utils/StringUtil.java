/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package utils;

import java.text.DecimalFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import javax.swing.JEditorPane;
import javax.swing.text.BadLocationException;
import javax.swing.text.rtf.RTFEditorKit;

/**
 * Collection de méthodes utilitaires pour la manipulation des chaînes de caractères
 * @author Michel MBEM
 */
public class StringUtil {

    public static final String DEFAULT_QUOTE = "'";
    public static final char DEFAULT_PADDING = ' ';
    public static final String DEFAULT_SEPARATOR = ",";
    public static final String DEFAULT_CAMEL_CASE_REGEX = "[\\W_]+";
    private static DecimalFormat f = new DecimalFormat("#,##0.##");
    private static JEditorPane rtfPane;
    private static Random rnd = new Random();

    public static String generatedID() {
        return codeFromDate(new Date());
    }

    public static String codeFromDate(Date date) {
        if (date == null) {
            date = new Date();
        }
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        return String.valueOf(c.get(Calendar.YEAR))
                + (c.get(Calendar.MONTH) < 10 ? "0" : "") + String.valueOf(c.get(Calendar.MONTH))
                + (c.get(Calendar.DATE) < 10 ? "0" : "") + String.valueOf(c.get(Calendar.DATE))
                + (c.get(Calendar.HOUR_OF_DAY) < 10 ? "0" : "") + String.valueOf(c.get(Calendar.HOUR_OF_DAY))
                + (c.get(Calendar.MINUTE) < 10 ? "0" : "") + String.valueOf(c.get(Calendar.MINUTE))
                + (c.get(Calendar.SECOND) < 10 ? "0" : "") + String.valueOf(c.get(Calendar.SECOND))
                + "." + String.valueOf(c.get(Calendar.MILLISECOND)).concat(".").concat(String.valueOf(rnd.nextInt(1000)));
    }

    public static String quotedString(String value, String quote) {
        if (quote == null) {
            return value;
        }
        if (value == null) {
            return quote + quote;
        }
        return quote + value.replaceAll(quote, quote + quote) + quote;
    }

    public static String quotedString(String value) {
        return quotedString(value, DEFAULT_QUOTE);
    }

    public static boolean isNullOrEmpty(String chaine) {
        if (chaine == null) {
            return true;
        }
        return chaine.trim().isEmpty();
    }

    public static String padLeft(String value, int length, char padding) {
        StringBuilder sb = new StringBuilder(value);
        while (sb.length() < length) {
            sb.insert(0, padding);
        }
        return sb.toString();
    }

    public static String padLeft(String value, int length) {
        return padLeft(value, length, DEFAULT_PADDING);
    }

    public static String padRight(String value, int length, char padding) {
        StringBuilder sb = new StringBuilder(value);
        while (sb.length() < length) {
            sb.append(padding);
        }
        return sb.toString();
    }

    public static String padRight(String value, int length) {
        return padRight(value, length, DEFAULT_PADDING);
    }

    public static String join(String[] values, String separator) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) {
                sb.append(separator);
            }
            sb.append(values[i]);
        }
        return sb.toString();
    }

    public static String join(String[] values) {
        return join(values, DEFAULT_SEPARATOR);
    }

    public static String capitalize(String value) {
        if (isNullOrEmpty(value)) {
            return value;
        }
        if (value.length() == 1) {
            return value.toUpperCase();
        }
        return Character.toUpperCase(value.charAt(0)) + value.substring(1).toLowerCase();
    }

    public static String toCamelCase(String[] words, boolean firstWordLower) {
        StringBuilder sb = new StringBuilder();
        int index = 0;

        if (firstWordLower) {
            sb.append(words[0].toLowerCase());
            index = 1;
        }

        while (index < words.length) {
            sb.append(capitalize(words[index++]));
        }

        return sb.toString();
    }

    public static String toCamelCase(String value, String regex, boolean firstWordLower) {
        return toCamelCase(value.split(regex), firstWordLower);
    }

    public static String toCamelCase(String value, boolean firstWordLower) {
        return toCamelCase(value, DEFAULT_CAMEL_CASE_REGEX, firstWordLower);
    }

    public static String reverseCase(String value) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < value.length(); i++) {
            char c = value.charAt(i);
            if (Character.isUpperCase(c)) {
                sb.append(Character.toLowerCase(c));
            } else if (Character.isLowerCase(c)) {
                sb.append(Character.toUpperCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    public static String nullIfEmpty(String ch) {
        if (ch == null) {
            return null;
        }
        if (ch.isEmpty()) {
            return null;
        }
        if (ch.trim().equals("")) {
            return null;
        }
        return ch;
    }

    public static String formatNumber(double value) {
        return f.format(value);
    }

    public static String rtfToTexte(String rtfText) {
        try {
            if (rtfPane == null) {
                rtfPane = new JEditorPane();
                rtfPane.setEditorKit(new RTFEditorKit());
            }
            rtfPane.setText(rtfText);
            return rtfPane.getDocument().getText(0, rtfPane.getDocument().getLength());
        } catch (BadLocationException ex) {
            return "";
        }
    }
    
     public static String reformat(final String value){
        if(value==null){
            return "";
        }
        String st=value;
        StringBuilder builder=new StringBuilder();
        builder.append(st.substring(0, 2));
        st=st.substring(2);
        builder.append(" ");
        builder.append(st.substring(0, 2));
        st=st.substring(2);
        String suffix=st.substring(st.length()-4);
        st=st.substring(0, st.length()-4);
        builder.append(" ");
        builder.append(st);
         builder.append(" ");
        builder.append(suffix);
        return builder.toString();
    }
}
