/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services;

import cm.eusoworks.entities.cls.CleValeur;
import cm.eusoworks.entities.model.Agent;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IAgentService {

    public Agent getAgent(String agMatricule);

    public List<Agent> getAgents(String prefix);

    public String ajouterAgentBudgetaire(Agent agentBudgetaire);

    public void modifierAgentBudgetaire(Agent agentBudgetaire);
    
    public void supprimerAgentBudgetaire(String agMatricule, String userMaj, String ipAdresse);
   
    public List<CleValeur> importAgent(List<Agent> list);

    public void importAgent(String exMillesime, String matricule, String nom, String prenom, String nomJeuneFille,
                                Date dateNaiss, String cni,  String utLogin, String ipAdresse, boolean actif );
    
    public void validerImportation();
    
    public List<Agent> getAgentBudgetaire(String exMillesime, String organisationID);
    
    
}
