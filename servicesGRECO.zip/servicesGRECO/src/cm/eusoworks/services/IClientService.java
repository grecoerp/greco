/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services;

import cm.eusoworks.entities.model.Client;
import cm.eusoworks.entities.model.ClientGroupe;
import cm.eusoworks.entities.model.ClientRemise;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IClientService {

    public void clientAjouter(Client cl);

    public void clientModifier(Client cl);

    public void clientSupprimer(String clientID);

    public Client clientRechercher(String clientID);

    public List<Client> clientRechercherByIdentifiant(String identifiant);

    public List<Client> clientRechercherByNom(String nom);

    public List<Client> clientList();

    public void clientAjouterGroupe(Date last_update, String user_update, String ip_update, String clientID, String groupeClientID);
    
    
    public void groupeClientAjouter(ClientGroupe grp);

    public void groupeClientModifier(ClientGroupe grp);

    public void groupeClientSupprimer(String clientGroupeID);

    public ClientGroupe groupeClientRechercher(String clientGroupeID);

    public List<ClientGroupe> groupeClientList();
    
    
    public void remiseClientAjouter(ClientRemise rem);

    public void remiseClientModifier(ClientRemise rem);

    public void remiseClientSupprimer(String clientRemiseID);

    public ClientRemise remiseClientRechercher(String clientRemiseID);

    public List<ClientRemise> remiseClientList(String clientID, Date dateReference);
    

}
