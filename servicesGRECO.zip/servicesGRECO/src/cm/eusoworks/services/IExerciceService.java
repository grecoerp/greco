/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services;

import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.PrepaBudgetLexique;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IExerciceService {
    
    public void ajouter(Exercice act) throws GrecoException;
    public void modifier(Exercice act) throws GrecoException;
    public void supprimer(String exMillesime) throws GrecoException;
    public Exercice getExercice(String exMillesime);
    public List<Exercice> getListExercice(); 
    public List<Exercice> getListExerciceElaboration();
    public List<Exercice> getListExerciceBudgetisation();
    public List<Exercice> getListExerciceExecution();
    public List<Exercice> getListExerciceCloture();
    
    public void budgetAjouter(PrepaBudget budget)  throws GrecoException;
    public void budgetModifier(PrepaBudget budget)  throws GrecoException;
    public void budgetSupprimer(String userDelete, String ipDelete, String budgetID)  throws GrecoException;
    public PrepaBudget budgetGetByID(String budgetID);
    public List<PrepaBudget> budgetGetByMillesime(String organisationID, String millesime);
    public List<PrepaBudget> budgetGetByMillesime(String organisationID, String millesime, int typeBudget);
    public List<PrepaBudget> budgetGetByMillesimeOnLine(String organisationID, String millesime, boolean online);
    public void budgetLexique(String organisationID, String millesime, String lexiqueFr, String lexiqueUs)  throws GrecoException;
    public PrepaBudgetLexique budgetLexiqueFind(String organisationID, String millesime)  throws GrecoException;
    public void budgetTransfererEnExecution(String millesime, String budgetID)  throws GrecoException;
}
