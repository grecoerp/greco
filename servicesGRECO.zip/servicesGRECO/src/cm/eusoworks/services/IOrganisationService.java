/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services;

import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.DatabaseOptions;
import cm.eusoworks.entities.model.Notes;
import cm.eusoworks.entities.model.OrgOptions;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IOrganisationService {

    /**
     * Ajoute une nouvelle organisation dans la base
     *
     * @param org l'entite possedant les proprietes de l'organisation a ajouter
     * @param codeErreur : Code erreur en cas de non execution de la procedure
     * @return code erreur en cas de non insertion de l'organisation
     * @throws GrecoException
     */
    public int ajouter(Organisation org, int codeErreur) throws GrecoException;

    /**
     * Modifie les proprietes d'une organisation
     *
     * @param org : l'organisation a modifier
     * @param codeErreur : Code erreur en cas de non execution de la procedure
     * @return Code erreur en cas de non mise a jour insertion de l'organisation
     * @throws GrecoException
     */
    public int modifier(Organisation org, int codeErreur) throws GrecoException;

    /**
     * Supprime une organisation de la base de donnees
     *
     * @param organisationID : l'identifiant de l'organisation a supprimer
     * @throws GrecoException : Generes une exception si la suppression a echoue
     * notamment pour cause de contraintes d'integrite
     */
    public void supprimer(String organisationID) throws GrecoException;

    /**
     * Renvoi l'organisation possedant l'identiant specifie en parametre
     *
     * @param organisationID : l'identifiant de l'organisation
     * @return Organisation
     */
    public Organisation rechercherById(String organisationID);

    /**
     * Renvoie une liste d'organisation possedant le code specifie en parametre
     *
     * @param code :Code de/des organisation
     * @return List
     */
    public List<Organisation> rechercherByCode(String code);

    /**
     * Renvoie la liste des organisations actives
     *
     * @return List
     */
    public List<Organisation> listeOrganisationActives();
    
    public List<Organisation> listeOrganisationUserActives(String login);
    
    public List<Organisation> listeOrganisationUserOrdonnateurs(String login);
    
    public List<Organisation> listeOrganisationUserControleur(String login);
    
    public List<Organisation> listeOrganisationUserComptable(String login);
    
    public List<Organisation> listeOrganisationUserGestion(String login);
    

    /**
     * Renvoie la liste de toutes les organisations de la base, actives ou non
     *
     * @return List
     */
    public List<Organisation> listeOrganisationComplete();

    public void ajouterStructure(Structure org) throws GrecoException;

    public void modifierStructure(Structure org) throws GrecoException;

    public void supprimerStructure(String structureID) throws GrecoException;

    public List<Structure> listeStructuresOrganisation(String organisationID);
    
    public List<Structure> listeStructuresUserByOrganisation(String organisationID, String login);
    
    public List<Structure> listeStructuresFilles(String organisationID, String structureID);
    
    public void saveParametres(String organisationID, String zoneEco, String paysFr, String paysUs, String deviseFr, String deviseUs, String orgSigleFr, 
            String orgSigleUs, String orgLibelleFr, String orgLibelleUs, String orgContact, String appAbreviationFr, String appAbreviationUs, String appTitleFr, String appTitleUs,
            String user, String adresseIP, String machine, String motif, String tutelleFr, String tutelleUs);
    
    public void saveParametres(OrgOptions op);
    
    public void saveBackupDBParameters(String organisationID, String adresseIP, String port, String username, String password, String database, String dumpPath, 
                                        String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    
    public DatabaseOptions databaseGetParameters(String organisationID);
    
    public OrgOptions getOptionOrganisation(String organisationID);
    
    public List<Structure> listeStructuresByUniteOrganique(String organisationID, String uniteOrganiqueID);
    
    public int structureMaxOrdre(String caCode, String loCode);
    
    public void noteModification(String user_update, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins);

    public void noteAjout(String userupdate, String ip_update, String noteID, String objet, String contenu, Date dateAffichage, Integer statut, String organisationIDs, String moduleIDs, String userLogins);

    public List<Notes> noteRechercher(String organisationID, String noteID, String moduleID, String userLogins, Date dateAffichageDebut, Date dateAffichageFin, String userupdate, Integer statut);

    public void noteSuppression(String noteID); 

}
