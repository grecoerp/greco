/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services;

import cm.eusoworks.entities.model.Fournisseur;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IFournisseurService {
    
    public void ajouter(Fournisseur four) throws GrecoException;
    public String ajouterFournisseurBudgetaire(Fournisseur four, String exMillesime) throws GrecoException;
    public void modifier(Fournisseur four) throws GrecoException;
    public void supprimer(String fournisseurID) throws GrecoException;
    public Fournisseur getFournisseur(String fournisseurID);
    public List<Fournisseur> getListFournisseur();
    public List<Fournisseur> getListFournisseurByNumContribuable(String numContribuable);
  
}
