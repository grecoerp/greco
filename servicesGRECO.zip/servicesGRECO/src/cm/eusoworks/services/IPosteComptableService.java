/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services;

import cm.eusoworks.entities.model.PosteComptable;
import cm.eusoworks.entities.model.PosteComptableNature;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IPosteComptableService {
    

    public void ajouter(PosteComptable pc)  throws GrecoException;

    public void modifier(PosteComptable pc)  throws GrecoException;

    public void supprimer(String posteComptableID)  throws GrecoException;

    public PosteComptable rechercherById(String posteComptableID);

    public List<PosteComptable> rechercherByCode(String codePC);

    public List<PosteComptable> listePosteComptableActifs();
 
    public List<PosteComptable> listePosteComptableComplete();
    
    public List<PosteComptable> getPosteComptableOfLocalite(String localiteID);
    
    public List<PosteComptable> getPosteComptableByLocalite(String localiteID);
    
    public List<PosteComptable> getPosteComptableByNature(String naturePC);
    
    public List<PosteComptable> getPosteComptableByLocaliteAndNature(String localiteID, String naturePC);
    
    //poste comptable nature
    public void ajouterPCNature(PosteComptableNature pc)  throws GrecoException;

    public void modifierPCNature(PosteComptableNature pc)  throws GrecoException;

    public void supprimerPCNature(String naturePC)  throws GrecoException;

    public PosteComptableNature rechercherPCNatureById(String naturePC);

    public List<PosteComptableNature> getPosteComptableNature();
    
}
