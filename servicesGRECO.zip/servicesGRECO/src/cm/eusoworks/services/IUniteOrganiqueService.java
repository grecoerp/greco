/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services;

import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.NiveauOrganique;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IUniteOrganiqueService {
    /**
     * Ajoute une nouvelle unite organique dans la base
     * @param org l'entite possedant les proprietes de l'unite organique a ajouter
     * @param codeErreur : Code erreur en cas de non execution de la procedure
     * @return code erreur en cas de non insertion de l'organisation
     * @throws GrecoException 
     */
    public int ajouter(UniteOrganique org, int codeErreur)  throws GrecoException;
    /**
     * Modifie les proprietes d'une unite organique 
     * @param org : l'unite organique  a modifier
     * @param codeErreur : Code erreur en cas de non execution de la procedure
     * @return Code erreur en cas de non mise a jour insertion de l'organisation
     * @throws GrecoException 
     */
    public int modifier(UniteOrganique org, int codeErreur)  throws GrecoException;
    /**
     * Supprime une unite organique  de la base de donnees
     * @param uniteOrganiqueID : l'identifiant de l'unite organique  a supprimer
     * @throws GrecoException : Generes une exception si la suppression a echoue notamment pour cause de contraintes d'integrite 
     */
    public void supprimer(String uniteOrganiqueID)  throws GrecoException;
    /**
     * Renvoi l'unite organique  possedant l'identiant specifie en parametre
     * @param uniteOrganiqueID : l'identifiant de l'unite organique 
     * @return UniteOrganique
     */
    public UniteOrganique rechercherById(String uniteOrganiqueID);
    /**
     * Renvoie une liste d'unite organique  possedant le code specifie en parametre
     * @param numOrdre
     * @return UniteOrganique
     */
    public UniteOrganique rechercherByOrder(int numOrdre);
    
    /**
     * Renvoie la liste de toutes les unites organiques de la base, actives ou non
     * @return List
     */
    public List<UniteOrganique> listeUniteOrganique(String organisationID);
    
    public List<UniteOrganique> listeUniteOrganiqueFilles(String uniteOrganiqueID);
    
    public List<UniteOrganique> getUniteOrganiqueForStructure(String structureID);
    
    public List<UniteOrganique> getUniteOrganiqueFillesForStructure(String structureID);
    
    public int ajouterNiveau(NiveauOrganique org, int codeErreur)  throws GrecoException;

    public int modifierNiveau(NiveauOrganique org, int codeErreur)  throws GrecoException;

    public void supprimerNiveau(int niveauOrganiqueID)  throws GrecoException;
    
    public NiveauOrganique rechercherNiveauById(String niveauOrganiqueID);
    
    public List<NiveauOrganique> listeNiveauOrganique(String organisationID);
    
    public List<UniteOrganique> listeUniteOrganiqueByNiveau(String organisationID, int niveauOrganiqueID);
}
