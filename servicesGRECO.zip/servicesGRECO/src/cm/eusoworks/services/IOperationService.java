/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.services;

import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.view.VueOpDisponiblePipe;
import java.math.BigDecimal;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IOperationService {
    
    //prepa
    public void prepaAjouter(PrepaOperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    public void prepaModifier(PrepaOperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    public void prepaSupprimer(String tacheID, String user, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    public PrepaOperationBudgetaire prepaGetOperation(String tacheID);
    public List<PrepaOperationBudgetaire> prepaGetListOperationByActivite(String activiteID, String budgetID);
    public List<PrepaOperationBudgetaire> prepaGetListOperationByActiviteWithCollectif(String activiteID, String budgetID, String budgetCollectifID);
    
    // copie prepa
    public int prepaCopierSelectOperation( List<PrepaOperationBudgetaire> listeOperation, 
              String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module);
    
    // execution
    public void ajouter(OperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    public void modifier(OperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    public void supprimer(String tacheID, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    public OperationBudgetaire getOperation(String tacheID);
    public List<OperationBudgetaire> getListOperationByActivite(String activiteID);
    public List<OperationBudgetaire> getListOperationByActiviteAndStructure(String activiteID, String structureID);
    public BigDecimal getDisponible(OperationBudgetaire op);
    public VueOpDisponiblePipe getDisponiblePipe(String tacheID);
    /*
    getListOperationByActiviteExec :
    Liste des operations budgetaires avec la dotation initiale et le disponible affichés en cours d'exécution 
    */
    public List<OperationBudgetaire> getListOperationByActiviteExecution(String activiteID, String budgetID);
    
    public void prepaCollectifInsert(String budgetID, String budgetCollectifID, PrepaOperationBudgetaire act, String user_update, String ip_update, String hostname, String mac, String motif, String md5HostName, String os, String arhitecture, String function, String module) throws GrecoException;
    
    public int prepaCollectifEnExecution (String budgetInitialID, String budgetCollectifID,String user_update);
}
