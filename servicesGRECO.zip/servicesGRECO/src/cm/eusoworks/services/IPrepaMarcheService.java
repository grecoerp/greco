/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services;

import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.PrepaMarche;
import cm.eusoworks.entities.model.PrepaMarcheContractant;
import cm.eusoworks.entities.model.PrepaMarcheFinancement;
import cm.eusoworks.entities.model.PrepaMarcheGestion;
import cm.eusoworks.entities.model.PrepaMarcheMO;
import cm.eusoworks.entities.model.PrepaMarchePhasage;
import cm.eusoworks.entities.model.PrepaMarchePrestation;
import cm.eusoworks.entities.model.PrepaMarcheTypeAO;
import cm.eusoworks.entities.view.VuePrepaMarche;
import cm.eusoworks.entities.view.VuePrepaMarcheArticle;
import cm.eusoworks.entities.view.VuePrepaMarcheJournal;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IPrepaMarcheService {

    int deleteMarche(String paId);

    PrepaMarche saveMarche(PrepaMarche marche, PrepaMarcheGestion gestion, PrepaMarchePhasage phasage);

    int deleteMarcheContractant(String contractantId);

    PrepaMarcheContractant saveMarcheContractant(PrepaMarcheContractant contractant);

    int deleteMarcheFinancement(String financementId);

    PrepaMarcheFinancement saveMarcheFinancement(PrepaMarcheFinancement financement);

    int deleteMarchePrestation(String naturePrestationId);

    PrepaMarchePrestation saveMarchePrestation(PrepaMarchePrestation prestation);

    int deleteMarcheTypeAO(String typeAOId);

    PrepaMarcheTypeAO saveMarcheTypeAO(PrepaMarcheTypeAO typeAO);

    PrepaMarche getMarche(String paId);

    List<PrepaMarche> getMarches(String exMillesime);

    List<PrepaMarche> getMarches(String exMillesime, String organisationID);

    List<PrepaMarche> getMarches(String exMillesime, String organisationID, String paId, String naturePrestationId, String contractantId, String typeAOId, String financementId);

    PrepaMarcheContractant getMarcheContractant(String contractantId);

    List<PrepaMarcheContractant> getMarcheContractants();

    PrepaMarcheFinancement getMarcheFinancement(String financementId);

    List<PrepaMarcheFinancement> getMarcheFinancements();

    PrepaMarchePrestation getMarchePrestations(String naturePrestationId);

    List<PrepaMarchePrestation> getMarchePrestations();

    PrepaMarcheTypeAO getMarcheTypeAO(String typeAOId);

    List<PrepaMarcheTypeAO> getMarcheTypeAOs();

    List<OperationBudgetaire> getParagrapheParChapitreEtNature(String exMillesime, String organisationID, String neLike);

    List<VuePrepaMarche> getMarcheByPaId(String paId);

    List<VuePrepaMarcheJournal> getMarcheJournal(String exMillesime, String organisationID, String maitreOuvrage);

    List<VuePrepaMarcheJournal> getMarcheListeMO(String exMillesime, String organisationID);

    List<VuePrepaMarche> getListeMarcheByExerciceChapitre(String exMillesime, String organisationID);

    List<VuePrepaMarcheJournal> getListeMarcheAttribueByChapitre(String exMillesime, String organisationID);

    List<VuePrepaMarcheJournal> getListeMarcheAttribueByRegionAndChapitre(String exMillesime, String chCode, String prProvinceID);

    List<VuePrepaMarcheJournal> getMarcheAbbreviationUnique(String abbreviationSF, String abbreviationPr, String abbreviationAO);

    int deleteMarcheMO(String maitreId);

    int saveMarcheMO(PrepaMarcheMO mO);

    PrepaMarcheMO getMarcheMO(String maitreId);

    List<PrepaMarcheMO> getMarcheMOParExercice(String exMillesime);

    List<PrepaMarcheMO> getMarcheMOChapitres(String exMillesime);

    List<PrepaMarcheMO> getMarcheMOStructures(String exMillesime);

    List<VuePrepaMarcheArticle> getListeMarcheArticle(String arCode, String user);

    List<VuePrepaMarche> getListeMarcheRecovery(String exMillesime, String organisationID);
}
