/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.services;

import cm.eusoworks.entities.model.Article;
import cm.eusoworks.entities.model.Rubrique;
import cm.eusoworks.entities.model.SousRubrique;
import cm.eusoworks.entities.exception.GrecoException;
import java.util.Date;
import java.util.List;

/**
 *
 * @author macbookair
 */
@javax.ejb.Remote
public interface IMercurialeService {

    public String ajouterArticle(Article act) throws GrecoException;

    public void modifierArticle(Article act) throws GrecoException;

    public void supprimerArticle(String amId) throws GrecoException;

    public Article getArticle(String millesime, String refArticle);

    public List<Article> rchercherArticle(String millesime, String chaineRecherchee);

    public List<Rubrique> getListRubriques(String millesime);

    public List<SousRubrique> getListSousRubriques(String millesime, String numRubrique);

    public List<Article> getListArticleBySousRubrique(String exMillesime, String srId);
    
    public Article getArticle(String amId);
    
    public Article getArticle(String millesime, String refArticle, Date dateEmission);
    
    public List<Article> getStockArticles(String exMillesime, String find, boolean isRefOrDesignation);
    
    public Article getStockArticle(String exMillesime, String reference);

}
