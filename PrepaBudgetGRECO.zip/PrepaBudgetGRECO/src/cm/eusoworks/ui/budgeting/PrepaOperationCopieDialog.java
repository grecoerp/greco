/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PrepaActivite;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JOptionPane;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author macbookair
 */
public class PrepaOperationCopieDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OperationDialog
     */
    PrepaActivite tache;
    PrepaBudget budgetCourant;
    String budgetExploite;
    List<PrepaOperationBudgetaire> listOperations = ObservableCollections.observableList(new ArrayList<PrepaOperationBudgetaire>());

    public PrepaOperationCopieDialog(boolean modal, PrepaActivite tache, PrepaBudget budget) {
        super(null, modal);
        initComponents();
        this.tache = tache;
        budgetCourant = budget;
        budgetExploite = budgetExploite;
        lblTacheACopier.setText(tache.getCode() + " " + tache.getLibelle());
        lblTacheACopier1.setText(tache.getCode() + " " + tache.getLibelle());
        loadOperations();
        loadOrganisations();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Copie des opérations d'une tâche vers une autre tâche ");
        //setPreferredSize(new Dimension(955, 620));
        pack();
        setLocationRelativeTo(null);
    }

    private void loadBudget() {
        List<PrepaBudget> list = null;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            try {
                list = GrecoServiceFactory.getExerciceService().budgetGetByMillesime(o.getOrganisationID(), tache.getMillesime());
            } catch (Exception e) {
                e.printStackTrace();
                list = null;
            }
            if (list != null && !list.isEmpty()) {
                cboBudget.setModel(new DefaultComboBoxModel(list.toArray()));
                cboBudget.setSelectedIndex(-1);
            }
        }
    }

    private void loadOperations() {
        List<PrepaOperationBudgetaire> listOper = new ArrayList<>();
        listOper = GrecoServiceFactory.getOperationService().prepaGetListOperationByActivite(tache.getActiviteID(), budgetCourant.getBudgetID());

        listOperations.clear();
        if (listOper != null) {
            for (PrepaOperationBudgetaire op : listOper) {
                listOperations.add(op);
            }
        }

    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadStructureOrganisation() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            List<Structure> list = new ArrayList<Structure>();
            try {
                list = GrecoServiceFactory.getOrganisationService().listeStructuresUserByOrganisation(o.getOrganisationID(),
                        GrecoSession.USER_CONNECTED.getLogin());
            } catch (Exception e) {
                list = null;
            }
            if (list != null && !list.isEmpty()) {
                cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
                cboStructure.setSelectedIndex(-1);
            }
        }
    }

    private void loadTacheOrganisation() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            List<PrepaActivite> list = new ArrayList<PrepaActivite>();
            try {
                list = GrecoServiceFactory.getActiviteService().prepaGetListActiviteNiveau(o.getOrganisationID(), GrecoSession.optionNiveau.getAt(), tache.getMillesime());
            } catch (Exception e) {
                list = null;
            }
            if (list != null && !list.isEmpty()) {
                cboTache.setModel(new DefaultComboBoxModel(list.toArray()));
                cboTache.setSelectedIndex(-1);
            }
        }
    }

    public List<PrepaOperationBudgetaire> getListOperations() {
        return listOperations;
    }

    public void setListOperations(List<PrepaOperationBudgetaire> listOperations) {
        this.listOperations = listOperations;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jPanel3 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        lblTacheACopier1 = new org.jdesktop.swingx.JXLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOperations = new javax.swing.JTable();
        jLabel3 = new javax.swing.JLabel();
        btnSuivant = new cm.eusoworks.tools.ui.GButton();
        chkCocherTous = new javax.swing.JCheckBox();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        cboTache = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        lblTacheACopier = new org.jdesktop.swingx.JXLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        cboBudget = new javax.swing.JComboBox();
        jPanel2 = new javax.swing.JPanel();
        btnPrecedent = new cm.eusoworks.tools.ui.GButton();
        btnEnregistrer = new javax.swing.JButton();
        btnFermer = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        jPanel3.setBackground(new java.awt.Color(249, 249, 249));

        jLabel12.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel12.setText("TACHE A COPIER");

        lblTacheACopier1.setText("jXLabel1");

        tblOperations.setRowHeight(22);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listOperations}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblOperations);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${compteCode}"));
        columnBinding.setColumnName("Paragraphe");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelleFr}"));
        columnBinding.setColumnName("Libellé");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${ae}"));
        columnBinding.setColumnName("AE");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${cp}"));
        columnBinding.setColumnName("CP");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane1.setViewportView(tblOperations);
        if (tblOperations.getColumnModel().getColumnCount() > 0) {
            tblOperations.getColumnModel().getColumn(0).setResizable(false);
            tblOperations.getColumnModel().getColumn(0).setPreferredWidth(40);
            tblOperations.getColumnModel().getColumn(1).setResizable(false);
            tblOperations.getColumnModel().getColumn(1).setPreferredWidth(70);
            tblOperations.getColumnModel().getColumn(2).setPreferredWidth(400);
            tblOperations.getColumnModel().getColumn(3).setPreferredWidth(120);
            tblOperations.getColumnModel().getColumn(4).setPreferredWidth(120);
        }

        jLabel3.setText("Liste des paragraphes à copier     ");

        btnSuivant.setText("Sélectionner le projet de destination >>> ");
        btnSuivant.setStyle(5);
        btnSuivant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuivantActionPerformed(evt);
            }
        });

        chkCocherTous.setText("Cocher tous");
        chkCocherTous.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkCocherTousActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnSuivant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(42, 42, 42))
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 158, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblTacheACopier1, javax.swing.GroupLayout.PREFERRED_SIZE, 658, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chkCocherTous, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 22, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(5, 5, 5)
                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTacheACopier1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(chkCocherTous)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnSuivant, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(11, 11, 11))
        );

        getContentPane().add(jPanel3, "source");

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(249, 249, 251));
        jPanel1.setLayout(null);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Structure responsable : ");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 260, 150, 30);

        jPanel1.add(cboStructure);
        cboStructure.setBounds(190, 260, 490, 27);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Organisation : ");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(10, 150, 120, 20);

        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });
        jPanel1.add(cboOrganisation);
        cboOrganisation.setBounds(190, 150, 490, 20);

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Tache destination : ");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(10, 220, 140, 30);

        jPanel1.add(cboTache);
        cboTache.setBounds(190, 220, 490, 30);

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        jLabel11.setText("TACHE A COPIER");
        jPanel1.add(jLabel11);
        jLabel11.setBounds(10, 20, 110, 14);

        lblTacheACopier.setText("jXLabel1");
        jPanel1.add(lblTacheACopier);
        lblTacheACopier.setBounds(10, 50, 680, 50);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        jLabel2.setText("Copier vers ...");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 110, 240, 30);

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel13.setText("BUDGET : ");
        jPanel1.add(jLabel13);
        jLabel13.setBounds(10, 180, 120, 20);

        cboBudget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboBudgetActionPerformed(evt);
            }
        });
        jPanel1.add(cboBudget);
        cboBudget.setBounds(190, 180, 490, 20);

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 15, 5));

        btnPrecedent.setText("<<< Sélectionner la tâche source");
        btnPrecedent.setStyle(5);
        btnPrecedent.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPrecedentActionPerformed(evt);
            }
        });
        jPanel2.add(btnPrecedent);

        btnEnregistrer.setText("Démarrer la copie  ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnFermer.setText("Fermer");
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });
        jPanel2.add(btnFermer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetails, "destination");

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnFermerActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        loadBudget();
        loadStructureOrganisation();
        loadTacheOrganisation();

    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        int res = JOptionPane.showConfirmDialog(null, "Etes vous de vouloir copier les opérations de cette tache ?");
        if (res == JOptionPane.YES_OPTION) {
            try {
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                PrepaActivite tacheDest = (PrepaActivite) cboTache.getSelectedItem();
                Structure structure = (Structure) cboStructure.getSelectedItem();
                PrepaBudget pb = (PrepaBudget) cboBudget.getSelectedItem();
                String budgetExploite = BudgetType.ETAT_REPORT;
                switch (pb.getType()) {
                    case BudgetType.REPORT:
                        budgetExploite = BudgetType.ETAT_REPORT;
                        break;
                    case BudgetType.INITIAL:
                        budgetExploite = BudgetType.ETAT_INITIAL;
                        break;
                    case BudgetType.ADDITIF:
                        budgetExploite = BudgetType.ETAT_ADDITIF;
                        break;
                    default:
                        break;
                }

                if (o != null) {
                    if (tacheDest != null) {
                        if (structure != null) {
                            if (pb != null) {
                                // liste des operations a copier
                                List<PrepaOperationBudgetaire> l = new ArrayList<>();
                                for (PrepaOperationBudgetaire op : listOperations) {
                                    if (op.isChecked()) {
                                        op.setActiviteBudgetiseID(tacheDest.getActiviteID());
                                        op.setStructureID(structure.getStructureID());
                                        op.setBudgetID(pb.getBudgetID());
                                        op.setBudgetExploite(budgetExploite);
                                        op.setTacheID(null);
                                        op.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                                        op.setIpUpdate(GrecoSession.USER_ADRESSE_IP);

                                        l.add(op);
                                    }
                                }
                                if (!l.isEmpty()) {
                                    int nb = GrecoServiceFactory.getOperationService().prepaCopierSelectOperation(l, GrecoSession.USER_CONNECTED.getLogin(),
                                            GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                                            Crypto.encrypt("copie des opération de la tache " + tache.getLibelle() + " vers la tache " + tacheDest.getLibelle()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                                            GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.BUDGETISATION_ANNUELLE);
                                    if (nb == l.size()) {
                                        GrecoSession.notifications.success();
                                        GrecoOptionPane.showSuccessDialog(nb + " d'opérations copiés avec succès");
                                        this.dispose();
                                    } else if (nb < l.size()) {
                                        GrecoSession.notifications.doubleBeep();
                                        GrecoOptionPane.showWarningDialog(nb + "/" + l.size() + " opérations copiés");
                                        this.dispose();
                                        return; 
                                    }

                                }

                            }

                        }
                    }
                }
                GrecoOptionPane.showWarningDialog("Vous n'avez pas sélectionné tous les paramètres ou bien la liste des tâches à copier est vide ");

            } catch (Exception e) {
                e.printStackTrace();
                GrecoSession.notifications.echec();
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void chkCocherTousActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkCocherTousActionPerformed
        // TODO add your handling code here:
        selectAllOperations();
    }//GEN-LAST:event_chkCocherTousActionPerformed

    private void btnSuivantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuivantActionPerformed
        // TODO add your handling code here:
        int nb = 0;
        for (PrepaOperationBudgetaire op : listOperations) {
            if (op.isChecked()) {
                nb++;
            }
        }
        jLabel2.setText("("+nb+") opérations à copier vers ...");
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "destination");
    }//GEN-LAST:event_btnSuivantActionPerformed

    private void cboBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboBudgetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboBudgetActionPerformed

    private void btnPrecedentActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPrecedentActionPerformed
        // TODO add your handling code here:
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "source");
    }//GEN-LAST:event_btnPrecedentActionPerformed

    private void selectAllOperations() {
        // TODO add your handling code here:
        boolean s = chkCocherTous.isSelected();
        List<PrepaOperationBudgetaire> l = new ArrayList<>();
        for (PrepaOperationBudgetaire st : listOperations) {
            st.setChecked(s);
            l.add(st);
        }
        listOperations.clear();
        for (PrepaOperationBudgetaire st : l) {
            listOperations.add(st);
        }
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnFermer;
    private cm.eusoworks.tools.ui.GButton btnPrecedent;
    private cm.eusoworks.tools.ui.GButton btnSuivant;
    private javax.swing.JComboBox cboBudget;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboStructure;
    private javax.swing.JComboBox cboTache;
    private javax.swing.JCheckBox chkCocherTous;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private org.jdesktop.swingx.JXLabel lblTacheACopier;
    private org.jdesktop.swingx.JXLabel lblTacheACopier1;
    private javax.swing.JPanel pDetails;
    private javax.swing.JTable tblOperations;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
