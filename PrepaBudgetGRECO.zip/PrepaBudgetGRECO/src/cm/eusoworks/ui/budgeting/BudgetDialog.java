/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PrepaBudgetLexique;
import com.siicore.util.DateUtil;
import java.awt.CardLayout;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author ouethy
 */
public class BudgetDialog extends GrecoTemplateDialog {

    private PrepaBudget pb;
    public static int MODE_NOUVEAU = 1;
    public static int MODE_VALIDATION_MINISTERIELLE = 2;
    public static int MODE_VALIDATION_PRIMATURE = 3;

    private int mode;
    private int typeBudget;
    PrepaBudgetLexique pbl;

    /**
     * Creates new form CodeSmithDialog
     */
    public BudgetDialog(JFrame parent, boolean modal, PrepaBudget pb, int mode, Organisation o, Exercice e, int type) {
        super(parent, modal);
        initComponents();
        this.pb = pb;
        this.mode = mode;
        this.typeBudget = type;
        txtReference.setEnabled(false);
        loadOrganisations(o);
        loadMillesis(e);
        initUI();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Gestion des budgets ");
        //setPreferredSize(new Dimension(955, 620));
    }

    public BudgetDialog(JFrame parent, boolean modal, PrepaBudget pb, int mode, Organisation o, Exercice e) {
        this(parent, modal, pb, mode, o, e, pb==null?BudgetType.INITIAL:pb.getType());
    }

    private void initUI() {
        if (typeBudget != BudgetType.COLLECTIF) {
            lblBudgetInitial.setVisible(false);
            cboBudget.setVisible(false);
        } else {
            loadBudget(BudgetType.INITIAL);
            lblBudgetInitial.setVisible(true);
            cboBudget.setVisible(true);
        }

        if (pb == null) {
//            cboMillesime.setSelectedIndex(-1);
//            cboOrganisationID.setSelectedIndex(-1);
            cboMillesime.setEnabled(false);
            cboOrganisationID.setEnabled(false);
            txtLibelleFr.setText("");
            txtLibelleUs.setText("");
            txtReference.setText("");
        } else {
            for (int i = 0; i < cboMillesime.getItemCount(); i++) {
                Exercice o = (Exercice) cboMillesime.getItemAt(i);
                if (pb.getMillesime().equalsIgnoreCase(o.getMillesime())) {
                    cboMillesime.setSelectedIndex(i);
                    cboMillesime.setEnabled(false);
                    break;
                }
            }
            for (int i = 0; i < cboOrganisationID.getItemCount(); i++) {
                Organisation o = (Organisation) cboOrganisationID.getItemAt(i);
                if (pb.getOrganisationID().equalsIgnoreCase(o.getOrganisationID())) {
                    cboOrganisationID.setSelectedIndex(i);
                    cboOrganisationID.setEnabled(false);
                    break;
                }
            }
            txtLibelleFr.setText(pb.getLibelleFr());
            txtLibelleUs.setText(pb.getLibelleUs());

            typeBudget = pb.getType();
            chkSaisie.setSelected(pb.isSaisie());
            chkMinisterielle.setSelected(pb.isValideMinistere());
            chkPrimature.setSelected(pb.isValidePM());
            txtReference.setText(pb.getReference());

            rdbInitial.setEnabled(false);
            rdbAdditif.setEnabled(false);
            rdbReport.setEnabled(false);
            rdbCollectif.setEnabled(false);

            if (this.mode == MODE_VALIDATION_MINISTERIELLE) {
                chkMinisterielle.setEnabled(true);
            } else if (this.mode == MODE_VALIDATION_PRIMATURE) {
                chkPrimature.setEnabled(true);
                txtReference.setEnabled(true);
            }
            // note 
            txtNotePresentation.setText(pb.getNotePresentationFr());
            // volume 
            txtVolumeAE.setValue(pb.getVolumeAE());
            txtVolumeCP.setValue(pb.getVolumeCP());
        }
        switch (this.typeBudget) {
            case BudgetType.INITIAL:
                rdbInitial.setSelected(true);
                break;
            case BudgetType.ADDITIF:
                rdbAdditif.setSelected(true);
                break;
            case BudgetType.REPORT:
                rdbReport.setSelected(true);
                break;
            case BudgetType.COLLECTIF:
                rdbCollectif.setSelected(true);

                break;
            default:
                break;
        }
    }

    private void loadBudget(int type) {
        Organisation o = (Organisation) cboOrganisationID.getSelectedItem();
        if (o != null) {
            Exercice e = (Exercice) cboMillesime.getSelectedItem();
            if (e != null) {
                List<PrepaBudget> list = GrecoServiceFactory.getExerciceService().budgetGetByMillesime(o.getOrganisationID(),
                        e.getMillesime(), type);
                if (list != null && !list.isEmpty()) {
                    cboBudget.setModel(new DefaultComboBoxModel(list.toArray()));
                }
            }
        }
    }

    private void loadMillesis(Exercice ex) {
        List<Exercice> list = new ArrayList();
        if (ex != null) {
            list.add(ex);
        } else {
            try {
                list = GrecoServiceFactory.getExerciceService().getListExercice();
            } catch (Exception e) {
            }
        }
        if (list != null && !list.isEmpty()) {
            cboMillesime.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboMillesime.setSelectedIndex(0);
            }
        }
    }

    private void loadOrganisations(Organisation org) {
        List<Organisation> list = new ArrayList();
        if (org != null) {
            list.add(org);
        } else {
            try {
                list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
            } catch (Exception e) {
            }
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisationID.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisationID.setSelectedIndex(0);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        panelContents = new javax.swing.JPanel();
        panelInfos = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        btnNotePresentation1 = new cm.eusoworks.tools.ui.GButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtNotePresentation = new javax.swing.JEditorPane();
        pCentre = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        cboMillesime = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        cboOrganisationID = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        txtLibelleFr = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        txtLibelleUs = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        txtReference = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtVolumeAE = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        txtVolumeCP = new javax.swing.JFormattedTextField();
        rdbReport = new javax.swing.JRadioButton();
        rdbInitial = new javax.swing.JRadioButton();
        rdbAdditif = new javax.swing.JRadioButton();
        chkPrimature = new javax.swing.JCheckBox();
        chkSaisie = new javax.swing.JCheckBox();
        chkMinisterielle = new javax.swing.JCheckBox();
        btnNotePresentation = new cm.eusoworks.tools.ui.GButton();
        lnkLexique = new org.jdesktop.swingx.JXHyperlink();
        rdbCollectif = new javax.swing.JRadioButton();
        lblBudgetInitial = new javax.swing.JLabel();
        cboBudget = new javax.swing.JComboBox();
        pSouth = new javax.swing.JPanel();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();
        btnFermer = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("True");
        setPreferredSize(new java.awt.Dimension(676, 455));

        panelContents.setLayout(new java.awt.BorderLayout());

        panelInfos.setLayout(new java.awt.CardLayout());

        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));

        btnNotePresentation1.setText("<<< Retour ");
        btnNotePresentation1.setStyle(5);
        btnNotePresentation1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotePresentation1ActionPerformed(evt);
            }
        });
        jPanel3.add(btnNotePresentation1);

        jPanel2.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jScrollPane2.setViewportView(txtNotePresentation);

        jPanel2.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        panelInfos.add(jPanel2, "note");

        pCentre.setBackground(new java.awt.Color(255, 255, 255));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel3.setText("Millesime  :");

        cboMillesime.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboMillesime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboMillesimeActionPerformed(evt);
            }
        });

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel11.setText("Organisation  :");

        cboOrganisationID.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel4.setText("Libelle Francais  :");

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel5.setText("Libelle Anglais  :");

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel9.setText("Reference  :");

        txtReference.setEnabled(false);

        jLabel1.setText("AE : ");

        txtVolumeAE.setEditable(false);
        txtVolumeAE.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtVolumeAE.setFont(new java.awt.Font("Lucida Grande", 0, 20)); // NOI18N

        jLabel2.setText("CP : ");

        txtVolumeCP.setEditable(false);
        txtVolumeCP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter()));
        txtVolumeCP.setFont(new java.awt.Font("Lucida Grande", 0, 20)); // NOI18N

        buttonGroup1.add(rdbReport);
        rdbReport.setForeground(new java.awt.Color(102, 153, 255));
        rdbReport.setText("BUDGET REPORT N-1");
        rdbReport.setEnabled(false);
        rdbReport.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbReportActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdbInitial);
        rdbInitial.setForeground(new java.awt.Color(153, 0, 153));
        rdbInitial.setText("BUDGET INITIAL ");
        rdbInitial.setEnabled(false);

        buttonGroup1.add(rdbAdditif);
        rdbAdditif.setForeground(new java.awt.Color(255, 153, 0));
        rdbAdditif.setText("BUDGET ADDITIF");
        rdbAdditif.setEnabled(false);

        chkPrimature.setText("Validation Primature");
        chkPrimature.setEnabled(false);

        chkSaisie.setText("En cours de saisie ");
        chkSaisie.setEnabled(false);

        chkMinisterielle.setText("Validation ministerielle");
        chkMinisterielle.setEnabled(false);

        btnNotePresentation.setText("Note de présentation du budget");
        btnNotePresentation.setStyle(5);
        btnNotePresentation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNotePresentationActionPerformed(evt);
            }
        });

        lnkLexique.setText("Petit lexique du budget suivant la nomenclature ");
        lnkLexique.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnkLexiqueActionPerformed(evt);
            }
        });

        buttonGroup1.add(rdbCollectif);
        rdbCollectif.setForeground(new java.awt.Color(255, 153, 0));
        rdbCollectif.setText("COLLECTIF BUD.");
        rdbCollectif.setEnabled(false);

        lblBudgetInitial.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        lblBudgetInitial.setText("Budget Initial : ");

        cboBudget.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboBudget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboBudgetActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pCentreLayout = new javax.swing.GroupLayout(pCentre);
        pCentre.setLayout(pCentreLayout);
        pCentreLayout.setHorizontalGroup(
            pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCentreLayout.createSequentialGroup()
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pCentreLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pCentreLayout.createSequentialGroup()
                                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pCentreLayout.createSequentialGroup()
                                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(0, 0, 0)
                                        .addComponent(txtLibelleFr, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pCentreLayout.createSequentialGroup()
                                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(20, 20, 20)
                                        .addComponent(txtLibelleUs, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pCentreLayout.createSequentialGroup()
                                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(20, 20, 20)
                                        .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(pCentreLayout.createSequentialGroup()
                                            .addComponent(btnNotePresentation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                            .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(chkPrimature, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(chkMinisterielle, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addComponent(chkSaisie, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                        .addGroup(pCentreLayout.createSequentialGroup()
                                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(50, 50, 50)
                                            .addComponent(txtVolumeAE, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(30, 30, 30)
                                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 50, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGap(10, 10, 10)
                                            .addComponent(txtVolumeCP, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(pCentreLayout.createSequentialGroup()
                                .addComponent(rdbReport)
                                .addGap(18, 18, 18)
                                .addComponent(rdbInitial, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rdbAdditif, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(rdbCollectif, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(pCentreLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pCentreLayout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(20, 20, 20)
                                .addComponent(cboMillesime, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                                .addComponent(lnkLexique, javax.swing.GroupLayout.PREFERRED_SIZE, 344, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pCentreLayout.createSequentialGroup()
                                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pCentreLayout.createSequentialGroup()
                                        .addComponent(lblBudgetInitial, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(20, 20, 20)
                                        .addComponent(cboBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 531, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(pCentreLayout.createSequentialGroup()
                                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(20, 20, 20)
                                        .addComponent(cboOrganisationID, javax.swing.GroupLayout.PREFERRED_SIZE, 540, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(0, 0, Short.MAX_VALUE)))))
                .addContainerGap())
        );
        pCentreLayout.setVerticalGroup(
            pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCentreLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboOrganisationID, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboMillesime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lnkLexique, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(lblBudgetInitial, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 41, Short.MAX_VALUE)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(rdbReport)
                    .addComponent(rdbInitial)
                    .addComponent(rdbAdditif)
                    .addComponent(rdbCollectif))
                .addGap(18, 18, 18)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLibelleFr, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLibelleUs, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pCentreLayout.createSequentialGroup()
                        .addGap(4, 4, 4)
                        .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txtReference, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtVolumeAE, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtVolumeCP, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pCentreLayout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chkSaisie)
                .addGroup(pCentreLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pCentreLayout.createSequentialGroup()
                        .addGap(5, 5, 5)
                        .addComponent(chkPrimature)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(chkMinisterielle))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pCentreLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnNotePresentation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)))
                .addGap(17, 17, 17))
        );

        panelInfos.add(pCentre, "infos");

        panelContents.add(panelInfos, java.awt.BorderLayout.CENTER);

        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        pSouth.add(btnEnregistrer);

        btnSupprimer.setText("Supprimer");
        btnSupprimer.setCouleur(1);
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        pSouth.add(btnSupprimer);

        btnFermer.setText("Fermer");
        btnFermer.setCouleur(3);
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });
        pSouth.add(btnFermer);

        panelContents.add(pSouth, java.awt.BorderLayout.SOUTH);

        getContentPane().add(panelContents, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

	private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
            // TODO add your handling code here:
            fermer();
    }//GEN-LAST:event_btnFermerActionPerformed

	private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
            // TODO add your handling code here:
            enregistrer();
    }//GEN-LAST:event_btnEnregistrerActionPerformed

	private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
            // TODO add your handling code here:
            supprimer();
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void rdbReportActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbReportActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbReportActionPerformed

    private void cboMillesimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboMillesimeActionPerformed
        // TODO add your handling code here:
        Exercice e = (Exercice) cboMillesime.getSelectedItem();
        if (e != null) {
            int year = DateUtil.getYear(e.getDateDebut());
            rdbReport.setText("BUDGET REPORT " + year);
        }
    }//GEN-LAST:event_cboMillesimeActionPerformed

    private void btnNotePresentation1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotePresentation1ActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "infos");
    }//GEN-LAST:event_btnNotePresentation1ActionPerformed

    private void btnNotePresentationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNotePresentationActionPerformed
        // TODO add your handling code here:
        ((CardLayout) panelInfos.getLayout()).show(panelInfos, "note");
    }//GEN-LAST:event_btnNotePresentationActionPerformed

    private void lnkLexiqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnkLexiqueActionPerformed
        // TODO add your handling code here:
        chargerLexiqueBudget();
    }//GEN-LAST:event_lnkLexiqueActionPerformed

    private void cboBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboBudgetActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboBudgetActionPerformed

    private void chargerLexiqueBudget() {

        Organisation org = (Organisation) cboOrganisationID.getSelectedItem();
        if (org != null) {
            Exercice e = (Exercice) cboMillesime.getSelectedItem();
            if (e != null) {
                try {
                    pbl = GrecoServiceFactory.getExerciceService().budgetLexiqueFind(org.getOrganisationID(), e.getMillesime());
                } catch (GrecoException ex) {
                    pbl = null;
                    ManageException.show(ex, Locale.getDefault());
                }
                if (pbl == null) {
                    pbl = new PrepaBudgetLexique();
                    pbl.setOrganisationID(org.getOrganisationID());
                    pbl.setMillesime(e.getMillesime());
                    pbl.setLexiqueFr("");
                    pbl.setLexiqueUs("");
                }
                SwingUtilities.invokeLater(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            BudgetLexiqueDialog dialog = new BudgetLexiqueDialog(null, true, pbl);
                            dialog.setVisible(true);
                        } catch (Exception e) {
                        }
                    }
                });
            } else {
                GrecoOptionPane.showErrorDialog("Aucun millesime sélectionné");
            }
        } else {
            GrecoOptionPane.showErrorDialog("Aucun organisme sélectionné");

        }
    }

    private void fermer() {
        // TODO add your handling code here:
        this.dispose();
    }

    private boolean controlData() {
        boolean res = true;
        Organisation o = (Organisation) cboOrganisationID.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez s?lectionner  l'organisme");
            return false;
        }
        Exercice m = (Exercice) cboMillesime.getSelectedItem();
        if (m == null) {
            GrecoOptionPane.showWarningDialog("Veuillez selectionner  un exercice budgetaire");
            return false;
        }

        if (txtLibelleFr.getText().isEmpty()) {
            GrecoOptionPane.showWarningDialog("Saisir la description du budget ");
            return false;
        }

        if (!rdbInitial.isSelected() && !rdbAdditif.isSelected() && !rdbReport.isSelected()  && !rdbCollectif.isSelected()) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir le type de budget");
            return false;
        }
        if (this.mode == MODE_VALIDATION_PRIMATURE) {
            if (txtReference.getText().isEmpty() && chkPrimature.isSelected()) {
                GrecoOptionPane.showWarningDialog("Saisir la reference de l'acte du PM qui autorise l'ouverture des credits relatifs a ce budget  ");
                return false;
            }
        }
        
        if(typeBudget == BudgetType.COLLECTIF){
            PrepaBudget p = (PrepaBudget) cboBudget.getSelectedItem();
            if(p == null){
                GrecoOptionPane.showErrorDialog("Vous voulez creer un collectif budgetaire... Veuillez specifier le budget initial");
                return false;
            }
        }

        return res;
    }

    private void remplirPrepaBudget() {
        Exercice m = (Exercice) cboMillesime.getSelectedItem();
        if (m == null) {
            pb.setMillesime(null);
        } else {
            pb.setMillesime(m.getMillesime());
        }
        Organisation o = (Organisation) cboOrganisationID.getSelectedItem();
        if (o == null) {
            pb.setOrganisationID(null);
        } else {
            pb.setOrganisationID(o.getOrganisationID());
        }
        pb.setLibelleFr(txtLibelleFr.getText().trim());
        pb.setLibelleUs(txtLibelleUs.getText().trim());
        int type = 0;
        if (rdbInitial.isSelected()) {
            type = BudgetType.INITIAL;
        } else if (rdbAdditif.isSelected()) {
            type = BudgetType.ADDITIF;
        } else if (rdbReport.isSelected()) {
            type = BudgetType.REPORT;
        } else if (rdbCollectif.isSelected()) {
            type = BudgetType.COLLECTIF;
        }
        pb.setType(type);
        pb.setReference(txtReference.getText().trim());
        String etat = "1" + (chkMinisterielle.isSelected() ? "1" : "0") + (chkPrimature.isSelected() ? "1" : "0");
        pb.setEtat(etat);
        pb.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        pb.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        pb.setNotePresentationFr(txtNotePresentation.getText());
        
        PrepaBudget p = null;
        try {
            p = (PrepaBudget) cboBudget.getSelectedItem();
        } catch (Exception e) {
        }
        pb.setBudgetCollectifInitial(p==null?null:p.getBudgetID());
        
        
    }

    private void enregistrer() {
        if (controlData()) {
            glasspane.setText("enregistrement  ....");
            glasspane.attente();
            if (pb == null) {
                pb = new PrepaBudget();
                remplirPrepaBudget();

                try {
                    GrecoServiceFactory.getExerciceService().budgetAjouter(pb);
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("enregistr? avec succ?s");
                    glasspane.arret();
                } catch (GrecoException ex) {
                    glasspane.arret();
                    pb = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                    return;
                } catch (Exception e) {
                    glasspane.arret();
                    e.printStackTrace();
                    pb = null;
                    GrecoSession.notifications.echec();
                    GrecoOptionPane.showErrorDialog("ECHEC DE L'ENREGISTREMENT \n\n");
                    return;
                }
            } else {
                remplirPrepaBudget();
                try {
                    GrecoServiceFactory.getExerciceService().budgetModifier(pb);
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("modifi? avec succ?s ");
                    glasspane.arret();
                } catch (Exception e) {
                    glasspane.arret();
                    GrecoSession.notifications.echec();
                    return;
                }
            }
            initUI();
            glasspane.arret();
        }
    }

    private void supprimer() {
        // TODO add your handling code here:
        if (pb != null) {
            int reponse = GrecoOptionPane.showConfirmDialog("Voulez-vous supprimer ?");
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    reponse = GrecoOptionPane.showConfirmDialog("Attention !!! \n\n Toutes les opérations budgétisées vont etre supprimées. Etes-vous sûr de vouloir toujours supprimer ce budget ? ?");
                    if (reponse == JOptionPane.YES_OPTION) {
                        GrecoServiceFactory.getExerciceService().budgetSupprimer(GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP, pb.getBudgetID());
                        GrecoSession.notifications.success();
                        GrecoOptionPane.showSuccessDialog("Budget supprimé avec succès ");
                        this.dispose();
                    }
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BudgetDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BudgetDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BudgetDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BudgetDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                BudgetDialog dialog = new BudgetDialog(new javax.swing.JFrame(), true, null, 0, null, null);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnFermer;
    private cm.eusoworks.tools.ui.GButton btnNotePresentation;
    private cm.eusoworks.tools.ui.GButton btnNotePresentation1;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox cboBudget;
    private javax.swing.JComboBox cboMillesime;
    private javax.swing.JComboBox cboOrganisationID;
    private javax.swing.JCheckBox chkMinisterielle;
    private javax.swing.JCheckBox chkPrimature;
    private javax.swing.JCheckBox chkSaisie;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblBudgetInitial;
    private org.jdesktop.swingx.JXHyperlink lnkLexique;
    private javax.swing.JPanel pCentre;
    private javax.swing.JPanel pSouth;
    private javax.swing.JPanel panelContents;
    private javax.swing.JPanel panelInfos;
    private javax.swing.JRadioButton rdbAdditif;
    private javax.swing.JRadioButton rdbCollectif;
    private javax.swing.JRadioButton rdbInitial;
    private javax.swing.JRadioButton rdbReport;
    private javax.swing.JTextField txtLibelleFr;
    private javax.swing.JTextField txtLibelleUs;
    private javax.swing.JEditorPane txtNotePresentation;
    private javax.swing.JTextField txtReference;
    private javax.swing.JFormattedTextField txtVolumeAE;
    private javax.swing.JFormattedTextField txtVolumeCP;
    // End of variables declaration//GEN-END:variables
}
