/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.ActiviteNiveau;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PrepaActivite;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VuePTAOperation;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.renderer.BooleanTableRenderer;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.resources.images.GrecoImages;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTree;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.ExpandVetoException;
import javax.swing.tree.TreePath;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;
import org.jdesktop.swingx.JXTreeTable;
import org.jdesktop.swingx.decorator.HighlighterFactory;
import org.jdesktop.swingx.treetable.DefaultTreeTableModel;
import org.jdesktop.swingx.treetable.MutableTreeTableNode;

/**
 *
 * @author macbookair
 */
public class PrepaPTATransfertExecutionDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private Localite locality;
    private Categorie category;
    private Fonction fonction;

    private Organisation currentOrganisation = null;
    private Exercice currentExercice = null;
    private int currentNiveau = 1;

    List<ActiviteNiveau> listNiveaux;
    TreePath path;
    TreePath pathParent;

    List<PrepaBudget> listBudget = ObservableCollections.observableList(new ArrayList<PrepaBudget>());
    PrepaBudget selectedBudget;

    GrecoImages images = new GrecoImages();
    Color activityColor = new Color(0, 147, 0);

    public PrepaPTATransfertExecutionDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        loadOrganisations();
        loadExercicesBudgetisation();
        loadNiveauActivite();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Transfert du Plan de Travail en execution  ");
//        setPreferredSize(new Dimension(955, 620));

        btnSuivant.setVisible(false);
        pack();
    }

    private void loadNiveauActivite() {
        try {
            listNiveaux = GrecoServiceFactory.getNiveauService().listeNiveauActivite();
        } catch (Exception e) {
        }
    }

    private String getLibelleNiveau(int n) {
        String libelle = "";
        for (ActiviteNiveau a : listNiveaux) {
            if (a.getNiveauActiviteID() == n) {
                libelle = a.getLibelle(Locale.getDefault());
                break;
            }
        }
        return libelle;
    }

    private void initTree() {
        treeTable.setTreeTableModel(getRoot());

        JTableHeader header = treeTable.getTableHeader();
        header.getColumnModel().getColumn(0).setPreferredWidth(70);
        header.getColumnModel().getColumn(0).setResizable(false);
        header.getColumnModel().getColumn(1).setMinWidth(0);
        header.getColumnModel().getColumn(1).setPreferredWidth(400);
        header.getColumnModel().getColumn(2).setPreferredWidth(45);
        header.getColumnModel().getColumn(2).setResizable(false);
        header.getColumnModel().getColumn(3).setPreferredWidth(100);
        header.getColumnModel().getColumn(3).setResizable(false);
        header.getColumnModel().getColumn(4).setPreferredWidth(100);
        header.getColumnModel().getColumn(4).setResizable(false);
        header.getColumnModel().getColumn(5).setPreferredWidth(20);
        header.getColumnModel().getColumn(5).setResizable(false);
        header.getColumnModel().getColumn(6).setPreferredWidth(40);
        header.getColumnModel().getColumn(6).setResizable(false);

        ActiviteTableCellRenderer cellRender = new ActiviteTableCellRenderer(treeTable);
        header.getColumnModel().getColumn(0).setCellRenderer(cellRender);
        header.getColumnModel().getColumn(1).setCellRenderer(cellRender);
        header.getColumnModel().getColumn(3).setCellRenderer(cellRender);
        header.getColumnModel().getColumn(4).setCellRenderer(cellRender);
        treeTable.setRowHeight(25);
        treeTable.setTreeCellRenderer(new ActiviteTreeCellRenderer());
        treeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        treeTable.setHighlighters(HighlighterFactory.createAlternateStriping(new Color(250, 250, 251),
                new Color(255, 255, 255)));
        treeTable.setSelectionBackground(new Color(208, 217, 230));

        treeTable.setSelectionForeground(new Color(105, 128, 151));
        treeTable.setOpaque(true);
        treeTable.setBackground(Color.white);
        treeTable.setGridColor(new Color(246, 246, 246));
        treeTable.setShowGrid(true, true);
        treeTable.setShowsRootHandles(true);

        treeTable.expandAll();

    }

    private DefaultTreeTableModel getRoot() {

        MyMutableTreeTableNode aRoot = null;
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        aRoot = getActiviteRootsNode(o);

        ActiviteTreeTableModel model = new ActiviteTreeTableModel(aRoot);
        return model;
    }

    private MyMutableTreeTableNode getActiviteRootsNode(Organisation org) {
        MyMutableTreeTableNode node = new MyMutableTreeTableNode(new PrepaActivite());
        List<PrepaActivite> l = null;
        Exercice ex = (Exercice) cboExercice.getSelectedItem();
        l = GrecoServiceFactory.getActiviteService().prepaGetListActiviteRootsByBudget(org.getOrganisationID(), ex.getMillesime(), selectedBudget.getBudgetID());
        ActiviteNiveau n = GrecoServiceFactory.getNiveauService().getNiveauActivite(1);

        if (l == null || l.isEmpty()) {
            try {

            } catch (Exception e) {

            }

        } else {
            for (PrepaActivite a : l) {
                MyMutableTreeTableNode aPG = new MyMutableTreeTableNode(a);
                if (a.haschilds()) {
                    aPG.add(new MyMutableTreeTableNode(new PrepaActivite()));
                }
                node.add(aPG);
            }
        }

        return node;
    }

    public List<PrepaBudget> getListBudget() {
        return listBudget;
    }

    public void setListBudget(List<PrepaBudget> listBudget) {
        this.listBudget = listBudget;
    }

    public PrepaBudget getSelectedBudget() {
        return selectedBudget;
    }

    public void setSelectedBudget(PrepaBudget selectedBudget) {
        this.selectedBudget = selectedBudget;
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        pAccueil = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        btnSuivant = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        pPTA = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        treeTable = new org.jdesktop.swingx.JXTreeTable();
        jPanel2 = new javax.swing.JPanel();
        btnChoixBudget = new cm.eusoworks.tools.ui.GButton();
        btnTransfert = new cm.eusoworks.tools.ui.GButton();
        pFin = new javax.swing.JPanel();
        jLabel43 = new javax.swing.JLabel();
        jLabel44 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        pAccueil.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme/Administration  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        btnSuivant.setText("Continuer");
        btnSuivant.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSuivantActionPerformed(evt);
            }
        });

        jTable1.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jTable1.setRowHeight(28);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listBudget}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, jTable1);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelleFr}"));
        columnBinding.setColumnName("BUDGET");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${volumeAE}"));
        columnBinding.setColumnName("AE");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${volumeCP}"));
        columnBinding.setColumnName("CP");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${saisie}"));
        columnBinding.setColumnName("Saisie");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${valideMinistere}"));
        columnBinding.setColumnName("Visa Odo");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${validePM}"));
        columnBinding.setColumnName("Visa PM");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedBudget}"), jTable1, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(300);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(40);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(40);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(20);
            jTable1.getColumnModel().getColumn(3).setCellRenderer(new BooleanTableRenderer());
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setPreferredWidth(20);
            jTable1.getColumnModel().getColumn(4).setCellRenderer(new BooleanTableRenderer());
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setPreferredWidth(20);
            jTable1.getColumnModel().getColumn(5).setCellRenderer(new BooleanTableRenderer());
        }

        javax.swing.GroupLayout pAccueilLayout = new javax.swing.GroupLayout(pAccueil);
        pAccueil.setLayout(pAccueilLayout);
        pAccueilLayout.setHorizontalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pAccueilLayout.createSequentialGroup()
                                .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(10, 10, 10)
                                .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(pAccueilLayout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 746, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(385, 385, 385)
                        .addComponent(btnSuivant, javax.swing.GroupLayout.PREFERRED_SIZE, 211, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(125, 125, 125))
        );
        pAccueilLayout.setVerticalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(43, 43, 43)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 197, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(btnSuivant, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(55, Short.MAX_VALUE))
        );

        getContentPane().add(pAccueil, "accueil");

        pPTA.setLayout(new java.awt.BorderLayout());

        treeTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                treeTableMouseReleased(evt);
            }
        });
        treeTable.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                treeTableTreeWillExpand(evt);
            }
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
        });
        treeTable.addTreeSelectionListener(new javax.swing.event.TreeSelectionListener() {
            public void valueChanged(javax.swing.event.TreeSelectionEvent evt) {
                treeTableValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(treeTable);

        pPTA.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel2.setBackground(new java.awt.Color(252, 252, 252));
        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 50, 5));

        btnChoixBudget.setText("<<<  Choix du budget");
        btnChoixBudget.setStyle(5);
        btnChoixBudget.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnChoixBudgetActionPerformed(evt);
            }
        });
        jPanel2.add(btnChoixBudget);

        btnTransfert.setText("Transferer le budget en execution >>>");
        btnTransfert.setStyle(5);
        btnTransfert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTransfertActionPerformed(evt);
            }
        });
        jPanel2.add(btnTransfert);

        pPTA.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pPTA, "pta");

        pFin.setBackground(new java.awt.Color(255, 255, 255));

        jLabel43.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        jLabel43.setText("Transferer en execution avec success");

        jLabel44.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/msg_success.png"))); // NOI18N

        javax.swing.GroupLayout pFinLayout = new javax.swing.GroupLayout(pFin);
        pFin.setLayout(pFinLayout);
        pFinLayout.setHorizontalGroup(
            pFinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFinLayout.createSequentialGroup()
                .addGroup(pFinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pFinLayout.createSequentialGroup()
                        .addGap(190, 190, 190)
                        .addComponent(jLabel43))
                    .addGroup(pFinLayout.createSequentialGroup()
                        .addGap(387, 387, 387)
                        .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(371, Short.MAX_VALUE))
        );
        pFinLayout.setVerticalGroup(
            pFinLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFinLayout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addComponent(jLabel43)
                .addGap(30, 30, 30)
                .addComponent(jLabel44, javax.swing.GroupLayout.PREFERRED_SIZE, 76, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(234, Short.MAX_VALUE))
        );

        getContentPane().add(pFin, "fin");

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnSuivantActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSuivantActionPerformed
        // TODO add your handling code here:
        if (selectedBudget == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir le type de budget à transferer");
            return;
        }
        String msg = "";
        if (!selectedBudget.isValidePM()) {
            msg = "Vous ne pouvez pas transferer en execution un budget qui n'a pas ete valide en machine. ";
            GrecoOptionPane.showErrorDialog(msg);
            return;
        }
        int res = GrecoOptionPane.showConfirmDialog("Vous avez choisi de transferer en execution le budget :" + selectedBudget.getLibelleFr() + " ?");
        if (res == JOptionPane.NO_OPTION) {
            return;
        }
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'organisme");
            return;
        }
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e == null) {
            GrecoOptionPane.showWarningDialog("Veuillez sélectionner l'exercice budgétaire");
            return;
        }
        // si budget collectif, basculer drectement sans afficher l'arbre 
        if (selectedBudget.getType() == BudgetType.COLLECTIF) {
            int ress = GrecoOptionPane.showConfirmDialog("Le Collectif Budgetaire va etre mis en execution instantanement. Continuer ? ");
            if (ress == JOptionPane.NO_OPTION) {
                return;
            }
            int exex = GrecoServiceFactory.getOperationService().prepaCollectifEnExecution(selectedBudget.getBudgetCollectifInitial(), selectedBudget.getBudgetID(), GrecoSession.USER_CONNECTED.getUserUpdate());
            if(exex != 1){
                GrecoOptionPane.showWarningDialog("Execute avec erreurs. Verifier que le Collectif budgetaire est pris en compte SVP");
            }
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "fin");
        } else {
            currentOrganisation = o;
            currentExercice = e;
            this.setTitle(selectedBudget.getLibelleFr() + " - Transfert en execution  ");
            initTree();

            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "pta");
        }

    }//GEN-LAST:event_btnSuivantActionPerformed


    private void treeTableValueChanged(javax.swing.event.TreeSelectionEvent evt) {//GEN-FIRST:event_treeTableValueChanged
        // TODO add your handling code here:

        path = evt.getNewLeadSelectionPath();
        if (path != null) {
            Object o = path.getLastPathComponent();
            if (o instanceof MyMutableTreeTableNode) {
                Object a = ((MyMutableTreeTableNode) o).getUserObject();
                if (a instanceof PrepaActivite) {
                    PrepaActivite parent = (PrepaActivite) a;
                    int n = parent.getNiveauActiviteID().intValue();

                } else if (a instanceof PrepaOperationBudgetaire) {

                }
            }
        }
    }//GEN-LAST:event_treeTableValueChanged

    private void treeTableTreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_treeTableTreeWillExpand
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Object o = evt.getPath().getLastPathComponent();
        try {
            if (o instanceof MyMutableTreeTableNode) {
                MyMutableTreeTableNode tree = (MyMutableTreeTableNode) o;
                Object ob = tree.getUserObject();
                if (ob instanceof PrepaActivite) {
                    PrepaActivite act = (PrepaActivite) ob;
                    List<PrepaActivite> list = new ArrayList<>();
                    tree.removeAll();
                    if (act.getNiveauActiviteID() < GrecoSession.optionNiveau.getAt() - 1) {
                        // liste des activites filles
                        list = GrecoServiceFactory.getActiviteService().prepaGetListActiviteChildsByBudget(act.getActiviteID(), selectedBudget.getBudgetID());
                        if (list != null) {
                            for (PrepaActivite v : list) {
                                MyMutableTreeTableNode nodeTree = new MyMutableTreeTableNode(v);
                                if (v.haschilds()) {
                                    nodeTree.add(new MyMutableTreeTableNode(new PrepaActivite()));
                                }
                                tree.add(nodeTree);
                            }
                        }

                    } else if (act.getNiveauActiviteID() == (GrecoSession.optionNiveau.getAt() - 1)) {
                        // liste des activites filles
                        list = GrecoServiceFactory.getActiviteService().prepaGetListActiviteChildsAndOperationCountByBudget(act.getActiviteID(), selectedBudget.getBudgetID());
                        if (list != null) {
                            for (PrepaActivite v : list) {
                                MyMutableTreeTableNode nodeTree = new MyMutableTreeTableNode(v);
                                if (v.haschilds()) {
                                    nodeTree.add(new MyMutableTreeTableNode(new PrepaActivite()));
                                }
                                tree.add(nodeTree);
                            }
                        }

                    } else {
                        // liste des operations budgetaires
                        List<PrepaOperationBudgetaire> listOper = new ArrayList<>();
                        listOper = GrecoServiceFactory.getOperationService().prepaGetListOperationByActivite(act.getActiviteID(), selectedBudget.getBudgetID());
                        BigDecimal sommeAE = BigDecimal.ZERO;
                        BigDecimal sommeCP = BigDecimal.ZERO;
                        if (listOper != null) {
                            for (PrepaOperationBudgetaire v : listOper) {
                                MyMutableTreeTableNode nodeTree = new MyMutableTreeTableNode(v);
                                tree.add(nodeTree);
                                sommeAE = sommeAE.add(v.getAe());
                                sommeCP = sommeCP.add(v.getCp());
                            }
                        }

                        ((PrepaActivite) tree.getUserObject()).setAe(sommeAE);
                        ((PrepaActivite) tree.getUserObject()).setCp(sommeCP);
//                        majTotaux(tree);
                    }

                }
            }
        } catch (Exception e) {
            setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }//GEN-LAST:event_treeTableTreeWillExpand

    private void treeTableMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeTableMouseReleased
        // TODO add your handling code here:
        // on selectionne dabord
        int lg = treeTable.rowAtPoint(evt.getPoint());
        treeTable.getSelectionModel().setSelectionInterval(lg, lg);
        pathParent = treeTable.getTreeSelectionModel().getSelectionPath().getParentPath();
        if (pathParent != null) {
            if (evt.getClickCount() == 2) {
//                if (path != null) {
//                    Object o = path.getLastPathComponent();
//                    if (o instanceof MyMutableTreeTableNode) {
//                        Object a = ((MyMutableTreeTableNode) o).getUserObject();
//                        if (a instanceof PrepaActivite) {
//                            PrepaActivite act = (PrepaActivite) a;
//                            PrepaActiviteDialog actDialog = new PrepaActiviteDialog(this, true, act, currentOrganisation.getOrganisationID(),
//                                    currentExercice.getMillesime(), act.getNiveauActiviteID().intValue(), null);
//                            actDialog.setVisible(true);
//                        } else if (a instanceof PrepaOperationBudgetaire) {
//                            Object p = pathParent.getLastPathComponent();
//                            if (p instanceof MyMutableTreeTableNode) {
//                                Object t = ((MyMutableTreeTableNode) p).getUserObject();
//                                if (t instanceof PrepaActivite) {
//                                    PrepaActivite tache = (PrepaActivite) t;
//                                    PrepaOperationDialog op = new PrepaOperationDialog(null, true, tache, (PrepaOperationBudgetaire) a, selectedBudget);
//                                    op.setVisible(true);
//                                    op.dispose();
//                                    // majTotaux((MyMutableTreeTableNode) p); 
//                                }
//                            }
//                        }
//                    }
//                }
            }
        }

    }//GEN-LAST:event_treeTableMouseReleased

    private void majTotaux(MyMutableTreeTableNode p) {
//        MyMutableTreeTableNode node = p;
        double sommeAE = 0;
        double sommeCP = 0;
        if (p.getChildCount() > 0) {
            MyMutableTreeTableNode n;
            Object o;
            for (int i = 0; i < p.getChildCount(); i++) {
                n = (MyMutableTreeTableNode) p.getChildAt(i);
                o = n.getUserObject();
                if (o instanceof PrepaOperationBudgetaire) {
                    PrepaOperationBudgetaire op = (PrepaOperationBudgetaire) o;
                    sommeAE += op.getAe().doubleValue();
                    sommeCP += op.getCp().doubleValue();
                }
            }
            //mise a jour du noeud
            PrepaActivite a = (PrepaActivite) p.getUserObject();
            a.setAe(BigDecimal.valueOf(sommeAE));
            a.setCp(BigDecimal.valueOf(sommeCP));

//            TreePath par = path.getParentPath();
//            ((ActiviteTreeTableModel) treeTable.getTreeTableModel()).valueForPathChanged(par, a);
            ((ActiviteTreeTableModel) treeTable.getTreeTableModel()).valueForPathChanged(path, a);

            treeTable.collapsePath(path);
            treeTable.expandPath(path);

        }
    }

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        loadBudget();
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        if (selectedBudget != null) {
            btnSuivant.setVisible(true);
        } else {
            btnSuivant.setVisible(false);
        }
        if (evt.getClickCount() == 2) {
            btnSuivantActionPerformed(null);
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void btnChoixBudgetActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnChoixBudgetActionPerformed
        // TODO add your handling code here:
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "accueil");
//        apercu();
    }//GEN-LAST:event_btnChoixBudgetActionPerformed

    private void btnTransfertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTransfertActionPerformed
        // TODO add your handling code here:
        int res = GrecoOptionPane.showConfirmDialog("Etes-vous sur de vouloir transferer ce budget en execution ?\n " + selectedBudget.getLibelleFr());
        if (res == JOptionPane.YES_OPTION) {
            glasspane.attente();
            try {
                Exercice e = (Exercice) cboExercice.getSelectedItem();
                if (e != null) {
                    GrecoServiceFactory.getExerciceService().budgetTransfererEnExecution(e.getMillesime(), selectedBudget.getBudgetID());
                    GrecoSession.notifications.success();

                    glasspane.arret();

                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "fin");
                } else {
                    GrecoOptionPane.showWarningDialog("Veuilez selectionner l'exercice ");
                }

            } catch (GrecoException e) {
                glasspane.arret();
                GrecoSession.notifications.echec();
                ManageException.show(e, Locale.getDefault());
            }
        }
        glasspane.arret();
    }//GEN-LAST:event_btnTransfertActionPerformed

    private void apercu() {
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        GrecoReports fonctions = new GrecoReports();
        Image armoirieCM = null;//new siiResources.Images();
        HashMap parameters = fonctions.mainParameters();
        parameters.put("chapitreFR", currentOrganisation.getLibelleFr());
        parameters.put("chapitreEN", currentOrganisation.getLibelleUs());
        parameters.put("armoirieCM", armoirieCM);

        List<VuePTAOperation> oper = new ArrayList<>();
        try {
            oper = GrecoServiceFactory.getReportService().getPTAOperation(currentOrganisation.getOrganisationID(),
                    currentExercice.getMillesime());
        } catch (Exception e) {
            e.printStackTrace();
        }

        JRDataSource dataSource = new JRBeanCollectionDataSource(oper);
        try {
            JasperPrint print = JasperFillManager.fillReport(fonctions.ptaOperation(), parameters, dataSource);
            JRHelper.viewReport(print);
        } catch (Exception e) {
            e.printStackTrace();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));
    }

    private void loadBudget() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            listBudget.clear();
            Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e != null) {
                List<PrepaBudget> list = GrecoServiceFactory.getExerciceService().budgetGetByMillesimeOnLine(o.getOrganisationID(),
                        e.getMillesime(), false);
                if (list != null && !list.isEmpty()) {
                    for (PrepaBudget p : list) {
                        listBudget.add(p);
                    }
                }
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrepaPTATransfertExecutionDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrepaPTATransfertExecutionDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrepaPTATransfertExecutionDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrepaPTATransfertExecutionDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PrepaPTATransfertExecutionDialog dialog = new PrepaPTATransfertExecutionDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnChoixBudget;
    private javax.swing.JButton btnSuivant;
    private cm.eusoworks.tools.ui.GButton btnTransfert;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel43;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTable jTable1;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pFin;
    private javax.swing.JPanel pPTA;
    private org.jdesktop.swingx.JXTreeTable treeTable;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

    class ActiviteTreeTableModel extends DefaultTreeTableModel {

        private static final int N = 0;
        private static final int DESIGNATION = 1;
        private static final int IMPUT = 2;
        private static final int AE = 3;
        private static final int CP = 4;
        private static final int SOURCEFINANCEMENT = 5;
        private static final int STRUCTURE = 6;

        public ActiviteTreeTableModel(MyMutableTreeTableNode root) {
            super(root);
        }

        @Override
        public void insertNodeInto(MutableTreeTableNode newChild, MutableTreeTableNode parent, int index) {
            super.insertNodeInto(newChild, parent, index); //To change body of generated methods, choose Tools | Templates.

        }

        @Override
        public void removeNodeFromParent(MutableTreeTableNode node) {
            MutableTreeTableNode parent = (MutableTreeTableNode) node.getParent();
            if (parent != null) {
//                parent.remove(node);
                try {
                    super.removeNodeFromParent(node);
                } catch (Exception e) {
                }

            } else {
                ((MutableTreeTableNode) getRoot()).remove(node);
            }

        }

        @Override
        public void valueForPathChanged(TreePath path, Object newValue) {
            super.valueForPathChanged(path, newValue); //To change body of generated methods, choose Tools | Templates.
        }

        public void updateInserted(TreePath pathchanged) {
            modelSupport.firePathChanged(pathchanged);
        }

        @Override
        public boolean isCellEditable(Object node, int column) {
            return false;
        }

        @Override
        public String getColumnName(int column) {
            String res = "";
            switch (column) {
                case N:
                    res = "N°";
                    break;
                case DESIGNATION:
                    res = "Désignation";
                    break;
                case IMPUT:
                    res = "Paragraphe";
                    break;
                case AE:
                    res = "AE";
                    break;
                case CP:
                    res = "CP";
                    break;
                case SOURCEFINANCEMENT:
                    res = "Fin.";
                    break;
                case STRUCTURE:
                    res = "Structure";
                    break;
            }
            return res;
        }

        @Override
        public int getColumnCount() {
            return 7;
        }

        @Override
        public Object getValueAt(Object node, int column) {
            Object res = "";
            if (node instanceof MyMutableTreeTableNode) {
                MyMutableTreeTableNode defNode = (MyMutableTreeTableNode) node;
                if (defNode.getUserObject() instanceof PrepaActivite) {
                    PrepaActivite a = (PrepaActivite) defNode.getUserObject();
                    switch (column) {
                        case N:
                            break;
                        case DESIGNATION:
                            res = a.getNiveauActiviteID() + getEspaceActivite(a) + a.getCode() + " - " + a.getLibelle();
                            break;
                        case IMPUT:
                            res = "";
                            break;
                        case AE:
                            res = a.getAe();
                            break;
                        case CP:
                            res = a.getCp();
                            break;
                        case SOURCEFINANCEMENT:
                            res = "";
                            break;
                        case STRUCTURE:
                            res = "";
                            break;
                    }
                } else if (defNode.getUserObject() instanceof PrepaOperationBudgetaire) {
                    PrepaOperationBudgetaire o = (PrepaOperationBudgetaire) defNode.getUserObject();
                    switch (column) {
                        case N:

                            break;
                        case DESIGNATION:
                            res = "9" + getEspaceOperation() + o.getLibelle();
                            break;
                        case IMPUT:
                            res = o.getCompteCode(); // + " - " + o.getCompteLibelle();
                            break;
                        case AE:
                            res = o.getAe();
                            break;
                        case CP:
                            res = o.getCp();
                            break;
                        case SOURCEFINANCEMENT:
                            res = o.getFinancementAbbreviation();
                            break;
                        case STRUCTURE:
                            res = o.getStructureAbbreviation();
                            break;
                    }
                }
            }
            return res;
        }

        private String getEspaceActivite(PrepaActivite a) {
            String esc = "";
            for (int i = 0; i < a.getNiveauActiviteID(); i++) {
                esc = esc + "  ";
            }
            return esc;
        }

        private String getEspaceOperation() {
            String esc = "";
            for (int i = 0; i < GrecoSession.optionNiveau.getAt(); i++) {
                esc = esc + "  ";
            }
            esc = esc + "   ";
            return esc;
        }

    }

    class ActiviteTreeCellRenderer extends DefaultTreeCellRenderer {

        public ActiviteTreeCellRenderer() {
        }

        @Override
        public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus) {

            if (value instanceof MyMutableTreeTableNode) {
                MyMutableTreeTableNode node = (MyMutableTreeTableNode) value;
                Object o = node.getUserObject();
                if (o instanceof PrepaActivite) {
                    PrepaActivite a;
                    a = (PrepaActivite) o;
                    if (null != a.getNiveauActiviteID()) {
                        switch (a.getNiveauActiviteID()) {
                            case 1:
                                setIcon(images.ptaProgramme());
                                break;
                            case 2:
                                setIcon(images.ptaSousProgramme());
                                break;
                            case 3:
                                setIcon(images.ptaActivite());
                                break;
                            default:
                                break;
                        }
                    }
                } else if (o instanceof PrepaOperationBudgetaire) {
                    PrepaOperationBudgetaire op;
                    op = (PrepaOperationBudgetaire) o;
                    String b = op.getBudgetExploite();
                    if (b != null && !b.isEmpty()) {
                        if (b.equals(BudgetType.ETAT_REPORT)) {
                            setIcon(images.ptaParaReport());
                        } else if (b.equals(BudgetType.ETAT_INITIAL)) {
                            setIcon(images.ptaParaInitial());
                        } else if (b.equals(BudgetType.ETAT_ADDITIF)) {
                            setIcon(images.ptaParaAdditif());
                        } else if (b.equals(BudgetType.ETAT_INITIAL_ADDITIF)) {
                            setIcon(images.ptaParaInitAdditif());
                        } else if (b.equals(BudgetType.ETAT_ALL_BUDGET)) {
                            setIcon(images.ptaParaAllBudget());
                        }
                    } else {
                        setIcon(images.ptaParaInitial());
                    }
                }

            }

            return this;
        }
    }

    class ActiviteTableCellRenderer extends DefaultTableCellRenderer {

        JXTreeTable treetb;

        public ActiviteTableCellRenderer(JXTreeTable treettable) {
            this.treetb = treettable;
        }

        @Override
        public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {

            setOpaque(true);
            setBackground(isSelected ? treetb.getSelectionBackground() : treetb.getBackground());
            this.setForeground(isSelected ? treetb.getSelectionForeground() : treetb.getForeground());

            if (column == 1) {
                setHorizontalAlignment(LEFT);
                String val = (String) value;
                int niveau = 0;
                try {
                    niveau = Integer.valueOf(val.substring(0, 1));
                } catch (Exception e) {
                }

                switch (niveau) {
                    case 1:
                    case 2:
                        setFont(new Font("Arial", Font.BOLD, 12));
                        setText(val.substring(1).toUpperCase());
                        //setForeground(isSelected ? treetb.getSelectionForeground() : treetb.getForeground());
                        break;
                    case 3:
                        setFont(new Font("Arial", Font.PLAIN, 14));
                        setText(val.substring(1));
                        //setForeground(Color.GREEN);
                        break;
                    case 9:
                        setFont(new Font("Courrier", Font.ITALIC, 13));
                        setText(val.substring(1));
                        break;
                    default:
                        break;
                }
            } else if (column == 3 || column == 4) {
                setHorizontalAlignment(RIGHT);
                if (value instanceof String) {
                    String v = (String) value;
                    if (v.isEmpty()) {
                        setText("");
                    } else {
                        double nb = Double.valueOf(v);
                        DecimalFormat d = new DecimalFormat("#,##0");
                        setText(d.format(nb));
//                        setFont(new Font("Arial", Font.BOLD, 11));
                    }
                } else if (value instanceof BigDecimal) {
                    BigDecimal v = (BigDecimal) value;
                    DecimalFormat d = new DecimalFormat("#,##0");
                    setText(d.format(v.doubleValue()));
//                   setFont(new Font("Arial", Font.BOLD, 11));
                }
            }
            return this;

        }
    }
}
