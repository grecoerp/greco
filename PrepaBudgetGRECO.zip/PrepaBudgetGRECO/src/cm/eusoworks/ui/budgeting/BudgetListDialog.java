/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.ActiviteNiveau;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.model.OperationBudgetaire;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.renderer.BooleanTableRenderer;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import com.siicore.util.DateUtils;
import java.awt.AlphaComposite;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import javax.swing.tree.TreePath;
import org.jdesktop.observablecollections.ObservableCollections;
import org.jdesktop.swingx.treetable.DefaultTreeTableModel;

/**
 *
 * @author macbookair
 */
public class BudgetListDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private Localite locality;
    private Categorie category;
    private Fonction fonction;

    private Organisation currentOrganisation = null;
    private Exercice currentExercice = null;
    private int currentNiveau = 1;

    List<ActiviteNiveau> listNiveaux;
    TreePath path;
    TreePath pathParent;

    List<PrepaBudget> listBudget = ObservableCollections.observableList(new ArrayList<PrepaBudget>());
    PrepaBudget selectedBudget;

    BBPanel panelBudgetType;

    public static int MODE_NOUVEAU = 1;
    public static int MODE_VALIDATION_MINISTERIELLE = 2;
    public static int MODE_VALIDATION_PRIMATURE = 3;

    private int modeF;
    int t; // type de budget surlequel on a clique. t = 1, 2, 3 mais les type de budget c'est 0, 1, 2

    public BudgetListDialog(JFrame parent, boolean modal, int mode) {
        super(parent, modal);
        initComponents();
        this.modeF = mode;
        panelBudgetType = new BBPanel();
        getContentPane().add(panelBudgetType, java.awt.BorderLayout.CENTER);
        loadOrganisations();
        loadExercicesBudgetisation();
        loadNiveauActivite();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Gestion des budgets ");

        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseExited(MouseEvent e) {
                super.mouseExited(e); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseEntered(MouseEvent e) {
                super.mouseEntered(e); //To change body of generated methods, choose Tools | Templates.
            }

            @Override
            public void mouseClicked(MouseEvent e) {
                t = panelBudgetType.isClickOnBall(e, 181);
                if (e.getClickCount() == 1) {
                    if (t == 1) {
                        loadBudget(BudgetType.REPORT);
                    } else if (t == 2) {
                        loadBudget(BudgetType.INITIAL);
                    } else if (t == 3) {
                        loadBudget(BudgetType.ADDITIF);
                    } else if (t == 4) {
                        loadBudget(BudgetType.COLLECTIF);
                    }
                } else if (e.getClickCount() == 2) {
                    Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                    Exercice ex = (Exercice) cboExercice.getSelectedItem();
                    if (t == 1) {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    BudgetDialog dialog = new BudgetDialog(null, true, null, BudgetDialog.MODE_NOUVEAU, o, ex, BudgetType.REPORT);
                                    dialog.setVisible(true);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    } else if (t == 2) {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    BudgetDialog dialog = new BudgetDialog(null, true, null, BudgetDialog.MODE_NOUVEAU, o, ex, BudgetType.INITIAL);
                                    dialog.setVisible(true);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    } else if (t == 3) {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    BudgetDialog dialog = new BudgetDialog(null, true, null, BudgetDialog.MODE_NOUVEAU, o, ex, BudgetType.ADDITIF);
                                    dialog.setVisible(true);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    } else if (t == 4) {
                        SwingUtilities.invokeLater(new Runnable() {
                            @Override
                            public void run() {
                                try {
                                    BudgetDialog dialog = new BudgetDialog(null, true, null, BudgetDialog.MODE_NOUVEAU, o, ex, BudgetType.COLLECTIF);
                                    dialog.setVisible(true);
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        });
                    }
                }
            }
        });

        pack();
        setLocationRelativeTo(null);
    }

    private void loadNiveauActivite() {
        try {
            listNiveaux = GrecoServiceFactory.getNiveauService().listeNiveauActivite();
        } catch (Exception e) {
        }
    }

    private String getLibelleNiveau(int n) {
        String libelle = "";
        for (ActiviteNiveau a : listNiveaux) {
            if (a.getNiveauActiviteID() == n) {
                libelle = a.getLibelle(Locale.getDefault());
                break;
            }
        }
        return libelle;
    }

    public List<PrepaBudget> getListBudget() {
        return listBudget;
    }

    public void setListBudget(List<PrepaBudget> listBudget) {
        this.listBudget = listBudget;
    }

    public PrepaBudget getSelectedBudget() {
        return selectedBudget;
    }

    public void setSelectedBudget(PrepaBudget selectedBudget) {
        this.selectedBudget = selectedBudget;
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserOrdonnateurs(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }
        }
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        pAccueil = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        pListeBudget = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jSeparator2 = new javax.swing.JSeparator();
        lblListeBudget = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");

        pAccueil.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme/Administration  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel1.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(102, 153, 255));
        jLabel2.setText("Double-cliquez pour ajouter élaborer un nouveau budget");

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 153, 153));
        jLabel3.setText("Cliquez une fois sur le type de budget de votre choix pour afficher la liste des budgets existants ");

        javax.swing.GroupLayout pAccueilLayout = new javax.swing.GroupLayout(pAccueil);
        pAccueil.setLayout(pAccueilLayout);
        pAccueilLayout.setHorizontalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(33, 33, 33)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pAccueilLayout.createSequentialGroup()
                        .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 893, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 893, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(25, 25, 25))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pAccueilLayout.createSequentialGroup()
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 499, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(285, 285, 285)))
                .addGap(0, 0, Short.MAX_VALUE))
        );
        pAccueilLayout.setVerticalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, 18)
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        getContentPane().add(pAccueil, java.awt.BorderLayout.NORTH);

        pListeBudget.setBackground(new java.awt.Color(255, 255, 255));

        jTable1.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jTable1.setRowHeight(28);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listBudget}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, jTable1);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelleFr}"));
        columnBinding.setColumnName("BUDGET");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${volumeAE}"));
        columnBinding.setColumnName("AE");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${volumeCP}"));
        columnBinding.setColumnName("CP");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${saisie}"));
        columnBinding.setColumnName("Saisie");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${valideMinistere}"));
        columnBinding.setColumnName("Visa Odo");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${validePM}"));
        columnBinding.setColumnName("Visa PM");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedBudget}"), jTable1, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jTable1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jTable1MouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jTable1);
        if (jTable1.getColumnModel().getColumnCount() > 0) {
            jTable1.getColumnModel().getColumn(0).setPreferredWidth(250);
            jTable1.getColumnModel().getColumn(1).setResizable(false);
            jTable1.getColumnModel().getColumn(1).setPreferredWidth(40);
            jTable1.getColumnModel().getColumn(2).setResizable(false);
            jTable1.getColumnModel().getColumn(2).setPreferredWidth(40);
            jTable1.getColumnModel().getColumn(3).setResizable(false);
            jTable1.getColumnModel().getColumn(3).setPreferredWidth(15);
            jTable1.getColumnModel().getColumn(3).setCellRenderer(new BooleanTableRenderer());
            jTable1.getColumnModel().getColumn(4).setResizable(false);
            jTable1.getColumnModel().getColumn(4).setPreferredWidth(15);
            jTable1.getColumnModel().getColumn(4).setCellRenderer(new BooleanTableRenderer());
            jTable1.getColumnModel().getColumn(5).setResizable(false);
            jTable1.getColumnModel().getColumn(5).setPreferredWidth(15);
            jTable1.getColumnModel().getColumn(5).setCellRenderer(new BooleanTableRenderer());
        }

        lblListeBudget.setFont(new java.awt.Font("Lucida Grande", 0, 16)); // NOI18N
        lblListeBudget.setText("      ");

        javax.swing.GroupLayout pListeBudgetLayout = new javax.swing.GroupLayout(pListeBudget);
        pListeBudget.setLayout(pListeBudgetLayout);
        pListeBudgetLayout.setHorizontalGroup(
            pListeBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pListeBudgetLayout.createSequentialGroup()
                .addGroup(pListeBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pListeBudgetLayout.createSequentialGroup()
                        .addGap(170, 170, 170)
                        .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 500, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pListeBudgetLayout.createSequentialGroup()
                        .addGap(127, 127, 127)
                        .addGroup(pListeBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 653, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblListeBudget, javax.swing.GroupLayout.PREFERRED_SIZE, 632, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(171, Short.MAX_VALUE))
        );
        pListeBudgetLayout.setVerticalGroup(
            pListeBudgetLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pListeBudgetLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblListeBudget, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 148, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        getContentPane().add(pListeBudget, java.awt.BorderLayout.SOUTH);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
//        loadBudget();
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            int year = DateUtils.getYear(e.getDateDebut());
            panelBudgetType.setBudgetText("BUDGET REPORT " + (year - 1), "BUDGET INITIAL " + year, "BUDGET ADDITIF " + year, "COLLECTIF BUDGETAIRE ");
        }
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void jTable1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jTable1MouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            if (selectedBudget != null) {
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                Exercice e = (Exercice) cboExercice.getSelectedItem();
                if (e != null) {
                    if (modeF == MODE_NOUVEAU) {
                        if (!selectedBudget.getEtat().equals("100")) {
                            GrecoOptionPane.showSuccessDialog("Ce budget à déjà été validé. Vous ne pouvez plus le supprimer ");
                        } else {
                            SwingUtilities.invokeLater(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        BudgetDialog dialog = new BudgetDialog(null, true, selectedBudget, BudgetDialog.MODE_NOUVEAU, o, e, selectedBudget.getType());
                                        dialog.setVisible(true);
                                        loadBudget(t-1);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                        }
                    } 
                    else if (modeF == MODE_VALIDATION_MINISTERIELLE) {
                        if (selectedBudget.getEtat().equals("111")) {
                            GrecoOptionPane.showSuccessDialog("Ce budget à déjà été validé par la primature");
                        } else {
                            SwingUtilities.invokeLater(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        BudgetDialog dialog = new BudgetDialog(null, true, selectedBudget, BudgetDialog.MODE_VALIDATION_MINISTERIELLE, o, e);
                                        dialog.setVisible(true);
                                        loadBudget(t-1);
                                    } catch (Exception e) {
                                        e.printStackTrace();
                                    }
                                }
                            });
                        }
                    } else if (modeF == MODE_VALIDATION_PRIMATURE) {
                        if (selectedBudget.getEtat().equals("100")) {
                            GrecoOptionPane.showWarningDialog("Ce budget n'a pas encore été validé au niveau ministériel");
                        } else {
                            SwingUtilities.invokeLater(new Runnable() {
                                @Override
                                public void run() {
                                    try {
                                        BudgetDialog dialog = new BudgetDialog(null, true, selectedBudget, BudgetDialog.MODE_VALIDATION_PRIMATURE, o, e);
                                        dialog.setVisible(true);
                                        loadBudget(t-1);
                                    } catch (Exception e) {
                                    }
                                }
                            });
                        }
                    }
                }
                
                
            } else {
                GrecoOptionPane.showWarningDialog("Veuillez sélectionner le budget à modifier SVP");
            }
        }
    }//GEN-LAST:event_jTable1MouseClicked

    private void loadBudget(int type) {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            listBudget.clear();
            Exercice e = (Exercice) cboExercice.getSelectedItem();
            if (e != null) {
                List<PrepaBudget> list = GrecoServiceFactory.getExerciceService().budgetGetByMillesime(o.getOrganisationID(),
                        e.getMillesime(), type);
                if (list != null && !list.isEmpty()) {
                    for (PrepaBudget p : list) {
                        listBudget.add(p);
                    }

                }
                switch (type) {
                    case BudgetType.REPORT:
                        lblListeBudget.setForeground(new Color(125, 161, 237) );
                        lblListeBudget.setText("BUDGET(S) DE REPORT");
                        break;
                    case BudgetType.INITIAL:
                        lblListeBudget.setForeground( new Color(156, 0, 132));
                        lblListeBudget.setText("BUDGET INITIAL");
                        break;
                    case BudgetType.ADDITIF:
                        lblListeBudget.setForeground( new Color(255, 153, 0) );
                        lblListeBudget.setText("BUDGET(S) ADDITIF(S)");
                        break;
                }
            }
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(BudgetListDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(BudgetListDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(BudgetListDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(BudgetListDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                BudgetListDialog dialog = new BudgetListDialog(new javax.swing.JFrame(), true, 0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JTable jTable1;
    private javax.swing.JLabel lblListeBudget;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pListeBudget;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

    class ActiviteTreeTableModel extends DefaultTreeTableModel {

        private static final int N = 0;
        private static final int DESIGNATION = 1;
        private static final int IMPUT = 2;
        private static final int COUT = 3;
        private static final int SOURCEFINANCEMENT = 4;
        private static final int STRUCTURE = 5;

        public ActiviteTreeTableModel(MyMutableTreeTableNode root) {
            super(root);
        }

        @Override
        public boolean isCellEditable(Object node, int column) {
            return false;
        }

        @Override
        public String getColumnName(int column) {
            String res = "";
            switch (column) {
                case N:
                    res = "N°";
                    break;
                case DESIGNATION:
                    res = "Désignation";
                    break;
                case IMPUT:
                    res = "Imputation";
                    break;
                case COUT:
                    res = "Coût";
                    break;
                case SOURCEFINANCEMENT:
                    res = "Financement";
                    break;
                case STRUCTURE:
                    res = "Structure";
                    break;
            }
            return res;
        }

        @Override
        public int getColumnCount() {
            return 6;
        }

        @Override
        public Object getValueAt(Object node, int column) {
            Object res = "";
            if (node instanceof MyMutableTreeTableNode) {
                MyMutableTreeTableNode defNode = (MyMutableTreeTableNode) node;
                if (defNode.getUserObject() instanceof Activite) {
                    Activite a = (Activite) defNode.getUserObject();
                    switch (column) {
                        case N:
                            break;
                        case DESIGNATION:
                            res = getEspaceActivite(a) + a.getCode() + " - " + a.getLibelle();
                            break;
                        case IMPUT:
                            res = "";
                            break;
                        case COUT:
                            res = "";
                            break;
                        case SOURCEFINANCEMENT:
                            res = "";
                            break;
                        case STRUCTURE:
                            res = "";
                            break;
                    }
                } else if (defNode.getUserObject() instanceof OperationBudgetaire) {
                    OperationBudgetaire o = (OperationBudgetaire) defNode.getUserObject();
                    switch (column) {
                        case N:

                            break;
                        case DESIGNATION:
                            res = getEspaceOperation() + o.getLibelle();
                            break;
                        case IMPUT:
                            res = o.getCompteCode() + " - " + o.getCompteLibelle();
                            break;
                        case COUT:
                            res = o.getAe();
                            break;
                        case SOURCEFINANCEMENT:
                            res = o.getFinancementAbbreviation();
                            break;
                        case STRUCTURE:
                            res = o.getStructureAbbreviation();
                            break;
                    }
                }
            }
            return res;
        }

        private String getEspaceActivite(Activite a) {
            String esc = "";
            for (int i = 0; i < a.getNiveauActiviteID(); i++) {
                esc = esc + "  ";
            }
            return esc;
        }

        private String getEspaceOperation() {
            String esc = "";
            for (int i = 0; i < GrecoSession.optionNiveau.getAt(); i++) {
                esc = esc + "  ";
            }
            esc = esc + "   ";
            return esc;
        }

    }

    //// BBPanel
    public static class BBPanel extends JPanel {

        BallInBox m_bb;   // The bouncing ball panel
        JPanel buttonPanel;

        //========================================================== constructor
        /**
         * Creates a panel with the controls and bouncing ball display.
         */
        BBPanel() {
            m_bb = new BallInBox();
            //... Layout outer panel with button panel above bouncing ball
            this.setLayout(new BorderLayout());
            this.add(m_bb, BorderLayout.CENTER);
            new StartAction().actionPerformed(null);
        }//end constructor

        public int isClickOnBall(MouseEvent e, int panelNorthHeight) {
            return m_bb.isClickOnBall(e, panelNorthHeight);
        }

        ////////////////////////////////////// inner listener class StartAction
        class StartAction implements ActionListener {

            public void actionPerformed(ActionEvent e) {
                m_bb.setAnimation(true);
            }
        }

        //////////////////////////////////////// inner listener class StopAction
        class StopAction implements ActionListener {

            public void actionPerformed(ActionEvent e) {
                m_bb.setAnimation(false);
            }
        }

        public void setBudgetText(String budgetreport, String budgetinitial, String budgetAdditif, String collectifBudgetaire) {
            m_bb.setBudgetText(budgetreport, budgetinitial, budgetAdditif, collectifBudgetaire);
        }
    }//endclass BBPanel

    //BouncingBall
    public static class BallInBox extends JPanel {
        //============================================== fields
        //... Instance variables representing the ball.

        private Ball m1_ball = new Ball("BUDGET REPORT 2016", 200, 30, 2, 3);
        private Ball m2_ball = new Ball("BUDGET INITIAL 2017", 400, 28, 1, 2, new Color(102, 0, 51), new Color(156, 0, 132));
        private Ball m3_ball = new Ball("BUDGET ADDITIF 2017", 600, 31, 2, 4, new Color(255, 51, 0), new Color(255, 153, 0));
        private Ball m4_ball = new Ball("COLLECTIF BUDGETAIRE", 800, 31, 2, 5, new Color(201, 20, 27), new Color(219, 81, 73));

        //... Instance variables for the animiation
        private int m_interval = 300;  // Milliseconds between updates.
        private Timer m_timer;           // Timer fires to anmimate one step.

        //========================================================== constructor
        /**
         * Set panel size and creates timer.
         */
        public BallInBox() {
            setBackground(Color.white);
            setPreferredSize(new Dimension(850, 200));
//            setBorder(BorderFactory.createLineBorder(Color.BLACK));
            m_timer = new Timer(m_interval, new TimerAction());
        }

        public void setBudgetText(String budgetreport, String budgetinitial, String budgetAdditif, String collectifBudget) {
            m1_ball.setText(budgetreport);
            m2_ball.setText(budgetinitial);
            m3_ball.setText(budgetAdditif);
            m4_ball.setText(collectifBudget);
        }

        //========================================================= setAnimation
        /**
         * Turn animation on or off.
         *
         * @param turnOnOff Specifies state of animation.
         */
        public void setAnimation(boolean turnOnOff) {
            if (turnOnOff) {
                m_timer.start();  // start animation by starting the timer.
            } else {
                m_timer.stop();   // stop timer
            }
        }

        //======================================================= paintComponent
        public void paintComponent(Graphics g) {
            super.paintComponent(g);  // Paint background, border
            m1_ball.draw(g);           // Draw the ball.
            m2_ball.draw(g);
            m3_ball.draw(g);
            m4_ball.draw(g);
        }

        public int isClickOnBall(MouseEvent e, int height) {
//            System.out.println(e.getX() + " " + e.getY());
//            System.out.println(m1_ball.getX() + " " + m1_ball.getY());
            int ball = 0;
            if (m1_ball.isClickOnBall(e.getX(), e.getY() - height)) {
                ball = 1;
            } else if (m2_ball.isClickOnBall(e.getX(), e.getY() - height)) {
                ball = 2;
            } else if (m3_ball.isClickOnBall(e.getX(), e.getY() - height)) {
                ball = 3;
            } else if (m4_ball.isClickOnBall(e.getX(), e.getY() - height)) {
                ball = 4;
            }
            return ball;

        }

        //////////////////////////////////// inner listener class ActionListener
        class TimerAction implements ActionListener {
            //================================================== actionPerformed

            /**
             * ActionListener of the timer. Each time this is called, the ball's
             * position is updated, creating the appearance of movement.
             *
             * @param e This ActionEvent parameter is unused.
             */
            public void actionPerformed(ActionEvent e) {
                m1_ball.setBounds(getWidth(), getHeight());
                m1_ball.move();  // Move the ball.

                m2_ball.setBounds(getWidth(), getHeight());
                m2_ball.move();  // Move the ball.

                m3_ball.setBounds(getWidth(), getHeight());
                m3_ball.move();  // Move the ball.
                
                m4_ball.setBounds(getWidth(), getHeight());
                m4_ball.move();  // Move the ball.
                repaint();      // Repaint indirectly calls paintComponent.
            }
        }
    }//endclass

    /// BallModel
    public static class Ball extends Component {
        //... Constants

        final static int DIAMETER = 150;

        //... Instance variables
        private int m_x;           // x and y coordinates upper left
        private int m_y;

        private int mf_x;           // x and y coordinates upper left
        private int mf_y;

        private int m_velocityX;   // Pixels to move each time move() is called.
        private int m_velocityY;

        private int m_rightBound;  // Maximum permissible x, y values.
        private int m_bottomBound;
        private int m_leftBound;
        private int m_topBound;

        private String text;
        private String[] strs;

        private Color COLOR1 = new Color(125, 161, 237);
        private Color COLOR2 = new Color(91, 118, 173);
//        private static Color COLOR2 = new Color(255, 255, 255);

        //======================================================== constructor
        public Ball(String str, int x, int y, int velocityX, int velocityY, Color col1, Color col2) {
            m_x = x;
            m_y = y;
            mf_x = x;
            mf_y = y;
            text = str;
            strs = text.split(" ");
            m_velocityX = velocityX;
            m_velocityY = velocityY;
            COLOR1 = col1;
            COLOR2 = col2;
        }

        public Ball(String str, int x, int y, int velocityX, int velocityY) {
            this(str, x, y, velocityX, velocityY, new Color(125, 161, 237), new Color(91, 118, 173));
        }

        //======================================================== setBounds
        public void setBounds(int width, int height) {
            m_rightBound = mf_x + 5;
            m_bottomBound = mf_y + 7;
            m_leftBound = mf_x - 5;
            m_topBound = mf_y - 7;
        }

        //============================================================== move
        public void move() {
            //... Move the ball at the give velocity.
            m_x += m_velocityX;
            m_y += m_velocityY;

            //... Bounce the ball off the walls if necessary.
            if (m_x < m_leftBound) {                  // If at or beyond left side
                m_x = m_leftBound;            // Place against edge and
                m_velocityX = -m_velocityX; // reverse direction.

            } else if (m_x > m_rightBound) { // If at or beyond right side
                m_x = m_rightBound;    // Place against right edge.
                m_velocityX = -m_velocityX;  // Reverse direction.
            }

            if (m_y < m_topBound) {                 // if we're at top
                m_y = m_topBound;
                m_velocityY = -m_velocityY;

            } else if (m_y > m_bottomBound) { // if we're at bottom
                m_y = m_bottomBound;
                m_velocityY = -m_velocityY;
            }
        }

        //============================================================== draw
        public void draw(Graphics g) {
            float tran = 0.75f;//0.1f + pct * 0.9f;

            Graphics2D g2d = (Graphics2D) g.create();
            g2d.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, tran));
            GradientPaint p1 = new GradientPaint(0, 0, COLOR1, DIAMETER / 2, DIAMETER - 75, COLOR2);
            g2d.setPaint(p1);
            g2d.fillOval(m_x, m_y, DIAMETER, DIAMETER);
            g2d.setColor(Color.white);
            g2d.setFont(new Font("Courier New", Font.BOLD, 20));
            FontMetrics metrics = g.getFontMetrics();
            int decalage = -35;
            for (String str : strs) {
                int width = metrics.stringWidth(str);
                int height = metrics.getHeight(); //+ metrics.getMaxDescent();
                decalage += height + 20;
                g2d.drawString(str, m_x + ((DIAMETER - width - 20) / 2), m_y + ((DIAMETER - height + decalage) / 2));
            }

        }

        //============================================= getDiameter, getX, getY
        public int getDiameter() {
            return DIAMETER;
        }

        public int getX() {
            return m_x;
        }

        public int getY() {
            return m_y;
        }

        public boolean isClickOnBall(int xpos, int ypos) {
            boolean res = false;
            if (xpos >= m_x && xpos <= m_x + DIAMETER) {
                if (ypos >= m_y && ypos <= m_y + DIAMETER) {
                    res = true;
                }
            }
            return res;
        }

        //======================================================== setPosition
        public void setPosition(int x, int y) {
            m_x = x;
            m_y = y;
        }

        public Color getCOLOR1() {
            return COLOR1;
        }

        public void setCOLOR1(Color COLOR1) {
            this.COLOR1 = COLOR1;
        }

        public Color getCOLOR2() {
            return COLOR2;
        }

        public void setCOLOR2(Color COLOR2) {
            this.COLOR2 = COLOR2;
        }

        public String getText() {
            return text;
        }

        public void setText(String text) {
            this.text = text;
            strs = text.split(" ");
        }

    }

}
