/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.ui.budgeting;

import org.jdesktop.swingx.treetable.DefaultMutableTreeTableNode;
import org.jdesktop.swingx.treetable.MutableTreeTableNode;


/**
 *
 * @author ouethy
 */
public class MyMutableTreeTableNode extends DefaultMutableTreeTableNode{

    public MyMutableTreeTableNode(Object userObject, boolean allowsChildren) {
        super(userObject, allowsChildren);
    }

    public MyMutableTreeTableNode(Object userObject) {
        super(userObject);
    }

    public MyMutableTreeTableNode() {
    }
    public void removeAll(){
        children.clear();
    }
    @Override
    public void remove(int childIndex) {
//        super.remove(index);
         MutableTreeTableNode child = (MutableTreeTableNode)getChildAt(childIndex);
        children.remove(childIndex);
        child.setParent(null);
    }
    
    @Override
    public void add(MutableTreeTableNode newChild) {
       if(newChild != null && newChild.getParent() == this)
             insert(newChild, getChildCount() - 1);             
        else
            insert(newChild, getChildCount());
    }

}
