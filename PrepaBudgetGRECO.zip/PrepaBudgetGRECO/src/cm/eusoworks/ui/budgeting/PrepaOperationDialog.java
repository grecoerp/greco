/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.budgeting;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.enumeration.BudgetType;
import cm.eusoworks.entities.model.Activite;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.PrepaOperationBudgetaire;
import cm.eusoworks.entities.model.SourceFinancement;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.PrepaBudget;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueOpFichier;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import org.jdesktop.observablecollections.ObservableCollections;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author macbookair
 */
public class PrepaOperationDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OperationDialog
     */
    boolean fichierDejaLu = false;
    Activite tache;
    PrepaOperationBudgetaire paragraphe;
    private List<PrepaOperationBudgetaire> operations = null;
    List<VueOpFichier> listLignes = ObservableCollections.observableList(new ArrayList<VueOpFichier>());
    PrepaBudget budget;

    public PrepaOperationDialog(JFrame parent, boolean modal, Activite tache, PrepaOperationBudgetaire paragraphe, PrepaBudget budget) {
        super(parent, modal);
        initComponents();
        this.tache = tache;
        this.paragraphe = paragraphe;
        this.budget = budget;
        txtProjetLibelle.setText(tache.getCode() + " - " + tache.getLibelleFr());
        loadStructureOrganisation();
        loadFinancement();
        loadCompte();
        AutoCompleteDecorator.decorate(cboCompte);
        AutoCompleteDecorator.decorate(cboStructure);
        AutoCompleteDecorator.decorate(cboFinancement);
        initUI();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Opérations budgétaires //" + budget.getLibelleFr());
        setPreferredSize(new Dimension(955, 620));
        pack();
        setLocationRelativeTo(null);
    }

    private void loadStructureOrganisation() {
        String organisationID = tache.getOrganisationID();
        if (organisationID != null) {
            List<Structure> list = new ArrayList<Structure>();
            try {
                list = GrecoServiceFactory.getOrganisationService().listeStructuresUserByOrganisation(organisationID,
                        GrecoSession.USER_CONNECTED.getLogin());
            } catch (Exception e) {
                list = null;
            }
            if (list != null && !list.isEmpty()) {
                cboStructure.setModel(new DefaultComboBoxModel(list.toArray()));
                if (list.size() == 1) {
                    cboStructure.setSelectedIndex(0);
                } else {
                    cboStructure.setSelectedIndex(-1);
                }
            }
        }
    }

    private void loadFinancement() {

        List<SourceFinancement> list = new ArrayList<SourceFinancement>();
        try {
            list = GrecoServiceFactory.getSourceFinancementService().listeSourceFinancement(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboFinancement.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboFinancement.setSelectedIndex(0);
            }
        }
    }

    private void loadCompte() {

        List<Compte> list = new ArrayList<Compte>();
        try {
            list = GrecoServiceFactory.getNomenclatureService().getListCompteUtilisables();
        } catch (Exception e) {
            list = null;
        }
        if (list != null && !list.isEmpty()) {
            cboCompte.setModel(new DefaultComboBoxModel(list.toArray()));
            cboCompte.setSelectedIndex(-1);
        }
    }

    private void initUI() {
        btnEnregistrer.setVisible(budget.getEtat().equals("100"));
        lnkImporter.setVisible(budget.getEtat().equals("100"));

        if (paragraphe == null) {
            txtLibelle.clear();
            txtIndicateurResultat.clear();
            txtSourceVerif.clear();
            cboCompte.setSelectedIndex(-1);
            txtAE.setText(null);
            txtCP.setText(null);
        } else {
            txtLibelle.setTextFr(paragraphe.getLibelleFr());
            txtLibelle.setTextUs(paragraphe.getLibelleUs()==null?"":paragraphe.getLibelleUs());
            txtIndicateurResultat.setTextFr(paragraphe.getIndicateurFr());
            txtIndicateurResultat.setTextUs(paragraphe.getIndicateurUs()==null?"":paragraphe.getIndicateurUs());
            txtSourceVerif.setTextFr(paragraphe.getSourceVerificationFr());
            txtSourceVerif.setTextUs(paragraphe.getSourceVerificationUs()==null?"":paragraphe.getSourceVerificationUs());
            txtAE.setValue(paragraphe.getAe());
            txtCP.setValue(paragraphe.getCp());
            dtpDateDebut.setDate(paragraphe.getDateDebut());
            dtpDateFin.setDate(paragraphe.getDateFin());
            try {
                chronogramme1.setCalendrier(paragraphe.getCalendrier());
            } catch (Exception e) {
                e.printStackTrace();
            }

            for (int i = 0; i < cboStructure.getItemCount(); i++) {
                if (((Structure) cboStructure.getItemAt(i)).getStructureID().equalsIgnoreCase(paragraphe.getStructureID())) {
                    cboStructure.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboFinancement.getItemCount(); i++) {
                if (((SourceFinancement) cboFinancement.getItemAt(i)).getFinancementID().equalsIgnoreCase(paragraphe.getFinancementID())) {
                    cboFinancement.setSelectedIndex(i);
                    break;
                }
            }
            for (int i = 0; i < cboCompte.getItemCount(); i++) {
                if (((Compte) cboCompte.getItemAt(i)).getCode().equalsIgnoreCase(paragraphe.getCompteCode())) {
                    cboCompte.setSelectedIndex(i);
                    break;
                }
            }
        }
    }

    private void remplirCurrentStructure() {
        paragraphe.setLibelleFr(txtLibelle.getTextFr());
        paragraphe.setLibelleUs(txtLibelle.getTextUs());
        paragraphe.setIndicateurFr(txtIndicateurResultat.getTextFr());
        paragraphe.setIndicateurUs(txtIndicateurResultat.getTextUs());
        paragraphe.setSourceVerificationFr(txtSourceVerif.getTextFr());
        paragraphe.setSourceVerificationUs(txtSourceVerif.getTextUs());
        paragraphe.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        paragraphe.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
        paragraphe.setDateDebut(dtpDateDebut.getDate());
        paragraphe.setDateFin(dtpDateFin.getDate());

        try {
            txtAE.commitEdit();
        } catch (Exception e) {
        }
        try {
            txtCP.commitEdit();
        } catch (Exception e) {
        }

        try {
            paragraphe.setAe(BigDecimal.valueOf((long) txtAE.getValue()));
//            paragraphe.setAe((BigDecimal) txtAE.getValue());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "La modification sur le montant AE n'a pas été prise en compte");
//            return;

        }
        try {
            paragraphe.setCp(BigDecimal.valueOf((long) txtCP.getValue()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "La modification sur le montant CP n'a pas été prise en compte");
            return;
        }

        Compte c = (Compte) cboCompte.getSelectedItem();
        paragraphe.setCompteCode(c.getCode());
        Structure s = (Structure) cboStructure.getSelectedItem();
        paragraphe.setStructureID(s.getStructureID());
        paragraphe.setPosteComptableID(s.getPosteComptableID());
        SourceFinancement sf = (SourceFinancement) cboFinancement.getSelectedItem();
        paragraphe.setFinancementID(sf.getFinancementID());
        paragraphe.setActiviteBudgetiseID(tache.getActiviteID());

        paragraphe.setCalendrier(chronogramme1.getCalendrier());

        // budget pour lequel l'opération est inscrite 
        paragraphe.setBudgetID(budget.getBudgetID());
        switch (budget.getType()) {
            case BudgetType.REPORT:
                paragraphe.setBudgetExploite(BudgetType.ETAT_REPORT);
                break;
            case BudgetType.INITIAL:
                paragraphe.setBudgetExploite(BudgetType.ETAT_INITIAL);
                break;
            case BudgetType.ADDITIF:
                paragraphe.setBudgetExploite(BudgetType.ETAT_ADDITIF);
                break;
            default:
                break;
        }
    }

    private boolean checkData() {
        boolean res = true;

        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir la structure porteuse du projet");
            return false;
        }
        SourceFinancement sf = (SourceFinancement) cboFinancement.getSelectedItem();
        if (sf == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir la source de financement ");
            return false;
        }
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c == null) {
            GrecoOptionPane.showWarningDialog("Veuillez choisir le paragraphe budgétaire de cette opération");
            return false;
        }
        if (txtLibelle.getTextFr() == null || txtLibelle.getTextFr().isEmpty()) {
            GrecoOptionPane.showWarningDialog("le libellé de la tâche ne peut pas être vide ");
            return false;
        }

        return res;
    }

    private void importer() {
        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la structure responsable ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return;
        }
        SourceFinancement u = (SourceFinancement) cboFinancement.getSelectedItem();
        if (u == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la source de financement ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return;
        }
//        Date deb = dtpDateDebut.getDate();
//        if (deb == null) {
//            JOptionPane.showMessageDialog(this, "Selectionnez la date de démarrage de cette opération ", "GRECO", JOptionPane.WARNING_MESSAGE);
//            return;
//        }
//        Date fin = dtpDateFin.getDate();
//        if (deb == null) {
//            JOptionPane.showMessageDialog(this, "Selectionnez la date de fin de cette opération ", "GRECO", JOptionPane.WARNING_MESSAGE);
//            return;
//        }
        ((CardLayout) pOperation.getLayout()).show(pOperation, "fichier");
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        jLabel5 = new javax.swing.JLabel();
        dtpDateDebut = new org.jdesktop.swingx.JXDatePicker();
        jLabel6 = new javax.swing.JLabel();
        dtpDateFin = new org.jdesktop.swingx.JXDatePicker();
        pDetails = new javax.swing.JPanel();
        pOperation = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtLibelle = new editor.EditorRTF();
        txtIndicateurResultat = new editor.EditorRTF();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        cboStructure = new javax.swing.JComboBox();
        jLabel9 = new javax.swing.JLabel();
        cboFinancement = new javax.swing.JComboBox();
        jLabel10 = new javax.swing.JLabel();
        cboCompte = new javax.swing.JComboBox();
        jLabel7 = new javax.swing.JLabel();
        txtSourceVerif = new editor.EditorRTF();
        jLabel2 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        txtCP = new javax.swing.JFormattedTextField();
        txtAE = new javax.swing.JFormattedTextField();
        jSeparator1 = new javax.swing.JSeparator();
        btnEnregistrer = new javax.swing.JButton();
        lnkImporter = new org.jdesktop.swingx.JXHyperlink();
        jLabel12 = new javax.swing.JLabel();
        chronogramme1 = new cm.eusoworks.tools.ui.Chronogramme();
        jScrollPane3 = new javax.swing.JScrollPane();
        txtProjetLibelle = new javax.swing.JTextArea();
        pFichier = new javax.swing.JPanel();
        jLabel13 = new javax.swing.JLabel();
        txtFilePath = new javax.swing.JTextField();
        btnParcourir = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tableApercu = new org.jdesktop.swingx.JXTable();
        btnApercu = new javax.swing.JButton();
        btnTraitementFichier = new cm.eusoworks.tools.ui.GButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtErrors = new javax.swing.JTextArea();
        lblErrors = new javax.swing.JLabel();
        btnRetour = new javax.swing.JButton();
        lblNbLignes = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnFermer = new javax.swing.JButton();

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel5.setText("Date de début : ");

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel6.setText("Date de fin : ");

        setDefaultCloseOperation(javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");

        pDetails.setLayout(new java.awt.BorderLayout());

        pOperation.setLayout(new java.awt.CardLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(200, 190, 490, 70);
        jPanel1.add(txtIndicateurResultat);
        txtIndicateurResultat.setBounds(200, 270, 490, 70);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Opération  : ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 190, 100, 50);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Indicateur / Résultat :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 270, 160, 50);

        jLabel1.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel1.setText("Structure responsable : ");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(20, 10, 150, 30);

        jPanel1.add(cboStructure);
        cboStructure.setBounds(200, 7, 490, 30);

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 12)); // NOI18N
        jLabel9.setText("Financement : ");
        jPanel1.add(jLabel9);
        jLabel9.setBounds(20, 40, 140, 30);

        jPanel1.add(cboFinancement);
        cboFinancement.setBounds(200, 40, 490, 30);

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Compte : ");
        jPanel1.add(jLabel10);
        jLabel10.setBounds(20, 70, 140, 30);

        cboCompte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboCompteActionPerformed(evt);
            }
        });
        jPanel1.add(cboCompte);
        cboCompte.setBounds(200, 70, 490, 30);

        jLabel7.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel7.setText("Source de vérification :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 360, 160, 40);
        jPanel1.add(txtSourceVerif);
        txtSourceVerif.setBounds(200, 350, 490, 80);

        jLabel2.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel2.setText("AE : ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(190, 110, 50, 30);

        jLabel8.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        jLabel8.setText("CP : ");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(450, 110, 50, 30);

        txtCP.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(new java.text.DecimalFormat("#,##0"))));
        txtCP.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtCP.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtCPFocusLost(evt);
            }
        });
        jPanel1.add(txtCP);
        txtCP.setBounds(500, 110, 190, 32);

        txtAE.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.NumberFormatter(java.text.NumberFormat.getIntegerInstance())));
        txtAE.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        txtAE.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent evt) {
                txtAEFocusLost(evt);
            }
        });
        jPanel1.add(txtAE);
        txtAE.setBounds(240, 110, 190, 32);
        jPanel1.add(jSeparator1);
        jSeparator1.setBounds(20, 180, 660, 12);

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel1.add(btnEnregistrer);
        btnEnregistrer.setBounds(710, 280, 116, 29);

        lnkImporter.setText("Importer une liste opération / tâche à partir d'un fichier");
        lnkImporter.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        lnkImporter.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                lnkImporterActionPerformed(evt);
            }
        });
        jPanel1.add(lnkImporter);
        lnkImporter.setBounds(300, 160, 400, 20);

        jLabel12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel12.setText("Calendrier d'exécution : ");
        jPanel1.add(jLabel12);
        jLabel12.setBounds(20, 440, 160, 50);
        jPanel1.add(chronogramme1);
        chronogramme1.setBounds(200, 450, 290, 46);

        jScrollPane3.setEnabled(false);
        jScrollPane3.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N

        txtProjetLibelle.setColumns(20);
        txtProjetLibelle.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        txtProjetLibelle.setForeground(new java.awt.Color(102, 102, 102));
        txtProjetLibelle.setLineWrap(true);
        txtProjetLibelle.setRows(5);
        jScrollPane3.setViewportView(txtProjetLibelle);

        jPanel1.add(jScrollPane3);
        jScrollPane3.setBounds(700, 10, 210, 230);

        pOperation.add(jPanel1, "operation");

        pFichier.setBackground(new java.awt.Color(255, 255, 255));

        jLabel13.setText("Fichier a importer ");

        btnParcourir.setText("...");
        btnParcourir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnParcourirActionPerformed(evt);
            }
        });

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listLignes}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableApercu);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${compte}"));
        columnBinding.setColumnName("Compte");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelleFr}"));
        columnBinding.setColumnName("Libelle");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${ae}"));
        columnBinding.setColumnName("AE");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${cp}"));
        columnBinding.setColumnName("CP");
        columnBinding.setColumnClass(java.math.BigDecimal.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane1.setViewportView(tableApercu);
        if (tableApercu.getColumnModel().getColumnCount() > 0) {
            tableApercu.getColumnModel().getColumn(0).setPreferredWidth(70);
            tableApercu.getColumnModel().getColumn(1).setPreferredWidth(300);
            tableApercu.getColumnModel().getColumn(2).setPreferredWidth(100);
            tableApercu.getColumnModel().getColumn(3).setPreferredWidth(100);
        }

        btnApercu.setText("Apercu du fichier");
        btnApercu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnApercuActionPerformed(evt);
            }
        });

        btnTraitementFichier.setText("Importer les donnees ");
        btnTraitementFichier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnTraitementFichierActionPerformed(evt);
            }
        });

        txtErrors.setColumns(20);
        txtErrors.setForeground(new java.awt.Color(204, 0, 0));
        txtErrors.setRows(5);
        jScrollPane2.setViewportView(txtErrors);

        lblErrors.setText("Resultat de l'importation");

        btnRetour.setText("<<< Retour");
        btnRetour.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRetourActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pFichierLayout = new javax.swing.GroupLayout(pFichier);
        pFichier.setLayout(pFichierLayout);
        pFichierLayout.setHorizontalGroup(
            pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFichierLayout.createSequentialGroup()
                .addGroup(pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pFichierLayout.createSequentialGroup()
                        .addGap(14, 14, 14)
                        .addGroup(pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(btnRetour)
                            .addGroup(pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addGroup(pFichierLayout.createSequentialGroup()
                                    .addComponent(btnApercu)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addComponent(lblNbLignes, javax.swing.GroupLayout.PREFERRED_SIZE, 328, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGap(9, 9, 9))
                                .addComponent(jLabel13, javax.swing.GroupLayout.PREFERRED_SIZE, 239, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGroup(pFichierLayout.createSequentialGroup()
                                    .addComponent(txtFilePath, javax.swing.GroupLayout.PREFERRED_SIZE, 579, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(btnParcourir, javax.swing.GroupLayout.PREFERRED_SIZE, 49, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(jScrollPane1)
                                .addComponent(jScrollPane2))))
                    .addGroup(pFichierLayout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addComponent(btnTraitementFichier, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(217, 217, 217)
                        .addComponent(lblErrors, javax.swing.GroupLayout.PREFERRED_SIZE, 185, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(265, Short.MAX_VALUE))
        );
        pFichierLayout.setVerticalGroup(
            pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFichierLayout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel13)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtFilePath, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnParcourir))
                .addGap(23, 23, 23)
                .addGroup(pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(btnApercu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblNbLignes, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 132, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28)
                .addGroup(pFichierLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btnTraitementFichier, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblErrors))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 151, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnRetour)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        pOperation.add(pFichier, "fichier");

        pDetails.add(pOperation, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 15, 5));

        btnFermer.setText("Fermer");
        btnFermer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnFermerActionPerformed(evt);
            }
        });
        jPanel2.add(btnFermer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetails, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (!checkData()) {
            return;
        }

        if (paragraphe == null) {
            paragraphe = new PrepaOperationBudgetaire();
            remplirCurrentStructure();
            try {
                GrecoServiceFactory.getOperationService().prepaAjouter(paragraphe, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Ajout de l'opération :" + paragraphe.getLibelle()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.BUDGETISATION_ANNUELLE);
                GrecoSession.notifications.success();
                if (operations == null) {
                    operations = new ArrayList<>();
                }
                PrepaOperationBudgetaire e = paragraphe;
                operations.add(e);
                paragraphe = null;
                initUI();
            } catch (GrecoException ex) {
                paragraphe = null;
                GrecoSession.notifications.echec();
                ManageException.show(ex, GrecoSession.USER_LANGUAGE);
            } catch (Exception e) {
                paragraphe = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
            }
        } else {
            remplirCurrentStructure();
            try {
                GrecoServiceFactory.getOperationService().prepaModifier(paragraphe, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Modification de l'opération : " + paragraphe.getLibelle()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.BUDGETISATION_ANNUELLE);
                GrecoSession.notifications.success();
                dispose();
            } catch (GrecoException ex) {
                GrecoSession.notifications.echec();
                ManageException.show(ex, GrecoSession.USER_LANGUAGE);
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void txtAEFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtAEFocusLost
        try {
            // TODO add your handling code here:
            txtAE.commitEdit();
        } catch (ParseException ex) {
            Logger.getLogger(PrepaOperationDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
//        Compte c = (Compte) cboCompte.getSelectedItem();
//        if (c == null || !c.getCode().substring(0, 1).equals("2")) {
        txtCP.setValue(txtAE.getValue());
//        }

    }//GEN-LAST:event_txtAEFocusLost

    private void btnFermerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnFermerActionPerformed
        // TODO add your handling code here:
        this.setVisible(false);
    }//GEN-LAST:event_btnFermerActionPerformed

    private void btnRetourActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRetourActionPerformed
        // TODO add your handling code here:
        ((CardLayout) pOperation.getLayout()).show(pOperation, "operation");
    }//GEN-LAST:event_btnRetourActionPerformed

    private void btnParcourirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnParcourirActionPerformed
        // TODO add your handling code here:
        File repertoireCourant = null;
        if (txtFilePath.getText().isEmpty()) {
            try {
                repertoireCourant = new File(".").getCanonicalFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } else {
            try {
                repertoireCourant = new File(txtFilePath.getText()).getCanonicalFile();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
        JFileChooser dialogue = new JFileChooser(repertoireCourant);
        dialogue.showOpenDialog(null);
        try {
            txtFilePath.setText(dialogue.getSelectedFile().getCanonicalPath());
        } catch (IOException ex) {
            Logger.getLogger(PrepaOperationDialog.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_btnParcourirActionPerformed

    private void btnApercuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnApercuActionPerformed
        // TODO add your handling code here:
        lblNbLignes.setText("");
        lblErrors.setText("Resultat de l'importation");
        File f = null;
        try {
            f = new File(txtFilePath.getText()).getCanonicalFile();
            //lecture du fichier texte	
            try {
                InputStream ips = new FileInputStream(f);
                InputStreamReader ipsr = new InputStreamReader(ips);
                BufferedReader br = new BufferedReader(ipsr);
                String ligne;
                List<VueOpFichier> list = new ArrayList<>();
                int i = 0;
                while ((ligne = br.readLine()) != null) {
                    String[] l = ligne.split(";");
                    VueOpFichier o = new VueOpFichier();
                    if (l.length > 0) {
                        if (l[0] != null && !l[0].isEmpty()) {
                            try {
                                o.setLibelleFr(l[0]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setIndicateur(l[1]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setSourceVerification(l[2]);
                            } catch (Exception e) {
                            }
//////                    try {
//////                        o.setStructure(l[3]);
//////                    } catch (Exception e) {
//////                    }
                            try {
                                o.setJan(l[4]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setFev(l[5]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setMar(l[6]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setAvr(l[7]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setMai(l[8]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setJun(l[9]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setJul(l[10]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setAou(l[11]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setSep(l[12]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setOct(l[13]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setNov(l[14]);
                            } catch (Exception e) {
                            }

                            try {
                                o.setDec(l[15]);
                            } catch (Exception e) {
                            }
                            try {
                                o.setCompte(l[16]);
                            } catch (Exception e) {
                            }
////////                    try {
////////                        o.setCompteLibelle(l[17]);
////////                    } catch (Exception e) {
////////                    }
                            try {
                                o.setAe(BigDecimal.valueOf(Long.parseLong(l[18].replace(" ", ""))));
                            } catch (Exception e) {
                            }
                            try {
                                o.setCp(BigDecimal.valueOf(Long.parseLong(l[18].replace(" ", ""))));
                            } catch (Exception e) {
                            }
                        }
                        list.add(o);
                    i++;
                    }

                    

                }
                br.close();
                fichierDejaLu = true;
                lblNbLignes.setText(i + " tache(s) a importer");

                listLignes.clear();
                for (VueOpFichier v : list) {
                    listLignes.add(v);
                }
                if (i > 0) {
                    btnTraitementFichier.setVisible(true);
                } else {
                    btnTraitementFichier.setVisible(false);
                }
            } catch (Exception e) {
                System.out.println(e.toString());
            }

        } catch (IOException ex) {
            Logger.getLogger(PrepaOperationDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_btnApercuActionPerformed

    private void btnTraitementFichierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnTraitementFichierActionPerformed
        // TODO add your handling code here:
        txtErrors.setText("");
        if (!fichierDejaLu) {
            btnApercuActionPerformed(null);
        }
        int er = 0, sc = 0;
        for (VueOpFichier v : listLignes) {
            paragraphe = new PrepaOperationBudgetaire();
            paragraphe.setLibelleFr(v.getLibelleFr());
            paragraphe.setLibelleUs(v.getLibelleUs());
            paragraphe.setIndicateurFr(v.getIndicateur());
            paragraphe.setIndicateurUs(v.getIndicateur());
            paragraphe.setSourceVerificationFr(v.getSourceVerification());
            paragraphe.setSourceVerificationUs(v.getSourceVerification());
            paragraphe.setCalendrier(v.getCalendrier());
            paragraphe.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
            paragraphe.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
            paragraphe.setDateDebut(dtpDateDebut.getDate());
            paragraphe.setDateFin(dtpDateFin.getDate());
            paragraphe.setBudgetID(this.budget.getBudgetID());
            try {
                paragraphe.setAe(v.getAe());
            } catch (Exception e) {
                paragraphe.setAe(BigDecimal.ZERO);

            }
            try {
                paragraphe.setCp(v.getCp());
            } catch (Exception e) {
                paragraphe.setCp(BigDecimal.ZERO);
            }

            paragraphe.setCompteCode(v.getCompte());
            Structure s = (Structure) cboStructure.getSelectedItem();
            paragraphe.setStructureID(s.getStructureID());
            paragraphe.setPosteComptableID(s.getPosteComptableID());
            SourceFinancement sf = (SourceFinancement) cboFinancement.getSelectedItem();
            paragraphe.setFinancementID(sf.getFinancementID());
            paragraphe.setActiviteBudgetiseID(tache.getActiviteID());
            try {
                GrecoServiceFactory.getOperationService().prepaAjouter(paragraphe, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Ajout d'une opération " + paragraphe.getLibelle()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.BUDGETISATION_ANNUELLE);
                sc++;
            } catch (GrecoException ex) {
                er++;
                txtErrors.append(v.getCompte() + " - " + v.getLibelleFr());
                txtErrors.append("\n");
            }
            if (er > 0) {
                lblErrors.setForeground(Color.red);
                lblErrors.setText(er + " taches non enregistrees. Verifier que ces comptes existent dans le plan comptable SVP");
            } else {
                lblErrors.setForeground(Color.green);
                lblErrors.setText(sc + " taches enregistrees avec success");
                btnTraitementFichier.setVisible(false);
            }

        }
    }//GEN-LAST:event_btnTraitementFichierActionPerformed

    private void lnkImporterActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_lnkImporterActionPerformed
        // TODO add your handling code here:
        importer();
    }//GEN-LAST:event_lnkImporterActionPerformed

    private void cboCompteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboCompteActionPerformed
        // TODO add your handling code here:`
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c != null) {
            if (!c.getCode().substring(0, 1).equals("2")) {
                if (paragraphe == null) {
                    txtLibelle.setTextFr(c.getLibelleFr());
                    txtLibelle.setTextUs(c.getLibelleUs());
                }
            }
        }
    }//GEN-LAST:event_cboCompteActionPerformed

    private void txtCPFocusLost(java.awt.event.FocusEvent evt) {//GEN-FIRST:event_txtCPFocusLost
        // TODO add your handling code here:
        try {
            // TODO add your handling code here:
            txtCP.commitEdit();
        } catch (ParseException ex) {
            Logger.getLogger(PrepaOperationDialog.class.getName()).log(Level.SEVERE, null, ex);
        }
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c == null || !c.getCode().substring(0, 1).equals("2")) {
            txtAE.setValue(txtCP.getValue());
        }
    }//GEN-LAST:event_txtCPFocusLost

    private boolean controlData() {
        boolean res = true;

        if (txtLibelle.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le libelle de l'opération ", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtIndicateurResultat.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir l'indicateur de résultat ", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtSourceVerif.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir la source de vérification ", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Structure s = (Structure) cboStructure.getSelectedItem();
        if (s == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la structure responsable ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        SourceFinancement u = (SourceFinancement) cboFinancement.getSelectedItem();
        if (u == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner la source de financement ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Compte c = (Compte) cboCompte.getSelectedItem();
        if (c == null) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner le paragraphe budgétaire ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Date deb = dtpDateDebut.getDate();
        if (deb == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la date de démarrage de cette opération ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        Date fin = dtpDateFin.getDate();
        if (deb == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la date de fin de cette opération ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        long ae = ((Number) txtAE.getValue()).longValue();
        long cp = ((Number) txtCP.getValue()).longValue();
        if (cp > ae) {
            JOptionPane.showMessageDialog(this, "Le CP ne doit pas etre supérieur à l'AE ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PrepaOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PrepaOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PrepaOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PrepaOperationDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PrepaOperationDialog dialog = new PrepaOperationDialog(new javax.swing.JFrame(), true, null, null, null);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    public List<PrepaOperationBudgetaire> getOperations() {
        return operations;
    }

    public List<VueOpFichier> getListLignes() {
        return listLignes;
    }

    public void setListLignes(List<VueOpFichier> listLignes) {
        this.listLignes = listLignes;
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnApercu;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnFermer;
    private javax.swing.JButton btnParcourir;
    private javax.swing.JButton btnRetour;
    private cm.eusoworks.tools.ui.GButton btnTraitementFichier;
    private javax.swing.JComboBox cboCompte;
    private javax.swing.JComboBox cboFinancement;
    private javax.swing.JComboBox cboStructure;
    private cm.eusoworks.tools.ui.Chronogramme chronogramme1;
    private org.jdesktop.swingx.JXDatePicker dtpDateDebut;
    private org.jdesktop.swingx.JXDatePicker dtpDateFin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JLabel lblErrors;
    private javax.swing.JLabel lblNbLignes;
    private org.jdesktop.swingx.JXHyperlink lnkImporter;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pFichier;
    private javax.swing.JPanel pOperation;
    private org.jdesktop.swingx.JXTable tableApercu;
    private javax.swing.JFormattedTextField txtAE;
    private javax.swing.JFormattedTextField txtCP;
    private javax.swing.JTextArea txtErrors;
    private javax.swing.JTextField txtFilePath;
    private editor.EditorRTF txtIndicateurResultat;
    private editor.EditorRTF txtLibelle;
    private javax.swing.JTextArea txtProjetLibelle;
    private editor.EditorRTF txtSourceVerif;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
