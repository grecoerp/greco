/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.tree;

import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;

/**
 *
 * @author DISI
 */
public class ProfilTreeModel extends  DefaultTreeModel {
    
    public ProfilTreeModel(TreeNode root) {
        super(root);
    }
    
}
