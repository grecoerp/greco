/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tree;

import cm.eusoworks.entities.model.Compte;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author macbookair
 */
public class CompteNode extends DefaultMutableTreeNode{
    private Compte compte;

    public CompteNode() {
        this(null);
    } 
    public CompteNode(Compte cat) {
        compte = cat;
    }

    @Override
    public String toString() {
        return (compte == null)?"aucun compte":compte.toString();
    }

    public Compte getCompte() {
        return compte;
    }
  
    public int getNiveauID(){
        return (compte == null)?-1:compte.getNiveauID();
    }
    
    public String getParentCode(){
        return (compte == null)?null:compte.getParentCode();
    }
    
    public String getCode(){
        return (compte == null)?"-1":compte.getCode();
    }
}
