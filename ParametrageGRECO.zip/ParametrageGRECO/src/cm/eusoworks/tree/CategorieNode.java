/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.tree;

import cm.eusoworks.entities.model.Categorie;
import javax.swing.tree.DefaultMutableTreeNode;

/**
 *
 * @author macbookair
 */
public class CategorieNode extends DefaultMutableTreeNode{
    private Categorie categorie;

    public CategorieNode() {
        this(null);
    } 
    public CategorieNode(Categorie cat) {
        categorie = cat;
    }

    @Override
    public String toString() {
        return (categorie == null)?"aucune categorie":categorie.toString();
    }

    public Categorie getCategorie() {
        return categorie;
    }
  
    public int getNiveauID(){
        return (categorie == null)?-1:categorie.getNiveauID();
    }
    
    public String getParentCode(){
        return (categorie == null)?null:categorie.getParentCode();
    }
    
    public String getCode(){
        return (categorie == null)?"-1":categorie.getCode();
    }
}
