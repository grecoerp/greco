/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.Users;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueMachine;
import cm.eusoworks.entities.view.VueTrack;
import cm.eusoworks.jasper.GrecoReports;
import cm.eusoworks.report.JRHelper;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import java.awt.Cursor;
import java.awt.Image;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import net.sf.jasperreports.engine.JRDataSource;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author jeanemmanuel
 */
public class ModuleProfilerFrame extends javax.swing.JFrame {

    GrecoReports fonctions = new GrecoReports();

    List<Users> listUsers = ObservableCollections.observableList(new ArrayList<Users>());
    List<VueMachine> listMachines = ObservableCollections.observableList(new ArrayList<VueMachine>());
    Users selectedUser;
    VueMachine selectedMachine;

    List<VueTrack> listTracks = ObservableCollections.observableList(new ArrayList<VueTrack>());
    List<VueTrack> listTracksMachines = ObservableCollections.observableList(new ArrayList<VueTrack>());
    List<VueTrack> listTracksDossiers = ObservableCollections.observableList(new ArrayList<VueTrack>());

    /**
     * Creates new form ModuleProfilerFrame
     */
    public ModuleProfilerFrame() {
        initComponents();
        loadOrganisations();
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Journalisation des évènenemts systèmes");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        setLocationRelativeTo(null);
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserActives(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
                Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                if (o != null) {
                    try {
                        loadListUsers(o.getOrganisationID());
                    } catch (Exception e) {
                    }
                    try {
                        loadMachines();
                    } catch (Exception e) {
                    }
                }
            }
        }
    }

    private void loadListUsers(String organisationID) {
        List<Users> list = GrecoServiceFactory.getUserService().getListUsersByOrganisation(organisationID);
        listUsers.clear();
        if (list != null && !list.isEmpty()) {
            for (Users u : list) {
                listUsers.add(u);
            }
        }
    }

    private void loadMachines() {
        List<VueMachine> list = GrecoServiceFactory.getUserService().getListMachine();
        listMachines.clear();
        if (list != null && !list.isEmpty()) {
            for (VueMachine v : list) {
                listMachines.add(v);
            }
        }
    }

    public List<Users> getListUsers() {
        return listUsers;
    }

    public void setListUsers(List<Users> listUsers) {
        this.listUsers = listUsers;
    }

    public List<VueTrack> getListTracks() {
        return listTracks;
    }

    public void setListTracks(List<VueTrack> listTracks) {
        this.listTracks = listTracks;
    }

    public List<VueMachine> getListMachines() {
        return listMachines;
    }

    public void setListMachines(List<VueMachine> listMachines) {
        this.listMachines = listMachines;
    }

    public VueMachine getSelectedMachine() {
        return selectedMachine;
    }

    public void setSelectedMachine(VueMachine selectedMachine) {
        this.selectedMachine = selectedMachine;
    }

    public List<VueTrack> getListTracksMachines() {
        return listTracksMachines;
    }

    public void setListTracksMachines(List<VueTrack> listTracksMachines) {
        this.listTracksMachines = listTracksMachines;
    }

    public List<VueTrack> getListTracksDossiers() {
        return listTracksDossiers;
    }

    public void setListTracksDossiers(List<VueTrack> listTracksDossiers) {
        this.listTracksDossiers = listTracksDossiers;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        pOrganisation = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel1 = new javax.swing.JLabel();
        jDateDebut = new org.jdesktop.swingx.JXDatePicker();
        jLabel2 = new javax.swing.JLabel();
        jDateFin = new org.jdesktop.swingx.JXDatePicker();
        tabbedPane = new javax.swing.JTabbedPane();
        pUtilisateur = new javax.swing.JPanel();
        splitUtilisateur = new javax.swing.JSplitPane();
        scrollListUsers = new javax.swing.JScrollPane();
        jListUtilisateurs = new javax.swing.JList<>();
        scrollListUsersDetails = new javax.swing.JScrollPane();
        tableUtilisateurs = new javax.swing.JTable();
        pUtilisateurOption = new javax.swing.JPanel();
        btnActualiser = new cm.eusoworks.tools.ui.GButton();
        btnImprimer = new javax.swing.JButton();
        pMachine = new javax.swing.JPanel();
        splitMachine = new javax.swing.JSplitPane();
        scrollListMachine = new javax.swing.JScrollPane();
        jListMachine = new javax.swing.JList<>();
        scrollListMachineDetails = new javax.swing.JScrollPane();
        tableMachine = new javax.swing.JTable();
        pMachineOption = new javax.swing.JPanel();
        btnActualiserMachine = new cm.eusoworks.tools.ui.GButton();
        btnImprimerMachine = new javax.swing.JButton();
        pDossiers = new javax.swing.JPanel();
        pDossierOption = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        txtNumDossier = new javax.swing.JTextField();
        btnActualiserDossier = new cm.eusoworks.tools.ui.GButton();
        btnImprimerDossier = new javax.swing.JButton();
        scrollListMachineDetails1 = new javax.swing.JScrollPane();
        tableDossiers = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        pOrganisation.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme/Administration  :");
        jLabel7.setToolTipText("");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel1.setText("Du ");

        jLabel2.setText("au ");

        javax.swing.GroupLayout pOrganisationLayout = new javax.swing.GroupLayout(pOrganisation);
        pOrganisation.setLayout(pOrganisationLayout);
        pOrganisationLayout.setHorizontalGroup(
            pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOrganisationLayout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jLabel7)
                .addGap(5, 5, 5)
                .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jDateDebut, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(39, 39, 39)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jDateFin, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(191, Short.MAX_VALUE))
        );
        pOrganisationLayout.setVerticalGroup(
            pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOrganisationLayout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addComponent(jLabel7))
            .addGroup(pOrganisationLayout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jDateDebut, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel1)
                        .addComponent(jLabel2)
                        .addComponent(jDateFin, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );

        getContentPane().add(pOrganisation, java.awt.BorderLayout.NORTH);

        tabbedPane.setBackground(new java.awt.Color(255, 255, 255));
        tabbedPane.setTabPlacement(javax.swing.JTabbedPane.BOTTOM);
        tabbedPane.setOpaque(true);

        pUtilisateur.setBackground(new java.awt.Color(255, 255, 255));
        pUtilisateur.setLayout(new java.awt.BorderLayout());

        splitUtilisateur.setDividerLocation(300);

        jListUtilisateurs.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jListUtilisateurs.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listUsers}");
        org.jdesktop.swingbinding.JListBinding jListBinding = org.jdesktop.swingbinding.SwingBindings.createJListBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, jListUtilisateurs);
        jListBinding.setDetailBinding(org.jdesktop.beansbinding.ELProperty.create("${nomCompletDecrypt}"));
        bindingGroup.addBinding(jListBinding);
        org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedUser}"), jListUtilisateurs, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jListUtilisateurs.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jListUtilisateursValueChanged(evt);
            }
        });
        scrollListUsers.setViewportView(jListUtilisateurs);

        splitUtilisateur.setLeftComponent(scrollListUsers);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listTracks}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableUtilisateurs);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${lUJ2}"));
        columnBinding.setColumnName("Nom Machine");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${m2M}"));
        columnBinding.setColumnName("Evenement");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${tR78}"));
        columnBinding.setColumnName("Machine");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${r36}"));
        columnBinding.setColumnName("MAT7");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${yU9}"));
        columnBinding.setColumnName("Adresse MAC");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        scrollListUsersDetails.setViewportView(tableUtilisateurs);
        if (tableUtilisateurs.getColumnModel().getColumnCount() > 0) {
            tableUtilisateurs.getColumnModel().getColumn(0).setPreferredWidth(150);
            tableUtilisateurs.getColumnModel().getColumn(1).setPreferredWidth(400);
            tableUtilisateurs.getColumnModel().getColumn(2).setPreferredWidth(200);
            tableUtilisateurs.getColumnModel().getColumn(3).setPreferredWidth(130);
            tableUtilisateurs.getColumnModel().getColumn(4).setPreferredWidth(150);
        }

        splitUtilisateur.setRightComponent(scrollListUsersDetails);

        pUtilisateur.add(splitUtilisateur, java.awt.BorderLayout.CENTER);

        pUtilisateurOption.setBackground(new java.awt.Color(204, 204, 255));
        pUtilisateurOption.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnActualiser.setText("Actualiser");
        btnActualiser.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualiserActionPerformed(evt);
            }
        });
        pUtilisateurOption.add(btnActualiser);

        btnImprimer.setLabel("Imprimer");
        btnImprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimerActionPerformed(evt);
            }
        });
        pUtilisateurOption.add(btnImprimer);

        pUtilisateur.add(pUtilisateurOption, java.awt.BorderLayout.NORTH);

        tabbedPane.addTab("Utilisateurs", pUtilisateur);

        splitMachine.setDividerLocation(350);

        jListMachine.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jListMachine.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listMachines}");
        jListBinding = org.jdesktop.swingbinding.SwingBindings.createJListBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, jListMachine);
        jListBinding.setDetailBinding(org.jdesktop.beansbinding.ELProperty.create("${tR78}"));
        bindingGroup.addBinding(jListBinding);
        binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedMachine}"), jListMachine, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        jListMachine.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jListMachineValueChanged(evt);
            }
        });
        scrollListMachine.setViewportView(jListMachine);

        splitMachine.setLeftComponent(scrollListMachine);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listTracksMachines}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableMachine);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${lUJ2}"));
        columnBinding.setColumnName("Date");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${nM}"));
        columnBinding.setColumnName("Nom Utilisateur");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${pM}"));
        columnBinding.setColumnName("Prenom Utilisateur");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${zZ33}"));
        columnBinding.setColumnName("Compte");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${m2M}"));
        columnBinding.setColumnName("Evenement");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        scrollListMachineDetails.setViewportView(tableMachine);
        if (tableMachine.getColumnModel().getColumnCount() > 0) {
            tableMachine.getColumnModel().getColumn(0).setPreferredWidth(140);
            tableMachine.getColumnModel().getColumn(1).setPreferredWidth(450);
            tableMachine.getColumnModel().getColumn(2).setPreferredWidth(150);
            tableMachine.getColumnModel().getColumn(2).setHeaderValue("MAT7");
            tableMachine.getColumnModel().getColumn(3).setPreferredWidth(150);
            tableMachine.getColumnModel().getColumn(4).setPreferredWidth(150);
        }

        splitMachine.setRightComponent(scrollListMachineDetails);

        pMachineOption.setBackground(new java.awt.Color(204, 204, 255));
        pMachineOption.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT));

        btnActualiserMachine.setText("Actualiser");
        btnActualiserMachine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualiserMachineActionPerformed(evt);
            }
        });
        pMachineOption.add(btnActualiserMachine);

        btnImprimerMachine.setLabel("Imprimer");
        btnImprimerMachine.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimerMachineActionPerformed(evt);
            }
        });
        pMachineOption.add(btnImprimerMachine);

        javax.swing.GroupLayout pMachineLayout = new javax.swing.GroupLayout(pMachine);
        pMachine.setLayout(pMachineLayout);
        pMachineLayout.setHorizontalGroup(
            pMachineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1093, Short.MAX_VALUE)
            .addGroup(pMachineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pMachineLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addGroup(pMachineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addComponent(pMachineOption, javax.swing.GroupLayout.PREFERRED_SIZE, 1093, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(splitMachine, javax.swing.GroupLayout.PREFERRED_SIZE, 1093, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGap(0, 0, Short.MAX_VALUE)))
        );
        pMachineLayout.setVerticalGroup(
            pMachineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 530, Short.MAX_VALUE)
            .addGroup(pMachineLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(pMachineLayout.createSequentialGroup()
                    .addGap(0, 0, Short.MAX_VALUE)
                    .addComponent(pMachineOption, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, 0)
                    .addComponent(splitMachine, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGap(0, 0, Short.MAX_VALUE)))
        );

        tabbedPane.addTab("Machines", pMachine);

        pDossiers.setLayout(new java.awt.BorderLayout());

        pDossierOption.setBackground(new java.awt.Color(204, 204, 255));

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Num. Dossier :");
        pDossierOption.add(jLabel3);

        txtNumDossier.setColumns(15);
        txtNumDossier.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        pDossierOption.add(txtNumDossier);

        btnActualiserDossier.setText("Actualiser");
        btnActualiserDossier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnActualiserDossierActionPerformed(evt);
            }
        });
        pDossierOption.add(btnActualiserDossier);

        btnImprimerDossier.setLabel("Imprimer");
        btnImprimerDossier.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnImprimerDossierActionPerformed(evt);
            }
        });
        pDossierOption.add(btnImprimerDossier);

        pDossiers.add(pDossierOption, java.awt.BorderLayout.NORTH);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listTracksDossiers}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tableDossiers);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${lUJ2}"));
        columnBinding.setColumnName("Date");
        columnBinding.setColumnClass(java.util.Date.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${nM}"));
        columnBinding.setColumnName("Nom");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${pM}"));
        columnBinding.setColumnName("Prenom");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${zZ33}"));
        columnBinding.setColumnName("Compte");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${m2M}"));
        columnBinding.setColumnName("Evenements");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${tR78}"));
        columnBinding.setColumnName("Machine");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${r36}"));
        columnBinding.setColumnName("Adresse IP");
        columnBinding.setColumnClass(String.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${yU9}"));
        columnBinding.setColumnName("adresse MAC");
        columnBinding.setColumnClass(String.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        scrollListMachineDetails1.setViewportView(tableDossiers);
        if (tableDossiers.getColumnModel().getColumnCount() > 0) {
            tableDossiers.getColumnModel().getColumn(0).setPreferredWidth(140);
            tableDossiers.getColumnModel().getColumn(1).setPreferredWidth(150);
            tableDossiers.getColumnModel().getColumn(2).setPreferredWidth(150);
            tableDossiers.getColumnModel().getColumn(3).setPreferredWidth(100);
            tableDossiers.getColumnModel().getColumn(4).setPreferredWidth(450);
            tableDossiers.getColumnModel().getColumn(5).setPreferredWidth(200);
            tableDossiers.getColumnModel().getColumn(6).setPreferredWidth(130);
            tableDossiers.getColumnModel().getColumn(7).setPreferredWidth(150);
        }

        pDossiers.add(scrollListMachineDetails1, java.awt.BorderLayout.CENTER);

        tabbedPane.addTab("Suivi des dossiers", pDossiers);

        getContentPane().add(tabbedPane, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o != null) {
            loadListUsers(o.getOrganisationID());
            try {
                loadMachines();
            } catch (Exception e) {
            }
        }
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void jListUtilisateursValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jListUtilisateursValueChanged
        // TODO add your handling code here:
        if (selectedUser != null) {
            listTracks.clear();
            
            String nom = GrecoSession.USER_CONNECTED.getLogin();
            String lastChar = String.valueOf(GrecoSession.USER_CONNECTED.getLogin().charAt(GrecoSession.USER_CONNECTED.getLogin().length() - 1));
            if (lastChar.equals("\\")) {
                nom = nom.concat("\\");
            }
            List<VueTrack> list = GrecoServiceFactory.getUserService().getTracking(
                    nom,
                    jDateDebut.getDate() == null ? new Date() : jDateDebut.getDate(),
                    jDateFin.getDate() == null ? new Date() : jDateFin.getDate());

            if (list != null) {
                for (VueTrack v : list) {
                    listTracks.add(v);
                }
            }
        }
    }//GEN-LAST:event_jListUtilisateursValueChanged

    private void btnActualiserActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualiserActionPerformed
        // TODO add your handling code here:
        jListUtilisateursValueChanged(null);
    }//GEN-LAST:event_btnActualiserActionPerformed

    private void btnImprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimerActionPerformed
        // TODO add your handling code here:
        imprimerUsers();
    }//GEN-LAST:event_btnImprimerActionPerformed

    private void jListMachineValueChanged(javax.swing.event.ListSelectionEvent evt) {//GEN-FIRST:event_jListMachineValueChanged
        // TODO add your handling code here:
        if (selectedMachine != null) {
            List<VueTrack> list = GrecoServiceFactory.getUserService().getTrackingMachine(
                    selectedMachine.getHost(),
                    jDateDebut.getDate() == null ? new Date() : jDateDebut.getDate(),
                    jDateFin.getDate() == null ? new Date() : jDateFin.getDate());

            listTracksMachines.clear();
            if (list != null && !list.isEmpty()) {
                for (VueTrack v : list) {
                    listTracksMachines.add(v);
                }
            }
        }

    }//GEN-LAST:event_jListMachineValueChanged

    private void btnActualiserMachineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualiserMachineActionPerformed
        // TODO add your handling code here:
        jListMachineValueChanged(null);
    }//GEN-LAST:event_btnActualiserMachineActionPerformed

    private void btnImprimerMachineActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimerMachineActionPerformed
        // TODO add your handling code here:
        imprimerMachines();
    }//GEN-LAST:event_btnImprimerMachineActionPerformed

    private void btnActualiserDossierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnActualiserDossierActionPerformed
        // TODO add your handling code here:
        if (txtNumDossier.getText() != null) {
            List<VueTrack> list = GrecoServiceFactory.getUserService().getTrackingDossier(txtNumDossier.getText());
            listTracksDossiers.clear();
            if (list != null && !list.isEmpty()) {
                for (VueTrack v : list) {
                    listTracksDossiers.add(v);
                }
            }
        } else {
            GrecoOptionPane.showWarningDialog("Veuillez saisir le numero du dossier a consulter");
        }
    }//GEN-LAST:event_btnActualiserDossierActionPerformed

    private void btnImprimerDossierActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnImprimerDossierActionPerformed
        // TODO add your handling code here:
        imprimerDossier();
    }//GEN-LAST:event_btnImprimerDossierActionPerformed

    public void imprimerUsers() {

        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
        Image armoirieCM = null;//new siiResources.Images();
        HashMap parameters = fonctions.mainParameters();
        parameters.put("orgLibelleFr", GrecoAppConfig.getOrgLibelleFr());
        parameters.put("orgLibelleUs", GrecoAppConfig.getOrgLibelleUS());
        parameters.put("armoirieCM", armoirieCM);
        parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
        parameters.put("PARAM_DispositifUS", GrecoAppConfig.getAppTitleUs());
        parameters.put("PARAM_Titre", "Journal des évènements systèmes");
        try {
            parameters.put("appAbreviation", GrecoAppConfig.getAppAbbreviation());
        } catch (Exception e) {
        }
        try {
            parameters.put("objet", "Utilisateur suivi : " + selectedUser.getNomCompletDecrypt());
        } catch (Exception e) {
        }
        try {
            String datedeb = s.format(jDateDebut.getDate() == null ? new Date() : jDateDebut.getDate());
            String datefin = s.format(jDateFin.getDate() == null ? new Date() : jDateFin.getDate());
            parameters.put("periode", "Période du " + datedeb + " au " + datefin);
        } catch (Exception e) {
        }

        JRDataSource dataSource = new JRBeanCollectionDataSource(listTracks);
        try {
            JasperPrint print = JasperFillManager.fillReport(fonctions.tracking(), parameters, dataSource);
            JRHelper.viewReport(print);
        } catch (Exception e) {
            e.printStackTrace();
        }

        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

    }

    public void imprimerMachines() {

        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
        Image armoirieCM = null;//new siiResources.Images();
        HashMap parameters = fonctions.mainParameters();
        parameters.put("orgLibelleFr", GrecoAppConfig.getOrgLibelleFr());
        parameters.put("orgLibelleUs", GrecoAppConfig.getOrgLibelleUS());
        parameters.put("armoirieCM", armoirieCM);
        parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
        parameters.put("PARAM_DispositifUS", GrecoAppConfig.getAppTitleUs());
        parameters.put("PARAM_Titre", "Journal des évènements systèmes");
        try {
            parameters.put("appAbreviation", GrecoAppConfig.getAppAbbreviation());
        } catch (Exception e) {
        }
        try {
            parameters.put("objet", "Machine suivie : " + Crypto.decrypt(selectedMachine.getNomMachine()));
        } catch (Exception e) {
        }
        try {
            String datedeb = s.format(jDateDebut.getDate() == null ? new Date() : jDateDebut.getDate());
            String datefin = s.format(jDateFin.getDate() == null ? new Date() : jDateFin.getDate());
            parameters.put("periode", "Période du " + datedeb + " au " + datefin);
        } catch (Exception e) {
        }

        JRDataSource dataSource = new JRBeanCollectionDataSource(listTracksMachines);
        try {
            JasperPrint print = JasperFillManager.fillReport(fonctions.tracking(), parameters, dataSource);
            JRHelper.viewReport(print);
        } catch (Exception e) {
            e.printStackTrace();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

    }

    public void imprimerDossier() {

        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        SimpleDateFormat s = new SimpleDateFormat("dd/MM/yyyy");
        Image armoirieCM = null;//new siiResources.Images();
        HashMap parameters = fonctions.mainParameters();
        parameters.put("orgLibelleFr", GrecoAppConfig.getOrgLibelleFr());
        parameters.put("orgLibelleUs", GrecoAppConfig.getOrgLibelleUS());
        parameters.put("armoirieCM", armoirieCM);
        parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
        parameters.put("PARAM_DispositifUS", GrecoAppConfig.getAppTitleUs());
        parameters.put("PARAM_Titre", "Journal des évènements systèmes");
        try {
            parameters.put("appAbreviation", GrecoAppConfig.getAppAbbreviation());
        } catch (Exception e) {
        }
        try {
            parameters.put("objet", "Dossier num. : " + txtNumDossier.getText().trim());
        } catch (Exception e) {
        }
        try {
            parameters.put("periode", "");
        } catch (Exception e) {
        }

        JRDataSource dataSource = new JRBeanCollectionDataSource(listTracksDossiers);
        try {
            JasperPrint print = JasperFillManager.fillReport(fonctions.tracking(), parameters, dataSource);
            JRHelper.viewReport(print);
        } catch (Exception e) {
            e.printStackTrace();
        }
        setCursor(new Cursor(Cursor.DEFAULT_CURSOR));

    }

    public Users getSelectedUser() {
        return selectedUser;
    }

    public void setSelectedUser(Users selectedUser) {
        this.selectedUser = selectedUser;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ModuleProfilerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ModuleProfilerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ModuleProfilerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ModuleProfilerFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ModuleProfilerFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnActualiser;
    private cm.eusoworks.tools.ui.GButton btnActualiserDossier;
    private cm.eusoworks.tools.ui.GButton btnActualiserMachine;
    private javax.swing.JButton btnImprimer;
    private javax.swing.JButton btnImprimerDossier;
    private javax.swing.JButton btnImprimerMachine;
    private javax.swing.JComboBox cboOrganisation;
    private org.jdesktop.swingx.JXDatePicker jDateDebut;
    private org.jdesktop.swingx.JXDatePicker jDateFin;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JList<String> jListMachine;
    private javax.swing.JList<String> jListUtilisateurs;
    private javax.swing.JPanel pDossierOption;
    private javax.swing.JPanel pDossiers;
    private javax.swing.JPanel pMachine;
    private javax.swing.JPanel pMachineOption;
    private javax.swing.JPanel pOrganisation;
    private javax.swing.JPanel pUtilisateur;
    private javax.swing.JPanel pUtilisateurOption;
    private javax.swing.JScrollPane scrollListMachine;
    private javax.swing.JScrollPane scrollListMachineDetails;
    private javax.swing.JScrollPane scrollListMachineDetails1;
    private javax.swing.JScrollPane scrollListUsers;
    private javax.swing.JScrollPane scrollListUsersDetails;
    private javax.swing.JSplitPane splitMachine;
    private javax.swing.JSplitPane splitUtilisateur;
    private javax.swing.JTabbedPane tabbedPane;
    private javax.swing.JTable tableDossiers;
    private javax.swing.JTable tableMachine;
    private javax.swing.JTable tableUtilisateurs;
    private javax.swing.JTextField txtNumDossier;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables
}
