/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.CategorieNiveau;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tree.CategorieNode;
import cm.eusoworks.tree.NomenclatureTreeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author macbookair
 */
public class NomenclatureCategorieDialog extends GrecoTemplateDialog {

    private List<CategorieNiveau> listNiveaux;
    NomenclatureDialog md = null;

    /**
     * Creates new form NomenclatureCategorieDialog
     */
    public NomenclatureCategorieDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        tree.putClientProperty("JTree.lineStyle", "None");
        ((BasicTreeUI) tree.getUI()).setExpandedIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/expanded.png")));
        ((BasicTreeUI) tree.getUI()).setCollapsedIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/collapsed.png")));
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Nomenclature des catégories de services ");
        mnuModifier.setText(Locale.getDefault() == Locale.FRENCH ? "Modifier ..." : "Update ...");
        mnuDelete.setText(Locale.getDefault() == Locale.FRENCH ? "Supprimer " : "Delete ");

        mnuNouveau.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nouveauAction();
            }
        });
        mnuModifier.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifierAction();
            }
        });
        mnuDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                supprimerAction();
            }
        });
        loadListNiveau();

        initHierarchie();

        setMinimumSize(new Dimension(445, 448));
        setLocationRelativeTo(null);
    }

    private void nouveauAction() {

        Object parent = tree.getLastSelectedPathComponent();
        if (parent instanceof CategorieNode) {
            md = new NomenclatureDialog(this, true, ((CategorieNode) parent).getCategorie(), null);
            md.setVisible(true);

            CategorieNode n = (CategorieNode) parent;
            CategorieNode fils;
            List<Categorie> l = new ArrayList<>();
            if (n.getCode() == null) {
                l = GrecoServiceFactory.getNomenclatureService().getListCategorieRacines();
            } else {
                l = GrecoServiceFactory.getNomenclatureService().getListCategorieChilds(n.getCode());
            }
            n.removeAllChildren();
            for (Categorie categorie : l) {
                fils = new CategorieNode(categorie);
                if (fils.getCategorie().getNbChilds() > 0) {
                    fils.add(new CategorieNode());
                }
                n.add(fils);
            }
            ((DefaultTreeModel) tree.getModel()).reload(n);
            TreePath path = new TreePath(n.getPath());
            TreeExpansionEvent evt = new TreeExpansionEvent(tree, path);
            try {
                treeTreeWillExpand(evt);
                tree.collapsePath(path);
                tree.expandPath(path);
            } catch (Exception e) {
            }
            tree.scrollPathToVisible(path);
            
            
        }
    }

    private void modifierAction() {
        Object o = tree.getLastSelectedPathComponent();
        if (o instanceof CategorieNode) {
            CategorieNode fils = (CategorieNode) o;
            CategorieNode parent = (CategorieNode) fils.getParent();
            md = new NomenclatureDialog(this, true, parent==null?null:parent.getCategorie(), fils.getCategorie());
            md.setVisible(true);
            ((DefaultTreeModel) tree.getModel()).reload(fils);
        }
    }

    private void supprimerAction() {
        Object o = tree.getLastSelectedPathComponent();
        if (o instanceof CategorieNode) {
            CategorieNode fils = (CategorieNode) o;
            int res = JOptionPane.showConfirmDialog(null, "Etes vous sur de vouloir supprimer ce noeud et son contenu ?\n " + fils.toString(), "GRECO", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                int cf = JOptionPane.showConfirmDialog(null, "Apres suppression, vous ne pourrez plus recuperer les informations.\n\n Etes vous sur de vouloir tout supprimer ?\n " + fils.toString(), "GRECO", JOptionPane.YES_NO_OPTION);
                if (cf == JOptionPane.YES_OPTION) {
                    try {
                        GrecoServiceFactory.getNomenclatureService().supprimerCategorie(fils.getCode());
                        GrecoSession.notifications.success();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                    
                    
                    
                    if (fils.getParent() != null) {
                        TreePath path = new TreePath(fils.getParent());
                        TreeExpansionEvent evt = new TreeExpansionEvent(tree, path);
                        try {
                            treeTreeWillExpand(evt);
                            tree.collapsePath(path);
                            tree.expandPath(path);
                        } catch (Exception e) {
                        }
                        
                        ((DefaultTreeModel) tree.getModel()).reload(fils.getParent());
                        tree.scrollPathToVisible(path);
                        
                    }
                    ((DefaultTreeModel) tree.getModel()).reload(fils);

                    
                }
            }
        }

    }

    private void loadListNiveau() {
        try {
            listNiveaux = GrecoServiceFactory.getNiveauService().listeNiveauCategorie();
        } catch (Exception e) {
            listNiveaux = null;
        }
    }

    private CategorieNiveau findNiveau(int niveau) {
        CategorieNiveau catNiveau = null;
        for (CategorieNiveau c : listNiveaux) {
            if (c.getNiveauCategorieID() == niveau) {
                catNiveau = c;
                break;
            }
        }
        return catNiveau;
    }

    private void initHierarchie() {
        Categorie root = new Categorie("-1");
        root.setCode(null);
        root.setNiveauID(0);
        root.setLibelleFr("Hierarchie des categorie de services");
        root.setLibelleUs("services plan");

        CategorieNode rootNode = new CategorieNode(root);

        List<Categorie> listRacines = new ArrayList<>();
        try {
            listRacines = GrecoServiceFactory.getNomenclatureService().getListCategorieRacines();
        } catch (Exception e) {
            listRacines = null;
        }
        if (listRacines != null && !listRacines.isEmpty()) {
            for (Categorie categorie : listRacines) {
                CategorieNode node = new CategorieNode(categorie);
                if (node.getCategorie().getNbChilds() > 0) {
                    node.add(new CategorieNode());
                }
                rootNode.add(node);
            }
        }

        tree.setModel(new DefaultTreeModel(rootNode));
        tree.setCellRenderer(new NomenclatureTreeRenderer());

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popupMenu = new javax.swing.JPopupMenu();
        mnuNouveau = new javax.swing.JMenuItem();
        mnuModifier = new javax.swing.JMenuItem();
        mnuDelete = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tree = new javax.swing.JTree();

        mnuNouveau.setText("jMenuItem1");

        mnuModifier.setText("jMenuItem1");

        mnuDelete.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Hierarchie des categories de services");

        jPanel1.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT));
        getContentPane().add(jPanel1, java.awt.BorderLayout.NORTH);

        tree.setShowsRootHandles(true);
        tree.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                treeTreeWillExpand(evt);
            }
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
        });
        tree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                treeMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tree);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void treeMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeMouseReleased
        // TODO add your handling code here:
        if (SwingUtilities.isRightMouseButton(evt)) {
            Object o = tree.getLastSelectedPathComponent();
            if (o instanceof CategorieNode) {
                CategorieNode node = (CategorieNode) o;
                //recuperer le niveau du noeud selectionnee
                int niveau = node.getNiveauID();
                if (niveau == 0) {
                    popupMenu.add(mnuNouveau);
                    popupMenu.remove(mnuModifier);
                    popupMenu.remove(mnuDelete);
                } else {
                    popupMenu.add(mnuNouveau);
                    popupMenu.add(mnuModifier);
                    popupMenu.add(mnuDelete);
                }
                niveau++;
                // rechercher le libelle du niveau suivant a creer
                CategorieNiveau niv = findNiveau(niveau);
                if (niv != null) {
                    mnuNouveau.setText((Locale.getDefault() == Locale.FRENCH ? "Ajouter - " : "Add new ") + niv.getLibelle(Locale.getDefault()).toLowerCase());
                } else {
                    popupMenu.remove(mnuNouveau);
                }
                popupMenu.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        }
    }//GEN-LAST:event_treeMouseReleased

    private void treeTreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_treeTreeWillExpand
        // TODO add your handling code here:
        Object o = evt.getPath().getLastPathComponent();
        if (o instanceof CategorieNode) {
            CategorieNode n = (CategorieNode) o;
            CategorieNode fils;
            List<Categorie> l = new ArrayList<>();
            if (n.getCode() == null) {
                l = GrecoServiceFactory.getNomenclatureService().getListCategorieRacines();
            } else {
                l = GrecoServiceFactory.getNomenclatureService().getListCategorieChilds(n.getCode());
            }
            n.removeAllChildren();
            for (Categorie categorie : l) {
                fils = new CategorieNode(categorie);
                if (fils.getCategorie().getNbChilds() > 0) {
                    fils.add(new CategorieNode());
                }
                n.add(fils);
            }
            TreePath path = new TreePath(n.getPath());
            tree.collapsePath(path);
            tree.scrollPathToVisible(new TreePath(n.getPath()));
        }

    }//GEN-LAST:event_treeTreeWillExpand

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCategorieDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCategorieDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCategorieDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCategorieDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                NomenclatureCategorieDialog dialog = new NomenclatureCategorieDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem mnuDelete;
    private javax.swing.JMenuItem mnuModifier;
    private javax.swing.JMenuItem mnuNouveau;
    private javax.swing.JPopupMenu popupMenu;
    private javax.swing.JTree tree;
    // End of variables declaration//GEN-END:variables
}
