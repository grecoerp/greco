/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.CompteNiveau;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tree.CompteNode;
import cm.eusoworks.tree.NomenclatureTreeRenderer;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.TreeExpansionEvent;
import javax.swing.plaf.basic.BasicTreeUI;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 *
 * @author macbookair
 */
public class NomenclatureCompteDialog extends GrecoTemplateDialog {

    private List<CompteNiveau> listNiveaux;
    NomenclatureDialog md = null;
    CompteNode oldRoot;

    /**
     * Creates new form NomenclatureCompteDialog
     */
    public NomenclatureCompteDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        tree.putClientProperty("JTree.lineStyle", "None");
        ((BasicTreeUI) tree.getUI()).setExpandedIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/expanded.png")));
        ((BasicTreeUI) tree.getUI()).setCollapsedIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/collapsed.png")));
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Plan cmptable ");
        mnuModifier.setText(Locale.getDefault() == Locale.FRENCH ? "Modifier ..." : "Update ...");
        mnuDelete.setText(Locale.getDefault() == Locale.FRENCH ? "Supprimer " : "Delete ");

        mnuNouveau.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                nouveauAction();
            }
        });
        mnuModifier.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifierAction();
            }
        });
        mnuDelete.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                supprimerAction();
            }
        });
        loadListNiveau();

        initHierarchie();

        setMinimumSize(new Dimension(545, 650));
        setLocationRelativeTo(null);
    }

    private void nouveauAction() {

        Object parent = tree.getLastSelectedPathComponent();
        if (parent != null && parent instanceof CompteNode) {
            md = new NomenclatureDialog(this, true, ((CompteNode) parent).getCompte(), null);
            md.setVisible(true);

            CompteNode n = (CompteNode) parent;
            CompteNode fils;
            List<Compte> l = new ArrayList<>();
            if (n.getCode() == null) {
                l = GrecoServiceFactory.getNomenclatureService().getListCompteRacines();
            } else {
                l = GrecoServiceFactory.getNomenclatureService().getListCompteChilds(n.getCode());
            }
            n.removeAllChildren();
            for (Compte compte : l) {
                fils = new CompteNode(compte);
                if (fils.getCompte().getNbChilds() > 0) {
                    fils.add(new CompteNode());
                }
                n.add(fils);
            }
            ((DefaultTreeModel) tree.getModel()).reload(n);
            TreePath path = new TreePath(n.getPath());
            TreeExpansionEvent evt = new TreeExpansionEvent(tree, path);
            try {
                treeTreeWillExpand(evt);
                tree.collapsePath(path);
                tree.expandPath(path);
            } catch (Exception e) {
            }
            tree.scrollPathToVisible(path);

        }
    }

    private void modifierAction() {
        Object o = tree.getLastSelectedPathComponent();
        if (o instanceof CompteNode) {
            CompteNode fils = (CompteNode) o;
            CompteNode parent = (CompteNode) fils.getParent();
            md = new NomenclatureDialog(this, true, parent == null ? null : parent.getCompte(), fils.getCompte());
            md.setVisible(true);
            ((DefaultTreeModel) tree.getModel()).reload(fils);
        }
    }

    private void supprimerAction() {
        Object o = tree.getLastSelectedPathComponent();
        if (o instanceof CompteNode) {
            CompteNode fils = (CompteNode) o;
            int res = JOptionPane.showConfirmDialog(null, "Etes vous sur de vouloir supprimer ce noeud et son contenu ?\n " + fils.toString(), "GRECO", JOptionPane.YES_NO_OPTION);
            if (res == JOptionPane.YES_OPTION) {
                int cf = JOptionPane.showConfirmDialog(null, "Apres suppression, vous ne pourrez plus recuperer les informations.\n\n Etes vous sur de vouloir tout supprimer ?\n " + fils.toString(), "GRECO", JOptionPane.YES_NO_OPTION);
                if (cf == JOptionPane.YES_OPTION) {
                    try {
                        GrecoServiceFactory.getNomenclatureService().supprimerCompte(fils.getCode());
                        GrecoSession.notifications.success();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }

                    if (fils.getParent() != null) {
                        TreePath path = new TreePath(fils.getParent());
                        TreeExpansionEvent evt = new TreeExpansionEvent(tree, path);
                        try {
                            treeTreeWillExpand(evt);
                            tree.collapsePath(path);
                            tree.expandPath(path);
                        } catch (Exception e) {
                        }

                        ((DefaultTreeModel) tree.getModel()).reload(fils.getParent());
                        tree.scrollPathToVisible(path);

                    }
                    ((DefaultTreeModel) tree.getModel()).reload(fils);

                }
            }
        }

    }

    private void loadListNiveau() {
        try {
            listNiveaux = GrecoServiceFactory.getNiveauService().listeNiveauCompte();
        } catch (Exception e) {
            listNiveaux = null;
        }
    }

    private CompteNiveau findNiveau(int niveau) {
        CompteNiveau catNiveau = null;
        for (CompteNiveau c : listNiveaux) {
            if (c.getNiveauCompteID() == niveau) {
                catNiveau = c;
                break;
            }
        }
        return catNiveau;
    }

    private void initHierarchie() {
        Compte root = new Compte("-1");
        root.setCode(null);
        root.setNiveauID(0);
        root.setLibelleFr("Plan comptable");
        root.setLibelleUs("accounting plan");

        CompteNode rootNode = new CompteNode(root);

        List<Compte> listRacines = new ArrayList<>();
        try {
            listRacines = GrecoServiceFactory.getNomenclatureService().getListCompteRacines();
        } catch (Exception e) {
            listRacines = null;
        }
        if (listRacines != null && !listRacines.isEmpty()) {
            for (Compte compte : listRacines) {
                CompteNode node = new CompteNode(compte);
                if (node.getCompte().getNbChilds() > 0) {
//                    node.add(new CompteNode());
                    List<Compte> lf = new ArrayList<>();
                    CompteNode fs;
                    lf = GrecoServiceFactory.getNomenclatureService().getListCompteChilds(node.getCode());
                    if (lf != null) {
                        for (Compte c : lf) {
                            fs = new CompteNode(c);
                            if (fs.getCompte().getNbChilds() > 0) {
                                fs.add(new CompteNode());
                            }
                            node.add(fs);
                        }
                    }
                }
                rootNode.add(node);
            }
        }
        oldRoot = rootNode;
        tree.setExpandsSelectedPaths(true);
        tree.setModel(new DefaultTreeModel(rootNode));
        tree.setCellRenderer(new NomenclatureTreeRenderer());

    }

    private CompteNode chargerNodeChilds(CompteNode node) {
        CompteNode n = node;
        n.removeAllChildren();
        List<Compte> l = GrecoServiceFactory.getNomenclatureService().getListCompteChilds(node.getCode());
        if (l != null) {
            for (Compte compte : l) {
                CompteNode fils = new CompteNode(compte);
                if (fils.getCompte().getNbChilds() > 0) {
                    n.add(chargerNodeChilds(fils));
                } else {
                    n.add(fils);
                }
//                node.add(fils);
            }
        }

        return n;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        popupMenu = new javax.swing.JPopupMenu();
        mnuNouveau = new javax.swing.JMenuItem();
        mnuModifier = new javax.swing.JMenuItem();
        mnuDelete = new javax.swing.JMenuItem();
        jPanel1 = new javax.swing.JPanel();
        btnTout = new cm.eusoworks.tools.ui.GButton();
        btn1 = new cm.eusoworks.tools.ui.GButton();
        btn2 = new cm.eusoworks.tools.ui.GButton();
        btn3 = new cm.eusoworks.tools.ui.GButton();
        btn4 = new cm.eusoworks.tools.ui.GButton();
        btn5 = new cm.eusoworks.tools.ui.GButton();
        btn6 = new cm.eusoworks.tools.ui.GButton();
        btn7 = new cm.eusoworks.tools.ui.GButton();
        btn8 = new cm.eusoworks.tools.ui.GButton();
        btn9 = new cm.eusoworks.tools.ui.GButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        tree = new javax.swing.JTree();
        jPanel2 = new javax.swing.JPanel();
        btnAdd = new cm.eusoworks.tools.ui.GButton();

        mnuNouveau.setText("jMenuItem1");

        mnuModifier.setText("jMenuItem1");

        mnuDelete.setText("jMenuItem1");

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Plan comptable");
        getContentPane().setLayout(new java.awt.BorderLayout(0, 3));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(new java.awt.GridLayout(1, 9, 1, 4));

        btnTout.setText("-");
        btnTout.setStyle(1);
        btnTout.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnToutActionPerformed(evt);
            }
        });
        jPanel1.add(btnTout);

        btn1.setText("1");
        btn1.setStyle(2);
        btn1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn1ActionPerformed(evt);
            }
        });
        jPanel1.add(btn1);

        btn2.setText("2");
        btn2.setStyle(2);
        btn2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn2ActionPerformed(evt);
            }
        });
        jPanel1.add(btn2);

        btn3.setText("3");
        btn3.setStyle(2);
        btn3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn3ActionPerformed(evt);
            }
        });
        jPanel1.add(btn3);

        btn4.setText("4");
        btn4.setStyle(2);
        btn4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn4ActionPerformed(evt);
            }
        });
        jPanel1.add(btn4);

        btn5.setText("5");
        btn5.setStyle(2);
        btn5.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn5ActionPerformed(evt);
            }
        });
        jPanel1.add(btn5);

        btn6.setText("6");
        btn6.setStyle(2);
        btn6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn6ActionPerformed(evt);
            }
        });
        jPanel1.add(btn6);

        btn7.setText("7");
        btn7.setStyle(2);
        btn7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn7ActionPerformed(evt);
            }
        });
        jPanel1.add(btn7);

        btn8.setText("8");
        btn8.setStyle(2);
        btn8.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn8ActionPerformed(evt);
            }
        });
        jPanel1.add(btn8);

        btn9.setText("9");
        btn9.setStyle(3);
        btn9.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn9ActionPerformed(evt);
            }
        });
        jPanel1.add(btn9);

        getContentPane().add(jPanel1, java.awt.BorderLayout.NORTH);

        tree.setShowsRootHandles(true);
        tree.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                treeTreeWillExpand(evt);
            }
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
        });
        tree.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                treeMouseReleased(evt);
            }
        });
        jScrollPane1.setViewportView(tree);

        getContentPane().add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 5, 3));

        btnAdd.setText("+");
        btnAdd.setCouleur(2);
        btnAdd.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddActionPerformed(evt);
            }
        });
        jPanel2.add(btnAdd);

        getContentPane().add(jPanel2, java.awt.BorderLayout.SOUTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void treeMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_treeMouseReleased
        // TODO add your handling code here:
        if (SwingUtilities.isRightMouseButton(evt)) {
            Object o = tree.getLastSelectedPathComponent();
            if (o instanceof CompteNode) {
                CompteNode node = (CompteNode) o;
                //recuperer le niveau du noeud selectionnee
                int niveau = node.getNiveauID();
                if (niveau == 0) {
                    popupMenu.add(mnuNouveau);
                    popupMenu.remove(mnuModifier);
                    popupMenu.remove(mnuDelete);
                } else {
                    popupMenu.add(mnuNouveau);
                    popupMenu.add(mnuModifier);
                    popupMenu.add(mnuDelete);
                }
                niveau++;
                // rechercher le libelle du niveau suivant a creer
                CompteNiveau niv = findNiveau(niveau);
                if (niv != null) {
                    mnuNouveau.setText((Locale.getDefault() == Locale.FRENCH ? "Ajouter - " : "Add new ") + niv.getLibelle(Locale.getDefault()).toLowerCase());
                } else {
                    popupMenu.remove(mnuNouveau);
                }
                popupMenu.show(evt.getComponent(), evt.getX(), evt.getY());
            }
        }
    }//GEN-LAST:event_treeMouseReleased

    private void treeTreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_treeTreeWillExpand
        // TODO add your handling code here:
        Object o = evt.getPath().getLastPathComponent();
        if (o instanceof CompteNode) {
            CompteNode n = (CompteNode) o;
            CompteNode fils;

            List<Compte> l = new ArrayList<>();

            if (n.getCode() == null) {
                l = GrecoServiceFactory.getNomenclatureService().getListCompteRacines();
            } else {
                l = GrecoServiceFactory.getNomenclatureService().getListCompteChilds(n.getCode());
            }
            n.removeAllChildren();
            for (Compte compte : l) {
                fils = new CompteNode(compte);
                if (fils.getCompte().getNbChilds() > 0) {
                    fils.add(new CompteNode());
                }
                n.add(fils);
            }
            TreePath path = new TreePath(n.getPath());
            tree.collapsePath(path);
            tree.scrollPathToVisible(new TreePath(n.getPath()));
        }

    }//GEN-LAST:event_treeTreeWillExpand

    private void btnAddActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddActionPerformed
        // TODO add your handling code here:
        nouveauAction();
    }//GEN-LAST:event_btnAddActionPerformed

    private void showPlanReduit(String value) {
        Compte r = new Compte("-1");
        r.setCode(null);
        r.setNiveauID(0);
        r.setLibelleFr("Aucune classe ");
        r.setLibelleUs("no corresponding accounting plan");
        CompteNode newRoot = new CompteNode(r);

        CompteNode root = oldRoot;
        int childs = root.getChildCount();
        CompteNode node = null;
        for (int j = 0; j < childs; j++) {
            node = (CompteNode) root.getChildAt(j);
            if (node != null) {
                String code = node.getCode();
                if (code.equals(value)) {
                    newRoot = node;
                    break;
                }
            }
        }
        tree.setModel(new DefaultTreeModel(newRoot));
        //tree.expandRow(0);

    }

    private void btn1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn1ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("1");
    }//GEN-LAST:event_btn1ActionPerformed

    private void btn2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn2ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("2");
    }//GEN-LAST:event_btn2ActionPerformed

    private void btn3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn3ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("3");
    }//GEN-LAST:event_btn3ActionPerformed

    private void btn4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn4ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("4");
    }//GEN-LAST:event_btn4ActionPerformed

    private void btn5ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn5ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("5");
    }//GEN-LAST:event_btn5ActionPerformed

    private void btn6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn6ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("6");
    }//GEN-LAST:event_btn6ActionPerformed

    private void btn7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn7ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("7");
    }//GEN-LAST:event_btn7ActionPerformed

    private void btn8ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn8ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("8");
    }//GEN-LAST:event_btn8ActionPerformed

    private void btn9ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn9ActionPerformed
        // TODO add your handling code here:
        showPlanReduit("9");
    }//GEN-LAST:event_btn9ActionPerformed

    private void btnToutActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnToutActionPerformed
        // TODO add your handling code here:
        tree.setModel(new DefaultTreeModel(oldRoot));
        tree.expandRow(0);
    }//GEN-LAST:event_btnToutActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCompteDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCompteDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCompteDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NomenclatureCompteDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                NomenclatureCompteDialog dialog = new NomenclatureCompteDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btn1;
    private cm.eusoworks.tools.ui.GButton btn2;
    private cm.eusoworks.tools.ui.GButton btn3;
    private cm.eusoworks.tools.ui.GButton btn4;
    private cm.eusoworks.tools.ui.GButton btn5;
    private cm.eusoworks.tools.ui.GButton btn6;
    private cm.eusoworks.tools.ui.GButton btn7;
    private cm.eusoworks.tools.ui.GButton btn8;
    private cm.eusoworks.tools.ui.GButton btn9;
    private cm.eusoworks.tools.ui.GButton btnAdd;
    private cm.eusoworks.tools.ui.GButton btnTout;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem mnuDelete;
    private javax.swing.JMenuItem mnuModifier;
    private javax.swing.JMenuItem mnuNouveau;
    private javax.swing.JPopupMenu popupMenu;
    private javax.swing.JTree tree;
    // End of variables declaration//GEN-END:variables
}
