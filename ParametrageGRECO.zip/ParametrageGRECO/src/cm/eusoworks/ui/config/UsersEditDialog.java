/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Users;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Exercice;
import cm.eusoworks.entities.model.Modules;
import cm.eusoworks.entities.model.Systeme;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.entities.security.Crypto;
import cm.eusoworks.entities.view.VueEntiteReduit;
import cm.eusoworks.renderer.BooleanTableRenderer;
import cm.eusoworks.tools.ui.GButton;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.tree.ProfilTreeModel;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Cursor;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import org.jdesktop.observablecollections.ObservableCollections;

/**
 *
 * @author macbookair
 */
public class UsersEditDialog extends GrecoTemplateDialog {

    public Users user;
    private boolean actif = false;

    List<VueEntiteReduit> listOrganisation = ObservableCollections.observableList(new ArrayList<VueEntiteReduit>());
    List<VueEntiteReduit> listStructures = ObservableCollections.observableList(new ArrayList<VueEntiteReduit>());
    List<VueEntiteReduit> listSourceFinancements = ObservableCollections.observableList(new ArrayList<VueEntiteReduit>());
    List<VueEntiteReduit> listProgramme = ObservableCollections.observableList(new ArrayList<VueEntiteReduit>());
    List<VueEntiteReduit> listSousProgramme = ObservableCollections.observableList(new ArrayList<VueEntiteReduit>());

    VueEntiteReduit selectedOrganisation;
    VueEntiteReduit selectedProgramme;

    String old_organisationID = "";
    BooleanTableRenderer booleanTableRenderer = new BooleanTableRenderer();

    public UsersEditDialog(JFrame parent, boolean modal, Users user) {
        super(parent, modal);
        initComponents();
        this.user = user;
//        loadOrganisations();
        initUI();
        initOrganisation();
        initSourceFinancement();
        initProfils();
        loadExercicesBudgetisation();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Utilisateur ");
        //setPreferredSize(new Dimension(500, 520));
        pack();
    }

    private void loadExercicesBudgetisation() {
        List<Exercice> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getExerciceService().getListExerciceBudgetisation();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboExercice.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboExercice.setSelectedIndex(0);
            }
        }
    }

    private void initOrganisation() {
        List<VueEntiteReduit> list = GrecoServiceFactory.getUserService().userOrganisationList(GrecoSession.USER_CONNECTED.getLogin(), user == null ? null : user.getLogin());
        if (list != null && !list.isEmpty()) {
            listOrganisation.clear();
            for (VueEntiteReduit v : list) {
                listOrganisation.add(v);
            }
        }
    }

    private void initSourceFinancement() {
        try {
            List<VueEntiteReduit> list = GrecoServiceFactory.getUserService().userSourceFinancementList(GrecoSession.USER_CONNECTED.getLogin(), user == null ? null : user.getLogin());
            if (list != null && !list.isEmpty()) {
                listSourceFinancements.clear();
                for (VueEntiteReduit v : list) {
                    listSourceFinancements.add(v);
                }
            }
        } catch (GrecoException ex) {
            ManageException.show(ex, Locale.getDefault());
        }
    }

    private void initProfils() {
        treeProfil.setModel(getRoot());
        treeProfil.setRootVisible(true);
    }

    private DefaultTreeModel getRoot() {
        TreeNode aRoot = null;
        aRoot = getSystemRootNode();

        ProfilTreeModel model = new ProfilTreeModel(aRoot);
        return model;
    }

    private TreeNode getSystemRootNode() {
        ProfilTreeNode node = new ProfilTreeNode();
        List<Systeme> list = GrecoServiceFactory.getSystemeService().getSystemeListByLogin(GrecoSession.USER_CONNECTED.getLogin());
        if (list != null && !list.isEmpty()) {
            for (Systeme s : list) {
                ProfilTreeNode p = new ProfilTreeNode(s);
                p.add(new ProfilTreeNode());
                node.add(p);
            }
        }
        return node;
    }

    private void initUI() {
        if (user == null) {
            txtService.setText("");
            txtLogin.setText("");
            txtPassword.setText("");
            txtNom.setText("");
            txtPrenom.setText("");
            txtMatricule.setText("");
            txtFonction.setText("");
            actif = true;
        } else {
            txtService.setText(user.getServiceDecrypt());
            txtLogin.setText(user.getLoginDecrypt());
            txtLogin.setEnabled(false);
            txtPassword.setText(user.getPassword());
            txtNom.setText(user.getNomDecrypt());
            txtPrenom.setText(user.getPrenomDecrypt());
            txtMatricule.setText(user.getImmatriculationDecrypt());
            txtFonction.setText(user.getFonctionDecrypt());
            actif = user.getActif();

            //social networks
            socialPanel.setFacebook(Crypto.decrypt(user.getFacebook()));
            socialPanel.setWhatsapp(Crypto.decrypt(user.getWhatsapp()));
            socialPanel.setTwitter(Crypto.decrypt(user.getTwitter()));
            socialPanel.setLinkedln(Crypto.decrypt(user.getLinkedln()));
            socialPanel.setGoogleplus(Crypto.decrypt(user.getGoogleplus()));
            socialPanel.setEmail(Crypto.decrypt(user.getEmail()));
            socialPanel.setTelephone(Crypto.decrypt(user.getTelephone()));
        }
        actifLabel();
    }

    public List<VueEntiteReduit> getListOrganisation() {
        return listOrganisation;
    }

    public void setListOrganisation(List<VueEntiteReduit> listOrganisation) {
        this.listOrganisation = listOrganisation;
    }

    public VueEntiteReduit getSelectedOrganisation() {
        return selectedOrganisation;
    }

    public void setSelectedOrganisation(VueEntiteReduit selectedOrganisation) {
        this.selectedOrganisation = selectedOrganisation;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        bindingGroup = new org.jdesktop.beansbinding.BindingGroup();

        pOptions = new javax.swing.JPanel();
        btnInfos = new cm.eusoworks.tools.ui.GButton();
        btnOrganisation = new cm.eusoworks.tools.ui.GButton();
        btnProgramme = new cm.eusoworks.tools.ui.GButton();
        btnSourceFinancement = new cm.eusoworks.tools.ui.GButton();
        btnProfils = new cm.eusoworks.tools.ui.GButton();
        jPanel3 = new javax.swing.JPanel();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        loginLabel = new javax.swing.JLabel();
        txtLogin = new javax.swing.JTextField();
        passwordLabel = new javax.swing.JLabel();
        nomLabel = new javax.swing.JLabel();
        txtNom = new javax.swing.JTextField();
        prenomLabel = new javax.swing.JLabel();
        txtPrenom = new javax.swing.JTextField();
        immatriculationLabel = new javax.swing.JLabel();
        txtMatricule = new javax.swing.JTextField();
        fonctionLabel = new javax.swing.JLabel();
        txtFonction = new javax.swing.JTextField();
        serviceLabel = new javax.swing.JLabel();
        txtService = new javax.swing.JTextField();
        txtPassword = new javax.swing.JPasswordField();
        lblActif = new javax.swing.JLabel();
        chkReinitialiser = new javax.swing.JCheckBox();
        socialPanel = new cm.eusoworks.ui.config.UserSocialPanel();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        btnAnnuler = new cm.eusoworks.tools.ui.GButton();
        pOrganisation = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tblOrganisation = new javax.swing.JTable();
        jLabel2 = new javax.swing.JLabel();
        chkStructure = new javax.swing.JCheckBox();
        jScrollPane2 = new javax.swing.JScrollPane();
        tblStructure = new javax.swing.JTable();
        btnEnregistrerStructure = new cm.eusoworks.tools.ui.GButton();
        btnEnregistrerOrganisation = new cm.eusoworks.tools.ui.GButton();
        pProgramme = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        cboExercice = new javax.swing.JComboBox();
        jLabel5 = new javax.swing.JLabel();
        jScrollPane5 = new javax.swing.JScrollPane();
        tblProgramme = new javax.swing.JTable();
        btnEnregistrerProgramme = new cm.eusoworks.tools.ui.GButton();
        jLabel6 = new javax.swing.JLabel();
        chkSousProgramme = new javax.swing.JCheckBox();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblAction = new javax.swing.JTable();
        btnEnregistrerAction = new cm.eusoworks.tools.ui.GButton();
        pFinancement = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        chkSourceFinancement = new javax.swing.JCheckBox();
        jScrollPane3 = new javax.swing.JScrollPane();
        tblSourceFinancement = new javax.swing.JTable();
        btnEnregistrerSourceFinancement = new cm.eusoworks.tools.ui.GButton();
        pAutorisation = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        treeProfil = new javax.swing.JTree();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        setResizable(false);

        pOptions.setBackground(new java.awt.Color(252, 252, 252));
        pOptions.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 0, 5));

        btnInfos.setText("Infos");
        btnInfos.setName("details"); // NOI18N
        btnInfos.setStyle(1);
        btnInfos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnInfosActionPerformed(evt);
            }
        });
        pOptions.add(btnInfos);

        btnOrganisation.setText("Organisation");
        btnOrganisation.setName("organisation"); // NOI18N
        btnOrganisation.setStyle(5);
        btnOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnOrganisationActionPerformed(evt);
            }
        });
        pOptions.add(btnOrganisation);

        btnProgramme.setText("Programmes");
        btnProgramme.setName("programme"); // NOI18N
        btnProgramme.setStyle(5);
        btnProgramme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProgrammeActionPerformed(evt);
            }
        });
        pOptions.add(btnProgramme);

        btnSourceFinancement.setText("Financements");
        btnSourceFinancement.setName("financement"); // NOI18N
        btnSourceFinancement.setStyle(5);
        btnSourceFinancement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSourceFinancementActionPerformed(evt);
            }
        });
        pOptions.add(btnSourceFinancement);

        btnProfils.setText("Autorisations");
        btnProfils.setName("autorisation"); // NOI18N
        btnProfils.setStyle(5);
        btnProfils.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnProfilsActionPerformed(evt);
            }
        });
        pOptions.add(btnProfils);

        getContentPane().add(pOptions, java.awt.BorderLayout.PAGE_START);

        jPanel3.setLayout(new java.awt.CardLayout());

        pDetails.setBorder(javax.swing.BorderFactory.createEtchedBorder());
        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        loginLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        loginLabel.setText("Login:");

        passwordLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        passwordLabel.setText("Password:");

        nomLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        nomLabel.setText("Nom:");

        prenomLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        prenomLabel.setText("Prenom:");

        immatriculationLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        immatriculationLabel.setText("Matricule:");

        fonctionLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        fonctionLabel.setText("Fonction:");

        serviceLabel.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        serviceLabel.setText("Service:");

        lblActif.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        lblActif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/radioSelect.png"))); // NOI18N
        lblActif.setText("utilisateur actif ?");
        lblActif.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblActifMouseClicked(evt);
            }
        });

        chkReinitialiser.setText("reinitialiser");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(serviceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(14, 14, 14)
                        .addComponent(txtService, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(loginLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(25, 25, 25)
                        .addComponent(txtLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(10, 10, 10)
                        .addComponent(passwordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 88, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(253, 253, 253)
                        .addComponent(chkReinitialiser, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(nomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 60, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(22, 22, 22)
                        .addComponent(txtNom, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(prenomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(txtPrenom, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(immatriculationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(2, 2, 2)
                        .addComponent(txtMatricule, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(fonctionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(12, 12, 12)
                        .addComponent(txtFonction, javax.swing.GroupLayout.PREFERRED_SIZE, 270, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(130, 130, 130)
                        .addComponent(lblActif, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(socialPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(12, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(socialPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(4, 4, 4)
                                .addComponent(serviceLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtService, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(loginLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtLogin, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(passwordLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtPassword, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addComponent(chkReinitialiser, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(20, 20, 20)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(nomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtNom, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(6, 6, 6)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(2, 2, 2)
                                .addComponent(prenomLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtPrenom, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(2, 2, 2)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(immatriculationLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtMatricule, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGap(12, 12, 12)
                                .addComponent(fonctionLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(txtFonction, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(20, 20, 20)
                        .addComponent(lblActif, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.setCouleur(2);
        btnEnregistrer.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });

        btnAnnuler.setText("Fermer");
        btnAnnuler.setCouleur(3);
        btnAnnuler.setFont(new java.awt.Font("Tahoma", 0, 13)); // NOI18N
        btnAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 511, Short.MAX_VALUE)
                .addComponent(btnAnnuler, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel2Layout.createSequentialGroup()
                        .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 27, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(btnAnnuler, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        jPanel3.add(pDetails, "details");

        pOrganisation.setBackground(new java.awt.Color(249, 249, 249));
        pOrganisation.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel1.setText("Liste des organisations / entités sur lesquelles l'utilisateur est habilité à effectuer des opérations  ");

        tblOrganisation.setRowHeight(22);

        org.jdesktop.beansbinding.ELProperty eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listOrganisation}");
        org.jdesktop.swingbinding.JTableBinding jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblOrganisation);
        org.jdesktop.swingbinding.JTableBinding.ColumnBinding columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("Droit");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Organisation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${ordonnateur}"));
        columnBinding.setColumnName("Ordonnateur");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${controleur}"));
        columnBinding.setColumnName("Controleur");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${comptable}"));
        columnBinding.setColumnName("Comptable");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${gestion}"));
        columnBinding.setColumnName("Ctrl. Gestion");
        columnBinding.setColumnClass(Boolean.class);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();org.jdesktop.beansbinding.Binding binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedOrganisation}"), tblOrganisation, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tblOrganisation.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblOrganisationMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tblOrganisation);
        if (tblOrganisation.getColumnModel().getColumnCount() > 0) {
            tblOrganisation.getColumnModel().getColumn(0).setResizable(false);
            tblOrganisation.getColumnModel().getColumn(0).setPreferredWidth(15);
            tblOrganisation.getColumnModel().getColumn(1).setPreferredWidth(700);
            tblOrganisation.getColumnModel().getColumn(2).setResizable(false);
            tblOrganisation.getColumnModel().getColumn(2).setPreferredWidth(30);
            tblOrganisation.getColumnModel().getColumn(2).setCellRenderer(new BooleanTableRenderer());
            tblOrganisation.getColumnModel().getColumn(3).setResizable(false);
            tblOrganisation.getColumnModel().getColumn(3).setPreferredWidth(30);
            tblOrganisation.getColumnModel().getColumn(3).setCellRenderer(new BooleanTableRenderer());
            tblOrganisation.getColumnModel().getColumn(4).setResizable(false);
            tblOrganisation.getColumnModel().getColumn(4).setPreferredWidth(30);
            tblOrganisation.getColumnModel().getColumn(4).setCellRenderer(new BooleanTableRenderer());
            tblOrganisation.getColumnModel().getColumn(5).setResizable(false);
            tblOrganisation.getColumnModel().getColumn(5).setPreferredWidth(30);
            tblOrganisation.getColumnModel().getColumn(5).setCellRenderer(new BooleanTableRenderer());
        }

        jLabel2.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("Liste des structures ");

        chkStructure.setForeground(new java.awt.Color(51, 51, 51));
        chkStructure.setText("Cocher tous ");
        chkStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkStructureActionPerformed(evt);
            }
        });

        tblStructure.setForeground(new java.awt.Color(0, 102, 204));
        tblStructure.setRowHeight(20);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listStructures}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblStructure);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("Droit");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Désignation");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane2.setViewportView(tblStructure);
        if (tblStructure.getColumnModel().getColumnCount() > 0) {
            tblStructure.getColumnModel().getColumn(0).setResizable(false);
            tblStructure.getColumnModel().getColumn(0).setPreferredWidth(20);
            tblStructure.getColumnModel().getColumn(1).setPreferredWidth(700);
        }

        btnEnregistrerStructure.setText("Enregistrer");
        btnEnregistrerStructure.setCouleur(2);
        btnEnregistrerStructure.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerStructureActionPerformed(evt);
            }
        });

        btnEnregistrerOrganisation.setText("Enregistrer");
        btnEnregistrerOrganisation.setCouleur(2);
        btnEnregistrerOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerOrganisationActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pOrganisationLayout = new javax.swing.GroupLayout(pOrganisation);
        pOrganisation.setLayout(pOrganisationLayout);
        pOrganisationLayout.setHorizontalGroup(
            pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOrganisationLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pOrganisationLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnEnregistrerOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(33, 33, 33))
                    .addGroup(pOrganisationLayout.createSequentialGroup()
                        .addGroup(pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane1)
                            .addComponent(jScrollPane2))
                        .addContainerGap())
                    .addGroup(pOrganisationLayout.createSequentialGroup()
                        .addGroup(pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel1)
                            .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chkStructure, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(18, Short.MAX_VALUE))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pOrganisationLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEnregistrerStructure, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33))
        );
        pOrganisationLayout.setVerticalGroup(
            pOrganisationLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOrganisationLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEnregistrerOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chkStructure)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEnregistrerStructure, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(42, Short.MAX_VALUE))
        );

        jPanel3.add(pOrganisation, "organisation");

        pProgramme.setBackground(new java.awt.Color(249, 249, 249));
        pProgramme.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Exercice : ");

        cboExercice.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboExercice.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboExerciceActionPerformed(evt);
            }
        });

        jLabel5.setText("Liste des Programmes sur lesquels l'utilisateur est habilité");

        tblProgramme.setRowHeight(22);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listProgramme}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblProgramme);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("Checked");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Libelle");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();binding = org.jdesktop.beansbinding.Bindings.createAutoBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, org.jdesktop.beansbinding.ELProperty.create("${selectedProgramme}"), tblProgramme, org.jdesktop.beansbinding.BeanProperty.create("selectedElement"));
        bindingGroup.addBinding(binding);

        tblProgramme.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblProgrammeMouseClicked(evt);
            }
        });
        jScrollPane5.setViewportView(tblProgramme);
        if (tblProgramme.getColumnModel().getColumnCount() > 0) {
            tblProgramme.getColumnModel().getColumn(0).setResizable(false);
            tblProgramme.getColumnModel().getColumn(0).setPreferredWidth(15);
            tblProgramme.getColumnModel().getColumn(1).setPreferredWidth(700);
        }

        btnEnregistrerProgramme.setText("Enregistrer");
        btnEnregistrerProgramme.setCouleur(2);
        btnEnregistrerProgramme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerProgrammeActionPerformed(evt);
            }
        });

        jLabel6.setFont(new java.awt.Font("Lucida Grande", 0, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(0, 102, 204));
        jLabel6.setText("Liste des actions/sous-programmes ");

        chkSousProgramme.setForeground(new java.awt.Color(51, 51, 51));
        chkSousProgramme.setText("Cocher tous ");
        chkSousProgramme.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSousProgrammeActionPerformed(evt);
            }
        });

        tblAction.setForeground(new java.awt.Color(0, 102, 204));
        tblAction.setRowHeight(20);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listSousProgramme}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblAction);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("Checked");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Libelle");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane6.setViewportView(tblAction);
        if (tblAction.getColumnModel().getColumnCount() > 0) {
            tblAction.getColumnModel().getColumn(0).setResizable(false);
            tblAction.getColumnModel().getColumn(0).setPreferredWidth(20);
            tblAction.getColumnModel().getColumn(1).setPreferredWidth(700);
        }

        btnEnregistrerAction.setText("Enregistrer");
        btnEnregistrerAction.setCouleur(2);
        btnEnregistrerAction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pProgrammeLayout = new javax.swing.GroupLayout(pProgramme);
        pProgramme.setLayout(pProgrammeLayout);
        pProgrammeLayout.setHorizontalGroup(
            pProgrammeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pProgrammeLayout.createSequentialGroup()
                .addGap(130, 130, 130)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(pProgrammeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pProgrammeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pProgrammeLayout.createSequentialGroup()
                        .addGroup(pProgrammeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chkSousProgramme, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 681, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pProgrammeLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addComponent(btnEnregistrerProgramme, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(27, 27, 27))
                    .addGroup(pProgrammeLayout.createSequentialGroup()
                        .addGroup(pProgrammeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jScrollPane5)
                            .addComponent(jScrollPane6))
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pProgrammeLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEnregistrerAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(25, 25, 25))
        );
        pProgrammeLayout.setVerticalGroup(
            pProgrammeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pProgrammeLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pProgrammeLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pProgrammeLayout.createSequentialGroup()
                        .addGap(3, 3, 3)
                        .addComponent(cboExercice, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEnregistrerProgramme, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chkSousProgramme)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 144, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEnregistrerAction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(69, Short.MAX_VALUE))
        );

        jPanel3.add(pProgramme, "programme");

        pFinancement.setBackground(new java.awt.Color(249, 249, 249));
        pFinancement.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        jLabel3.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(153, 0, 153));
        jLabel3.setText("Liste des sources de financements  ");

        chkSourceFinancement.setForeground(new java.awt.Color(51, 51, 51));
        chkSourceFinancement.setText("Cocher tous ");
        chkSourceFinancement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                chkSourceFinancementActionPerformed(evt);
            }
        });

        tblSourceFinancement.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        tblSourceFinancement.setForeground(new java.awt.Color(102, 0, 153));
        tblSourceFinancement.setRowHeight(22);

        eLProperty = org.jdesktop.beansbinding.ELProperty.create("${listSourceFinancements}");
        jTableBinding = org.jdesktop.swingbinding.SwingBindings.createJTableBinding(org.jdesktop.beansbinding.AutoBinding.UpdateStrategy.READ_WRITE, this, eLProperty, tblSourceFinancement);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${checked}"));
        columnBinding.setColumnName("Droit");
        columnBinding.setColumnClass(Boolean.class);
        columnBinding = jTableBinding.addColumnBinding(org.jdesktop.beansbinding.ELProperty.create("${libelle}"));
        columnBinding.setColumnName("Libelle");
        columnBinding.setColumnClass(String.class);
        columnBinding.setEditable(false);
        bindingGroup.addBinding(jTableBinding);
        jTableBinding.bind();
        jScrollPane3.setViewportView(tblSourceFinancement);
        if (tblSourceFinancement.getColumnModel().getColumnCount() > 0) {
            tblSourceFinancement.getColumnModel().getColumn(0).setResizable(false);
            tblSourceFinancement.getColumnModel().getColumn(0).setPreferredWidth(20);
            tblSourceFinancement.getColumnModel().getColumn(1).setPreferredWidth(500);
            tblSourceFinancement.getColumnModel().getColumn(1).setHeaderValue("Code");
        }

        btnEnregistrerSourceFinancement.setText("Enregistrer");
        btnEnregistrerSourceFinancement.setCouleur(2);
        btnEnregistrerSourceFinancement.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerSourceFinancementActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pFinancementLayout = new javax.swing.GroupLayout(pFinancement);
        pFinancement.setLayout(pFinancementLayout);
        pFinancementLayout.setHorizontalGroup(
            pFinancementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFinancementLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pFinancementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pFinancementLayout.createSequentialGroup()
                        .addGroup(pFinancementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 720, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chkSourceFinancement, javax.swing.GroupLayout.PREFERRED_SIZE, 685, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(18, 18, 18))
                    .addGroup(pFinancementLayout.createSequentialGroup()
                        .addComponent(jScrollPane3)
                        .addContainerGap())))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pFinancementLayout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btnEnregistrerSourceFinancement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(28, 28, 28))
        );
        pFinancementLayout.setVerticalGroup(
            pFinancementLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pFinancementLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 26, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(chkSourceFinancement)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 179, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btnEnregistrerSourceFinancement, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(272, Short.MAX_VALUE))
        );

        jPanel3.add(pFinancement, "financement");

        pAutorisation.setLayout(new java.awt.BorderLayout());

        treeProfil.addTreeWillExpandListener(new javax.swing.event.TreeWillExpandListener() {
            public void treeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
                treeProfilTreeWillExpand(evt);
            }
            public void treeWillCollapse(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {
            }
        });
        jScrollPane4.setViewportView(treeProfil);

        pAutorisation.add(jScrollPane4, java.awt.BorderLayout.CENTER);

        jPanel3.add(pAutorisation, "autorisation");

        getContentPane().add(jPanel3, java.awt.BorderLayout.CENTER);

        bindingGroup.bind();

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblActifMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblActifMouseClicked
        // TODO add your handling code here:
        actif = !actif;
        actifLabel();
    }//GEN-LAST:event_lblActifMouseClicked

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        enregistrer();
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerActionPerformed
        // TODO add your handling code here:
        this.dispose();
    }//GEN-LAST:event_btnAnnulerActionPerformed

    private void btnOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnOrganisationActionPerformed
        // TODO add your handling code here:
        changeButton(evt);
    }//GEN-LAST:event_btnOrganisationActionPerformed

    private void btnInfosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnInfosActionPerformed
        // TODO add your handling code here:
        changeButton(evt);
    }//GEN-LAST:event_btnInfosActionPerformed

    private void btnSourceFinancementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSourceFinancementActionPerformed
        // TODO add your handling code here:
        changeButton(evt);
    }//GEN-LAST:event_btnSourceFinancementActionPerformed

    private void btnProfilsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProfilsActionPerformed
        // TODO add your handling code here:
        changeButton(evt);
    }//GEN-LAST:event_btnProfilsActionPerformed

    private void btnEnregistrerOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerOrganisationActionPerformed
        // TODO add your handling code here:
        enregistrerOrganisation();
    }//GEN-LAST:event_btnEnregistrerOrganisationActionPerformed

    private void tblOrganisationMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblOrganisationMouseClicked
        // TODO add your handling code here:
        afficherStructures();
    }//GEN-LAST:event_tblOrganisationMouseClicked

    private void chkStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkStructureActionPerformed
        selectAllStructures();
    }//GEN-LAST:event_chkStructureActionPerformed

    private void btnEnregistrerStructureActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerStructureActionPerformed
        // TODO add your handling code here:
        enregistrerStructures();
    }//GEN-LAST:event_btnEnregistrerStructureActionPerformed

    private void chkSourceFinancementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSourceFinancementActionPerformed
        // TODO add your handling code here:
        selectAllSourceFinancement();
    }//GEN-LAST:event_chkSourceFinancementActionPerformed

    private void btnEnregistrerSourceFinancementActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerSourceFinancementActionPerformed
        // TODO add your handling code here:
        enregistrerSourceFinancement();
    }//GEN-LAST:event_btnEnregistrerSourceFinancementActionPerformed

    private void treeProfilTreeWillExpand(javax.swing.event.TreeExpansionEvent evt)throws javax.swing.tree.ExpandVetoException {//GEN-FIRST:event_treeProfilTreeWillExpand
        // TODO add your handling code here:
        setCursor(new Cursor(Cursor.WAIT_CURSOR));
        Object o = evt.getPath().getLastPathComponent();
        try {
            if (o instanceof ProfilTreeNode) {
                ProfilTreeNode node = (ProfilTreeNode) o;
                Object ob = node.getUserObject();
                if (ob instanceof Systeme) {
                    Systeme s = (Systeme) ob;
                    List<Modules> list = GrecoServiceFactory.getSystemeService().getModuleListWithHabilitation(GrecoSession.USER_CONNECTED.getLogin(), s.getSystemeID());
                    if (list != null && !list.isEmpty()) {
                        node.removeAllChildren();
                        for (Modules m : list) {
                            node.add(new ProfilTreeNode(m));
                        }
                    }
                }
            }
        } catch (Exception e) {
        }
    }//GEN-LAST:event_treeProfilTreeWillExpand

    private void loadProgrammes() {
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            try {
                List<VueEntiteReduit> list = GrecoServiceFactory.getUserService().userProgrammeList(GrecoSession.USER_CONNECTED.getLogin(), user == null ? null : user.getLogin(), e.getMillesime());
                listProgramme.clear();
                if (list != null && !list.isEmpty()) {
                    for (VueEntiteReduit v : list) {
                        listProgramme.add(v);
                    }
                }
            } catch (GrecoException ex) {
                ManageException.show(ex, Locale.getDefault());
            }
        }

    }

    private void afficherSousProgrammes() {
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        if (e != null) {
            if (selectedProgramme != null) {
                try {
                    List<VueEntiteReduit> list = GrecoServiceFactory.getUserService().userProgrammeActionList(GrecoSession.USER_CONNECTED.getLogin(), user == null ? null : user.getLogin(),
                            selectedProgramme.getId(), e.getMillesime());
                    listSousProgramme.clear();
                    if (list != null && !list.isEmpty()) {
                        for (VueEntiteReduit v : list) {
                            listSousProgramme.add(v);
                        }
                    }
                } catch (GrecoException ex) {
                    ManageException.show(ex, Locale.getDefault());
                }
            }
        }

    }


    private void btnProgrammeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnProgrammeActionPerformed
        // TODO add your handling code here:
        changeButton(evt);
    }//GEN-LAST:event_btnProgrammeActionPerformed

    private void cboExerciceActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboExerciceActionPerformed
        // TODO add your handling code here:
        loadProgrammes();
    }//GEN-LAST:event_cboExerciceActionPerformed

    private void tblProgrammeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblProgrammeMouseClicked
        // TODO add your handling code here:
        afficherSousProgrammes();
    }//GEN-LAST:event_tblProgrammeMouseClicked

    private void btnEnregistrerProgrammeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerProgrammeActionPerformed
        // TODO add your handling code here:
        enregistrerProgrammes(1);
    }//GEN-LAST:event_btnEnregistrerProgrammeActionPerformed

    private void chkSousProgrammeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_chkSousProgrammeActionPerformed
        // TODO add your handling code here:
        selectAllSousProgramme();
    }//GEN-LAST:event_chkSousProgrammeActionPerformed

    private void btnEnregistrerActionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionActionPerformed
        // TODO add your handling code here:
        enregistrerProgrammes(2);
    }//GEN-LAST:event_btnEnregistrerActionActionPerformed

    private void selectAllSousProgramme() {
        // TODO add your handling code here:
        boolean s = chkSousProgramme.isSelected();
        List<VueEntiteReduit> l = new ArrayList<>();
        for (VueEntiteReduit st : listSousProgramme) {
            st.setChecked(s);
            l.add(st);
        }
        listSousProgramme.clear();
        for (VueEntiteReduit st : l) {
            listSousProgramme.add(st);
        }
    }

    private void selectAllSourceFinancement() {
        // TODO add your handling code here:
        boolean s = chkSourceFinancement.isSelected();
        List<VueEntiteReduit> l = new ArrayList<>();
        for (VueEntiteReduit st : listSourceFinancements) {
            st.setChecked(s);
            l.add(st);
        }
        listSourceFinancements.clear();
        for (VueEntiteReduit st : l) {
            listSourceFinancements.add(st);
        }
    }

    private void selectAllStructures() {
        // TODO add your handling code here:
        boolean s = chkStructure.isSelected();
        List<VueEntiteReduit> l = new ArrayList<>();
        for (VueEntiteReduit st : listStructures) {
            st.setChecked(s);
            l.add(st);
        }
        listStructures.clear();
        for (VueEntiteReduit st : l) {
            listStructures.add(st);
        }
    }

    private void afficherStructures() {
        //on a changé d'organisation pour charger les strucures
        if (!selectedOrganisation.getId().equalsIgnoreCase(old_organisationID)) {
            try {
                List<VueEntiteReduit> list = GrecoServiceFactory.getUserService().userStructureList(GrecoSession.USER_CONNECTED.getLogin(), user == null ? null : user.getLogin());
                listStructures.clear();
                if (list != null && !list.isEmpty()) {
                    for (VueEntiteReduit s : list) {
                        listStructures.add(s);
                    }
                }
                old_organisationID = selectedOrganisation.getId();
            } catch (GrecoException ex) {
                ManageException.show(ex, Locale.getDefault());
            }
        }
    }

    private void enregistrerProgrammes(int type) {
        Exercice e = (Exercice) cboExercice.getSelectedItem();
        List<VueEntiteReduit> list = new ArrayList<>();
        if (type == 1) {
            for (VueEntiteReduit v : listProgramme) {
                if (v.isChecked()) {
                    list.add(v);
                }
            }
        } else {
            for (VueEntiteReduit v : listSousProgramme) {
                if (v.isChecked()) {
                    list.add(v);
                }
            }
        }

        if (!list.isEmpty()) {
            try {
                GrecoServiceFactory.getUserService().userProgrammeSave(user.getLogin(), selectedProgramme.getId(), e.getMillesime(), type, list, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Affectation des programmes à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception ex) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                ex.printStackTrace();
                return;
            }
        } else {
            try {
                GrecoServiceFactory.getUserService().userProgrammeDelete(user.getLogin(), e.getMillesime(), type, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Retrait de tous les programmes à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception ex) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                ex.printStackTrace();
                return;
            }
        }
    }

    private void enregistrerStructures() {
        List<VueEntiteReduit> list = new ArrayList<>();
        for (VueEntiteReduit v : listStructures) {
            if (v.isChecked()) {
                list.add(v);
            }
        }

        if (!list.isEmpty()) {
            try {
                GrecoServiceFactory.getUserService().userStructureSave(user.getLogin(), list, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Affectation des stuctures à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception e) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
                return;
            }
        } else {
            try {
                GrecoServiceFactory.getUserService().userStructureDelete(user.getLogin(), GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Retrait de toutes les structures à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception e) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
                return;
            }
        }
    }

    private void enregistrerSourceFinancement() {
        List<VueEntiteReduit> list = new ArrayList<>();
        for (VueEntiteReduit v : listSourceFinancements) {
            if (v.isChecked()) {
                list.add(v);
            }
        }

        if (!list.isEmpty()) {
            try {
                GrecoServiceFactory.getUserService().userSourceFinancementSave(user.getLogin(), list, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Affectation des sources de financements à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception e) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
                return;
            }
        } else {
            try {
                GrecoServiceFactory.getUserService().userSourceFinancementDelete(user.getLogin(), GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Retrait des sources de financements à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception e) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
                return;
            }
        }
    }

    private void enregistrerOrganisation() {
        List<VueEntiteReduit> list = new ArrayList<>();
        for (VueEntiteReduit v : listOrganisation) {
            if (v.isChecked()) {
                list.add(v);
            }
        }

        if (!list.isEmpty()) {
            try {
                GrecoServiceFactory.getUserService().userOrganisationSave(user.getLogin(), list, GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Affectation des organisations à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception e) {
                e.printStackTrace();
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
                return;
            }
        } else {
            try {
                GrecoServiceFactory.getUserService().userOrganisationDelete(user.getLogin(), GrecoSession.USER_CONNECTED.getLogin(),
                        GrecoSession.USER_ADRESSE_IP, GrecoSession.USER_HOST_NAME, GrecoSession.USER_ADRESSE_MAC,
                        Crypto.encrypt("Retrait des organisations à " + user.getNomCompletDecrypt()), Crypto.getMD5(GrecoSession.USER_HOST_NAME),
                        GrecoSession.USER_OS, GrecoSession.USER_ARCHITECTURE, "", Modules.UTILISATEURS);
                GrecoSession.notifications.success();
                GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                glasspane.arret();
            } catch (Exception e) {
                glasspane.arret();
                user = null;
                GrecoSession.notifications.echec();
                e.printStackTrace();
                return;
            }
        }
    }

    private void changeButton(java.awt.event.ActionEvent evt) {
        Object o = evt.getSource();
        if (o instanceof GButton) {
            for (int i = 0; i < pOptions.getComponentCount(); i++) {
                Object object = pOptions.getComponent(i);
                if (object instanceof GButton) {
                    ((GButton) object).setStyle(5);
                }
            }
            ((GButton) o).setStyle(0);
            ((CardLayout) jPanel3.getLayout()).show(jPanel3, ((GButton) o).getName());
        }
    }

    private void actifLabel() {
        if (actif) {
            lblActif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/radioSelect.png")));
        } else {
            lblActif.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/radioUnSelect.png")));
        }
    }

    private boolean controlData() {
        boolean res = true;

        if (txtLogin.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le compte de connexion de l'utilisateur ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (String.valueOf(txtPassword.getPassword()).isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le mot de passe de l'utilisateur ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtNom.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le nom de l'utilisateur ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return res;
    }

    private void remplirUser() {
        user.setLogin(Crypto.encrypt(txtLogin.getText().trim()));
        user.setService(Crypto.encrypt(txtService.getText().trim()));
        user.setFonction(Crypto.encrypt(txtFonction.getText().trim()));
        user.setImmatriculation(Crypto.encrypt(txtMatricule.getText().trim()));
        user.setActif(actif);
        user.setNom(Crypto.encrypt(txtNom.getText().trim()));
        user.setPassword(String.valueOf(txtPassword.getPassword()));
        user.setPrenom(Crypto.encrypt(txtPrenom.getText().trim()));
        user.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        user.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

    }

    private void enregistrer() {
        if (controlData()) {
            glasspane.setText("enregistrement de l'utilisateur ....");
            glasspane.attente();
            if (user == null) {
                user = new Users();
                remplirUser();

                try {
                    GrecoServiceFactory.getUserService().enregistrer(user.getUserUpdate(), user.getIpUpdate(), user.getLogin(),
                            Crypto.crypterPassword(user.getLoginDecrypt(), user.getPassword()), user.getNom(), user.getPrenom(), user.getImmatriculation(),
                            user.getFonction(), Crypto.encrypt(socialPanel.getEmail()), actif, user.getService(), user.getOrganisationID(), user.getStructureID(),
                            Crypto.encrypt(socialPanel.getFacebook()), Crypto.encrypt(socialPanel.getWhatsapp()), Crypto.encrypt(socialPanel.getTwitter()),
                            Crypto.encrypt(socialPanel.getLinkedln()), Crypto.encrypt(socialPanel.getGoogleplus()), Crypto.encrypt(socialPanel.getTelephone()));
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("enregistré avec succès");
                    glasspane.arret();
                } catch (GrecoException e) {
                    glasspane.arret();
                    user = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    return;
                } catch (Exception e) {
                    glasspane.arret();
                    e.printStackTrace();
                    user = null;
                    GrecoSession.notifications.echec();
                    JOptionPane.showMessageDialog(this, "ECHEC DE L'NREGISTREMENT \n\n", "ECHEC", JOptionPane.ERROR_MESSAGE);
                    return;
                }
            } else {
                remplirUser();
                try {
                    GrecoServiceFactory.getUserService().modifier(user.getUserUpdate(), user.getIpUpdate(), user.getLogin(),
                            chkReinitialiser.isSelected() ? Crypto.crypterPassword(user.getLoginDecrypt(), String.valueOf( txtPassword.getPassword())) : user.getPassword(), user.getNom(), user.getPrenom(), user.getImmatriculation(),
                            user.getFonction(), Crypto.encrypt(socialPanel.getEmail()), actif, user.getService(), user.getOrganisationID(), user.getStructureID(),
                            Crypto.encrypt(socialPanel.getFacebook()), Crypto.encrypt(socialPanel.getWhatsapp()), Crypto.encrypt(socialPanel.getTwitter()),
                            Crypto.encrypt(socialPanel.getLinkedln()), Crypto.encrypt(socialPanel.getGoogleplus()), Crypto.encrypt(socialPanel.getTelephone()));
                    GrecoSession.notifications.success();
                    GrecoOptionPane.showSuccessDialog("modifié avec succès ");
                    glasspane.arret();
                } catch (Exception e) {
                    glasspane.arret();
                    GrecoSession.notifications.echec();
                    return;
                }
            }
            initUI();
            glasspane.arret();
        }
    }

    public List<VueEntiteReduit> getListStructures() {
        return listStructures;
    }

    public void setListStructures(List<VueEntiteReduit> listStructures) {
        this.listStructures = listStructures;
    }

    public List<VueEntiteReduit> getListSourceFinancements() {
        return listSourceFinancements;
    }

    public void setListSourceFinancements(List<VueEntiteReduit> listSourceFinancements) {
        this.listSourceFinancements = listSourceFinancements;
    }

    public List<VueEntiteReduit> getListProgramme() {
        return listProgramme;
    }

    public void setListProgramme(List<VueEntiteReduit> listProgramme) {
        this.listProgramme = listProgramme;
    }

    public List<VueEntiteReduit> getListSousProgramme() {
        return listSousProgramme;
    }

    public void setListSousProgramme(List<VueEntiteReduit> listSousProgramme) {
        this.listSousProgramme = listSousProgramme;
    }

    public VueEntiteReduit getSelectedProgramme() {
        return selectedProgramme;
    }

    public void setSelectedProgramme(VueEntiteReduit selectedProgramme) {
        this.selectedProgramme = selectedProgramme;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UsersEditDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UsersEditDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UsersEditDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UsersEditDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                UsersEditDialog dialog = new UsersEditDialog(new javax.swing.JFrame(), true, null);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAnnuler;
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private cm.eusoworks.tools.ui.GButton btnEnregistrerAction;
    private cm.eusoworks.tools.ui.GButton btnEnregistrerOrganisation;
    private cm.eusoworks.tools.ui.GButton btnEnregistrerProgramme;
    private cm.eusoworks.tools.ui.GButton btnEnregistrerSourceFinancement;
    private cm.eusoworks.tools.ui.GButton btnEnregistrerStructure;
    private cm.eusoworks.tools.ui.GButton btnInfos;
    private cm.eusoworks.tools.ui.GButton btnOrganisation;
    private cm.eusoworks.tools.ui.GButton btnProfils;
    private cm.eusoworks.tools.ui.GButton btnProgramme;
    private cm.eusoworks.tools.ui.GButton btnSourceFinancement;
    private javax.swing.JComboBox cboExercice;
    private javax.swing.JCheckBox chkReinitialiser;
    private javax.swing.JCheckBox chkSourceFinancement;
    private javax.swing.JCheckBox chkSousProgramme;
    private javax.swing.JCheckBox chkStructure;
    private javax.swing.JLabel fonctionLabel;
    private javax.swing.JLabel immatriculationLabel;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JLabel lblActif;
    private javax.swing.JLabel loginLabel;
    private javax.swing.JLabel nomLabel;
    private javax.swing.JPanel pAutorisation;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pFinancement;
    private javax.swing.JPanel pOptions;
    private javax.swing.JPanel pOrganisation;
    private javax.swing.JPanel pProgramme;
    private javax.swing.JLabel passwordLabel;
    private javax.swing.JLabel prenomLabel;
    private javax.swing.JLabel serviceLabel;
    private cm.eusoworks.ui.config.UserSocialPanel socialPanel;
    private javax.swing.JTable tblAction;
    private javax.swing.JTable tblOrganisation;
    private javax.swing.JTable tblProgramme;
    private javax.swing.JTable tblSourceFinancement;
    private javax.swing.JTable tblStructure;
    private javax.swing.JTree treeProfil;
    private javax.swing.JTextField txtFonction;
    private javax.swing.JTextField txtLogin;
    private javax.swing.JTextField txtMatricule;
    private javax.swing.JTextField txtNom;
    private javax.swing.JPasswordField txtPassword;
    private javax.swing.JTextField txtPrenom;
    private javax.swing.JTextField txtService;
    private org.jdesktop.beansbinding.BindingGroup bindingGroup;
    // End of variables declaration//GEN-END:variables

    public class ProfilTreeNode extends DefaultMutableTreeNode {

        public ProfilTreeNode() {
        }

        public ProfilTreeNode(Object userObject) {
            super(userObject);
        }

        public ProfilTreeNode(Object userObject, boolean allowsChildren) {
            super(userObject, allowsChildren);
        }

    }

}
