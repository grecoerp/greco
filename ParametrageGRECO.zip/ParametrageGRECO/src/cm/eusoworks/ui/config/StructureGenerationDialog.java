/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PosteComptable;
import cm.eusoworks.entities.model.Structure;
import cm.eusoworks.entities.model.UniteOrganique;
import cm.eusoworks.entities.model.NiveauOrganique;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tools.ui.GrecoOptionPane;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

/**
 *
 * @author macbookair
 */
public class StructureGenerationDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private Structure currentStructure = null;
    private Organisation lastOrganisation = new Organisation("-11111");
    private Localite locality;
    private Categorie category;
    private Fonction fonction;
    private int mode;

    public static int MODE_NORMAL = 1;
    public static int MODE_STRUCTURE_BUDGETAIRE = 2;

    public StructureGenerationDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        this.mode = mode;
        loadOrganisations();
        setPreferredSize(new Dimension(850, 650));
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Generation des structures a partir de l'organigramme ");
    }

    private void loadOrganisations() {
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationUserActives(GrecoSession.USER_CONNECTED.getLogin());
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            cboOrganisation.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboOrganisation.setSelectedIndex(0);
            }

        }
    }

    private void loadUniteOrganiques() {
        Organisation o = (Organisation) cboOrganisation.getSelectedItem();
        if (o == null) {
            return;
        }
        List<UniteOrganique> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getUniteOrganiqueService().listeUniteOrganique(o.getOrganisationID());
        } catch (Exception e) {
        }
    }

    private void loadPosteComptables() {
        List<PosteComptable> list = new ArrayList();

        if (locality != null) {
            try {
                list = GrecoServiceFactory.getPosteComptableService().getPosteComptableOfLocalite(locality.getCode());
            } catch (Exception e) {
            }
        }
        if (list != null && !list.isEmpty()) {
            cboPosteComptable.setModel(new DefaultComboBoxModel(list.toArray()));
            if (list.size() == 1) {
                cboPosteComptable.setSelectedIndex(0);
            } else {
                cboPosteComptable.setSelectedIndex(-1);
            }
        }
    }

    private void remplirCurrentStructure() {
        currentStructure.setOrganisationID(((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID());

        currentStructure.setStructureParentID(null);

        currentStructure.setUniteOrganiqueID(null);

        currentStructure.setAbbreviationFr("");
        currentStructure.setAbbreviationUs("");
        currentStructure.setLibelleFr("");
        currentStructure.setLibelleUs("");

        currentStructure.setCategorieCode(category.getCode());
        currentStructure.setFonctionCode(fonction.getCode());
        currentStructure.setLocaliteCode(locality.getCode());

        currentStructure.setPosteComptableID(((PosteComptable) cboPosteComptable.getSelectedItem()).getPosteComptableID());
        StringBuilder code = new StringBuilder();
        code.append(category.getCode().trim());
        code.append(locality.getCode().trim());
        try {
            int ordre = GrecoServiceFactory.getOrganisationService().structureMaxOrdre(category.getCode(), locality.getCode());
            code.append("" + ordre);
        } catch (Exception e) {
            code.append("00");
        }

        currentStructure.setCode(code.toString().trim());

        currentStructure.setDateCreation(new Date());
        currentStructure.setDateCessation(null);
        currentStructure.setActif(true);
        currentStructure.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentStructure.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        cboOrganisation = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        btnSelectionnerLocalite = new javax.swing.JButton();
        lblLocalite = new javax.swing.JLabel();
        jLabel10 = new javax.swing.JLabel();
        cboPosteComptable = new javax.swing.JComboBox();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        btnSelectCategorie = new javax.swing.JButton();
        btnSelectFonction = new javax.swing.JButton();
        lblCategorie = new javax.swing.JLabel();
        lblFonction = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Organisme/Administration  :");

        cboOrganisation.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cboOrganisation.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cboOrganisationActionPerformed(evt);
            }
        });

        jLabel8.setText("Localité :");

        btnSelectionnerLocalite.setText("sélectionner une localité ");
        btnSelectionnerLocalite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectionnerLocaliteActionPerformed(evt);
            }
        });

        lblLocalite.setForeground(new java.awt.Color(0, 153, 102));

        jLabel10.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        jLabel10.setText("Poste comptable : ");

        jLabel11.setText("Catégorie de service :");

        jLabel12.setText("Fonction : ");

        btnSelectCategorie.setText("Sélectionner une catégorie : ");
        btnSelectCategorie.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectCategorieActionPerformed(evt);
            }
        });

        btnSelectFonction.setText("Sélectionner la fontion : ");
        btnSelectFonction.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectFonctionActionPerformed(evt);
            }
        });

        lblCategorie.setForeground(new java.awt.Color(255, 153, 0));

        jLabel1.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(0, 102, 204));
        jLabel1.setText("Cliquez sur le bouton \"Demarer la generation\" pour lancer la generation ");

        jLabel2.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(0, 102, 204));
        jLabel2.setText("Veuillez selectionner les valeurs par defaut qui seront affectees a chaque structure cree");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel7, javax.swing.GroupLayout.PREFERRED_SIZE, 180, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(btnSelectCategorie, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(lblCategorie, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)
                        .addComponent(btnSelectFonction, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(lblFonction, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(90, 90, 90)
                        .addComponent(btnSelectionnerLocalite, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(10, 10, 10)
                        .addComponent(lblLocalite, javax.swing.GroupLayout.PREFERRED_SIZE, 300, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 140, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(50, 50, 50)
                        .addComponent(cboPosteComptable, javax.swing.GroupLayout.PREFERRED_SIZE, 420, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 730, javax.swing.GroupLayout.PREFERRED_SIZE)))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel7)
                    .addComponent(cboOrganisation, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(33, 33, 33)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel11, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSelectCategorie)
                    .addComponent(lblCategorie, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSelectFonction)
                    .addComponent(lblFonction, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(11, 11, 11)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btnSelectionnerLocalite)
                    .addComponent(lblLocalite, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(10, 10, 10)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cboPosteComptable, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(63, 63, 63)
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5));

        btnEnregistrer.setText("Demarer la generation des codes structures ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetails, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {

            SwingUtilities.invokeLater(new Runnable() {
                @Override
                public void run() {
                    Thread con;
                    con = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            glasspane.attente();
                            int errors = 0;
                            Organisation o = (Organisation) cboOrganisation.getSelectedItem();
                            //liste des niveaux organiques;
                            List<NiveauOrganique> listNiveau = GrecoServiceFactory.getUniteOrganiqueService().listeNiveauOrganique(o.getOrganisationID());
                            for (int i = 0; i < listNiveau.size(); i++) {
                                NiveauOrganique n = listNiveau.get(i);
                                int niv = n.getNiveauOrganiqueID().intValue();

                                //liste des unite organiques de ce niveau
                                List<UniteOrganique> listUniteOrg = new ArrayList<>();
                                listUniteOrg = GrecoServiceFactory.getUniteOrganiqueService().listeUniteOrganiqueByNiveau(o.getOrganisationID(), niv);
                                Structure structureParent = null;
                                String uniteOrganiqueParentID;

                                //pour chaque unite organique, on cree sa structure homonyme
                                for (UniteOrganique u : listUniteOrg) {
                                    uniteOrganiqueParentID = u.getUniteOrganiqueParentID();
                                    if (uniteOrganiqueParentID != null) {
                                        List<Structure> list = GrecoServiceFactory.getOrganisationService().listeStructuresByUniteOrganique(o.getOrganisationID(), uniteOrganiqueParentID);
                                        if (list != null && !list.isEmpty()) {
                                            structureParent = list.get(0);
                                        }
                                    }
                                    currentStructure = new Structure();
                                    currentStructure.setOrganisationID(((Organisation) cboOrganisation.getSelectedItem()).getOrganisationID());
                                    currentStructure.setStructureParentID(structureParent == null ? null : structureParent.getStructureID());
                                    currentStructure.setUniteOrganiqueID(u.getUniteOrganiqueID());
                                    String abbr = getAbbreviation(u.getLibelleFr());
                                    currentStructure.setAbbreviationFr(abbr);
                                    currentStructure.setAbbreviationUs(abbr);
                                    currentStructure.setLibelleFr(u.getLibelleFr());
                                    currentStructure.setLibelleUs(u.getLibelleUs());
                                    currentStructure.setCategorieCode(category.getCode());
                                    currentStructure.setFonctionCode(fonction.getCode());
                                    currentStructure.setLocaliteCode(locality.getCode());
                                    currentStructure.setPosteComptableID(((PosteComptable) cboPosteComptable.getSelectedItem()).getPosteComptableID());
                                    StringBuilder code = new StringBuilder();
                                    code.append(category.getCode().trim());
                                    code.append(locality.getCode().trim());
                                    try {
                                        int nb = GrecoServiceFactory.getOrganisationService().structureMaxOrdre(category.getCode().trim(), locality.getCode());
                                        String s = "00" + nb;
                                        int l = s.length();
                                        code.append(s.substring(l - 3));
                                    } catch (Exception e) {
                                    }
                                    currentStructure.setCode(code.toString().trim());

                                    currentStructure.setDateCreation(new Date());
                                    currentStructure.setDateCessation(null);
                                    currentStructure.setActif(true);
                                    currentStructure.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                                    currentStructure.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                                    try {
                                        GrecoServiceFactory.getOrganisationService().ajouterStructure(currentStructure);
                                        glasspane.setText(currentStructure.getLibelleFr() + "creee avec success");
                                    } catch (GrecoException ex) {
                                        currentStructure = null;
                                        errors++;
                                        ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                                    }

                                }

                            }
                            glasspane.arret();
                            btnEnregistrer.setEnabled(false);
                            if (errors == 0) {
                                GrecoOptionPane.showSuccessDialog("Les structures de l'organigramme ont etees creees ...");
                            } else {
                                GrecoOptionPane.showWarningDialog("Operation Terminee. Certaines structures n'ont pas pu etre crees. Nous vous prions de faire des verifications d'usage ...");
                            }
                        }
                    }, "Performer");
                    con.start();
                }
            });

        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private String getAbbreviation(String designation) {
        String str[] = designation.split(" ");
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < str.length; i++) {
            String mot = str[i];
            if (mot.equalsIgnoreCase("et") || mot.equalsIgnoreCase("de") || mot.equalsIgnoreCase("des") || mot.equalsIgnoreCase("la") || 
                            mot.equalsIgnoreCase("les") || mot.equalsIgnoreCase("du") ||mot.equalsIgnoreCase("non") || mot.equalsIgnoreCase("")) {

            } else {
                try {
                    s.append(String.valueOf(mot.charAt(0)).toUpperCase());
                } catch (Exception e) {
                }
            }

        }
        return s.toString();
    }

    private void btnSelectionnerLocaliteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectionnerLocaliteActionPerformed
        // TODO add your handling code here:
        final ViewLocaliteDialog dialog = new ViewLocaliteDialog(null, true);
        dialog.setVisible(true);
        locality = dialog.getSelectedLocalite();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if (locality == null) {
            lblLocalite.setForeground(Color.red);
            lblLocalite.setText("Attention!!! aucune localité choisie");
        } else {
            lblLocalite.setForeground(new Color(0, 153, 102));
            lblLocalite.setText(locality.getLibelle(Locale.getDefault()));
        }
        loadPosteComptables();


    }//GEN-LAST:event_btnSelectionnerLocaliteActionPerformed

    private void cboOrganisationActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cboOrganisationActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cboOrganisationActionPerformed

    private void btnSelectCategorieActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectCategorieActionPerformed
        // TODO add your handling code here:
        final ViewCategorieDialog dialog = new ViewCategorieDialog(null, true);
        dialog.setVisible(true);
        category = dialog.getSelectedCategorie();
        if (category.getNiveauID() != GrecoSession.optionNiveau.getCa().intValue()) {
            category = null;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if (category == null) {
            lblCategorie.setForeground(Color.red);
            lblCategorie.setText("Attention!!! aucune catégorie de service choisie");
        } else {
            lblCategorie.setForeground(new Color(0, 153, 102));
            lblCategorie.setText(category.getLibelle(Locale.getDefault()));
        }
    }//GEN-LAST:event_btnSelectCategorieActionPerformed

    private void btnSelectFonctionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectFonctionActionPerformed
        // TODO add your handling code here:
        final ViewFonctionDialog dialog = new ViewFonctionDialog(null, true);
        dialog.setVisible(true);
        fonction = dialog.getSelectedFonction();
        if (fonction.getNiveauID() != GrecoSession.optionNiveau.getFu()) {
            fonction = null;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if (fonction == null) {
            lblFonction.setForeground(Color.red);
            lblFonction.setText("Attention!!! aucune fonction secondaire choisie");
        } else {
            lblFonction.setForeground(new Color(0, 153, 102));
            lblFonction.setText(fonction.getLibelle(Locale.getDefault()));
        }
    }//GEN-LAST:event_btnSelectFonctionActionPerformed

    private boolean controlData() {
        boolean res = true;
        if (category == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la catégorie de service", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (fonction == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la fonction secondaire ", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (locality == null) {
            JOptionPane.showMessageDialog(this, "Selectionnez la localite geographique dans laquelle le poste comptable est crée", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        PosteComptable p = (PosteComptable) cboPosteComptable.getSelectedItem();
        if (p == null) {
            JOptionPane.showMessageDialog(this, "Sélectionner le poste comptable rattaché à cette structure", java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(StructureGenerationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(StructureGenerationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(StructureGenerationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(StructureGenerationDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                StructureGenerationDialog dialog = new StructureGenerationDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnSelectCategorie;
    private javax.swing.JButton btnSelectFonction;
    private javax.swing.JButton btnSelectionnerLocalite;
    private javax.swing.JComboBox cboOrganisation;
    private javax.swing.JComboBox cboPosteComptable;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JLabel lblCategorie;
    private javax.swing.JLabel lblFonction;
    private javax.swing.JLabel lblLocalite;
    private javax.swing.JPanel pDetails;
    // End of variables declaration//GEN-END:variables
}
