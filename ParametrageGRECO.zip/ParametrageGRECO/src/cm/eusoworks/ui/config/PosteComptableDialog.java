/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.model.Organisation;
import cm.eusoworks.entities.model.PosteComptable;
import cm.eusoworks.entities.model.PosteComptableNature;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.CardLayout;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.HighlightPredicate;
import org.jdesktop.swingx.renderer.DefaultListRenderer;

/**
 *
 * @author macbookair
 */
public class PosteComptableDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private PosteComptable currentPC;
    private Localite locality;

    public PosteComptableDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        jListPC.setRolloverEnabled(true);
        jListPC.setCellRenderer(new DefaultListRenderer());
        jListPC.addHighlighter(new ColorHighlighter(HighlightPredicate.ROLLOVER_ROW, new Color(135, 164, 190), Color.white));
        loadPosteComptablesNatures();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Gestion des postes comptables ");
    }

    private void loadPosteComptablesNatures() {
        List<PosteComptableNature> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getPosteComptableService().getPosteComptableNature();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            jListPCNature.removeAll();
            jListPCNature.setListData(list.toArray());
            cboNaturePC.setModel(new DefaultComboBoxModel(list.toArray()));
        }
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "nature");
    }

    private void loadPosteComptables() {
        List<PosteComptable> list = new ArrayList();
        PosteComptableNature n = (PosteComptableNature) jListPCNature.getSelectedValue();
        if (n != null) {
            try {
                list = GrecoServiceFactory.getPosteComptableService().getPosteComptableByNature(n.getNaturePC());
            } catch (Exception e) {
            }
        }
        if (list != null && !list.isEmpty()) {
            jListPC.removeAll();
            jListPC.setListData(list.toArray());

        }
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");

    }

    private void initUI() {
        if (currentPC == null) {
            txtCode.setValue(null);
            txtAbbreviation.clear();
            txtLibelle.clear();
            dtpDateCreation.setDate(new Date());
            dtpDateCessation.setDate(null);
            chkActive.setSelected(true);
            locality = null;
            lblLocalite.setText("");
        } else {
            for (int i = 0; i < cboNaturePC.getItemCount(); i++) {
                PosteComptableNature n = (PosteComptableNature) cboNaturePC.getItemAt(i);
                if(currentPC.getNaturePC().equalsIgnoreCase(n.getNaturePC())){
                    cboNaturePC.setSelectedIndex(i);
                    break;
                }
            }
            txtCode.setText(currentPC.getCode().substring(1));
            txtAbbreviation.setTextFr(currentPC.getAbbreviationFr());
            txtAbbreviation.setTextUs(currentPC.getAbbreviationUs());
            txtLibelle.setTextFr(currentPC.getLibelleFr());
            txtLibelle.setTextUs(currentPC.getLibelleUs());
            dtpDateCreation.setDate(currentPC.getDateCreation());
            dtpDateCessation.setDate(currentPC.getDateCessation());
            chkActive.setSelected(currentPC.getActif());
            try {
                locality = GrecoServiceFactory.getNomenclatureService().getLocalite(currentPC.getCodeLocalite());
                lblLocalite.setText(locality.getLibelle());
            } catch (Exception e) {
                locality = null;
            }
        }
    }

    private void remplirCurrentPosteComptable() {
        currentPC.setNaturePC(((PosteComptableNature)cboNaturePC.getSelectedItem()).getNaturePC().trim());
        currentPC.setCode(((PosteComptableNature)cboNaturePC.getSelectedItem()).getNaturePC().trim()+txtCode.getText().trim());
        currentPC.setAbbreviationFr(txtAbbreviation.getTextFr().toUpperCase());
        currentPC.setAbbreviationUs(txtAbbreviation.getTextUs().toUpperCase());
        currentPC.setLibelleFr(txtLibelle.getTextFr().toUpperCase());
        currentPC.setLibelleUs(txtLibelle.getTextUs().toUpperCase());
        currentPC.setDateCreation(dtpDateCreation.getDate());
        currentPC.setDateCessation(dtpDateCessation.getDate());
        currentPC.setActif(chkActive.isSelected());
        currentPC.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentPC.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
        currentPC.setCodeLocalite(locality.getCode());
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pListNature = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jListPCNature = new javax.swing.JList();
        pAccueil = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        btnNewOrg = new javax.swing.JButton();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtAbbreviation = new editor.EditorRTF();
        txtLibelle = new editor.EditorRTF();
        dtpDateCreation = new org.jdesktop.swingx.JXDatePicker();
        dtpDateCessation = new org.jdesktop.swingx.JXDatePicker();
        chkActive = new javax.swing.JCheckBox();
        txtCode = new javax.swing.JFormattedTextField();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        cboNaturePC = new javax.swing.JComboBox();
        jLabel8 = new javax.swing.JLabel();
        btnSelectionner = new javax.swing.JButton();
        lblLocalite = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new javax.swing.JButton();
        btnSupprimer = new javax.swing.JButton();
        btnAnnuler = new javax.swing.JButton();
        pListPC = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListPC = new org.jdesktop.swingx.JXList();
        jPanel3 = new javax.swing.JPanel();
        btnListeCompleteOrg = new javax.swing.JButton();
        btnAddOrg = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des Postes comptables");
        getContentPane().setLayout(new java.awt.CardLayout());

        pListNature.setLayout(new java.awt.BorderLayout());

        jListPCNature.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jListPCNature.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListPCNatureMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(jListPCNature);

        pListNature.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        getContentPane().add(pListNature, "nature");

        jLabel1.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jLabel1.setForeground(new java.awt.Color(153, 153, 153));
        jLabel1.setText("Aucun poste comptable cree.");

        btnNewOrg.setText("Ajouter un nouveau poste comptable");
        btnNewOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnNewOrgActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout pAccueilLayout = new javax.swing.GroupLayout(pAccueil);
        pAccueil.setLayout(pAccueilLayout);
        pAccueilLayout.setHorizontalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGroup(pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 466, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(pAccueilLayout.createSequentialGroup()
                        .addGap(178, 178, 178)
                        .addComponent(btnNewOrg)))
                .addContainerGap(107, Short.MAX_VALUE))
        );
        pAccueilLayout.setVerticalGroup(
            pAccueilLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pAccueilLayout.createSequentialGroup()
                .addGap(132, 132, 132)
                .addComponent(jLabel1)
                .addGap(65, 65, 65)
                .addComponent(btnNewOrg)
                .addContainerGap(200, Short.MAX_VALUE))
        );

        getContentPane().add(pAccueil, "accueil");

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setLayout(null);
        jPanel1.add(txtAbbreviation);
        txtAbbreviation.setBounds(210, 120, 180, 64);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(210, 200, 380, 70);
        jPanel1.add(dtpDateCreation);
        dtpDateCreation.setBounds(210, 360, 140, 22);
        jPanel1.add(dtpDateCessation);
        dtpDateCessation.setBounds(520, 360, 130, 22);

        chkActive.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        chkActive.setText("Poste comptable en activite");
        chkActive.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        chkActive.setHorizontalTextPosition(javax.swing.SwingConstants.LEFT);
        jPanel1.add(chkActive);
        chkActive.setBounds(360, 60, 270, 25);

        try {
            txtCode.setFormatterFactory(new javax.swing.text.DefaultFormatterFactory(new javax.swing.text.MaskFormatter("###")));
        } catch (java.text.ParseException ex) {
            ex.printStackTrace();
        }
        txtCode.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        jPanel1.add(txtCode);
        txtCode.setBounds(210, 60, 60, 35);

        jLabel2.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel2.setText("Numero d'ordre : ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(20, 60, 180, 30);

        jLabel3.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel3.setText("Sigle : ");
        jPanel1.add(jLabel3);
        jLabel3.setBounds(20, 120, 88, 40);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("Designation :");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(20, 200, 140, 40);

        jLabel5.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel5.setText("Date de creation : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(20, 360, 130, 30);

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel6.setText("Date de cessation : ");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(370, 360, 140, 20);

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jLabel7.setText("Nature  :");
        jPanel1.add(jLabel7);
        jLabel7.setBounds(20, 20, 120, 17);

        cboNaturePC.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cboNaturePC);
        cboNaturePC.setBounds(210, 20, 420, 20);

        jLabel8.setText("Localité :");
        jPanel1.add(jLabel8);
        jLabel8.setBounds(20, 294, 100, 30);

        btnSelectionner.setText("sélectionner");
        btnSelectionner.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectionnerActionPerformed(evt);
            }
        });
        jPanel1.add(btnSelectionner);
        btnSelectionner.setBounds(210, 300, 110, 23);

        lblLocalite.setForeground(new java.awt.Color(0, 153, 102));
        jPanel1.add(lblLocalite);
        lblLocalite.setBounds(330, 300, 300, 20);

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5));

        btnEnregistrer.setText("Enregistrer ");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnSupprimer.setText("Supprimer");
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel2.add(btnSupprimer);

        btnAnnuler.setText("Annuler");
        btnAnnuler.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAnnulerActionPerformed(evt);
            }
        });
        jPanel2.add(btnAnnuler);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pDetails, "details");

        pListPC.setLayout(new java.awt.BorderLayout());

        jListPC.setModel(new javax.swing.AbstractListModel() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public Object getElementAt(int i) { return strings[i]; }
        });
        jListPC.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListPC.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jListPC.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jListPC.setSelectionForeground(new java.awt.Color(0, 102, 255));
        jListPC.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListPCMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jListPC);

        pListPC.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 15, 5));

        btnListeCompleteOrg.setLabel("Liste complete de tous les postes comptables");
        btnListeCompleteOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnListeCompleteOrgActionPerformed(evt);
            }
        });
        jPanel3.add(btnListeCompleteOrg);

        btnAddOrg.setText("Ajouter un nouveau poste comptable");
        btnAddOrg.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddOrgActionPerformed(evt);
            }
        });
        jPanel3.add(btnAddOrg);

        pListPC.add(jPanel3, java.awt.BorderLayout.SOUTH);

        getContentPane().add(pListPC, "list");

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnNewOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnNewOrgActionPerformed
        // TODO add your handling code here:
        currentPC = null;
        initUI();
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "details");
    }//GEN-LAST:event_btnNewOrgActionPerformed

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (controlData()) {
            if (currentPC == null) {
                currentPC = new PosteComptable();
                remplirCurrentPosteComptable();
                try {
                    GrecoServiceFactory.getPosteComptableService().ajouter(currentPC);
                    GrecoSession.notifications.success();
                    loadPosteComptables();
                } catch (GrecoException ex) {
                    currentPC = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else { // modification de l'organisation 
                remplirCurrentPosteComptable();
                try {
                    GrecoServiceFactory.getPosteComptableService().modifier(currentPC);
                    GrecoSession.notifications.success();
                    loadPosteComptables();
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnListeCompleteOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnListeCompleteOrgActionPerformed
        // TODO add your handling code here:
        List<Organisation> list = new ArrayList();
        try {
            list = GrecoServiceFactory.getOrganisationService().listeOrganisationComplete();
        } catch (Exception e) {
        }
        if (list != null && !list.isEmpty()) {
            jListPC.setListData(list.toArray());
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
        } else {
            ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "accueil");
        }
    }//GEN-LAST:event_btnListeCompleteOrgActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        if (!currentPC.getPosteComptableID().isEmpty()) {
            int reponse = JOptionPane.showConfirmDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("deleteQuestion") + currentPC.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getPosteComptableService().supprimer(currentPC.getPosteComptableID());
                    GrecoSession.notifications.success();
                    loadPosteComptables();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }

        }
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAddOrgActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddOrgActionPerformed
        // TODO add your handling code here:
        btnNewOrgActionPerformed(null);
    }//GEN-LAST:event_btnAddOrgActionPerformed

    private void jListPCMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListPCMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            currentPC = (PosteComptable) jListPC.getSelectedValue();
            initUI();
            if (currentPC != null) {
                ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "details");
            }

        }
    }//GEN-LAST:event_jListPCMouseClicked

    private void btnAnnulerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAnnulerActionPerformed
        // TODO add your handling code here:
        loadPosteComptablesNatures();
        ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "nature");
    }//GEN-LAST:event_btnAnnulerActionPerformed

    private void jListPCNatureMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListPCNatureMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            PosteComptableNature naturePC = (PosteComptableNature) jListPCNature.getSelectedValue();
            if (naturePC != null) {
                jListPC.removeAll();
                List<PosteComptable> list = new ArrayList();
                try {
                    list = GrecoServiceFactory.getPosteComptableService().getPosteComptableByNature(naturePC.getNaturePC());
                } catch (Exception e) {
                }
                if (list != null && !list.isEmpty()) {
                    jListPC.setListData(list.toArray());
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "list");
                } else {
                    ((CardLayout) getContentPane().getLayout()).show(getContentPane(), "accueil");
                }
            }

        }
    }//GEN-LAST:event_jListPCNatureMouseClicked

    private void btnSelectionnerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectionnerActionPerformed
        // TODO add your handling code here:
        final ViewLocaliteDialog dialog = new ViewLocaliteDialog(null, true);
        dialog.setVisible(true);
        locality = dialog.getSelectedLocalite();
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        if(locality == null){ 
            lblLocalite.setForeground(Color.red);
            lblLocalite.setText("Attention!!! aucune localité choisie");
        }else {
            lblLocalite.setForeground(new Color(0,153,102));
            lblLocalite.setText(locality.getLibelle(Locale.getDefault()));
        }
        
    }//GEN-LAST:event_btnSelectionnerActionPerformed

    private boolean controlData() {
        boolean res = true;
        PosteComptableNature n = (PosteComptableNature) cboNaturePC.getSelectedItem();
        if(n == null){
            JOptionPane.showMessageDialog(this, "Selectionnez la nature du poste comptable", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtCode.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("pleaseCode"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtAbbreviation.getTextFr().isEmpty() || txtAbbreviation.getTextUs().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("pleaseSigle"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtLibelle.getTextFr().isEmpty() || txtLibelle.getTextUs().isEmpty()) {
            JOptionPane.showMessageDialog(this, java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("pleaseLibelle"), java.util.ResourceBundle.getBundle("cm/eusoworks/properties/OrganisationDialog").getString("grecoMsg"), JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if(locality == null){
            JOptionPane.showMessageDialog(this, "Selectionnez la localite geographique dans laquelle le poste comptable est crée", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(PosteComptableDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(PosteComptableDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(PosteComptableDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(PosteComptableDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                PosteComptableDialog dialog = new PosteComptableDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAddOrg;
    private javax.swing.JButton btnAnnuler;
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.JButton btnListeCompleteOrg;
    private javax.swing.JButton btnNewOrg;
    private javax.swing.JButton btnSelectionner;
    private javax.swing.JButton btnSupprimer;
    private javax.swing.JComboBox cboNaturePC;
    private javax.swing.JCheckBox chkActive;
    private org.jdesktop.swingx.JXDatePicker dtpDateCessation;
    private org.jdesktop.swingx.JXDatePicker dtpDateCreation;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private org.jdesktop.swingx.JXList jListPC;
    private javax.swing.JList jListPCNature;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JLabel lblLocalite;
    private javax.swing.JPanel pAccueil;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListNature;
    private javax.swing.JPanel pListPC;
    private editor.EditorRTF txtAbbreviation;
    private javax.swing.JFormattedTextField txtCode;
    private editor.EditorRTF txtLibelle;
    // End of variables declaration//GEN-END:variables
}
