/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import static cm.eusoworks.context.GrecoSession.optionNiveau;
import cm.eusoworks.entities.model.ActiviteNiveau;
import cm.eusoworks.entities.model.CategorieNiveau;
import cm.eusoworks.entities.model.CompteNiveau;
import cm.eusoworks.entities.model.FonctionNiveau;
import cm.eusoworks.entities.model.LocaliteNiveau;
import cm.eusoworks.entities.model.OptionNiveauMax;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import org.jdesktop.swingx.autocomplete.AutoCompleteDecorator;

/**
 *
 * @author macbookair
 */
public class ParametreNomenclatureDialog extends GrecoTemplateDialog {

    
    /**
     * Creates new form ParametreNomenclatureDialog
     */
    public ParametreNomenclatureDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        initCombo();
        AutoCompleteDecorator.decorate(cboFonction);
        AutoCompleteDecorator.decorate(cboCategorie);
        AutoCompleteDecorator.decorate(cboLocalite);
        AutoCompleteDecorator.decorate(cboCompte);
        AutoCompleteDecorator.decorate(cboActivite);
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : "+"Spécifications des niveaux  ");
    }

    private void initCombo(){
        
        try {
            List<FonctionNiveau> l = GrecoServiceFactory.getNiveauService().listeNiveauFonction();
            cboFonction.setModel(new DefaultComboBoxModel(l.toArray()));
            if(optionNiveau != null){
                for (int i = 0; i < cboFonction.getItemCount(); i++) {
                    FonctionNiveau o = (FonctionNiveau) cboFonction.getItemAt(i);
                    if(o.getNiveauFonctionID() == optionNiveau.getFu().intValue()){
                        cboFonction.setSelectedIndex(i);
                        break;
                    }
                }
            }else {
                cboFonction.setSelectedIndex(cboFonction.getItemCount() - 1);
            }
        } catch (Exception e) {
        }
        try {
            List<CategorieNiveau> l = GrecoServiceFactory.getNiveauService().listeNiveauCategorie();
            cboCategorie.setModel(new DefaultComboBoxModel(l.toArray()));
            if(optionNiveau != null){
                for (int i = 0; i < cboCategorie.getItemCount(); i++) {
                    CategorieNiveau o = (CategorieNiveau) cboCategorie.getItemAt(i);
                    if(o.getNiveauCategorieID() == optionNiveau.getCa().intValue()){
                        cboCategorie.setSelectedIndex(i);
                        break;
                    }
                }
            }else {
                cboCategorie.setSelectedIndex(cboCategorie.getItemCount() - 1);
            }
        } catch (Exception e) {
        }
        try {
            List<LocaliteNiveau> l = GrecoServiceFactory.getNiveauService().listeNiveauLocalite();
            cboLocalite.setModel(new DefaultComboBoxModel(l.toArray()));
            if(optionNiveau != null){
                for (int i = 0; i < cboLocalite.getItemCount(); i++) {
                    LocaliteNiveau o = (LocaliteNiveau) cboLocalite.getItemAt(i);
                    if(o.getNiveauLocaliteID() == optionNiveau.getLo().intValue()){
                        cboLocalite.setSelectedIndex(i);
                        break;
                    }
                }
            }else {
                cboLocalite.setSelectedIndex(cboLocalite.getItemCount() - 1);
            }
        } catch (Exception e) {
        }
        try {
            List<CompteNiveau> l = GrecoServiceFactory.getNiveauService().listeNiveauCompte();
            cboCompte.setModel(new DefaultComboBoxModel(l.toArray()));
            if(optionNiveau != null){
                for (int i = 0; i < cboCompte.getItemCount(); i++) {
                    CompteNiveau o = (CompteNiveau) cboCompte.getItemAt(i);
                    if(o.getNiveauCompteID() == optionNiveau.getPc().intValue()){
                        cboCompte.setSelectedIndex(i);
                        break;
                    }
                }
            }else {
                cboCompte.setSelectedIndex(cboCompte.getItemCount() - 1);
            }
        } catch (Exception e) {
        }
        try {
            List<ActiviteNiveau> l = GrecoServiceFactory.getNiveauService().listeNiveauActivite();
            cboActivite.setModel(new DefaultComboBoxModel(l.toArray()));
            if(optionNiveau != null){
                for (int i = 0; i < cboActivite.getItemCount(); i++) {
                    ActiviteNiveau o = (ActiviteNiveau) cboActivite.getItemAt(i);
                    if(o.getNiveauActiviteID() == optionNiveau.getAt().intValue()){
                        cboActivite.setSelectedIndex(i);
                        break;
                    }
                }
            }else {
                cboActivite.setSelectedIndex(cboActivite.getItemCount() - 1);
            }
        } catch (Exception e) {
        }
        
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        cboFonction = new javax.swing.JComboBox();
        jLabel2 = new javax.swing.JLabel();
        cboCategorie = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        cboLocalite = new javax.swing.JComboBox();
        cboCompte = new javax.swing.JComboBox();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cboActivite = new javax.swing.JComboBox();
        btnAppliquer = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Parametrage des nomenclatures");

        jLabel1.setText("Classification fonctionnelle :");

        cboFonction.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel2.setText("Categorie de services :");

        cboCategorie.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel3.setText("Carte administrative des regions : ");

        cboLocalite.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cboCompte.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel4.setText("Plan comptable : ");

        jLabel5.setText("Nomenclature programmatique : ");

        cboActivite.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnAppliquer.setText("Appliquer ");
        btnAppliquer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAppliquerActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboFonction, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboCategorie, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboLocalite, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboCompte, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(cboActivite, javax.swing.GroupLayout.PREFERRED_SIZE, 232, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(182, 182, 182)
                        .addComponent(btnAppliquer)))
                .addContainerGap(27, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(cboFonction, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(cboCategorie, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(cboLocalite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(cboCompte, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cboActivite, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addComponent(btnAppliquer)
                .addGap(14, 14, 14))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnAppliquerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAppliquerActionPerformed
        // TODO add your handling code here:
        int fu = ((FonctionNiveau)cboFonction.getSelectedItem()).getNiveauFonctionID();
        int ca = ((CategorieNiveau)cboCategorie.getSelectedItem()).getNiveauCategorieID();
        int lo = ((LocaliteNiveau)cboLocalite.getSelectedItem()).getNiveauLocaliteID();
        int pc = ((CompteNiveau)cboCompte.getSelectedItem()).getNiveauCompteID();
        int at = ((ActiviteNiveau)cboActivite.getSelectedItem()).getNiveauActiviteID();
        
        try {
            GrecoServiceFactory.getNiveauService().saveParametreNiveau(fu, ca, lo, pc, at, GrecoSession.USER_CONNECTED.getLogin(), GrecoSession.USER_ADRESSE_IP);
            GrecoSession.notifications.success();
        } catch (GrecoException e) {
            GrecoSession.notifications.echec();
            ManageException.show(e, GrecoSession.USER_LANGUAGE);
        }
        
        try {
            optionNiveau = GrecoServiceFactory.getNiveauService().getOptionNiveauxMax();
        } catch (Exception e) {
            optionNiveau = null;
        }
    }//GEN-LAST:event_btnAppliquerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ParametreNomenclatureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ParametreNomenclatureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ParametreNomenclatureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ParametreNomenclatureDialog.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                ParametreNomenclatureDialog dialog = new ParametreNomenclatureDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnAppliquer;
    private javax.swing.JComboBox cboActivite;
    private javax.swing.JComboBox cboCategorie;
    private javax.swing.JComboBox cboCompte;
    private javax.swing.JComboBox cboFonction;
    private javax.swing.JComboBox cboLocalite;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
