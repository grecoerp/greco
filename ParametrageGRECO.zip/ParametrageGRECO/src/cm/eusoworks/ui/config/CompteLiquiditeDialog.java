/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Droits;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.entities.model.Banque;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.CompteLiquidite;
import cm.eusoworks.entities.model.Journaux;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.awt.Color;
import java.awt.Dimension;
import java.util.ArrayList;
import java.util.List;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import org.jdesktop.swingx.decorator.ColorHighlighter;
import org.jdesktop.swingx.decorator.HighlightPredicate;
import org.jdesktop.swingx.renderer.DefaultListRenderer;

/**
 *
 * @author macbookair
 */
public class CompteLiquiditeDialog extends GrecoTemplateDialog {

    /**
     * Creates new form OrganisationDialog
     */
    private CompteLiquidite currentLiquidite = null;
    private Compte compteCredit;
    private Journaux journal;

    public CompteLiquiditeDialog(JFrame parent, boolean modal) {
        super(parent, modal);
        initComponents();
        jListComptes.setRolloverEnabled(true);
        jListComptes.setCellRenderer(new DefaultListRenderer());
        jListComptes.addHighlighter(new ColorHighlighter(HighlightPredicate.ROLLOVER_ROW, new Color(135, 164, 190), Color.white));
        loadCompteLiquidite();
        loadJournaux();
        loadBanque();
        initUI();
        setLocationRelativeTo(null);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Compte(s) de Liquidite : Banque et Caisse  ");
        setPreferredSize(new Dimension(750, 500));
        pack();
        setLocationRelativeTo(null);
    }

    private void loadJournaux() {
        List<Journaux> lj = GrecoServiceFactory.getComptaService().journauxList();
        if (lj != null) {
            cboJournal.setModel(new DefaultComboBoxModel(lj.toArray()));
        }
    }

    private void loadBanque() {
        List<Banque> lj = GrecoServiceFactory.getBanqueService().banqueListe();
        if (lj != null) {
            lj.add(null);
            cboBanque.setModel(new DefaultComboBoxModel(lj.toArray()));
            cboBanque.setSelectedIndex(-1);
        }
    }

    private void loadCompteLiquidite() {
        List<CompteLiquidite> list = new ArrayList<CompteLiquidite>();
        try {
            list = GrecoServiceFactory.getComptaService().liquiditeListe(CompteLiquidite.ALL);
        } catch (Exception e) {
            list = null;
        }
        jListComptes.removeAll();
        if (list != null) {
            jListComptes.setListData(list.toArray());
        }
    }

    private void initUI() {
        if (currentLiquidite == null) {
            txtLibelle.clear();
            txtCode.setText("");
            compteCredit = null;
            lblCompteCredit.setText("");
            cboJournal.setSelectedItem(null);
        } else {
            txtCode.setText(currentLiquidite.getCode());
            try {
                txtLibelle.setTextFr(currentLiquidite.getLibelleFr());
            } catch (Exception e) {
            }
            try {
                txtLibelle.setTextUs(currentLiquidite.getLibelleUs());
            } catch (Exception e) {
            }
            //initialisation des type
            if (currentLiquidite.getIsBanque()) {
                rdbBanque.setSelected(true);
            }else {
                rdbCaisse.setSelected(true);
            }
                
            lblCompteCredit.setText(currentLiquidite.getCompte());
            for (int i = 0; i < cboJournal.getItemCount(); i++) {
                String  jrnl = cboJournal.getItemAt(i);
                if(jrnl.startsWith(currentLiquidite.getJournalID())){
                    cboJournal.setSelectedIndex(i);
                }
            }
            cboJournal.setSelectedItem(currentLiquidite.getJournalID());
        }
    }

    private void remplirCurrentDroit() {
        currentLiquidite.setLibelleFr(txtLibelle.getTextFr().toUpperCase());
        currentLiquidite.setLibelleUs(txtLibelle.getTextUs().toUpperCase());
        currentLiquidite.setCode(txtCode.getText().trim());
        currentLiquidite.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
        currentLiquidite.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

        currentLiquidite.setCompte(compteCredit == null ? null : compteCredit.getCode());
        journal = (Journaux) cboJournal.getSelectedItem();
        currentLiquidite.setJournalID(journal == null ? null : journal.getJournalID());

        initialiseType();
    }

    private void initialiseType() {
        currentLiquidite.setIsBanque(rdbBanque.isSelected());
        if (rdbBanque.isSelected()) {
            currentLiquidite.setBanqueID(((Banque) cboBanque.getSelectedItem()).getCode());
        } else {
            currentLiquidite.setBanqueID(null);
        }
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jSplitPane1 = new javax.swing.JSplitPane();
        pListPC = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        jListComptes = new org.jdesktop.swingx.JXList();
        jPanel3 = new javax.swing.JPanel();
        btnAddCompteLiquidite = new cm.eusoworks.tools.ui.GButton();
        pDetails = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        txtLibelle = new editor.EditorRTF();
        jLabel4 = new javax.swing.JLabel();
        lblLocalite = new javax.swing.JLabel();
        lblCategorie = new javax.swing.JLabel();
        lblFonction = new javax.swing.JLabel();
        rdbBanque = new javax.swing.JRadioButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        cboJournal = new javax.swing.JComboBox<>();
        btnSelectCompteCredit = new javax.swing.JButton();
        lblCompteCredit = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txtCode = new javax.swing.JTextField();
        cboBanque = new javax.swing.JComboBox<>();
        rdbCaisse = new javax.swing.JRadioButton();
        jPanel2 = new javax.swing.JPanel();
        btnEnregistrer = new cm.eusoworks.tools.ui.GButton();
        btnSupprimer = new cm.eusoworks.tools.ui.GButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("GRECO - Gestion des droits à liquider");

        pListPC.setLayout(new java.awt.BorderLayout());

        jListComptes.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        jListComptes.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        jListComptes.setSelectionBackground(new java.awt.Color(204, 204, 255));
        jListComptes.setSelectionForeground(new java.awt.Color(0, 102, 255));
        jListComptes.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jListComptesMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(jListComptes);

        pListPC.add(jScrollPane2, java.awt.BorderLayout.CENTER);

        jPanel3.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 15, 5));

        btnAddCompteLiquidite.setText("Ajouter un compte de liquidite");
        btnAddCompteLiquidite.setCouleur(2);
        btnAddCompteLiquidite.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnAddCompteLiquidite.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnAddCompteLiquiditeActionPerformed(evt);
            }
        });
        jPanel3.add(btnAddCompteLiquidite);

        pListPC.add(jPanel3, java.awt.BorderLayout.SOUTH);

        jSplitPane1.setLeftComponent(pListPC);

        pDetails.setLayout(new java.awt.BorderLayout());

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setLayout(null);
        jPanel1.add(txtLibelle);
        txtLibelle.setBounds(130, 170, 300, 80);

        jLabel4.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel4.setText("IDENTIFIANT : ");
        jPanel1.add(jLabel4);
        jLabel4.setBounds(10, 100, 110, 40);

        lblLocalite.setForeground(new java.awt.Color(0, 153, 102));
        jPanel1.add(lblLocalite);
        lblLocalite.setBounds(390, 370, 300, 20);

        lblCategorie.setForeground(new java.awt.Color(255, 153, 0));
        jPanel1.add(lblCategorie);
        lblCategorie.setBounds(390, 290, 300, 20);
        jPanel1.add(lblFonction);
        lblFonction.setBounds(390, 330, 300, 20);

        buttonGroup1.add(rdbBanque);
        rdbBanque.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbBanque.setMnemonic('N');
        rdbBanque.setText("Compte bancaire ?");
        rdbBanque.setActionCommand("N");
        rdbBanque.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbBanqueActionPerformed(evt);
            }
        });
        jPanel1.add(rdbBanque);
        rdbBanque.setBounds(10, 10, 160, 23);

        jLabel2.setText("Compte a crediter : ");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 270, 140, 30);

        jLabel5.setText("Journal : ");
        jPanel1.add(jLabel5);
        jLabel5.setBounds(10, 320, 80, 20);

        jPanel1.add(cboJournal);
        cboJournal.setBounds(130, 320, 300, 27);

        btnSelectCompteCredit.setText("Sélectionner ...");
        btnSelectCompteCredit.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSelectCompteCreditActionPerformed(evt);
            }
        });
        jPanel1.add(btnSelectCompteCredit);
        btnSelectCompteCredit.setBounds(160, 270, 150, 29);

        lblCompteCredit.setFont(new java.awt.Font("Arial", 0, 18)); // NOI18N
        lblCompteCredit.setText("jLabel6");
        jPanel1.add(lblCompteCredit);
        lblCompteCredit.setBounds(330, 270, 110, 30);

        jLabel6.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel6.setText("Designation :");
        jPanel1.add(jLabel6);
        jLabel6.setBounds(10, 170, 90, 40);
        jPanel1.add(txtCode);
        txtCode.setBounds(130, 100, 300, 40);

        cboBanque.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jPanel1.add(cboBanque);
        cboBanque.setBounds(180, 10, 270, 27);

        buttonGroup1.add(rdbCaisse);
        rdbCaisse.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        rdbCaisse.setMnemonic('N');
        rdbCaisse.setText("Caisse ");
        rdbCaisse.setActionCommand("N");
        rdbCaisse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdbCaisseActionPerformed(evt);
            }
        });
        jPanel1.add(rdbCaisse);
        rdbCaisse.setBounds(10, 50, 160, 23);

        pDetails.add(jPanel1, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.RIGHT, 1, 5));

        btnEnregistrer.setText("    Enregistrer    ");
        btnEnregistrer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnEnregistrer.setStyle(1);
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });
        jPanel2.add(btnEnregistrer);

        btnSupprimer.setText("      Supprimer   ");
        btnSupprimer.setCouleur(1);
        btnSupprimer.setFont(new java.awt.Font("Arial", 0, 13)); // NOI18N
        btnSupprimer.setStyle(3);
        btnSupprimer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnSupprimerActionPerformed(evt);
            }
        });
        jPanel2.add(btnSupprimer);

        pDetails.add(jPanel2, java.awt.BorderLayout.SOUTH);

        jSplitPane1.setRightComponent(pDetails);

        getContentPane().add(jSplitPane1, java.awt.BorderLayout.CENTER);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void enregistrer() {
        if (controlData()) {
            int erreur = 0;
            if (currentLiquidite == null) {
                currentLiquidite = new CompteLiquidite();
                remplirCurrentDroit();
                try {

                    GrecoServiceFactory.getComptaService().liquiditeAjouter(currentLiquidite);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Compte de liquidite enregistré", "RESULTAT", JOptionPane.INFORMATION_MESSAGE);
                    loadCompteLiquidite();
                    initUI();
                } catch (GrecoException ex) {
                    currentLiquidite = null;
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            } else { // modification de l'organisation 
                remplirCurrentDroit();
                try {
                    GrecoServiceFactory.getComptaService().liquiditeModifier(currentLiquidite);
                    GrecoSession.notifications.success();
                    JOptionPane.showMessageDialog(this, "Compte de liquidite modifie", "RESULTAT", JOptionPane.INFORMATION_MESSAGE);
                    loadCompteLiquidite();
                    initUI();
                } catch (GrecoException ex) {
                    GrecoSession.notifications.echec();
                    ManageException.show(ex, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }

    private void supprimer() {
        if (!currentLiquidite.getLiquiditeID().isEmpty()) {
            int reponse = JOptionPane.showConfirmDialog(this, "Estes-vous sur de vouloir supprimer ce compte de liquidite ? " + "\n" + currentLiquidite.toString());
            if (reponse == JOptionPane.YES_OPTION) {
                try {
                    GrecoServiceFactory.getComptaService().liquiditeSupprimer(currentLiquidite.getLiquiditeID());
                    GrecoSession.notifications.success();
                    loadCompteLiquidite();
                    currentLiquidite = null;
                    initUI();
                } catch (GrecoException e) {
                    GrecoSession.notifications.echec();
                    ManageException.show(e, GrecoSession.USER_LANGUAGE);
                }
            }
        }
    }

    private void addNewDroit() {
        currentLiquidite = null;
        initUI();
    }
    private void jListComptesMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jListComptesMouseClicked
        // TODO add your handling code here:
        if (evt.getClickCount() == 2) {
            currentLiquidite = (CompteLiquidite) jListComptes.getSelectedValue();
            currentLiquidite = GrecoServiceFactory.getComptaService().liquiditeRechercherById(currentLiquidite.getLiquiditeID());
            initUI();
        }
    }//GEN-LAST:event_jListComptesMouseClicked

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        enregistrer();
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    private void btnSupprimerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSupprimerActionPerformed
        // TODO add your handling code here:
        supprimer();
        loadCompteLiquidite();
    }//GEN-LAST:event_btnSupprimerActionPerformed

    private void btnAddCompteLiquiditeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnAddCompteLiquiditeActionPerformed
        // TODO add your handling code here:
        addNewDroit();
    }//GEN-LAST:event_btnAddCompteLiquiditeActionPerformed

    private void btnSelectCompteCreditActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnSelectCompteCreditActionPerformed
        // TODO add your handling code here:
        final ViewCompteDialog dialog = new ViewCompteDialog(null, true);
        dialog.setVisible(true);
        Compte compte = dialog.getSelectedCompte();
        if (compte.getNiveauID() < GrecoSession.optionNiveau.getPc()) {
            compte = null;
        }
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    dialog.dispose();
                } catch (Exception e) {
                }
            }
        });
        compteCredit = compte;
        if (compte == null) {
            lblCompteCredit.setForeground(Color.red);
            lblCompteCredit.setText("Compte absent !!!  ");
        } else {
            lblCompteCredit.setForeground(new Color(0, 153, 102));
            lblCompteCredit.setText(compte.getCode());
        }
    }//GEN-LAST:event_btnSelectCompteCreditActionPerformed

    private void rdbBanqueActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbBanqueActionPerformed
        // TODO add your handling code here:
        cboBanque.setSelectedIndex(-1);
        if (rdbBanque.isSelected()) {
            cboBanque.setEnabled(true);
        } else {
            cboBanque.setEnabled(false);
        }
    }//GEN-LAST:event_rdbBanqueActionPerformed

    private void rdbCaisseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdbCaisseActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdbCaisseActionPerformed

    private boolean controlData() {
        boolean res = true;

        if (txtCode.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le code caisse ou le RIB", "ATTENTION", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (txtLibelle.getTextFr().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le libellé ", "ATTENTION", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (buttonGroup1.getSelection() == null) {
            JOptionPane.showMessageDialog(this, "Veuillez selectionner le type de compte ", "ATTENTION", JOptionPane.WARNING_MESSAGE);
            return false;
        }

        if (rdbBanque.isSelected()) {
            if (cboBanque.getSelectedItem() == null) {
                JOptionPane.showMessageDialog(this, "Vous avez choisit un compte de liquidite Banque. \n Veuillez selectionner la banque SVP", "ATTENTION", JOptionPane.WARNING_MESSAGE);
                return false;
            }
        }
        return res;
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CompteLiquiditeDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CompteLiquiditeDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CompteLiquiditeDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CompteLiquiditeDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                CompteLiquiditeDialog dialog = new CompteLiquiditeDialog(new javax.swing.JFrame(), true);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private cm.eusoworks.tools.ui.GButton btnAddCompteLiquidite;
    private cm.eusoworks.tools.ui.GButton btnEnregistrer;
    private javax.swing.JButton btnSelectCompteCredit;
    private cm.eusoworks.tools.ui.GButton btnSupprimer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboBanque;
    private javax.swing.JComboBox<String> cboJournal;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private org.jdesktop.swingx.JXList jListComptes;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSplitPane jSplitPane1;
    private javax.swing.JLabel lblCategorie;
    private javax.swing.JLabel lblCompteCredit;
    private javax.swing.JLabel lblFonction;
    private javax.swing.JLabel lblLocalite;
    private javax.swing.JPanel pDetails;
    private javax.swing.JPanel pListPC;
    private javax.swing.JRadioButton rdbBanque;
    private javax.swing.JRadioButton rdbCaisse;
    private javax.swing.JTextField txtCode;
    private editor.EditorRTF txtLibelle;
    // End of variables declaration//GEN-END:variables
}
