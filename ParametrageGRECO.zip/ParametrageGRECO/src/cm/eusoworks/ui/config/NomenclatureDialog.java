/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.ui.config;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.context.GrecoServiceFactory;
import cm.eusoworks.context.GrecoSession;
import cm.eusoworks.entities.model.Categorie;
import cm.eusoworks.entities.model.Compte;
import cm.eusoworks.entities.model.Fonction;
import cm.eusoworks.entities.model.Localite;
import cm.eusoworks.entities.model.LocaliteNiveau;
import cm.eusoworks.entities.exception.GrecoException;
import cm.eusoworks.tools.exception.ManageException;
import cm.eusoworks.tree.CompteNode;
import cm.eusoworks.ui.tpl.GrecoTemplateDialog;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.text.DefaultFormatterFactory;
import javax.swing.text.MaskFormatter;

/**
 *
 * @author macbookair
 */
public class NomenclatureDialog extends JDialog {

    /**
     * Creates new form NomenclatureDialog
     */
    Object noeudParent;
    Object noeud;
    LocaliteNiveau localteNiveau;

    public NomenclatureDialog(JDialog parent, boolean modal, Object noeudParent, Object noeud, LocaliteNiveau locNiv) {
        super(parent, modal);
        initComponents();
        this.noeud = noeud;
        this.noeudParent = noeudParent;
        this.localteNiveau = locNiv;
        initMask();
        initModification();

//        setResizable(false);
        setTitle(GrecoAppConfig.getAppAbbreviation() + " : " + "Nomenclature ... ");
        setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        pack();
        setLocationRelativeTo(null);
    }

    public NomenclatureDialog(JDialog parent, boolean modal, Object noeudParent, Object noeud) {
        this(parent, modal, noeudParent, noeud, null);
    }

    private void initModification() {
        pOptions.setVisible(false);
        if (noeud != null) {
            if (noeud instanceof Categorie) {
                Categorie o = (Categorie) noeud;
                txtAbbreviation.setTextFr(o.getAbbreviationFr());
                txtAbbreviation.setTextUs(o.getAbbreviationUs());
                txtLibelle.setTextFr(o.getLibelleFr());
                txtLibelle.setTextUs(o.getLibelleUs());
            } else if (noeud instanceof Compte) {
                Compte o = (Compte) noeud;
                txtAbbreviation.setTextFr(o.getAbbreviationFr());
                txtAbbreviation.setTextUs(o.getAbbreviationUs());
                txtLibelle.setTextFr(o.getLibelleFr());
                txtLibelle.setTextUs(o.getLibelleUs());
                try {
                    if (o.getNature().equalsIgnoreCase(Compte.NATURE_CHARGES)) {
                        rdbCharge.setSelected(true);
                    } else {
                        rdbProduit.setSelected(true);
                    }
                } catch (Exception e) {
                }
                pOptions.setVisible(true);

            } else if (noeud instanceof Fonction) {
                Fonction o = (Fonction) noeud;
                txtAbbreviation.setTextFr(o.getAbbreviationFr());
                txtAbbreviation.setTextUs(o.getAbbreviationUs());
                txtLibelle.setTextFr(o.getLibelleFr());
                txtLibelle.setTextUs(o.getLibelleUs());
            } else if (noeud instanceof Localite) {
                Localite o = (Localite) noeud;
                txtAbbreviation.setTextFr(o.getAbbreviationFr());
                txtAbbreviation.setTextUs(o.getAbbreviationUs());
                txtLibelle.setTextFr(o.getLibelleFr());
                txtLibelle.setTextUs(o.getLibelleUs());
            }
        } else if (noeudParent instanceof Compte) {
            pOptions.setVisible(true);
        }
    }

    private void initMask() {
        String codeP = "";
        int nbChiffre = 0;
        int niveau;

        panelCompteNature.setVisible(false);

        if (noeud == null) { // ajout d un noeud
            String mask = "";
            if (noeudParent instanceof Categorie) {
                codeP = ((Categorie) noeudParent).getCode();
                mask = (codeP == null ? "" : codeP);
            } else if (noeudParent instanceof Fonction) {
                codeP = ((Fonction) noeudParent).getCode();
                mask = (codeP == null ? "" : codeP);
            } else if (noeudParent instanceof Localite) {
                codeP = ((Localite) noeudParent).getCode();
                if (localteNiveau == null) {
                    mask = (codeP == null ? "" : codeP);
                } else {
                    String m = localteNiveau.getMask();
                    int i = m.length();
                    mask = (codeP == null ? m : codeP.concat(m).substring(0, i));
                    ;
                }
            } else if (noeudParent instanceof Compte) {
                try {
                    if (((Compte) noeudParent).getNiveauID() >= (GrecoSession.optionNiveau.getPc() - 1)) {
                        panelCompteNature.setVisible(true);
                    }
                } catch (Exception e) {
                }
                codeP = ((Compte) noeudParent).getCode();
                mask = (codeP == null ? "" : codeP);
            }

            txtRadical.setText(mask);

        } else { // modification d'un noeud
            if (noeud instanceof Categorie) {
                codeP = ((Categorie) noeud).getCode();
                nbChiffre = ((Categorie) noeud).getNiveauID();
            } else if (noeud instanceof Fonction) {
                codeP = ((Fonction) noeud).getCode();
                nbChiffre = ((Fonction) noeud).getNiveauID();
            } else if (noeud instanceof Localite) {
                codeP = ((Localite) noeud).getCode();
                nbChiffre = ((Localite) noeud).getNiveauID();
            } else if (noeud instanceof Compte) {
                try {
                    if (((Compte) noeud).getNiveauID() >= GrecoSession.optionNiveau.getPc()) {
                        panelCompteNature.setVisible(true);
                    }
                } catch (Exception e) {
                }
                codeP = ((Compte) noeud).getCode();
                nbChiffre = ((Compte) noeud).getNiveauID();
            }

            txtCodeSaisie.setText(codeP);
            txtRadical.setEnabled(false);
            txtCodeSaisie.setEnabled(false);
        }
    }

    private boolean controlData() {
        boolean res = true;
        if (txtCodeSaisie.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (txtLibelle.getTextFr().isEmpty() || txtLibelle.getTextUs().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez saisir le libelle en francais et en anglais", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        if (!rdbCharge.isSelected() && !rdbProduit.isSelected()) {
            JOptionPane.showMessageDialog(this, "Veuillez choisir la nature du compte : CHARGE / PRODUIT", "GRECO", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return res;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jLabel1 = new javax.swing.JLabel();
        txtAbbreviation = new editor.EditorRTF();
        panelCompteNature = new javax.swing.JPanel();
        rdbCharge = new javax.swing.JRadioButton();
        rdbProduit = new javax.swing.JRadioButton();
        txtLibelle = new editor.EditorRTF();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        btnEnregistrer = new javax.swing.JButton();
        pOptions = new javax.swing.JPanel();
        cboLetragePointage = new javax.swing.JComboBox<>();
        chkCentralisable = new javax.swing.JCheckBox();
        chkSaisieOut = new javax.swing.JCheckBox();
        chkCreerParent = new javax.swing.JCheckBox();
        txtRadical = new javax.swing.JTextField();
        txtCodeSaisie = new javax.swing.JTextField();

        jLabel1.setText("Abbreviation :");

        panelCompteNature.setBackground(new java.awt.Color(102, 255, 204));
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 15, 5);
        flowLayout1.setAlignOnBaseline(true);
        panelCompteNature.setLayout(flowLayout1);

        buttonGroup1.add(rdbCharge);
        rdbCharge.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbCharge.setSelected(true);
        rdbCharge.setText("charge");
        panelCompteNature.add(rdbCharge);

        buttonGroup1.add(rdbProduit);
        rdbProduit.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        rdbProduit.setText("produit");
        panelCompteNature.add(rdbProduit);

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(255, 255, 255));

        jLabel2.setText("Intitule  : ");

        jLabel3.setFont(new java.awt.Font("Arial Black", 0, 14)); // NOI18N
        jLabel3.setText("Code : ");

        btnEnregistrer.setText("Enregistrer");
        btnEnregistrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnregistrerActionPerformed(evt);
            }
        });

        pOptions.setBorder(javax.swing.BorderFactory.createTitledBorder("Options "));

        cboLetragePointage.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Pas de lettrage, ni de pointage", "Compte lettrable", "Compte pointable" }));

        chkCentralisable.setText("Compte centralisable dans le grand livre");

        chkSaisieOut.setText("Ne pas afficher ce compte en saisie");

        chkCreerParent.setText("Si le compte n'existe pas, creer et rattacher les comptes ayant le meme radical");

        javax.swing.GroupLayout pOptionsLayout = new javax.swing.GroupLayout(pOptions);
        pOptions.setLayout(pOptionsLayout);
        pOptionsLayout.setHorizontalGroup(
            pOptionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOptionsLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(pOptionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pOptionsLayout.createSequentialGroup()
                        .addGroup(pOptionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cboLetragePointage, javax.swing.GroupLayout.PREFERRED_SIZE, 323, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(chkCentralisable, javax.swing.GroupLayout.DEFAULT_SIZE, 509, Short.MAX_VALUE)
                            .addComponent(chkSaisieOut, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addComponent(chkCreerParent, javax.swing.GroupLayout.DEFAULT_SIZE, 548, Short.MAX_VALUE))
                .addContainerGap())
        );
        pOptionsLayout.setVerticalGroup(
            pOptionsLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pOptionsLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cboLetragePointage, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chkCentralisable)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chkSaisieOut)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(chkCreerParent)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        txtRadical.setEditable(false);
        txtRadical.setFont(new java.awt.Font("Arial", 1, 24)); // NOI18N
        txtRadical.setHorizontalAlignment(javax.swing.JTextField.RIGHT);
        txtRadical.setToolTipText("");
        txtRadical.setEnabled(false);

        txtCodeSaisie.setFont(new java.awt.Font("Arial", 0, 24)); // NOI18N
        txtCodeSaisie.setHorizontalAlignment(javax.swing.JTextField.LEFT);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btnEnregistrer, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addComponent(pOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 78, Short.MAX_VALUE)
                                .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(23, 23, 23)
                                    .addComponent(txtRadical, javax.swing.GroupLayout.PREFERRED_SIZE, 90, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                    .addComponent(txtCodeSaisie, javax.swing.GroupLayout.PREFERRED_SIZE, 186, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addComponent(txtLibelle, javax.swing.GroupLayout.PREFERRED_SIZE, 482, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtRadical, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel3, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtCodeSaisie)))
                .addGap(22, 22, 22)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtLibelle, javax.swing.GroupLayout.PREFERRED_SIZE, 64, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(pOptions, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btnEnregistrer))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnregistrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnregistrerActionPerformed
        // TODO add your handling code here:
        if (noeudParent == null) {
            if (noeud instanceof Categorie) {
                if (controlData()) {
                    if (noeud == null) { // ajout d une nouvelle categorie dans la base
                        Categorie o = new Categorie();
                        o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                        o.setNiveauID(((Categorie) noeudParent).getNiveauID() + 1);
                        o.setParentCode(((Categorie) noeudParent).getCode());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                        try {
                            GrecoServiceFactory.getNomenclatureService().ajouterCategorie(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    } else {  // modification d'une categorie 
                        Categorie o = (Categorie) noeud;
                        o.setCode(txtCodeSaisie.getText().trim());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                        try {
                            GrecoServiceFactory.getNomenclatureService().modifierCategorie(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    }

                }
                return;
            }
            if (noeud instanceof Compte) {
                if (controlData()) {
                    if (noeud == null) { // ajout d un nouveau compte dans la base
                        Compte o = new Compte();
                        o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                        o.setNiveauID(((Compte) noeudParent).getNiveauID() + 1);
                        o.setParentCode(((Compte) noeudParent).getCode());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                        o.setCentralisateur(chkCentralisable.isSelected());
                        o.setAffichage(!chkSaisieOut.isSelected());
                        int i = cboLetragePointage.getSelectedIndex();
                        switch (i) {
                            case 0:
                                o.setPointage(false);
                                o.setLettrage(false);
                                break;
                            case 1:
                                o.setLettrage(true);
                                o.setPointage(false);
                                break;
                            case 2:
                                o.setPointage(true);
                                o.setLettrage(false);
                                break;
                        }

                        try {
                            if (((Compte) noeudParent).getNiveauID() >= (GrecoSession.optionNiveau.getPc() - 1)) {
                                o.setNature(rdbCharge.isSelected() ? Compte.NATURE_CHARGES : Compte.NATURE_PRODUITS);
                            } else {
                                o.setNature(null);
                            }
                        } catch (Exception e) {
                        }

                        try {
                            GrecoServiceFactory.getNomenclatureService().ajouterCompte(o, chkCreerParent.isSelected());
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    } else {  // modification d'un compte
                        Compte o = (Compte) noeud;
                        o.setCode(txtCodeSaisie.getText().trim());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                        o.setCentralisateur(chkCentralisable.isSelected());
                        o.setAffichage(!chkSaisieOut.isSelected());
                        int i = cboLetragePointage.getSelectedIndex();
                        switch (i) {
                            case 0:
                                o.setPointage(false);
                                o.setLettrage(false);
                                break;
                            case 1:
                                o.setLettrage(true);
                                o.setPointage(false);
                                break;
                            case 2:
                                o.setPointage(true);
                                o.setLettrage(false);
                                break;
                        }
                        try {
                            if (((Compte) noeud).getNiveauID() >= GrecoSession.optionNiveau.getPc()) {
                                o.setNature(rdbCharge.isSelected() ? Compte.NATURE_CHARGES : Compte.NATURE_PRODUITS);
                            } else {
                                o.setNature(null);
                            }
                        } catch (Exception e) {
                        }

                        try {
                            GrecoServiceFactory.getNomenclatureService().modifierCompte(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    }
                }
                return;

            }
            if (noeud instanceof Fonction) {
                if (controlData()) {
                    if (noeud == null) { // ajout d une nouvelle categorie dans la base
                        Fonction o = new Fonction();
                        o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                        o.setNiveauID(((Fonction) noeudParent).getNiveauID() + 1);
                        o.setParentCode(((Fonction) noeudParent).getCode());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                        try {
                            GrecoServiceFactory.getNomenclatureService().ajouterFonction(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    } else {  // modification d'une categorie 
                        Fonction o = (Fonction) noeud;
                        o.setCode(txtCodeSaisie.getText().trim());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                        try {
                            GrecoServiceFactory.getNomenclatureService().modifierFonction(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    }

                }
                return;
            }
            if (noeud instanceof Localite) {
                if (controlData()) {
                    if (noeud == null) { // ajout d une nouvelle categorie dans la base
                        Localite o = new Localite();
                        o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                        o.setNiveauID(((Localite) noeudParent).getNiveauID() + 1);
                        o.setParentCode(((Localite) noeudParent).getCode());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                        try {
                            GrecoServiceFactory.getNomenclatureService().ajouterLocalite(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    } else {  // modification d'une categorie 
                        Localite o = (Localite) noeud;
                        o.setCode(txtCodeSaisie.getText().trim());
                        o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                        o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                        o.setLibelleFr(txtLibelle.getTextFr().trim());
                        o.setLibelleUs(txtLibelle.getTextUs().trim());
                        o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                        o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                        try {
                            GrecoServiceFactory.getNomenclatureService().modifierLocalite(o);
                            GrecoSession.notifications.success();
                            this.dispose();
                        } catch (GrecoException e) {
                            GrecoSession.notifications.echec();
                            ManageException.show(e, GrecoSession.USER_LANGUAGE);
                        }
                    }

                }
                return;
            }
        } else if (noeudParent instanceof Categorie) {
            if (controlData()) {
                if (noeud == null) { // ajout d une nouvelle categorie dans la base
                    Categorie o = new Categorie();
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setNiveauID(((Categorie) noeudParent).getNiveauID() + 1);
                    o.setParentCode(((Categorie) noeudParent).getCode());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                    try {
                        GrecoServiceFactory.getNomenclatureService().ajouterCategorie(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                } else {  // modification d'une categorie 
                    Categorie o = (Categorie) noeud;
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                    try {
                        GrecoServiceFactory.getNomenclatureService().modifierCategorie(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                }

            }
            return;
        }
        if (noeudParent instanceof Fonction) {
            if (controlData()) {
                if (noeud == null) { // ajout d une nouvelle categorie dans la base
                    Fonction o = new Fonction();
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setNiveauID(((Fonction) noeudParent).getNiveauID() + 1);
                    o.setParentCode(((Fonction) noeudParent).getCode());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                    try {
                        GrecoServiceFactory.getNomenclatureService().ajouterFonction(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                } else {  // modification d'une categorie 
                    Fonction o = (Fonction) noeud;
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                    try {
                        GrecoServiceFactory.getNomenclatureService().modifierFonction(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                }

            }
            return;

        }
        if (noeudParent instanceof Localite) {
            if (controlData()) {
                if (noeud == null) { // ajout d une nouvelle categorie dans la base
                    Localite o = new Localite();
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setNiveauID(((Localite) noeudParent).getNiveauID() + 1);
                    o.setParentCode(((Localite) noeudParent).getCode());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                    try {
                        GrecoServiceFactory.getNomenclatureService().ajouterLocalite(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                } else {  // modification d'une categorie 
                    Localite o = (Localite) noeud;
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());

                    try {
                        GrecoServiceFactory.getNomenclatureService().modifierLocalite(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                }

            }
            return;

        }
        if (noeudParent instanceof Compte) {
            if (controlData()) {
                if (noeud == null) { // ajout d une nouvelle categorie dans la base
                    Compte o = new Compte();
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setNiveauID(((Compte) noeudParent).getNiveauID() + 1);
                    o.setParentCode(((Compte) noeudParent).getCode());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                    o.setCentralisateur(chkCentralisable.isSelected());
                    o.setAffichage(!chkSaisieOut.isSelected());
                    int i = cboLetragePointage.getSelectedIndex();
                    switch (i) {
                        case 0:
                            o.setPointage(false);
                            o.setLettrage(false);
                            break;
                        case 1:
                            o.setLettrage(true);
                            o.setPointage(false);
                            break;
                        case 2:
                            o.setPointage(true);
                            o.setLettrage(false);
                            break;
                    }
                    try {
                        if (((Compte) noeudParent).getNiveauID() >= (GrecoSession.optionNiveau.getPc() - 1)) {
                            o.setNature(rdbCharge.isSelected() ? Compte.NATURE_CHARGES : Compte.NATURE_PRODUITS);
                        } else {
                            o.setNature(null);
                        }
                    } catch (Exception e) {
                    }
                    o.setNature(rdbCharge.isSelected() ? Compte.NATURE_CHARGES : Compte.NATURE_PRODUITS);

                    try {
                        GrecoServiceFactory.getNomenclatureService().ajouterCompte(o, chkCreerParent.isSelected());
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                } else {  // modification d'un compte
                    Compte o = (Compte) noeud;
                    o.setCode(txtRadical.getText() + txtCodeSaisie.getText().trim());
                    o.setAbbreviationFr(txtAbbreviation.getTextFr().trim());
                    o.setAbbreviationUs(txtAbbreviation.getTextUs().trim());
                    o.setLibelleFr(txtLibelle.getTextFr().trim());
                    o.setLibelleUs(txtLibelle.getTextUs().trim());
                    o.setIpUpdate(GrecoSession.USER_ADRESSE_IP);
                    o.setUserUpdate(GrecoSession.USER_CONNECTED.getLogin());
                    o.setCentralisateur(chkCentralisable.isSelected());
                    o.setAffichage(!chkSaisieOut.isSelected());
                    int i = cboLetragePointage.getSelectedIndex();
                    switch (i) {
                        case 0:
                            o.setPointage(false);
                            o.setLettrage(false);
                            break;
                        case 1:
                            o.setLettrage(true);
                            o.setPointage(false);
                            break;
                        case 2:
                            o.setPointage(true);
                            o.setLettrage(false);
                            break;
                    }
                    try {
                        if (((Compte) noeud).getNiveauID() >= GrecoSession.optionNiveau.getPc()) {
                            o.setNature(rdbCharge.isSelected() ? Compte.NATURE_CHARGES : Compte.NATURE_PRODUITS);
                        } else {
                            o.setNature(null);
                        }
                    } catch (Exception e) {
                    }

                    try {
                        GrecoServiceFactory.getNomenclatureService().modifierCompte(o);
                        GrecoSession.notifications.success();
                        this.dispose();
                    } catch (GrecoException e) {
                        GrecoSession.notifications.echec();
                        ManageException.show(e, GrecoSession.USER_LANGUAGE);
                    }
                }

            }
            return;

        }
    }//GEN-LAST:event_btnEnregistrerActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(NomenclatureDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(NomenclatureDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(NomenclatureDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(NomenclatureDialog.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                NomenclatureDialog dialog = new NomenclatureDialog(null, true, null, null, null);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEnregistrer;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> cboLetragePointage;
    private javax.swing.JCheckBox chkCentralisable;
    private javax.swing.JCheckBox chkCreerParent;
    private javax.swing.JCheckBox chkSaisieOut;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JPanel pOptions;
    private javax.swing.JPanel panelCompteNature;
    private javax.swing.JRadioButton rdbCharge;
    private javax.swing.JRadioButton rdbProduit;
    private editor.EditorRTF txtAbbreviation;
    private javax.swing.JTextField txtCodeSaisie;
    private editor.EditorRTF txtLibelle;
    private javax.swing.JTextField txtRadical;
    // End of variables declaration//GEN-END:variables
}
