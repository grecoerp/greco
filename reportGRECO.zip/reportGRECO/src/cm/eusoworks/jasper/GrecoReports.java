/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.jasper;

import cm.eusoworks.context.GrecoAppConfig;
import cm.eusoworks.resources.images.GrecoImages;
import java.io.InputStream;
import java.util.HashMap;
import java.util.logging.Logger;

/**
 *
 * @author ouethy
 */
public class GrecoReports {

    private static String reportDir = "cm/eusoworks/jasper/";
    private static final String pta = "pta.jasper";
    private static final String ptaReduit = "ptaReduit.jasper";
    private static final String ptaTache = "ptaTache.jasper";
    private static final String ptaTacheParagraphe = "ptaTacheParagraphe.jasper";
    private static final String ptaParagraphe = "ptaParagraphe.jasper";
    private static final String bonCommandeAdministratif = "bonCommandeAdministratif.jasper";
    private static final String bonCommandeAdministratifCCAA = "bonCommandeAdministratifCCAA.jasper";
    private static final String bonCommandeAdministratifFST = "bonCommandeFST.jasper";
    private static final String bonCommandeAdministratifProforma = "bonCommandeFSTProforma.jasper";
    private static final String ordreMission = "ordreDeMission.jasper";
    private static final String ordreMissionCCAA = "ordreDeMissionCCAA.jasper";
    private static final String apercu = "modele.jasper";
    private static final String mandat = "mandat.jasper";
    private static final String ptaStructureParagraphe = "ptaStructureParagraphe.jasper";
    private static final String bordereauTransmission = "bordereauTransmission.jasper";
    private static final String bordereauTransmissionAC = "bordereauTransmissionAC.jasper";
    private static final String ficheEngagement = "FicheEngagement.jasper";
    private static final String ficheEngagementDroits = "FicheEngagementDroit.jasper";
    private static final String livreJournalEngagement = "LivreJournalEngagement.jasper";
    private static final String tracking = "tracking.jasper";
    private static final String structureCodification = "structureCodification.jasper";
    private static final String paieFiche = "fichePaie.jasper";
    private static final String paieBase = "FichePaieBase.jasper";
    private static final String paieRetenue = "FichePaieRetenues.jasper";
    private static final String paieNet = "FichePaieNet.jasper";
    private static final String paieRecapCotisation = "FichePaieRecapCotisations.jasper";
    private static final String ficheControleAE = "FicheControleAE.jasper";
    private static final String ficheControleAEDetails = "FicheControleAEDetails.jasper";
    private static final String ficheControleAEProjetDetails = "FicheControleAEProjetDetails.jasper";
    private static final String ficheConsolideeAEProjet = "FicheConsolideeAEProjet.jasper";
    private static final String missionFiche = "missionFiche.jasper";
    private static final String virement = "virement.jasper";
    private static final String virementDetails = "VirementDetails.jasper";
    private static final String fileficheControleProjetDetails = "FileFicheControleProjetDetails.jasper";
    private static final String fileficheConsolideeProjet = "FileFicheConsolideeProjet.jasper";
    private static final String ficheLevee = "ficheLevee.jasper";
    
    

    public HashMap mainParameters() {
        return mainParameters(null, null, null, null);
    }

    public HashMap mainParameters(String chapitreFR, String chapitreEN, String serviceFR, String serviceEN) {
        HashMap parameters = new HashMap();
        parameters.put("paysFR", GrecoAppConfig.getPaysFr());
        parameters.put("paysEN", GrecoAppConfig.getPaysUS());
        parameters.put("deviseFR", GrecoAppConfig.getDeviseFr());
        parameters.put("deviseEN", GrecoAppConfig.getDeviseUS());
        parameters.put("PARAM_DispositifFR", GrecoAppConfig.getAppTitleFr());
        parameters.put("PARAM_DispositifUS", GrecoAppConfig.getAppTitleUs());
        parameters.put("orgLibelleFr", GrecoAppConfig.getOrgLibelleFr());
        parameters.put("orgLibelleUs", GrecoAppConfig.getOrgLibelleUS());

        if (chapitreFR != null) {
            parameters.put("chapitreFR", chapitreFR);
        }
        if (chapitreEN != null) {
            parameters.put("chapitreEN", chapitreEN);
        }
        if (serviceFR != null) {
            parameters.put("serviceFR", serviceFR);
        }
        if (serviceEN != null) {
            parameters.put("serviceEN", serviceEN);
        }
        GrecoImages mesImages = new GrecoImages();
        parameters.put("fond", null);
        parameters.put("logo", mesImages.logo());
        return parameters;
    }

    
    public InputStream ptaOperation() {
        try {
            return getClass().getResourceAsStream(pta);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ptaTache() {
        try {
            return getClass().getResourceAsStream(ptaTache);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ptaTacheParagraphe() {
        try {
            return getClass().getResourceAsStream(ptaTacheParagraphe);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ptaTacheReduit() {
        try {
            return getClass().getResourceAsStream(ptaReduit);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ptaParagraphe() {
        try {
            return getClass().getResourceAsStream(ptaParagraphe);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream bonCommandeAdministratif() {
        try {
            return getClass().getResourceAsStream(bonCommandeAdministratif);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream bonCommandeAdministratifCCAA() {
        try {
            return getClass().getResourceAsStream(bonCommandeAdministratifCCAA);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream bonCommandeAdministratifFST() {
        try {
            return getClass().getResourceAsStream(bonCommandeAdministratifFST);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream bonCommandeAdministratifProforma() {
        try {
            return getClass().getResourceAsStream(bonCommandeAdministratifProforma);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ordreMisssion() {
        try {
            return getClass().getResourceAsStream(ordreMission);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ordreMisssionCCAA() {
        try {
            return getClass().getResourceAsStream(ordreMissionCCAA);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream apercu() {
        try {
            return getClass().getResourceAsStream(apercu);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream mandat() {
        try {
            return getClass().getResourceAsStream(mandat);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ptaStructureParagraphe() {
        try {
            return getClass().getResourceAsStream(ptaStructureParagraphe);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream bordereauTransmission() {
        try {
            return getClass().getResourceAsStream(bordereauTransmission);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream bordereauTransmissionAC() {
        try {
            return getClass().getResourceAsStream(bordereauTransmissionAC);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheEngagement() {
        try {
            return getClass().getResourceAsStream(ficheEngagement);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream ficheEngagementDroits() {
        try {
            return getClass().getResourceAsStream(ficheEngagementDroits);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream livreJournalEngagement() {
        try {
            return getClass().getResourceAsStream(livreJournalEngagement);
        } catch (Exception ex) {
            return null;
        }
    }

    public InputStream tracking() {
        try {
            return getClass().getResourceAsStream(tracking);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream structureCodification() {
        try {
            return getClass().getResourceAsStream(structureCodification);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream paieBulletin() {
        try {
            return getClass().getResourceAsStream(paieFiche);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream paieRubriqueBase() {
        try {
            return getClass().getResourceAsStream(paieBase);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream paieRubriqueRetenues() {
        try {
            return getClass().getResourceAsStream(paieRetenue);
        } catch (Exception ex) {
            return null;
        }
    }
    public InputStream paieRubriqueNet() {
        try {
            return getClass().getResourceAsStream(paieNet);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream paieRecapCotisation() {
        try {
            return getClass().getResourceAsStream(paieRecapCotisation);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ficheControleAE() {
        try {
            return getClass().getResourceAsStream(ficheControleAE);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ficheControleAEDetail() {
        try {
            return getClass().getResourceAsStream(ficheControleAEDetails);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ficheControleAEProjetDetails() {
        try {
            return getClass().getResourceAsStream(ficheControleAEProjetDetails);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ficheConsolideeAEProjet() {
        try {
            return getClass().getResourceAsStream(ficheConsolideeAEProjet);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ficheMission() {
        try {
            return getClass().getResourceAsStream(missionFiche);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream virement() {
        try {
            return getClass().getResourceAsStream(virement);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream virementDetails() {
        try {
            return getClass().getResourceAsStream(virementDetails);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream fileficheControleProjetDetails() {
        try {
            return getClass().getResourceAsStream(fileficheControleProjetDetails);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream fileficheConsolideeProjet() {
        try {
            return getClass().getResourceAsStream(fileficheConsolideeProjet);
        } catch (Exception ex) {
            return null;
        }
    }
    
    public InputStream ficheLevee() {
        try {
            return getClass().getResourceAsStream(ficheLevee);
        } catch (Exception ex) {
            return null;
        }
    }

}
