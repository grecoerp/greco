/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.report;


import cm.eusoworks.tools.ui.ProgressPane;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import net.sf.jasperreports.engine.*;
import net.sf.jasperreports.engine.data.JRBeanCollectionDataSource;

/**
 * Collection de méthodes utilitaires pour l'interaction avec JasperReports
 * @author Michel MBEM
 */
public class JRHelper {

    /**
     * Prépare et affiche un aperçu avant impression de l'état indiqué par <i>path</i>
     * @param path Le chemin d'accès au fichier d'état .jasper
     * @param parameters La collection des paramètres d'état
     * @param dataSource La source de données de l'état
     * @throws java.lang.Exception
     */
    public static void viewReport(String path, Map parameters, JRDataSource dataSource, String modName) throws Exception {
        JasperPrint jPrint = JasperFillManager.fillReport(path, parameters, dataSource);
        JReportFrame frame = new JReportFrame(modName, jPrint);
        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(true);
        viewer.setFitPageZoomRatio();
        frame.getContentPane().add(viewer);
        frame.setAlwaysOnTop(true);
        frame.setVisible(true);
    }

    public static void viewReport(InputStream jasper, Map parameters, JRDataSource dataSource, String modName) throws Exception {
        JasperPrint jPrint = JasperFillManager.fillReport(jasper, parameters, dataSource);
        JReportFrame frame = new JReportFrame(modName, jPrint);
        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(true);
        viewer.setFitPageZoomRatio();
        frame.getContentPane().add(viewer);
        frame.setAlwaysOnTop(true);
        frame.setVisible(true);
    }

    /**
     *
     * @param dialog
     * @param path Le chemin d'accès au fichier d'état .jasper
     * @param parameters La collection des paramètres d'état
     * @param dataSource La source de données de l'état
     * @throws java.lang.Exception
     */
    public static void viewReport(JFrame dialog, String path, Map parameters, JRDataSource dataSource) throws Exception {
        JasperPrint jPrint = JasperFillManager.fillReport(path, parameters, dataSource);
        printPreview(jPrint);
    }

    /**
     *
     * @param dialog
     * @param path
     * @param parameters
     * @param dataSource
     * @throws Exception
     */
    public static void viewReport(JDialog dialog, String path, Map parameters, JRDataSource dataSource) throws Exception {
        JasperPrint jPrint = JasperFillManager.fillReport(path, parameters, dataSource);
        printPreview(jPrint);
    }

    /**
     * Affiche un boîte de dialogue d'impression et imprime un état
     * @param path Le chemin d'accès au fichier d'état .jasper
     * @param parameters La collection des paramètres d'état
     * @param dataSource La source de données de l'état
     * @throws java.lang.Exception
     */
    public static void printReport(String path, Map parameters, JRDataSource dataSource) throws Exception {
        JasperPrint jPrint = JasperFillManager.fillReport(path, parameters, dataSource);
        JasperPrintManager.printReport(jPrint, true);
    }

    private static void printPreview(JasperPrint jPrint) {
        JReportFrame frame = new JReportFrame("", jPrint);
        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(true);
        viewer.setFitPageZoomRatio();

        frame.getContentPane().add(viewer);
        frame.setVisible(true);
    }

    private static void printPreview(JasperPrint jPrint, ProgressPane glasspane) {
        JReportFrame frame = new JReportFrame("", jPrint);
        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(true);
        viewer.setFitPageZoomRatio();

        frame.getContentPane().add(viewer);
        if (glasspane != null) {
            glasspane.stop();
            glasspane.interrupt();
        }
        frame.setVisible(true);
    }
    
//    private static void printPreview(JasperPrint jPrint, ReportProgressPanel glasspane) {
//        JReportFrame frame = new JReportFrame("", jPrint);
//        SIICJRPanel viewer = new SIICJRPanel(jPrint);
//        viewer.setEnableSaveButton(true);
//        viewer.setFitPageZoomRatio();
//
//        frame.getContentPane().add(viewer);
//        if (glasspane != null) {
//            glasspane.stop();
//            glasspane.interrupt();
//        }
//        frame.setVisible(true);
//    }
    

    

    private static void printPreview(JasperPrint jPrint, boolean hibeButton) {
        JReportFrame frame = new JReportFrame("", jPrint, hibeButton);
        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(false);
        viewer.setFitPageZoomRatio();
        frame.getContentPane().add(viewer);
        frame.setVisible(true);
    }

    private static void printPreview(JasperPrint jPrint, JFrame parent) {
        JReportFrame frame = new JReportFrame("", jPrint);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        frame.setSize(screenSize.width - 200, screenSize.height - 200);

        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(false);
        viewer.setFitPageZoomRatio();
        frame.getContentPane().add(viewer);
        frame.setVisible(true);
    }

    private static void printPreview(JasperPrint jPrint, JDialog parent) {
        JFrame frame = new JFrame();
        JDialog dialog = new JDialog(parent);

        //ImageIcon icon = new ImageIcon(JRHelper.class.getClassLoader().getResource("gfp/ui/resources/printer.png"));
        //frame.setIconImage(icon.getImage());
        //ResourceBundle resources = ResourceBundle.getBundle("gfp/ui/resources/MercuriaApp");
        //frame.setTitle(resources.getString("Application.title"));
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        dialog.setSize(screenSize.width - 200, screenSize.height - 200);
        dialog.setLocationRelativeTo(null);
        dialog.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
//        JRViewer viewer = new JRViewer(jPrint);
        SIICJRPanel viewer = new SIICJRPanel(jPrint);
        viewer.setEnableSaveButton(false);
        dialog.getContentPane().add(viewer);
        dialog.setVisible(true);
        viewer.setFitPageZoomRatio();
    }

    public static void viewReport(InputStream etat, HashMap parameters, JRDataSource ds, ImageIcon icon, String titre) throws JRException {
        JasperPrint jPrint = JasperFillManager.fillReport(etat, parameters, ds);
        printPreview(jPrint);
    }

    public static void viewReport(InputStream etat, HashMap parameters, JRDataSource ds, ProgressPane  glassPane) throws JRException {
        JasperPrint jPrint = JasperFillManager.fillReport(etat, parameters, ds);
        printPreview(jPrint, glassPane);
    }

    
//    public static void viewReport(InputStream etat, HashMap parameters, JRDataSource ds, com.siicore.component.ReportProgressPanel glassPane) throws JRException {
//        JasperPrint jPrint = JasperFillManager.fillReport(etat, parameters, ds);
//        printPreview(jPrint, glassPane);
//    }
    

    private static void printPreview(JasperPrint jPrint, ImageIcon icon, String title) {
        JFrame frame = new JFrame();
        if (icon != null) {
            frame.setIconImage(icon.getImage());
        }
        if (icon != null) {
            frame.setTitle(title);
        }
    }

    public static JasperPrint getJasperPrint(InputStream path, Map parameters, JRDataSource dataSource) throws Exception {
        return JasperFillManager.fillReport(path, parameters, dataSource);
    }

    public static void viewReport(JasperPrint jasperPrint, ImageIcon icon, String title) throws Exception {
        printPreview(jasperPrint, icon, title);
    }

    public static JasperPrint getJasperPrint(InputStream etat, HashMap parameters, JRDataSource ds) throws JRException {
        return JasperFillManager.fillReport(etat, parameters, ds);
    }

    public static void viewReport(JasperPrint jPrint, ProgressPane glasspane) throws JRException {
        printPreview(jPrint, glasspane);
    }
    
//    public static void viewReport(JasperPrint jPrint, com.siicore.component.ReportProgressPanel glasspane) throws JRException {
//        printPreview(jPrint, glasspane);
//    }
    
    public static void viewReport(JasperPrint jPrint) throws JRException {
        printPreview(jPrint);
    }

    public static void viewReport(InputStream etat, HashMap parameters, JRBeanCollectionDataSource ds, Object object, String string, boolean hideButton) {
        JasperPrint jPrint = null;
        try {
            jPrint = JasperFillManager.fillReport(etat, parameters, ds);
            printPreview(jPrint, hideButton);
        } catch (JRException ex) {
            Logger.getLogger(JRHelper.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public static JasperPrint mergeDocuments(JasperPrint doc1, JasperPrint doc2) {
        if (doc1 == null) {
            return doc2;
        } else {
            if (doc2 == null) {
                return doc1;
            }
            for (Object page : doc2.getPages()) {
                doc1.addPage((JRPrintPage) page);
            }
        }
        return doc1;
    }
}
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
