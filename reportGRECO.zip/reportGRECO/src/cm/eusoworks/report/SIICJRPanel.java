/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.report;

import java.io.InputStream;
import java.util.Locale;
import java.util.ResourceBundle;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.view.JRViewer;

/**
 *
 * @author sngos
 */
public class SIICJRPanel extends JRViewer{

    public SIICJRPanel(JasperPrint jrPrint, Locale locale, ResourceBundle resBundle) {
        super(jrPrint, locale, resBundle);
    }

    public SIICJRPanel(InputStream is, boolean isXML, Locale locale, ResourceBundle resBundle) throws JRException {
        super(is, isXML, locale, resBundle);
    }

    public SIICJRPanel(String fileName, boolean isXML, Locale locale, ResourceBundle resBundle) throws JRException {
        super(fileName, isXML, locale, resBundle);
    }

    public SIICJRPanel(JasperPrint jrPrint, Locale locale) {
        super(jrPrint, locale);
    }

    public SIICJRPanel(InputStream is, boolean isXML, Locale locale) throws JRException {
        super(is, isXML, locale);
    }

    public SIICJRPanel(String fileName, boolean isXML, Locale locale) throws JRException {
        super(fileName, isXML, locale);
    }

    public SIICJRPanel(JasperPrint jrPrint) {
        super(jrPrint);
    }

    public SIICJRPanel(InputStream is, boolean isXML) throws JRException {
        super(is, isXML);
    }

    public SIICJRPanel(String fileName, boolean isXML) throws JRException {
        super(fileName, isXML);

    }
   public void setEnableSaveButton(boolean enable){
       this.btnSave.setEnabled(enable);
   }
}
