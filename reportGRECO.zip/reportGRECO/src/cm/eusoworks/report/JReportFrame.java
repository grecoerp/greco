/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package cm.eusoworks.report;

import cm.eusoworks.context.GrecoAppConfig;
import java.awt.Desktop;
import java.awt.Toolkit;
import java.io.File;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileFilter;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JRExporter;
import net.sf.jasperreports.engine.JRExporterParameter;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.export.JRCsvExporter;
import net.sf.jasperreports.engine.export.JRHtmlExporter;
import net.sf.jasperreports.engine.export.JRPdfExporter;
import net.sf.jasperreports.engine.export.JRRtfExporter;
import net.sf.jasperreports.engine.export.JRTextExporter;
import net.sf.jasperreports.engine.export.JRXlsExporter;
import net.sf.jasperreports.engine.export.JRXmlExporter;
import net.sf.jasperreports.engine.export.oasis.JROdtExporter;
import net.sf.jasperreports.engine.export.ooxml.JRDocxExporter;

/**
 *
 * @author ouethy
 */
public class JReportFrame extends javax.swing.JDialog {

    JasperPrint report = null;
    String fformat;

    /** Creates new form JReportFrame */
    public JReportFrame(String moduleName, JasperPrint jPrint) {
        super();
        setModal(true);
        report = jPrint;
        initComponents();
        setTitle(GrecoAppConfig.getAppAbbreviation()+ " - Reporting tools");
        try {
            setIconImage((new ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/icon.png"))).getImage());
        } catch (Exception e) {
        }
        setSize(1000, 700);
        setLocationRelativeTo(null);
//        setAlwaysOnTop(true);
    }

    public JReportFrame(String moduleName, JasperPrint jPrint, boolean hideButton) {
        this(moduleName, jPrint);
    }

    FileFilter filtrePDF = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            return f.getName().toUpperCase().endsWith(".pdf");
        }

        @Override
        public String getDescription() {
            return "Fichiers Portable Document Format (*.PDF)";
        }
    };
    FileFilter filtreRTF = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            return f.getName().toLowerCase().endsWith(".rtf");
        }

        @Override
        public String getDescription() {
            return "Fichiers Rich Text Format (*.rtf)";
        }
    };
    FileFilter filtreDOC = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            return f.getName().toLowerCase().endsWith(".doc");
        }

        @Override
        public String getDescription() {
            return "Fichiers Microsoft Word 1997-2003 (*.doc)";
        }
    };
    FileFilter filtreXLS = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            return f.getName().toUpperCase().endsWith(".xls");
        }

        @Override
        public String getDescription() {
            return "Fichiers Microsoft Excel 1997-2003 (*.xls)";
        }
    };
    FileFilter filtreHTML = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            return f.getName().toUpperCase().endsWith(".html");
        }

        @Override
        public String getDescription() {
            return "Fichiers Internet (*.html)";
        }
    };
    FileFilter filtreODF = new FileFilter() {

        @Override
        public boolean accept(File f) {
            if (f.isDirectory()) {
                return true;
            }
            return f.getName().toUpperCase().endsWith(".odt");
        }

        @Override
        public String getDescription() {
            return "OpenOffice Writer (*.odt)";
        }
    };

    private static void exportToFile(JasperPrint jPrint, String destPath) throws JRException {
        JRExporter exporter = getExporter(FileUtil.getExtension(destPath).toLowerCase());
        if (exporter != null) {
            exporter.setParameter(JRExporterParameter.JASPER_PRINT, jPrint);
            exporter.setParameter(JRExporterParameter.OUTPUT_FILE_NAME, destPath);
            exporter.exportReport();
        }
    }

    private static JRExporter getExporter(String format) {
        if (format.equals(".pdf")) {
            return new JRPdfExporter();
        }
        if (format.equals(".rtf")) {
            return new JRRtfExporter();
        }
        if (format.equals(".xls")) {
            return new JRXlsExporter();
        }
        if (format.equals(".htm") || format.equals(".html")) {
            return new JRHtmlExporter();
        }
        if (format.equals(".xml") || format.equals(".jrpxml")) {
            return new JRXmlExporter();
        }
        if (format.equals(".txt")) {
            return new JRTextExporter();
        }
        if (format.equals(".csv")) {
            return new JRCsvExporter();
        }
        if (format.equals(".odt")) {
            return new JROdtExporter();
        }
        if (format.equals(".doc") || format.equals(".docx")) {
            return new JRDocxExporter();
        }
        return null;
    }

    public void exportToPDF() {
        fileChooser.addChoosableFileFilter(filtrePDF);
        fformat = ".pdf";
        exportRapport();
    }

    public void exportToDOC() {
        fileChooser.addChoosableFileFilter(filtreDOC);
        fformat = ".doc, .docx";
        exportRapport();
    }

    public void exportToRTF() {
        fileChooser.addChoosableFileFilter(filtreRTF);
        fformat = ".rtf";
        exportRapport();
    }

    public void exportToXLS() {
        fileChooser.addChoosableFileFilter(filtreXLS);
        fformat = ".xls";
        exportRapport();
    }

    public void exportToHTML() {
        fileChooser.addChoosableFileFilter(filtreHTML);
        fformat = ".html";
        exportRapport();
    }

    public void exportToODF() {
        fileChooser.addChoosableFileFilter(filtreODF);
        fformat = ".odt";
        exportRapport();
    }

    public void exportRapport() {
        File file = new File(report.getName().concat(fformat));//null;
        fileChooser.setSelectedFile(file);

        if (fileChooser.showOpenDialog(this) == JFileChooser.APPROVE_OPTION) {
            try {
                file = fileChooser.getSelectedFile();
                //attendre la fin de l'exportation avant d'esssayer d'editer le fichier
                exportToFile(report, file.getPath());//.concat(fformat));

            } catch (JRException ex) {
                Logger.getLogger(JReportFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
            try {
                if (Desktop.isDesktopSupported()) {
                    Desktop desktop = Desktop.getDesktop();
                    desktop.open(file);
                }
            } catch (IOException ex) {
                StringBuilder msg = new StringBuilder("Impossible d'accéder au fichier: \n\n");
                msg.append("1. Assure vous que le nom du fichier a été correctement saisi avec l'extension du fichier\n");
                msg.append("2. Vérifiez que vous avez les droits d'écriture sur le dossier ou sur le disque \n");
                msg.append("3. Vérifiez que le disque n'est pas plein \n");
                msg.append("4. Si le problème persiste, contactez votre administrateur système\n\n\n");
                msg.append(ex.getMessage());
                Toolkit.getDefaultToolkit().beep();
                JOptionPane.showMessageDialog(this, msg.toString(), "Echec", JOptionPane.ERROR_MESSAGE);
            }

        }
    }


    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        fileChooser = new javax.swing.JFileChooser();
        panelExport = new org.jdesktop.swingx.JXGlassBox();
        jPanel1 = new javax.swing.JPanel();
        linkExporter = new org.jdesktop.swingx.JXHyperlink();
        btnPDF = new javax.swing.JButton();
        btnEXCEL = new javax.swing.JButton();
        btnWORD = new javax.swing.JButton();
        btnODT = new javax.swing.JButton();
        btnIE = new javax.swing.JButton();
        btnRTF = new javax.swing.JButton();
        btnCSV = new javax.swing.JButton();
        btnXML = new javax.swing.JButton();

        panelExport.setLayout(new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 5));

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new java.awt.BorderLayout(0, 5));

        jPanel1.setBackground(new java.awt.Color(51, 51, 51));
        java.awt.FlowLayout flowLayout1 = new java.awt.FlowLayout(java.awt.FlowLayout.CENTER, 20, 5);
        flowLayout1.setAlignOnBaseline(true);
        jPanel1.setLayout(flowLayout1);

        linkExporter.setForeground(new java.awt.Color(255, 255, 255));
        linkExporter.setText("Exporter sous ...");
        linkExporter.setClickedColor(new java.awt.Color(153, 153, 153));
        linkExporter.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jPanel1.add(linkExporter);

        btnPDF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exPDF.png"))); // NOI18N
        btnPDF.setBorderPainted(false);
        btnPDF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnPDFActionPerformed(evt);
            }
        });
        jPanel1.add(btnPDF);

        btnEXCEL.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exExcel.png"))); // NOI18N
        btnEXCEL.setBorderPainted(false);
        btnEXCEL.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEXCELActionPerformed(evt);
            }
        });
        jPanel1.add(btnEXCEL);

        btnWORD.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exWord.png"))); // NOI18N
        btnWORD.setBorderPainted(false);
        btnWORD.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnWORDActionPerformed(evt);
            }
        });
        jPanel1.add(btnWORD);

        btnODT.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exODT.png"))); // NOI18N
        btnODT.setBorderPainted(false);
        btnODT.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnODTActionPerformed(evt);
            }
        });
        jPanel1.add(btnODT);

        btnIE.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exHtml.png"))); // NOI18N
        btnIE.setBorderPainted(false);
        btnIE.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnIEActionPerformed(evt);
            }
        });
        jPanel1.add(btnIE);

        btnRTF.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exRTF.png"))); // NOI18N
        btnRTF.setBorderPainted(false);
        btnRTF.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnRTFActionPerformed(evt);
            }
        });
        jPanel1.add(btnRTF);

        btnCSV.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exCSV.png"))); // NOI18N
        btnCSV.setBorderPainted(false);
        btnCSV.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnCSVActionPerformed(evt);
            }
        });
        jPanel1.add(btnCSV);

        btnXML.setIcon(new javax.swing.ImageIcon(getClass().getResource("/cm/eusoworks/resources/images/exXML.png"))); // NOI18N
        btnXML.setBorderPainted(false);
        btnXML.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnXMLActionPerformed(evt);
            }
        });
        jPanel1.add(btnXML);

        getContentPane().add(jPanel1, java.awt.BorderLayout.NORTH);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btnRTFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnRTFActionPerformed
        // TODO add your handling code here:
        exportToRTF();
    }//GEN-LAST:event_btnRTFActionPerformed

    private void btnPDFActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnPDFActionPerformed
        // TODO add your handling code here:
        exportToPDF();
    }//GEN-LAST:event_btnPDFActionPerformed

    private void btnEXCELActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEXCELActionPerformed
        // TODO add your handling code here:
        exportToXLS();
    }//GEN-LAST:event_btnEXCELActionPerformed

    private void btnODTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnODTActionPerformed
        // TODO add your handling code here:
        exportToODF();
    }//GEN-LAST:event_btnODTActionPerformed

    private void btnIEActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnIEActionPerformed
        // TODO add your handling code here:
        exportToHTML();
    }//GEN-LAST:event_btnIEActionPerformed

    private void btnCSVActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnCSVActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnCSVActionPerformed

    private void btnWORDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnWORDActionPerformed
        // TODO add your handling code here:
        exportToDOC();
    }//GEN-LAST:event_btnWORDActionPerformed

    private void btnXMLActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnXMLActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_btnXMLActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JReportFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JReportFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JReportFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JReportFrame.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnCSV;
    private javax.swing.JButton btnEXCEL;
    private javax.swing.JButton btnIE;
    private javax.swing.JButton btnODT;
    private javax.swing.JButton btnPDF;
    private javax.swing.JButton btnRTF;
    private javax.swing.JButton btnWORD;
    private javax.swing.JButton btnXML;
    private javax.swing.JFileChooser fileChooser;
    private javax.swing.JPanel jPanel1;
    private org.jdesktop.swingx.JXHyperlink linkExporter;
    private org.jdesktop.swingx.JXGlassBox panelExport;
    // End of variables declaration//GEN-END:variables
}
