/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cm.eusoworks.report;

import java.awt.Desktop;
import java.io.*;
import javax.swing.JOptionPane;

/**
 * Collection de méthodes utilitaires pour l'interaction avec le système de
 * fichiers.
 *
 * @author Michel MBEM
 */
public class FileUtil extends Object{

    /**
     * Vérifie qu'un fichier existe ou non
     *
     * @param path Le chemin d'accès au fichier
     * @return true si le fichier existe; false sinon
     */
    public static boolean exists(String path) {
        File file = new File(path);
        return file.exists();
    }

    /**
     * Vérifie qu'un chemin d'accès désigne un répertoire ou non
     *
     * @param path Le chemin d'accès au répertoire
     * @return true si le chemin désigne un répertoire; false sinon
     */
    public static boolean isDirectory(String path) {
        File file = new File(path);
        return file.exists() && file.isDirectory();
    }

    /**
     * Vérifie qu'un chemin d'accès désigne un fichier ou non
     *
     * @param path Le chemin d'accès au fichier
     * @return true si le chemin désigne un fichier; false sinon
     */
    public static boolean isFile(String path) {
        File file = new File(path);
        return file.exists() && file.isFile();
    }

    /**
     * Vérifie qu'un chemin d'accès désigne un fichier caché ou non
     *
     * @param path Le chemin d'accès au fichier
     * @return true si le chemin désigne un fichier caché; false sinon
     */
    public static boolean isHidden(String path) {
        File file = new File(path);
        return file.exists() && file.isHidden();
    }

    /**
     * Extrait le chemin d'accès au répertoire parent d'un fichier
     *
     * @param path Le chemin d'accès au fichier
     * @return une chaîne de caractères
     */
    public static String getDirectory(String path) {
        File file = new File(path);
        return file.getParent();
    }

    /**
     * Extrait le nom d'un fichier de son chemin d'accès
     *
     * @param path Le chemin d'accès au fichier
     * @return une chaîne de caractères
     */
    public static String getFileName(String path) {
        File file = new File(path);
        return file.getName();
    }

    public static String getFileNameWithoutExtension(String file) {
        return file.substring(0, file.lastIndexOf("."));
    }

    /**
     * Extrait l'extension du nom d'un fichier
     *
     * @param fileName Le chemin d'accès au fichier
     * @return une chaîne de caractères
     */
    public static String getExtension(String fileName) {
        if (fileName == null) {
            return null;
        }
        int lastDot = fileName.lastIndexOf(".");
        if (lastDot > fileName.lastIndexOf(File.separator)) {
            return fileName.substring(lastDot);
        }
        return "";
    }

    /**
     * Change l'extension d'un nom de fichier
     *
     * @param fileName le nom original du fichier
     * @param newExtension la nouvelle extension
     * @return une chaîne de caractères
     */
    public static String changeExtension(String fileName, String newExtension) {
        if (fileName == null) {
            return null;
        }
        int lastDot = fileName.lastIndexOf(".");
        if (lastDot > fileName.lastIndexOf(File.separator)) {
            return fileName.substring(0, lastDot) + newExtension;
        }
        return fileName;
    }

    /**
     * Concatène deux chemins d'accès pour avoir une chemin plus long
     *
     * @param path1 Le chemin d'accès au répertoire racine
     * @param path2 Le chémin d'accès au répertoire fils ou à un fichier
     * @return une chaîne de caractères
     */
    public static String combine(String path1, String path2) {
        if (path1 == null) {
            return path2;
        }
        if (path2 == null) {
            return path1;
        }
        if (path1.endsWith(File.separator)) {
            return path1 + path2;
        }
        return path1 + File.separator + path2;
    }

    /**
     * Obtient le répertoir d'acceuil de l'utilisateur du système
     *
     * @return une chaîne de caractères
     */
    public static String getUserDir() {
        return System.getProperty("user.home");
    }

    /**
     * Obtient le répertoire de travail de l'utilisateur courant
     *
     * @return une chaîne de caractères
     */
    public static String getCurrentDir() {
        return System.getProperty("user.dir");
    }

    /**
     * Obtient le chemin d'accès au répertoire temporaire de l'utilisateur
     *
     * @return une chaîne de caractères
     */
    public static String getTempDir() {
        return System.getProperty("java.io.tmpdir");
    }

    /**
     * Déplace ou renomme un fichier ou un répertoire
     *
     * @param source le fichier à déplacer
     * @param dest le répertoire de destination ou le nouveau nom
     * @return true si l'opération s'est bien deroulée; false sinon
     */
    public static boolean move(String source, String dest) {
        File sourceFile = new File(source);
        File destFile = new File(dest);
        return sourceFile.renameTo(destFile);
    }

    /**
     * Copie un flus binaire vers un autre
     *
     * @param input le flus source
     * @param output le flux de destination
     * @return un entier représentant le nombre d'octets copiés
     * @throws java.io.IOException
     */
    public static int copyStream(InputStream input, OutputStream output) throws IOException {
        byte[] buffer = new byte[1024];
        int amount, total = 0;
        while ((amount = input.read(buffer)) > 0) {
            output.write(buffer, 0, amount);
            total += amount;
        }
        return total;
    }

    /**
     * Copie (duplique) le contenu d'un répertoire ou d'un fichier
     *
     * @param sourceFile Le fichier source
     * @param destFile Le fichier à créer par clonage du premier
     * @return true si la copie s'est bien terminée; false sinon
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public static boolean copy(File sourceFile, File destFile) throws FileNotFoundException, IOException {
        if (!sourceFile.exists()) {
            return false;
        }

        if (destFile.exists() && destFile.isDirectory()) {
            destFile = new File(destFile, sourceFile.getName());
        }

        if (sourceFile.isDirectory()) {
            if (!(destFile.exists() || destFile.mkdirs())) {
                return false;
            }
            for (File childFile : sourceFile.listFiles()) {
                if (!copy(childFile, new File(destFile, childFile.getName()))) {
                    return false;
                }
            }
            return true;
        }

        File destDir = destFile.getParentFile();
        if (!(destDir.exists() || destDir.mkdirs())) {
            return false;
        }

        InputStream input = new FileInputStream(sourceFile);
        OutputStream output = new FileOutputStream(destFile);
        copyStream(input, output);
        input.close();
        output.close();
        return true;
    }

    /**
     * Copie (duplique) le contenu d'un répertoire ou d'un fichier
     *
     * @param source Le fichier source
     * @param dest Le fichier à créer par clonage du premier
     * @return true si la copie s'est bien terminée; false sinon
     * @throws java.io.FileNotFoundException
     * @throws java.io.IOException
     */
    public static boolean copy(String source, String dest) throws FileNotFoundException, IOException {
        return copy(new File(source), new File(dest));
    }

    /**
     * Supprime un fichier ou un répertoire.
     * <b>N.B.:</b> La suppression d'un répertoire est récursive
     *
     * @param file le fichier ou répertoire à supprimer
     * @return true si tout se passe bien; false sinon
     */
    public static boolean delete(File file) {
        if (file.isDirectory()) {
            for (File childFile : file.listFiles()) {
                if (!delete(childFile)) {
                    return false;
                }
            }
        }
        return file.delete();
    }

    /**
     * Supprime un fichier ou un répertoire.
     * <b>N.B.:</b> La suppression d'un répertoire est récursive
     *
     * @param path le fichier ou répertoire à supprimer
     * @return true si tout se passe bien; false sinon
     */
    public static boolean delete(String path) {
        return delete(new File(path));
    }

    /**
     * Ouvre un fichier binaire en lecture
     *
     * @param path Le chamin d'accès au fichier
     * @return une référence à java.io.InputStream
     * @throws java.io.FileNotFoundException
     */
    public static InputStream open(String path) throws FileNotFoundException {
        return new FileInputStream(path);
    }

    /**
     * Ouvre un fichier binaire en écriture
     *
     * @param path Le chamin d'accès au fichier
     * @return une référence à java.io.InputStream
     * @throws java.io.FileNotFoundException
     */
    public static OutputStream create(String path) throws FileNotFoundException {
        return new FileOutputStream(path, false);
    }

    /**
     * Ouvre un fichier binaire en écriture et place le curseur en fin de
     * fichier
     *
     * @param path Le chamin d'accès au fichier
     * @return une référence à java.io.InputStream
     * @throws java.io.FileNotFoundException
     */
    public static OutputStream append(String path) throws FileNotFoundException {
        return new FileOutputStream(path, true);
    }

    /**
     * Ouvre un fichier texte en lecture
     *
     * @param path Le chamin d'accès au fichier
     * @return une référence à java.io.InputStream
     * @throws java.io.FileNotFoundException
     */
    public static BufferedReader openText(String path) throws FileNotFoundException {
        return new BufferedReader(new InputStreamReader(new FileInputStream(path)));
    }

    /**
     * Ouvre un fichier texte en écriture
     *
     * @param path Le chamin d'accès au fichier
     * @return une référence à java.io.InputStream
     * @throws java.io.FileNotFoundException
     */
    public static PrintWriter createText(String path) throws FileNotFoundException {
        return new PrintWriter(new OutputStreamWriter(new FileOutputStream(path, false)), true);
    }

    /**
     * Ouvre un fichier texte en écriture et place le curseur en fin de fichier
     *
     * @param path Le chamin d'accès au fichier
     * @return une référence à java.io.InputStream
     * @throws java.io.FileNotFoundException
     */
    public static PrintWriter appendText(String path) throws FileNotFoundException {
        return new PrintWriter(new OutputStreamWriter(new FileOutputStream(path, true)), true);
    }

//    public static void showFile(String classpath, String nameFile, String tmpFilePath, org.springframework.core.io.ResourceLoader loader) {
//        File tmpDocPDF = null, tmpDocPDF2 = null;
//        try {
//            //Chargement de la ressource pdf
//            String pathResource = "classpath:/" + classpath + nameFile;
//            org.springframework.core.io.Resource fileResource = loader.getResource(pathResource);
//            InputStream ipStream = fileResource.getInputStream();
//            //création du fichier pour le transfert
//            tmpDocPDF = null;
//            tmpDocPDF = File.createTempFile("psfeTempFile", ".pdf");
//            tmpDocPDF.deleteOnExit();
//            OutputStream out = new FileOutputStream(tmpDocPDF);
//            //transfert du fichier dans le dossier temporaire
//            int res = FileUtil.copyStream(ipStream, out);
//            tmpDocPDF2 = new File(tmpFilePath);
//            FileUtil.copy(tmpDocPDF, tmpDocPDF2);
//            if (res > 0 && Desktop.isDesktopSupported()) {
//                // si copie effectué, ouvrir le fichier
//                Desktop desktop = Desktop.getDesktop();
//                desktop.browse(tmpDocPDF2.toURI());
//            }
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, e.getMessage());
//            e.printStackTrace();
//        }
//    }

    public static void showFile(String classpath, String nameFile, String tmpFilePath) {
        File tmpDocPDF = null, tmpDocPDF2 = null;
        try {
            //Chargement de la ressource pdf
            String pathResource = "classpath:/" + classpath + nameFile;
            
            File fileResource = new File(pathResource);
            FileInputStream ipStream = new FileInputStream(fileResource);
            //création du fichier pour le transfert
            tmpDocPDF = null;
            tmpDocPDF = File.createTempFile("grecoTempFile", ".pdf");
            tmpDocPDF.deleteOnExit();
            OutputStream out = new FileOutputStream(tmpDocPDF);
            //transfert du fichier dans le dossier temporaire
            int res = FileUtil.copyStream(ipStream, out);
            tmpDocPDF2 = new File(tmpFilePath);
            FileUtil.copy(tmpDocPDF, tmpDocPDF2);
            if (res > 0 && Desktop.isDesktopSupported()) {
                // si copie effectué, ouvrir le fichier
                Desktop desktop = Desktop.getDesktop();
                desktop.browse(tmpDocPDF2.toURI());
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
            e.printStackTrace();
        }
    }
}
