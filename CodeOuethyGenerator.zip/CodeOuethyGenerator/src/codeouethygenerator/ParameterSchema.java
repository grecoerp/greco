/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeouethygenerator;

/**
 *
 * @author macbook
 */
public class ParameterSchema {
    private String name;
    private String type;
    private int length;
    private String direction;
    private int precision;
    private int scale;
    private boolean nullable;

    public ParameterSchema() {
    }

    public ParameterSchema(String name, String type, int length, String direction, int precision, int scale, boolean nullable) {
        this.name = name;
        this.type = type;
        this.length = length;
        this.direction = direction;
        this.precision = precision;
        this.scale = scale;
        this.nullable = nullable;
    }

    
    
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getLength() {
        return length;
    }

    public void setLength(int length) {
        this.length = length;
    }

    public String getDirection() {
        return direction;
    }

    public void setDirection(String direction) {
        this.direction = direction;
    }

    

    public int getPrecision() {
        return precision;
    }

    public void setPrecision(int precision) {
        this.precision = precision;
    }

    public int getScale() {
        return scale;
    }

    public void setScale(int scale) {
        this.scale = scale;
    }

    public boolean isNullable() {
        return nullable;
    }

    public void setNullable(boolean nullable) {
        this.nullable = nullable;
    }
    
    
    
}
