/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package codeouethygenerator;

/**
 *
 * @author macbook
 */
public class CodeOuethyGenerator {

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            // The newInstance() call is a work around for some
            // broken Java implementations

            Class.forName("com.mysql.jdbc.Driver").newInstance();
            
            GeneratorMainDialog frame = new GeneratorMainDialog();
            frame.setVisible(true);
            
            
        } catch (Exception ex) {
            // handle the error
        }
    }

}
